# 18世纪三组调查事件合并交付｜2026-11-08

[编辑交接与使用门禁](EDITOR_HANDOFF.md) / [162组合并事件](MERGED_EPISODE_GROUPS.json) / [原始315条ID映射](ORIGINAL_TO_GROUP.json) / [1126条完整归档](COMPLETE_1126_ARCHIVE_CROSSWALK.json)

**数据状态：research_only；一切地图几何仍待核。** `E18-MRG`用于编辑组织，绝不直接当已发布地图事件ID。

英文键、记录来源和完整URL已在JSON中。CSV供非程序员编辑筛选。原始研究ZIP以SHA256索引，保留在用户本地/当前对话附件，不覆盖。
