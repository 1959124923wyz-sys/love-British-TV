# -*- coding: utf-8 -*-
import collections,csv,datetime,hashlib,json,os,pathlib,re,zipfile,importlib.util
ROOT=pathlib.Path('/mnt/data/18c_consolidation_20261108')
TRIAGE=pathlib.Path('/mnt/data/triage_work')
spec=importlib.util.spec_from_file_location('merge_config',ROOT/'merge_config.py')
conf=importlib.util.module_from_spec(spec);spec.loader.exec_module(conf)
selected=list(csv.DictReader((TRIAGE/'SELECTED_EVENT_QUEUE.csv').open(encoding='utf-8-sig')))
allrows=list(csv.DictReader((TRIAGE/'ALL_EVENT_TRIAGE.csv').open(encoding='utf-8-sig')))
assert len(selected)==315 and len(allrows)==1126
arcs={t['story_id']:t for t in json.loads((TRIAGE/'STORY_ARCS.json').read_text())}
byarc=collections.defaultdict(list)
for row in selected:byarc[row['story_arc']].append(row)
for a in byarc.values():a.sort(key=lambda x:(int(x['year']),x['id']))

def indexes(s):
 result=[]
 for spec in s.split(','):
  if '-' in spec:
   x,y=(int(v) for v in spec.split('-'))
   assert x<=y
   result.extend(range(x,y+1))
  else:result.append(int(spec))
 return result

def dedup_terms(values):
 return list(dict.fromkeys(v for v in values if v and v.strip()))

merged=[];links=[];readable=[]
for arc_id in sorted(conf.GROUPS):
 expected=set(range(len(byarc[arc_id])));assigned=[]
 for no,(title,sidx,grade,mechanism) in enumerate(conf.GROUPS[arc_id],1):
  group_id=f'E18-MRG-{arc_id}-{no:02d}'
  idxs=indexes(sidx)
  assigned.extend(idxs)
  batch=[byarc[arc_id][i] for i in idxs]
  years=[int(x['year']) for x in batch]
  start=min(years);end=max(years)
  assert 1700<=start<=end<=1799
  sources=dedup_terms(row['assistant']+':'+s for row in batch for s in row['source_ids'].split(';') if s)
  urls=dedup_terms(u for row in batch for u in row['source_urls'].split(';'))
  srcids=dedup_terms(r['id'] for r in batch)
  orig_modes=collections.Counter(r['final_tier'] for r in batch)
  relevant_topics=dedup_terms(t for r in batch for t in (r['topic']+';'+r['all_topics'] if 'all_topics' in r else r['topic']).replace(',',';').split(';'))
  involved=dedup_terms(r['assistant'] for r in batch)
  caution=[r['review_flags'] for r in batch if any(s in r['review_flags'] for s in ['风险','冲突','争议','不足','待核','不确定'])]
  typ='series_of_distinct_actions' if end>start else 'single_year_episode_group'
  merged.append({
   'id':group_id,'story_arc_id':arc_id,'story_arc_title':arcs[arc_id]['title'],
   'title_zh':title,'start_year':start,'end_year':end,
   'source_years':sorted(set(years)),'temporal_semantics':typ,
   'map_display_tier':grade,'editorial_merge_type':mechanism,
   'editorial_status':'research_only','history_verified':False,'mapping_approved':False,
   'publication_status':'not_submitted',
   'no_assumed_continuous_activity':True,'no_assumed_single_site':len(batch)>1,
   'geometry':None,'event_site_lat':None,'event_site_lon':None,'territorial_polygons':[],
   'related_topic_ids':relevant_topics,
   'original_candidate_count':len(batch),'original_candidate_ids':srcids,
   'source_keys':sources,'source_urls':urls,
   'source_url_verification':'original_assistant_citations_not_cross_verified',
   'historical_actor_review_needed':True,
   'assistant_origins':involved,'preliminary_grade_mix':dict(orig_modes),
   'merge_justification':{
    'common_campaign':'多次交战/军事行动属于同一战争或镇压过程，编辑阶段合为专题级事件，保留各具体行动',
    'policy_series':'相同制度/政策机制多次立法或执行动作合为制度系列，禁止将中间没有证据的年份画为持续事件',
    'same_operation':'同一事件/政策的不同记录、地点或阶段，保留多地行动细节和来源差异',
    'context':'仅作历史背景材料或具体案例，不创建独立地图节点',
    'standalone':'具有独立的具体时空、责任主体和历史价值，不强行与其他事件混合'
   }[mechanism],
   'candidate_subevents':[{'original_id':r['id'],'year':int(r['year']),'date':r['date'],'title':r['title'],'description':r['summary'],'original_editorial_tier':r['final_tier'],'review_flags':r['review_flags'],'source_keys':dedup_terms(r['assistant']+':'+k for k in r['source_ids'].split(';') if k),'source_urls':dedup_terms(r['source_urls'].split(';')),'geo_status':r['geo_status'],'source_package':r['root_provenance']} for r in batch],
   'review_before_publication':['查证候审行动、日期、地点与历史主体；尤其要区分英国、当地独立国家、殖民民兵及土著反抗者','将可核日期拆为真实Atlas事件；没有地理证据不推断实际控制区域','专题正文可列全部子行动；默认地图只显示经过审核的主要节点']
  })
  for r in batch:
   links.append({'original_id':r['id'],'assistant':r['assistant'],'original_year':r['year'],'original_tier':r['final_tier'],'merged_group_id':group_id,'final_display_tier':grade,'merge_type':mechanism,'original_title':r['title'],'group_title':title,'source_package':r['root_provenance']})
 assert sorted(assigned)==sorted(expected),(arc_id,len(assigned),len(expected),collections.Counter(assigned))
assert len(links)==len(selected)==315
ids=[r['original_id'] for r in links]
assert len(set(ids))==315
assert len(merged)==162
assert collections.Counter(x['map_display_tier'] for x in merged)=={'main_candidate':82,'topic_only':58,'article_only':22}

# full original dataset is kept intact; only adds editorial bridge information.
byid={r['original_id']:r for r in links}
complete=[]
for row in allrows:
 item={'original_id':row['id'],'assistant':row['assistant'],'original_title':row['title'],'year':row['year'],'arc':row['story_arc'],'topic':row['topic'],'original_grade':row['final_tier'],'source_ids':row['source_ids'],'source_urls':row['source_urls'],'root_provenance':row['root_provenance']}
 if row['id'] in byid:
  m=byid[row['id']];item['consolidation_disposition']='assigned_to_group';item['merged_group_id']=m['merged_group_id'];item['final_display_tier']=m['final_display_tier']
 elif row['final_tier']=='归并为史料／正文':
  item['consolidation_disposition']='story_narrative_evidence';item['merged_group_id']='';item['final_display_tier']='article_only'
 elif row['final_tier']=='低价值归档':
  item['consolidation_disposition']='low_value_archive';item['merged_group_id']='';item['final_display_tier']='not_selected'
 else:
  assert row['final_tier']=='暂缓核查／前史',row
  item['consolidation_disposition']='historical_or_chronology_deferred';item['merged_group_id']='';item['final_display_tier']='deferred'
 complete.append(item)
assert len(complete)==1126
assert collections.Counter(x['consolidation_disposition'] for x in complete)=={'assigned_to_group':315,'story_narrative_evidence':432,'low_value_archive':363,'historical_or_chronology_deferred':16}

summary={'schema':'atlas-18c-consolidated-editorial-package-v1','creation_date':'2026-11-08','research_source':'Assistant A round 8; Assistant B round 7; Assistant C round 8 + editorial first-pass triage','original_event_rows':1126,'original_selected_rows':315,'merged_group_count':162,'group_display_counts':dict(collections.Counter(x['map_display_tier'] for x in merged)),'story_arcs':35,'original_unselected_narrative_rows':432,'original_low_value_archival_rows':363,'original_deferred_rows':16,'history_verified':False,'publication_approved':False,'geometry_created':False,'counts_are_editorial_not_history_statistics':True,'transformation_policy':'Groups preserve exact original candidate IDs and source citations, and preserve subevents. Multi-year historical series are not continuous yearly map control or a single location.'}

(ROOT/'CONSOLIDATION_MANIFEST.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(ROOT/'MERGED_EPISODE_GROUPS.json').write_text(json.dumps({'schema':'atlas-18c-merged-review-groups-v1','status':'research_only','groups':merged},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(ROOT/'ORIGINAL_TO_GROUP.json').write_text(json.dumps({'schema':'atlas-18c-first-pass-review-id-crosswalk-v1','source_records':links},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(ROOT/'COMPLETE_1126_ARCHIVE_CROSSWALK.json').write_text(json.dumps({'schema':'atlas-18c-full-original-record-archive-crosswalk-v1','source_records':complete},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def writecsv(path,rows,keys):
 with open(ROOT/path,'w',encoding='utf-8-sig',newline='') as f:
  writer=csv.DictWriter(f,fieldnames=keys,extrasaction='ignore');writer.writeheader();writer.writerows(rows)

flatten=[]
for e in merged:
 flatten.append({'id':e['id'],'story_arc':e['story_arc_id'],'title':e['title_zh'],'start_year':e['start_year'],'end_year':e['end_year'],'source_years':';'.join(map(str,e['source_years'])),'display_tier':e['map_display_tier'],'merge_type':e['editorial_merge_type'],'original_count':e['original_candidate_count'],'original_ids':';'.join(e['original_candidate_ids']),'topics':';'.join(e['related_topic_ids']),'source_ids':';'.join(e['source_keys']),'source_urls':';'.join(e['source_urls']),'mapping_approved':'NO','history_verified':'NO','geo':'null'})
writecsv('MERGED_EPISODE_GROUPS.csv',flatten,list(flatten[0]))
writecsv('ORIGINAL_TO_GROUP.csv',links,list(links[0]))
writecsv('COMPLETE_1126_ARCHIVE_CROSSWALK.csv',complete,list(complete[0]))

# Reference original ZIPs in manifest without duplicating the full 3 archival ZIPs inside this curated package
source_files=[pathlib.Path(x) for x in ['/mnt/data/18c_americas_round8_download(1).zip','/mnt/data/assistant2_round7_full(1).zip','/mnt/data/AiYingTV_Assistant3_Round8_All_Research_20261108(1).zip']]
original={f.name:{'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in source_files}
source_registry={};source_resolved={}
for assistant,archive in zip('ABC',source_files):
 with zipfile.ZipFile(archive) as zp:
  name=f'18c_assistant_{assistant}/SOURCE_REGISTRY.json'
  obj=json.loads(zp.read(name).decode('utf-8-sig'))
  (ROOT/f'SOURCES_{assistant}.json').write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
  sources=obj.get('sources',[])
  source_registry[assistant]={'size':len(sources),'original_file':name,'zip_sha256':original[archive.name]['sha256']}
  for item in sources:
   if isinstance(item,dict) and item.get('id'):
    source_resolved[f'{assistant}:{item["id"]}']={'url':item.get('url'),'title':item.get('title'),'institution':item.get('institution',item.get('author_or_institution')),'read_scope':item.get('actually_read_scope',item.get('reading_level',item.get('access_level','unknown')))}
allkeys={s for g in merged for s in g['source_keys']}
missing=sorted(allkeys-set(source_resolved))
(ROOT/'SOURCES_AUDIT.json').write_text(json.dumps({'schema':'atlas-18c-merged-source-namespace-v1','registries':source_registry,'all_used_source_references':len(allkeys),'unresolved_original_registry_ids':missing,'resolved':{k:source_resolved[k] for k in sorted(allkeys) if k in source_resolved}},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
# Keep each story series as a small self-contained GitHub-friendly JSON for review, avoiding one huge UI page.
series_dir=ROOT/'series'
series_dir.mkdir(exist_ok=True)
for aid in conf.GROUPS:
 set_groups=[g for g in merged if g['story_arc_id']==aid]
 (series_dir/f'{aid}.json').write_text(json.dumps({'schema':'atlas-18c-merged-series-v1','story_arc_id':aid,'arc_title':arcs[aid]['title'],'groups':set_groups},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

(ROOT/'ORIGINAL_RESEARCH_ZIP_SHA256.json').write_text(json.dumps(original,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

# Markdown summary and handoff
core=[r for r in merged if r['map_display_tier']=='main_candidate']
md=f'''# 爱英TV｜18世纪事件二次整理与地图编辑交接（2026-11-08）

**结论：将上一轮315条主图／专题候审记录压缩为162个历史事件/事件系列组合，具体为82组主图候审、58组专题内候审、22组正文材料。**

原始1126条候审记录全部保留：315条逐条关联至合并组，432条仅作为正文证据，363条低价值归档，16条历史时间/证据待核。**这里的162组是编辑用的聚合单元，并不意味着162个可直接投产的单点Atlas事件。**

### 处理标准

- **合并同一行动**：同一场驱逐中的多个拘留地点、同一战争的若干交战、同一法案的起草/批准/执行以及同一条约谈判中的多次发言，合成一个系列主条目；原动作保留在 `candidate_subevents` 中。
- **不合并不同责任主体**：1798年爱尔兰起义相关起义军杀害平民、亲政府武装屠杀和政府军镇压分开；1740年Fort Mose的西班牙建堡、自由黑人民兵反攻和英国攻堡严格分主体；1795年开普布尔居民反抗与Xhosa/Gqunukwebe抵抗分开。
- **制度与政策**：孟加拉1770年饥荒多份地方官信件融入同一专题，不把每封公文做地图节点；1793永久地税多份法案版本合并；1788—1792奴役船运输法规归入制度系列。法规发生时间与成效须另查。
- **纵贯世纪专题**：1700苏格兰达连围城撤离与1706—1707英苏联盟有关但不是同一具体事件；已结束的殖民据点不可继续绘为英国土地。
- **地图年份**：凡 `start_year≠end_year`，展示的是“多件具名事实被编为一个研究系列”，并非从第一年到末年每年连续发生或在同一坐标发生。正式地图需展开其经审节点并只在符合实际年份显示。
- **历史来源审查**：原助手引证保留在每个group的 `source_urls` 和每个 `candidate_subevents`；仍需实际访问机构原页或原档。禁止填补缺失坐标、虚构疆界、擅自扩大英国王室的实际管辖。

## 最重要的合并实例

| 原记录 | 新编辑组合 | 处理说明 |
|---|---|---|
| 7条阿卡迪亚1755年拘押/驱逐节点 | 1755年阿卡迪亚驱逐令及多地行动 | 总地图显示主要行动；Grand-Pré、Fort Edward、Annapolis等可作专题内部多地点，不应全部堆在主图 |
| 7条1795—96年圣文森特战事节点 | 第二次Carib战争与Garifuna抵抗 | 单一战役系列，1797年流放Roatán另设重大节点 |
| 9条1770—72年孟加拉饥荒/税务往来 | 孟加拉大饥荒、公司税务及地方官往来 | 独立正文设财政、人口和粮食证据分节，各官员报告不各画一个图标 |
| 6条1799年迈索尔政变/战利品/分治 | 斯里兰加帕特纳攻陷、战利品及迈索尔分治 | 攻城、财产转移、占领权与战后附属条约需在专题章节区分 |
| 4条1735—1737及1744年宾州地权争议 | Walking Purchase / Lancaster大会 | 两个不同法律政治过程，分别成组 |
| 4条1700年达连最后远征记录 | 达连西班牙围城和殖民者撤离 | 前17世纪系列E6-T04-DARIEN后续；1707年联合单列 |
| 4条1796年摩鹿加安汶英方接管 | 安汶驻地与荷属香料垄断 | 英军实际占领据点，不表示控制所有香料岛土著土地 |

## GitHub内每类文件的用途

1. `MERGED_EPISODE_GROUPS.json`：**最重要**，162组元数据、子事件、证据URL、源记录、历史时段与制图门禁。一个组可以在正式Atlas中拆为多个事实核准的点。
2. `MERGED_EPISODE_GROUPS.csv`：便于按年、系列、优先级筛选的扁平队列。
3. `ORIGINAL_TO_GROUP.json`/`.csv`：315条被选记录到162组的逐条不可逆丢失防护映射。
4. `COMPLETE_1126_ARCHIVE_CROSSWALK.json`/`.csv`：完整1126条记录的归档关系；不应从低价值归档中直接生成Atlas。
5. `CONSOLIDATION_MANIFEST.json`：总数、版本和语义门禁。
6. `ORIGINAL_RESEARCH_ZIP_SHA256.json`：原始三个ZIP的SHA-256，用于对照原件。
7. `EDITOR_HANDOFF.md`：你正在阅读的主编/地图编辑交接说明。

## 地图编辑同事可以开始的工作

**先做一批有地理核心且史料明确的专题**：阿卡迪亚1755、马龙战争与流放1739及1795—96、孟加拉普拉西至Diwani 1757—65及1770饥荒、迈索尔1792/1799、1795开普、1788新南威尔士、1798爱尔兰。

对于每个主题：按原 `story_arc_id` 识别系列，调 `candidate_subevents` 引证；从原档确认真实地点/日期/各方，再编逐年Atlas，并向旧17世纪稳定专题ID回链。**同一个组不得直接假定一个GPS。** 对历史不确定的疆界只能用经论证的虚线表示，不能根据现代国家、省或县边界涂色。

**不许自动导入地图**：当前研究JSON不在正式`data/chapters.json`，事件ID `E18-MRG-...` 是研究合并组编号，不是已审Atlas事件ID。正式Atlas事件仍需自己的、可点击的稳定ID及 `[[已核事件ID|历史叙述动作]]`；专题的单击、双击档案与返回流程要通过桌面地图测试。

## 协作和领取规则

各同事选取一个 `Txx` 系列或一个地域/时期，不要同时改 `data/chapters.json` 与公共Atlas同一十年。建议每人单独GitHub分支/PR；主编审查来源与空间语义后合并，不能绕过17世纪连续性审核。研究元数据可在本目录更新，但**不得直接改写旧 `E6-` 事件身份或已发表地理图层**。

## 质量核对

- 每条选中记录在 `ORIGINAL_TO_GROUP.json` 关联且只关联一个162组ID。
- 每组中的 `source_urls` 与 `candidate_subevents` 保留助手出处，研究来源本身未验证，不能自称查阅了原始卷页。
- 162组地理几何与具体经纬度均为空；未产生任何殖民控制新多边形。
- 现有35系列ID为编辑规划，不是35个新建公开频道，也不意味着原105题已废弃。
'''
(ROOT/'EDITOR_HANDOFF.md').write_text(md,encoding='utf-8')
(ROOT/'README.md').write_text('''# 18世纪三组调查事件合并交付｜2026-11-08

[编辑交接与使用门禁](EDITOR_HANDOFF.md) / [162组合并事件](MERGED_EPISODE_GROUPS.json) / [原始315条ID映射](ORIGINAL_TO_GROUP.json) / [1126条完整归档](COMPLETE_1126_ARCHIVE_CROSSWALK.json)

**数据状态：research_only；一切地图几何仍待核。** `E18-MRG`用于编辑组织，绝不直接当已发布地图事件ID。

英文键、记录来源和完整URL已在JSON中。CSV供非程序员编辑筛选。原始研究ZIP以SHA256索引，保留在用户本地/当前对话附件，不覆盖。
''',encoding='utf-8')

# archive with all 9 deliverables; no original 3 massive sources duplicated
zip_path=pathlib.Path('/mnt/data/18C_Consolidated_Research_Handoff_20261108.zip')
with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in ROOT.glob('*'):
  if f.suffix in ['.csv','.json','.md','.py']:
   z.write(f,arcname='18c_consolidation/'+f.name)
 for f in (ROOT/'series').glob('T*.json'):
  z.write(f,arcname='18c_consolidation/series/'+f.name)
 print('Zip manifest',len(z.namelist()),'entries, bytes',zip_path.stat().st_size)
print('Success',len(merged),'merged groups',len(links),'crosswalk',len(complete),'archive crosswalk')
print('Distribution',collections.Counter(x['map_display_tier'] for x in merged))
print('First 10 group titles',[x['title_zh'] for x in merged[:10]])
