# -*- coding: utf-8 -*-
# Curated editorial grouping of 315 first-pass selected records. Index per arc is
# zero-based after sorting by (numeric year, source ID). Not scientific evidence.
# (label, selected-row-index-list, display tier, treatment)
# display tier: main_candidate | topic_only | article_only
# treatment: common_campaign | policy_series | same_operation | context | standalone
GROUPS={
'T01':[
 ('1722—1765年英国奴隶船上的多起反抗（比较案例）','0,2,4','article_only','policy_series'),
 ('1748年南卡靛蓝补贴政策','1','article_only','standalone'),
 ('1750年西非贸易机构重组','3','article_only','standalone'),
 ('1772—1778年英格兰与苏格兰奴役地位诉讼（比较案例）','5-6','topic_only','policy_series'),
 ('1781年圣尤斯特歇斯战利品拍卖与没收','7','topic_only','same_operation'),
 ('1788年英国奴隶船人数规制立法','8','topic_only','standalone'),
 ('1792年英国议会渐进禁贸动议未形成法律','9','main_candidate','standalone')],
'T02':[
 ('1720年Old Calabar船舶购奴的局部史料','0','article_only','context'),
 ('1767年Old Calabar伏击及人口掳卖','1','main_candidate','standalone'),
 ('1781—1783年宗号杀人及保险索赔审判','2-4','main_candidate','same_operation')],
'T03':[
 ('1730年百慕大限制自由黑人与原住民政策','0','topic_only','standalone'),
 ('1760—1788年牙买加奴役法律与惩罚制度变更','1,8','topic_only','policy_series'),
 ('1760年牙买加Tacky起义','2','main_candidate','standalone'),
 ('1765年St Mary Blackwall庄园反抗','3','topic_only','standalone'),
 ('1767年牙买加地方自由/补偿法条','4','article_only','context'),
 ('1774年牙买加被疑起义与个人特赦文书','5-6','article_only','context'),
 ('1781年圣尤斯特歇斯犹太居民抗议英军没收','7','topic_only','same_operation')],
'T04':[
 ('1718年牙买加殖民地追捕马龙社区政策','0','article_only','context'),
 ('1730—1739年第一次马龙战争及双边和约','1-5','main_candidate','common_campaign'),
 ('1769—1788年马龙社区自治受殖民法律约束','6-7','topic_only','policy_series'),
 ('1795—1796年第二次马龙战争与强制流放决定','8-9','main_candidate','common_campaign'),
 ('1796年Trelawny马龙居民强制流放新斯科舍','10','main_candidate','standalone')],
'T05':[
 ('1767年圣文森特奴役财产权法条','0','article_only','context'),
 ('1795—1796年第二次Carib战争与Garifuna抵抗','1-7','main_candidate','common_campaign'),
 ('1797年Garifuna大规模强制迁往Roatán','8','main_candidate','standalone')],
'T06':[
 ('1793—1798年英军介入并占领圣多明各部分港口后撤离','0-3,7-8','main_candidate','common_campaign'),
 ('1795—1796年Fédon起义及英国殖民军事镇压','4-6','main_candidate','common_campaign')],
'T07':[
 ('1704年新英格兰军队袭击阿卡迪亚村镇','0','topic_only','standalone'),
 ('1749年新斯科舍殖民政府的Mi’kmaq敌对政策','1','topic_only','standalone'),
 ('1755年Beauséjour堡垒归属改变','2','topic_only','standalone'),
 ('1755年阿卡迪亚驱逐令及多地拘押运输行动','3-9','main_candidate','common_campaign'),
 ('1758年Île Saint-Jean占领及驱逐','10','main_candidate','standalone'),
 ('1761年Mi’kmaq不同社区的和平友好条约','11-12','topic_only','policy_series')],
'T08':[
 ('1740年英属佐治亚围攻St Augustine失败','0','topic_only','standalone'),
 ('1745年新英格兰与英海军夺取Louisbourg','1','main_candidate','standalone'),
 ('1759年尼亚加拉堡易手','2','topic_only','standalone'),
 ('1760年蒙特利尔法国驻军投降','3','main_candidate','standalone'),
 ('1763年Odawa及盟友围攻底特律','4','main_candidate','standalone'),
 ('1763年乔治三世王室公告及界线主张','5','main_candidate','standalone'),
 ('1763年Paxton殖民定居者杀害Conestoga','6','topic_only','standalone'),
 ('1764年Presque Isle临时和约条件','7','topic_only','standalone'),
 ('1770—1773年Cherokee/Creek土地谈判与以债抵地','8-9','main_candidate','policy_series'),
 ('1774年魁北克法与殖民地治理重组','10','main_candidate','standalone'),
 ('1775年佐治亚商人追索原住民土地抵债','11','article_only','context')],
'T09':[
 ('1712—1713年Tuscarora战争、Nooherooka攻陷与俘虏','0-3','main_candidate','common_campaign'),
 ('1715年Yamasee及盟友战争反抗','4','main_candidate','standalone'),
 ('1715—1716年卡罗来纳战后条约及贸易规制','5-6','topic_only','policy_series'),
 ('1723年北卡获释者驱逐法条','7','article_only','standalone'),
 ('1732年乔治亚皇家托管殖民特许','8','topic_only','standalone')],
'T10':[
 ('1735—1737年宾夕法尼亚Walking Purchase土地欺诈','0-1','main_candidate','same_operation'),
 ('1744年Lancaster大会土地争议与多轮陈词','2-5','topic_only','same_operation')],
'T11':[
 ('1705年弗吉尼亚奴役及仆役法典','0','main_candidate','standalone'),
 ('1712年纽约被奴役者反抗后的殖民处决','1','main_candidate','standalone'),
 ('1729年马里兰奴役人口刑罚法条','2','article_only','standalone'),
 ('1735年乔治亚禁奴制度','3','topic_only','standalone'),
 ('1738年西班牙佛罗里达Fort Mose自由黑人据点','4','article_only','context'),
 ('1739年Stono起义及殖民民兵追捕杀害','5-6','main_candidate','same_operation'),
 ('1740年南卡罗来纳奴役法典','7','main_candidate','standalone'),
 ('1740年英属佐治亚攻占Fort Mose后遭西班牙反攻','8-9','topic_only','same_operation')],
'T12':[
 ('1764—1767年英国议会北美殖民地征税与货币限制','0-2','main_candidate','policy_series'),
 ('1774年英议会关闭波士顿港惩罚措施','3','main_candidate','standalone'),
 ('1775年Dunmore宣布对特定反英奴隶主劳工附条件自由','4-5','main_candidate','same_operation'),
 ('1781年约克镇英军投降','6','main_candidate','standalone'),
 ('1783年巴黎和约对被奴役人口撤运限制条款','7','topic_only','standalone'),
 ('1793年Chloe Cooley遭强制售往美国','8','topic_only','standalone'),
 ('1794—1795年Jay条约美英西部据点撤离安排','9-10','topic_only','same_operation')],
'T13':[
 ('1700年纽芬兰1699年渔业法相关条款开始施行','0','topic_only','standalone'),
 ('1713—1714年HBC部分海湾堡垒依和约交接','1-3','main_candidate','same_operation'),
 ('1715年Thanadelthur推动Dene—Cree外交','4','main_candidate','standalone'),
 ('1732年Prince of Wales Fort建造','5','topic_only','standalone'),
 ('1754年Henday在Cree向导帮助下赴内陆','6','article_only','standalone'),
 ('1782年法军夺取哈德孙湾公司两个堡垒','7-8','main_candidate','same_operation'),
 ('1783年巴黎和约纽芬兰渔业条款','9','topic_only','standalone')],
'T14':[
 ('1756年孟加拉纳瓦卜夺取威廉堡','0','main_candidate','standalone'),
 ('1757年普拉西战役与孟加拉纳瓦卜政权更替','1','main_candidate','standalone'),
 ('1760年Mir Qasim接任及公司地税收入安排','2','topic_only','standalone'),
 ('1764年布克萨尔战役','3','main_candidate','standalone'),
 ('1765年Diwani授予与阿拉哈巴德赔款体系','4-5','main_candidate','same_operation'),
 ('1767年英国议会征收公司印度收益年款','6','topic_only','standalone'),
 ('1775—1781年阿瓦德Begams财产承诺与强行剥夺','7-8','main_candidate','policy_series'),
 ('1785年相关纳瓦卜财务偿付协商','9','article_only','context'),
 ('1793年英国议会续授权东印度公司贸易政治权力','10','topic_only','standalone')],
'T15':[
 ('1770—1772年孟加拉大饥荒、公司税务及地方官往来','0-8','main_candidate','common_campaign')],
'T16':[
 ('1762年孟加拉征税承包改革','0','topic_only','standalone'),
 ('1770年Rajshahi饥荒税额与实收差异','1','article_only','context'),
 ('1773年公司占领Baikunthpur与Sannyasi反抗','2','topic_only','standalone'),
 ('1786年孟加拉税务委员会重组','3','article_only','standalone'),
 ('1793年孟加拉永久地税制度颁布','4-6','main_candidate','same_operation'),
 ('1799年Midnapore Jungle Mahals地方地权武装反抗','7','main_candidate','standalone')],
'T17':[
 ('1769年迈索尔军逼近马德拉斯迫使议和','0','main_candidate','standalone'),
 ('1780—1781年Pollilur两场战斗（战果各异）','1-2','topic_only','common_campaign'),
 ('1784年芒格洛尔英—迈索尔和约','3','main_candidate','standalone'),
 ('1792年斯里兰加帕特纳和约及王子人质条款','4-5','main_candidate','same_operation'),
 ('1799年斯里兰加帕特纳攻陷、战利品及迈索尔分治','6-11','main_candidate','common_campaign')],
'T18':[
 ('1774年罗希拉战争中卡特拉战役','0','main_candidate','standalone'),
 ('1775—1782年第一次英—马拉塔战争与多次条约','1-4,6-7','main_candidate','common_campaign'),
 ('1781年贝拿勒斯Chait Singh反抗Hastings','5','main_candidate','standalone')],
'T19':[
 ('1761—1763年本地治里法军驻军投降及返还安排','0-1','topic_only','policy_series'),
 ('1798年海得拉巴与公司附属军队条约','2','main_candidate','standalone'),
 ('1798—1799年Kattabomman税权抗争和公司攻堡','3-4','main_candidate','common_campaign')],
'T20':[
 ('1709年联合东印度公司组织完成','0','topic_only','standalone'),
 ('1748年胡椒专卖和公司商业特许','1','article_only','standalone'),
 ('1772—1773年东印度公司财务危机、孟加拉税政及规制法','2-7','main_candidate','policy_series'),
 ('1775年贝拿勒斯贡赋重订安排','8','article_only','context')],
'T21':[
 ('1773—1799年比哈尔鸦片专卖及合同/限制法令演变','0-1,3,7-8','main_candidate','policy_series'),
 ('1780—1788年孟加拉盐业专卖收购与销售制度','2,4','main_candidate','policy_series'),
 ('1792年南印度歉收饥困与济助函件','5-6','topic_only','same_operation')],
'T22':[
 ('1762—1764年英军占领马尼拉、赎金争议及撤离','0-3','main_candidate','common_campaign')],
'T23':[
 ('1775年Balambangan商馆被袭与撤离','0','topic_only','standalone'),
 ('1786—1791年槟城驻地及与吉打的年款条约','1-2,4-5','main_candidate','policy_series'),
 ('1789年南安达曼流放殖民试验','3','topic_only','standalone'),
 ('1796年英军夺取安汶及维持香料垄断','6-7,9','main_candidate','same_operation'),
 ('1796年英军登陆及占据班达群岛堡垒','8,10-11','main_candidate','same_operation')],
'T24':[
 ('1791年Cochin与英国驻官员早期协议','0','topic_only','standalone'),
 ('1795年英国接管Trincomalee和Cochin据点','1-2','main_candidate','common_campaign'),
 ('1795年康提国王与英国订友好条约','3','topic_only','standalone'),
 ('1796年英军接管Colombo及Galle荷兰堡垒','4-5','main_candidate','same_operation'),
 ('1797年锡兰海岸反对英方税政的抗议','6','main_candidate','standalone')],
'T25':[
 ('1795年英军登陆并迫使开普VOC政权投降','0-3','main_candidate','common_campaign'),
 ('1799年Graaff-Reinet布尔居民起义及英军镇压','4-5','main_candidate','same_operation'),
 ('1799年Gqunukwebe武装抵抗英军与Zuurveld谈判','6-7','main_candidate','same_operation')],
'T26':[
 ('1727年达荷美征服Hueda（非英国行动背景）','0','article_only','context'),
 ('1750—1752年英议会重组非洲贸易商公司及城堡','1-3','main_candidate','policy_series'),
 ('1758年英军取得圣路易据点','4','main_candidate','standalone'),
 ('1763年英法塞内加尔/Gorée据点和约分配','5','topic_only','standalone'),
 ('1779年法军再夺圣路易英方驻地','6','topic_only','standalone'),
 ('1783年英法西非据点与甘比亚条约安排','7-8','topic_only','same_operation'),
 ('1788—1792年英国奴役船载运人数限制与续法','9-12','main_candidate','policy_series')],
'T27':[
 ('1728年RAC撤出Bunce岛堡','0','article_only','standalone'),
 ('1792年黑人民兵及前效忠派集体迁居塞拉利昂','1','main_candidate','standalone'),
 ('1799年黑人塞拉利昂定居者与公司土地权争议','2-3','main_candidate','same_operation')],
'T28':[
 ('1770—1774年西班牙驱逐Port Egmont英驻军及英方撤站','0-1','topic_only','policy_series'),
 ('1798—1799年马耳他居民反法起义及英国海军封锁','2-3','topic_only','same_operation')],
'T29':[
 ('1703—1705年爱尔兰天主教地权与宗教惩罚法','0-4','main_candidate','policy_series'),
 ('1720年英国爱尔兰依附宣示法','5','topic_only','standalone'),
 ('1762年Whiteboys农民地权及征税抗争','6','topic_only','standalone'),
 ('1778年爱尔兰天主教地权法律部分放宽','7','topic_only','standalone'),
 ('1782年英国撤销1720爱尔兰依附宣示法','8','topic_only','standalone')],
'T30':[
 ('1797年爱尔兰起义前军事戒严与解除武装','0','main_candidate','standalone'),
 ('1798年联合爱尔兰人起义、主要战役与镇压','1-6,8,11-12','main_candidate','common_campaign'),
 ('1798年Scullabogue拘押者遇害（起义方责任）','9','topic_only','standalone'),
 ('1798年Dunlavin亲政府武装杀害被拘者','10','topic_only','standalone'),
 ('1798年Vinegar Hill战后亲政府报复暴力','7','topic_only','standalone')],
'T31':[
 ('1700年苏格兰达连第二远征被西班牙围攻撤离','0-3','main_candidate','same_operation'),
 ('1706—1707年英苏联合条约、司法及达连赔偿安排','4-8','main_candidate','policy_series'),
 ('1725年苏格兰麦芽税暴动及镇压','9','topic_only','standalone')],
'T32':[
 ('1715—1716年詹姆斯党第一次起义及政府缴械','0-2','topic_only','common_campaign'),
 ('1719年Glenshiel詹姆斯党战争','3','topic_only','standalone'),
 ('1725年苏格兰再次缴械政策','4','article_only','context'),
 ('1745—1746年詹姆斯党起义、Culloden及战俘外运','5-7','main_candidate','common_campaign'),
 ('1747—1748年高地服饰禁令及世袭法权终止','8-9','main_candidate','policy_series'),
 ('1792年高地Year of the Sheep清场反抗','10','main_candidate','standalone')],
'T34':[
 ('1717—1786年英国与爱尔兰罪犯海外流放制度','0,2','topic_only','policy_series'),
 ('1785—1788年新南威尔士殖民筹备、第一舰队及悉尼定居','1,3-5','main_candidate','common_campaign'),
 ('1790—1791年第二、第三舰队继续强制运送囚犯','6-9','main_candidate','policy_series')],
'T35':[
 ('1788—1791年殖民地抓捕Arabanoo并扩大Rose Hill等农业据点','0-1,7','main_candidate','common_campaign'),
 ('1789—1791年港湾船只、武器与原住民反抗冲突','2,5-6','article_only','policy_series'),
 ('1790年Phillip下令武装惩罚性远征','3-4','main_candidate','same_operation'),
 ('1792—1794年Pemulwuy抵抗与Toongabbie暴力','8-9','main_candidate','common_campaign'),
 ('1795年Hawkesbury原住民抵抗与军队镇压','10-12','main_candidate','common_campaign'),
 ('1797年Pemulwuy抵抗行动及殖民追捕','13','topic_only','standalone'),
 ('1799年Hawkesbury两名原住民男孩遇害审判','14','topic_only','standalone')],
}
