# 1739—1741｜英国皇家海军对西属加勒比港口的袭击与失败

**定位**：第七轮地区扩查深入调查；`research_only`。本篇为逐条有来源的事件候选整合，非已刊发地图故事。

## 背景—决策

1739年英西进入海军殖民战争阶段，Edward Vernon指挥皇家舰队攻击西属加勒比要港Portobelo。英国海军实际于11月21日围攻港口防御、11月22日接受西班牙守军投降，拆毁军事设施并取得部分战利品。1741年又以更大规模远征进攻Cartagena de Indias，却未成功夺下城市。

## 实际行动、具名地点与时间

### 1739-11-21｜英国皇家海军Vernon舰队炮击巴拿马Portobelo的Iron Castle

事件ID：`E18A7-1739-PORTO-IRON-FORT`。英国海军Vernon指挥六艘战舰围攻巴拿马加勒比岸的Puerto Bello/Portobelo，11月21日下午炮击其港口Iron Castle防御设施；原有居民与西班牙驻军是不同角色。

**行为主体**：Admiral Edward Vernon; Spanish defenders；**地点**：Iron Castle, Puerto Bello / Portobelo, Panama；**证据来源**：R7050。

### 1739-11-22｜Portobelo西班牙总督向Vernon投降，英国海军缴获财物并拆堡

事件ID：`E18A7-1739-PORTO-SURRENDER`。皇家格林尼治博物馆记11月22日当地西班牙总督接受英军投降条件，英国海军缴获船只和军械，分配驻军公款并拆毁堡垒。投降书中约定的一万美元及战利品不能自动视为实际伦敦财政收益。

**行为主体**：Vernon fleet; Governor Francisco Martínez de Retez；**地点**：Portobelo, Panama；**证据来源**：R7050。

**数字口径**：馆藏记投降条款为十千美元，不等于财库实得、海员获益或英国财政净额。

### 1741-04｜英国海陆军大规模进攻Cartagena de Indias但未攻下城市

事件ID：`E18A7-1741-CARTAGENA-SIEGE-FAILED`。Vernon和其他英国将领在1741年4月攻打西属哥伦比亚Cartagena de Indias，西班牙守军由Blas de Lezo等组织成功防御。英国纪念奖章曾预刻“英军占领”，与真实战斗结果相反；不能将奖章字句当成控制改变。

**行为主体**：Admiral Edward Vernon; General Wentworth; Blas de Lezo；**地点**：Cartagena de Indias / Boca Chica, Colombia；**证据来源**：R7051。

**争议**：英国纪念奖章印有“占领卡塔赫纳”，皇家博物馆正文明确判定1741年攻击失败。

## 受影响群体、抵抗、经济后果与长期影响

实际战事不仅有英国舰队和西班牙守军，也牵涉西属美洲港口的民间商业和被奴役人口。皇家格林尼治博物馆收藏了英国曾预先宣传Cartagena胜利的奖章，馆藏文字明确指出占领失败，因此奖章文字绝对不能作为地图换旗证据。

## 地图和统计审查

Portobelo沿海军事行动只能标具名堡垒和港口，不能沿地图填出巴拿马大陆实控区。馆藏所记公款分配、投降条款一万美元与英国实际战利品净收益须分开核实。

本篇事件的经纬度若为空，即只能以历史地名呈现；一切现代遗址Point仅作为**现代位置参照**，未经核实的主权边界、种植园面积、强迫迁移航迹全部不绘Polygon/LineString。

## 资料来源与实际阅读范围

- `R7050`：The Capture of Puerto Bello, 21 November 1739；https://www.rmg.co.uk/collections/objects/rmgc-object-11846；**阅读层级**：1739 Nov 21 attack Iron Castle; Nov 22 Spanish capitulation; money distribution, removal fortifications; sum in capitulation not evidence cash transferred。
- `R7051`：Medal commemorating Vernon attack on Cartagena, 1741；https://www.rmg.co.uk/collections/objects/rmgc-object-38515；**阅读层级**：Cartagena attacked April 1741, British failed despite propaganda medals falsely depicting Spanish surrender。

## 下一阶段具体查核

依事件来源ID逐件查原卷或国家机构提供的数字副本，记录卷号、页码、原文异文与反方当事人证词；画地图之前再审历史名称及权属。
