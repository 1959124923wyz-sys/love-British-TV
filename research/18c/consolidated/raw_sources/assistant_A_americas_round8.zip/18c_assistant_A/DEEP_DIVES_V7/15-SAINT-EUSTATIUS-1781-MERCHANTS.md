# 1781｜英国圣尤斯特歇斯岛占领、财物没收与犹太居民驱逐

**定位**：第七轮地区扩查深入调查；`research_only`。本篇为逐条有来源的事件候选整合，非已刊发地图故事。

## 背景—决策

1781年2月3日英国海军上将George Brydges Rodney及陆军John Vaughan攻占荷兰自由贸易港St Eustatius。该港是加勒比、欧洲和北美间重要转运站，英方查封大量在港货物、储藏设施和船只。

## 实际行动、具名地点与时间

### 1781-02-03｜英国Rodney与Vaughan联合远征夺取荷属圣尤斯特歇斯岛

事件ID：`E18A7-1781-STATIA-CAPTURE`。英国舰队和陆军要求荷兰总督De Graaff投降并占领加勒比自由贸易港圣尤斯特歇斯；随后收取泊港船舶和仓储货物。占领港口与收缴商货相互有关，却不意味当地所有私人资产都依法成为皇家财产。

**行为主体**：Admiral George Brydges Rodney; General John Vaughan; Governor Johannes de Graaff；**地点**：Oranjestad, St Eustatius；**证据来源**：R7052, R7053, R7054。

**数字口径**：在港130余艘与后续200余艘为不同阶段及不同来源估数，不得相加。

### 1781-02-13｜英国驻军对圣尤斯特歇斯犹太商人集体搜身、没收财物并驱逐多人

事件ID：`E18A7-1781-STATIA-SEARCH-DEPORT`。Abbattista依据当时请愿和英国议会记录，记2月13日英国军方特别要求犹太男性户主接受搜查，没收钱物并将约30人驱逐；其他商人亦被没收资产。宗教歧视是否为指挥官唯一动机在学术讨论中有不同解释。

**行为主体**：Rodney/Vaughan occupation forces; Sephardic Jewish community；**地点**：Oranjestad waterfront, St Eustatius；**证据来源**：R7052。

**争议**：研究者在“指挥官是否出于反犹主义动机”上存分歧；可确认区别对待及个体驱逐、搜查。

**数字口径**：“约30人”是学术文章引用当代资料的被驱逐户主规模，不能自动当全部犹太人口或实际抵达St Kitts人数。

### 1781-02-16｜圣尤斯特歇斯犹太居民集体请愿反对英国军官驱逐与没收

事件ID：`E18A7-1781-STATIA-HEBREW-PETITION`。圣尤斯特歇斯犹太社区在2月16日向英国占领军提出请愿，追问对其家庭驱逐、没收财产的法理依据；他们也援引自己或亲属的英国臣民身份和信仰自由的权利。诉求和英方对它的回应分别记录。

**行为主体**：Hebrew nation petitioners; Rodney and Vaughan；**地点**：St Eustatius, Dutch Caribbean；**证据来源**：R7052。

### 1781-03｜英国占领军在圣尤斯特歇斯组织缴获货物拍卖与战利品处置

事件ID：`E18A7-1781-STATIA-SEIZURE-AUCTIONS`。1781年2—3月，英军登记泊港船只与仓储货物并组织拍卖，许多商人财物被收缴。伦敦贸易商、犹太商人与荷兰居民围绕财物归属提出异议，英国方面出现大量诉讼。登记/估值/实际变现净额必须区分。

**行为主体**：Rodney prize agents; merchants of St Eustatius；**地点**：Oranjestad lower town warehouses, St Eustatius；**证据来源**：R7052, R7053, R7054。

**数字口径**：争议估值约200—300余万英镑属于当代不同估价，不是英王实际收到可核净收益。

### 1781-03-30｜英国王室向Rodney及Vaughan发出占领所得与私人产权限制指示

事件ID：`E18A7-1781-STATIA-PRIZE-INSTRUCTIONS`。学术论文引1781年3月30日王室指示，限制可合法没收财物类别，包括对居民个人财物的保护，文件直到4月才送抵军官。发布命令与实际返还需要查逐船拍卖及后续诉讼，不可假设已赔偿。

**行为主体**：British Crown; Admiralty; Rodney and Vaughan；**地点**：London to St Eustatius, legal instruction only；**证据来源**：R7052, R7053。

**争议**：3月30日文件发出与4月抵达军营是两个阶段；未证每件被没收财物已返还。

## 受影响群体、抵抗、经济后果与长期影响

受害人包括荷兰、英国籍商人和塞法迪犹太居民。独立学术论述援引2月13日英军集中搜查犹太男性户主、驱逐部分商人的证据；2月16日社区还提出具名请愿，质疑处罚法律依据。对Rodney是否主要出于宗教仇恨动机有学术争论，但没收和集体区别对待已获支持。3月30日英国王室限缩合法没收财产的指示不等于实际已返还财物。

## 地图和统计审查

英国舰队占领的是荷兰港城与军事设施，不能把现代圣尤斯特歇斯岛全图当成精准1781年实控边界；荷兰原有商贸设施、黑人奴役劳动和自由群体需单列。英军货物估值、后续拍卖净额与商人诉讼判决仍应留null，优先查CO 318/7-8、ADM 1/314、奖品法庭和议会文字。

本篇事件的经纬度若为空，即只能以历史地名呈现；一切现代遗址Point仅作为**现代位置参照**，未经核实的主权边界、种植园面积、强迫迁移航迹全部不绘Polygon/LineString。

## 资料来源与实际阅读范围

- `R7052`：Edmund Burke, the Atlantic American war and the poor Jews at St Eustatius；https://oajournals.fupress.net/index.php/cromohs/article/download/16454/14912?inline=1；**阅读层级**：1781 Feb3 Rodney Vaughan seize Dutch island; Feb13 forcible search and exile Jewish male heads; Feb16 Hebrew Nation petition; 30 Mar Crown property instructions; historian disputes whether Rodney motive specifically antisemitic。
- `R7053`：Making Money from the Royal Navy in the Late Eighteenth Century: Charles Kerr on Antigua；https://doi.org/10.1080%2F00253359.2021.1978257；**阅读层级**：1781 Feb3 St Eustatius surrendered to Rodney Vaughan, 130 ships at anchor seized and further seizures, legal disputes of prize money。
- `R7054`：St Eustatius in the American Revolution (1903)；https://penelope.uchicago.edu/Thayer/E/Journals/AHR/8/4/StEustatius_in_the_American_Revolution%2A.html；**阅读层级**：1781 English seizure, merchant protests to UK Parliament, Edmund Burke debate, archival documents。

## 下一阶段具体查核

依事件来源ID逐件查原卷或国家机构提供的数字副本，记录卷号、页码、原文异文与反方当事人证词；画地图之前再审历史名称及权属。
