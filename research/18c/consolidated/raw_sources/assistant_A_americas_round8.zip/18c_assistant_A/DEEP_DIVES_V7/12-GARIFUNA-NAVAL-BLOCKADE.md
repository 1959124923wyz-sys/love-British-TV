# 1795—1796｜皇家海军镇压Grenada与St Vincent抗争

**定位**：第七轮地区扩查深入调查；`research_only`。本篇为逐条有来源的事件候选整合，非已刊发地图故事。

## 背景—决策

Douglas Hamilton的同行评审研究汇引英国海军日志，显示英军舰艇攻击圣文森特Kalinago/Black Carib运输独木舟、岸上集会及与欧洲革命力量之间的联系，以断绝反抗者跨岛支援。

## 实际行动、具名地点与时间

### 1795-03-08｜圣文森特Kalinago和被奴役者组织武装反抗英国殖民土地占领

事件ID：`E18A7-1795-VINCENT-1795-RAISE`。3月8日反抗发生，Kalinago领袖Chatoyer与其他政治主体反对英国自1770年代以来占用原住民土地；不同参与者的诉求并不完全相同。

**行为主体**：Joseph Chatoyer; Kalinago communities; enslaved workers；**地点**：St Vincent eastern/northern territories；**证据来源**：N18。

### 1795-03-12｜Kalinago反抗军推进Kingstown外围并夺取Dorsetshire Hill英方堡垒

事件ID：`E18A7-1795-VINCENT-1795-KINGSTOWN`。Hamilton记至3月12日Kalinago已抵达Kingstown外围并夺取山上英军据点；后续英海军、民兵夺回，但具体夺回日另查。

**行为主体**：Joseph Chatoyer and Kalinago; British militia, HMS Roebuck and Zebra；**地点**：Dorsetshire Hill, St Vincent；**证据来源**：N18。

### 1795-04｜英国海军袭击Kalinago海岸船只并毁坏16条独木舟

事件ID：`E18A7-1795-VINCENT-1795-CANOES`。Hamilton据Roebuck原舰日志引述，英方海军登陆攻击用于原住民跨岛运补的船只，烧毁16条独木舟；被打死的本地人数无可靠总数。

**行为主体**：HMS Roebuck; local naval detachments; Kalinago seafarers；**地点**：North side unspecified bay, St Vincent；**证据来源**：N18。

**数字口径**：16是本次海岸袭击中被毁船只数，不是全部Kalinago独木舟或人口死亡数。

### 1795-04-11｜HMS Roebuck海军人员参与夺取Calliagua抵抗阵地

事件ID：`E18A7-1795-VINCENT-1795-CALLIAQUA`。海军日志列Lieutenant Grove及30人参与登陆、攻取Calliagua村落；不能由此认定圣文森特东海岸所有Kalinago地权已废止。

**行为主体**：Lieutenant Grove; HMS Roebuck; Kalinago defenders；**地点**：Calliagua, St Vincent；**证据来源**：N18。

### 1795-07｜英国军舰炮击Chateaubelair附近岸上Kalinago抵抗者

事件ID：`E18A7-1795-VINCENT-1795-CAMPFIRE`。Roebuck舰船记录英军向Chateaubelair山丘抵抗者以九磅、六磅火炮射击，属于岸上军事镇压行动，海面炮位不应制造GIS航迹。

**行为主体**：HMS Roebuck; Kalinago fighters；**地点**：Chateaubelair area, St Vincent；**证据来源**：N18。

### 1796-06｜Abercromby增援迫使圣文森特Kalinago反抗军在军事压力下停战

事件ID：`E18A7-1796-VINCENT-1796-CAP`。六月英方增援和海军部署改变岛内格局，Kalinago社群被迫停战，随后遭被拘、驱逐；各自治社群结束抵抗的时间并非同一日。

**行为主体**：Sir Ralph Abercromby; Kalinago communities；**地点**：St Vincent multiple locations；**证据来源**：N18。

## 受影响群体、抵抗、经济后果与长期影响

英军行动涉及地方自治、战争俘虏和随后Garifuna强制流放。对于海军日志列出的船只毁坏数，只能记录对应行动、日期和计数对象；不能等同于当场被杀人数或推断驱逐过程中全部死亡人数。

## 地图和统计审查

文献引用ADM档案但本批没有亲阅ADM原卷。航船路线、岸炮射击角度、Garifuna被拘地点需原逐页日志和航海地图方可制图。

本篇事件的经纬度若为空，即只能以历史地名呈现；一切现代遗址Point仅作为**现代位置参照**，未经核实的主权边界、种植园面积、强迫迁移航迹全部不绘Polygon/LineString。

## 资料来源与实际阅读范围

- `N18`：Royal Navy counterinsurgency 1795–1832；https://journals.sagepub.com/doi/10.1177/08438714231219455；**阅读层级**：圣文森特第二次战争、Grenada 1795反叛及海军阻断。

## 下一阶段具体查核

依事件来源ID逐件查原卷或国家机构提供的数字副本，记录卷号、页码、原文异文与反方当事人证词；画地图之前再审历史名称及权属。
