# 1793—1798｜英国入侵圣多明各与恢复奴役制度的企图

**定位**：第七轮地区扩查深入调查；`research_only`。本篇为逐条有来源的事件候选整合，非已刊发地图故事。

## 背景—决策

英国军队于1793年在法属Saint-Domingue若干沿海港口建立占领据点，在部分殖民庄园主支持下试图保住对岛内劳动力的奴役制度。行动延伸到Jérémie、Môle-Saint-Nicolas与Port-au-Prince等地。

## 实际行动、具名地点与时间

### 1793-09｜英国军队登陆法属Saint-Domingue的Jérémie并支持殖民奴役秩序恢复

事件ID：`E18A7-1793-HAITI-1793-JEREMIE`。英国军队于1793年9月在Jérémie等地区开始占领，获法国反共和派庄园主合作，企图恢复奴役人口的强迫劳动；未整体征服海地。

**行为主体**：British expedition; French planters; self-liberating insurgents；**地点**：Jérémie, southern Saint-Domingue (Haiti)；**证据来源**：R7021, R7022。

### 1793-09｜英国占领Môle Saint-Nicolas港堡并组织军政据点

事件ID：`E18A7-1793-HAITI-1793-MOLE`。史料研究记1793年9月英军另在Môle Saint-Nicolas建立占领据点，不等于控制北部全部区域。

**行为主体**：British expeditionary garrison; French colonial inhabitants；**地点**：Môle Saint-Nicolas, northern Haiti；**证据来源**：R7022。

### 1794-06｜英军与反共和派协同行动夺取Port-au-Prince

事件ID：`E18A7-1794-HAITI-1794-PORT`。大学史学研究转引David Geggus记六月上旬港城被英国部队占据（搜索摘录给出6月4日）；在原研究PDF未截图前保留月级，原稿日级候审。

**行为主体**：British troops; French royalists; Haitian revolutionary forces；**地点**：Port-au-Prince, Saint-Domingue；**证据来源**：R7022, R7021。

### 1798｜英军在海地革命军压力下逐港撤离Saint-Domingue

事件ID：`E18A7-1798-HAITI-1798-EVAC`。英军占据的岛上多处沿海据点在1798年被迫撤除；不能从一个港口撤军推定整座岛行政主权统一归英方或法方。

**行为主体**：General Thomas Maitland; Toussaint Louverture; British Caribbean Fleet；**地点**：Port-au-Prince, Saint-Marc, Arcahaie, Môle Saint-Nicolas (multiple sites)；**证据来源**：R7022, R7021。

## 受影响群体、抵抗、经济后果与长期影响

海地革命参与者以及获得自由的黑人武装组织具有独立的战略目标，不能写成英法战争的被动附属。英国1798年撤出主要沿海据点，显示英军原先未实现全岛军事征服或永久英属主权。

## 地图和统计审查

此项依赖大学研究PDF检索摘要及美国国会图书馆原书目录，尚未逐页核卷，尤其1794年6月4日和1798年各港撤离日期需由战斗日志重新校准。海地沿岸多个港口保持空坐标及逐点核证。

本篇事件的经纬度若为空，即只能以历史地名呈现；一切现代遗址Point仅作为**现代位置参照**，未经核实的主权边界、种植园面积、强迫迁移航迹全部不绘Polygon/LineString。

## 资料来源与实际阅读范围

- `R7021`：1797 St Domingo survey primary print catalogue；https://www.loc.gov/item/02012343/；**阅读层级**：1793 British invasion intended seizure and reinstatement of slavery; digitized contemporary book in images, image pages not individually transcribed。
- `R7022`：British occupation of Saint-Domingue historiography dissertation；https://deepblue.lib.umich.edu/bitstream/handle/2027.42/96644/dcasslem.pdf?sequence=1；**阅读层级**：1793 Jérémie/Môle St Nicolas landings, 1794-06-04 Port au Prince, 1798 withdrawal; PDF not visually verified, corroborate before day-level publication。

## 下一阶段具体查核

依事件来源ID逐件查原卷或国家机构提供的数字副本，记录卷号、页码、原文异文与反方当事人证词；画地图之前再审历史名称及权属。
