# 1796—1799｜英军夺取荷属圭亚那种植园殖民地

**定位**：第七轮地区扩查深入调查；`research_only`。本篇为逐条有来源的事件候选整合，非已刊发地图故事。

## 背景—决策

1796英国军队在加勒比及南美北岸战争中接管荷属Demerara、Essequibo、Berbice，各地有不同投降时间。当地糖业与奴役劳动网络原本建立在荷兰殖民管理之上，英国取得港口控制后继续依赖原先庄园与拍卖设施。

## 实际行动、具名地点与时间

### 1796｜英国占领Essequibo后继续使用Court of Policy及奴役人口拍卖设施

事件ID：`E18A7-1796-GUY-1796-COURT`。圭亚那国家信托记录Court of Policy旧设施曾包含奴役人口拍卖办公室；设施年代持续跨荷英政权，具体英国每年拍卖数字未知。

**行为主体**：Dutch/English administrators; planter auction traders; enslaved communities；**地点**：Fort Zeelandia / Fort Island, Essequibo；**证据来源**：R7025, R7023。

### 1796-04-23｜英国海军夺取荷属Demerara据点并接管糖业种植园殖民地

事件ID：`E18A7-1796-GUY-1796-DEMERARA`。海军二手史记4月23日荷属Demerara与Essequibo向英军投降；国家陆军博物馆与圭亚那国家信托确认1796占领。原荷属种植园奴役制度继续。

**行为主体**：Major-General John Whyte; Vice-Admiral John Laforey; Dutch/Batavian authorities；**地点**：Demerara River and Stabroek/Georgetown region；**证据来源**：R7027, R7023, R7024。

### 1796-04-23｜英国军队接管荷属Essequibo及其种植园与贸易港

事件ID：`E18A7-1796-GUY-1796-ESSEQUIBO`。另列与Demerara同日投降的Essequibo，避免地图把三条河及所有内陆原住民土地画为单一已证英国实占。

**行为主体**：British expedition; Dutch colonial court; Indigenous and enslaved communities；**地点**：Essequibo River Dutch colonial posts, Guyana；**证据来源**：R7027, R7025。

### 1796-05-02｜英军接收荷属Berbice殖民地并控制当地沿海要塞

事件ID：`E18A7-1796-GUY-1796-BERBICE`。皇家海军军史资料把Berbice的降服置于1796年5月2日；圭亚那议会简表另有年份不一，日期需继续核原投降文本。

**行为主体**：Major General John Whyte; Berbice Dutch administration；**地点**：Berbice River, Guyana；**证据来源**：R7027, R7024。

**争议**：圭亚那议会简表对Demerara/Essequibo有1795年记载，英国海军史与军团史则指出1796年4月；需以1796投降契约正本校准。

### 1799-01｜英占Demerara殖民地扩大Stabroek市镇范围纳入Werk-en-Rust

事件ID：`E18A7-1799-GUY-1799-WERK`。圭亚那国家信托记1799年1月将原庄园Werk-en-Rust纳入Stabroek市区，地方扩张与种植园地产相接；不推断已核地块面积。

**行为主体**：British colonial administration; plantation landowners；**地点**：Werk-en-Rust, Stabroek, Demerara；**证据来源**：R7024。

## 受影响群体、抵抗、经济后果与长期影响

原住民族内陆社区与被奴役人口未因殖民总督换旗自动接受新君主主权。1799年Stabroek的Werk-en-Rust市镇整合是局部地产与行政发展，不是英国对圭亚那整片内陆完成测绘征服。

## 地图和统计审查

三处殖民地降服日主要依赖19世纪海军史及国家信托机构，圭亚那议会二手年表存在1795/1796年份争议。必须找各地殖民议事会与海军正式投降书原件再批准精准日期。

本篇事件的经纬度若为空，即只能以历史地名呈现；一切现代遗址Point仅作为**现代位置参照**，未经核实的主权边界、种植园面积、强迫迁移航迹全部不绘Polygon/LineString。

## 资料来源与实际阅读范围

- `R7027`：British capture of Demerara Essequibo and Berbice 1796；https://threedecks.org/index.php?display_type=show_battle&id=705；**阅读层级**：1796-04-23 surrender Demerara/Essequibo and May 2 Berbice; identify naval author as secondary and not an original capitulation。
- `R7023`：South American Rangers 1797 object record；https://collection.nam.ac.uk/detail.php?acc=1984-06-175-1；**阅读层级**：1796 British Demerara occupation; slave economy, armed Black garrison Rangers; details 1797 research only。
- `R7024`：Historic Georgetown；https://ntg.gov.gy/historic-georgetown/26/；**阅读层级**：1796 British reoccupation Demerara Essequibo Berbice; Jan 1799 Werk-en-Rust town incorporation。
- `R7025`：Dutch Heritage Museum Court of Policy；https://ntg.gov.gy/monument/dutch-heritage-museum-court-of-policy/；**阅读层级**：British takeover 1796 and slave auction office in Dutch-era court building。

## 下一阶段具体查核

依事件来源ID逐件查原卷或国家机构提供的数字副本，记录卷号、页码、原文异文与反方当事人证词；画地图之前再审历史名称及权属。
