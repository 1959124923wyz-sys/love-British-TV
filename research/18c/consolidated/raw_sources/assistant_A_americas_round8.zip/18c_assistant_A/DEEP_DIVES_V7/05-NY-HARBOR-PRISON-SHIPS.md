# 1776—1783｜纽约港英国战俘船与被拘押者死亡

**定位**：第七轮地区扩查深入调查；`research_only`。本篇为逐条有来源的事件候选整合，非已刊发地图故事。

## 背景—决策

英国驻纽约军队与皇家海军将大量俘虏置于Wallabout Bay和港内改装废船，拘押对象包括大陆军、水手、私掠船员及部分平民。Thomas Dring等幸存者留下船内空间、食物及染病情况的回忆。

## 实际行动、具名地点与时间

### 1776｜英国占领纽约后把战俘及其他拘押者关进Wallabout湾囚船

事件ID：`E18A7-1776-NY-PRISONSHIPS-START`。自1776年英国据点扩张起在纽约港区、布鲁克林Wallabout Bay设囚船拘押军人、水手、私掠船员及若干平民。NPS记载卫生、饮水、营养和疫病条件恶劣。该船群是拘押地点，不构成海面上的殖民领土面。

**行为主体**：British Royal Navy and army custodians; captured patriots；**地点**：Wallabout Bay, Brooklyn, New York；**证据来源**：R7033。

**数字口径**：NPS所列约11,500死亡数属于纪念和后世合计估算，本轮不录为已精确核实死亡人数。

## 受影响群体、抵抗、经济后果与长期影响

港内军用囚船的制度史与具体Jersey船的使用年份、一次次病亡必须分清。美国国家公园管理局对广为流传的死亡人数给予纪念性介绍，但没有给出逐船逐月完整分母，故数据库不填一个所谓精确死亡总数。

## 地图和统计审查

核查ADM 51/军方战俘押送清册、Dring原书不同版本与墙外湾土地遗骸记录。官方NPS网页把Jersey写作240门炮舰显然异常，不能搬用这一明显有误的技术细节。

本篇事件的经纬度若为空，即只能以历史地名呈现；一切现代遗址Point仅作为**现代位置参照**，未经核实的主权边界、种植园面积、强迫迁移航迹全部不绘Polygon/LineString。

## 资料来源与实际阅读范围

- `R7033`：The Prison Ship Martyrs；https://www.nps.gov/articles/000/prison-ship-martyrs.htm；**阅读层级**：1776-83 New York Wallabout Bay British floating prisons, captivity disease neglect deaths, survivor Thomas Dring testimony; page erroneously states 240-gun Jersey—DO NOT USE that detail。

## 下一阶段具体查核

依事件来源ID逐件查原卷或国家机构提供的数字副本，记录卷号、页码、原文异文与反方当事人证词；画地图之前再审历史名称及权属。
