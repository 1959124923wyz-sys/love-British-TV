# 1782｜查尔斯顿撤军、忠诚派迁移与被奴役人口转运

**定位**：第七轮地区扩查深入调查；`research_only`。本篇为逐条有来源的事件候选整合，非已刊发地图故事。

## 背景—决策

1782年12月14日英国军队从Gadsden’s Wharf完成撤出Charleston；美国国家公园管理局记载忠诚派随船出走，另有5000余名非洲裔被转移，其中多数仍为忠诚派奴隶主掌握的人身财产。

## 实际行动、具名地点与时间

### 1782-12-14｜英国撤出查尔斯顿，结束当地两年多军事占领

事件ID：`E18A7-1782-SC-CHARLESTON-EXIT`。英国后卫部从Gadsden’s Wharf登船撤出Charles Town，独立军随即进入；英方将军队、忠诚派及大量被奴役人口一并由军舰/运输船转移。不能将疏散人口数量当全部解放人口。

**行为主体**：British Army rear guard; Royal Navy; American Army; Loyalists；**地点**：Gadsden’s Wharf, Charleston, South Carolina；**证据来源**：R7037。

**数字口径**：NPS约14000登船是全部撤离人口估数，约4200忠诚派与5000多非洲裔不应简单相加作整体分母。

### 1782-12-14｜随英国军队撤离的忠诚派奴隶主强制携带数千被奴役非洲裔离开查尔斯顿

事件ID：`E18A7-1782-SC-CHARLESTON-ENSLAVED-REMOVAL`。国家公园局指出5000多名非洲裔随撤离船队离开查尔斯顿，其中多数仍是忠诚派奴隶主所持被奴役人口、被迫迁往别处；也有此前逃往英国战线而获自由者。必须把被迫跨地贩运与获得自由者的自主迁徙区分。

**行为主体**：Loyalist enslavers; British naval evacuation; enslaved Africans; self-emancipated Black loyalists；**地点**：Charleston Harbor, South Carolina；**证据来源**：R7037。

**数字口径**：>5000是全体非洲裔撤离估计（自由与被奴役合并），并非5000全为被奴役者；确切被奴役人数未知。

## 受影响群体、抵抗、经济后果与长期影响

同一撤军既包含英方从奴隶制社会撤出的政治结果，也包含强迫把他人带往英帝国其他殖民地的个人灾难。部分非洲裔此前逃往英国战线并获得自由，不能把这批自由人士与被带走的被奴役者统一计算为单一人口类型。

## 地图和统计审查

约14000全部登船、约4200忠诚派、5000余非洲裔是同一来源不同交叉人口集合，不用加法产生新总人数。航线、运送目的地和逐船乘客名单需要运输船册；地图只列Gadsden’s Wharf现代地名，未核具体码头战时坐标则空值。

本篇事件的经纬度若为空，即只能以历史地名呈现；一切现代遗址Point仅作为**现代位置参照**，未经核实的主权边界、种植园面积、强迫迁移航迹全部不绘Polygon/LineString。

## 资料来源与实际阅读范围

- `R7037`：Liberty Won and Lost: British Evacuation of Charleston；https://www.nps.gov/articles/000/british-evacuation-of-charleston.htm；**阅读层级**：Dec 14 1782 Charleston withdrawal: approx 4200 loyalists, >5000 Africans many forcibly relocated as enslaved by loyalists, some free, total ~14000 all aboard 130 British ships; overlap note。

## 下一阶段具体查核

依事件来源ID逐件查原卷或国家机构提供的数字副本，记录卷号、页码、原文异文与反方当事人证词；画地图之前再审历史名称及权属。
