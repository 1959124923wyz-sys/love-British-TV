# 1779｜康涅狄格沿岸三城掠夺与焚毁

**定位**：第七轮地区扩查深入调查；`research_only`。本篇为逐条有来源的事件候选整合，非已刊发地图故事。

## 背景—决策

英国将纽约据点作为出发地，William Tryon率领的军队陆续袭击New Haven、Fairfield、Norwalk。馆藏与地方居民证词支持在7月7—8日Fairfield广泛焚毁住房与商业建筑，Norwalk在7月11—12日遭大规模损毁。

## 实际行动、具名地点与时间

### 1779-07-05｜Tryon英军从海上袭击New Haven并掠夺港镇物资

事件ID：`E18A7-1779-CT-NEW-HAVEN-RAID`。英军在纽约总司令Clinton部署下对Connecticut沿海进行袭击，New Haven为首个目标；其登陆、焚烧军事储备和对部分民居掠夺须分开核实。

**行为主体**：William Tryon; British and Loyalist soldiers；**地点**：New Haven, Connecticut；**证据来源**：R7042, R7043。

### 1779-07-07｜Tryon军登陆Fairfield并迫使居民逃离

事件ID：`E18A7-1779-CT-FAIRFIELD-LAND`。Fairfield博物馆与Connecticut州议会史记7月7日约两千英军及德意志辅助军登陆，民兵阻击同时居民逃散。人数是部队规模估计，不能转作平民受害人数。

**行为主体**：William Tryon; British-Hessian expedition; Fairfield militia；**地点**：Fairfield Beach, Connecticut；**证据来源**：R7040, R7041。

**数字口径**：约2000英军/黑森士兵为部署估数，不是被害居民人数。

### 1779-07-08｜英军焚毁Fairfield大量住宅商铺和民用设施

事件ID：`E18A7-1779-CT-FAIRFIELD-BURN`。在7月7日登陆后，英军至7月8日焚毁Fairfield市镇大片住宅、仓库、作坊及农场；多个公民证词后来被收集。实际烧毁栋数须从遗产调查账与财产损失清单逐项审计。

**行为主体**：William Tryon; British military forces; affected Fairfield residents；**地点**：Fairfield center, Connecticut；**证据来源**：R7040, R7042, R7041。

**争议**：地方文献对焚毁的起止具体日存在7日夜间至8日早晨的不同叙述，标题采用8日为持续行动后段。

### 1779-07-11｜英军从长岛渡海袭击Norwalk港区并登陆

事件ID：`E18A7-1779-CT-NORWALK-LAND`。William Tryon部由Long Island跨海逼近Norwalk，在Calf Pasture等处登陆；当地民兵与独立派居民准备抵抗并撤出家属。

**行为主体**：William Tryon; Royal Navy; Loyalist auxiliaries；**地点**：Norwalk, Connecticut；**证据来源**：R7043, R7042, R7049。

### 1779-07-12｜英军纵火焚毁Norwalk大量住宅、店铺、磨坊与教堂

事件ID：`E18A7-1779-CT-NORWALK-BURN`。Tryon军1779年7月11—12日的突袭导致Norwalk城镇大规模毁坏，建筑类型包括民房、商店、谷仓、磨坊、教堂；战争区军民财产损失和民兵伤亡不可混算。

**行为主体**：William Tryon; British-Loyalist raiders; Norwalk residents；**地点**：Norwalk town center, Connecticut；**证据来源**：R7042, R7043, R7049。

**争议**：不同机构把纵火概括为7月11日或12日，最终日期建议1779-07-11/12时间窗；此记录按更具体的地面行动阶段置12日。

## 受影响群体、抵抗、经济后果与长期影响

应区分英国正规军、德意志辅助军与保皇派辅助人员的具体行为；城市居民、当地民兵、神职人员及拥王居民有不同政治选择。英军称目标是打击海岸反英军事活动和物资，但实际造成大批民用建筑被毁。

## 地图和统计审查

New Haven、Fairfield、Norwalk需分别绘制城市代表点。Fairfield住民证词原卷与Connecticut报纸、Tryon报告将用于校正被毁建筑统计；Norwalk“11日/12日焚烧”争议只取时间窗，不编造精确焚烧开始分钟。

本篇事件的经纬度若为空，即只能以历史地名呈现；一切现代遗址Point仅作为**现代位置参照**，未经核实的主权边界、种植园面积、强迫迁移航迹全部不绘Polygon/LineString。

## 资料来源与实际阅读范围

- `R7042`：Connecticut Raids；https://www.mountvernon.org/library/digitalhistory/digital-encyclopedia/article/connecticut-raids；**阅读层级**：1779 July British Tryon punitive raids at New Haven, Fairfield, Norwalk, sources note political blowback and burned homes。
- `R7043`：The Burning of Norwalk historical archive retrospective；https://www.norwalkcurrent.com/from-the-archives-the-burning-of-norwalk/；**阅读层级**：July 11-12 1779 British landing and burning; local papers, journals and conflicting date interpretation; July 12 burn is most consistent。
- `R7040`：The Burning of Fairfield；https://www.fairfieldhistory.org/burning-of-fairfield/；**阅读层级**：1779 July 7 landing then July 7-8 town burning; contains references to sworn testimony of women witnesses; counts are local descriptions not audited building census。
- `R7041`：Burning of Fairfield July 1779；https://housedems.ct.gov/node/26023；**阅读层级**：1779 July British Hessian raids; local civilian flight/looting/burning property。
- `R7049`：St Pauls Norwalk historical research；https://ecct1archives.omeka.net/items/show/2557；**阅读层级**：Norwalk 1779 British burn, loyalist relocation, official 11 July vs 12 July date discrepancy; keep date window if strict。

## 下一阶段具体查核

依事件来源ID逐件查原卷或国家机构提供的数字副本，记录卷号、页码、原文异文与反方当事人证词；画地图之前再审历史名称及权属。
