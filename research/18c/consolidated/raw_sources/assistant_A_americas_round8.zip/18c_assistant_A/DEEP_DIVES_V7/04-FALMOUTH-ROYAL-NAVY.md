# 1775｜皇家海军法尔茅斯焚城事件：命令、证词与毁损

**定位**：第七轮地区扩查深入调查；`research_only`。本篇为逐条有来源的事件候选整合，非已刊发地图故事。

## 背景—决策

皇家海军Graves的海岸惩罚性命令与Henry Mowat的实际攻击可从军官次日向上级呈报以及镇民同日私人日记交叉追溯。1775年10月18日英舰炮击并纵火焚毁Falmouth Neck（今Portland）民居和公共建筑。

## 实际行动、具名地点与时间

### 1775-10｜英国海军司令Graves发布惩罚新英格兰沿岸城镇的命令

事件ID：`E18A7-1775-MAINE-FALMOUTH-ORDER`。Maine Historical Society馆藏说明Graves要求Mowat焚毁多个支持殖民地独立的海港城镇，最终舰长只执行对Falmouth的摧毁。命令拟攻击的其他城镇不能写作已毁。

**行为主体**：Vice-Admiral Samuel Graves; Captain Henry Mowat；**地点**：Boston naval command and coast of Massachusetts Bay；**证据来源**：R7030, R7032。

**争议**：Graves命令所列九城及各城市军事理由尚需读Mowat原始逐段报告。

### 1775-10-18｜Mowat英国军舰炮击并纵火摧毁法尔茅斯市镇

事件ID：`E18A7-1775-MAINE-FALMOUTH-BURN`。1775年10月18日英国皇家海军炮击Falmouth Neck（今Portland），焚毁居民住宅、仓库和教堂。Stephen Longfellow II当日私人日记及次日英军舰长上呈报告均被Maine Historical Society数字馆藏收录；1776年幸存者书信显示民居损失和被迫逃离。

**行为主体**：Captain Henry Mowat; Royal Navy; townspeople；**地点**：Falmouth Neck / Portland, Maine；**证据来源**：R7031, R7030, R7032。

**数字口径**：房屋精确毁损数量不同书籍口径差异，不使用未经原账核对的确切值。

## 受影响群体、抵抗、经济后果与长期影响

下令袭击更多城镇的纸面计划与唯一实际攻击的Falmouth必须区分。当地居民被迫撤离，房屋被毁，战争期间民间财产损失可以通过地契、赔偿诉求和房产税登记复核；数目未核算入总损失。

## 地图和统计审查

Maine Historical Society的Captain Mowat档与Stephen Longfellow当日日记是真实馆藏，网页机构摘录与原件高清图像应注明阅读层次；旧建筑的精确街址缺同时代配准，不画城市焚毁Polygon。

本篇事件的经纬度若为空，即只能以历史地名呈现；一切现代遗址Point仅作为**现代位置参照**，未经核实的主权边界、种植园面积、强迫迁移航迹全部不绘Polygon/LineString。

## 资料来源与实际阅读范围

- `R7030`：1775-10-19 Captain Mowat report to Admiral Graves, digital object and description；https://www.mainememory.net/record/159024；**阅读层级**：Mowat letter report Oct 19 following Oct 18 destruction, Graves orders to punish 9 settlements; collection notes transcription linked; original artifact page indexed。
- `R7032`：Revolution in Massachusetts: Burning of Falmouth；https://guides.bpl.org/c.php?g=800717&p=10424695；**阅读层级**：Oct 18 1775 Henry Mowat Royal Navy burned Falmouth; Vice Adm Graves coastal punitive order。
- `R7031`：Stephen Longfellow II original 1775 diary entry；https://www.mainememory.net/record/102228；**阅读层级**：Oct 18 1775 diary explicitly records town burned by King troops, individual property loss; document in collection。

## 下一阶段具体查核

依事件来源ID逐件查原卷或国家机构提供的数字副本，记录卷号、页码、原文异文与反方当事人证词；画地图之前再审历史名称及权属。
