# 1781｜英军两处烧毁行动与非洲裔守军

**定位**：第七轮地区扩查深入调查；`research_only`。本篇为逐条有来源的事件候选整合，非已刊发地图故事。

## 背景—决策

Benedict Arnold转投英方后于1781年1月5日前后进攻Richmond并破坏军资和烟草，还波及州政府依赖的Dixon/Nicolson印刷事务。九月六日Arnold又带英国部队对New London及河对岸Groton发起突袭。

## 实际行动、具名地点与时间

### 1781-01-05｜叛离独立派的英军指挥官Arnold攻入Richmond毁坏军事物资

事件ID：`E18A7-1781-VA-RICHMOND-ARNOLD`。Arnold率英国部队攻入Virginia首府Richmond，焚毁军工厂、仓储及大量烟草；州政府和Jefferson逃往内陆；印刷商Dixon与Nicolson业务被破坏，影响议会法案印行。

**行为主体**：British Brigadier General Benedict Arnold; Governor Thomas Jefferson；**地点**：Richmond and Westham, Virginia；**证据来源**：R7047, R7046, R7048。

**争议**：Library of Congress总叙述把行动列为1月6—10日，Chesterfield郡和更早文献称1月5日攻入；1月5按县政府记载，若需原日志逐时核应保留争议。

### 1781-09-06｜Arnold英军攻击New London并纵火焚毁城市建筑

事件ID：`E18A7-1781-CT-NEWLONDON-RAID`。Benedict Arnold指挥的英军9月6日从New London侧登陆，攻入后下令烧毁港口军事补给和大量市镇建筑。另一支从Groton侧进攻Fort Griswold，行动须分开落点。

**行为主体**：Benedict Arnold; Royal British and loyalist troops；**地点**：New London, Connecticut；**证据来源**：R7039。

### 1781-09-06｜英军攻陷Fort Griswold，守军William Ledyard与Jordan Freeman阵亡

事件ID：`E18A7-1781-CT-GROTON-GRISWOLD`。英国军队在Groton侧攻取Fort Griswold，司令William Ledyard被杀，参战非洲裔自由战士Jordan Freeman也死亡。英军是否使用Ledyard佩剑处决，州立图书馆明确标为有争议的报道，不能写成定论。

**行为主体**：British troops; Colonel William Ledyard; Jordan Freeman；**地点**：Fort Griswold, Groton Heights, Connecticut；**证据来源**：R7039。

**争议**：Ledyard遭自己军刀杀害只是有争议的口述传统，不采用。

## 受影响群体、抵抗、经济后果与长期影响

Connecticut州立图书馆明确记载William Ledyard与非洲裔士兵Jordan Freeman在Fort Griswold被杀。有关Ledyard被自己佩剑杀害的故事属于有争议的后世说法，应保留来源差异；地方民兵及平民的防卫不应被英国正规军叙述完全覆盖。

## 地图和统计审查

Richmond的1月5日入城与LOC 1月6—10日整个攻势时间窗不矛盾，但仍应核原始行军日记。New London与Groton分别成两个位置，不绘横跨整条河的占领面。

本篇事件的经纬度若为空，即只能以历史地名呈现；一切现代遗址Point仅作为**现代位置参照**，未经核实的主权边界、种植园面积、强迫迁移航迹全部不绘Polygon/LineString。

## 资料来源与实际阅读范围

- `R7047`：American Revolution 250th Commemoration；https://www.chesterfield.gov/rev250；**阅读层级**：British Arnold captured Richmond Jan 5 1781, burned military stores tobacco, damaged ironworks at Westham, militia resistance。
- `R7046`：Index of Virginia Printing: Session Laws October 1780；https://www.lva.virginia.gov/collections/virginia-print/imprints/1781.011；**阅读层级**：1781 Jan 5 Arnold raid Richmond damaged Dixon Nicolson printing office and disrupted session laws publication; catalog record not original printing read。
- `R7048`：Thomas Jefferson Papers Timeline 1774-1783；https://www.loc.gov/collections/thomas-jefferson-papers/articles-and-essays/the-thomas-jefferson-papers-timeline-1743-to-1827/1774-to-1783/；**阅读层级**：Arnold invasion Jan 6-10 1781, Jefferson government fled, military/printing disruption; individual Jan 5 from VA government。
- `R7039`：Battle of Groton Heights and Burning of New London；https://libguides.ctstatelibrary.org/History-Day/1775-1815/Groton-Heights-New-London；**阅读层级**：Sept 6 1781 British troops land both sides of Thames; Benedict Arnold orders New London burning, Col William Ledyard and African American defender Jordan Freeman killed at Fort Griswold; sword death is contested。

## 下一阶段具体查核

依事件来源ID逐件查原卷或国家机构提供的数字副本，记录卷号、页码、原文异文与反方当事人证词；画地图之前再审历史名称及权属。
