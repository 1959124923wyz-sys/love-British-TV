# 1756｜Kittanning火攻、莱纳佩抵抗及殖民报复

**定位**：第七轮地区扩查深入调查；`research_only`。本篇为逐条有来源的事件候选整合，非已刊发地图故事。

## 背景—决策

Pennsylvania的殖民民兵1756年9月8日由John Armstrong攻击Allegheny河畔Kittanning/Attiqué的Lenape聚落。当地既是原住民生活与贸易网络的一部分，也曾成为反击英国殖民定居者的武装活动区域。

## 实际行动、具名地点与时间

### 1756-09-08｜宾州民兵攻袭并焚毁莱纳佩人的Kittanning/Attiqué聚落

事件ID：`E18A7-1756-PA-KITTAN-RAID`。宾夕法尼亚殖民民兵由John Armstrong率领袭击俄亥俄流域Lenape聚落，使村庄遭受火攻和破坏。莱纳佩此前在英国殖民者进入前已有政治及河流道路网络；单场军事胜利未使整个河谷成为英方实控地。

**行为主体**：Pennsylvania provincial militia; John Armstrong; Lenape residents；**地点**：Kittanning / Attiqué, Allegheny River, PA；**证据来源**：R7044, R7045。

**数字口径**：伤亡、被掳与营房数量待核双方原始材料；当前留null。

## 受影响群体、抵抗、经济后果与长期影响

宾州殖民部队摧毁了具名聚落，但不能从这一日战争行动推论所有Lenape认同法或英王对整片河谷拥有主权。地方历史会和县政府规划文件支持日期与地名，原双方伤亡统计仍须另核。

## 地图和统计审查

应寻找Armstrong战报、殖民议会报销和被毁村庄地图，以及Lenape部族保存的自有史料。历史村镇可找官方定位点，但本轮未把现代县界作为1700年代军控面。

本篇事件的经纬度若为空，即只能以历史地名呈现；一切现代遗址Point仅作为**现代位置参照**，未经核实的主权边界、种植园面积、强迫迁移航迹全部不绘Polygon/LineString。

## 资料来源与实际阅读范围

- `R7044`：Kittanning or Attiqué Indian Town Marker；https://www.historicarmstrong.org/armstrong-county-history；**阅读层级**：Lenape settlement attacked by PA militia led John Armstrong Sept 8 1756; entire territory cannot be treated occupied from one raid。
- `R7045`：Comprehensive Plan 2005: County History；https://co.armstrong.pa.us/images/departments/planning/plansdocs/accp2005.pdf；**阅读层级**：September 1756 Armstrong attacked and destroyed Kittanning settlement; PDF only search excerpt, no full page inspection。

## 下一阶段具体查核

依事件来源ID逐件查原卷或国家机构提供的数字副本，记录卷号、页码、原文异文与反方当事人证词；画地图之前再审历史名称及权属。
