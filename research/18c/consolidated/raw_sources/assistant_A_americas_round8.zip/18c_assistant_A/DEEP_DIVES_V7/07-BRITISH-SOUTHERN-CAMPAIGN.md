# 1778—1780｜萨凡纳与查尔斯顿的英国围城和军事控制

**定位**：第七轮地区扩查深入调查；`research_only`。本篇为逐条有来源的事件候选整合，非已刊发地图故事。

## 背景—决策

英国战略从北方港口延伸至南方种植园及海港。1778年12月29日英军夺取Savannah；1780年查尔斯顿围城中，4月1日修壕、4月8日海军突破炮台、4月13日炮击、4月14日切断撤路，5月12日守军投降。

## 实际行动、具名地点与时间

### 1778-12-29｜英军攻取萨凡纳港并在佐治亚建立南方战场基地

事件ID：`E18A7-1778-GEORGIA-SAVANNAH-CAP`。Archibald Campbell率英国远征军在1778年12月29日攻取Savannah，随后企图通过州内保皇派和奴役种植园经济支撑英国对美国南方的统治。此港的占领不能当作Georgia所有原住民内陆土地由英国实占。

**行为主体**：Archibald Campbell; British Southern expedition; Georgian inhabitants；**地点**：Savannah, Georgia；**证据来源**：R7035, R7034, R7038。

### 1780-04-01｜Clinton英军开始修筑查尔斯顿围城第一道平行壕

事件ID：`E18A7-1780-SC-CHARLESTON-LINES`。英国围城军在Charleston Neck修第一道围城平行壕，逐步逼近城市与居民并切断军队补给；军事攻防不等于全部周边郡县已归英国实控。

**行为主体**：Sir Henry Clinton; British engineers; Benjamin Lincoln defenders；**地点**：Charleston Neck, South Carolina；**证据来源**：R7034。

### 1780-04-08｜皇家海军舰队突破Fort Moultrie海防进入查尔斯顿港

事件ID：`E18A7-1780-SC-CHARLESTON-NAVY`。Arbuthnot率英海军舰队4月8日驶过Fort Moultrie炮台，切断被围军港上联络；海上实际航迹仍无本轮校准GIS线。

**行为主体**：Admiral Mariot Arbuthnot; British Royal Navy; American defenders；**地点**：Charleston Harbor, South Carolina；**证据来源**：R7034。

### 1780-04-13｜英国围城炮兵开始连续炮击查尔斯顿

事件ID：`E18A7-1780-SC-CHARLESTON-SHELL`。国家公园局记录英军4月13日展开大规模炮击，炮火延续至5月投降，居民区财产及政治压力扩大；未核具名单栋损失账。

**行为主体**：British Army artillery; Charleston civilians and garrison；**地点**：Charleston, South Carolina；**证据来源**：R7034。

### 1780-04-14｜Tarleton英军在Moncks Corner击散大陆军骑兵阻断撤路

事件ID：`E18A7-1780-SC-MONCKS-CORNER`。英国军官Banastre Tarleton在Moncks Corner击溃Isaac Huger的独立军骑兵，帮助英国封锁查尔斯顿的陆上撤退。不同类型俘虏与战死人数需原军报核对。

**行为主体**：Banastre Tarleton; Isaac Huger; British cavalry and American cavalry；**地点**：Moncks Corner, South Carolina；**证据来源**：R7034。

### 1780-05-12｜查尔斯顿美军投降，英国军政取得城市驻防和战俘

事件ID：`E18A7-1780-SC-CHARLESTON-CAP`。1780年5月12日Lincoln部投降，英国占据Charleston城、防御炮台与港口；较低阶军官及普通兵被关押在拥挤的监狱船上。NPS叙述英国俘获炮弹及武器，但各项数量不可重复合计。

**行为主体**：Henry Clinton; Benjamin Lincoln; Mariot Arbuthnot；**地点**：Charleston, South Carolina；**证据来源**：R7034, R7035, R7036。

### 1782-12-14｜英国撤出查尔斯顿，结束当地两年多军事占领

事件ID：`E18A7-1782-SC-CHARLESTON-EXIT`。英国后卫部从Gadsden’s Wharf登船撤出Charles Town，独立军随即进入；英方将军队、忠诚派及大量被奴役人口一并由军舰/运输船转移。不能将疏散人口数量当全部解放人口。

**行为主体**：British Army rear guard; Royal Navy; American Army; Loyalists；**地点**：Gadsden’s Wharf, Charleston, South Carolina；**证据来源**：R7037。

**数字口径**：NPS约14000登船是全部撤离人口估数，约4200忠诚派与5000多非洲裔不应简单相加作整体分母。

### 1782-12-14｜随英国军队撤离的忠诚派奴隶主强制携带数千被奴役非洲裔离开查尔斯顿

事件ID：`E18A7-1782-SC-CHARLESTON-ENSLAVED-REMOVAL`。国家公园局指出5000多名非洲裔随撤离船队离开查尔斯顿，其中多数仍是忠诚派奴隶主所持被奴役人口、被迫迁往别处；也有此前逃往英国战线而获自由者。必须把被迫跨地贩运与获得自由者的自主迁徙区分。

**行为主体**：Loyalist enslavers; British naval evacuation; enslaved Africans; self-emancipated Black loyalists；**地点**：Charleston Harbor, South Carolina；**证据来源**：R7037。

**数字口径**：>5000是全体非洲裔撤离估计（自由与被奴役合并），并非5000全为被奴役者；确切被奴役人数未知。

## 受影响群体、抵抗、经济后果与长期影响

占领查尔斯顿的英军随后拘押大批战俘，部分在拥挤的监狱船内死亡。英军取得海港和军用据点，也试图争取忠诚派人力和南方农业产出，然而乡间政治忠诚、奴役人口身份与原住民领土应分别对待。

## 地图和统计审查

查尔斯顿港和Savannah可落官方现代城市代表点，但1780年城墙、营垒和英军控制下各地农庄边界均需古地图配准。不同来源的战俘人数、武器数、伤亡人数不可同口径相加。

本篇事件的经纬度若为空，即只能以历史地名呈现；一切现代遗址Point仅作为**现代位置参照**，未经核实的主权边界、种植园面积、强迫迁移航迹全部不绘Polygon/LineString。

## 资料来源与实际阅读范围

- `R7035`：Events Leading to the Siege of Yorktown, 1781；https://www.nps.gov/york/learn/historyculture/eventstoyorktown.htm；**阅读层级**：Savannah taken Dec 29 1778, Charleston surrendered May 12 1780; separate dates from alternative erroneous NPS WPA timeline。
- `R7034`：Siege of Charleston 1780；https://www.nps.gov/articles/siege-of-charleston-1780.htm；**阅读层级**：1780 April 1 first British siege parallel, April 8 Royal Navy breaks past Fort Moultrie, April 13 shelling, April 14 Moncks Corner, May 12 surrender, June 3 Clinton loyalty decree。
- `R7038`：Kings Mountain: Conquest of Georgia South Carolina；https://npshistory.com/handbooks/historical/22/hh22c.htm；**阅读层级**：British Savannah Dec 29 1778 and Charleston May 12 1780, military and economic control of named ports, not entire colony。
- `R7036`：Henry Clinton；https://www.nps.gov/people/henry-clinton.htm；**阅读层级**：May 12 surrender, June 3 parole requirement and loyalty, local resistance。
- `R7037`：Liberty Won and Lost: British Evacuation of Charleston；https://www.nps.gov/articles/000/british-evacuation-of-charleston.htm；**阅读层级**：Dec 14 1782 Charleston withdrawal: approx 4200 loyalists, >5000 Africans many forcibly relocated as enslaved by loyalists, some free, total ~14000 all aboard 130 British ships; overlap note。

## 下一阶段具体查核

依事件来源ID逐件查原卷或国家机构提供的数字副本，记录卷号、页码、原文异文与反方当事人证词；画地图之前再审历史名称及权属。
