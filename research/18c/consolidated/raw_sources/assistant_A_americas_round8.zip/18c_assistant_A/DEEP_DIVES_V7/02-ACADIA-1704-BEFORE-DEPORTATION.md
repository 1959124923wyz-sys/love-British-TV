# 1704｜阿卡迪亚前驱战事：Beaubassin与Grand-Pré

**定位**：第七轮地区扩查深入调查；`research_only`。本篇为逐条有来源的事件候选整合，非已刊发地图故事。

## 背景—决策

新英格兰殖民军Benjamin Church在1704年沿阿卡迪亚殖民聚落实施袭击，先后涉及Beaubassin与Grand-Pré。加拿大公园局叙述支持上述地方行动，但并未证明此时英国已控制Mi’kma’ki全境。

## 实际行动、具名地点与时间

### 1704｜Benjamin Church率新英格兰兵袭击阿卡迪亚Beaubassin

事件ID：`E18A7-1704-ACAD-1704-BE`。加拿大公园局记1704年New England兵袭击Beaubassin/Chignecto的阿卡迪亚居民聚落；与1696袭击、1750年焚村分开。

**行为主体**：Benjamin Church; New England colonial militia; Acadian residents；**地点**：Beaubassin, Chignecto, Acadia；**证据来源**：R7010, S11。

### 1704｜新英格兰军队继续摧毁Grand-Pré部分阿卡迪亚村庄

事件ID：`E18A7-1704-ACAD-1704-GP`。在袭击Beaubassin后，Church部队攻击Grand-Pré并破坏阿卡迪亚居民农庄；该次行动距离1755年英国驱逐仍约半世纪，不应合并。

**行为主体**：Benjamin Church; Acadian civilians；**地点**：Grand-Pré, Minas Basin, Acadia；**证据来源**：R7010。

## 受影响群体、抵抗、经济后果与长期影响

与1755年新斯科舍殖民政府的正式驱逐政策分别记录：1704是战争袭击，1755是实施多处系统性强制迁移。Mi’kmaq与Wolastoqiyik条约政治不从英国和法国之间的占领叙事中消失。

## 地图和统计审查

地点使用旧阿卡迪亚遗址参考，不追加任意海岸线或烧毁建筑GPS。继续核Church远征日记和Parks Canada跨世纪同名村落对应旧专题ID。

本篇事件的经纬度若为空，即只能以历史地名呈现；一切现代遗址Point仅作为**现代位置参照**，未经核实的主权边界、种植园面积、强迫迁移航迹全部不绘Polygon/LineString。

## 资料来源与实际阅读范围

- `R7010`：First warfare: Fort Beauséjour/Fort Cumberland；https://parks.canada.ca/lhn-nhs/nb/beausejour/culture/histoire-history/premier-conflit-first-warfare；**阅读层级**：1704 Benjamin Church campaign Beaubassin then Grand-Pré; independent pre-1755 expulsion raid。
- `S11`：A village caught in the crossfire Beaubassin；https://parks.canada.ca/lhn-nhs/ns/beaubassin/culture/village；**阅读层级**：1704袭击、1713边界不定、1722船只、1730宣誓、1750受迫迁移。

## 下一阶段具体查核

依事件来源ID逐件查原卷或国家机构提供的数字副本，记录卷号、页码、原文异文与反方当事人证词；画地图之前再审历史名称及权属。
