# 1702—1728｜卡罗来纳对佛罗里达的军事袭击与原住民奴役

**定位**：第七轮地区扩查深入调查；`research_only`。本篇为逐条有来源的事件候选整合，非已刊发地图故事。

## 背景—决策

英属卡罗来纳的殖民者试图利用与西班牙佛罗里达的军事竞争扩大港口势力及被俘人口交易。1702年卡罗来纳议会鼓励远征参与者分享掠获品及被迫奴役的人口，随后James Moore率部围攻圣奥古斯丁；城堡未被攻取，英军撤离时焚毁城市。1704年行动转向Apalachee的传教村及原住民政治网络。

## 实际行动、具名地点与时间

### 1702-09｜卡罗来纳殖民议会以掠夺品和奴役人口份额激励圣奥古斯丁远征

事件ID：`E18A7-1702-FL-1702-COUNCIL`。英国殖民议会批准攻击西班牙佛罗里达的计划，公开承诺参加者分享掠夺所得和被俘人口；法令决策≠实际每人所得。

**行为主体**：Carolina Commons; James Moore；**地点**：Charles Towne, Carolina；**证据来源**：R7001, R7007。

### 1702-10-16｜James Moore从Port Royal率舰队驶向西属佛罗里达

事件ID：`E18A7-1702-FL-1702-SAIL`。NPS详述Moore的舰队从卡罗来纳Port Royal开航；路线顺序有据但没有地理航迹，不画实际航行曲线。

**行为主体**：James Moore; Carolina provincial fleet；**地点**：Port Royal, Beaufort, South Carolina；**证据来源**：R7001。

### 1702-11｜英属卡罗来纳远征军焚毁Nombre de Dios传教教堂

事件ID：`E18A7-1702-FL-1702-NOMBRE`。英方登陆后焚毁Nombre de Dios的原住民传教设施；佛罗里达大学考古史与NPS围城史互证。

**行为主体**：Carolina troops; mission community；**地点**：Nombre de Dios, St Augustine, Florida；**证据来源**：R7001, R7003。

### 1702-11-03｜卡罗来纳舰队夜袭Amelia岛西班牙传教据点

事件ID：`E18A7-1702-FL-1702-AMELIA`。11月3日午夜至次日英方占据岛上部分西班牙驻点及传教点，为进攻St Augustine铺路；未证整岛原住民土地合法归属。

**行为主体**：Moore expedition; Spanish mission communities；**地点**：Amelia Island, Florida；**证据来源**：R7001。

### 1702-11-08｜英国卡罗来纳军队封锁St Augustine入口并围困城堡

事件ID：`E18A7-1702-FL-1702-BLOCK`。NPS记录11月8日英舰出现在圣奥古斯丁海湾，陆路部队推进；守方把居民和物资转入城堡，围城与强夺城堡是不同结果。

**行为主体**：Moore and Robert Daniel; Joseph de Zúñiga y Zérda；**地点**：St Augustine, Castillo de San Marcos, Florida；**证据来源**：R7001, R7002。

### 1702-12-26｜古巴西班牙援军抵达迫使英方放弃圣奥古斯丁围城

事件ID：`E18A7-1702-FL-1702-RELIEF`。四艘西班牙战舰抵达，英军撤围焚毁圣奥古斯丁的其余建筑；英国没有取得Castillo de San Marcos实控。

**行为主体**：Moore; Robert Daniel; Spanish relief navy；**地点**：St Augustine, Florida；**证据来源**：R7001, R7002。

### 1703｜Apalachicola军队袭击San José de Ocuya传教站

事件ID：`E18A7-1703-FL-1703-OCUYA`。佛罗里达州博物馆时间轴把1703年Ocuya定为最先遭毁的阿帕拉契传教站之一，参与者为Apalachicola力量；须核原档再判与英国殖民官员直接指挥关系。

**行为主体**：Apalachicola fighters; Spanish mission; Apalachee residents；**地点**：San José de Ocuya, Apalachee province, Florida；**证据来源**：R7004。

**争议**：此事件行动主体是Apalachicola军，不应自动写成英国正规军直接参战。

### 1704｜James Moore率卡罗来纳远征袭击Apalachee传教区并劫掳原住民

事件ID：`E18A7-1704-FL-1704-APALACHEE`。英殖民军与部分Creek等盟友袭击阿帕拉契传教村落，俘虏进入北方殖民地奴役网络。不同社区既有外交自主，也有与西班牙当局的冲突；原史料估数需另核分母。

**行为主体**：James Moore; Carolina troops; Creek allies; Apalachee peoples；**地点**：Apalachee province, inland northern Florida；**证据来源**：R7005, R7006, R7007。

**数字口径**：学术摘要提及数千居民被迁走/奴役，但是否含逃难、盟军搬迁、欧洲定居者尚需核对；事件数值字段保留null。

### 1704｜卡罗来纳袭击中Ayubale传教站守军及居民抵抗并遭镇压

事件ID：`E18A7-1704-FL-1704-AYUBALE`。Covington学术史提及Ayubale传教站神父Miranda及原住民守军抵抗，以及从San Luis赶往的Ruiz Mexia救援部队失败；未核具体日和人数。

**行为主体**：Apalachee defenders; Spanish relief column; Carolinian allied troops；**地点**：Ayubale mission, Apalachee province；**证据来源**：R7006。

### 1704｜San Luis居民与西班牙当局自行焚毁并撤离聚落以阻止英方占领

事件ID：`E18A7-1704-FL-1704-SANLUIS-BURN`。官方教师导览记7月31日San Luis的居民和西班牙驻军主动拆焚居所后撤离，这是防止英军占领而实施的撤退措施；不能误写为英方当日烧毁San Luis。

**行为主体**：Apalachee residents; Spanish garrison；**地点**：Mission San Luis de Talimali, Florida；**证据来源**：R7004, R7005。

**争议**：本轮在线正文支持1704年居民主动焚城，7月31日精确日期来自州立博物馆教师指南PDF搜索摘录，原PDF页面尚未截图；日期候审改为year更安全。

### 1704｜阿帕拉契幸存社区向法国辖Mobile、圣奥古斯丁等地迁移

事件ID：`E18A7-1704-FL-1704-FLIGHT`。州立博物馆记载部分Apalachee人向Mobile移居；另有人被贩卖至英属卡罗来纳等地，应尊重今天仍存续的Apalachee社区谱系。

**行为主体**：Apalachee families; Carolina slaving network; French and Spanish refuge authorities；**地点**：Mobile and St Augustine (regional endpoints only)；**证据来源**：R7004, R7005。

### 1705｜西属官员重访Apalachee故地发现重大人口与农牧损失

事件ID：`E18A7-1705-FL-1705-DESERTED`。州立博物馆年表称Landeche在1705年再访时原传教地区无人且无牲畜；这一记述限其访问范围，不能断言整个Apalachee民族消失。

**行为主体**：Spanish Admiral Landeche; Apalachee survivors；**地点**：Mission San Luis, Apalachee province；**证据来源**：R7004。

### 1715｜Guale酋长Francisco Jospogue的妻儿遭被英国鼓励的袭击者掳卖

事件ID：`E18A7-1715-FL-1715-JOSPOGUE`。佛罗里达大学历史人物专题引学术研究，记1715年其妻与4子女被与英属卡罗来纳交易网络有关的Yamasee袭击者俘虏；Jospogue拒绝三次以改宗换回家人的条件，家人被出售。

**行为主体**：Francisco Jospogue; Yamasee raiders; English slave traders；**地点**：Nombre de Dios area, St Augustine, Spanish Florida；**证据来源**：R7008。

**争议**：仅有大学历史人物页面，需检索所引Parker论文及英方交易原卷；切勿将全部Yamasee集体归为英方附属。

### 1728｜Palmer袭击再次破坏Nombre de Dios天主教堂与村庄

事件ID：`E18A7-1728-FL-1728-NOMBRE`。佛罗里达大学考古史记该城与教堂于1728年再遭卡罗来纳军毁坏，随后西班牙总督撤离残存建筑。

**行为主体**：John Palmer; Yamasee and mission communities；**地点**：Nombre de Dios, St Augustine；**证据来源**：R7003, R18。

### 1728-03-09｜John Palmer率卡罗来纳人和原住民盟军袭击Yamasee村落

事件ID：`E18A7-1728-FL-1728-PALMER`。NPS考古综述记3月9日约百名殖民者和百名原住民盟军突袭Nombre de Dios的Yamasee镇；30死亡、15俘虏是史家转引的单次袭击估数，非人口普查。

**行为主体**：Colonel John Palmer; Carolinian raiders; Yamasee villagers；**地点**：Nombre de Dios, St Augustine, Florida；**证据来源**：R18, R7002。

**数字口径**：NPS引用二手历史研究：30名Yamasee死亡及15人被俘；登记为当代研究引史家数字，不作为独立精确死亡总数。

## 受影响群体、抵抗、经济后果与长期影响

必须区分Moore率领的英属殖民军、自己参与战争且拥有独立政治动机的Creek/Apalachicola盟友、Apalachee抵抗者以及西班牙驻军。San Luis的焚毁系当地居民和西班牙驻军为防落入英军而自行拆毁，不能归责为英军亲自焚城。1715年Guale首领Jospogue的家人遭奴役是具名微观受害，原交易、赎回档案尚待核。

## 地图和统计审查

诸传教村只是有证地点；英方远征没有据此获得佛罗里达内陆实控。巨额俘虏人数仍有口径争议；查找1702州议会原决议、Moore行动记与西班牙mission visitas，需兼用当代Apalachee社区材料。

本篇事件的经纬度若为空，即只能以历史地名呈现；一切现代遗址Point仅作为**现代位置参照**，未经核实的主权边界、种植园面积、强迫迁移航迹全部不绘Polygon/LineString。

## 资料来源与实际阅读范围

- `R7001`：The Siege of 1702；https://www.nps.gov/casa/learn/historyculture/the-siege-of-1702.htm；**阅读层级**：1702 Carolinian council promised booty/slaves; Oct 16 sailing; Nov 3 Amelia landing; Nov 8 St Augustine blockade; Dec 26 relief; retreat and town burned。
- `R7007`：Moore, James Sr.；https://www.scencyclopedia.org/sce/entries/moore-james-sr/；**阅读层级**：1702 St Augustine siege; 1703-04 Carolinian Florida mission raids and indigenous enslavement。
- `R7002`：St. Augustine: introduction timeline；https://www.floridamuseum.ufl.edu/staugustine/timeline/castillo-introduction/；**阅读层级**：1702 siege, 1704 Apalachee missions, 1728 Palmer raid, 1763 Florida cession。
- `R7003`：Nombre de Dios Mission Sites；https://www.floridamuseum.ufl.edu/histarch/research/st-augustine/menendez/nombre-de-dios/；**阅读层级**：1702 and 1728 destruction of Nombre de Dios church, later protective relocations。
- `R7004`：Mission San Luis timeline；https://missionsanluis.org/learn/timeline/；**阅读层级**：1703 Ocuya attack; 1704 mission collapse and Apalachee relocation; 1705 deserted sites; 1763-64 migration。
- `R7005`：End of the Mission System；https://missionsanluis.org/learn/history/end-of-the-mission-system/；**阅读层级**：1704 English and Creek allies raids; many Apalachees enslaved, others fled; San Luis burned by evacuees, not British torching。
- `R7006`：Apalachee Indians, 1704–1763 (1971)；https://stars.library.ucf.edu/fhq/vol50/iss4/5/；**阅读层级**：1704 Moore raids, Apalachee dispossession, estimates described by earlier historian; numbers not adopted as exact totals。
- `R7008`：The English Menace & African Resistance；https://www.floridamuseum.ufl.edu/staugustine/timeline/the-english-menace/；**阅读层级**：1715 Francisco Jospogue family taken into English-slaving network; identity, family repeated refusal from cited academic research。
- `R18`：Ninety Six colonial site and the Cherokee War 1760–1762；https://www.nps.gov/orgs/1539/the-southeast-chronicles-ninety-six-national-historic-site.htm；**阅读层级**：1760 Jun24 action, Aug8 Loudoun surrender, 1761 Grant expedition, use reported totals attributed to cited studies。

## 下一阶段具体查核

依事件来源ID逐件查原卷或国家机构提供的数字副本，记录卷号、页码、原文异文与反方当事人证词；画地图之前再审历史名称及权属。
