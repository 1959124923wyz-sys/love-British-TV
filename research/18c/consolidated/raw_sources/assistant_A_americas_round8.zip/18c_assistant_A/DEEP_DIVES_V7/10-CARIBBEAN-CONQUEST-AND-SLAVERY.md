# 1761—1797｜小安的列斯群岛殖民权转换、种植园和战争

**定位**：第七轮地区扩查深入调查；`research_only`。本篇为逐条有来源的事件候选整合，非已刊发地图故事。

## 背景—决策

七年战争和法国革命战争时期，英国通过海军、陆军攻击相继控制或短期占领Dominica、Martinique、Tobago、St Lucia、Trinidad等不同岛屿。1794年Martinique攻城时，英国与一部分反法国革命废奴政策的殖民庄园主结盟。

## 实际行动、具名地点与时间

### 1761｜英国海陆军远征多米尼克的欧洲殖民驻点

事件ID：`E18A7-1761-CAR-1761-DOMINICA`。新不伦瑞克大学馆藏说明将1761年Dominica的英国入侵与1762年Martinique/Cuba连列；为资料线索，待找条约原档明确实际日与占领范围。

**行为主体**：Royal Navy; British expedition; local French administration；**地点**：Roseau and Dominica, Caribbean；**证据来源**：R7015。

### 1762｜英国七年战争远征占领马提尼克并维持短期军事管治

事件ID：`E18A7-1762-CAR-1762-MARTINIQUE`。美国国会图书馆所引法国海外档案导览记英国于1762年占领Martinique，1763年交还法国。反法军行动应单列，不当成持久英属实控。

**行为主体**：British forces; French colonial garrison；**地点**：Fort Royal, Martinique；**证据来源**：R7014, R7015。

### 1763｜英国按照战后和约将马提尼克交还法国

事件ID：`E18A7-1763-CAR-1763-MARTINIQUE-REST`。法国档案导览记1763恢复法国管治；离岛和实际换旗时间仍需逐港总督书信确定。

**行为主体**：British and French Crown authorities；**地点**：Martinique island, colony administration；**证据来源**：R7014。

### 1793-04-15｜英国远征军夺取法属Tobago的Fort République

事件ID：`E18A7-1793-CAR-1793-TOBAGO`。英国国家陆军博物馆以1793年4月15日为史画标题，记Cuyler与Laforey舰队攻取Scarborough高地堡垒；英国1779/81年失去该岛后又恢复军事驻点。

**行为主体**：Major General Cornelius Cuyler; Vice Admiral John Laforey；**地点**：Fort République / Fort King George, Scarborough, Tobago；**证据来源**：R7019。

### 1794-02｜英军在部分反废奴法国庄园主配合下进攻Martinique

事件ID：`E18A7-1794-CAR-1794-MARTINIQUE-ATTACK`。英国海军Jervis与陆军Charles Grey进攻法国据点；文献明确部分法国庄园主反对法国革命后的废奴政治，进而协助英军。

**行为主体**：Admiral John Jervis; General Charles Grey; French planter allies；**地点**：Martinique, French Caribbean；**证据来源**：R7016, R7017。

### 1794-03｜Fort Royal与Fort Bourbon被英军陆续夺取并维持岛上殖民占领

事件ID：`E18A7-1794-CAR-1794-MARTINIQUE-CAP`。博物馆馆藏说明两个要塞到3月下旬抵抗结束、马提尼克形成英国军政占领，延续至1800年之后；1794不绘古代岛界实测Polygon。

**行为主体**：British Army and Royal Navy; French garrison；**地点**：Fort Royal / Fort Bourbon, Martinique；**证据来源**：R7017, R7014。

### 1794-03-20｜英国Charles Grey军队攻占Martinique的Fort Louis

事件ID：`E18A7-1794-CAR-1794-FORT-LOUIS`。英国国家陆军博物馆给出20 March 1794军队突击Fort Louis的日级信息；该事件不是同年的Guadeloupe战斗。

**行为主体**：General Charles Grey; French republican garrison；**地点**：Fort Louis, Fort-de-France, Martinique；**证据来源**：R7016, R7017。

### 1796-05｜Abercromby英国军队再夺St Lucia主要据点

事件ID：`E18A7-1796-CAR-1796-STLUCIA`。英国国家陆军博物馆记1796再度攻下St Lucia；法国共和军与被奴役者当地长期反抗未同日结束，精确投降日期待档案核证。

**行为主体**：Sir Ralph Abercromby; British forces; local French republicans and self-liberating fighters；**地点**：St Lucia, Fort Charlotte / Morne Fortune general region；**证据来源**：R7020, N18。

### 1797-02-17｜英国海陆军攻击西属Trinidad迫使殖民当局投降

事件ID：`E18A7-1797-CAR-1797-TRINIDAD`。国家陆军博物馆同代版画标题明确描绘1797年2月17日战斗，英国将西班牙据点纳入军事占领；投降文本与继后条约日期另核。

**行为主体**：General Sir Ralph Abercromby; Rear Admiral Henry Harvey; Spanish governor；**地点**：Port of Spain / Spanish naval station, Trinidad；**证据来源**：R7018, R7020。

## 受影响群体、抵抗、经济后果与长期影响

要把“欧洲殖民当局换旗”“被奴役者所处法律制度是否改变”“原住民及逃亡者武装行动”区别记录；英军夺下一处港堡不等于全岛原住民失去土地政治自主。1793夺Tobago和1797夺Trinidad分别有英国国家陆军博物馆馆藏图画题名与战例说明。

## 地图和统计审查

1761 Dominica的法英归属在条约以前具有特殊性质，不能简单标为英国攻取既成的法国主权岛。多岛屿未得有据逐日占领界线，保留单点或无坐标，无任何跨岛主权Polygon。

本篇事件的经纬度若为空，即只能以历史地名呈现；一切现代遗址Point仅作为**现代位置参照**，未经核实的主权边界、种植园面积、强迫迁移航迹全部不绘Polygon/LineString。

## 资料来源与实际阅读范围

- `R7015`：British West Indies research guide；https://lib.unb.ca/guides/loyalist-collection-british-west-indies；**阅读层级**：1761 Dominica invasion, 1762 Martinique and Cuba, after 1763 demobilization; finding aid, not primary dispatch pages。
- `R7014`：Francophone Caribbean Collections: Online Resources；https://guides.loc.gov/francophone-caribbean-collections-library-of-congress/online-resources；**阅读层级**：Martinique British taken 1762 and restored 1763; again invaded 1794, held into following century。
- `R7019`：Capture of Tobago 15 April 1793；https://collection.nam.ac.uk/detail.php?acc=1978-11-87-1；**阅读层级**：1793-04-15 title; British storm Fort République/Scarborough, island conquest and eighteenth-century change。
- `R7016`：Fort Louis in the Island of Martinique 1794；https://collection.nam.ac.uk/detail.php?acc=1971-02-33-249-1；**阅读层级**：1794-03-20 British storming of Fort Louis with support of slaveholding French planters。
- `R7017`：Forts Bourbon and Louis Martinique 1794；https://collection.nam.ac.uk/detail.php?acc=1971-02-33-250-1；**阅读层级**：1794 February attack; forts resisted until late March; contextual institutional caption。
- `R7020`：38th Staffordshire Regiment campaign overview；https://www.nam.ac.uk/explore/38th-1st-staffordshire-regiment-foot；**阅读层级**：1794 Martinique and 1796 St Lucia, 1797 Trinidad participation, corroborating theater but not day。
- `N18`：Royal Navy counterinsurgency 1795–1832；https://journals.sagepub.com/doi/10.1177/08438714231219455；**阅读层级**：圣文森特第二次战争、Grenada 1795反叛及海军阻断。
- `R7018`：Taking of Trinidad 17 February 1797；https://collection.nam.ac.uk/detail.php?acc=1971-02-33-406-1；**阅读层级**：1797-02-17 date represented by engraving; actual capitulation needs treaty original confirmation。

## 下一阶段具体查核

依事件来源ID逐件查原卷或国家机构提供的数字副本，记录卷号、页码、原文异文与反方当事人证词；画地图之前再审历史名称及权属。
