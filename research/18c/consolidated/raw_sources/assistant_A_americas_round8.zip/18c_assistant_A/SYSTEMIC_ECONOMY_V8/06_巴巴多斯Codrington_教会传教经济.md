# Codrington庄园：传教机构和糖业奴役劳动

## 当事人

殖民财产持有人Christopher Codrington III在1710年去世，向英国国教相关的Society for the Propagation of the Gospel in Foreign Parts（SPG，现USPG的历史前身）遗赠巴巴多斯东部的两座糖庄园。SPG继承并从1712年前后通过当地管理人经营，用庄园收入支持传教。

## 经济与人口

USPG及Codrington和解项目说明庄园两处合计**约700英亩**，受奴役劳动力长期投入甘蔗种植、制糖和日常维护；现组织网站记不同时期同时存在**190—440名**劳工。这是跨1712—1838范围的叙述，不能当1712年单一人口。

**数字冲突**：Church of England的官方问答对1710年遗赠记**300名**被奴役者；Codrington项目另一历史网页写**约400人**。初始年份、遗嘱规定人数与实际移交人头尚需1710遗嘱、1712管理账核实。保留不同来源而不强行平均或累计。

## 对“体系化”的证据价值

此个案属于**宗教团体的公司化持有与跨海财政链**，是除王室和私商之外的第三类组织。英国国教传教体系的一个机构获益，不应被误写成“英国政府的全部教会部门均直接持有这700英亩”。被奴役者自身宗教选择、逃亡和拒绝服从需利用庄园管理人通信与人口簿继续核实。

## 史料
- `R8013` Project Spire frequently asked questions — https://www.churchofengland.org/national-bodies/church-commissioners/what-we-do/what-we-fund/project-spire/faqs
- `R8014` The Codrington Project — https://uspg.org.uk/codrington-project/
- `R8015` History timeline — https://www.codringtonproject.org/about/history/
