# 1768斯坦威克斯堡条约：英王边界谈判、Haudenosaunee政治与其他民族争地

**状态**：研究候审，未刊发；这些事件ID均在累计事件数据库中，引用本文不得额外计数。
**旧专题关联**：E18-C13, E18-C25

## 一、背景

1763王室公告试图限制殖民定居越过阿巴拉契亚；殖民投机者依旧争夺俄亥俄流域及宾州内陆。原住民政治实体仍拥有各自土地、联盟与外交权利。

## 二、决策与殖民机制

北方总督William Johnson与南方John Stuart奉英国贸易部意图建立新界线；1768年与六族达成界线协议。

## 三、实际行动：逐件候审事件

### 1766-07｜Odawa领袖Pontiac与英方在Fort Ontario达成外交安排

**事件ID**：`E18A3-1766-PONTIAC-ONTARIO`。**行动主体**：Pontiac、William Johnson及联盟其他族群。**位置**：Fort Ontario Oswego New York。
美国国家公园管理局记1766年7月Pontiac与英方Johnson在Fort Ontario议和，基本结束该阶段战事，原住民族对土地的争议并未消失。

**来源**：`V301`。**位置精度**：no_verified_coordinate。

### 1768-10｜英国南方原住民事务官John Stuart与切罗基首领调整边界

**事件ID**：`E18A3-1768-HARD-LABOUR`。**行动主体**：John Stuart、Cherokee首领。**位置**：Hard Labour South Carolina historic locale。
NPS记1768-10-17结论；另早期历史法条抄本指出10月14日签署，两日差留待检原文，暂精确至月。

**来源**：`V301`。**位置精度**：no_verified_coordinate。

### 1768-11-05｜英王代表与Haudenosaunee六族在Stanwix制定有争议边界

**事件ID**：`E18A3-1768-STANWIX`。**行动主体**：William Johnson、Six Nations代表、Lenape/Shawnee/Mingo等相关族群。**位置**：Fort Stanwix Rome New York。
1768-11-05签订《斯坦威克斯堡条约》划定边界、并提出将其他民族所主张土地纳入转让；原件不能作为所有当地原住民直接签署与让地的证明。

**来源**：`V301`, `V302`。**位置精度**：modern_official_site_representative_not_historical_GPS。

### 1770-10-18｜英国与切罗基代表再谈Lochaber边界及土地声索

**事件ID**：`E18A3-1770-LOCHABER`。**行动主体**：John Stuart、Cherokee代表、英殖民地方官。**位置**：Lochaber South Carolina。
1770-10-18 Lochaber条约重划南部殖民边界，史料明确有不同条约与测量版本；不绘现代Kentucky/Tennessee为英方实测征服区。

**来源**：`V301`。**位置精度**：no_verified_coordinate。

### 1773｜英国在宾州调整1768年原住民界线形成新的土地契约争议

**事件ID**：`E18A3-1773-FORT-STANWIX-LINE`。**行动主体**：英国殖民官、六族代表、Lenape等地方民族。**位置**：Pennsylvania colonial frontier (multiple places)。
NPS记1773年修订Fort Stanwix涉及宾州所谓Line of Property；这是测量与声索变化，不能仅因一条法定线就画实控多边形。

**来源**：`V301`。**位置精度**：no_verified_coordinate。

## 四、地名、控制变化与GIS

可核签约代表点为今天的Fort Stanwix国家纪念地(-75.455576,43.210534)。美国NPS另给Willett中心入口另一组坐标。18世纪条约Guy Johnson历史边界图是值得独立校准的线证，当前GeoJSON未画任何实际边界。

## 五、行为主体和人物

Haudenosaunee六族代表、Lenape、Shawnee、Mingo及Cherokee等各自有土地关系者，Sir William Johnson、John Stuart、英国投机商。

## 六、受影响群体

Six Nations签约文书里提及Shawnee/Delaware等群体，不构成每一处实际居住者授权转让的共同协议；不能把条约价值算到所有部族。

## 七、反抗与政治主张

原文保留六族申诉英殖民侵占和要求保障村庄周边地权的声索；研究应收集Shawnee/Lenape自身叙述与族群档案来核验实际同意。

## 八、经济与统计后果

条约宣称价值£10460 7s 3d含贸易礼物与现金。这是当时文书中的政治交易口径，不是每英亩价格或殖民土地实控总收益。

## 九、长期影响、史料冲突与下一步

1768边线、1770Lochaber和1773宾州线调整反映不断改变的权利声索，不能直接套现代州界模拟1680—1790实占。

### 原档争议与研究门禁

Hard Labour日期NPS为10月17，历史原件转录可能为10月14；本包仅月级。条约图像仍未地理配准，不允许虚构LineString。

### 来源入口（阅读层级如登记）

- **V301** [1768 Boundary Line Treaty of Fort Stanwix](https://home.nps.gov/articles/000/1768-boundary-line-treaty-of-fort-stanwix.htm) — institutional_historical_interpretation_full_text
- **V302** [1768 Treaty of Fort Stanwix text](https://treaties.okstate.edu/treaties/treaty-of-fort-stanwix-1768-21783) — edited_primary_source_transcription

**制图总则**：现代官方遗址Point不代表历史控制面；历史线和海上路线未经过GIS审核，不绘Polygon或LineString。
