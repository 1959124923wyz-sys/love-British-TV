# 1721—1724英国新英格兰殖民军袭击Norridgewock阿布纳基社区

**状态**：研究候审，未刊发；这些事件ID均在累计事件数据库中，引用本文不得额外计数。
**旧专题关联**：E18-C03

## 一、背景

阿布纳基社会在Kennebec河流域有自身村落与外交组织，欧洲传教、英法战争和英国新英格兰定居扩张交织。

## 二、决策与殖民机制

英殖民武装组织进入原住民村落，殖民官方信件与后世不同群体叙述保存不同时点的军事行动。

## 三、实际行动：逐件候审事件

### 1721-01-21｜英属新英格兰殖民军官记述袭击Norridgewock阿布纳基村落

**事件ID**：`E18A3-ABENAKI-RAID-1721`。**行动主体**：Johnson Harmon、Joseph Heath、Abenaki居民。**位置**：Norridgewock village Kennebec River。
缅因历史学会存1721-01-21两名英殖民军官发出的Norridgewock袭击信，原件所描述的行动实际发生日仍待对照全文。

**来源**：`V342`, `V343`。**位置精度**：no_verified_coordinate。

### 1724-08-23｜殖民部队袭击并烧毁Norridgewock阿布纳基聚居地

**事件ID**：`E18A3-ABENAKI-1724-NORRIDGEWOCK`。**行动主体**：英属新英格兰民兵、Abenaki居民及耶稣会传教士。**位置**：Norridgewock Kennebec River village。
1934史学论文及原始档案编辑记1724年8月23日殖民军攻击阿布纳基Norridgewock并杀死居民；伤亡数字及原住民口述版本矛盾，暂不登记确数。

**来源**：`V341`, `V343`。**位置精度**：no_verified_coordinate。

## 四、地名、控制变化与GIS

Norridgewock位于缅因Kennebec河流域，旧村落遗址不能从现代城镇标签自动获得真实战斗/烧村GPS。

## 五、行为主体和人物

Norridgewock Abenaki居民、Johnson Harmon和Joseph Heath等殖民军官、Jesuit Sebastian Rale、Wabanaki相关社区。

## 六、受影响群体

殖民军攻击村落导致居民死亡与生活空间破坏，但人数尚未建立双源可比口径。

## 七、反抗与政治主张

原住民族组织村落保卫与多地区外交联系；不同Abenaki口述、英方军报、耶稣会记述不应由殖民胜方叙述独占。

## 八、经济与统计后果

定居者希望进入河流和资源区域；目前没有真实逐宗土地交易、恢复和赔款的账本，不能据战争示意图计算剥夺面积。

## 九、长期影响、史料冲突与下一步

袭击加剧英法/原住民冲突与后续条约谈判，并为阿卡迪亚—新英格兰长时跨地区事件链提供补充。

### 原档争议与研究门禁

1721信件确切写成日期只是文书日期，真实行军袭击日需阅读全文；1724-08-23战斗日期在后世文献流传且各历法版本应对照。

### 来源入口（阅读层级如登记）

- **V341** [The Attack on Norridgewock 1724](https://penelope.uchicago.edu/Thayer/E/Journals/NEQ/7/3/Attack_on_Norridgewock%2A.html) — peer_reviewed_1934_historical_study_full_text
- **V342** [Letter about Abenaki village raid 1721](https://www.mainememory.net/record/7350) — primary_letter_transcription_and_metadata
- **V343** [Dummer War 1720s Native diplomacy and New England raids](https://albanyindiancommissioners.com/tag/dummers-war/) — edited_primary_archival_transcription_context

**制图总则**：现代官方遗址Point不代表历史控制面；历史线和海上路线未经过GIS审核，不绘Polygon或LineString。
