# 1745 Louisbourg堡垒夺取与1748返还：军事行动/外交条款双时间线

**状态**：研究候审，未刊发；这些事件ID均在累计事件数据库中，引用本文不得额外计数。
**旧专题关联**：E18-C11

## 一、背景

法国Louisbourg是新法兰西大西洋补给和海上军事要塞，英属新英格兰殖民者与英国皇家海军联合攻取。

## 二、决策与殖民机制

马萨诸塞总督William Shirley组织殖民军，William Pepperrell率兵、Royal Navy提供海上封锁和协助。

## 三、实际行动：逐件候审事件

### 1745-06｜新英格兰殖民军与皇家海军夺取法国Louisbourg要塞

**事件ID**：`E18A3-1745-LOUISBOURG-FALL`。**行动主体**：William Pepperrell部队、英国皇家海军、法国守军。**位置**：Louisbourg Île Royale / Cape Breton。
英国国家陆军博物馆和UNB文书目录确认1745英军与殖民军合围Louisbourg；具体6月中旬接受投降，旧历/新历日别待核，故登记月级。

**来源**：`V319`, `V320`, `V318`。**位置精度**：no_verified_coordinate。

### 1748｜Aix-la-Chapelle和约决定把Louisbourg交还法国

**事件ID**：`E18A3-1748-LOUISBOURG-RETURN`。**行动主体**：英法王室、新英格兰殖民当局、Louisbourg居民。**位置**：Louisbourg Cape Breton。
1748和约约定返还Louisbourg，具体地方实际交接日不能据条约年直接推为1748年末法方完全占堡。

**来源**：`V318`, `V320`。**位置精度**：no_verified_coordinate。

## 四、地名、控制变化与GIS

Île Royale/Cape Breton的Louisbourg堡垒为局部军占，不等于1745年英国控制整个现新斯科舍省或Cape Breton所有原住民土地。

## 五、行为主体和人物

William Shirley、William Pepperrell、Peter Warren、法国驻军及当地居民、Mi’kmaq等地方政治团体。

## 六、受影响群体

围城损失仍待团属编表，不将战士总数、人口驱逐与当地居民死亡混合。

## 七、反抗与政治主张

法国驻军防守且Mi’kmaq仍拥有自主权；战争从不抹去地方原住民政治。

## 八、经济与统计后果

Louisbourg扼守贸易航线，英国军政希望改变法方商贸与补给制度；总掠获额须查船货账。

## 九、长期影响、史料冲突与下一步

1748和约决定交还Louisbourg，地方真实接管比条约签署需单独核验。1758再度攻取已在C11旧资料，不能与1745混为同一战争。

### 原档争议与研究门禁

UNB线上目录中有一处将1758错写1748，需用英国陆军博物馆与新斯科舍政府确认事件年份；新旧历区别使日级战役日期仍待审。

### 来源入口（阅读层级如登记）

- **V318** [Acadian Timeline](https://acadien.novascotia.ca/en/timeline) — provincial_government_historical_timeline
- **V319** [Louisbourg Papers expedition of 1745](https://loyalist.lib.unb.ca/record/louisbourg-papers-expedition-1745-1744-1758) — primary_archive_collection_guide_only
- **V320** [The Capture of Louisbourg 1745](https://collection.nam.ac.uk/detail.php?acc=1971-02-33-227-1) — museum_object_and_historical_context

**制图总则**：现代官方遗址Point不代表历史控制面；历史线和海上路线未经过GIS审核，不绘Polygon或LineString。
