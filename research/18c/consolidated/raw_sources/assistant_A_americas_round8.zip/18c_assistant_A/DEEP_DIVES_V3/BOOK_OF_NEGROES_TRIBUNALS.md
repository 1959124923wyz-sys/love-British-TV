# 1779—1783 Philipsburg公告、黑人求自由与英美联合撤离审查

**状态**：研究候审，未刊发；这些事件ID均在累计事件数据库中，引用本文不得额外计数。
**旧专题关联**：E18-C17, E18-C18

## 一、背景

1775 Dunmore与1779 Clinton的英国军令为部分逃离反英殖民者的人提供保护；并非英国帝国废除所有海外奴役制。

## 二、决策与殖民机制

Clinton1779年公告分别处理被俘武装黑人、逃离起义军奴隶主的人；Carleton1783年为避免和平条约争议设船舶检查与申索机制。

## 三、实际行动：逐件候审事件

### 1779-06-30｜英军Clinton宣布保护逃离反英奴役主人的黑人

**事件ID**：`E18A3-PHILIPSBURG-1779`。**行动主体**：Sir Henry Clinton、African freedom seekers、British army。**位置**：Philipsburgh New York。
1779-06-30英军总部公告只对逃自rebels的人提供免被卖与军内职业保护，对俘获武装黑人另规定以固定价格购入，不能表述为帝国普遍废奴。

**来源**：`V337`, `V338`, `S34`。**位置精度**：no_verified_coordinate。

### 1783-04-15｜英国司令Carleton发令检查纽约港载运黑人撤离的船只

**事件ID**：`E18A3-CARLETON-APRIL1783`。**行动主体**：Sir Guy Carleton、British ship masters、Black Loyalists。**位置**：New York City port。
英国国家档案馆《Book of Negroes》部分原件转录记Carleton在1783-04-15给军队发命令，涉及黑人逃亡者身份核查；并非每人获自由。

**来源**：`V339`, `V340`。**位置精度**：no_verified_coordinate。

### 1783-05-22｜Carleton下达第二次纽约港黑人撤离监督命令

**事件ID**：`E18A3-CARLETON-MAY1783`。**行动主体**：Sir Guy Carleton、British naval inspection commissioners。**位置**：New York port。
TNA原卷末页引用了1783-05-22第2次命令；单列文书日期以便审英美双方处理流程。

**来源**：`V339`。**位置精度**：no_verified_coordinate。

### 1783-07-24｜纽约英美联合审查委员会裁定将两名黑人儿童交还声索人

**事件ID**：`E18A3-1783-JUL24-CHILDREN-CLAIM`。**行动主体**：British commissioners、American claimant Gerrard G. Beekman、儿童Peter和Elizabeth及父亲Samuel Doson。**位置**：New York British evacuation commission。
英国国家档案馆公开原件记1783-07-24双方审查：Peter、Elizabeth随父亲逃到纽约后被他人声称财产，联合委员会允许送还声索者，此为具体再奴役案例。

**来源**：`V339`。**位置精度**：no_verified_coordinate。

### 1783-08-02｜纽约撤离审查会处理Betty/Elizabeth Truant遭索还身份纠纷

**事件ID**：`E18A3-1783-AUG2-BETTY-CLAIM`。**行动主体**：Thomas Smith、Betty（证件名Elizabeth Truant）、英美审查人。**位置**：New York British evacuation commission。
TNA公开1783-08-02案件开头与证件名称，但所引网页不显示最终判决；结果字段必须为null，不能称已送回奴役。

**来源**：`V339`。**位置精度**：no_verified_coordinate。

### 1783-11-30｜英国军方在纽约撤离末期查验船载黑人登记名册

**事件ID**：`E18A3-1783-INSPECTION-NOV30`。**行动主体**：British naval commissioners、Black Loyalists。**位置**：New York Harbor。
TNA原卷有1783-11-30船舶检查证明，名单数千人中有仍受奴役者，不得将船载总数均归已获自由者。

**来源**：`V339`, `V340`。**位置精度**：no_verified_coordinate。

## 四、地名、控制变化与GIS

公告由Philipsburgh签发、在纽约英军控制区施行；检查委员会与船只登记在纽约，航行目的地新斯科舍各港需要逐船查看。

## 五、行为主体和人物

Sir Henry Clinton、Sir Guy Carleton、Black Loyalists、黑人求自由者、联合英美审查委员、Gerrard G. Beekman、儿童Peter与Elizabeth及父亲Samuel Doson、Betty/Elizabeth Truant。

## 六、受影响群体

约3000条名册包括自由与仍被奴役者。纽约两名儿童被审查会判交回声索者，揭示部分求自由者仍面临再奴役。

## 七、反抗与政治主张

被奴役者主动逃向英军、服役、诉求自由；具体记录保留当事人姓名和身份申诉而非只笼统称军队给予自由。

## 八、经济与统计后果

英国与美国围绕赔偿和所谓奴隶主财产争执；名册有原奴隶主、年龄、船名字段，应据原册逐条归档。

## 九、长期影响、史料冲突与下一步

移往新斯科舍后一些黑人效忠派又遭遇土地拒发、就业歧视和迁居塞拉利昂，与C18—C19专篇持续相接。

### 原档争议与研究门禁

TNA网页展示1783-08-02 Betty案开头但未给最终判词；不能称该案必定再奴役。加拿大早期页面关于1782年撤离的年份误记，采用原件1783年月日与LAC新版名册核。

### 来源入口（阅读层级如登记）

- **S34** [American Revolution Timeline](https://www.nps.gov/subjects/americanrevolution/timeline.htm) — institutional_webpage_read
- **V337** [Henry Clinton 1779 Proclamation broadside](https://www.loc.gov/item/rbpe.11001000/) — primary_printed_broadside_catalogue
- **V338** [Philipsburg Proclamation 30 June 1779 full transcription](https://forgingus.org/documents/philipsburg-proclamation-30-june-1779) — transcribed_primary_proclamation_text
- **V339** [The Book of Negroes source extracts and Anglo-American hearings](https://www.nationalarchives.gov.uk/explore-the-collection/stories/the-book-of-negroes/) — government_archive_primary_document_partial_transcription
- **V340** [Book of Negroes 1783 searchable register](https://www.canada.ca/en/library-archives/collection/research-help/genealogy-family-history/loyalists/book-of-negroes.html) — national_archive_catalogue_with_db

**制图总则**：现代官方遗址Point不代表历史控制面；历史线和海上路线未经过GIS审核，不绘Polygon或LineString。
