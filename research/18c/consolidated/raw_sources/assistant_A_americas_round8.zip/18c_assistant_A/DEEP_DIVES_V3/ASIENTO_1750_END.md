# 1750年马德里条约：南海公司Asiento合约终止的分阶段证据

**状态**：研究候审，未刊发；这些事件ID均在累计事件数据库中，引用本文不得额外计数。
**旧专题关联**：E18-A02

## 一、背景

1713年英西外交授予英国方面向西属美洲供给被奴役非洲人的特许。贸易合同与西属领土主权不同，南海公司及英国议会资本角色也需区别。

## 二、决策与殖民机制

1750-10-05英西签马德里赔偿/贸易条约，据西班牙国家历史档案馆目录，专设条款取消黑奴Asiento和许可船。

## 三、实际行动：逐件候审事件

### 1750-10-05｜马德里条约终结英国Asiento特许供应权的外交安排

**事件ID**：`E18A3-1750-ASIENTO-TREATY`。**行动主体**：西班牙王室、英国政府、南海公司。**位置**：Madrid。
西班牙国家历史档案馆条约系列记1750-10-05英西签订赔偿和贸易条约，明确涉及废止Asiento与Navío de Permiso；这是条约签署日，非每一份私营合约在该日结账。

**来源**：`V329`, `V330`。**位置精度**：no_verified_coordinate。

### 1750-11-05｜英国王室批准终结Asiento相关贸易权的马德里条约

**事件ID**：`E18A3-1750-ASIENTO-RATIFICATION-UK`。**行动主体**：英国王室、南海公司、西班牙王室。**位置**：London/Madrid。
PARES专件记英国方面1750-11-05批准条约；尚未核批约交换与商业结算生效日。

**来源**：`V330`。**位置精度**：no_verified_coordinate。

### 1750-12-03｜西班牙王室批准马德里条约有关Asiento终止条款

**事件ID**：`E18A3-1750-ASIENTO-RATIFICATION-SP`。**行动主体**：西班牙王室、英国政府。**位置**：Madrid。
PARES专件记西班牙1750-12-03批准，不能把5 Oct签订和12 Dec批准混为一天。

**来源**：`V330`。**位置精度**：no_verified_coordinate。

## 四、地名、控制变化与GIS

签约在Madrid；原Asiento服务区域分散于西属美洲商馆与港口，不能绘为英国拥有的殖民岛屿。

## 五、行为主体和人物

西班牙王室、英国王室、南海公司投资人、被奴役非洲人。

## 六、受影响群体

供给权通过条约取消不等于被强迫买卖的所有人获释；各商站人员与结算仍待原档。

## 七、反抗与政治主张

尚待查档记录西属港口被奴役者反抗与跨王室商法争议，不能虚构。

## 八、经济与统计后果

签署、英国批准11月5日与西班牙批准12月3日是三件可区分的法律动作；财务赔款金额尚未经此批查验。

## 九、长期影响、史料冲突与下一步

皇家特许贸易权被终止，但英国公司及私人奴役贸易在其他辖区继续。

### 原档争议与研究门禁

两份PARES记录同属一国档案系列，非独立双源；需要英方条约批准副本与南海公司清算账，不可按目录声称亲读6件原文。

### 来源入口（阅读层级如登记）

- **V329** [Madrid treaty on asiento and permitted vessels signed 1750-10-05](https://pares.cultura.gob.es/ParesBusquedas20/catalogo/description/6080941) — primary_archive_catalogue_text_only
- **V330** [1750 Madrid treaty ratified 3 December 1750](https://pares.cultura.gob.es/ParesBusquedas20/catalogo/description/5590380) — primary_archive_catalogue_text_only

**制图总则**：现代官方遗址Point不代表历史控制面；历史线和海上路线未经过GIS审核，不绘Polygon或LineString。
