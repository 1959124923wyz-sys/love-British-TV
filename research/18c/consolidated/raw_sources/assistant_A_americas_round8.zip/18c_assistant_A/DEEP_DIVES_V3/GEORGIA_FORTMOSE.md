# 1732—1763乔治亚殖民、Yamacraw外交与Fort Mose自由黑人抵抗

**状态**：研究候审，未刊发；这些事件ID均在累计事件数据库中，引用本文不得额外计数。
**旧专题关联**：E18-C21

## 一、背景

乔治亚殖民特许1732成立，殖民者抵达Yamacraw原住民家园之后必须与Tomochichi谈判；不应把对英友好政治行为解释为自动自愿移交所有祖地。

## 二、决策与殖民机制

托管人1735禁黑奴旨在特定防御与移民经济秩序，后来因殖民者压力渐次取消；1740 Oglethorpe发动对西班牙佛罗里达军事远征。

## 三、实际行动：逐件候审事件

### 1732-06-09｜英国王室签发乔治亚托管殖民地特许

**事件ID**：`E18A3-GEORGIA-CHARTER-1732`。**行动主体**：George II、Georgia Trustees、Creek和Yamacraw原住民族。**位置**：London / coastal Georgia paper claim。
英王1732-06-09签特许给英国托管人，不等于已在原住民住地完成军事征服或取得地籍。

**来源**：`V310`, `V312`。**位置精度**：no_verified_coordinate。

### 1733-02-12｜Oglethorpe获Yamacraw政治允许后在Savannah河岸建殖民聚落

**事件ID**：`E18A3-GEORGIA-SAVANNAH-1733`。**行动主体**：Oglethorpe、Yamacraw领袖Tomochichi、Mary Musgrove、移民。**位置**：Yamacraw Bluff / Savannah。
GHS官方年表记1733-02-12第一批114名殖民者抵达Yamacraw Bluff，日期为现代公历惯用标记，落点未经本轮定位历史现场GPS。

**来源**：`V307`, `V308`。**位置精度**：no_verified_coordinate。

### 1733-05｜Tomochichi与Oglethorpe就Savannah定居和贸易举行会谈

**事件ID**：`E18A3-GEORGIA-PEACE-1733`。**行动主体**：Tomochichi、Mary Musgrove、James Oglethorpe、Yamacraw。**位置**：Savannah / Yamacraw Bluff。
GHS年表记1733-05-20和平协议，当地纪念碑文记05-21正式核准，精确日有不同历史表述；保留月级。

**来源**：`V307`, `V308`, `V346`。**位置精度**：no_verified_coordinate。

### 1734-03-23｜Yamacraw代表团赴英国向英王与托管人争取公平贸易

**事件ID**：`E18A3-TOMOCHICHI-ENGLAND-1734`。**行动主体**：Tomochichi、Senauki、Toonahowi、Georgia Trustees。**位置**：Savannah to London route not traced。
GHS记代表团1734-03-23离Savannah赴伦敦，诉求教育与公平贸易；原住民代表是主动行动主体，不以殖民者单方叙述替代。

**来源**：`V307`, `V309`。**位置精度**：no_verified_coordinate。

### 1735｜Georgia殖民托管人通过禁止非洲奴役的制度

**事件ID**：`E18A3-GEORGIA-SLAVE-BAN-1735`。**行动主体**：Georgia Trustees、英国Privy Council、殖民移民。**位置**：Georgia colony (legal claim)。
1735 Georgia法律禁黑奴，主要关乎殖民地政治/军事设计；种植园主继续要求输入被奴役者，不把禁令直接当全体非洲人即时解放。

**来源**：`V310`, `V311`, `V312`。**位置精度**：no_verified_coordinate。

### 1738｜西班牙佛罗里达为逃离英国卡罗来纳奴役的人建立Fort Mose

**事件ID**：`E18A3-FORTMOSE-REFUGE-1738`。**行动主体**：Francisco Menéndez与自由黑人社区、西班牙总督、Carolina逃亡奴役者。**位置**：Fort Mose near St Augustine Florida。
1738西班牙创建有法律自由地位的非洲裔Fort Mose聚落并作为北方防线；不是英属据点，故在政治属性中写对英奴役的逃离与抵抗。

**来源**：`V313`, `V314`, `V316`。**位置精度**：no_verified_coordinate。

### 1740-05｜英国Georgia殖民军入侵西属佛罗里达并占Fort Mose

**事件ID**：`E18A3-1740-BRITISH-FORTMOSE`。**行动主体**：James Oglethorpe、英殖民军、被迫撤离的Fort Mose自由黑人。**位置**：Fort Mose St Augustine region。
1740年5月Oglethorpe围攻St Augustine，英国部队夺取Fort Mose迫使当地自由黑人迁入城中；随后当地黑人民兵夺回，非整座佛罗里达英占。

**来源**：`V314`, `V315`, `V316`。**位置精度**：no_verified_coordinate。

### 1740-06-26｜Francisco Menéndez率自由黑人民兵与盟军收复Fort Mose

**事件ID**：`E18A3-1740-FORTMOSE-RETAKE`。**行动主体**：Francisco Menéndez、自由黑人团、Spanish troops、Native allies。**位置**：Fort Mose near St Augustine Florida。
地方Fort Mose历史学会给出1740-06-26夜袭日期，美国NPS确认战役及反攻，具体伤亡/团人数有不同统计。

**来源**：`V317`, `V314`, `V316`。**位置精度**：no_verified_coordinate。

### 1740-07-20｜英国Georgia总督放弃围攻St Augustine

**事件ID**：`E18A3-1740-ST-AUGUSTINE-LIFT`。**行动主体**：James Oglethorpe、British colonial militia and Royal Navy。**位置**：Castillo de San Marcos, St Augustine reference only。
NPS原战史记英军1740-07-20因补给被突破与舰队撤走而解除围城；不能把该年涂成英方长期控制St Augustine。

**来源**：`V315`, `V314`。**位置精度**：modern_official_site_representative_not_historical_GPS。

### 1751-01-01｜Georgia结束临时奴役禁令并允许种植园进口被奴役非洲人

**事件ID**：`E18A3-1751-GEORGIA-SLAVERY-LEGAL`。**行动主体**：Georgia Trustees、种植园主、英国议会。**位置**：Georgia colony (law)。
学术百科确认托管人要求1751-01-01为奴役合法化施行起点；应追索该年的立法原件及实际首批输入账簿。

**来源**：`V311`, `V310`。**位置精度**：no_verified_coordinate。

### 1763｜佛罗里达转交英国后Fort Mose社区随西班牙军民撤往古巴

**事件ID**：`E18A3-1763-FORTMOSE-LEAVE`。**行动主体**：Fort Mose自由黑人居民、西班牙军政、英国占领当局。**位置**：Fort Mose to Havana (no plotted sea route)。
1763条约将佛罗里达转交英国，许多黑人自由居民选择随西班牙军队撤往古巴，不当作英国军队主动解放当地。

**来源**：`V316`, `V314`。**位置精度**：no_verified_coordinate。

## 四、地名、控制变化与GIS

Savannah/Yamacraw Bluff、Fort Mose、西属St Augustine均有现代地名；本轮只有Castillo de San Marcos官方GPS可作为附近围城参照，不代替Fort Mose或18世纪围城线。

## 五、行为主体和人物

Tomochichi、Senauki、Mary Musgrove、James Oglethorpe、Georgia Trustees、Francisco Menéndez与自解放黑人、Spanish军队、原住民盟军。

## 六、受影响群体

从英属卡罗来纳逃往佛罗里达的非洲裔在西班牙Fort Mose建立自由居民共同体，1740英军袭击迫使临时撤离。

## 七、反抗与政治主张

自由黑人民兵在Menéndez带领下1740-06-26与西班牙及原住民盟军收复被英军占据的Fort Mose，体现反抗者组织能力与政治诉求。

## 八、经济与统计后果

Georgia对非洲奴役的1735禁令和1751许可以及英西对奴役劳动力的争夺应独立说明；暂无合法输入首年度逐港统计。

## 九、长期影响、史料冲突与下一步

1763英占佛罗里达推动Fort Mose居民随西班牙撤离至古巴；英占一段时间不等于英国统治该自由社区整个旧史。

### 原档争议与研究门禁

GHS关于1733年协定的日期有5月20与5月21不同记载，故本包只记月；1763撤离航线不画直线；1715 Yamasee战争与1733移民关系需要进一步族群史料。

### 来源入口（阅读层级如登记）

- **V307** [Tomochichi and Georgia first years timeline](https://www.georgiahistory.com/resource/tomochichi/timeline/) — historical_society_chronology
- **V308** [Tomochichi biography](https://www.georgiahistory.com/resource/tomochichi/brief-biography/) — historical_society_biography
- **V309** [Tomochichi travels to Great Britain](https://www.georgiahistory.com/resource/tomochichi/travels-to-great-britain/) — institutional_history
- **V310** [Trustee Georgia, 1732–1752](https://www.georgiaencyclopedia.org/articles/history-archaeology/trustee-georgia-1732-1752/) — scholarly_encyclopedia
- **V311** [Slavery in Colonial Georgia](https://www.georgiaencyclopedia.org/articles/history-archaeology/slavery-in-colonial-georgia/) — scholarly_encyclopedia
- **V312** [Establishing Georgia Colony 1732 to 1750](https://www.loc.gov/classroom-materials/united-states-history-primary-source-timeline/colonial-settlement-1600-1763/georgia-colony-1732-1750/) — official_primary_source_guide
- **V313** [History of Fort Mose](https://www.floridastateparks.org/learn/history-fort-mose) — state_historic_site_summary
- **V314** [Fort Mose](https://www.nps.gov/foma/learn/historyculture/fort-mose.htm) — official_site_history
- **V315** [1740 Siege of St Augustine](https://home.nps.gov/foma/learn/historyculture/1740-siege.htm) — official_site_military_history
- **V316** [African Americans in St Augustine 1565–1821](https://www.nps.gov/casa/learn/historyculture/african-americans-in-st-augustine-1565-1821.htm) — official_site_history
- **V317** [The Battle of Bloody Mose 1740](https://fortmose.org/battle-of-bloody-mose/) — community_historical_society_history
- **V346** [Tomochichi grave historical marker](https://dlg.usg.edu/record/dlg_ghm_tomochichis-grave) — official_collection_historical_marker_coordinates

**制图总则**：现代官方遗址Point不代表历史控制面；历史线和海上路线未经过GIS审核，不绘Polygon或LineString。
