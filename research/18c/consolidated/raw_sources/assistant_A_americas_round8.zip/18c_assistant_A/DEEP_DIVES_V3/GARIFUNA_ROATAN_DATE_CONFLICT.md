# Garifuna被迫迁往Roatán：1797年4月11日与12日的冲突

既存`E18A-1797-A16-01`已从日级改为**1797-04**月级。

- 学术专书Christopher Taylor《The Black Carib Wars》chapter 8, Oxford Academic 公开摘要使用**11 April 1797**和2,026名抵岸者，另称其中664名男性、1,362名女性与儿童。网页章节正文限制访问。https://doi.org/10.14325/mississippi/9781617033100.003.0009
- Garifuna Nation族群历史页写**12 April 1797**、约2,500名抵达；社区观点须保留。https://www.garifunanation.org/history/
- 其他二次研究反复引用Nancie L. Gonzalez分阶段总数：Baliceaux被扣押、从圣文森特登船、Roatán靠岸、转往Trujillo是四种不同分母；本批不把约2500与2026、2248等混为一个精确总数。

**后续核证目标**：1797年押送舰船日志与海军航海日期格式、岸上登陆记录、英西文件是否采用不同历法和起始时间、4月11日抛锚与4月12日实际登陆是否可分。

**制图语义**：圣文森特—Baliceaux—Roatán地点间的历史关联有证，但未证逐段航迹时只登记文字顺序，严禁画直线航线；坐标仍null。
