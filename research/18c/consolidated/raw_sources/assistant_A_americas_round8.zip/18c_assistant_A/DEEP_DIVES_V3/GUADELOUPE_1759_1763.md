# 1759—1763英国占领瓜德罗普：双投降协议、奴役经济、和约归还

**本地候审研究**；A19与跨世纪E6-T07-LEEWARD。

## 背景与决策
七年战争中英国海军和陆军联合攻打法属瓜德罗普。英将John Barrington对沿海种植园进行袭击，企图迫使法国殖民当局和种植园主投降。

## 行动及日期
- **1759年5月1日**：密歇根大学Clements Library展出两份分别由法国总督、殖民居民代表签署的投降条款馆藏索引，不能混成一份协议。
- **1759—1763年**：美国国会图书馆编年确认短期英国占领。种植园的被奴役劳动依旧持续，英国商人跨洋供应奴役者有商业关系，但本档未核完整航次与具体总数。
- **1763年2月10日**：《巴黎和约》第八条规定英国将瓜德罗普、Marie-Galante、La Désirade、马提尼克等归还法国，给英商以有限期整理债务地产；法定归还与军队实际离岛需分开。

## 地点与人物
瓜德罗普、Fort Royal、Basse-Terre；英军John Barrington、法国总督与庄园主、从事强迫种植园劳动的被奴役非洲人。未加入古代边界或测量错误的GPS。

## 受害者、抵抗、经济后果
奴役劳动者在英军受降协定及殖民统治下继续处于强制经济系统。岛屿生产扩大等研究结论尚待在奴役运输账、庄园收入与海关账交叉确认，暂不填未经验证的运输量或利润。

## 长期结果
1759年短时英国殖民占领须在1763和约阶段终止，不得简单沿用到1794年第二次短时夺取，亦不得根据岛屿轮廓计算1759确证实际占领平方公里。

## 史料
- Clements原始投降协议目录：https://clements.umich.edu/exhibit/1759-britains-year-of-victories/case-13/
- 美国国会图书馆历史编年：https://guides.loc.gov/francophone-caribbean-collections-library-of-congress/guadeloupe
- 皇家格林尼治博物馆1759征服纪念币：https://www.rmg.co.uk/collections/objects/rmgc-object-38744
- 1763条约第八条全文：https://www.battlefields.org/learn/primary-sources/treaty-paris-1763
