# 1774邓莫尔战争：弗吉尼亚皇家殖民地、肖尼政治与边界强制外交

**状态**：研究候审，未刊发；这些事件ID均在累计事件数据库中，引用本文不得额外计数。
**旧专题关联**：E18-C11, E18-C17

## 一、背景

1768条约涉及被不同民族争执的俄亥俄南岸猎地。殖民移民、炒地商人与皇家殖民地权声索产生军事冲突。

## 二、决策与殖民机制

英王任命的弗吉尼亚总督Lord Dunmore调动殖民民兵推进1774年战争。不能将其简化为英国伦敦直属常备军全面征服。

## 三、实际行动：逐件候审事件

### 1774-05｜弗吉尼亚皇家总督Dunmore组织殖民民兵对肖尼与明戈发动战争

**事件ID**：`E18A3-DUNMORE-MAY1774`。**行动主体**：Lord Dunmore、Virginia militia、Shawnee及Mingo。**位置**：Ohio Country (regional conflict)。
殖民地边界主张及移民侵入引发军事冲突，英王皇家总督指挥的殖民军与Ohio Country民族作战，战争1774年5至10月。

**来源**：`V304`, `V305`。**位置精度**：no_verified_coordinate。

### 1774-10-10｜Virginia殖民民兵与Cornstalk率领的肖尼军队在Point Pleasant交战

**事件ID**：`E18A3-DUNMORE-POINT-PLEASANT`。**行动主体**：Andrew Lewis、Hokoleskwa (Cornstalk)、Virginia militia、Shawnee联盟。**位置**：Point Pleasant Ohio/Kanawha confluence。
1774-10-10俄亥俄与大卡纳瓦河汇合处大战；大学史编记各约800的估计战力，不作可精确测绘战线与确定阵亡人数。

**来源**：`V304`, `V306`。**位置精度**：no_verified_coordinate。

### 1774-10-19｜Dunmore总督在Camp Charlotte迫使肖尼承认有争议的俄亥俄边界

**事件ID**：`E18A3-DUNMORE-CAMPCHARLOTTE`。**行动主体**：Lord Dunmore、Hokoleskwa、Shawnee及Delaware外交代表。**位置**：Camp Charlotte Scioto River Ohio。
1774-10-19在Camp Charlotte议和，英属弗吉尼亚殖民地要求承认俄亥俄河地界；声索/外交不是肖尼政治实体完全灭失。

**来源**：`V304`, `V305`, `V306`。**位置精度**：no_verified_coordinate。

## 四、地名、控制变化与GIS

俄亥俄与大卡纳瓦河汇流处Point Pleasant为具名战斗点，Camp Charlotte在俄亥俄Scioto河地区，均不凭地名推断当日战线面积。

## 五、行为主体和人物

Andrew Lewis、Lord Dunmore、Shawnee首领Hokoleskwa(Cornstalk)、Mingo及其他俄亥俄政治主体。

## 六、受影响群体

英国殖民地定居扩张给Shawnee及Mingo土地和贸易网络造成压力；战斗损失不同消息源有别，留空确数。

## 七、反抗与政治主张

Cornstalk领导军队10月10日交战、在不利处境下参与10月19日条约议价；Logan及其他领袖并非完全统一诉求。

## 八、经济与统计后果

条约以俄亥俄河为暂时殖民土地界限，但没有可核英方实际夺地面积或地产总收益。

## 九、长期影响、史料冲突与下一步

与美独立战争前夕的英国王室殖民治理相接，1774冲突是独立的一段北美土地战争，不能因1775革命开始而省略。

### 原档争议与研究门禁

Library of Virginia公开的1774单页原印说明需要逐卷对照伦敦Public Record Office原信；战争总伤亡/原住民土地让与详细边界均未审。

### 来源入口（阅读层级如登记）

- **V304** [Lord Dunmore’s War](https://encyclopediavirginia.org/entries/lord-dunmores-war/) — academic_historical_synthesis_full_text
- **V305** [Express from Lord Dunmore at Camp Charlotte 1774.031](https://www.lva.virginia.gov/collections/virginia-print/imprints/1774.031) — primary_broadside_catalogue_with_context_only
- **V306** [Treaty of Camp Charlotte](https://www.wvencyclopedia.org/entries/732) — regional_scholarly_interpretation

**制图总则**：现代官方遗址Point不代表历史控制面；历史线和海上路线未经过GIS审核，不绘Polygon或LineString。
