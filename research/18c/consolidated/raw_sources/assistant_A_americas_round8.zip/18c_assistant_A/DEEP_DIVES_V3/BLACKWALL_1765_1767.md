# 1765—1767年牙买加Blackwall起义与殖民司法、赔偿法规

**性质：候审研究，不是正式地图事件。** 对应A06/A07；新增E18-A23仅为建议专题。

## 背景
英国殖民牙买加的糖业种植园由强迫劳动维持。1760年Tacky起义镇压后，St Mary地区Coromantee及其他非洲裔被奴役者继续组织抵抗；不能把1765起义合并为1760战争。

## 决策与实际行动
牙买加政府史称1760年Tacky一方曾夺取Fort Haldane军备；1765年11月Blackwall率反抗者在St Mary的Whitehall庄园发动起义。牙买加国家图书馆编年只证11月，早期叙述称23日，日级日期待原档；当代法律文书确认了Whitehall起义而以白人殖民者的利益为叙述出发点。

## 司法与立法
1766年8月6日殖民议员Edward Long提交审查1765起义的报告，建议通过关税阻止来自Gold Coast某些非洲人群的强制输入，但提案未通过。1767年12月21日殖民议会通过特别法释放York与Cuffee，条款规定向原奴隶主（或其遗产）分别支付**140英镑**与**80英镑**补偿。这是**法定授权**，不是已核实际拨款。

## 具体地点
Saint Mary Parish、Whitehall Plantation、Fort Haldane、Spanish Town（议会行政参考地）。上述事件未有测绘GPS，本包坐标一律null。

## 相关人物与政治主体
Blackwall、York、Cuffee、Edward Long、Ballard Beckford的遗产承继方、James Charles Sholto Douglas以及被奴役起义参与者。York与Cuffee的法定释放涉及其个人选择，不能简化为英殖民当局主动普遍解放。

## 受害群体与抵抗
1765被奴役的非洲裔居民及参与起义的妇女、马龙同盟者在殖民文书中可能遭匿名化；2021年Devin Leigh与Clifton E. Sorrell III学术论文专门研究这种书写失衡。

## 经济后果
确认立法付款额度140、80英镑，但缺收据与财政付款簿，不计入已获支付额。提议限制贩运非洲人的加税议案**未通过**。

## 长期影响与未解决证据
从Tacky的1760战争到1765另起起义以及1766—67殖民政府处理，构成武装反抗—恐慌—制法的跨年进程。下一步核1765年殖民议会Journal、Whitehall庄园账及受害人证词。

## 主要来源
- UNB原印本转录：https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1767
- Cambridge/Oxford学术研究：https://academic.oup.com/histres/article/97/278/573/7762616
- 美国国会图书馆学术目录：https://www.loc.gov/item/hlas-bi2023000044/
- 牙买加政府：https://jamaica55.gov.jm/st-mary/st-mary-history/
- 牙买加国家图书馆编年：https://nlj.gov.jm/history-notes/Chronology%20of%20Resistance%20in%20the%20British%20West%20Indies.pdf（当前仅查索引摘要）
