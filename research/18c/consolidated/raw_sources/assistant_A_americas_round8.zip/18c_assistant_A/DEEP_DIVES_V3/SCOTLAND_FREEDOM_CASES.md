# 1756—1778 Scottish freedom cases：英美殖民人身财产法律的地域边界

**状态**：研究候审，未刊发；这些事件ID均在累计事件数据库中，引用本文不得额外计数。
**旧专题关联**：E18-A08

## 一、背景

英国美洲被奴役的人有时被奴隶主带至苏格兰，殖民地法下的永久奴役身份在苏格兰遭遇不同司法体系。

## 二、决策与殖民机制

奴隶主试图继续主张对受奴役人口劳役或遣返的控制；被拘禁者采用逃离、呈请与诉讼寻求法律地位。

## 三、实际行动：逐件候审事件

### 1756-04-21｜James Montgomery逃出计划强制遣返弗吉尼亚的船只

**事件ID**：`E18A3-MONTGOMERY-ESCAPE-1756`。**行动主体**：James Montgomery、苏格兰奴隶主Robert Sheddan。**位置**：Port Glasgow Scotland。
苏格兰国家档案馆记1756-04-21 Montgomery从Port Glasgow船逃离，后被拘爱丁堡；他的案件未得到最终法庭判决，不能和Knight定案混淆。

**来源**：`V335`, `V333`。**位置精度**：no_verified_coordinate。

### 1769｜David Spens在苏格兰挑战被拘押奴役身份

**事件ID**：`E18A3-SPENS-LAWSUIT-1769`。**行动主体**：David Spens、David Dalrymple。**位置**：Fife/Edinburgh Scotland。
苏格兰国家档案馆记1769年Spens诉讼，因奴隶主身故而获释放，缺乏同Court of Session的完整终审裁决。

**来源**：`V333`。**位置精度**：no_verified_coordinate。

### 1774-05-20｜Joseph Knight在珀斯地方法庭争取脱离终身服役

**事件ID**：`E18A3-KNIGHT-SHERIFF-1774`。**行动主体**：Joseph Knight、John Wedderburn、珀斯郡法院。**位置**：Perth Scotland。
国家档案馆提供1774-05-20初审法庭材料摘录及诉讼脉络，先后经历地方法官和上诉法院，不能当终审生效日。

**来源**：`V333`, `V336`。**位置精度**：no_verified_coordinate。

### 1778-01-15｜苏格兰最高民事法院裁定Joseph Knight不受永久奴役

**事件ID**：`E18A3-KNIGHT-JUDGMENT-1778`。**行动主体**：Joseph Knight、John Wedderburn、苏格兰Court of Session。**位置**：Edinburgh Parliament House Scotland。
苏格兰法院记1778-01-15法庭以10比4支持Knight，殖民牙买加的奴役法不能在苏格兰获得持续奴役效力；与英格兰Somerset案分属不同司法区。

**来源**：`V333`, `V334`, `V336`。**位置精度**：no_verified_coordinate。

## 四、地名、控制变化与GIS

Port Glasgow、Perth、Edinburgh的各案法庭地名可核，精确庭室与拘押地GPS需源证；英国不同法域切忌混一。

## 五、行为主体和人物

James Montgomery（此前名字Shanker）、David Spens、Joseph Knight、Robert Sheddan、David Dalrymple、John Wedderburn及苏格兰法院。

## 六、受影响群体

苏格兰法庭个案不能证明牙买加/北美种植园已废奴；此处特定诉讼人与受影响的在苏格兰人身权独立审。

## 七、反抗与政治主张

Montgomery1756-04-21从遣返船逃走，Spens诉讼后获释放，Knight1774诉讼持续至1778年胜诉；他们是主动法律与生活决策者。

## 八、经济与统计后果

苏格兰档案中可查奴隶主对未来劳力和转卖利润期待，真实售价及错失利润需查合同不能虚造。

## 九、长期影响、史料冲突与下一步

1778-01-15最高法院Knight案裁定，不承认牙买加殖民主张可在苏格兰强制永久服役；这是英属帝国内司法地理差异的重要案例。

### 原档争议与研究门禁

1756 Montgomery案因当事人死于Tolbooth未判；1769 Spens因奴隶主死亡获释放，只有Knight为终审判例。不能把三者均记司法胜诉。

### 来源入口（阅读层级如登记）

- **V333** [The Joseph Knight case](https://www.nrscotland.gov.uk/learning-and-events/slavery-and-scotland/the-joseph-knight-case/) — official_archive_transcript_extract_and_case_history
- **V334** [Plaque marks historic slavery case at Court of Session](https://judiciary.scot/home/media-information/media-hub-news/2022/12/06/plaque-marks-historic-slavery-case-at-court-of-session) — official_judiciary_history
- **V335** [The James Montgomery slavery case 1756](https://www.nrscotland.gov.uk/learning-and-events/slavery-and-scotland/the-james-montgomery-slavery-case-1756/) — official_archive_case_history
- **V336** [Knight v Wedderburn catalogue CS235/K/2/2](https://catalogue.nrscotland.gov.uk/nrsonlinecatalogue/details.aspx?df=&di=y&dt=&k=&ko=a&r=CS235%2Fk%2F2%2F2&reference=CS235%2FK%2F2%2F2&ro=s&st=1&tc=y&tl=n&tn=n&tp=n) — primary_archive_catalogue_not_full_papers

**制图总则**：现代官方遗址Point不代表历史控制面；历史线和海上路线未经过GIS审核，不绘Polygon或LineString。
