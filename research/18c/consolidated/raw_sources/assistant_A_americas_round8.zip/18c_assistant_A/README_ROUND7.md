# 爱英TV 18世纪第一调查员｜第七轮扩大调查包

**用途**：只供主编离线审核研究，未发到网页、GitHub和正式Atlas。

事件候选累计487条；来源累计389条（去重网址359）；49份原专题保留；本轮15篇新长文；25个现代遗址点。

## 目录导读

- `EVENT_CANDIDATES.json/.csv`：逐行动候选与证据门禁，其他年份不应随意补行。
- `SOURCE_REGISTRY.json`、`SOURCE_AUDIT_V7.json`：文献和实际阅读范围，重复链接审计。
- `TOPIC_DOSSIERS/`：全部49个A/C原始专题及本轮内容续写。
- `DEEP_DIVES_V7/`：13篇跨地区重大影响个案；直接按题名阅读。
- `PROPOSED_ADDITIONAL_TOPICS_V7.json`：只提出14个待主编批准的新母题，不动项目既有编号。
- `CLAIM_SOURCE_MATRIX_V7.csv`：第七轮逐事件对照来源的审查表。
- `MAP_PLACE_RESEARCH_V7.csv`、`MAP_CANDIDATES.geojson`：历史地名与目前已核官方现代遗址点，无未经证实的多边形。
- `GEO_AND_CHRONOLOGY_AUDIT_V7.md`及`GAPS_AND_CONFLICTS.md`：日期争议、人口数字和历史实控的不确定性。
- `PROGRESS.md`及`REFERENCE/VALIDATION_V7.json`：状态和检验记录。

## 统计规则

上述来源是数据库记录数量，并非独立学者互证篇数；去重网址只用于查重，不自动作为第二个独立史料。多个记录针对同一大事件的不同日/不同地点/不同主体行动单列，禁止把事件条目数说成死亡人数。

这份离线压缩包仅供历史研究候审（research_only）；GitHub未修改。
