# 1783—1793年豪德诺索尼六族与Grand River：Crawford、Haldimand与Simcoe土地文书

**专题阶段**：第五轮独立候审，未在正式地图发布。
**涉及18世纪母题**：`E18-C13`, `E18-C17`。
**新核事件**：3项；事实日期以事件JSON为准。
**阅读等级**：既有网站、档案转录、学术摘要和原档目录的差异逐项登记，绝不代称已阅纸本。

一、背景
美国独立战争对豪德诺索尼政治联盟造成分裂和家园破坏。与英国结盟并被逐出纽约地区的部分家庭选择迁到今安大略的Grand River，原住民族政治关系包含Mississauga等更早的土地权利人。

二、决策与制度
1783年10月Crawford代理王室与部分沿岸原住民族完成购地事务；1784年10月25日Haldimand公告为六族等效忠王室家庭安排Grand River两侧各六英里地权，1793年Simcoe专利缩窄/重新界定范围。

三、实际行动与日期
条约与专利不是普遍事实上的农场交割、地权注销或英国占领。要把“Mississauga卖地给王室”“豪德诺索尼获王室安置保证”“殖民管理者再设界”拆为不同时间及行动主体。

### 可追溯事件清单
| 日期 | 事件ID | 行动 | 来源ID |
|---|---|---|---|
| 1783-10 | `E18A5-CROWN-1783-CRAWFORD` | Crawford在安大略湖沿岸与部分原住民族谈判王室购买土地供效忠派安置 | V5018, V5044 |
| 1784-10-25 | `E18A5-CROWN-1784-HALDIMAND` | Haldimand公告安排效忠王室的豪德诺索尼六族在Grand River安置 | V5017, V5018, V5019 |
| 1793 | `E18A5-CROWN-1793-SIMCOE` | Simcoe土地专利对1784豪德诺索尼六族大河安置范围作出不同界定 | V5017, V5018 |

四、具体地点和地图证据
Grand River是河流流域历史地名；“两侧各六英里”仅能作纸面主张的宽度条款，不准GIS自动缓冲成实测主权面。

五、人物和行动主体
Joseph Brant及豪德诺索尼六族各政治社群、Mississauga产权持有者、Frederick Haldimand、John Graves Simcoe、王室土地部门。

六、受影响群体
从各事件`actor_entities_text`及当地政体辨识受影响的人，明确区分被奴役、原住民族、自愿盟友、战争俘虏、殖民民兵及独立民众。缺少独立人口核证时按群体名记录，不凭空分配具体人头。

七、反抗与政治主张
六族对于独立国家地权及英国政府后续财产资产处理持续提出索赔。两个不同王室文件范围矛盾并不等于其权利自动丧失。

八、经济后果和数字口径
可追查公款、地租、地产托管与后世土地出售账；当前没有经过地籍配准的1784年真实实控面积，不计算现代六英里缓冲区面积。

九、长期影响与17世纪续接
加拿大安大略省仍将此列为涉及补偿和历史账款的土地索赔，说明1784承诺的后果长期持续。
17世纪祖先专题ID见EVENT_CANDIDATES.json对应字段，不以1699示意面直接作为18世纪实控。

十、冲突和待查原档
逐份核Crawford deed、1784文书原件、1793专利及1821 Ridout调查图；对Mississauga与Haudenosaunee口述历史作独立对照。

### 本批核心来源：只按实际阅读层级引用
- `V5018` **Ontario Government**，[Map of Ontario treaties and reserves: Six Nations Crown Grant](https://www.ontario.ca/page/map-ontario-treaties-and-reserves)。阅读级别：`government_treaty_context_read`；具体支持：1783 Crawford purchases, 1784 Crown grant, 1793 Simcoe Patent; modern reference maps not 1784 surveyed actual control.
- `V5044` **Ontario Government**，[Map of Ontario treaties and reserves – Crawford purchases](https://www.ontario.ca/page/map-ontario-treaties-and-reserves)。阅读级别：`government_treaty_history_read`；具体支持：Oct 1783 Crown purchases from some Indigenous parties along Lake Ontario/St Lawrence for Loyalists; exact tract survey requires original deed.
- `V5017` **Ontario Government**，[Six Nations of the Grand River – Crown/Haldimand historical claims](https://www.ontario.ca/page/six-nations-grand-river)。阅读级别：`government_claim_history_read`；具体支持：1784 Haldimand Proclamation versus 1793 Simcoe Patent, narrower limits and ongoing property/accounting claims.
- `V5019` **Ontario Government**，[Indigenous culture and history along TransCanada Trail](https://www.ontario.ca/page/indigenous-culture-and-history-along-transcanada-trail)。阅读级别：`government_heritage_history_read`；具体支持：Haudenosaunee refuge after US independence; Haldimand Crown proclamation and Six Nations agency in Grand River.

**地图门禁**：本轮新事件均没有凭空增加WGS84坐标、沿海航迹线或疆域面。论文解读、档案目录和地理点都还须主编核对后方可用于正式发布。
