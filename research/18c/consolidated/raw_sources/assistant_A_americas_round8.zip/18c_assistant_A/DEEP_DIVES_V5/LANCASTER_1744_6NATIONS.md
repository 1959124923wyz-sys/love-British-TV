# 1744年兰开斯特条约：六族代表的原始发言与英属殖民地土地声索

**专题阶段**：第五轮独立候审，未在正式地图发布。
**涉及18世纪母题**：`E18-C13`, `E18-C25`。
**新核事件**：4项；事实日期以事件JSON为准。
**阅读等级**：既有网站、档案转录、学术摘要和原档目录的差异逐项登记，绝不代称已阅纸本。

一、背景
1681年宾夕法尼亚特许与早期莱纳佩地契开启了殖民地土地市场，但1744年弗吉尼亚、马里兰和宾州的土地纠纷无法直接由国王特许解决。六族使节在长达数日的会议中提出独立法理与外交观点。

二、决策与制度
Pennsylvania副总督George Thomas接待，Virginia与Maryland派委员参与。1744年6月22日开场，6月25日分别讨论马里兰土地争端和盟约，6月30日发言人Gachradodow反驳英国法权天经地义的预设。

三、实际行动与日期
会议逐日发言和交换wampum带具有政治意义。英国殖民地代表主张通过外交认可并平息争议，但签订欧洲法式地产文件与各原住民族实际拥有、使用、出售土地必须逐宗核查。

### 可追溯事件清单
| 日期 | 事件ID | 行动 | 来源ID |
|---|---|---|---|
| 1744-06-22 | `E18A5-LANCASTER-JUN22` | 兰开斯特条约会议开场：宾州、弗吉尼亚及马里兰代表与六族使节会面 | V5001, V5002, V5037 |
| 1744-06-25 | `E18A5-LANCASTER-JUN25` | Canassatego在兰开斯特质疑英属殖民地方与六族土地权利分歧 | V5001, V5002 |
| 1744-06-30 | `E18A5-LANCASTER-JUN30` | 兰开斯特六族发言人Gachradodow质疑殖民正义标准 | V5001, V5002 |
| 1744-07-04 | `E18A5-LANCASTER-JUL4` | Canassatego在兰开斯特会议继续回应宾州殖民官员 | V5001, V5002 |

四、具体地点和地图证据
具名Lancaster Court House可作为历史会议地名。缺官方可复核GPS，本轮保持坐标null，禁止照现代州界或后世县界绘制1744年英方实占多边形。

五、人物和行动主体
六族政治家Canassatego、Gachradodow及出席各国使节，Pennsylvania官员George Thomas、Virginia和Maryland委员、译员Conrad Weiser。Lenape等非本次主要签约方仍有不可忽视的土地利益。

六、受影响群体
从各事件`actor_entities_text`及当地政体辨识受影响的人，明确区分被奴役、原住民族、自愿盟友、战争俘虏、殖民民兵及独立民众。缺少独立人口核证时按群体名记录，不凭空分配具体人头。

七、反抗与政治主张
六族发言明确反驳将英王征服与殖民法律视为唯一正义。条约文本含原住民公开政治陈述，应按族群、发言者和外交阶段保存，不能删减为仅仅“英人购买土地”。

八、经济后果和数字口径
贸易礼物和土地争议是会议议程，但礼物具体金额不自动作为地价，更不能用现代Shenandoah Valley面积推算“1744年实际被英国吞并的面积”。

九、长期影响与17世纪续接
1744年印本以Philadelphia印刷传播，后来殖民地关于俄亥俄与蓝岭以西的地产扩张把这一会议作为声称的法源之一；原住民族并未统一交出整个北美中部。
17世纪祖先专题ID见EVENT_CANDIDATES.json对应字段，不以1699示意面直接作为18世纪实控。

十、冲突和待查原档
逐字核对6月26和7月3、4原文、各族授权关系与独立大学史料；对照1754/1768/1770实际殖民调查图。

### 本批核心来源：只按实际阅读层级引用
- `V5001` **University of Nebraska–Lincoln, Center for Digital Research in the Humanities**，[A Treaty Held at Lancaster, 1744: Benjamin Franklin original print edited transcript](https://treatiesportal.unl.edu/earlytreaties/treaty.00003.html)。阅读级别：`historical_primary_1744_print_transcription_read`；具体支持：Court-house sessions dated June 22, 25, 26, 28, 30 and July 3-4; direct speeches of Six Nations deputies and colonial commissioners.
- `V5002` **Library of Congress**，[A Treaty, held at Lancaster ... with the Indians of the Six Nations, 1744](https://www.loc.gov/item/22007828/)。阅读级别：`institutional_original_1744_print_catalogue_read`；具体支持：Contemporary pamphlet bibliographic record (53 scanned images); confirms printer, parties, year; not a separate eyewitness.
- `V5037` **U.S. National Archives**，[American Indian treaties ratified 1722-1869 catalog links](https://www.archives.gov/research/native-americans/treaties/catalog-links)。阅读级别：`federal_archive_finding_aid_read`；具体支持：Treaty list 1744 Lancaster NAID77165997 and 1722/1726 treaties; not personally inspected original scanned treaty images.

**地图门禁**：本轮新事件均没有凭空增加WGS84坐标、沿海航迹线或疆域面。论文解读、档案目录和地理点都还须主编核对后方可用于正式发布。
