# 1788—1792年英国议会对奴役贸易的调查、船运规制与未落实的废奴决议

**专题阶段**：第五轮独立候审，未在正式地图发布。
**涉及18世纪母题**：`E18-A10`, `E18-A20`。
**新核事件**：6项；事实日期以事件JSON为准。
**阅读等级**：既有网站、档案转录、学术摘要和原档目录的差异逐项登记，绝不代称已阅纸本。

一、背景
十八世纪末废奴者、非洲裔作者与宗教团体通过请愿、证词和演说挑战英国奴役贸易；种植园与航运资本也积极维持该贸易。1787年正式反贩奴组织化已在原A10专题登记。

二、决策与制度
首相Pitt在1788年2月委托枢密院调查，5月5日提出下议院下届讨论动议；Dolben于5月21日提出运奴船密度规制法案。1789年4月报告递交议会，5月Wilberforce开展演说。

三、实际行动与日期
1791年废除贸易议案失败（旧事件已收）；1792年5月1日下议院转而支持逐步终止贸易。1804年原始Hansard回溯指出该决议并未成为有约束力的禁贸法。

### 可追溯事件清单
| 日期 | 事件ID | 行动 | 来源ID |
|---|---|---|---|
| 1788-02 | `E18A5-ABOL-1788-FEB-PRIVY` | Pitt政府委托枢密院贸易委员会调查奴役贸易 | V5032, V5033 |
| 1788-05-05 | `E18A5-ABOL-1788-MAY5-PITT` | Pitt在下议院提出下会期讨论奴役贸易的动议 | V5032, V5033 |
| 1788-05-21 | `E18A5-ABOL-1788-MAY21-DOLBEN` | Dolben提出限制奴役船载运人数的议案 | V5032, V5034 |
| 1789-04 | `E18A5-ABOL-1789-APRIL-REPORT` | 英国枢密院奴役贸易调查报告提交下议院 | V5033, V5032 |
| 1789-05-12 | `E18A5-ABOL-1789-MAY12-WILBERFORCE` | Wilberforce在下议院提出正式废奴论述与议会辩论 | V5033, V5034 |
| 1792-05-01 | `E18A5-ABOL-1792-MAY1-GRADUAL` | 英国下议院通过循序终止奴役贸易的动议但未形成当年禁贸法律 | V5035, V5034 |

四、具体地点和地图证据
伦敦Westminster为决策发生地，与被贸易人口从非洲到美洲的航线、实际暴力地点是不同空间对象。

五、人物和行动主体
William Pitt、William Wilberforce、William Dolben、Clarkson、Cugoano与Olaudah Equiano等非洲裔证言者，航运商与种植园代表及不同阶层请愿者。

六、受影响群体
从各事件`actor_entities_text`及当地政体辨识受影响的人，明确区分被奴役、原住民族、自愿盟友、战争俘虏、殖民民兵及独立民众。缺少独立人口核证时按群体名记录，不凭空分配具体人头。

七、反抗与政治主张
被奴役者持续自行反抗、逃离、集体协作。立法之争与被迫运输者争取自由同时发生，不能用议会动议把奴役者的主动性删除。

八、经济后果和数字口径
1788限制船舱密度是贸易规制，不是禁止船舶采购、装卸、经营利润归零；1792的“渐进决议”也不能把真实航次变成零。

九、长期影响与17世纪续接
1807禁贸法在另一个世纪通过。18世纪地图应表现1788、1789、1791、1792政策与贸易持续并行的矛盾，而非在1792年直接停止奴役航行。
17世纪祖先专题ID见EVENT_CANDIDATES.json对应字段，不以1699示意面直接作为18世纪实控。

十、冲突和待查原档
查1788 Act 28 Geo. III ch.54正式条款及官方日级御准日期、1789下议院会议纪要、1792表决文本和奴隶船名册进行事实交叉。

### 本批核心来源：只按实际阅读层级引用
- `V5032` **UK Parliament**，[First parliamentary debates on slavery trade](https://www.parliament.uk/about/living-heritage/transformingsociety/tradeindustry/slavetrade/overview/the-first-parliamentary-debates/)。阅读级别：`institutional_history_read`；具体支持：Feb 1788 Privy Council inquiry, 5 May 1788 Pitt motion, 21 May 1788 Dolben bill.
- `V5033` **UK Parliament**，[Wilberforce makes the case](https://www.parliament.uk/about/living-heritage/transformingsociety/tradeindustry/slavetrade/overview/wilberforce-makes-the-case/)。阅读级别：`institutional_history_read`；具体支持：Apr 1789 report and May 1789 parliamentary advocacy, 1791 entry to abolition society; not proof 1789 abolition.
- `V5034` **UK Parliament**，[The West Indian colonies and emancipation](https://www.parliament.uk/about/living-heritage/evolutionofparliament/legislativescrutiny/parliament-and-empire/parliament-and-the-american-colonies-before-1765/the-west-indian-colonies-and-emancipation/)。阅读级别：`institutional_history_read`；具体支持：1788 ship regulation and 1792 Commons gradual abolition preference but no abolition law until 1807.
- `V5035` **Historic Hansard, UK Parliament**，[1804 May 30 Commons: retrospective statement on 1792 gradual vote](https://hansard.parliament.uk/Commons/1804-05-30/debates/6bdbb9e5-921c-424f-b156-a432f339a591/CommonsChamber)。阅读级别：`primary_1804_debate_retrospective_read`；具体支持：1804 parliamentary speaker says May 1 1792 gradual abolition resolution failed to culminate in abolition; retrospective not contemporaneous 1792 minute.

**地图门禁**：本轮新事件均没有凭空增加WGS84坐标、沿海航迹线或疆域面。论文解读、档案目录和地理点都还须主编核对后方可用于正式发布。
