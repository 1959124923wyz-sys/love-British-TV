# 1714—1796哈德孙湾公司：York Factory据点换旗、1782火毁与1788迁址

**专题阶段**：第五轮独立候审，未在正式地图发布。
**涉及18世纪母题**：`E18-C27`。
**新核事件**：11项；事实日期以事件JSON为准。
**阅读等级**：既有网站、档案转录、学术摘要和原档目录的差异逐项登记，绝不代称已阅纸本。

一、背景
哈德孙湾公司早在1670年获王室纸面特许；但原住民族皮毛网络、海湾几个小型堡垒和不同欧洲舰队实际到访构成真实控制地理。1697—1713约克据点为法国控制，不能在1700年自动着为英国实占。

二、决策与制度
1713乌得勒支条约后公司人员直到1714年9月才实际抵达York Factory接收。1732年开始在丘吉尔河修石堡；1782法国La Pérouse舰队攻击Prince of Wales Fort和York Factory，1783HBC重新补建，1788洪水促使公司迁址。

三、实际行动与日期
Samuel Hearne在Prince of Wales Fort面对三艘法舰、39名驻站人员无战斗投降。Parks Canada 1979研究据HBC原档指约克工厂1782年8月24日投降、9月1日被法军焚毁；1783年Marten运预制房返回旧址。1788年5月7日严重洪水促使Colen另选更高地址。

### 可追溯事件清单
| 日期 | 事件ID | 行动 | 来源ID |
|---|---|---|---|
| 1714-09 | `E18A5-HBC-1714-YORK-TRANSFER` | HBC代表James Knight到达York Factory并接管法国前据点 | V5048, V5023 |
| 1732 | `E18A5-HBC-1732-PRINCE-FORT-STONE` | HBC在丘吉尔河口开始修筑Prince of Wales石砌堡垒 | V5021, V5022 |
| 1782 | `E18A5-HBC-1782-PRINCE-SURRENDER` | La Pérouse法国舰队迫使HBC Prince of Wales Fort无战斗投降 | V5021, V5022 |
| 1782 | `E18A5-HBC-1782-YORK-ATTACK` | 法国舰队攻击约克工厂商站并使公司遭受物资损毁 | V5048, V5049, V5025 |
| 1782-08-24 | `E18A5-HBC-1782-AUG24-YORK-SURRENDER` | 约克工厂主管Marten于1782年8月24日向La Pérouse舰队投降 | V5048, V5049 |
| 1782-09-01 | `E18A5-HBC-1782-SEP1-YORK-BURNING` | 法军于9月1日焚毁York Factory且HBC人员乘Severn离去 | V5048, V5049 |
| 1783 | `E18A5-HBC-1783-PRINCE-REVERT` | 法军袭击后Prince of Wales Fort归回HBC但未在原址重新驻防 | V5022, V5021 |
| 1783 | `E18A5-HBC-1783-YORK-RESTORE` | HBC将预制房屋运回York Factory重建商站 | V5048, V5049 |
| 1786 | `E18A5-HBC-1786-YORK-PLAN` | York Factory官员Joseph Colen向伦敦绘送新堡建筑图 | V5024, V5025 |
| 1788 | `E18A5-HBC-1788-YORK-III` | HBC在更高地势建设York Factory III并替代河岸旧据点 | V5049, V5025 |
| 1788-05-07 | `E18A5-HBC-1788-MAY7-FLOOD` | York Factory遭遇1788年5月7日严重洪灾、迫使重新选址 | V5048, V5049 |

四、具体地点和地图证据
使用老站历史河道位置描述，不把现代York Factory III点当1782守军GPS；旧站被河水侵蚀后的历史位置需结合不同时代测绘恢复，不能伪作现代经纬度。

五、人物和行动主体
Hudson’s Bay Company董事会与驻站管理者Samuel Hearne、Marten、Joseph Colen；法国La Pérouse海军；Cree、Dene、Inuit等既有政治商贸主体。

六、受影响群体
从各事件`actor_entities_text`及当地政体辨识受影响的人，明确区分被奴役、原住民族、自愿盟友、战争俘虏、殖民民兵及独立民众。缺少独立人口核证时按群体名记录，不凭空分配具体人头。

七、反抗与政治主张
Cree、Dene、Inuit等并非公司法权的附属土地；他们通过贸易条件、引路、粮食供应及各自外交组织经济；欧洲交战部队仅互夺具体筑防港点。

八、经济后果和数字口径
公司损失是货栈、毛皮、房屋及旧站投资；没有逐账核凭证时不捏造损失金额。1732施工与1783预制住房亦非任何国家对内陆人口的政治控制证据。

九、长期影响与17世纪续接
Parks Canada明确York Factory I (1684–1715)、II (1715–1788)受到河岸侵蚀已消失，III（1788后）是今日遗址所在地。1782战事对站址GIS要求极严格，必须区分不同岸线。
17世纪祖先专题ID见EVENT_CANDIDATES.json对应字段，不以1699示意面直接作为18世纪实控。

十、冲突和待查原档
逐页阅HBCA B.239/a/80、La Pérouse法舰日志、Parks Canada Manuscript Report 297图2–8、实际早期厂址地层和岸线变迁资料。PDF截图服务本轮返回502，当前仅读到报告索引文字。

### 本批核心来源：只按实际阅读层级引用
- `V5021` **Parks Canada**，[Prince of Wales Fort is Canada Strong](https://www.parks.canada.ca/lhn-nhs/mb/prince/culture/fort-strong)。阅读级别：`official_historic_site_interpretation_read`；具体支持：1782 French La Pérouse expedition; Samuel Hearne surrendered with 39 local men without exchange of shots.
- `V5022` **Parks Canada**，[Prince of Wales Fort, 2024 management plan](https://parks.canada.ca/lhn-nhs/mb/prince/info/gestion-management/plan-2024)。阅读级别：`official_archaeological_management_history_read`；具体支持：1782 damage, 1783 return to HBC control and inability to reoccupy same fort; Indigenous communities use landscape.
- `V5048` **Parks Canada, George Ingram (1979)**，[York Factory: A Structural History, Manuscript Report 297](https://parkscanadahistory.com/series/mrs/297.pdf)。阅读级别：`historical_research_pdf_indexed_text_screenshot_tool_failed`；具体支持：Indexed text p32: 24 August 1782 Marten surrendered York Factory to La Pérouse, 1 September 1782 burned, 1783 prefabricated house returned; 7 May 1788 flood; older 1714 possession. PDF screenshot service failed, original archival entries not personally read.
- `V5049` **Parks Canada, official federal historic designation**，[York Factory National Historic Site historic landscape and phases](https://www.pc.gc.ca/apps/dfhd/page_nhs_eng.aspx?id=158)。阅读级别：`federal_historic_designation_read`；具体支持：York Factory I 1684-1715 and II 1715-1788 eroded; III at new higher ground 1788 onward. Modern point cannot locate 1782 fort precisely.
- `V5025` **Parks Canada**，[York Factory commemorative intent](https://parks.canada.ca/lhn-nhs/mb/yorkfactory/info/commemoration)。阅读级别：`official_site_interpretation_read`；具体支持：York Factory III established after 1788; modern heritage site not same location/layout as 1782 fort.
- `V5024` **Parks Canada**，[York Factory archaeology and 1786 Colen octagon plan](https://parks.canada.ca/lhn-nhs/mb/yorkfactory/culture/archaeo)。阅读级别：`official_site_archaeology_and_historic_plan_read`；具体支持：1786 company officer plan not proof construction all finished; physical site layout differs over centuries.
- `V5023` **Parks Canada**，[York Factory human history](https://parks.canada.ca/lhn-nhs/mb/yorkfactory/culture/histoire-history)。阅读级别：`official_historic_site_history_read`；具体支持：1684 original fort; 1694-97 changes; 1713 treaty claim and HBC trading rights; location of post not entire watershed sovereignty.

**地图门禁**：本轮新事件均没有凭空增加WGS84坐标、沿海航迹线或疆域面。论文解读、档案目录和地理点都还须主编核对后方可用于正式发布。
