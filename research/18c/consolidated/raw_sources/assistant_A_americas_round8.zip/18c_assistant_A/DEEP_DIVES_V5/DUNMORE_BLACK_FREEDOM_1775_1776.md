# 1775—1776年弗吉尼亚：Dunmore公告、黑人参战、Great Bridge及诺福克大火

**专题阶段**：第五轮独立候审，未在正式地图发布。
**涉及18世纪母题**：`E18-C17`, `E18-C18`。
**新核事件**：4项；事实日期以事件JSON为准。
**阅读等级**：既有网站、档案转录、学术摘要和原档目录的差异逐项登记，绝不代称已阅纸本。

一、背景
1775年美国革命爆发后，弗吉尼亚王室总督Dunmore与殖民种植园利益集团决裂。被奴役非洲裔将战争视为争取自由和重新组织生活的机会；部分人选择加入英军，另一些人有不同策略。

二、决策与制度
1775年11月7日公告宣布戒严，对属于反英“叛乱者”并愿意拿起武器的非裔或契约劳工许诺自由；对效忠王室地主的奴役人口不作全面废奴承诺。这是战争动员条款而非帝国内全面废奴法。

三、实际行动与日期
Kemp’s Landing附近黑人自由寻求者参与战事；Colonial Williamsburg记11月15日公开宣布，部分年表把战斗写作11月17日。12月9日Great Bridge英军进攻失败，黑人Ethiopian Regiment参与。1776年1月1日英海军炮击Norfolk，英军烧码头仓储，同时反英军另烧大量城区建筑。

### 可追溯事件清单
| 日期 | 事件ID | 行动 | 来源ID |
|---|---|---|---|
| 1775-11-07 | `E18A5-DUNMORE-1775-NOV7-EDICT` | Dunmore总督颁布仅对反英奴隶主劳工附条件自由的军事公告 | V5012, V5013, V5015 |
| 1775-11-15 | `E18A5-DUNMORE-1775-NOV15-ANNOUNCE` | Dunmore在Kemp’s Landing战后公开宣传军役换自由公告 | V5013, V5014, V5041 |
| 1775-12-09 | `E18A5-DUNMORE-1775-DEC9-GREATBRIDGE` | 英军组织埃塞俄比亚军团参与Great Bridge战斗后撤退 | V5013, V5015, V5016 |
| 1776-01-01 | `E18A5-DUNMORE-1776-JAN1-NORFOLK` | 英舰炮击诺福克并发生英军与反英军队不同范围纵火 | V5015, V5013 |

四、具体地点和地图证据
公告签发在诺福克近海William船上，缺现代海上GPS，勿将诺福克城心坐标当船只精确位置；Great Bridge战斗点等官方原战场位置另找测绘证据。

五、人物和行动主体
Dunmore，英王正规军，Ethiopian Regiment中自我解放的非裔士兵，反英弗吉尼亚民兵，逃亡者家属及沿岸居民。

六、受影响群体
从各事件`actor_entities_text`及当地政体辨识受影响的人，明确区分被奴役、原住民族、自愿盟友、战争俘虏、殖民民兵及独立民众。缺少独立人口核证时按群体名记录，不凭空分配具体人头。

七、反抗与政治主张
黑人作战参与不能被简化为英国总督施舍自由；他们承担逃离、疾病、作战及今后迁徙的风险。殖民叛乱者对他们的战争行动和前奴役关系也应保留。

八、经济后果和数字口径
奴隶主的人身财产权受到逃离冲击，英军缺粮与舰船拥挤造成健康危机。现有材料无法给出所有参军黑人确切人数、疾病死亡和经济损失，置null。

九、长期影响与17世纪续接
1775公告、1779 Philipsburg声明及1783纽约撤离Book of Negroes构成不同阶段；并非全部黑人效忠派被同等条件接受或确获土地。
17世纪祖先专题ID见EVENT_CANDIDATES.json对应字段，不以1699示意面直接作为18世纪实控。

十、冲突和待查原档
需逐页比对1775年原传单、Kemp’s Landing军事报表和1776年诺福克火险/赔偿清单；11月15/17日期差异单独裁决。

### 本批核心来源：只按实际阅读层级引用
- `V5012` **Library of Congress**，[Lord Dunmore Proclamation, November 7 1775 original broadside](https://www.loc.gov/item/2020769135/)。阅读级别：`institutional_primary_broadside_catalogue_and_indexed_text_read`；具体支持：On ship William off Norfolk Nov 7 1775; offers conditional liberation to enslaved and indentured people belonging to rebels capable and willing to bear arms.
- `V5013` **Colonial Williamsburg Foundation**，[Dunmore’s Proclamation and the Fight for Freedom](https://www.colonialwilliamsburg.org/discover/moments-in-history/road-to-independence/dunmores-proclamation/)。阅读级别：`museum_interpretive_timeline_read`；具体支持：Nov 15 public announcement after Kemp’s Landing; Dec 9 Great Bridge; disease and shipboard crowding for Black refugees.
- `V5015` **Library of Virginia**，[John Murray Earl of Dunmore, biographical history](https://www.lva.virginia.gov/collections/dvb/bio/dunmore-john-murray-earl)。阅读级别：`state_library_scholarly_biography_read`；具体支持：Dec 9 1775 Great Bridge, Jan 1 1776 burning Norfolk with differentiated British and Patriot responsibility.
- `V5014` **George Washington’s Mount Vernon**，[The Ethiopian Regiment](https://www.mountvernon.org/library/digitalhistory/digital-encyclopedia/article/ethiopian-regiment)。阅读级别：`museum_scholarly_article_read`；具体支持：Nov 15 Black freedom-seekers at Kemp’s Landing; first week December regiment organized, white officers.
- `V5041` **U.S. National Park Service**，[1775 Dunmore Virginia Great Bridge overview](https://home.nps.gov/articles/warpoli.htm)。阅读级别：`federal_park_history_read`；具体支持：1775 Nov7 proclamation and Dec9 Great Bridge, estimate claims secondary; n.b. different day for Kemp’s Landing in separate accounts.
- `V5016` **U.S. National Park Service**，[Commemorating the War for Independence at Great Bridge](https://www.nps.gov/articles/000/commemorating-the-war-for-independence-at-great-bridge.htm)。阅读级别：`national_park_historical_interpretation_read`；具体支持：Ethiopian Regiment and Battle of Great Bridge Dec 1775; Black participants; no dependable regiment-total casualty data.

**地图门禁**：本轮新事件均没有凭空增加WGS84坐标、沿海航迹线或疆域面。论文解读、档案目录和地理点都还须主编核对后方可用于正式发布。
