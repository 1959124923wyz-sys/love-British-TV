# 1750年非洲贸易法、三港商人治理与1768 Black Prince水手哗变

**专题阶段**：第五轮独立候审，未在正式地图发布。
**涉及18世纪母题**：`E18-A01`, `E18-A03`, `E18-A04`, `E18-A20`。
**新核事件**：3项；事实日期以事件JSON为准。
**阅读等级**：既有网站、档案转录、学术摘要和原档目录的差异逐项登记，绝不代称已阅纸本。

一、背景
17世纪皇家非洲公司1698年丧失垄断，此后私商与公司仍参与人口贩运。18世纪英国政府及商业集团不但没有立刻终止贩奴，反而重新配置保障西非贸易据点的财政治理安排。

二、决策与制度
1750年议会《扩展和改进对非贸易法》设立Company of Merchants Trading to Africa。法律说明目的包括让殖民种植园以“合理价格”购买更多被奴役人口。三港入会注册截止6月30日、选举9名委员计划在7月10日。

三、实际行动与日期
法定40先令是单个商人入会费用，不是某批被贩卖人口的单价。仍缺原公会选举册证明各委员确实当日当选。1768年Black Prince从Bristol出航后船员反叛、杀害军官并改船名Liberty；这是船员对船主的哗变，不可拿来替代被拘禁非洲人在船上的反抗。

### 可追溯事件清单
| 日期 | 事件ID | 行动 | 来源ID |
|---|---|---|---|
| 1750-06-30 | `E18A5-RAC-1750-ADMISSION` | 1750非洲商人公司章程规定三港商人交40先令会费登记截止 | V5027, V5026 |
| 1750-07-10 | `E18A5-RAC-1750-ELECTION` | 1750非洲商人公司法规定在三港分别选出管理委员 | V5027, V5026, V5028 |
| 1768 | `E18A5-BLACKPRINCE-1768-REVOLT` | 1768布里斯托尔奴役船Black Prince水手哗变夺船并更名Liberty | V5031 |

四、具体地点和地图证据
法律涉及伦敦Guildhall、Bristol Merchants Hall、Liverpool Town Hall三座具名城市，但不为公司贸易图绘凭空跨大西洋航线或西非“英国殖民领土”多边形。

五、人物和行动主体
英国议会、非洲贸易公司、伦敦/布里斯托尔/利物浦商人、Black Prince船员及被贩卖人口、非洲海岸主权与交易主体。

六、受影响群体
从各事件`actor_entities_text`及当地政体辨识受影响的人，明确区分被奴役、原住民族、自愿盟友、战争俘虏、殖民民兵及独立民众。缺少独立人口核证时按群体名记录，不凭空分配具体人头。

七、反抗与政治主张
船员不服军官命令与非洲被奴役者抵抗属于不同历史群体，虽然处在同一船运经济结构。港口财资管理从没有合法消除遭强迫买卖者的暴力困境。

八、经济后果和数字口径
Historic England指出1750—1775年约100个奴役航次从Lancaster St George’s Quay出发，跨年规模不可当某单年。法律40先令与9名委员属制度数字，不是奴役人数或当年利润。

九、长期影响与17世纪续接
这项法律以国家机构维护西非据点，1788以后议会限制船舱装载却仍未在18世纪全面禁贸； Black Prince可作为船员劳动与奴役运输社会矛盾的独立篇章。
17世纪祖先专题ID见EVENT_CANDIDATES.json对应字段，不以1699示意面直接作为18世纪实控。

十、冲突和待查原档
查Bristol、Liverpool、London入会和公会会议簿、TNA T70转移清单、Black Prince船员法庭卷及船主账；避免把1750法定“可设公司”当具体每站实际交接。

### 本批核心来源：只按实际阅读层级引用
- `V5027` **Wikisource, scan-backed historical act**，[An act for extending and improving the trade to Africa (1750), primary legal text](https://en.wikisource.org/wiki/An_act_for_extending_and_improving_the_trade_to_Africa_(1750))。阅读级别：`historical_primary_statute_transcript_read`；具体支持：Sections II–VI company framework: 40-shilling admissions due June 30 and July 10 elections in London, Bristol, Liverpool. Exact legal reading subject to page proofing.
- `V5026` **Smithsonian NMAAHC**，[An Act for Extending and Improving the Trade to Africa, 1750, collection 2019.28.2](https://nmaahc.si.edu/object/nmaahc_2019.28.2)。阅读级别：`museum_original_1750_print_object_catalogue_read`；具体支持：Museum owns 22-page statute edition: reorganization and explicit plantation demand for enslaved people at reasonable rates.
- `V5028` **Cambridge University Press, History in Africa**，[Royal African Company correspondence 1681-1699, academic article abstract](https://www.cambridge.org/core/journals/history-in-africa/article/abs/royal-african-company-of-englands-west-african-correspondence-16811699/93CD3812821D2653BDA47A505A5A017C)。阅读级别：`peer_reviewed_abstract_read`；具体支持：Company losing monopoly in 1698, commercial decline 1720s, forts replaced by merchants-company arrangement 1750.
- `V5031` **University of Oxford Press**，[James H. Sweet, Mutiny on the Black Prince, academic monograph abstract](https://academic.oup.com/book/58166)。阅读级别：`academic_monograph_abstract_read_not_full_book`；具体支持：1768 Bristol Black Prince crew mutiny en route to Old Calabar, renamed Liberty, sailed toward Brazil; explicitly sailors, not captives.

**地图门禁**：本轮新事件均没有凭空增加WGS84坐标、沿海航迹线或疆域面。论文解读、档案目录和地理点都还须主编核对后方可用于正式发布。
