# 1786—1787年米斯基托海岸：英西外交撤离与被奴役者、效忠派再次流离

**专题阶段**：第五轮独立候审，未在正式地图发布。
**涉及18世纪母题**：`E18-A19`, `E18-A22`。
**新核事件**：3项；事实日期以事件JSON为准。
**阅读等级**：既有网站、档案转录、学术摘要和原档目录的差异逐项登记，绝不代称已阅纸本。

一、背景
英国与西班牙长期在今洪都拉斯和尼加拉瓜大西洋沿岸争夺贸易、殖民定居与木材权益；原有Miskitu政治体仍有独立外交利益。美国革命后部分效忠派来到黑河等殖民地。

二、决策与制度
1786年7月14日英西伦敦协定要求英籍殖民居民从Mosquito Shore撤离。协议是欧洲外交义务，不是原住民自治主体签署让地。

三、实际行动与日期
UNB登记1786年10月16日Black River效忠派请愿，要求补偿和迁居船；附“Negro Slaves”人数回单表。1787年2—6月英国官员组织撤离，但学者专门研究“未撤离英籍人口”，因此不能说海岸上所有英国人在同一日消失。

### 可追溯事件清单
| 日期 | 事件ID | 行动 | 来源ID |
|---|---|---|---|
| 1786-07-14 | `E18A5-MOSQUITO-1786-CONVENTION` | 1786伦敦英西公约约定撤出米斯基托海岸英籍殖民定居者 | V5029, V5030 |
| 1786-10-16 | `E18A5-MOSQUITO-1786-LOYALIST-PETITION` | Black River效忠派向英国官员请愿补偿与撤离运输 | V5030, V5029 |
| 1787 | `E18A5-MOSQUITO-1787-EVACUATION` | 英国开始实际撤出米斯基托海岸若干英籍殖民定居点 | V5030, V5029 |

四、具体地点和地图证据
伦敦签约不等于米斯基托沿岸的完整地图边界；Black River、Cape Gracias a Dios等历史地名保留空经纬度，查核过的同代海图才可提出淡色虚线概览。

五、人物和行动主体
英西王室代表、英国驻地James Lawrie、Black River效忠派、处于奴役身份的黑人、Miskitu领袖与居民。

六、受影响群体
从各事件`actor_entities_text`及当地政体辨识受影响的人，明确区分被奴役、原住民族、自愿盟友、战争俘虏、殖民民兵及独立民众。缺少独立人口核证时按群体名记录，不凭空分配具体人头。

七、反抗与政治主张
英籍殖民者提出债务和损失主张，被奴役者意愿在现存请愿文本中并非与殖民者权益一致，需更深挖个人姓名和是否被随迁转卖；Miskitu政治权利不能被英西条约覆盖。

八、经济后果和数字口径
木材、土地、奴役人口索赔应查CO137/86页167–169以及海关贸易账，档案目录只确认存在名单，不提供已独立复核人数。

九、长期影响与17世纪续接
协议到实际撤离存在时间差，构成加勒比大陆沿岸英国行政势力范围变化，而非把全部沿海地块都画成1786年稳定实占。
17世纪祖先专题ID见EVENT_CANDIDATES.json对应字段，不以1699示意面直接作为18世纪实控。

十、冲突和待查原档
逐页取得CO137/86、英西条约正文和Miskitu领导人外交证言；区分Black River与Belize其他英商木材区。

### 本批核心来源：只按实际阅读层级引用
- `V5029` **Cambridge University Press, The Americas**，[The Evacuation of the Mosquito Shore and the English Who Stayed Behind, 1786–1800](https://www.cambridge.org/core/journals/americas/article/abs/evacuation-of-the-mosquito-shore-and-the-english-who-stayed-behind-17861800/C3C415630F45B38FEE01002B12AF6DBB)。阅读级别：`peer_reviewed_extract_read`；具体支持：Treaty signed July 14 1786, obligations to remove British subjects from specific named coastal settlements; do not auto-transfer Miskitu political sovereignty.
- `V5030` **University of New Brunswick, Loyalist Collection**，[Original Correspondence Jamaica CO 137, 1780-1787 catalogue](https://loyalist.lib.unb.ca/record/original-correspondence-jamaica-co-137-1780-1787)。阅读级别：`archive_collection_catalogue_read_not_manuscript`；具体支持：1786 Oct 16 Black River loyalist memorial, request compensation/transport, accompanying enslaved persons return; Feb-June 1787 removal; originals at TNA Kew and restricted copies.

**地图门禁**：本轮新事件均没有凭空增加WGS84坐标、沿海航迹线或疆域面。论文解读、档案目录和地理点都还须主编核对后方可用于正式发布。
