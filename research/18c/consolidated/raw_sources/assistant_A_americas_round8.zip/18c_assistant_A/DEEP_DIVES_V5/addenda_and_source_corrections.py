from pathlib import Path
import json,csv,datetime,collections
P=Path('/mnt/data/18c_assistant_A'); e=json.loads((P/'EVENT_CANDIDATES.json').read_text());s=json.loads((P/'SOURCE_REGISTRY.json').read_text()); t=json.loads((P/'TOPIC_INDEX.json').read_text())
new_sources=[
('V5045','University of Michigan Clements Library','1759 Britain’s Year of Victories, Case 5: Niagara','https://clements.umich.edu/exhibit/1759-britains-year-of-victories/case-5/','academic_archive_onsite_1759_capitulation_item_and_commentary_read','July 24 La Belle Famille and July 25 Fort Niagara signed capitulation; describes manuscript articles in Frederick Mackenzie papers, no original image scrutinized.'),
('V5046','Old Fort Niagara Association','The Siege of Fort Niagara, battle day by day','https://www.oldfortniagara.org/my-post','heritage_museum_chronology_read','July 24 French relief defeated, July 25 surrender, July 26 French withdraw; compare occasional July 27 divergent secondary summaries.'),
('V5047','New York State Parks','Old Fort Niagara State Historic Site','https://parks.ny.gov/visit/historic-sites/old-fort-niagara-state-historic-site','government_historic_site_read','1759 UK captured Niagara; 1779 Haudenosaunee refugee displacement at Fort Niagara; US took post 1796. Refugee count is non-exact.'),
('V5048','Parks Canada, George Ingram (1979)','York Factory: A Structural History, Manuscript Report 297','https://parkscanadahistory.com/series/mrs/297.pdf','historical_research_pdf_indexed_text_screenshot_tool_failed','Indexed text p32: 24 August 1782 Marten surrendered York Factory to La Pérouse, 1 September 1782 burned, 1783 prefabricated house returned; 7 May 1788 flood; older 1714 possession. PDF screenshot service failed, original archival entries not personally read.'),
('V5049','Parks Canada, official federal historic designation','York Factory National Historic Site historic landscape and phases','https://www.pc.gc.ca/apps/dfhd/page_nhs_eng.aspx?id=158','federal_historic_designation_read','York Factory I 1684-1715 and II 1715-1788 eroded; III at new higher ground 1788 onward. Modern point cannot locate 1782 fort precisely.'),
('V5050','New York State Military Museum','Niagara, Fort historical listing','https://museum.dmna.ny.gov/forts/niagara','state_military_museum_history_read','Museum page mentions 27 July 1759 captured, conflicting with signed July25 capitulation; date conflict should be kept visible.'),
]
existing={x['id'] for x in s['sources']}
for id,inst,name,url,typ,scope in new_sources:
 if id not in existing:s['sources'].append({'id':id,'author_or_institution':inst,'title':name,'url':url,'type':typ,'actually_read_scope':scope,'manuscript_inspected':False,'read_scope_note':'原件目录、数字转录、考古学术报告区别标记；没有本人访问纸本档案。','supported_event_candidate_ids':[],'supported_topic_ids':[],'access_verified_at':'2026-11-08','primary_source_type':False,'separate_source_identity_note':'同一机构复述不可作为独立来源。'})
byid={x['id']:x for x in s['sources']}; byev={x['id']:x for x in e['events']}
def rewrite(id,source_ids,reason):
 x=byev[id];x['source_ids']=source_ids;x['source_urls']=[byid[z]['url'] for z in source_ids];x['source_support_count']=len(source_ids);x['source_note_v5']=reason
rewrite('E18A5-NIAGARA-1759-JUL24-FAMILLE',['V5036','V5045','V5046'],'真实1759报导及密歇根大学博物馆核对；原先无关的美国条约目录引用已删除。')
rewrite('E18A5-NIAGARA-1759-JUL25-SURRENDER',['V5036','V5045','V5046','V5050'],'7月25日投降原条款支持，纽约军事博物馆页面另出现7月27日数字；保留冲突待核，不将日期差异隐藏。')
rewrite('E18A5-HBC-1782-YORK-ATTACK',['V5048','V5049','V5025'],'具体攻堡日期和1782位置由Parks Canada研究报告和国家遗址文书对照。')
rewrite('E18A5-BLACKPRINCE-1768-REVOLT',['V5031'],'仅Oxford学术专书摘要（2024）提供事件主题证据；原船员刑事材料待读。')
# explicit precise action not inferred from dates
extra=[
('HBC-1714-YORK-TRANSFER',1714,9,None,['E18-C27'],'HBC代表James Knight到达York Factory并接管法国前据点','James Knight；法方留驻商人；Hudson’s Bay Company','Parks Canada研究报告依据公司日志称1714年9月Knight实际抵达并接管，独立于1713乌得勒支条约欧洲签约时间。','York Factory II predecessor, Hayes River, Manitoba',['V5048','V5023'],['E6-T10-HBC']),
('HBC-1782-AUG24-YORK-SURRENDER',1782,8,24,['E18-C27'],'约克工厂主管Marten于1782年8月24日向La Pérouse舰队投降','HBC驻站官Marten；法国舰队La Pérouse','Parks Canada的George Ingram研究据HBC原档记录8月24日投降：这是York Factory而非Prince of Wales Fort，须用1782老站址研究。','York Factory II (lost to river erosion), Hayes River',['V5048','V5049'],['E6-T10-HBC']),
('HBC-1782-SEP1-YORK-BURNING',1782,9,1,['E18-C27'],'法军于9月1日焚毁York Factory且HBC人员乘Severn离去','法国La Pérouse部队；HBC York Factory职员','Parks Canada建筑史记9月1日英国公司人员登上Severn帆船之际法军纵火，说明该商站没有在1782年末仍保持英方驻军。','York Factory II, Hayes River, Manitoba',['V5048','V5049'],['E6-T10-HBC']),
('HBC-1783-YORK-RESTORE',1783,None,None,['E18-C27'],'HBC将预制房屋运回York Factory重建商站','HBC伦敦委员会；驻站主管Marten及施工雇员','1783年HBC运抵预制建筑并在被摧毁的旧址恢复业务；1779至1788老站址不同于1788迁至新址的新York Factory III。','York Factory II, Hayes River, Manitoba',['V5048','V5049'],['E6-T10-HBC']),
('HBC-1788-MAY7-FLOOD',1788,5,7,['E18-C27'],'York Factory遭遇1788年5月7日严重洪灾、迫使重新选址','HBC Joseph Colen与员工；Hayes River自然洪水','Parks Canada引述Colen日记指出洪水5月7日毁坏大量站房，随后的选址与迁移是环境及公司建设事件，并非原住民土地被军事攻克。','York Factory II, Hayes River, Manitoba',['V5048','V5049'],['E6-T10-HBC']),
('HBC-1788-YORK-III',1788,None,None,['E18-C27'],'HBC在更高地势建设York Factory III并替代河岸旧据点','HBC Joseph Colen及原住民贸易伙伴','加拿大公园局界定约克堡第三期始建1788，旧工厂一二代位于已侵蚀河岸。现代遗址的监测点仅能作为1788年后第三期参考。','York Factory III / modern historic site, Manitoba',['V5049','V5025'],['E6-T10-HBC']),
('NIAGARA-1779-REFUGEES',1779,None,None,['E18-C17','E18-C12'],'Haudenosaunee和效忠派难民因美军烧毁村落大量逃往英属尼亚加拉堡','遭美军进攻的Haudenosaunee社区与效忠派；英军Fort Niagara驻军','纽约州公园局记1779年Van Schaick、Brodhead与Sullivan-Clinton美军远征破坏原住民家园，难民抵达英军据点并面临严酷粮食住房危机。必须明确破坏主体为美军及其盟友，英军为接收据点。','Fort Niagara / Niagara River, NY',['V5047','V5045'],['E6-T09-NY']),
('NIAGARA-1796-US-HANDOVER',1796,None,None,['E18-C17','E18-C11'],'英国终于在1796年将尼亚加拉堡交给美国控制','英国驻军与美国接收官员；当地Haudenosaunee等原住民族','纽约州公园局明确1796年美国接管Fort Niagara。1783年和约订立时与后来的真正交堡时间相隔多年，必须区别纸面转让与实占结束。','Fort Niagara, present New York',['V5047','V5050'],['E6-T09-NY']),
]
for i,(slug,yr,mo,day,tids,title,actors,desc,place,sids,old) in enumerate(extra,1):
 eid='E18A5-'+slug
 if eid in byev:continue
 model=next(x for x in e['events'] if x.get('v5_research_batch'))
 x={k:v for k,v in model.items()}; x.update(id=eid,date_text=str(yr)+(f'-{mo:02d}' if mo else '')+(f'-{day:02d}' if day else ''),year=yr,month=mo,day=day,date_precision='day' if day else 'month' if mo else 'year',topic_ids=tids,title=title,actor_entities_text=actors,historical_description_zh=desc,historical_place_name=place, source_ids=sids,source_urls=[byid[z]['url'] for z in sids],source_support_count=len(sids),evidence_status='official_institution_or_academic_research_needs_editorial_review',previous_17c_story_ids=old,topic_window_alignment={z:'research_window_or_continuation_review' for z in tids})
 e['events'].append(x)
 for z in sids:
  byid[z]['supported_event_candidate_ids'].append(eid);byid[z]['supported_topic_ids']=list(dict.fromkeys(byid[z]['supported_topic_ids']+tids))
# remove duplicate source support references with stale misattribution
for so in s['sources']:
 so['supported_event_candidate_ids']=list(dict.fromkeys([x for x in so.get('supported_event_candidate_ids',[]) if x in {v['id'] for v in e['events']} and so['id'] in next(v for v in e['events'] if v['id']==x)['source_ids']]))
for topic in t['topics']:
 topic['candidate_event_count']=sum(topic['id'] in x['topic_ids'] for x in e['events'])
 topic['source_ids']=list(dict.fromkeys(topic.get('source_ids',[])+[si for ev in e['events'] if topic['id'] in ev['topic_ids'] and ev.get('v5_research_batch') for si in ev['source_ids']]))
 topic['v5_new_events_count']=sum(topic['id'] in x['topic_ids'] for x in e['events'] if x.get('v5_research_batch'))
e['last_local_research_extension']='2026-11-08 48 round5 additions incl HBC 1782 daily siege/burning and 1796 Niagara transition'
s['last_local_research_extension']='2026-11-08 +6 extra academic archives including Parks Canada indexed report; screenshot service attempted and returned 502'
for file,data in [('EVENT_CANDIDATES.json',e),('SOURCE_REGISTRY.json',s),('TOPIC_INDEX.json',t)]: (P/file).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
# rebuild CSV with union columns
with (P/'EVENT_CANDIDATES.csv').open(encoding='utf-8-sig',newline='') as f:fields=csv.DictReader(f).fieldnames
fields=list(dict.fromkeys(fields+[k for ev in e['events'] for k in ev]))
with (P/'EVENT_CANDIDATES.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
 for ev in e['events']:
  w.writerow({key:json.dumps(val,ensure_ascii=False) if isinstance(val,(list,dict)) else val for key,val in ev.items()})
print('events',len(e['events']),'sources',len(s['sources']))
