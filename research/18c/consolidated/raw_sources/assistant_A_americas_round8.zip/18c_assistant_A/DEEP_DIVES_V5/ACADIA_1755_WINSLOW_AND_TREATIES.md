# 1749—1761年新斯科舍：Mi’kmaq外交与1755年Winslow驱逐日记

**专题阶段**：第五轮独立候审，未在正式地图发布。
**涉及18世纪母题**：`E18-C03`, `E18-C05`, `E18-C07`, `E18-C08`, `E18-C09`。
**新核事件**：8项；事实日期以事件JSON为准。
**阅读等级**：既有网站、档案转录、学术摘要和原档目录的差异逐项登记，绝不代称已阅纸本。

一、背景
阿卡迪亚英国1710夺港、1713法英欧洲条约并未消除Mi’kmaq、Wolastoqiyik和阿卡迪亚农民的地方政治。英国1749在Kjipuktuk建立哈利法克斯并对地域控制施加更大压力。

二、决策与制度
1755年7月28日Lawrence驱逐政策已有PR289基线。本轮新增1749年9月4日Saint John River批准和平条款，以及1752、1760、1761年不同原住民族首领与英国的单独议约：要区分地方主体、签约日及文书保存链。

三、实际行动与日期
Winslow日记10月8日记Grand-Pré居民被迫登上Church与Milbury号，描述抱儿妇女与衰老父母的场景。军方因怀疑Francis Hébert协助被拘押青年逃走而当面焚其房屋与谷仓。9月初另有Frye部队在Chépody与Petitcodiac焚毁村屋的报告。

### 可追溯事件清单
| 日期 | 事件ID | 行动 | 来源ID |
|---|---|---|---|
| 1749-09-04 | `E18A5-ACD-1749-SAINT-JOHN-RATIFY` | 圣约翰河原住民首领认可此前Chebucto和平条款 | V5007, V5043 |
| 1752-11-22 | `E18A5-ACD-1752-COPE-TREATY` | Mi’kmaq首领Jean-Baptiste Cope与总督Hopson重申和平友好条约 | V5011, V5043 |
| 1755-09-05 | `E18A5-ACD-SEP5-FRYE-LETTER` | Frye分遣队焚毁阿卡迪亚村落并遭法裔和原住民抵抗的军官书信 | V5005, S08 |
| 1755-10-08 | `E18A5-ACD-OCT8-EMBARK` | Winslow强制Grand-Pré阿卡迪亚家庭登上Church与Milbury运输船 | V5004, S07 |
| 1755-10-08 | `E18A5-ACD-OCT8-HEBERT` | Winslow命人当面烧毁Francis Hébert住宅与谷仓以惩戒逃离 | V5004, S07 |
| 1760-03 | `E18A5-ACD-1760-LAHAVE-TREATY` | Charles Lawrence与LaHave酋长Paul Laurent在哈利法克斯签订和平友好条约 | V5010, V5043 |
| 1761-06-25 | `E18A5-ACD-1761-MIRAMICHI-TREATY` | Miramichi首领Joseph Shabecholouct与Belcher在哈利法克斯缔结和平条约 | V5042, V5043 |
| 1761-11-09 | `E18A5-ACD-1761-MUIS-TREATY` | LaHave首领Francis Muis与Belcher签订1761和平友好条约 | V5008, V5009, V5043 |

四、具体地点和地图证据
Grand-Pré、Gaspereau、Chépody、Petitcodiac、Halifax等名称具证。保留未核坐标空值；新旧地点相同并不代表所有事件拥有同一GPS。

五、人物和行动主体
Lawrence、Monckton、Winslow、Frye及新英格兰军队；Francis Hébert与Les Mines被驱逐者；Mi’kmaq首领Jean-Baptiste Cope、Paul Laurent、Francis Muis、Joseph Shabecholouct及圣约翰河首领。

六、受影响群体
从各事件`actor_entities_text`及当地政体辨识受影响的人，明确区分被奴役、原住民族、自愿盟友、战争俘虏、殖民民兵及独立民众。缺少独立人口核证时按群体名记录，不凭空分配具体人头。

七、反抗与政治主张
被拘押青年从运输船逃亡、家族暗中帮助，法裔和原住民盟军在Petitcodiac周边反击焚村部队；原住民继续签订和约显示其外交主体身份存续。不得将地方军事反击一律写成毫无政治目标的“匪乱”。

八、经济后果和数字口径
军官书信报告曾烧毁181和253间建筑，但两个统计是否包含关系未完全确认，不相加为434。10月8日“约80户”只指当日记载的登船家庭，不代表1755全部被驱逐人数、人数或死亡。

九、长期影响与17世纪续接
村落毁灭、殖民地替代移民和失地的过程延续到1764后；1761和约的部分文本仅以1812年抄本保存，不能冒称审阅当时原稿。
17世纪祖先专题ID见EVENT_CANDIDATES.json对应字段，不以1699示意面直接作为18世纪实控。

十、冲突和待查原档
核Winslow所有运输船实际名单和保险账，分村毁损和统计口径；与Parks Canada的Grand-Pré、Fort Edward和Chignecto参照点对齐。

### 本批核心来源：只按实际阅读层级引用
- `V5004` **Nova Scotia Archives**，[John Winslow Journal: 8 October 1755 forced embarkation (NSHS III p166)](https://archives.novascotia.ca/deportation/archives/?Number=NSHSIII&Page=166)。阅读级别：`historical_primary_journal_later_printed_transcription_read`；具体支持：October 8 embarking families, burning Francis Hébert’s house and barn; October 9 correspondence.
- `S07` **Parks Canada**，[History of Grand-Pré](https://parks.canada.ca/lhn-nhs/ns/grandpre/culture/histoire-history)。阅读级别：`institutional_webpage_read`；具体支持：1755 Les Mines约2200人、1764返回后旧地已占
- `V5005` **Nova Scotia Archives**，[John Winslow Journal: Chépody and Petitcodiac September 1755 (NSHS III p101)](https://archives.novascotia.ca/deportation/archives/?Language=French&Number=NSHSIII&Page=101)。阅读级别：`historical_primary_captured_letter_transcription_read`；具体支持：Letter dated Sept 5 documenting British/New England detachment burning buildings and French/Indigenous armed resistance; building figures are author reports not independent censuses.
- `S08` **Parks Canada**，[The great upheaval Fort Beauséjour](https://parks.canada.ca/lhn-nhs/nb/beausejour/culture/histoire-history/deportation)。阅读级别：`institutional_webpage_read`；具体支持：1755-07-28命令、多个地区押送、1759抵抗、1761捕获、1764棚屋388人
- `V5007` **Nova Scotia Archives**，[1749 Saint John River ratification of Chebucto articles](https://archives.novascotia.ca/mikmaq/archives/?ID=622&Page=201605007&Transcript=1)。阅读级别：`historical_primary_treaty_copy_transcription_read`；具体支持：Sept 4 1749 ratification by St John River chiefs; refers to Aug 15 1749 Chebucto treaty articles; local signatory representation distinct.
- `V5043` **Nova Scotia Archives**，[Mi’kmaw teaching peace and friendship primary treaty collection](https://archives.novascotia.ca/teaching-learning/mikmaq/treaties/)。阅读级别：`official_collection_context_read`；具体支持：1725-1779 treaties, separate originals/copies; exact places, signatories and dates per item.
- `V5011` **Nova Scotia Archives**，[1752 Hopson proclamation on Cope treaty renewal, transcription](https://archives.novascotia.ca/mikmaq/archives/?ID=2&Page=201606222&Transcript=1)。阅读级别：`historical_primary_proclamation_transcription_read`；具体支持：Proclamation says treaty renewed on 22nd of that month; exact promulgation day not forced by search excerpt.
- `V5010` **Nova Scotia Archives**，[Treaties of Peace and Friendship, 1760 and 1761, online collection](https://archives.novascotia.ca/teaching-learning/mikmaq/treaties/archives/?ID=626)。阅读级别：`institutional_treaty_source_history_read`；具体支持：Charles Lawrence–Paul Laurent March 1760 copied treaty; originals not known, later copies and chain of custody disclosed.
- `V5042` **Nova Scotia Archives**，[Peace treaties online teaching collection, including 1761 25 June Joseph Shabecholouct](https://archives.novascotia.ca/mikmaq/archives/?ID=1558)。阅读级别：`archive_transcript_finding_aid_read`；具体支持：Treaty Halifax June 25, 1761 between Joseph Shabecholouct of Miramichi and Jonathan Belcher.
- `V5008` **Nova Scotia Archives**，[1761 Peace and Friendship Treaty between Jonathan Belcher and Francis Muis](https://archives.novascotia.ca/mikmaq/archives/?ID=627)。阅读级别：`archive_copy_catalogue_and_provenance_read`；具体支持：9 November 1761 Halifax treaty is preserved in 1812 Sigogne copy; originals no longer known to exist.
- `V5009` **Nova Scotia Archives**，[1761 Belcher and Francis Muis treaty: transcribed signature and 1812 provenance](https://archives.novascotia.ca/mikmaq/archives/?ID=21&Page=201606300&Transcript=3)。阅读级别：`historical_primary_1812_copy_transcription_read`；具体支持：Treaty signed 9 November 1761, copied/collated 5 May 1812; two separate documentary dates.

**地图门禁**：本轮新事件均没有凭空增加WGS84坐标、沿海航迹线或疆域面。论文解读、档案目录和地理点都还须主编核对后方可用于正式发布。
