# 1783年巴黎和约第3与7条：纽芬兰渔权、黑人效忠派撤离与财产声索

**专题阶段**：第五轮独立候审，未在正式地图发布。
**涉及18世纪母题**：`E18-C17`, `E18-C18`, `E18-C26`。
**新核事件**：2项；事实日期以事件JSON为准。
**阅读等级**：既有网站、档案转录、学术摘要和原档目录的差异逐项登记，绝不代称已阅纸本。

一、背景
革命战争期间英军曾对部分逃向英军的被奴役者承诺自由。1783年双方为结束战事确定边界与财产条款，使这些人的处境进入英美之间的法权争执。

二、决策与制度
1783年9月3日英美签署巴黎和约，条款3限定美国渔船使用纽芬兰和其他海域的条件，条款7限制英军撤离时带走被美国居民视为财产的黑人。

三、实际行动与日期
不得将Article 7简单理解为所有黑人效忠派立刻返奴。实际纽约港审查委员会、英军运输名单和美国索还主张分别构成不同法律、军政行为；前轮已经登记1783年7月24日两名儿童被交还的个案。

### 可追溯事件清单
| 日期 | 事件ID | 行动 | 来源ID |
|---|---|---|---|
| 1783-09-03 | `E18A5-CROWN-1783-PARIS-ARTICLE7` | 1783巴黎和约第七条把非裔人身视为可被声索的财产并限制英军撤运 | V5020, V5013 |
| 1783-09-03 | `E18A5-CROWN-1783-PARIS-FISH` | 1783巴黎和约第三条约定美国渔船使用纽芬兰海域的特定权利 | V5020, S79 |

四、具体地点和地图证据
巴黎为签约地，不可代表实际纽约黑人装船或纽芬兰捕鱼地点；以事件多地语义登记，缺GPS保留null。

五、人物和行动主体
英国代表David Hartley、美国谈判代表John Adams/Benjamin Franklin/John Jay、Carleton英军司令、前奴役主和有姓名的黑人撤离者。

六、受影响群体
从各事件`actor_entities_text`及当地政体辨识受影响的人，明确区分被奴役、原住民族、自愿盟友、战争俘虏、殖民民兵及独立民众。缺少独立人口核证时按群体名记录，不凭空分配具体人头。

七、反抗与政治主张
黑人效忠派以参军、航船与向官署申辩争取自由；法国和美国政治原则不能代替这些人的个人选择。

八、经济后果和数字口径
Article 3涉及鳕鱼加工与航运权利，Article 7涉及被迫视为动产的人身财产，两个不同条款不得用一种贸易收益口径算总和。

九、长期影响与17世纪续接
纽芬兰渔业继续涉及英国沿岸与美国渔船竞争，黑人效忠派到Nova Scotia和Sierra Leone的移民争议持续到1790年代。
17世纪祖先专题ID见EVENT_CANDIDATES.json对应字段，不以1699示意面直接作为18世纪实控。

十、冲突和待查原档
核英美委员会卷、实际释放/扣押登记和渔业登陆纠纷案；不同州奴役法和英军命令适用差异需逐案核。

### 本批核心来源：只按实际阅读层级引用
- `V5020` **U.S. National Archives**，[Treaty of Paris, 3 September 1783: full transcript](https://www.archives.gov/milestone-documents/treaty-of-paris)。阅读级别：`signed_primary_treaty_official_transcription_read`；具体支持：Article 3 Newfoundland fishing and drying, Article 7 British withdrawals and “Negroes or other Property”; no presumption all persons were returned.
- `S79` **Memorial University Newfoundland Heritage**，[King William's Act of 1699](https://www.heritage.nl.ca/lawfoundation/articles/doc2_1699william.html)。阅读级别：`primary_law_transcription_read`；具体支持：法律原文与1700渔季适用日期
- `V5013` **Colonial Williamsburg Foundation**，[Dunmore’s Proclamation and the Fight for Freedom](https://www.colonialwilliamsburg.org/discover/moments-in-history/road-to-independence/dunmores-proclamation/)。阅读级别：`museum_interpretive_timeline_read`；具体支持：Nov 15 public announcement after Kemp’s Landing; Dec 9 Great Bridge; disease and shipboard crowding for Black refugees.

**地图门禁**：本轮新事件均没有凭空增加WGS84坐标、沿海航迹线或疆域面。论文解读、档案目录和地理点都还须主编核对后方可用于正式发布。
