# 1759—1796年尼亚加拉堡：英国军事夺堡、豪德诺索尼流亡与实际交还美国

**专题阶段**：第五轮独立候审，未在正式地图发布。
**涉及18世纪母题**：`E18-C11`, `E18-C12`, `E18-C17`。
**新核事件**：4项；事实日期以事件JSON为准。
**阅读等级**：既有网站、档案转录、学术摘要和原档目录的差异逐项登记，绝不代称已阅纸本。

一、背景
尼亚加拉堡是法军与后来的英军在大湖区贸易、补给及外交网络中的要塞，但长期处在Haudenosaunee及周边原住民族政治家园。1759英军企图控制法军的军事据点和地区转运通路。

二、决策与制度
1759年英国正规军与殖民军在原住民盟友参与下包围法军Pouchot守卫的Fort Niagara。指挥官Prideaux阵亡后William Johnson接手。1759年7月24日法军援军在La Belle Famille失利，7月25日签署投降条款。

三、实际行动与日期
密歇根大学Clements图书馆展示签降条款影印/收藏目录，明确7月25日接收。纽约州军博物馆另一网页把占领误记或另记为7月27日，应以条款原稿与7月25日驻军进驻日期优先核。1779年美国军队攻击Haudenosaunee村落迫使难民进入仍由英军驻守的尼亚加拉堡。直到1796年美国才真正接收此堡。

### 可追溯事件清单
| 日期 | 事件ID | 行动 | 来源ID |
|---|---|---|---|
| 1759-07-24 | `E18A5-NIAGARA-1759-JUL24-FAMILLE` | La Belle Famille战斗后法军援助尼亚加拉堡的部队失利 | V5036, V5045, V5046 |
| 1759-07-25 | `E18A5-NIAGARA-1759-JUL25-SURRENDER` | 法军于1759年7月25日向Johnson交出尼亚加拉堡 | V5036, V5045, V5046, V5050 |
| 1779 | `E18A5-NIAGARA-1779-REFUGEES` | Haudenosaunee和效忠派难民因美军烧毁村落大量逃往英属尼亚加拉堡 | V5047, V5045 |
| 1796 | `E18A5-NIAGARA-1796-US-HANDOVER` | 英国终于在1796年将尼亚加拉堡交给美国控制 | V5047, V5050 |

四、具体地点和地图证据
Fort Niagara同代堡垒地名有据，La Belle Famille战斗约在堡南而战线未测，1779难民驻地缺精确边界；Modern military museum/visitor marker的GPS不能代表整个18世纪历史控制区。

五、人物和行动主体
英国军官Sir William Johnson、Prideaux；法军Pouchot；原住民族战士和外交群体、被迫离乡的Haudenosaunee家庭；美国军队与驻军。

六、受影响群体
从各事件`actor_entities_text`及当地政体辨识受影响的人，明确区分被奴役、原住民族、自愿盟友、战争俘虏、殖民民兵及独立民众。缺少独立人口核证时按群体名记录，不凭空分配具体人头。

七、反抗与政治主张
豪德诺索尼联盟并不等同英国附属民兵，原住民各支部和家庭在七年战争及独立战争中采取不同战略；1779年受害村庄毁坏的主体需如实记为美军，而非英军。

八、经济后果和数字口径
战争改变贸易堡垒驻军与大湖运输节点，不能把“英国获得Fort Niagara”计成整个大湖区土地永久实占。1779难民规模有机构概述但缺名单分母，不记录精确死亡人数。

九、长期影响与17世纪续接
1783《巴黎和约》后英方仍驻守数座大湖堡垒，1796年才完成Niagara交接。正适用于“外交声索日期”和“实际驻军交接日期”分层地图。
17世纪祖先专题ID见EVENT_CANDIDATES.json对应字段，不以1699示意面直接作为18世纪实控。

十、冲突和待查原档
阅1759年11条投降原款、当代1759年7月25日日志、1779—1780冬季军粮和难民回单、1796实际撤军交接军令。

### 本批核心来源：只按实际阅读层级引用
- `V5036` **Old Fort Niagara Association**，[The Battle of La Belle Famille: contemporary 1759 dispatch transcript](https://www.oldfortniagara.org/the-battle-of-la-belle-famille)。阅读级别：`heritage_museum_contemporary_dispatch_transcription_read`；具体支持：Contemporary dispatch describes July 24 battle and July 25 1759 French surrender at Fort Niagara; quoted troop counts are belligerent claims.
- `V5045` **University of Michigan Clements Library**，[1759 Britain’s Year of Victories, Case 5: Niagara](https://clements.umich.edu/exhibit/1759-britains-year-of-victories/case-5/)。阅读级别：`academic_archive_onsite_1759_capitulation_item_and_commentary_read`；具体支持：July 24 La Belle Famille and July 25 Fort Niagara signed capitulation; describes manuscript articles in Frederick Mackenzie papers, no original image scrutinized.
- `V5046` **Old Fort Niagara Association**，[The Siege of Fort Niagara, battle day by day](https://www.oldfortniagara.org/my-post)。阅读级别：`heritage_museum_chronology_read`；具体支持：July 24 French relief defeated, July 25 surrender, July 26 French withdraw; compare occasional July 27 divergent secondary summaries.
- `V5050` **New York State Military Museum**，[Niagara, Fort historical listing](https://museum.dmna.ny.gov/forts/niagara)。阅读级别：`state_military_museum_history_read`；具体支持：Museum page mentions 27 July 1759 captured, conflicting with signed July25 capitulation; date conflict should be kept visible.
- `V5047` **New York State Parks**，[Old Fort Niagara State Historic Site](https://parks.ny.gov/visit/historic-sites/old-fort-niagara-state-historic-site)。阅读级别：`government_historic_site_read`；具体支持：1759 UK captured Niagara; 1779 Haudenosaunee refugee displacement at Fort Niagara; US took post 1796. Refugee count is non-exact.

**地图门禁**：本轮新事件均没有凭空增加WGS84坐标、沿海航迹线或疆域面。论文解读、档案目录和地理点都还须主编核对后方可用于正式发布。
