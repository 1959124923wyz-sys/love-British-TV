# 爱英TV｜调查员A｜第5轮离线累计研究包

- 调查范围：英国18世纪北美、加勒比和大西洋奴役贸易（A01–A22／C01–C27）
- 所有成果是**候审研究资料，不是正式地图已发表内容**；无Github变更。
- 共358事件、310来源、49母专题、49个原专题报告 + 10份第5轮深挖报告。
- 第五轮净新增48事件与50来源，时间精度：到日163、月47、年148。
- 既有GeoJSON仅24个有据现代参考点；334件事件无地理坐标。
- 主事件数据库 `EVENT_CANDIDATES.json` 与 `EVENT_CANDIDATES.csv` 对齐；`SOURCE_REGISTRY.json`登记来源链接和阅读深度。
- `DEEP_DIVES_V5/`是本轮专题、48件新增事件的来源矩阵、报告索引；`GAPS_AND_CONFLICTS.md`写日期、参与主体和边线冲突。
- `NUMERICAL_EVIDENCE_V5.json`保留法律额、实施数量、实际收入的分别口径；没有来源的实际死亡与净收益全部保持null。
- `MAP_PLACE_RESEARCH_V5.csv`是历史地名调查线索，非可立即绘制的GIS；旧24点GeoJSON原状保存。
- `REFERENCE/VALIDATION_V5.json`是实际运行的格式、ID交叉引用、坐标类型和文件检查结果；`SHA256_SUMS_V5.txt`用于离线校验。
- 必须由主编后续处理：原件/逐航次数据复核、历史控制逐年校对、GIS证据审批、互动正文与浏览器QA。下载并解压ZIP后首先读`PROGRESS.md`。
