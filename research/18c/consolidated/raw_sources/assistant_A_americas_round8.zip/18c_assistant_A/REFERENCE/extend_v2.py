#!/usr/bin/env python3
# 1700–1799 Americas/Atlantic supplementary primary-source research. Local only.
import json,csv,os,copy,collections,zipfile,hashlib
from pathlib import Path
root=Path('/mnt/data/18c_assistant_A')
P=lambda f:root/f
D=lambda f:json.loads(P(f).read_text(encoding='utf-8'))
base=D('EVENT_CANDIDATES.json'); reg=D('SOURCE_REGISTRY.json'); index=D('TOPIC_INDEX.json');geo=D('MAP_CANDIDATES.geojson')
old_ids={e['id'] for e in base['events']}; existing_source={s['id'] for s in reg['sources']}
# Institution, source title, URL, actually inspected area, kind
S={
'R01':('Nova Scotia Archives','Winslow Journal at Grand Pré, NSHS vol III p.71','https://archives.novascotia.ca/deportation/archives/?Number=NSHSIII&Page=71','1883 transcribed 1755-08-16 and 1755-08-22 field journal; archival transcription of a historical manuscript','archival_primary_transcription'),
'R02':('Nova Scotia Archives','Winslow Journal at Grand Pré, NSHS vol III p.94','https://archives.novascotia.ca/deportation/archives/?Number=NSHSIII&Page=94','1755-09-04 summoning of Acadian inhabitants and preparations; 1883 transcription','archival_primary_transcription'),
'R03':('Nova Scotia Archives','Winslow Journal at Grand Pré, NSHS vol III p.98','https://archives.novascotia.ca/deportation/archives/?Language=English&Number=NSHSIII&Page=98','1755-09-05 detainee restrictions and hunger; 1755-08-28 Boston shipmaster letter transcribed','archival_primary_transcription'),
'R04':('Nova Scotia Archives','Winslow Journal at Grand Pré, NSHS vol III p.101','https://archives.novascotia.ca/deportation/archives/?Number=NSHSIII&Page=101','1755-09-05 officer dispatch on destruction of Chépody/Petitcodiac; author is participant, 1883 transcription','archival_primary_transcription'),
'R05':('Nova Scotia Archives','Winslow Journal at Grand Pré, NSHS vol III p.169','https://archives.novascotia.ca/deportation/archives/?Number=NSHSIII&Page=169','1755-10-11 seven incoming ships and separate letter about detainees escaping vessel security; primary correspondent','archival_primary_transcription'),
'R06':('Nova Scotia Archives','Winslow Journal at Grand Pré, NSHS vol III p.185','https://archives.novascotia.ca/deportation/archives/?Number=NSHSIII&Page=185','Lists burnt buildings on Nov 2,5,6,7 and officers claim 2242 embarked; counts are author records not independently measured','archival_primary_transcription'),
'R07':('Nova Scotia Archives','Acadian Heartland searchable primary source editions 1714–1768','https://archives.novascotia.ca/deportation/','Edition-level description: Akins 1869 and Winslow 1883/1885 archival transcripts; original manuscript not personally read','archival_primary_collection_overview'),
'R08':('Encyclopedia Virginia / Virginia Humanities','Virginia General Assembly 1705 An Act concerning Servants and Slaves (Hening ed. 1823)','https://encyclopediavirginia.org/primary-documents/an-act-concerning-servants-and-slaves-1705/','Transcribed October 1705 statute: sec IV, VI, XX, XXIII-XXV, XXXII, XXXIV, XXXVI-XXXIX, XL; edition pp447-463','published_primary_statute'),
'R09':('University of New Brunswick, Laws of Enslavement and Freedom','Jamaica 1760 An Act to remedy the Evils arising from irregular Assemblies...','https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1760','Full 1760-12-18 transcript and clauses I-II, IV, VI, X, XII, XXI; operative 1761-01-01, 1787 official compilation','published_primary_statute'),
'R10':('Historical Society of the New York Courts','Trials Relating to the New York Slave Insurrection, 1741','https://history.nycourts.gov/case/slave-conspiracy-trials/','Court institutional history: 1741-03-08 fire, Apr21 grand jury, May11 trials, 30 death sentences and 70 deportation sentences, testimony incentives','judicial_institutional_history'),
'R11':('University of South Carolina, SC Encyclopedia; Mark M Smith','Stono Rebellion 1739','https://www.scencyclopedia.org/sce/entries/stono-rebellion/','Sept 9 start; September pursuit, 1740 law, 1741 duty; divergent claimed deaths from NPS other source','academic_scholarly_encyclopedia'),
'R12':('US National Park Service','Stono Rebellion September 9 1739 / NPS Underground Railroad calendar','https://home.nps.gov/subjects/undergroundrailroad/iugrrm-social-media.htm','NPS event chronology, Cato-led group; naming differences Jemmy/Cato require source-by-source distinction','federal_institutional_history'),
'R13':('University of New Brunswick Laws of Enslavement and Freedom','South Carolina 1740 Act for better Ordering and Governing Negroes and other Slaves','https://slaveryandfreedomlaws.lib.unb.ca/node/253','Full 1740-05-10 law transcription from Grimké 1790, proprietary heirs, patrols, tickets, summary courts, published version','published_primary_statute'),
'R14':('North Carolina State Library, NCpedia','Tuscarora War in North Carolina before 1770','https://www.ncpedia.org/waywelived/tuscarora-war','1711 Lawson, Mar 20-23 1713 Nooherooka, 1715 treaty and 1717 Roanoke lands; reported 1400 killed/1000 enslaved is synthesis estimate','state_reference_scholarly_history'),
'R15':('State Library of North Carolina, NCpedia','Tuscarora People, defense of Neoheroka and Barnwell campaigns','https://www.ncpedia.org/american-indians/tuscarora','1711 September defense, 1712 Jan Narhantes, Apr Fort Hancock siege and concession; local tribal political complexity','state_reference_scholarly_history'),
'R16':('State Library of North Carolina, NCpedia','Nooherooka decisive battle March 20–23 1713','https://www.ncpedia.org/nooherooka-tuscarora-war','Site-level history and destruction report; 392,558,1000 figures are estimative and differ from period newspaper','state_institutional_history'),
'R17':('State Library of North Carolina, NCpedia','Boston News-Letter April 1713 report on Tuscarora War','https://www.ncpedia.org/media/boston-news-letter-reports','Actual 1713 newspaper transcription: reporting Moore with Indian allies, dated 1713-03-20 attack and different reported killed/captured numbers; contemporaneous partisan report','contemporary_news_primary_transcription'),
'R18':('US National Park Service Southeast Archeological Center','Ninety Six colonial site and the Cherokee War 1760–1762','https://www.nps.gov/orgs/1539/the-southeast-chronicles-ninety-six-national-historic-site.htm','1760 Jun24 action, Aug8 Loudoun surrender, 1761 Grant expedition, use reported totals attributed to cited studies','federal_academic_history'),
'R19':('University of South Carolina, SC Encyclopedia','Cherokee War 1759–1761','https://www.scencyclopedia.org/sce/entries/cherokee-war-1759-1761/','1758 settler killing Cherokee fighters, 1759 Dec22 coerced treaty, 1760 Feb1 Long Cane, 1760 fort, 1761 troops and Sept23 treaty','academic_scholarly_encyclopedia'),
'R20':('Parks Canada','Chloe Cooley National Historic Person','https://parks.canada.ca/culture/designation/personnage-person/chloe-cooley','1793 March abduction, March 21 testimony, June draft and July law; explicitly says no existing people freed, children after Jul 3 freed at 25','federal_primary_context_and_commemoration'),
'R21':('Parks Canada','Upper Canadian Act of 1793 Against Slavery National Historic Event','https://www.parks.canada.ca/culture/designation/evenement-event/loi-antiesclavagiste-act-against-slavery','Official plaque explicitly states did not free a single previously enslaved person; banned imports and children of enslaved later freed at 25','federal_institutional_history'),
'R22':('Nova Scotia Museum','Black Loyalist Communities in Nova Scotia','https://museum.novascotia.ca/stories/black-loyalist-communities-nova-scotia','1784 Jul Shelburne riot ~20 destroyed homes; June Port Mouton resettlement, free/enslaved distinguish, 1500 Shelburne settlement','provincial_museum_history'),
'R23':('Nova Scotia Archives','1798 Captain Holland Map 239: Port Roseway and Birchtown/Black Town','https://archives.novascotia.ca/maps/archives/?ID=225','Historical map collection descriptive metadata, originally published 1798-07-12; has insets with Birchtown and Black Town, NOT georeferenced coordinates','archival_map_catalogue_view'),
'R24':('Library and Archives Canada','Black Loyalist refugees – Port Roseway Associates 1782 to 1807','https://www.canada.ca/en/library-archives/collection/research-help/genealogy-family-history/loyalists/black-refugees-port-roseway-associates.html','1784 free Black Birchtown muster catalogue 1,498 references, not actual population; raw reels not read','archival_primary_catalogue'),
'R25':('Smithsonian National Postal Museum','Battle of Bushy Run: Fort Pitt smallpox blankets episode','https://postalmuseum.si.edu/exhibition/indians-at-the-post-office-murals-conflict/the-battle-of-bushy-run','Cites Trent diary June 24 1763, invoice wording, Amherst July 7 and 16, Bouquet July 13; impact not established','federal_museum_historical_analysis'),
'R26':('Elizabeth A Fenn, journal article','Biological Warfare in Eighteenth-Century North America: Beyond Jeffery Amherst','https://historycooperative.org/journal/smallpox-blankets/','Scholarly reconstruction of Fort Pitt contemporaneous invoice, 1763-06-24, letters July 7,13,16; disease causality uncertain','peer_reviewed_history_article_html'),
'R27':('Parks Canada','Thanadelthur National Historic Person','https://parks.canada.ca/culture/designation/personnage-person/thanadelthur','1714 self-liberation from captivity, 1715-16 female Dene guide diplomacy, 1717 Churchill River post; primary journals cited but not accessed','federal_indigenous_history'),
'R28':('Parks Canada','History of Sloop Cove / Samuel Hearne and Cumberland House','https://www.parks.canada.ca/lhn-nhs/mb/prince/culture/decouvrir-discover3','1774 inland Cumberland House and later 1782 French taking Prince of Wales fort; no river route digitization','federal_historical_site'),
'R29':('Royal Museums Greenwich / SlaveVoyages','Voyage 84106 Zong 1781','https://www.slavevoyages.org/voyage/84106','Vessel-level historical voyage database estimates embark 440 and disembark 208; numbers not all homicide and may reflect imputation','academic_voyage_database_record'),
'R30':('London Museum','Zong massacre 1781–1783 and insurance trial','https://www.londonmuseum.org.uk/collections/london-stories/zong-massacre-trial/','1781 Nov-Dec murders, 1783 March Guildhall insurance litigation; different public memory numerical summaries 130/133 not exact court count','museum_historical_explanation'),
'R31':('University of New Brunswick Laws of Enslavement and Freedom','Bermuda 1730 restrictive law against freed Black and Indigenous residents','https://slaveryandfreedomlaws.lib.unb.ca/laws/bermuda-1730-0','1930? no, original 1730 statute heading only and catalogue, transcript referenced only; Jan 1 date normalized by database not proven exact','colonial_statute_catalogue'),
'R32':('Historical Society of the New York Courts','Race and Slavery in New York Courts 1702-1741','https://history.nycourts.gov/product/2021-society-calendar-race-slavery-nys-courts/','1702 city law public whipping and 1741 death counts disputed with separate case study; documentary institutional history','judicial_institutional_history'),
'R33':('University of New Brunswick Laws of Enslavement and Freedom','South Carolina 1754 Act criminalizing helping enslaved people escape','https://slaveryandfreedomlaws.lib.unb.ca/laws/south-carolina-1754','Full transcription with 1754-06-24 commencement for capital penalties helping enslaved persons escape','published_primary_statute'),
'R34':('Nova Scotia Archives','1798 Plan of Port Roseway Harbour (African Nova Scotians collection)','https://archives.novascotia.ca/africanns/archives/?ID=50','An archival replica/reference to 1798 Map 239 with Black Town and Birchtown labels, not an independent historical witness from R23','archival_map_copy'),
'R35':('National Museums / US National Archives','1783 Carleton Papers and Book of Negroes overview','https://www.canada.ca/en/library-archives/collection/research-help/genealogy-family-history/loyalists.html','Archive finding aid: 1783 named refugee ship manifests; no individual record personally read','national_archival_index'),
'R36':('Parks Canada','1796–1800 Jamaican Maroons in Nova Scotia commemorative history','https://parks.canada.ca/culture/designation/evenement-event/marrons-maroons','1796 April forced departure, July arrival, Preston relocation and resistance, 1800 September 30 arrival elsewhere beyond target century','federal_historical_analysis'),
'R37':('US National Park Service','Stono Rebellion site study (NPS mentions Stono River near Rantowles)','https://home.nps.gov/subjects/undergroundrailroad/iugrrm-social-media.htm','NPS Stono September 9 first 20 freedom-seekers group, different names Cato vs Jemmy; precise spot not known','federal_historical_site_note'),
'R38':('US National Park Service','Native American colonists Yamasee War and Cherokee comparison','https://www.nps.gov/orgs/1539/the-southeast-chronicles-ninety-six-national-historic-site.htm','Cherokee injuries from settlers and frontier trade context; source also cited as R18, not independent','federal_historical_site'),
}
for sid,(inst,title,url,scope,typ) in S.items():
 if sid in existing_source:continue
 reg['sources'].append(dict(id=sid,author_or_institution=inst,title=title,url=url,type=typ,actually_read_scope=scope,manuscript_inspected=False,read_scope_note='2026-11-08在线HTML正文/档案馆校订文本或馆藏目录的可见部分；原纸本文物与微缩胶片没有逐件亲阅。',supported_event_candidate_ids=[],supported_topic_ids=[],access_verified_at='2026-11-08',primary_source_type=('primary_' in typ or 'primary_statute' in typ),separate_source_identity_note='同机构同页不同网址、转述或转载的副本不构成独立证据。'))
by_source={s['id']:s for s in reg['sources']}
# New high value named acts, dates, dispositions; all locations without validated modern GPS stay null.
# tuple: tag, date, title, topic(s), actor, historical place, historical claim, source_ids, class
E=[
# Acadia: British officer primary journal disaggregates burning and forced removal
('ACD-WINSLOW-ARRIVE','1755-08-16','Winslow率地方部队从Chignecto出发前往Pisiquid地区',['E18-C07','E18-C09'],'John Winslow、马萨诸塞殖民军','Chignecto—Fort Edward，Pisiquid','Winslow日记称8月16日率313名包括军官在内的部队从Chignecto乘三船出发，次日抵Fort Edward。此313是部队人数而不是押送者人数。',['R01'],'primary_field_journal'),
('ACD-WINSLOW-SETUP','1755-08-22','Winslow在Grand-Pré驻扎并将教堂作为军队控制点',['E18-C07','E18-C08'],'John Winslow及殖民地方部队','Grand-Pré / Gaspereau','日记开篇记8月22日于Grand-Pré扎营、使用教堂作为军械/守卫地点。仅能指示军队驻点，不得推定整个Les Mines已被军事占有。',['R01'],'primary_field_journal'),
('ACD-SEPT4-SUMMONS','1755-09-04','Winslow派人传唤Grand-Pré阿卡迪亚男子到教堂',['E18-C07','E18-C08'],'John Winslow、当地阿卡迪亚居民','Grand-Pré','Winslow在9月4日日记记向居民发出传唤，并安排执行；不得把当日行动误写为所有妇幼已经拘押。',['R02'],'primary_field_journal'),
('ACD-SEPT5-DETENTION','1755-09-05','英国地方部队将到教堂的Grand-Pré居民拘押并加强警戒',['E18-C07','E18-C08'],'John Winslow与新英格兰士兵；阿卡迪亚居民','Grand-Pré教堂','Winslow当日日记规定被拘押居民夜间在教堂内、白日活动不得越过军官许可线，并加倍岗哨；他又记居民没有食物而请求面包。',['R03','R02'],'primary_field_journal'),
('ACD-CHEPODY-BURN','1755-09-03','英方烧毁Chépody村建筑并袭击Petitcodiac河谷',['E18-C07'],'英国殖民军分遣队Major Frye与当地阿卡迪亚—原住民抵抗者','Chépody / Petitcodiac','9月5日寄出的英军现场报告称先在Chépody焚毁181座建筑，继于9月3日进入Petitcodiac河；遭阿卡迪亚人与原住民武装反击，军官称撤离前总共焚毁253座建筑。这些为当事军官自报不同作战范围计数，不能相加。',['R04'],'primary_report_with_partisan_counts'),
('ACD-OCT11-TRANSPORT','1755-10-11','Winslow记七艘新运输船抵达并准备押送Grand-Pré居民',['E18-C07','E18-C08'],'John Winslow、船长与殖民军、被拘押阿卡迪亚家庭','Grand-Pré / Annapolis Royal','Winslow报告前日（10月10日）七艘运输船从Annapolis方向抵达，并准备装载食品与拘押居民；仅为船次来港，不得把七船当做已满载离港。',['R05'],'primary_field_journal'),
('ACD-OCT11-ESCAPE','1755-10-11','Grand-Pré被拘押青年从运输船逃脱',['E18-C07','E18-C08'],'阿卡迪亚被拘押青年、英殖民军','Gaspereau河口','Winslow信件称约二十名被拘押青年从两船逃脱；约二十为军官近似报告，逃脱方式是军官推测，后续归队结局未证。',['R05'],'primary_officer_account'),
('ACD-NOV2-FIRE','1755-11-02','英军在Gaspereau焚毁49间民居等农庄建筑',['E18-C07','E18-C08'],'Winslow指挥的殖民军焚毁队伍','Gaspereau','Winslow统计表记11月2日焚毁49间住宅、39座谷仓、19座其他建筑。为一手军事计账，不代表已独立现场测绘。',['R06'],'primary_military_accounting'),
('ACD-NOV5-FIRE','1755-11-05','英军在Canard、Habitant、Pero等村焚毁房屋与谷仓',['E18-C07','E18-C08'],'Winslow麾下殖民军','Canard、Habitant、Pero','日记汇总11月5日焚毁76间住宅、81座谷仓与33座附属建筑。具体每村独立数量未列。',['R06'],'primary_military_accounting'),
('ACD-NOV6-FIRE','1755-11-06','英军继续焚毁Canard及Habitant村房屋',['E18-C07','E18-C08'],'Winslow麾下殖民军','Canard、Habitant','Winslow日记统计该日85间住宅、100座谷仓、75座其他建筑遭焚毁；村界与每处建筑坐标未知。',['R06'],'primary_military_accounting'),
('ACD-NOV7-FIRE','1755-11-07','英军再次焚毁Canard及Habitant建筑',['E18-C07','E18-C08'],'Winslow麾下殖民军','Canard、Habitant','Winslow统计该日焚毁45间住宅、56座谷仓与28座其他建筑。四日日记分类汇总255住宅/276谷仓/155杂屋。',['R06'],'primary_military_accounting'),
('ACD-NOV-ACCOUNT','1755-11','Winslow日记总结Les Mines驱逐人次及焚毁建筑账',['E18-C07','E18-C08'],'英国殖民军John Winslow和Osgood、被驱逐阿卡迪亚居民','Les Mines','11月日记附表记Winslow押船1510、Osgood押船732，合计2242；另记255住宅、276谷仓、155附屋、11磨坊及一处宗教建筑等。是该辖区参与者行动报告，可能与公园局约2200人来自同一个原始统计，不能把二者作为独立加总。',['R06','S07'],'primary_military_document_count'),
# Tuscarora and anti-Indigenous slave war
('TUS-LAWSON','1711-09','Tuscarora扣押侵入其领地的殖民测量官John Lawson',['E18-C21'],'Tuscarora领袖、John Lawson、Baron von Graffenried','Neuse River/Catechna','北卡州立资料记Lawson及同行于9月被扣留，Lawson后遭杀害；资料也记当地族人放过同行被奴役黑人。Lawson活动引发争议与越界测绘相关。',['R14','R15'],'state_scholarly_history'),
('TUS-ATTACK-1711','1711-09-22','Tuscarora等反击Neuse和Pamlico河周边殖民聚落',['E18-C21'],'Tuscarora及其盟友、北卡罗来纳殖民定居者','Neuse / Pamlico River settlements','北卡官方Tuscarora专题明确给1711年9月22日为进攻殖民聚落的关键日期；涉及双方伤亡的估值不在此虚构。',['R15','R16'],'state_scholarly_history'),
('TUS-NARHANTES','1712-01','Barnwell与原住民盟军攻打Tuscarora的Narhantes防御点',['E18-C21'],'John Barnwell、南卡殖民军、原住民盟军和Tuscarora','Fort Narhantes, near New Bern','北卡州历史记Barnwell在1712年1月围攻Narhantes，造成数百原住民死亡或被俘；确切数分源，不自动视为被奴役者数。',['R15'],'state_scholarly_history'),
('TUS-FORTHANCOCK','1712-04','Barnwell以壕沟和燃烧威胁围攻Tuscarora在Catechna的堡垒',['E18-C21'],'John Barnwell军队、Tuscarora守军与被拘殖民者','Fort Hancock / Catechna Creek','北卡州史料记1712年4月Barnwell再围攻Fort Hancock并迫使签署割地和平条件；出兵对象是原住民实际防御社区而非纸面空地。',['R15'],'state_scholarly_history'),
('TUS-NEOHEROKA-BEGIN','1713-03-20','Moore率殖民军及原住民盟军围攻Tuscarora的Nooherooka',['E18-C21'],'James Moore殖民武装、不同原住民盟军与Tuscarora守军','Nooherooka/Neoheroka, Greene County','官方州史将攻坚起始日记为1713年3月20日，堡内抵抗者与家庭在防御工事内被围。',['R16','R17'],'source_crosschecked_state_history_and_period_press'),
('TUS-NEOHEROKA-FALL','1713-03-23','殖民军焚毁Nooherooka防御工事并大量俘虏Tuscarora',['E18-C21'],'James Moore及其原住民盟军、Tuscarora','Nooherooka, near modern Snow Hill','官方州史记3月23日堡垒最终失守，幸存者遭俘；同期1713 Boston News-Letter报640死160俘，现代学者汇总不同，均不可当确证死亡总数。',['R14','R17','R16'],'crosschecked_date_quantities_conflict'),
('TUS-FEBTREATY','1715-02','北卡与残余Tuscarora交战群体订立和约',['E18-C21'],'北卡殖民当局和Tuscarora政治代表','North Carolina, precise treaty site not checked','北卡图书馆编年记持续抵抗至1715年2月签订和约；条款和各签字人待查原档。',['R14'],'state_scholarly_history'),
('TUS-1717-ROANOKE','1717','北卡为部分继续居住的Tuscarora划定Roanoke河附近用地',['E18-C21'],'北卡殖民地政府、Tuscarora居民','Roanoke River near Quitsna','北卡州史记1717年对仍留在当地的Tuscarora给予土地安排；缺契据界线，不能沿现代郡界画封闭多边形。',['R14'],'state_scholarly_history'),
# Stono revolt, legislation, continued manhunt
('STONO-REVOLT','1739-09-09','Stono河畔被奴役非洲人武装起义试图逃往西班牙佛罗里达',['E18-C21','E18-C22'],'来自中西非的被奴役者（首领名Cato/Jemmy存在叙述差异）、南卡殖民民兵','Stono River, St Paul Parish','以获得自由为目标的武装集结从约20人扩大，向St Augustine行进并与殖民民兵交战。两份机构来源首领称谓不同，记录为冲突点。',['R11','R12'],'academic_and_federal_history'),
('STONO-PURSUIT','1739-09','南卡民兵追捕Stono起义者并杀害被拘反抗者',['E18-C21'],'南卡民兵、起义者','Stono to south of Edisto River','南卡研究记初次冲突后仍有逃脱者，次周又发生交火，处决、斩首示众与长期搜捕；总死亡估计在不同记录间冲突。',['R11'],'academic_history'),
('STONO-LEADER-1742','1742','殖民当局在Stono起义数年后仍追捕被怀疑领袖',['E18-C21'],'南卡殖民民兵和逃亡者','South Carolina Lowcountry','南卡百科称至少一名被指起义领袖至1742年才被捕；不明姓名不得补造。',['R11'],'academic_history'),
('SC-CODE-1740','1740-05-10','南卡罗来纳通过奴役法典限制流动、交易和司法权',['E18-C21','E18-C22'],'South Carolina殖民议会、白人民兵与被奴役居民','Charleston, colonial South Carolina','1740年5月10日法令宣告动产奴役继承、简化审判程序、限定持船和外出工作；多处条款兼含有限制暴虐的字句，但法定处置主体基本是殖民奴隶主。',['R13','R11'],'primary_statute_and_academic_history'),
('SC-IMPORT-DUTY','1741','南卡殖民议会对再输入被奴役者征收限制性进口关税',['E18-C21','E18-A01'],'South Carolina殖民议会、奴役商人','Charleston','大学南卡百科记Stono起义后1741年提高对新输入被奴役人口关税；本轮未得到原税率法条，金额置空。',['R11'],'academic_history_pending_statute'),
('SC-FLIGHT-AID-1754','1754-06-24','南卡规定帮助被奴役者逃离殖民地可受重罪惩罚',['E18-C21','E18-C22'],'South Carolina殖民议会、潜在协助逃亡者','South Carolina','原法明确自1754年6月24日起将故意协助奴役者出逃及掳走等列为可判死刑的重罪；惩罚威胁不等于实际处决某个未经查明的人。',['R33'],'primary_statute'),
# Cherokee: military and local agency
('CHER-RETURNEES-KILLED','1758','弗吉尼亚定居者袭击从对法战争归来的Cherokee战士',['E18-C11'],'Virginia settlers、Cherokee warriors','Virginia frontier, precise place unknown','南卡大学学术百科记1758年底定居者杀害返回中的Cherokee军人；是后续英切罗基关系恶化的重要原因。',['R19'],'academic_history'),
('CHER-HOSTAGE-TREATY','1759-12-22','Lyttelton拘押Cherokee谈判代表并签订强迫条件的和约',['E18-C11'],'总督William Henry Lyttelton、Oconostota、Ostenaco等Cherokee领袖','Fort Prince George','英属南卡军队将切罗基代表带往Fort Prince George作为人质，12月22日签约要求交出指定个人；不是部族自愿割让全域。',['R19'],'academic_history'),
('CHER-LONGCANE','1760-02-01','Cherokee战士袭击Long Cane Creek殖民难民队伍',['E18-C11'],'Cherokee fighters、殖民地居民','Long Cane Creek, South Carolina','南卡百科记1760年2月1日难民队伍遭袭；此前人质事件与殖民者杀人关系应结合叙述。',['R19'],'academic_history'),
('CHER-HOSTAGES-KILLED','1760-02','Fort Prince George英国守军在Oconostota伏击后杀害Cherokee人质',['E18-C11'],'Fort Prince George英国驻军、Cherokee领袖','Fort Prince George','南卡百科记英守军在军官Cotymore遭伏击及死亡后报复杀死仍被扣留Cherokee人质；事件日仍需第一手军报。',['R19'],'academic_history'),
('CHER-MONTGOMERY-TOWNS','1760-05','英军Montgomery远征焚毁切罗基Lower Towns村落',['E18-C11'],'Archibald Montgomery英国正规军、Cherokee村社','Estatoe、Lower Town Cherokee territory','南卡百科记1760年4—5月英军约1600人深入并焚烧Estatoe等村；尚无本轮逐村毁屋清单，土地面积不得推断。',['R19','R18'],'two_institutional_studies'),
('CHER-ECHOEE','1760-06-24','Cherokee在Echoee方向伏击Montgomery英国远征队',['E18-C11'],'Cherokee fighters、Archibald Montgomery军队','near Echoee','美国国家公园研究记1760年6月24日Cherokee伏击英军，英军伤亡数字为来源转引，不直接作为核准合计。',['R18'],'federal_historical_study'),
('CHER-LOUDOUN-FALL','1760-08-08','Cherokee围困迫使英国Fort Loudoun守军投降',['E18-C11'],'Cherokee领导人Oconostota、Fort Loudoun英军','Fort Loudoun, upper Tennessee valley','南卡学术百科和国家公园研究均记1760年8月8日英军因食物短缺交出Fort Loudoun；后续撤离途中遭袭，应与初始投降分开。',['R18','R19'],'two_scholarly_institutional_histories'),
('CHER-LOUDOUN-WITHDRAWAL','1760-08','切罗基人在Fort Loudoun英军撤离后截击队伍并擒获军官',['E18-C11'],'Cherokee warriors、英军撤离队伍、John Stuart','near Fort Loudoun','在英国人质被杀的背景下，Cherokee战士攻击撤离英军，部分被杀或俘；不同资料称英军死亡人数不同，不用单一精确人数。',['R18','R19'],'two_scholarly_institutional_histories'),
('CHER-GRANT-DESTROY','1761-06','James Grant英军对切罗基城镇实施系统毁村与毁粮',['E18-C11'],'James Grant英军、殖民民兵、Cherokee communities','Middle / Outer Cherokee towns','南卡学术百科记1761年5—6月英军毁掉15个城镇及约15000英亩庄稼；面积为学术汇总估算，不等于英国获地或控制。',['R19','R18'],'reported_summary_not_mapped'),
('CHER-SEPT-TREATY','1761-09-23','英方与Cherokee代表在Charleston签和约并争论分界',['E18-C11'],'Cherokee leaders、South Carolina British colonial officials','Charleston','南卡学术百科将协议日期记1761-09-23，涉及交换战俘、法商与边界；缺原界文书，不画实际原住民领土让渡线。',['R19'],'academic_history_original_treaty_pending'),
# Upper Canada: witness testimony and provincial restrictions
('CHLOE-MARCH14','1793-03-14','Chloe Cooley被奴隶主捆绑押过Niagara河售给美国买方',['E18-C17','E18-C18'],'Chloe Cooley、奴隶主Adam Vrooman及其同伙、见证人','Queenston and Niagara River','加拿大公园局记Chloe反抗绑缚与贩卖，见证人Peter Martin等后来作证；此为加拿大境内受奴役者主动抵抗，不可将她写成获得自由。',['R20'],'federal_commemoration'),
('CHLOE-TESTIMONY','1793-03-21','Peter Martin与William Grisley向上加拿大行政会议作证',['E18-C18'],'Peter Martin、William Grisley、Upper Canada Executive Council','Upper Canada Executive Council, Niagara region','加拿大公园局记录1793年3月21日两名证人报告Chloe Cooley被迫售至美国的遭遇，推动总督要求草拟限制奴役的新法。',['R20'],'federal_commemoration'),
('CHLOE-BILL','1793-06-19','上加拿大Attorney General John White提交限制奴役草案',['E18-C18'],'John White、Lieutenant Governor Simcoe、殖民议会','Newark / Niagara-on-the-Lake','省档案教育资料记6月19日提交法案；对奴隶主利益的妥协、议员反对可据官立叙述，未经原议事录不虚构逐人投票。',['R20'],'government_context_pending_legislative_journal'),
('CHLOE-ACT','1793-07-09','上加拿大通过限制奴役和奴役人口输入的法律',['E18-C18'],'Upper Canada legislature、Simcoe、被奴役及自由黑人居民','Niagara-on-the-Lake','1793年立法禁止再输入被奴役者，既有奴役者没有当即释放；1793年7月3日后所生被奴役母亲子女到25岁获释。法令具体颁布日据安大略档案教育资料记7月9日，条款生日分界与颁布日不同。',['R20','R21'],'federal_history_ontario_archives_date_pending'),
# NS Black loyalists: racism vs crown policy and original map
('NS-PORTMOUTON','1784-06','Port Mouton火灾后黑人效忠派居民由殖民政府迁往Guysborough',['E18-C18'],'黑人效忠派社区、英属新斯科舍政府','Port Mouton / Chedabucto Bay','新斯科舍博物馆记Port Mouton遭火灾后1784年6月一批黑人效忠派迁往Chedabucto建立Guysborough；这是从北美迁来的社区内部再次迁移。',['R22'],'provincial_museum_history'),
('NS-SHELBURNE-RIOT','1784-07','Shelburne解散白人士兵袭击黑人效忠派住所',['E18-C18'],'前英军白人士兵、自由黑人效忠派居民','Shelburne, Nova Scotia','新斯科舍博物馆记约20户自由黑人住房被拆毁，为种族歧视和争工冲突；1784年事件可与1798当代港湾地名图结合但绝不按后图直接划1784暴力区。',['R22','R23'],'provincial_museum_and_archive_map_context'),
('NS-PORTROSEWAY-CHART','1798-07-12','Captain Holland绘制的Port Roseway港湾图公开标示Birchtown和Black Town',['E18-C18'],'英国殖民时代测绘者Captain Holland、黑人新斯科舍社区','Shelburne Harbour, Birchtown, Black Town','新斯科舍档案馆编目一幅1798年7月12日于伦敦发行的海湾图，嵌图包括Burch Town与Black Town；是地图证据不是当日新征服事件。',['R23','R34'],'historical_map_dated_not_new_conquest'),
# HBC diplomacy
('HBC-DENE-ESCAPE','1714','Dene女性Thanadelthur在逃脱俘虏处境后进入York Factory',['E18-C27'],'Thanadelthur、Cree及Dene社群、HBC人员','York Factory','加拿大公园局记Thanadelthur于1714年到York Factory寻求庇护，后来掌握Dene/Cree/英语语言助外交。原住民主体不可只写公司雇员。',['R27'],'federal_indigenous_history'),
('HBC-DENE-PEACE','1716','Thanadelthur促成Dene与Cree的和平谈判',['E18-C27'],'Thanadelthur、Dene代表、Cree代表、HBC William Stuart','interior Dene/Cree territory; exact route unknown','加拿大公园局把远征定为1715—1716年，和平协议在Thanadelthur自行完成途中外交后达成；精确日月与行走轨迹未核。',['R27'],'federal_indigenous_history'),
('HBC-CHURCHILL-POST','1717','HBC在Churchill River建立贸易站',['E18-C27'],'Hudson’s Bay Company、Dene和Cree商贸参与者','Churchill River','公园局确认贸易站于1717年夏设立，紧接1715—16地方外交；站点不能代表公司直接占领整个德内土地。',['R27'],'federal_indigenous_history'),
# Fort Pitt: original report and command correspondence, outcomes separated
('FORTPITT-POX-BLANKETS','1763-06-24','Fort Pitt驻军向Delaware谈判代表提供来自天花隔离病区的毯子',['E18-C12'],'Fort Pitt驻军军官和商人、Delaware政治代表Turtle’s Heart与Mamaltee','Fort Pitt (present-day Pittsburgh)','Trent日记及贸易报账转录记谈判后赠两条毯子和手帕，书面表达意图令天花传播。没有经证由此造成特定病例或死亡数字。',['R25','R26'],'journal_invoice_transcribed_intent_not_impact'),
('FORTPITT-AMHERST-LETTER','1763-07-07','英军总司令Amherst致Bouquet讨论以天花打击原住民',['E18-C12'],'Jeffery Amherst、Henry Bouquet','British command communications, New York to Pennsylvania','书信于7月7日提出传播天花建议，比6月24日Fort Pitt行动晚，不得误写为Amherst下令并导致6月24日事件。',['R25','R26'],'military_correspondence_transcribed'),
('FORTPITT-BOUQUET-REPLY','1763-07-13','Bouquet回信表示将尝试用天花感染物对付原住民',['E18-C12'],'Henry Bouquet、Jeffery Amherst','British command correspondence','Bouquet答复将尝试用毯子传播天花；这是军事通信中的行动意图，不能推断具体再次发放或疫病传播成果。',['R25','R26'],'military_correspondence_transcribed'),
('FORTPITT-AMHERST-RESPONSE','1763-07-16','Amherst赞同使用天花感染毯子并鼓励更多手段',['E18-C12'],'Jeffery Amherst、Henry Bouquet','British command correspondence','Amherst再次支持通过毯子播疫，属于军事最高层书面意向；人口伤亡与实际疫情归因未建立。',['R25','R26'],'military_correspondence_transcribed'),
# New York institutional repression chronology
('NY-1702-WHIPPER','1702','纽约殖民议会许可奴隶主惩罚并设置公共鞭刑者',['E18-C23'],'New York殖民地议会、奴隶主、黑人居民','New York City','纽约州法院历史学会记1702立法允许奴隶主施刑并设公共鞭刑者；原法案条次与生效日待核。',['R32'],'judicial_institutional_history'),
('NY-1741-FIRE-CONTEXT','1741-03','纽约多处火灾引起被奴役者阴谋审判恐慌',['E18-C24'],'殖民地法官、被告与被奴役社区','Fort George and lower Manhattan','州法院史记3月8日Fort George起火，往后又有多起火灾；审讯从普通火案迅速升级成基于有争议证词的谋反指控。',['R10'],'judicial_history'),
('NY-1741-EXILE','1741','纽约殖民法院判部分被告流放至加勒比奴役殖民地',['E18-C24'],'New York Supreme Court、受审黑人及白人','New York City; Caribbean destinations not checked','法院历史学会称约200受审、30判死刑、70判贩卖至加勒比；是司法处罚类别的汇总，非逐人已登船验证数字，且执行数字和另一机构处决口径待核。',['R10','R32'],'judicial_history_outcome_not_travel_manifest'),
# Caribbean legal implementation
('JAMAICA-LAW-ACTIVE','1761-01-01','1760年牙买加反起义法开始施行通行证、Obeah刑罚与自由身份证要求',['E18-A06','E18-A07'],'牙买加殖民议会、地方治安法官、被奴役及自由有色居民','Jamaica, colony-wide law only','1760-12-18法规第XXI条明确1761-01-01开始实施，条款X对Obeah处以死刑或运输，条款XII要求自由有色人登记证和徽记；不能给整岛绘制某日军占范围。',['R09'],'primary_statute_effective_date'),
('BERMUDA-FREE-BLACK-LIMIT','1730','百慕大法案限制获释非洲裔与原住民继续居住',['E18-A22'],'百慕大殖民议会、获释黑人及原住民','Bermuda','UNB法案目录标题表示获释后6个月的离境限制，数据库归档日1月1日为标准化字段，尚未核真实通过日。该法令为制度证据，具体驱逐人次未核。',['R31'],'colonial_law_heading_only'),
# Zong actual data and numbers / separately record database record; avoid overcount
('ZONG-ARRIVAL','1781-12-22','Zong奴役船在严重死亡及杀人后抵达牙买加',['E18-A09','E18-A20'],'Zong船长及船员、遭强制押送的非洲人','Jamaica (Black River recorded in SlaveVoyages)','SlaveVoyages航次84106将登船人数推估440、下船208。损失两者之差232含海上疾病、故意杀人等，绝不可全部判为谋杀人数；抵港日据保险博物馆二手整理待原港册。',['R29','R30'],'database_and_museum_figures_distinguished'),
('ZONG-INSURANCE','1783-03','伦敦保险人因Zong杀人理赔争议与船主对簿公堂',['E18-A09'],'Gregson船主集团、Gilbert保险人、英国法官','London Guildhall','伦敦博物馆指出1783年3月市政厅开庭审理理赔，首轮船东胜但保险人上诉；法院赔付主张不等于资金最终兑付，也未开刑事杀人审判。',['R30'],'museum_legal_history'),
]
# Avoid adding duplicate existing fact if only better source / same phase event:
existing_dates={(e['date_text'],e['title']) for e in base['events']}
added=[]
for tag,date,title,topic,actor,place,description,refs,evclass in E:
 if not all(t in {x['id'] for x in index['topics']} for t in topic):raise ValueError('missing topic '+str(topic))
 if any(x not in by_source for x in refs):raise ValueError('missing source '+str(refs))
 yr=int(date[:4]);mo=int(date[5:7]) if len(date)>=7 else None;day=int(date[8:10]) if len(date)==10 else None
 status='source-verified-online-primary-transcription' if evclass.startswith('primary') or evclass.startswith('published_primary') else 'source-checked-secondary-or-transcribed'
 if 'conflict' in evclass:status='source-conflict-needs-original-audit'
 entry=dict(id='E18A2-'+tag,date_text=date,year=yr,month=mo,day=day,date_precision=('day' if day else 'month' if mo else 'year'),topic_ids=topic,title=title,actor_entities_text=actor,historical_description_zh=description,historical_place_name=place,longitude=None,latitude=None,modern_reference_site=None,geo_precision='named_historical_location_reference_without_independently_verified_WGS84',coordinates_support_sources=[],source_ids=refs,source_urls=[by_source[s]['url'] for s in refs],source_support_count=len(refs),claim_crosscheck_status=('multiple_references_but_source_independence_to_audit' if len(refs)>1 else 'single_identified_institution_or_primary_edition'),evidence_status=status,previous_17c_story_ids=[],pr289_preexisting_acadia_candidate_ids=[],historical_control_boundary_verified=False,political_claim_not_actual_control=True,area_sqkm=None,historical_line_or_route_surveyed=False,estimated_casualties_count=None,estimated_trade_sum=None,publication_status='research_only',publication_review='not_submitted',topic_window_alignment={},topic_window_context_notice=None,evidence_kind=evclass,added_in_local_extension='2026-11-08-v2')
 for t in topic:
  idx=next(x for x in index['topics'] if x['id']==t)
  prec=idx.get('previous_story_ids',[])
  entry['previous_17c_story_ids']=list(dict.fromkeys(entry['previous_17c_story_ids']+prec))
  win=idx['research_window'];entry['topic_window_alignment'][t]=('in_core_research_window' if win['start_year']<=yr<=win['end_year'] else 'context_outside_core_window')
  if entry['topic_window_alignment'][t]!='in_core_research_window':entry['topic_window_context_notice']='New related case outside original topic research-window, for editor to move/crosslink to proper topic; no publication.'
 if entry['id'] in old_ids:raise ValueError('id collides '+entry['id'])
 base['events'].append(entry);old_ids.add(entry['id']);added.append(entry)
 for ref in refs:
  rec=by_source[ref];rec.setdefault('supported_event_candidate_ids',[]).append(entry['id']);rec['supported_topic_ids']=sorted(set(rec.get('supported_topic_ids',[])+topic))
# Make two events anchored in source-specific original law precise, not fake exact day
# strengthen old event descriptions rather than manufacture re-run
old_event_by_id={e['id']:e for e in base['events']}
patch_existing={
'E18A-1760-A06-01':('已核完整1760年12月18日牙买加法规正文。原法第XXI条规定1761年1月1日生效；原记录标题含"推出"，保持通过日而在1761另立生效事件。', ['R09']),
'E18A-1705-C22-01':('已核弗吉尼亚1705年10月立法正文，特别涉及第四、二十、二十五、三十四、三十六至三十九、四十条；相关法定处罚与补偿不是已执行事实。',['R08']),
'E18A-1741-C24-03':('纽约法院史证实5月11日被指控者集体庭审开始，更多案件持续；不要把当日视为所有处决发生。',['R10']),
'E18A-1781-A09-01':('SlaveVoyages Zong航次84106估计被迫登船440人、抵岸208人。二者差232非1781凶杀准确人数；伦敦博物馆网页自身有130和133两种表述。',['R29','R30']),
'E18A-1715-C27-01':('加拿大公园局进一步记1715—1716年Thanadelthur主导Dene/Cree外交，而非单一1715年的具体签约日。',['R27']),
}
for eid,(note,refs) in patch_existing.items():
 if eid in old_event_by_id:
  e=old_event_by_id[eid];e['v2_source_audit_note_zh']=note;e['v2_confirmatory_source_ids']=refs
# Source view/issue ledger: not artificially certify surviving printed text as manuscript personally inspected.
geo['metadata']['local_v2_extension']='All new locations are recorded as named historical places; no unverified GPS, Polygon, buffer or line is introduced.'
claim_rows=[]
def claim(topic,statement,docs,measurement_type=None,recorded_value=None,evidence_level='source_checked',caveat=None):
 k=f'V2-C{len(claim_rows)+1:03d}'
 claim_rows.append(dict(id=k,topic_ids=topic,claim_zh=statement,source_ids=docs,source_urls=[by_source[s]['url'] for s in docs],evidence_level=evidence_level,measurement_type=measurement_type,recorded_value=recorded_value,caveat=caveat,publication_status='research_only'))
claim(['E18-C07','E18-C08'],'Winslow记录1755年11月2、5、6、7日共焚毁255间住宅、276座谷仓、155座附属建筑；另有11座磨坊和1座宗教建筑等，共698建筑为原作者不同项汇总。',['R06'],'buildings_reported',{'houses':255,'barns':276,'outbuildings':155,'mills':11,'other_church':1,'total_in_original':698},'primary_transcription','一手部队记录，未由地籍逐栋复核；不能从建筑数推导受害人口。')
claim(['E18-C07','E18-C08'],'Winslow附表称个人负责押船1510人、Osgood负责732人，合计2242人，属Les Mines局部执行人员统计。',['R06','S07'],'persons_reported_by_perpetrator',{'Winslow':1510,'Osgood':732,'combined':2242},'period_officer_account','不与加拿大公园局约2200数字累加；同源独立性不成立。')
claim(['E18-C07'],'Winslow转录的另一份1755年9月5日英军书信记先在Chépody焚毁181栋建筑、行动总计焚毁253栋，两个数是包含关系。',['R04'],'buildings_reported',{'Chepody':181,'campaign_reported_total':253},'primary_transcription','书信在9月5日书写、报告9月3日前后行动；军队作者并非中立现场调查。')
claim(['E18-A06','E18-A07'],'牙买加1760反起义法规的Obeah条款（第X条）及身份登记（第XII条）按第XXI条自1761年1月1日生效。',['R09'],evidence_level='full_statute_transcribed',caveat='法律授权的刑罚不能被统计为实际执行人数。')
claim(['E18-C22'],'1705弗吉尼亚法第XXXVII-XXXIX条授权猎捕拒绝归来的逃亡奴役者并规定业主通过公共程序索赔。',['R08'],evidence_level='full_statute_transcribed',caveat='"有权索赔"不能记作特定业主获赔；世袭身份另列第XXXVI条。')
claim(['E18-C21'],'同时代1713年Boston News-Letter报Nooherooka战后英军声称640人被杀160人被俘，北卡现代资料另给与此不同的估计。',['R17','R16'],'contemporary_partisan_report',{'reported_killed':640,'reported_taken_prisoner':160},'conflicting_quantitative_sources','报纸转载的是殖民军声称，不当准确死者数；不能直接与其他现代估计求和。')
claim(['E18-C21'],'Stono反抗者首领在NPS公共介绍称Cato，在学术南卡资料与部分文献称Jemmy；名称与是否同一人待原卷核对。',['R11','R12'],evidence_level='conflicting_naming',caveat='地图事件标题使用集体政治主体，避免武断人物实体合并。')
claim(['E18-C11'],'1761年James Grant战役南卡学术来源报告焚毁约15个Cherokee城镇和15000英亩庄稼。',['R19'],'reported_town_crop_damage',{'towns_reported':15,'cropland_acres_reported':15000},'secondary_historical_synthesis','这是受毁农地面积的历史报道，不是英国殖民实控面积。')
claim(['E18-C12'],'1763年6月24日Fort Pitt赠污染毯记录与7月7/13/16英军通信可证明传播意图，不能证明特定感染/死亡人数。',['R25','R26'],evidence_level='transcribed_journal_invoice_and_letters',caveat='三份通信在6月24日行动后书写，不当作6月24日执行链。')
claim(['E18-C18'],'1793年上加拿大法律既未释放既有受奴役者，也没有立即释放所有25岁以上的人；只规定未来出生的相关子女在25岁获释。',['R20','R21'],evidence_level='two_federal_histories',caveat='同属加拿大公园系统的两篇材料，不算完全独立的第二机构。')
claim(['E18-A09'],'Zong航次84106估计从西非登船440、牙买加抵岸208，差232名为多种原因造成的航程人口减少。',['R29'],'voyage_dataset_estimate',{'embarked_estimated':440,'disembarked_estimated':208,'difference_not_murder_count':232},'academic_database','网页另列船员损失；伦敦博物馆对被杀人数出现130/133等不一致。')
claim(['E18-C18'],'1798-07-12 Captain Holland在伦敦发表Port Roseway海图，嵌图标明Birchtown和Black Town。',['R23','R34'],evidence_level='historical_cartographic_source',caveat='R34是同一张1798图在档案馆另一目录的索引；并非独立第二份测绘；不据图直接划1784暴力边线。')
claim(['E18-C24'],'1741纽约殖民司法机构报告约200人受审、30人判死刑、70人判加勒比奴役；另一机构列实际处决细项不同。',['R10','R32'],'court_history_synthesis',{'tried_approximately':200,'death_sentences':30,'sentenced_caribbean_slavery':70},'institutional_legal_history','死亡判决、实际被处决、加勒比判流与实际登船都是不同口径。')
claim(['E18-C18'],'1784年7月Shelburne白人退伍士兵毁掉自由黑人约20处住宅，据新斯科舍博物馆。',['R22'],'reported_house_destruction',{'houses_destroyed_reported':20},'provincial_museum','要核同代报案及赔偿记录方能确认每户受损/后续获赔情况。')
(P('EVIDENCE_CLAIMS_V2.json')).write_text(json.dumps(dict(schema='evidence-claims-18c-assistantA-20261108-v2',publication_status='research_only',claims=claim_rows),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
# Additional historic named places to be mapped only after authoritative geolocation validation
places={}
for e in added:
 nm=e['historical_place_name']
 if nm not in places:places[nm]=dict(historical_place_name=nm,event_ids=[],topic_ids=[],latitude=None,longitude=None,coordinate_status='UNRESOLVED: do not geocode from prose alone',historical_claim_area_verified=False,draw_as_verified_control_polygon=False,source_ids=[])
 item=places[nm];item['event_ids'].append(e['id']);item['topic_ids']=sorted(set(item['topic_ids']+e['topic_ids']));item['source_ids']=sorted(set(item['source_ids']+e['source_ids']))
with P('MAP_PLACE_RESEARCH_V2.csv').open('w',encoding='utf-8-sig',newline='') as f:
 fields=['historical_place_name','latitude','longitude','coordinate_status','historical_claim_area_verified','draw_as_verified_control_polygon','event_ids','topic_ids','source_ids'];wr=csv.DictWriter(f,fields);wr.writeheader()
 for x in places.values(): wr.writerow({k:';'.join(x[k]) if isinstance(x[k],list) else x[k] for k in fields})
# Append real new claims into corresponding substantive dossier rather than only overall index.
grouped=collections.defaultdict(list)
for e in added:
 for t in e['topic_ids']:grouped[t].append(e)
for t,rows in grouped.items():
 p=P(f'TOPIC_DOSSIERS/{t}.md')
 if not p.is_file():raise ValueError('missing dossier '+t)
 with p.open('a',encoding='utf-8') as f:
  f.write('\n\n## 十一、2026-11-08第二轮深度核证与新增原始档案节点\n\n')
  f.write('以下新增记录是在第一轮候审条目之外另行查得的独立行动或文书节点。**所有新增ID仅供本地研究，未进入正式Atlas；无证历史坐标统一留空。**\n\n')
  for e in sorted(rows,key=lambda z:(z['date_text'],z['id'])):
   f.write(f"### {e['date_text']}｜{e['title']} (`{e['id']}`)\n\n")
   f.write(f"**行动主体**：{e['actor_entities_text']}。**具名历史地点**：{e['historical_place_name']}（现阶段无独立核实的WGS84事件点）。\n\n")
   f.write(e['historical_description_zh']+'\n\n')
   f.write('**阅读证据**：'+'；'.join(f"[`{x}`]({by_source[x]['url']})" for x in e['source_ids'])+f"。**审查等级**：`{e['evidence_status']}`；**政治范围**：不据此新画实控面。\n\n")
  related=[x for x in claim_rows if t in x['topic_ids']]
  if related:
   f.write('### 此轮专门统计／争议记录\n\n')
   for c in related:f.write(f"- `{c['id']}`：{c['claim_zh']} **口径或缺口**：{c.get('caveat') or '待原卷复核'}；证据：{', '.join(c['source_ids'])}。\n")
  f.write('\n')
# Recompute index from all events; no manual stale counters
for idx in index['topics']:
 tid=idx['id'];linked=[e for e in base['events'] if tid in e['topic_ids']]
 idx['candidate_event_count']=len(linked)
 idx['source_ids']=list(dict.fromkeys(idx['source_ids']+[s for e in linked for s in e['source_ids']]))
 idx['v2_new_events_count']=len(grouped.get(tid,[]))
idx_by_id={x['id']:x for x in index['topics']}
index['last_local_research_extension']='2026-11-08-v2'
base['last_local_research_extension']='2026-11-08-v2'
base['notice']+=' V2 2026-11-08: source-checked extended candidates added, including some contextual events beyond individual original topic windows. No verified new polygons, GPS or publication.'
reg['last_local_research_extension']='2026-11-08-v2'
for f,d in [('EVENT_CANDIDATES.json',base),('SOURCE_REGISTRY.json',reg),('TOPIC_INDEX.json',index),('MAP_CANDIDATES.geojson',geo)]:P(f).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
# CSV all fields union, json encoded nested lists to avoid corruption
rows=base['events'];cols=list(dict.fromkeys(k for r in rows for k in r))
with P('EVENT_CANDIDATES.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=cols);w.writeheader()
 for row in rows:w.writerow({k:json.dumps(row[k],ensure_ascii=False) if isinstance(row.get(k),(list,dict)) else row.get(k) for k in cols})
# Continuation and reporting documents.
map_note='''# 地图第二轮史料判断 | 不捏造GPS或历史版图

## 一、具有真实历史测绘来源的图

- 1798-07-12 Captain Holland《Plan of Port Roseway Harbour》，新斯科舍省档案馆地图239号：嵌图标示 Birchtown 和 Black Town。原件索引：https://archives.novascotia.ca/maps/archives/?ID=225 。这是1798年的具名历史区域地图，适合未来进行地理配准和城镇落点核验。**目前没有经配准的WGS84线/多边形，也不能把1798聚落边界复制到1784年骚乱年份。**
- 1755年 Winslow 军官日记证实 Gaspereau、Canard、Habitant、Pero、Chépody、Petitcodiac 具名受袭村庄与日期。逐建筑事件的确切位置和历史村界没有逐宗地契/测绘对应，`MAP_PLACE_RESEARCH_V2.csv`仅留具名地点。
- Nooherooka 1713战斗，北卡州图书馆确认近今Snow Hill、Greene County，但现存防御工事与纪念/考古保护区不是英军统治区。需要州考古部门对原址位置坐标的正式资料后才能落具名点。
- Saint Vincent Garifuna、1796 Maroon、北美原住民作战路线等，本次未获得有据历史坐标，不绘造线段或武装影响Polygon。

## 二、坐标与图形判断

现有 `MAP_CANDIDATES.geojson` 保留第一轮22个官方现代遗址参考点。新增候选默认 `latitude=null`、`longitude=null`、`historical_control_boundary_verified=false`。后续只要证实*局部具名范围*但边线不确定，可考虑淡色虚线示意；当前材料中没有证明可画准确的领土多边形。公司商业站、王室法律纸面声索、编纂地图地点和军队短期占领分层。

## 三、跨世纪及独立年份

1798图证仅对应1798，1800年Jamaican Maroon从Halifax前往Sierra Leone是十九世纪事件，**不纳入1700—1799年代滑块**；1699年渔业法只有生效条款进入1700年的起始事件。\n'''
P('REFERENCE/MAP_CARTOGRAPHY_V2.md').write_text(map_note,encoding='utf-8')
conflict='''# 第二轮新增的重大争议与核验边界\n\n1. **1763 Fort Pitt**：6月24日军官及商人承认赠出来自天花病区的毯子，7月7、13、16日Amherst/Bouquet另行讨论以传播疾病攻击原住民。**先后时间不能颠倒，未证疾病传染成效和死亡数字**。核报账原件、Trent日记、两人信札，见 `R25/R26`。\n2. **1713 Nooherooka**：1713年同期亲殖民报纸的640死160俘，与北卡州史不同口径；这些是不同发表者的报道，不可累加且不当作准确总伤亡；要查战役逐人名册，见 `R14/R16/R17`。\n3. **1739 Stono人物**：NPS使用Cato，南卡历史研究常使用Jemmy，未经复核不能径直认作同一个人的两个实名；军事处刑、起义者被杀、被俘售卖分别记录，见 `R11/R12`。\n4. **1755 Winslow 2242**：日记记Winslow1510/Osgood732；加拿大公园局的Les Mines约2200可能依此史料而来，不当独立证据、不能求和。另日志11月毁建筑255/276/155/11/1这些项目分类，不当死亡人口。\n5. **1793 Upper Canada**：公园局明确记录法律未立即释放既有被奴役者；先前某政府综述写法过度概括。1793年7月3日是法定新生子女分界日期，7月9日是安大略档案所记通过日期，两者不同。\n6. **1741纽约**：`R10`法院史30人被判死刑、70人判加勒比奴役，但另外一页另列实际处决13烧18绞=31；应核罪名/最终处决名单和妇女/白人类别，不能把判死人数直接当实际处决精确数。\n7. **1781 Zong**：SlaveVoyages航次估计被迫登船440、抵岸208，两者相差232含疾病、被杀和其他因素，绝不使用232作为宗号谋杀精确人数。伦敦博物馆同页130与133不同语句本身需核法庭文书和投海日别记录。\n8. **1760牙买加**：1760-12-18通过反起义法，1761-01-01生效；Obeah、佩章、刑事威胁是法令规定，没有法庭名册不能给执行人数。\n9. **1784 Shelburne**：20户住房毁坏来自新斯科舍博物馆的回顾，尚待同代骚乱调查/赔款档；1798地图的Black Town是后时点测绘，不能倒推1784冲突范围。\n10. **1761 Cherokee**：报告毁15镇与15000英亩作物为汇总史研究估值，不是从英国军占获得的土地面积；1759人质条款/1761原住民边界要逐段核原约。\n11. **法律编年**：UNB部分殖民法规后台采用某年一月一日作为标准化年日期，例如百慕大1730法，未核通过日时应仅登记年份。\n12. **地理来源独立性**：档案馆同一幅1798 Holland海图在两URL展示不算两份独立测绘。现代站点参考GPS不是现场18世纪事件定位。\n'''
with P('GAPS_AND_CONFLICTS.md').open('a',encoding='utf-8') as f:f.write('\n\n## 2026-11-08第二轮重要冲突和来源精读\n\n'+conflict)
summary={
 'old_events':len(base['events'])-len(added),'new_events':len(added),'all_events':len(base['events']),
 'new_sources':len(S),'all_sources':len(reg['sources']),'source_checked_claims':len(claim_rows),
 'dossiers_extended':len(grouped),'dossiers_total':len(index['topics']),'old_geo_points_retained':len(geo['features']),
 'new_geo_points':0,'unmapped_new_events':len(added),'named_historical_places_in_addendum':len(places),
 'day_precision_new':sum(e['date_precision']=='day' for e in added),
 'month_precision_new':sum(e['date_precision']=='month' for e in added),
 'year_precision_new':sum(e['date_precision']=='year' for e in added),
 'no_GitHub_writes':True,
}
P('REFERENCE/VALIDATION_V2.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
with P('PROGRESS.md').open('a',encoding='utf-8') as f:
 f.write(f'''\n\n## 第二轮深挖（2026-11-08｜本地增量保存）\n\n- 累计 **{summary['all_events']}件**事件候选（第二轮新增 **{len(added)}件**）；第二轮日级{summary['day_precision_new']}、月级{summary['month_precision_new']}、年级{summary['year_precision_new']}件。新增 {len(S)} 条来源，累计 **{len(reg['sources'])}条**。\n- 对 {len(grouped)} 份专题档案增补原件与行动细节，原49篇均保留。另有 {len(claim_rows)} 条争议／数量口径证据声明；新增史料地点 {len(places)} 条尚无可靠GPS（均空坐标）。原22候审Point不改动，历史多边形0，新增伪造坐标0。\n- 新增档案：`EVIDENCE_CLAIMS_V2.json`、`MAP_PLACE_RESEARCH_V2.csv`、`REFERENCE/MAP_CARTOGRAPHY_V2.md`，以及本地扩充脚本`REFERENCE/extend_v2.py`。\n- 关键新方向：原文Winslow 1755驱逐和烧村日记、1740南卡奴役法全文、1713 Tuscarora同代报纸、Cherokee 1760/1761毁村、1763 Fort Pitt天花策略、1793 Chloe Cooley/上加拿大法律、1784 Shelburne种族骚乱、1798历史地图、1715–17 HBC的Dene女性外交。\n- 审查态势：统计数字保留原统计者/分母；即便两URL也不必然独立同源。完成网页核实**不等于原始手稿或原海图亲自测量**；本批没有上传GitHub。\n''')
# Structural QA
assert len({e['id'] for e in base['events']})==len(base['events'])
assert all(set(e['source_ids'])<=set(by_source) for e in base['events'])
assert len({x['id'] for x in reg['sources']})==len(reg['sources'])
assert all(e.get('latitude') is None and e.get('longitude') is None for e in added)
assert all(ft['geometry']['type']=='Point' for ft in geo['features'])
assert len(list(P('TOPIC_DOSSIERS').glob('E18-*.md')))==49
P('REFERENCE/VALIDATION_V2.json').write_text(json.dumps({'result':'PASS','summary':summary,'all_new_sources_resolve':True,'unique_events':True,'geometry_no_invention':True,'topic_files_all_exist':True},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
# Zip just once at end, complete local research directory. No overwrite of GitHub.
zip_path=Path('/mnt/data/18c_assistant_A_americas.zip')
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(root.rglob('*')):
  if p.is_file() and '__pycache__' not in p.parts:z.write(p,p.relative_to(root.parent))
with zipfile.ZipFile(zip_path) as z:
 assert z.testzip() is None
 zip_members=len(z.namelist())
print(json.dumps(dict(summary,zip=str(zip_path),zip_members=zip_members,zip_bytes=zip_path.stat().st_size,sha256=hashlib.sha256(zip_path.read_bytes()).hexdigest()),ensure_ascii=False,indent=2))
