# 爱英TV 18世纪第一调查员 | 本地候审成果

- **唯一仓库参考**：[love-British-TV](https://github.com/1959124923wyz-sys/love-British-TV)，**研究草稿**：[PR #289](https://github.com/1959124923wyz-sys/love-British-TV/pull/289)。全部研究成果仅写本地，仓库无更动。
- 读取项目规范 `AGENTS.md` 与 `docs/templates/16c-story-map-standard/README.md`，PR的 `research/18c/MAJOR_TOPICS.json`、`SOURCE_REGISTRY.json`、`CROSS_CENTURY_STORY_CONTINUITY.json`、阿卡迪亚候审三文件及17世纪原专题12篇。
- 目录组织：`TOPIC_DOSSIERS/`为49个详查专题；`EVENT_CANDIDATES.json/.csv`为事件级登记；`SOURCE_REGISTRY.json`为来源逐项读取深度；`MAP_CANDIDATES.geojson`只含官方现代历史遗址代表点；`REFERENCE/`含统计口径、17世纪承接与PR289既有ID对应；`GAPS_AND_CONFLICTS.md`集中存疑。
- **编审控制**：所有数据`research_only`。日期只保留证据实有的年/月/日。商馆不是领土，欧洲领土声索不是原住民土地让渡，统计窗不同不能相加，现代遗址GPS不当史事GPS，无经证政治边界或航线不绘面线。
- `REFERENCE/build_research.py`包含本轮整理的事件、来源及可重生文件的代码，保留以便主编独立审核；运行该代码会重建本地文件并且不写GitHub。
