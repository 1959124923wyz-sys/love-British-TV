import json, csv, pathlib, hashlib, zipfile, collections, os, datetime, re
P=pathlib.Path('/mnt/data/18c_assistant_A'); J=lambda n:json.loads((P/n).read_text(encoding='utf8')); W=lambda n,o:(P/n).write_text(json.dumps(o,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
E=J('EVENT_CANDIDATES.json');S=J('SOURCE_REGISTRY.json');T=J('TOPIC_INDEX.json');
es=E['events'];ss=S['sources']; byid={s['id']:s for s in ss}; ee={e['id']:e for e in es};v4=[e for e in es if e.get('local_research_round')==4]
# Important fixes identified during fact-by-fact comparison of university-transcribed primary laws.
for s in ss:
 if s['url'].endswith('/laws/node/324'):
    s['url']='https://slaveryandfreedomlaws.lib.unb.ca/node/324';s['read_scope_note']+=' 已修正原始文书的真实可访问链接node/324。'
for e in es:
 if e['id'].startswith('E18A4-'):
    e['source_urls']=[byid[i]['url'] for i in e['source_ids']]
    t=T['topics']; windows={a['id']:a['research_window'] for a in t}; o=[]
    for tid in e['topic_ids']:
        if tid in windows and not(windows[tid]['start_year']<=e['year']<=windows[tid]['end_year']):o.append(tid)
    e['topic_window_alignment']='in_primary_window' if not o else 'outside_primary_window_related_process_only'
    e['topic_window_context_notice']=('该节点发生于研究母题窗口外，仅作连续制度及背景线索，不可宣称PR #289原母题已扩窗或已出版。' if o else None)
# Up-date known dates / supporting clauses
for e in v4:
 if '自由身份证书续期' in e['title']:
    e.update({'date_text':'1761-12-19','year':1761,'month':12,'day':19,'date_precision':'day','topic_window_alignment':'in_primary_window','topic_window_context_notice':None})
 if e['title']=='牙买加殖民议会资助武装追捕逃亡奴役者':
    e['historical_description_zh']='1718年原始法条准许组建自愿武装追捕队，对抓获或杀死一名14岁以上被称为“反抗者”的被奴役者设每名50牙买加流通镑的法定赏金，另赋予队员夺得未满14岁儿童作为财产的权利；条文还涉及给追捕者10镑和红十字标识衣物。此为制度暴力的极具体证据，实际俘虏儿童人数、奖金付款和死伤均未核实。'
    e['legal_amount_quoted']='14岁以上每人法律赏金50牙买加镑（抓捕或杀害）；未满14岁被俘儿童作为追捕人员的法定战利品；特定猎手10镑另有衣物。'
    e['observed_actual_payment']=None
 if e['title']=='牙买加议会限制自由有色者与原住民司法证言条件':
    e['title']='牙买加1748年有条件认可自由黑人、原住民和混血者互相作证'
    e['historical_description_zh']='1748年议会允许自由黑人、原住民与自由混血居民在彼此案件中宣誓作证；还规定此前曾为奴役者获释的人与生来自由者在特定刑案程序上的差异缩小，但不许向具有白人法定特权者直接以同等资格作证，获释未满六个月者仍不得凭本法作证。属于有限司法权利扩张与同时存在的歧视边界，不可一概写为“全面禁止作证”。'
 if e['title']=='牙买加1744年针对所谓叛乱施刑与具名Hector解放法律':
    e['historical_description_zh']='1744年牙买加法令扩大在被控谋划杀白人案中的死刑/流放裁量并追认既有审判，还具名解除Hector的奴役身份，规定给Hector一次30牙买加流通镑及终身每年30镑、给原主Thomas Fuller一次100镑。均为法律承诺，不能证明已支付或推算实际已处刑人数。'
    e['legal_amount_quoted']='Hector：一次30镑、每年30镑；原主Thomas Fuller：一次100镑（法律规定）'
    e['observed_actual_payment']=None
 if e['title'].startswith('1770年10月18日英国与Cherokee'):
    e['v4_date_event_nature']='1768 treaty separate; on 1770-10-18 meeting; text labelled Treaty Monday 1770-10-22; read in Council 1770-12-12'
# protect register sourceUrls across all events if URL replacement known; keep source id stable
for e in es:
 if 'V4002' in e['source_ids']:e['source_urls']=[byid[i]['url'] for i in e['source_ids']]
W('EVENT_CANDIDATES.json',E);W('SOURCE_REGISTRY.json',S)
# 33-row law matrix sync from final data
mp=P/'PRIMARY_LAW_CLAUSE_MATRIX_V4.csv'
with mp.open('w',encoding='utf-8-sig',newline='') as f:
    cols=['event_id','date_precision','date','topic_ids','action','actor','source_ids','primary_source_links','assertion_level','original_amount_exact','payment_confirmed','executions_confirmed','gps_status','gis_boundary_status','independent_second_source_per_claim','archive_to_verify','outside_research_topic_window']
    w=csv.DictWriter(f,fieldnames=cols);w.writeheader()
    for e in v4:
        w.writerow({'event_id':e['id'],'date_precision':e['date_precision'],'date':e['date_text'],'topic_ids':';'.join(e['topic_ids']),'action':e['title'],'actor':e['actor_entities_text'],'source_ids':';'.join(e['source_ids']),'primary_source_links':';'.join(byid[k]['url'] for k in e['source_ids']),'assertion_level':e['evidence_status'],'original_amount_exact':e.get('legal_amount_quoted',''),'payment_confirmed':'UNKNOWN','executions_confirmed':'UNKNOWN','gps_status':'null','gis_boundary_status':'none','independent_second_source_per_claim':'pending','archive_to_verify':'colonial council journal; parish trial records; Treasury ledgers; historic surveys; relevant Indigenous and Maroon records','outside_research_topic_window':'yes' if e['topic_window_alignment']!='in_primary_window' else 'no'})
fields=[]
for e in es:
 for k in e:
    if k not in fields:fields.append(k)
with (P/'EVENT_CANDIDATES.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
    for e in es:w.writerow({k:json.dumps(v,ensure_ascii=False) if isinstance(v,(dict,list)) else v for k,v in e.items()})
# Update indexed candidate counters and date precision; avoid outdated counts
for t in T['topics']:
    subset=[e for e in es if t['id'] in e['topic_ids']]
    t['candidate_event_count']=len(subset);t['v4_new_events_count']=sum(1 for e in subset if e.get('local_research_round')==4)
T['last_local_research_extension']['corrected_source_urls']=1
W('TOPIC_INDEX.json',T)
# fix two original topic dossier lines which had been generated before date correction, append revision note once
for tid in ['E18-A06','E18-A05','E18-A07']:
    p=P/'TOPIC_DOSSIERS'/f'{tid}.md';s=p.read_text(encoding='utf8')
    s+='\n> **第四轮勘误（原始法令逐条核查）**：1718年追捕法每名14岁以上所谓反抗者50牙买加镑法定赏金、对14岁以下儿童的夺取作为法定战利品；1744年Hector一次30镑与每年30镑、原主100镑；1748年自由人士是获得有条件的彼此作证权，并仍受身份差别限制；1761年自由证修法精确日期为12月19日。以当前JSON和PRIMARY_LAW_CLAUSE_MATRIX_V4.csv的最终字段为准。\n'
    p.write_text(s,encoding='utf8')
# per-report amendments
p=P/'DEEP_DIVES_V4'/'JAMAICA_1717_1751_PENAL_CAPITAL.md';s=p.read_text(encoding='utf8').replace('1718年自愿武装追捕法对抓捕或杀死一名年满14岁的被称“rebellious”奴役者规定每名50镑的法定奖赏','1718年自愿武装追捕法对抓捕或杀死一名年满14岁的被称“rebellious”奴役者规定每名50镑的法定奖赏');s+='\n**进一步核查结果**：1748年一项相关法令扩大了自由黑人、原住民与自由混血居民彼此之间作证的权利，同时仍排除向具有白人权利者作证、并对新获释者设六个月等待。来源：https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1748 。\n';p.write_text(s,encoding='utf8')
# Gaps appendix
p=P/'GAPS_AND_CONFLICTS.md';s=p.read_text(encoding='utf8')
a='\n## 第四轮新增高优先缺口与重要史料冲突｜2026-11-08\n\n'
a+='1. **1718追捕奖励与儿童俘虏实际数量**：法条确定£50/每名14岁以上被捕或杀害者，及儿童可被攫为追捕者个人财产，但没有实到财政支出或儿童押运售卖名册；查Jamaica Council Minutes及treasury vouchers。\n'
a+='2. **1739年Cudjoe条约1500英亩**：原法全文有面积和相对方位，没有可认证闭合界址；绝不把该面积填为英国实际占地。调查具体地籍和马龙社群文书。\n'
a+='3. **1744 Hector释放及费用**：一次£30和年金£30、原主£100是不同法定权利，是否实际发放、活到哪一年均未知。\n'
a+='4. **1760年18名具名解放者**：法令列有Moll与Congo Molly等女性、两位Billy；个体后续自由证、死亡登记与财政实际年金支付待找。\n'
a+='5. **1768 Hard Labour日期**：弗吉尼亚历史文书校订用1768-10-14，NPS另有10-17说法，故原事件仍月级，不擅自订定签署日。\n'
a+='6. **1770 Lochaber议事时点**：10-18是代表集会，10-22文书列Treaty议程，12-12 Council阅报；三者须各自对应档案政治阶段。\n'
a+='7. **1769贸易委员会评议六族/切罗基地权**：报告明确指多原住民族权利冲突；£10,460 7s 3d为报告记载礼物与金钱估值，不等于全体实际收妥或确认主权边界。\n'
a+='8. **1783 Saint Christopher处罚制度反面**：罚主500当地镑与可对受伤奴役者拘押拍卖并存；未核一宗真实处罚或受害者售卖案。\n'
a+='9. **1784 Bahamas身份审查**：证明不足后可能拍卖；即使认定自由者也可能要求三个月内离开或90当地镑担保。需查各岛实施与身份诉讼，不得将全群岛一起绘受控面。\n'
a+='10. **纽约1711市政劳役市场与1799美国州法主体**：1711市政指定地点有证，但精确今日街址须校18世纪岸线；1799纽约州法已属美国，不能计英国政府当年新殖民举动。\n'
a+='11. **1717 HBC Churchill River商站**：加拿大公园局仅写夏季，不要人为改“7月”；Thanadelthur、Dene、Cree之间不等同被英国占领。\n'
a+='12. **法律网站 `YYYY-01-01` 占位**：1744/1748/1749、1784等数据库提供的1月1日是检索日期非条约实际签署日，当前本地仅采用年份。\n'
a+='13. **审判/法案单方报告**：1772年Sam定罪火刑判决尚需执行记录；1774年Westmoreland“阴谋”为法律前言指控，不自动落实为已发生起义。\n'
a+='14. **日期与证据双层核对**：本批主要是UNB数据库刊行版旧法的现代转录，单条法令可证正文却不能充当被奴役者的证言，独立交叉查地方、大学及原住民史料。\n\n'
if '## 第四轮新增高优先缺口' not in s:p.write_text(s+a,encoding='utf8')
# status
md=P/'PROGRESS.md';old=md.read_text(encoding='utf8');count=collections.Counter(e['date_precision'] for e in es);npt=len(T['topics']); geo=J('MAP_CANDIDATES.geojson'); features=geo['features'];geo_old_num=len(features);
geo_pts=[x for x in features if x.get('geometry',{}).get('type')=='Point'];geo_lns=[x for x in features if x.get('geometry',{}).get('type') in ('LineString','MultiLineString')];geo_poly=[x for x in features if x.get('geometry',{}).get('type') in ('Polygon','MultiPolygon')]
cc=[x for x in es if x.get('latitude') is None and x.get('longitude') is None]
usr=(P/'TOPIC_DOSSIERS');v3=list((P/'DEEP_DIVES_V3').glob('*.md'));v4reports=list((P/'DEEP_DIVES_V4').glob('*.md'));urls={x['url'].rstrip('/') for x in ss};
today='2026-11-08'
header=f'''# 当前最新总计｜{today} 第四轮累计状态（旧版统计为历史记录，不要误认为最新）\n\n- **{len(es)}件独立事件候选**（第三轮277 + 本轮{len(v4)}件），**{len(ss)}条来源ID**（第三轮227 + 本轮33条；可识别独立URL {len(urls)}个）。\n- 时间精度：**{count['day']}件到日、{count['month']}件到月、{count['year']}件到年**。\n- 17世纪连续性与18世纪PR #289：A01–A22、C01–C27共**{npt}项原专题研究索引**，49份主档案保持完整；第三轮14篇深挖报告 + 第四轮**{len(v4reports)}篇**深挖报告；新增33件与12份主档案逐节衔接。\n- 地图：原有**{geo_old_num}个GeoJSON官方参照点**保持原状，**{len(cc)}件事件仍坐标为null**。**正式绘制新历史实控Polygon：{len(geo_poly)}；未经资料复原航线或历史边线LineString：{len(geo_lns)}**。新增20条具名地点研究索引只留空坐标。\n- 本轮新增：33件逐件事件、33条新来源、8份长篇报告、`PRIMARY_LAW_CLAUSE_MATRIX_V4.csv`（法条证据矩阵）、`BOUNDARY_CLAIM_EVIDENCE_V4.json`（仅文字和空几何）、`MAP_PLACE_RESEARCH_V4.csv`、`GEO_AND_CHRONOLOGY_AUDIT_V4.md`、主专题追加和冲突审计。\n- **性质**：`research_only`，所有数字来自法定条文、统计表或明确机构陈述；该来源已读线上转录不等于馆藏纸本已阅，档案部门实际支付、刑罚执行和可争议条约边界均待原卷确认。\n- **GitHub改动**：0；只对`/mnt/data/18c_assistant_A/`写入。下一步请深挖Blackwall 1765原议事录、HBC站点账与Dene口述、纽芬兰海岸法院档、巴哈马自由身份证明实际审判名册、牙买加个人年金支付记录、1768–1770条约原地图地理配准。\n\n---\n\n'''
if old.startswith('# 当前最新总计'):
 old='\n'.join(old.split('\n')[4:])
md.write_text(header+old,encoding='utf8')
# Final QA: import verification, consistent dates, original point type retained; no made-up geometry
assert len(es)==len({x['id'] for x in es}), 'duplicate event ids'
assert len(ss)==len({x['id'] for x in ss}), 'duplicate source IDs'
assert len(urls)==len(ss) or len(urls)<len(ss)
assert len(T['topics'])==49 and len(list(usr.glob('E18-*.md')))==49
assert all(e['publication_status']=='research_only' and e['publication_review']=='not_submitted' for e in v4)
for e in es:
    assert set(e['source_ids']).issubset(set(byid)),(e['id'],set(e['source_ids'])-set(byid))
    if e['day'] is not None:assert e['month'] is not None
    if e.get('local_research_round')==4:
        assert e['latitude'] is None and e['longitude'] is None and e['area_sqkm'] is None
        assert all(u.startswith('https://') for u in e['source_urls'])
assert len(geo_poly)==0 and len(geo_lns)==0
with (P/'EVENT_CANDIDATES.csv').open(encoding='utf-8-sig') as f:
   csv_rows=list(csv.DictReader(f))
assert len(csv_rows)==len(es) and {x['id'] for x in csv_rows}=={x['id'] for x in es}
with (P/'PRIMARY_LAW_CLAUSE_MATRIX_V4.csv').open(encoding='utf-8-sig') as f: assert len(list(csv.DictReader(f)))==len(v4)
# verify no strings with mislabeled extension and no phantom day for data source placeholders
source_1718=next(s for s in ss if s['url'].endswith('/node/324'));assert not '/laws/node' in source_1718['url']
probs=[]
for e in v4:
  if e['date_precision']=='day' and not re.fullmatch(r'\d{4}-\d{2}-\d{2}',e['date_text']):probs.append(e['id'])
assert not probs,probs
qa={'date':'2026-11-08','schema':'local-americas-historical-research-round4-check-v1','events_total':len(es),'v4_new_events':len(v4),'sources_total':len(ss),'v4_new_source_ids':len([s for s in ss if s['id'].startswith('V4')]),'unique_source_urls':len(urls),'topic_main_reports':len(list(usr.glob('E18-*.md'))),'deep_dive_v3':len(v3),'deep_dive_v4':len(v4reports),'date_precision':dict(count),'historical_geojson_point_features':len(geo_pts),'geojson_lines':len(geo_lns),'geojson_polygons':len(geo_poly),'events_missing_coordinates':len(cc),'new_v4_coordinates':0,'map_named_research_places_v4':20,'new_law_clause_csv_rows':len(v4),'checks':['unique event & source ID','all source IDs exist','all new event coords null','no polygons or lines','date precision shape','CSV/JSON parity','49 topic dossiers remain','33 row law matrix','UNB URL normalized'],'github_modified':False,'publication_status':'research_only'}
W('REFERENCE/VALIDATION_V4.json',qa)
# manifest file listing, checksums
files=[x for x in P.rglob('*') if x.is_file() and x.name not in ('MANIFEST_V4.json',)]
manifest={'schema':'local-file-manifest-round4-v1','timestamp':'2026-11-08','note':'SHA256 files in directory before ZIP, excludes self MANIFEST_V4.json','files_count_excluding_manifest':len(files),'files':[{'path':str(f.relative_to(P)),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'size_bytes':f.stat().st_size} for f in sorted(files)]}
W('MANIFEST_V4.json',manifest)
zip_path=pathlib.Path('/mnt/data/18c_assistant_A_americas.zip'); tmp=zip_path.with_suffix('.zip.tmp')
with zipfile.ZipFile(tmp,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for f in sorted(x for x in P.rglob('*') if x.is_file()):z.write(f,arcname='18c_assistant_A/'+str(f.relative_to(P)))
with zipfile.ZipFile(tmp) as z:
 assert z.testzip() is None
 assert len(z.namelist())==len(list(P.rglob('*')))-len([x for x in P.rglob('*') if x.is_dir()])
 for k in ['EVENT_CANDIDATES.json','EVENT_CANDIDATES.csv','SOURCE_REGISTRY.json','TOPIC_INDEX.json','PRIMARY_LAW_CLAUSE_MATRIX_V4.csv','MANIFEST_V4.json','PROGRESS.md']:
  assert '18c_assistant_A/'+k in z.namelist()
tmp.replace(zip_path)
qa['zip_bytes']=zip_path.stat().st_size;qa['zip_files_count']=len(list(P.rglob('*')))-len([x for x in P.rglob('*') if x.is_dir()]);
print(json.dumps(qa,ensure_ascii=False,indent=2))
