from pathlib import Path
import json,csv
R=Path('/mnt/data/18c_assistant_A');ep=R/'EVENT_CANDIDATES.json';sp=R/'SOURCE_REGISTRY.json';ip=R/'TOPIC_INDEX.json';ev=json.loads(ep.read_text());reg=json.loads(sp.read_text());idx=json.loads(ip.read_text());t={x['id']:x for x in idx['topics']}
newsource={
 'PORTO_RMG':('Royal Museums Greenwich', 'The Capture of Puerto Bello, 21 November 1739', 'https://www.rmg.co.uk/collections/objects/rmgc-object-11846', 'full_public_museum_object_narrative','1739 Nov 21 attack Iron Castle; Nov 22 Spanish capitulation; money distribution, removal fortifications; sum in capitulation not evidence cash transferred'),
 'CART_RMG':('Royal Museums Greenwich','Medal commemorating Vernon attack on Cartagena, 1741','https://www.rmg.co.uk/collections/objects/rmgc-object-38515','public_museum_object_catalogue','Cartagena attacked April 1741, British failed despite propaganda medals falsely depicting Spanish surrender'),
 'EUST_ABBA':('Guido Abbattista, Cromohs scholarly journal','Edmund Burke, the Atlantic American war and the poor Jews at St Eustatius','https://oajournals.fupress.net/index.php/cromohs/article/download/16454/14912?inline=1','read_scholarly_html_full_article','1781 Feb3 Rodney Vaughan seize Dutch island; Feb13 forcible search and exile Jewish male heads; Feb16 Hebrew Nation petition; 30 Mar Crown property instructions; historian disputes whether Rodney motive specifically antisemitic'),
 'EUST_MARIT':('The Mariner’s Mirror, scholarly journal','Making Money from the Royal Navy in the Late Eighteenth Century: Charles Kerr on Antigua','https://doi.org/10.1080%2F00253359.2021.1978257','read_peer_reviewed_html','1781 Feb3 St Eustatius surrendered to Rodney Vaughan, 130 ships at anchor seized and further seizures, legal disputes of prize money'),
 'EUST_HIST':('J Franklin Jameson, American Historical Review historical text at UChicago','St Eustatius in the American Revolution (1903)','https://penelope.uchicago.edu/Thayer/E/Journals/AHR/8/4/StEustatius_in_the_American_Revolution%2A.html','read_historical_secondary_html','1781 English seizure, merchant protests to UK Parliament, Edmund Burke debate, archival documents',),
}
urls={s.get('url','').rstrip('/'):s['id'] for s in reg['sources'] if s.get('url')}
names={}
for key,(inst,title,url,scope,facts) in newsource.items():
 if url.rstrip('/') not in urls:
  sid=f'R7{1+len([x for x in reg["sources"] if x["id"].startswith("R7")]):03d}'
  reg['sources'].append({'id':sid,'author_or_institution':inst,'institution':inst,'title':title,'url':url,'type':'scholarly_or_museum_public_html','access_level':scope,'actually_read_scope':facts,'original_manuscript_personally_inspected':False,'manuscript_inspected':False,'supported_event_candidate_ids':[],'supported_topic_ids':[],'access_verified_at':'2026-11-08','read_scope_note':'公开网页/学术研究，不是亲阅历史原卷；奖章图案与实际战争结果必须相互区别。'})
  urls[url.rstrip('/')]=sid
 names[key]=urls[url.rstrip('/')]
previous_ids={e['id'] for e in ev['events']};new=[]
def add(name,date,title,description,actors,place,topic,keys,category='military_action',conflict=None,quant=None):
 year=int(date[:4]);month=int(date[5:7]) if len(date)>=7 else None;day=int(date[8:10]) if len(date)>=10 else None;id=f'E18A7-{year}-{name}'
 assert id not in previous_ids
 sids=[names[k] for k in keys];surls=[next(z['url'] for z in reg['sources'] if z['id']==s) for s in sids]
 e={'id':id,'date_text':date,'year':year,'month':month,'day':day,'date_precision':'day' if day else 'month' if month else 'year','topic_ids':topic,'title':title,'actor_entities_text':actors,'historical_description_zh':description,'historical_place_name':place,'longitude':None,'latitude':None,'modern_reference_site':None,'geo_precision':'no_verified_coordinate','coordinates_support_sources':[],'source_ids':sids,'source_urls':surls,'source_support_count':len(set(surls)),'claim_crosscheck_status':'independent_institutional_recheck_pending' if len(sids)<2 else 'two_sources_per_claim_still_review','evidence_status':'research_only','previous_17c_story_ids':sorted({q for t1 in topic for q in t[t1].get('previous_story_ids',[])}),'historical_control_boundary_verified':False,'political_claim_not_actual_control':True,'actual_military_control_polygon':False,'area_sqkm':None,'historical_line_or_route_surveyed':False,'estimated_casualties_count':None,'estimated_trade_sum':None,'publication_status':'research_only','publication_review':'not_submitted','local_research_round':7,'impact_category':category,'quantitative_qualification':quant,'source_conflict_note':conflict}
 new.append(e)
 for s in sids:
  x=next(z for z in reg['sources'] if z['id']==s);x['supported_event_candidate_ids'].append(id);x['supported_topic_ids']=sorted(set(x.get('supported_topic_ids',[])+topic))
add('PORTO-IRON-FORT','1739-11-21','英国皇家海军Vernon舰队炮击巴拿马Portobelo的Iron Castle','英国海军Vernon指挥六艘战舰围攻巴拿马加勒比岸的Puerto Bello/Portobelo，11月21日下午炮击其港口Iron Castle防御设施；原有居民与西班牙驻军是不同角色。','Admiral Edward Vernon; Spanish defenders','Iron Castle, Puerto Bello / Portobelo, Panama',['E18-A19'],['PORTO_RMG'],'colonial_port_assault')
add('PORTO-SURRENDER','1739-11-22','Portobelo西班牙总督向Vernon投降，英国海军缴获财物并拆堡','皇家格林尼治博物馆记11月22日当地西班牙总督接受英军投降条件，英国海军缴获船只和军械，分配驻军公款并拆毁堡垒。投降书中约定的一万美元及战利品不能自动视为实际伦敦财政收益。','Vernon fleet; Governor Francisco Martínez de Retez','Portobelo, Panama',['E18-A19'],['PORTO_RMG'],'temporary_occupation_and_seizure',quant='馆藏记投降条款为十千美元，不等于财库实得、海员获益或英国财政净额。')
add('CARTAGENA-SIEGE-FAILED','1741-04','英国海陆军大规模进攻Cartagena de Indias但未攻下城市','Vernon和其他英国将领在1741年4月攻打西属哥伦比亚Cartagena de Indias，西班牙守军由Blas de Lezo等组织成功防御。英国纪念奖章曾预刻“英军占领”，与真实战斗结果相反；不能将奖章字句当成控制改变。','Admiral Edward Vernon; General Wentworth; Blas de Lezo','Cartagena de Indias / Boca Chica, Colombia',['E18-A19'],['CART_RMG'],'failed_imperial_conquest',conflict='英国纪念奖章印有“占领卡塔赫纳”，皇家博物馆正文明确判定1741年攻击失败。')
add('STATIA-CAPTURE','1781-02-03','英国Rodney与Vaughan联合远征夺取荷属圣尤斯特歇斯岛','英国舰队和陆军要求荷兰总督De Graaff投降并占领加勒比自由贸易港圣尤斯特歇斯；随后收取泊港船舶和仓储货物。占领港口与收缴商货相互有关，却不意味当地所有私人资产都依法成为皇家财产。','Admiral George Brydges Rodney; General John Vaughan; Governor Johannes de Graaff','Oranjestad, St Eustatius',['E18-A19','E18-A04'],['EUST_ABBA','EUST_MARIT','EUST_HIST'],'occupation_and_mercantile_seizure',quant='在港130余艘与后续200余艘为不同阶段及不同来源估数，不得相加。')
add('STATIA-SEARCH-DEPORT','1781-02-13','英国驻军对圣尤斯特歇斯犹太商人集体搜身、没收财物并驱逐多人','Abbattista依据当时请愿和英国议会记录，记2月13日英国军方特别要求犹太男性户主接受搜查，没收钱物并将约30人驱逐；其他商人亦被没收资产。宗教歧视是否为指挥官唯一动机在学术讨论中有不同解释。','Rodney/Vaughan occupation forces; Sephardic Jewish community','Oranjestad waterfront, St Eustatius',['E18-A19'],['EUST_ABBA'],'ethnic_religious_targeted_deportation',quant='“约30人”是学术文章引用当代资料的被驱逐户主规模，不能自动当全部犹太人口或实际抵达St Kitts人数。',conflict='研究者在“指挥官是否出于反犹主义动机”上存分歧；可确认区别对待及个体驱逐、搜查。')
add('STATIA-HEBREW-PETITION','1781-02-16','圣尤斯特歇斯犹太居民集体请愿反对英国军官驱逐与没收','圣尤斯特歇斯犹太社区在2月16日向英国占领军提出请愿，追问对其家庭驱逐、没收财产的法理依据；他们也援引自己或亲属的英国臣民身份和信仰自由的权利。诉求和英方对它的回应分别记录。','Hebrew nation petitioners; Rodney and Vaughan','St Eustatius, Dutch Caribbean',['E18-A19'],['EUST_ABBA'],'local_political_resistance')
add('STATIA-PRIZE-INSTRUCTIONS','1781-03-30','英国王室向Rodney及Vaughan发出占领所得与私人产权限制指示','学术论文引1781年3月30日王室指示，限制可合法没收财物类别，包括对居民个人财物的保护，文件直到4月才送抵军官。发布命令与实际返还需要查逐船拍卖及后续诉讼，不可假设已赔偿。','British Crown; Admiralty; Rodney and Vaughan','London to St Eustatius, legal instruction only',['E18-A19'],['EUST_ABBA','EUST_MARIT'],'colonial_policy_legal_limit',conflict='3月30日文件发出与4月抵达军营是两个阶段；未证每件被没收财物已返还。')
add('STATIA-SEIZURE-AUCTIONS','1781-03','英国占领军在圣尤斯特歇斯组织缴获货物拍卖与战利品处置','1781年2—3月，英军登记泊港船只与仓储货物并组织拍卖，许多商人财物被收缴。伦敦贸易商、犹太商人与荷兰居民围绕财物归属提出异议，英国方面出现大量诉讼。登记/估值/实际变现净额必须区分。','Rodney prize agents; merchants of St Eustatius','Oranjestad lower town warehouses, St Eustatius',['E18-A04','E18-A19'],['EUST_ABBA','EUST_MARIT','EUST_HIST'],'mass_confiscation_mercantile',quant='争议估值约200—300余万英镑属于当代不同估价，不是英王实际收到可核净收益。')
# Commit additive data
EV=ev['events'];EV.extend(new)
for x in idx['topics']:
 x['candidate_event_count']=sum(x['id'] in e.get('topic_ids',[]) for e in EV)
 x['v7_new_events_count']=sum(x['id'] in e.get('topic_ids',[]) and e.get('local_research_round')==7 for e in EV)
 x['source_ids']=list(dict.fromkeys(x.get('source_ids',[])+[s for e in new if x['id'] in e['topic_ids'] for s in e['source_ids']]))
for tid in sorted({q for e in new for q in e['topic_ids']}):
 with (R/'TOPIC_DOSSIERS'/f'{tid}.md').open('a') as f:
  f.write('\n\n## 第七轮第三批｜Portobelo/Cartagena/St Eustatius商货与军事占领\n')
  for e in new:
   if tid not in e['topic_ids']:continue
   f.write('\n### '+e['date_text']+' '+e['title']+' ['+e['id']+']\n\n'+e['historical_description_zh']+'\n\n来源：'+', '.join(e['source_ids'])+'。地点：'+e['historical_place_name']+'。无证据实控Polygon。\n')
for path,obj in [(ep,ev),(sp,reg),(ip,idx)]:path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
cp=R/'EVENT_CANDIDATES.csv'
with cp.open(encoding='utf-8-sig',newline='') as f:cols=csv.DictReader(f).fieldnames
cols=list(dict.fromkeys(cols+[k for e in ev['events'] for k in e]))
with cp.open('w',encoding='utf-8-sig',newline='') as f:
 wr=csv.DictWriter(f,fieldnames=cols);wr.writeheader()
 for e in ev['events']:wr.writerow({k:json.dumps(v,ensure_ascii=False) if isinstance(v,(list,dict)) else '' if v is None else v for k,v in e.items()})
print('ROUND7_FINAL_GAP_EVENTS',len(new),'EVENTS_TOTAL',len(ev['events']),'SOURCE_TOTAL',len(reg['sources']))
