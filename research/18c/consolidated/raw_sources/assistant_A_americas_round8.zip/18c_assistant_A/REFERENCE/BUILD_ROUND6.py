#!/usr/bin/env python3
"""Sixth research-only, additive local package build. No GitHub writes; no invented coordinates."""
import csv, json, hashlib, zipfile, pathlib, collections, datetime, re
from copy import deepcopy
BASE=pathlib.Path('/mnt/data/18c_assistant_A')
def load(name):return json.loads((BASE/name).read_text(encoding='utf-8'))
def save(name,obj):
 p=BASE/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def md(name,s):
 p=BASE/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s.rstrip()+'\n',encoding='utf-8')
E=load('EVENT_CANDIDATES.json');S=load('SOURCE_REGISTRY.json');T=load('TOPIC_INDEX.json');G=load('MAP_CANDIDATES.geojson')
old_e=len(E['events']);old_s=len(S['sources']); current_ids={e['id'] for e in E['events']}; source_ids={s['id'] for s in S['sources']};existing_urls={s['url']:s['id'] for s in S['sources']}
# Verified online texts read in November 2026. A source record is NOT an independent fact check on every claim.
sources=[
('V6001','University of New Brunswick · Laws of Enslavement and Freedom','South Carolina 1712 Act, baptism does not manumit','https://slaveryandfreedomlaws.lib.unb.ca/laws/south-carolina-1712-0','transcribed_primary_legislation_read','1712-06-07 and clause XXXIV from Trott 1736 pp.212–213',True),
('V6002','University of New Brunswick · Laws of Enslavement and Freedom','North Carolina 1723 tax and removals','https://slaveryandfreedomlaws.lib.unb.ca/laws/north-carolina-1723','transcribed_primary_legislation_read','1723 tax on free mixed people age 12+, return of formerly enslaved subject to labor; website Jan 1 only index day',True),
('V6003','University of New Brunswick · Laws of Enslavement and Freedom','South Carolina 1726 plantation white labour ratio law','https://slaveryandfreedomlaws.lib.unb.ca/laws/south-carolina-1726','transcribed_primary_legislation_read','1726-03-11 assent by Middleton; 2 white employees and one extra per ten enslaved men over 20',True),
('V6004','University of New Brunswick · Laws of Enslavement and Freedom','Maryland 1729 severe punishment statute','https://slaveryandfreedomlaws.lib.unb.ca/laws/maryland-1729','transcribed_primary_legislation_read','ch.IV punishment in statute; day 1729-07-01 in archive is INEXACT',True),
('V6005','University of New Brunswick · Laws of Enslavement and Freedom','South Carolina 1740 slave code full transcription','https://slaveryandfreedomlaws.lib.unb.ca/laws/south-carolina-1740','transcribed_primary_legislation_read','1740-05-10; inheritance, civil freedom suit, patrol, punishment, owner compensation, gathering restrictions; law != execution',True),
('V6006','University of New Brunswick · Laws of Enslavement and Freedom','North Carolina 1741 servant and slave law','https://slaveryandfreedomlaws.lib.unb.ca/laws/north-carolina-1741','transcribed_primary_legislation_read','sections XIV, XXIII and XXIV incl free-people enslavement complaints',True),
('V6007','University of New Brunswick · Laws of Enslavement and Freedom','Jamaica 1797 age-related slave import duty','https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1797-1','transcribed_primary_legislation_read','assembly Dec18; council Dec20; assent Dec23 1797; operative Dec31 1798; expires Dec31 1801; statutory £10 != receipts',True),
('V6008','University of New Brunswick · Laws of Enslavement and Freedom','Dominica 1798 runaway slave capture and sale law','https://slaveryandfreedomlaws.lib.unb.ca/laws/dominica-1798','transcribed_primary_legislation_read','assembly Sep28 1797; council Apr27 1798; Roseau Apr30 1798; internally contradictory assent Mar15 1793',True),
('V6009','University of New Brunswick · Laws of Enslavement and Freedom','Dominica 1798 ban aid to fugitives and restricted testimony','https://slaveryandfreedomlaws.lib.unb.ca/laws/dominica-1798-0','transcribed_primary_legislation_read','named legal prohibitions, modes of testimony and punishment; do not claim executions',True),
('V6010','University of New Brunswick · Laws of Enslavement and Freedom','Jamaica 1799 act on Saint-Domingue-connected captive population','https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1799','transcribed_primary_law_abstract_read','catalogue Jan1 only approximate; actual enactment day unknown; 6-month forced removal clause and exceptions; 1819 Lunan digest',True),
('V6011','Bristol PortCities / Discovering Bristol','The fortunes of four ships: Prince of Orange, Marlborough, Juba, African Queen','https://www.discoveringbristol.org.uk/slavery/routes/bristol-to-africa/shipping/four-ships-fortunes/','institutional_maritime_history_read','source has named ships captains owners figures and some quoted letters; individual ship logs NOT inspected',False),
('V6012','Colonial Williamsburg','Slavery and the Virginia Gazette: runaway notices','https://www.colonialwilliamsburg.org/discover/sources/the-virginia-gazettes/slavery-and-the-virginia-gazette/','museum_primary_newspaper_excerpts_read','date/page of newspaper notices for Peter, Amy, Sam, John Hedgman, John Newton, Jack; 1745 Rind printer attribution doubtful',False),
('V6013','Colonial Williamsburg','Underground Allies: incomplete story of Fanny and Moses','https://www.colonialwilliamsburg.org/discover/18th-century-people/stories-of-black-life/underground-allies-the-incomplete-story-of-fanny-and-moses/','museum_primary_ad_and_interpretation_read','Fanny fled 1773-10-18, advertised Jan27 1774; enslaver suspicions about Moses not established facts',False),
('V6014','Colonial Williamsburg','Escaping to Freedom: Virginia Dunmore and Willoughby petition','https://www.colonialwilliamsburg.org/discover/18th-century-people/stories-of-women/escaping-to-freedom/','museum_petition_and_ledger_excerpts_read','Willoughby reported 87 escaped by Apr14 1776; petition Jun03 1777; Randolph women fled 1781; codicil 1782 Jul20',False),
('V6015','Nova Scotia Archives','Book of Negroes 1783 description and British return of Betty','https://archives.novascotia.ca/africanns/book-of-negroes/','provincial_archive_digitized_primary_context_read','PRO 30/55/100; registration Apr23-Nov30 1783 ~3000; Betty returned to claimant Thomas Smith',True),
('V6016','Nova Scotia Archives','Black Pioneers petition Thomas Peters and Murphy Steel','https://archives.novascotia.ca/africanns/archives/?ID=32','provincial_archive_primary_description_read','date 20(?) Aug1784; original RG1 vol359 no65; one acre Digby in 1785',True),
('V6017','Nova Scotia Archives','1792-01-07 Bulkeley draft commission to John Clarkson','https://archives.novascotia.ca/diaspora/archives/?ID=17&Page=201112037&Transcript=1','provincial_archive_volunteer_transcription_read','draft commission dated 1792-01-07, not individually approved transport execution',True),
('V6018','National Park Service U.S. / Dictionary of Canadian Biography','John Bradstreet northern expedition and conditional peace','https://www.nps.gov/people/john-bradstreet.htm','government_history_read','Aug12 1764 Presque Isle and Aug27 Detroit; Gage disavowed; online page erroneously says born 1914 elsewhere',False),
('V6019','University of Toronto / University of Laval biographical scholarship','John Bradstreet biography','https://www.biographi.ca/en/bio/bradstreet_john_4E.html','scholarly_biography_read','supports 1764 Aug12 and Aug27; age and birthplace contrasted with NPS erroneous 1914 metadata',False),
('V6020','Colonial Williamsburg journal research','Runaway advertisement Poplar and Planter 1736','https://research.colonialwilliamsburg.org/Foundation/journal/Autumn10/ads.cfm','museum_newspaper_excerpt_read','Nov5 1736 Virginia Gazette; Poplar and Planter earlier escapes; newspaper notices not proof of recapture',False),
('V6021','National Park Service U.S.','Jay Treaty British evacuation of forts discussion','https://www.nps.gov/articles/jay-s-treaty.htm','government_historical_summary_read','1794 Jay Treaty versus 1796 handovers, separate treaty and actual military control',False),
('V6022','Charleston County Public Library','Stono rebellion geographical and witness investigation','https://www.ccpl.org/charleston-time-machine/stono-rebellion-1739-where-did-it-begin','regional_library_historical_research_read','Stono river site not exact all battlefield geometries; avoid colonial reported death totals as measured',False),
('V6023','Making Freedom History primary source edition','William Bull 1739 October 5 letter reporting Stono rebellion','https://makingfreedomhistory.org/source/william-bulls-october-5-1739-letter-describing-the-stono-rebellion/','historical_primary_letter_transcription_context_read','1739-10-05 colonial official account; partisan estimates not independent demographic totals',True),
]
for sid,inst,title,url,typ,scope,primary in sources:
 if sid in source_ids: raise ValueError('source id collision')
 if url in existing_urls: raise ValueError('duplicate source URL '+url)
 S['sources'].append({'id':sid,'author_or_institution':inst,'title':title,'url':url,'type':typ,'actually_read_scope':scope,'manuscript_inspected':False,'read_scope_note':'2026-11-08在线全文、馆方展示、摘要与转录按此条reading level区分；未亲阅原件手稿；相同网页的多事件不算多条独立来源。','supported_event_candidate_ids':[],'supported_topic_ids':[],'access_verified_at':'2026-11-08','primary_source_type':primary,'separate_source_identity_note':'数字转录与原作者同一文献；两个机构转载同一原文不能自动视为两个独立验证。'})
source_lookup={s['id']:s for s in S['sources']};topics={t['id']:t for t in T['topics']}
# fields: date, title, actor, historical place, statement, source IDs, topic IDs, optional warnings; all names are evidence-bound locations, coordinates remain null.
records=[
('1712-06-07','南卡殖民议会规定基督教洗礼不得改变被奴役法律身份','南卡罗来纳殖民议会与总督Charles Craven','Charles Town / South Carolina','1712年6月7日法令第XXXIV条允许受洗但拒绝因基督教洗礼获得自由；该法本身未证明任何个体受洗后被怎样处置。','V6001','E18-C21'),
('1723','北卡殖民议会向12岁以上自由黑人及混合血统居民征收人头税','北卡罗来纳领主政府与殖民议会','Edenton, North Carolina','法条对12岁及以上自由黑人与混合血统居民规定税负，并涉及与该群体结婚的白人；1月1日为目录归档推定日，真实通过日未知。','V6002','E18-C21'),
('1723','北卡法条规定已获释者离境义务并惩罚重新入境','北卡殖民议会','North Carolina','法律指出获释者应于六个月内离境，并修订重新进入辖区者的拘捕/劳动处罚；它陈述既存和新增法律，未证明卖身/驱逐已发生的人数。','V6002','E18-C21'),
('1726-03-11','南卡法令强制种植园主配置白人雇员监控奴役劳动','南卡殖民议会与Arthur Middleton','Charles Town / South Carolina','条例要求拥有被奴役者的庄园至少雇两名白人，并按超过20名男性被奴役者后每10人增加一名白人；标准是法律义务，不是落实名单。','V6003','E18-C21'),
('1729','马里兰议会授权对被奴役重罪犯施行肢解及死刑','马里兰领主殖民议会','Maryland','针对被奴役者被裁定特定杀人、纵火罪行，允许砍手、绞刑和分尸展示；目录日期1729-07-01注明inexact，记录年精度。','V6004','E18-C22'),
('1736','Prince of Orange号从布里斯托尔经营奴役航次','船东Richard Farr & Co；船长Japhet Bird','Bristol / West African coast','馆方记载1736年航次并在西非购买、跨海贩运被奴役者；船期具体日和非洲交易点尚待原航次账。','V6011','E18-A01,E18-A04'),
('1736','Prince of Orange号载运者在圣基茨附近跳海抵抗','非洲被奴役者；船长Japhet Bird与船员','near Saint Kitts (St Kitts)','同一1736航次馆方记约100名男性跳海，33人溺亡，船长售出240名；实际海上位置、哪一天靠近圣基茨以及各人后来命运未知。1736航次与个别来源1737到达区分。','V6011','E18-A01,E18-A19'),
('1736-11-05','弗吉尼亚Gazette刊登Poplar与Planter两名逃亡者追捕广告','被奴役者Poplar、Planter；登广告奴隶主','Williamsburg, Virginia (newspaper publication)','1736-11-05刊报，两人实际出走分别早于刊报。Poplar被奴隶主称为outlawed是对方法律话语；刊报地点不等于逃亡GPS。','V6020','E18-C22'),
('1741','北卡奴役法规将交易与逃亡追捕纳入殖民地法院程序','北卡罗来纳议会','North Carolina','1741年仆役与奴役法律规定未经主人许可不得与被奴役者交易、对部分不法将自由人当奴隶出售者设置诉讼权；其自由权诉讼仍有差别待遇。','V6006','E18-C21'),
('1752-03','奴隶船Marlborough号由布里斯托尔前往西非','船东William Lougher & Co；船长Robert Codd','Bristol / Anomabu / Bonny','1752年3月离港，沿黄金海岸及博尼购买并非法商品化人口；后续西非地区航次各站具体天数未知。','V6011','E18-A01,E18-A04'),
('1752-10','Marlborough号被奴役者反抗、控制船舶并返回博尼','船上被奴役非洲人；船长Robert Codd；船员','off Bonny, West Africa (location approximate, no coordinate)','馆方记至10月购入420人、启航约三天发生反抗，舰被迫返Bonny；来源对不同地区被奴役者去向有记述，船的最终去向未证，海上位置保留null。','V6011','E18-A01,E18-A20'),
('1753-03-31','幸存水手John Harris对Marlborough反抗的书信见报','船员John Harris；Felix Farley’s Bristol Journal','Bristol (publication place)','馆方指出1753年3月31日报纸刊载John Harris致父亲关于Marlborough事件的书信；没有亲阅报纸扫描，证据等级为博物馆引述。','V6011','E18-A04'),
('1764-08-12','Bradstreet在Presque Isle与原住民代表达成临时议和条件','英军John Bradstreet；德拉瓦与肖尼等原住民代表','Fort Presque Isle / Erie area','Bradstreet试图与代表达成暂行和平安排；Gage后来否认其越权和约效力，不应画成英国军事征服原住民全境。','V6018,V6019','E18-C12'),
('1764-08-27','Bradstreet抵达底特律后继续与原住民谈判','英军John Bradstreet；大湖原住民族代表','Fort Detroit / Detroit River','英军到达底特律，继续交涉和平与堡垒供给；不同代表诉求和权利仍在，不因英方驻堡直接消失。','V6018,V6019','E18-C12'),
('1769-02-09','弗吉尼亚Gazette记载Peter擅长写通行证以逃避奴役追捕','被奴役者Peter；声索人William Macon','Williamsburg (newspaper) / Virginia','William Macon在广告中抱怨Peter能读写、曾自行写通行证；这反映抵抗技术，是奴隶主的指控而非独立取得的Peter证言。','V6012','E18-C22'),
('1769-11-09','弗吉尼亚Gazette刊登追捕Amy广告，记述以服饰争取自由','被奴役女性Amy；奴隶主Parker Hare','Williamsburg, Virginia (newspaper)','报纸称Amy约30岁，携银扣及换洗衣物外逃，可能借衣着被视为自由人；具体逃亡日期、地点未证，刊报时间确证。','V6012','E18-C22'),
('1771-01-10','弗吉尼亚Gazette刊登追捕Sam及三人的广告','被奴役者Sam等四人；奴隶主James Walker','Williamsburg, Virginia (newspaper)','广告记载Sam遭鞭打旧伤，以及四名被奴役者离开；报纸奴隶主的定性不可当作抵抗者自身主张。','V6012','E18-C22'),
('1773-10-18','弗吉尼亚被奴役少女Fanny自行逃离John Lewis','Fanny；奴隶主John Lewis','Williamsburg / Tidewater Virginia (route unverified)','殖民威廉斯堡据1774广告重建15岁左右Fanny在1773-10-18逃离；可能去见母亲Joan但路线和最终去向都不明。','V6013','E18-C22'),
('1774-01-27','John Lewis刊登搜捕Fanny广告并怀疑Moses协助','奴隶主John Lewis；Fanny；被怀疑的Moses','Williamsburg, Virginia (newspaper)','广告指控另一名被奴役者Moses可能保护Fanny；怀疑为奴隶主一方说法，不写成已证Moses实际窝藏。','V6013','E18-C22'),
('1774-03-10','Prince William监狱刊报拘押John Hedgman','John Hedgman；地方监狱官员','Prince William County / Virginia Gazette Williamsburg','报纸记23岁John Hedgman因被怀疑逃亡而拘留；是否合法奴役身份或最终解送未证。','V6012','E18-C22'),
('1774-12-15','弗吉尼亚被奴役织工Gabriel逃亡通缉广告刊登','Gabriel；声索人John Fox','Williamsburg, Virginia (newspaper)','殖民威廉斯堡馆方引述广告称Gabriel会织布、读书、拉小提琴，广告时间确证而出走准确日未知。','V6012','E18-C22'),
('1776-04-14','Willoughby记录奴役者约87人逃向英军控制区','约87位自我解放者；奴隶主John Willoughby Jr','Norfolk / Virginia','1787? 原请愿核为1777-06-03，追记1776-04-14有约87位被他声索的奴役者离开；约数与妇女21男人16及儿童分母不得简单加总。','V6014','E18-C17'),
('1776-07-19','弗吉尼亚Gazette刊载对原住民出身John Newton的搜捕','John Newton；登广告殖民居民','Williamsburg / Virginia Gazette','1776-07-19刊报称John Newton为出生于原住民社群的混合血统契约仆役；法律身份原话servant，不能从广告直接改写为终身动产奴隶。','V6012','E18-C17,E18-C22'),
('1777-06-03','John Willoughby向弗吉尼亚议会递交赔偿请愿','John Willoughby Jr.；弗吉尼亚议会','Virginia House of Delegates','请愿为奴隶主声索的损失，并记1776年逃离人群；金额与获赔金额不能从请愿书直接推断。','V6014','E18-C17'),
('1781','Randolph庄园Nanny、Eve、Aggy、Lucy等人逃往英军','被奴役者Nanny、Eve、Aggy、Lucy及另外四人','Williamsburg / Tidewater Virginia','Colonial Williamsburg依据庄园清册旁注推测1781年八人赴英军，其中女性四人有名字；被奴役者各人是否抵达英军及长期自由未逐一证实。','V6014','E18-C17'),
('1782-07-20','Betty Randolph遗嘱补充条款记录曾变卖Eve','奴隶主Betty Randolph；被奴役女性Eve','Williamsburg, Virginia','1782-07-20遗嘱附记称把Eve卖出并提及bad behaviour，前一年Eve曾被记录逃往英方；是否因此变卖尚待更直接文书，不能擅自归因。','V6014','E18-C17'),
('1783-04-23','英国在纽约开始登记赴新斯科舍黑人效忠派船客','Guy Carleton驻纽约英方行政；黑人效忠派及家属','New York (registration context)','新斯科舍档案馆指出《黑人名册》登记窗口为1783-04-23至11-30，约3000人名单是申请/登船记录人口，不等于均获得土地或法律保障。','V6015','E18-C17,E18-C18'),
('1783','《黑人名册》记Betty被英方交还声称拥有她的Thomas Smith','逃亡女性Betty；Thomas Smith；英国登记官员','New York / embarkation administration','新斯科舍档案馆明确记载英当局接受奴隶主Thomas Smith的声索，将Betty交还；与另案Betty Truant身份未知，不合并为同一人。','V6015','E18-C18'),
('1783-11-30','赴新斯科舍黑人效忠派登记阶段结束','纽约英方登记官；黑人移民','New York departure ports','档案馆将名册内英国版的船客登记结束于1783-11-30；这里是清单覆盖窗口末日，不能当所有黑人最后一船到岸日。','V6015','E18-C18'),
('1784-08','Black Pioneers老兵Peters与Murphy Steel请愿平等分地','Thomas Peters；Murphy Steel；新斯科舍殖民政府','Nova Scotia / Digby','新斯科舍档案馆RG1卷359件65署1784年8月20(?)，书写日存在疑问；两位士官要求与白人效忠派退伍军人同等土地待遇。','V6016','E18-C18'),
('1785','Black Pioneers老兵仅获Digby各一英亩授地','Black Pioneers退伍军人；新斯科舍殖民政府','Digby, Nova Scotia','新斯科舍档案馆说明在1785年仅各获一英亩，土地实际位置与权属测图未逐宗读档；按州档声明区分授地文书和实际耕作。','V6016','E18-C18'),
('1787','Juba号航次从旧卡拉巴尔购买230名被奴役非洲人','船东James Rogers & Co；船长John Kennedy；被奴役非洲人','Bristol / Old Calabar, Nigeria','馆方记1787年购买230名被奴役者并装运象牙、棕榈油和红木；时间为航次年，确切交易日未知。','V6011','E18-A01,E18-A04'),
('1787','Juba号抵达圣文森特贩卖幸存者','被奴役非洲人；Juba船员与种植园买主','Saint Vincent, Caribbean','Bristol研究记230名购入、201名抵达，29人未能抵达；出海死亡人数需核博物馆原文定义，不能当整个航次总死亡额和已付款。','V6011','E18-A01,E18-A20'),
('1792','African Queen号从布里斯托尔启程前往旧卡拉巴尔购买被奴役者','船东James Rogers；船长Samuel Stribling；非洲被奴役者','Bristol / Old Calabar','馆方记1792航次及贩运；页面不同段落人数口径不一致，所有候选人口损失统计保持空值，原账待查。','V6011','E18-A01,E18-A04'),
('1792-01-07','新斯科舍行政长官拟任命John Clarkson护送自愿迁塞拉利昂黑人','Richard Bulkeley；John Clarkson；新斯科舍黑人社群','Halifax, Nova Scotia','Nova Scotia RG1卷419第17号公开转录的是1792-01-07拟稿，为希望迁往塞拉利昂者提供船只与护送；不得将草案直接等同每个人实际登船。','V6017','E18-C19'),
('1793','African Queen号贩运被奴役者抵达牙买加','African Queen船员；被奴役非洲人；牙买加种植园购买者','Jamaica (landing point unknown)','馆方记1793抵达牙买加；对其船上死亡数和人口分母同馆不同网页出现冲突，不能据此计算死者、利润或平均死亡率。','V6011','E18-A01,E18-A20'),
('1797-12-18','牙买加议会通过针对25岁以上被奴役非洲人的进口税草案','牙买加议会；Speaker Don Campbell','Spanish Town / Jamaica government (legislature location unverified)','1797-12-18议会通过、12-20上院通过的文字在法律转录末尾有记载，法定£10不是实际征税收入。','V6007','E18-A06'),
('1797-12-23','总督Balcarres批准牙买加年龄歧视性奴役进口税法','牙买加总督Balcarres、议会','Jamaica (exact signing room unverified)','1797-12-23签署，定自1798-12-31对25岁以上从非洲输入的被奴役者收£10殖民地币税；不同生效日单独记录。','V6007','E18-A06'),
('1798-04-30','多米尼加公布取缔支持山区逃亡社群的殖民法律','多米尼加总督、议会与当地逃亡者','Roseau, Dominica','1798年法规禁止向逃亡被奴役社群供应食物、衣服、武器，并有限度允许奴隶证词用于指控自由人；法条说明存在抗争但具体供给者姓名与有罪人数未知。','V6009','E18-A19'),
('1798-04-30','多米尼加正式公布追捕逃亡者及拍卖羁押者法','多米尼加议会、Provost Marshal、逃亡者','Roseau, Dominica','1798-04-30刊布，设追捕赏额和逾期卖出制度；法条却在批准行中出现与1797议会和1798议会日期相悖的1793-03-15，列为原刊异文冲突。','V6008','E18-A19,E18-A20'),
('1798-12-31','牙买加对输入25岁以上被奴役者征£10法定税开始生效','牙买加征税官与进口船舶商人','Jamaica ports (unspecified)','1797法律规定的生效点是1798-12-31，实际应税人数与实缴总税款尚无核实账册。','V6007','E18-A06'),
('1799','牙买加法律命令部分法属圣多明各关联被奴役者六个月内离境','牙买加殖民议会；Saint-Domingue相关被奴役移民','Jamaica / Kingston / Port Royal','1799法令针对1791-08-23起居住在法属岛屿的被奴役者，设强制送离和部分认证豁免；来源为1819法律摘录，目录的1799-01-01不作为确证日。','V6010','E18-A06,E18-A18'),
]
# fix overly explanatory typo in one record before writing
records=[(d,t,a,p,desc.replace('1787? 原请愿核为','原请愿核为'),sid,tid) for d,t,a,p,desc,sid,tid in records]
# Existing matching 1740 code already present: improve its source without inventing new event
for e in E['events']:
 if e['id']=='E18A2-SC-CODE-1740':
  e.setdefault('source_ids',[])
  if 'V6005' not in e['source_ids']:e['source_ids'].append('V6005')
  if source_lookup['V6005']['url'] not in e['source_urls']:e['source_urls'].append(source_lookup['V6005']['url'])
  e['source_support_count']=len(e['source_ids'])
  e['v6_primary_law_clause_matrix']='PRIMARY_LAW_CLAUSE_MATRIX_V6.csv'
  e['v6_reconciliation']='1740-05-10为现有事件的原法深入分析，无重复新建事件。'
  source_lookup['V6005']['supported_event_candidate_ids'].append(e['id']);source_lookup['V6005']['supported_topic_ids']+=e['topic_ids']
# durable per-batch writes
batch=0; new_ids=[]; refs=[]
for n,(date,title,actor,place,desc,sidstr,tidstr) in enumerate(records,1):
 y=int(date[:4]);month=int(date[5:7]) if len(date)>=7 else None;day=int(date[8:10]) if len(date)==10 else None
 prec='day' if day else ('month' if month else 'year')
 eids=sidstr.split(',');tids=tidstr.split(',')
 for si in eids:
  if si not in source_lookup:raise ValueError('unknown '+si)
 for ti in tids:
  if ti not in topics:raise ValueError('unknown topic '+ti)
 eid=f'E18A6-{y}-{n:03}'
 if eid in current_ids:raise ValueError('id collision '+eid)
 previous=list(dict.fromkeys(pid for ti in tids for pid in topics[ti].get('previous_story_ids',[])))
 en={'id':eid,'date_text':date,'year':y,'month':month,'day':day,'date_precision':prec,'topic_ids':tids,'title':title,'actor_entities_text':actor,'historical_description_zh':desc,'historical_place_name':place,'longitude':None,'latitude':None,'modern_reference_site':None,'geo_precision':'no_verified_coordinate','coordinates_support_sources':[], 'source_ids':eids,'source_urls':[source_lookup[si]['url'] for si in eids], 'source_support_count':len(eids),'claim_crosscheck_status':('two_converging_independent_institutional_histories_primary_page_check_pending' if len(eids)>1 else 'single_primary_transcription_or_institutional_excerpt_second_source_pending'), 'evidence_status':'online_primary_transcription_or_institutional_interpretation_read_editorial_review_required', 'previous_17c_story_ids':previous,'pr289_preexisting_acadia_candidate_ids':[],'historical_control_boundary_verified':False,'political_claim_not_actual_control':True,'area_sqkm':None,'historical_line_or_route_surveyed':False,'estimated_casualties_count':None,'estimated_trade_sum':None,'publication_status':'research_only','publication_review':'not_submitted','topic_window_alignment':{ti:('in_core_research_window' if topics[ti]['research_window']['start_year']<=y<=topics[ti]['research_window']['end_year'] else 'contextual_related_event_outside_original_topic_window') for ti in tids},'local_research_round':6,'v6_source_notes':'每件按文献明确时间登记；公布、通过、签署、生效、登船、抵岸为不同动作；非同书双条独立交叉证据。'}
 if '1723'==date or '1729'==date or '1799'==date:en['date_evidence_note']='原文档案编目日为推定日，故只保留年，不保留1月1日或7月1日。'
 if 'Prince of Orange' in title:en['voyage_statistics_caveat']='273与240、33为馆方同航次不同节点；不当全船出生、死亡率或1780年代总数。'
 if 'Marlborough' in title:en['ship_mutiny_caveat']='原报道：返回Bonny后不同地区被奴役者命运不同，剩船去向未知；见冲突账。'
 if 'Dominica' in place or 'Dominica' in title or '多米尼加' in title:en['legal_date_conflict']='1788? 1798法文本有1793-03-15 assent条文与1797-09-28、1798-04-27、1798-04-30不符；保留刊布日。'
 E['events'].append(en);new_ids.append(eid);current_ids.add(eid)
 for si in eids:
  source_lookup[si]['supported_event_candidate_ids'].append(eid)
  for ti in tids:
   if ti not in source_lookup[si]['supported_topic_ids']:source_lookup[si]['supported_topic_ids'].append(ti)
 batch+=1
 if batch%10==0:
  E['last_local_research_extension']={'round':6,'events_committed_at_least':old_e+batch,'incremental':batch,'status':'checkpoint_in_directory'}
  save('EVENT_CANDIDATES.json',E); save('SOURCE_REGISTRY.json',S)
  p=BASE/'PROGRESS.md';p.write_text(f'# 第六轮研究进行中：已落盘 {batch} 件新事件；保留旧 {old_e} 件\n\n本地校验后才重建ZIP；未向GitHub写入。\n\n'+p.read_text(encoding='utf-8'),encoding='utf-8')
# sources without linked events? all additional URLs indexed as research gap sources, valid
E['last_local_research_extension']={'round':6,'new_events':batch,'total_events':len(E['events']),'sources_total':len(S['sources']),'source_case_first':'museum/primary transcription not automatic manuscript inspection'}
S['last_local_research_extension']={'round':6,'new_source_records':len(sources),'sources_total':len(S['sources']),'reading_policy':'URL actually inspected, manuscript not personally inspected, no fabricated event coordinates'}
# topic coverage update
for t in T['topics']:
 rel=[e for e in E['events'] if t['id'] in e['topic_ids']]
 t['candidate_event_count']=len(rel)
 t['v6_new_events_count']=sum(e['id'] in new_ids for e in rel)
 for e in rel:
  for si in e['source_ids']:
   if si not in t['source_ids']:t['source_ids'].append(si)
 t['index_refresh']='2026-11-08-round6'
T['last_local_research_extension']={'round':6,'total_topics':len(T['topics']),'source_count':len(S['sources']),'events_total':len(E['events'])}
# build event CSV union of evolving schema
cols=[]
for ev in E['events']:
 for k in ev:
  if k not in cols:cols.append(k)
with (BASE/'EVENT_CANDIDATES.csv').open('w',encoding='utf-8-sig',newline='') as fp:
 w=csv.DictWriter(fp,cols);w.writeheader()
 for ev in E['events']:
  w.writerow({k:(json.dumps(v,ensure_ascii=False) if isinstance(v,(list,dict)) else v) for k,v in ev.items()})
save('EVENT_CANDIDATES.json',E);save('SOURCE_REGISTRY.json',S);save('TOPIC_INDEX.json',T)
# only points with referenced official modern GPS, never from new historical places
G['metadata']['excluded_unknown_coordinate_events']=sum(e['longitude'] is None or e['latitude'] is None for e in E['events'])
G['metadata']['round6_new_geometry_features']=0;G['metadata']['round6_boundary_rule']='No G6 lines or polygons from historical place names or treaties; written outline is not precise control geometry.'
save('MAP_CANDIDATES.geojson',G)
# ship ledger: statements with source, quant contexts; figures derive ONLY museum text, no all-period estimates
ships=[
{'ship':'Prince of Orange','voyage_year':1736,'captain':'Japhet Bird','owners':'Richard Farr & Co','port':'Bristol','coast':'West African coast unspecified','arrive':'Saint Kitts area','onboard_count_at_start_of_crossing':None,'purchased_or_surviving_context':273,'persons_overboard_attempt':100,'reported_drowned':33,'persons_sold':240,'passage_deaths_claimed_total':None,'same_source_as_all':'V6011','caveat_zh':'273是馆方明确幸存或买入语境，33为跳海溺亡，240卖出；细节口径及1736-1737靠港时间需与船簿核实。'},
{'ship':'Marlborough','voyage_year':1752,'captain':'Robert Codd','owners':'William Lougher & Co','port':'Bristol','coast':'Anomabu and Bonny','arrive':None,'onboard_count_at_start_of_crossing':None,'purchased_or_surviving_context':420,'persons_overboard_attempt':None,'reported_drowned':None,'persons_sold':None,'passage_deaths_claimed_total':None,'same_source_as_all':'V6011','caveat_zh':'约10月出海约3日后起义返Bonny；剩余船员和黄金海岸被奴役者最终下落不明。420不是证实的抵岸人口。'},
{'ship':'Juba','voyage_year':1787,'captain':'John Kennedy','owners':'James Rogers & Co','port':'Bristol','coast':'Old Calabar','arrive':'Saint Vincent','onboard_count_at_start_of_crossing':230,'purchased_or_surviving_context':230,'persons_overboard_attempt':None,'reported_drowned':None,'persons_sold':201,'passage_deaths_claimed_total':29,'same_source_as_all':'V6011','caveat_zh':'230是购入人数，201为馆方抵达人数，29为该口径差额；船上死亡与更晚疾病死亡不混计。'},
{'ship':'African Queen','voyage_year':1792,'captain':'Samuel Stribling','owners':'James Rogers & Co','port':'Bristol','coast':'Old Calabar','arrive':'Jamaica (1793)','onboard_count_at_start_of_crossing':None,'purchased_or_surviving_context':None,'persons_overboard_attempt':None,'reported_drowned':None,'persons_sold':None,'passage_deaths_claimed_total':None,'same_source_as_all':'V6011','caveat_zh':'同馆不同段叙述人数冲突，暂不提供已核统一运量/死者人数。'}
]
save('SHIP_VOYAGES_V6.json',{'schema':'ship-studies-candidates-v6','status':'research_only','notes':['仅单船文献，不推算整个18世纪总运量','损失不得从两个不同阶段统计自行简单相减','船海位置缺乏原航迹，不能生成LineString'], 'ships':ships})
with (BASE/'SHIP_VOYAGES_V6.csv').open('w',encoding='utf-8-sig',newline='') as fp:
 w=csv.DictWriter(fp,fieldnames=list(ships[0]));w.writeheader();w.writerows(ships)
# primary law clauses, text-identified sections, do not incorrectly attribute quote to the modern re-editor
lawclauses=[
('1712-06-07','South Carolina','XXXIV','baptism','受洗及改信基督教不能自动解放被奴役者','V6001',None,None,'statute_only'),
('1723','North Carolina','II','tax','自由混合血统者12岁起列为应税人口','V6002',None,None,'statute_only'),
('1723','North Carolina','III','tax','与被规定族群婚姻关系的白人也纳入税制','V6002',None,None,'statute_only'),
('1723','North Carolina','IV','removal','曾获释者六个月内离境并禁返回','V6002',None,None,'statute_only'),
('1726-03-11','South Carolina','main','surveillance','每庄园配至少两名白人看管人员及后续按人数增加','V6003',None,None,'statute_only'),
('1729','Maryland','II','corporal_punishment','授权砍手绞刑及分尸，法院定罪仍须核个案','V6004',None,None,'statute_only'),
('1740-05-10','South Carolina','I','hereditary_property','子女随母身份并定义为可继承的动产奴役','V6005',None,None,'statute_only'),
('1740-05-10','South Carolina','I freedom suits','legal_due_process','允许提出自由诉讼但对多数非白人推定为奴隶、由原告举证','V6005',None,None,'statute_only'),
('1740-05-10','South Carolina','passes','surveillance','逃亡及跨庄园流动受到通行证限制','V6005',None,None,'statute_only'),
('1740-05-10','South Carolina','criminal proceedings','punishment','剥夺或压缩针对被奴役者的普通法律保障','V6005',None,None,'statute_only'),
('1740-05-10','South Carolina','rebellion','military_repression','对被认定为谋反者规定死刑和紧急治罪程序','V6005',None,None,'statute_only'),
('1740-05-10','South Carolina','compensation','owner_compensation','殖民财政可赔偿被依法处死者的业主，额度受原法限定','V6005',None,None,'statutory_authorisation_not_payment'),
('1740-05-10','South Carolina','assembly','cultural_repression','限制被奴役者大规模聚集及相关音乐活动','V6005',None,None,'statute_only'),
('1741','North Carolina','XIV','trade','禁止未经主人许可与奴役者进行交易','V6006',None,None,'statute_only'),
('1741','North Carolina','XXIII–XXIV','freedom_suits','规定特定已自由人士被非法贩卖时的申诉路径，范围有限','V6006',None,None,'statute_only'),
('1797-12-23','Jamaica','I','import_duty','从1798-12-31起对25岁以上被运入者每人征收10镑','V6007','£10','Jamaica currency','statutory_duty_not_received'),
('1797-12-23','Jamaica','II','inspection','规定检查员在港口查验新入境被奴役者年龄','V6007',None,None,'statute_only'),
('1797-12-23','Jamaica','XIII','legal_duration','法案效力规定至1801-12-31','V6007',None,None,'statute_only'),
('1798-04-30','Dominica','1','suppression_of_resistance','禁止为山区逃亡者提供粮食、衣服、军火','V6009',None,None,'statute_only'),
('1798-04-30','Dominica','2','testimony','对部分诉讼准许被奴役者在限制条件下作证','V6009',None,None,'statute_only'),
('1798-04-30','Dominica','1','bounty','向捕捉逃亡被奴役者的人员设置报酬','V6008','16s 6d','local currency unspecified','statutory_bounty_not_paid'),
('1798-04-30','Dominica','1','auction','允许将无人认领的被拘押逃亡者公开出售','V6008',None,None,'statute_only'),
('1799','Jamaica','1','forced_removal','命令某些曾居留圣多明各法属地区者在6个月内被送出殖民地','V6010',None,None,'statute_only'),
('1799','Jamaica','1 exceptions','conditional_exemptions','具登记证书及特定城镇主人家务奴役者豁免','V6010',None,None,'statute_only'),
]
primary_rows=[{'law_date_text':a,'colony':b,'clause_locator':c,'mechanism':d,'fact_zh':e,'source_id':f,'quoted_amount':g,'amount_currency':h,'actual_execution_or_payment_status':i,'page_or_archive_warning':'online transcription only; original paper/source PDF not separately inspected'} for a,b,c,d,e,f,g,h,i in lawclauses]
with (BASE/'PRIMARY_LAW_CLAUSE_MATRIX_V6.csv').open('w',encoding='utf-8-sig',newline='') as fp:
 w=csv.DictWriter(fp,fieldnames=list(primary_rows[0]));w.writeheader();w.writerows(primary_rows)
save('PRIMARY_LAW_CLAUSE_MATRIX_V6.json',{'schema':'primary-law-clause-matrix-v6','status':'research_only','clauses':primary_rows})
# evidence matrix per added event with identified single/double-source exact linkage
claim_rows=[]
for e in E['events']:
 if e['id'] not in new_ids:continue
 claim_rows.append({'event_id':e['id'],'date_text':e['date_text'],'topic_ids':';'.join(e['topic_ids']),'claim_zh':e['title'],'source_ids':';'.join(e['source_ids']),'source_urls':';'.join(e['source_urls']),'independent_check':'two_institutions_on_same_historical_action' if len(e['source_ids'])>1 else 'single_institution_or_transcription','archive_read_depth':'text_transcript_online_or_museum_page','map_status':'named_historical_place_only; null GPS','boundary_verified':False,'review_status':'research_only'})
with (BASE/'CLAIM_SOURCE_MATRIX_V6.csv').open('w',encoding='utf-8-sig',newline='') as fp:
 w=csv.DictWriter(fp,fieldnames=list(claim_rows[0]));w.writeheader();w.writerows(claim_rows)
save('CLAIM_SOURCE_MATRIX_V6.json',{'schema':'evidence-per-claim-v6','claims':claim_rows,'crosscheck_rule':'Museum copy of same primary record is not independent manuscript validation'})
# named locations list intentionally lacks made-up GPS
place_map={}
for e in E['events']:
 if e['id'] not in new_ids:continue
 for word in e['historical_place_name'].split(' / '):
  place_map.setdefault(word,[]).append(e['id'])
with (BASE/'MAP_PLACE_RESEARCH_V6.csv').open('w',encoding='utf-8-sig',newline='') as fp:
 w=csv.DictWriter(fp,fieldnames=['historical_place','candidate_event_ids','modern_latitude','modern_longitude','precision','research_next_step','published_geography']);w.writeheader()
 for p,ids in sorted(place_map.items()):
  w.writerow({'historical_place':p,'candidate_event_ids':';'.join(ids),'modern_latitude':'','modern_longitude':'','precision':'no_verified_site_specific_event_coordinate','research_next_step':'official gazetteer / contemporary parcel map / port source required before mapping point, line or territory','published_geography':'research_only'})
# research narratives: group per actual topic, each structured action with attached direct URLs
series=[
('01_four_bristol_slave_ships','A01·A04·A20｜布里斯托尔四艘具名奴役船、货物账与反抗',['E18-A01','E18-A04','E18-A20'],'船东、船长、交易地点及统计口径应按每一艘船每一段航次独立登记。Prince of Orange 约100人跳海、Marlborough船上起义返航、Juba人数账、African Queen口径冲突，不可互相补数。'),
('02_south_carolina_slave_code','C21｜南卡1712—1740奴役法与Stono之后的镇压',['E18-C21'],'1680年代卡罗来纳掳奴贸易与1715亚马西战争是前史；1726军警看守和1740法典以立法削减人身自由，抵抗者的实际组织需要个案和黑人民众史料。'),
('03_north_carolina_maryland_laws','C21·C22｜北卡税制与马里兰惩罚法',['E18-C21','E18-C22'],'以殖民议会、地方白人业主、被奴役者与自由有色居民为不同政治行动主体；目录推定日不可伪造立法日，惩罚许可不可充作已执行处刑数。'),
('04_virginia_runaway_advertisements','C22｜弗吉尼亚Gazette广告中的具名逃亡者',['E18-C22'],'Peter、Amy、Sam、Fanny、John Newton和John Hedgman等人的证据来自奴隶主或监狱公告，反映主动逃亡与严密追捕，但奴隶主的推测不等于被追捕者自己的供述。'),
('05_dunmore_families_property','C17｜Dunmore时期逃亡家庭与Willoughby请愿',['E18-C17'],'以殖民威廉斯堡馆方摘录的1777请愿、1776名单、1781庄园清册观察英国许诺自由与具体家庭风险，分清登记人口、声索人数与真实获释人数。'),
('06_new_york_nova_scotia_black_loyalists','C18·C19｜纽约撤离名册与新斯科舍黑人退伍军人土地抗争',['E18-C18','E18-C19'],'1783年船客名册、Betty被送回声索者、1784年Peters和Steel请愿、1785年Digby每人一英亩和1792迁居塞拉利昂草案，揭示自由与土地之间的持续争取。'),
('07_1764_bradstreet_indigenous_diplomacy','C12｜1764年英军Bradstreet临时议和、原住民族外交',['E18-C12'],'1764-08-12 Presque Isle与08-27 Detroit均为具名会议节点，Gage事后拒绝同意。原住民族不应仅被写成英军征服对象，各方有独立外交与土地诉求。'),
('08_1797_jamaica_law_trade','A06｜1797年牙买加进口税与1799年圣多明各人口流放条款',['E18-A06','E18-A18'],'从1797-12-18议会、12-23批准到1798-12-31生效相隔一年；1799涉及法属殖民地经历者送离六个月的规定，必须单列法定税与实际征税口径。'),
('09_1798_dominica_laws','A19·A20｜1798年多米尼加逃亡者网络、追捕奖金与没收',['E18-A19','E18-A20'],'岛上逃亡者凭地下协作获取粮食与武器；殖民议会禁止援助并设置追捕奖金与拍卖权。1783与1798法律日期冲突必须保持为待核原始印本问题。'),
('10_archival_source_conflicts','第六轮文献异文与统计分母：跨专题审计',['E18-A01','E18-A06','E18-A19','E18-C18'],'馆方网站中可能有自相矛盾的旧文献印记、出版者年代、人口统计以及立法日期。审查必须逐件；不得为了达到数量把同一法令条款分裂为多场战争。'),
]
for fname,title,tids,context in series:
 es=[e for e in E['events'] if e['id'] in new_ids and any(t in e['topic_ids'] for t in tids)]
 lines=[f'# 第六轮深入调查｜{title}','',f'**范围**：1700—1799；**状态**：研究候审；新关联事件 {len(es)} 件。','', '## 一、背景及跨世纪起点','',context,'','## 二、决策机构与执行人','', '按下列行动节点分别核对殖民议会、皇家总督、海上船长、公司和殖民民兵。法令、海关账、船客清单与实际登陆是不同类别，任何经纬度空值均有意保留。','','## 三、具名事件、地点、行动和直接证据','']
 for e in sorted(es,key=lambda a:(a['year'],a['month'] or 0,a['day'] or 0,a['id'])):
  lines += [f'### {e["date_text"]}｜{e["title"]}','', f'- **行动主体**：{e["actor_entities_text"]}',f'- **历史地点**：{e["historical_place_name"]}；坐标未核。', f'- **实际行动与性质**：{e["historical_description_zh"]}', '- **来源**：'+ '；'.join(f'[{sid}]({source_lookup[sid]["url"]})' for sid in e['source_ids']),'- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。','']
 lines += ['## 四、居民/被奴役者/原住民族的能动性与抵抗','','本篇不得把受压制者归为被动受害者：其逃亡、组织、谈判、船上起义、争取土地和法律申诉都是独立行动。部分证词仅留于敌对殖民者的追捕公告，须按发话主体还原。','','## 五、法律、经济及长期影响','','有数字的船货、赏金、进口税与土地面积只采当时文书明确的“法定、估计、登记、报称”口径；无法独立核实的实际支付、船东净利润、死亡总数和真实区域面积一律null。跨18世纪后的生效/到期条款应标后续调查，不把1801年事件塞回1799年滑条。','','## 六、地图GIS审查','','所有此批事件仅具名地点（并不等于准确事件GPS）。船舶海上路线与跨岛强制迁运不绘直线；殖民纸面司法管辖不当主权实占；可据同时代测绘但未校准边界仅在主编审核后以虚线概略方案呈现。','','## 七、下步逐页原档','','优先获取相应登船账、宣誓副本、殖民法律原刊或报纸整版、原住民社区记录及人名/地名同一性证据，以便把故事节点从候审提高至可出版级。']
 md('DEEP_DIVES_V6/'+fname+'.md','\n'.join(lines))
# amend original dossiers without replacing prior work
for t in T['topics']:
 additional=[e for e in E['events'] if e['id'] in new_ids and t['id'] in e['topic_ids']]
 if not additional:continue
 p=BASE/t['dossier_path'];assert p.exists(),p
 lines=['','---','',f'## 第六轮补充：新增逐件档案与原始记录（{len(additional)}件关联）','','以下均为候审事件，不作为正式地图Atlas已发表结论；仅有历史地名而无核定事件GPS的均保留空坐标。','']
 for e in sorted(additional,key=lambda e:(e['year'],e['month'] or 0,e['day'] or 0)):
  lines +=[f'- **{e["date_text"]}｜{e["title"]}**：{e["historical_description_zh"]}（{e["historical_place_name"]}；来源'+', '.join(e['source_ids'])+f'；候审ID `{e["id"]}`）']
 lines+=['','来源网址及阅读深度参见更新后的 `SOURCE_REGISTRY.json`；逐条主张参见 `CLAIM_SOURCE_MATRIX_V6.csv`。']
 with p.open('a',encoding='utf-8') as fh:fh.write('\n'.join(lines)+'\n')
# conflicts: prepend new issues but preserve previous work
conflicts='''# 第六轮重点争议与未解原档（前五轮记录完整保留在下方）

1. **Prince of Orange航次**：1736年为布里斯托尔博物馆的航次年份，抵达可能被另一文献索引为1737；273、240、100、33等不同节点的人数不得相加为死亡总量。需要船东账簿与SlaveVoyages航次原始登记。
2. **Marlborough 1752**：博物馆称船在反抗后返博尼，后续船舶及部分被奴役者去向未知；有非权威索引称抵岸317人，与馆方现存叙述不合，不列入确证人口统计。需查1753-03-31 *Felix Farley's Bristol Journal* 原版及船簿。
3. **African Queen 1792–1793**：历史机构的不同网页给出不一致的购入/航程死亡数字，本次不采用统一死亡数、死亡率或投资利润。
4. **多米尼加1798逃亡奴隶法异文**：公开转录在1797-09-28议会、1798-04-27委员会、1798-04-30公布的同一条法中印有“1793-03-15批准”，时间自相矛盾；仅使用确证刊布日，核原始1816 HC 226影印卷。
5. **北卡1723／马里兰1729／牙买加1799网站编目日**：均属不精确索引日，不可将一月一日或七月一日冒充历史立法日；本批只保留年份。
6. **John Hedgman与原住民出身John Newton**：追逃广告里的法律称谓与当事人身份待查，不用servant一词直接判定为终身世袭奴役。1774年月刊日为通缉/拘押记录，不是出逃日。
7. **Virginia Gazette 1745 Rind印记**：Colonial Williamsburg网页将1745年一则广告归于Rind版，但Rind的报业时间待核。本轮该条不建日级事件、保留人工冲突调查。
8. **Betty两人同名冲突**：1783《Book of Negroes》提Betty与声索人Thomas Smith；旧事件另有Betty/Elizabeth Truant，不合并、也不声称系同一人。
9. **Black Pioneers请愿日期**：新斯科舍档案署1784年8月20(?)，因日数字有疑问，本批精度仅记录1784-08。1785 Digby每人一英亩是档案馆所述分地，具体地籍与移民实际占地仍待逐宗查验。
10. **Bradstreet 1764**：两家机构记8月12日Presque Isle临时谈判与8月27日Detroit谈判；英军最高指挥官Gage事后否认相关条款，不能把议和画为原住民领地割让。NPS传记摘要另有诞生年1914明显排印错误，参照同页正文1714及学术辞典。
11. **1740南卡法典**：既有事件`E18A2-SC-CODE-1740`只补充法条、没有重复事件；法定对奴隶主赔偿、允许处刑等均不能统计为已支付或已执行的人数。
12. **法律生效年份跨世纪**：牙买加1797进口税到1798-12-31才开始，1801-12-31才结束，绝不把法律终止日计为18世纪事件。
13. **船舶海上与逃亡路线**：Bonny、Old Calabar、St Kitts只是来源记录的具名地点，船只真实海面GPS、渡河路线、历史堡垒轮廓未核，地图坐标空值而非从现代城市中心推测。
14. **原始载体**：本轮阅读全文的是UNB法条转录、Nova Scotia Archives志愿者转录、博物馆引述及馆方解释；未亲阅原版报纸整页、船长私人账或全部国立档案馆纸本，不能标注原手稿已检查。

---

'''
p=BASE/'GAPS_AND_CONFLICTS.md';p.write_text(conflicts+p.read_text(encoding='utf-8'),encoding='utf-8')
from collections import Counter
c=Counter(e['date_precision'] for e in E['events']);nempty=sum(e['longitude'] is None or e['latitude'] is None for e in E['events'])
p=BASE/'PROGRESS.md'; prior=p.read_text(encoding='utf-8')
head=f'''# 第六轮完成｜2026-11-08｜以此为当前统计口径

- 已在旧完整目录上增量完成：事件 {old_e}→**{len(E['events'])}**（+{len(new_ids)}），来源 {old_s}→**{len(S['sources'])}**（+{len(sources)}），原A/C **49**份专题档案保留。
- 事件日期精度：日 {c['day']}、月 {c['month']}、年 {c['year']}；各事件候选仅研究候审。
- 原有地图点 {len(G['features'])}，新增地图对象0；{nempty}件事件经纬度空值；无历史主权Polygon、LineString或面积计算。
- 新增第六轮10篇深挖报告、{len(primary_rows)}条法律条款矩阵、{len(ships)}艘单船账、{len(claim_rows)}条逐事件证据矩阵及具名地名候审表。
- 已去重1740南卡法典，不再重复新增同一立法；跨题事件在总数中只算一次。
- 包含前五轮文档与参考资料，未修改GitHub。历史原档逐页访问与GIS坐标校准仍是下一阶段任务。
- 本批来源属于线上原文转录、机构史料及馆藏索引；仍需双机构或独立原档逐条审查。

---

'''
p.write_text(head+prior,encoding='utf-8')
md('README_ROUND6.md',f'''# 第六轮完整研究包说明

原目录累积保留前五轮资料并新增：事件**{len(E['events'])}**件（+{len(new_ids)}）；来源**{len(S['sources'])}**条（+{len(sources)}）；49个原专题。地图只允许有来源的现代遗址代表Point，未对本轮具名地补造GPS。

新增目录`DEEP_DIVES_V6/`的十篇中文报告，`PRIMARY_LAW_CLAUSE_MATRIX_V6.csv/json`计{len(primary_rows)}项立法条款，`SHIP_VOYAGES_V6.csv/json`含四艘船，`CLAIM_SOURCE_MATRIX_V6.csv/json`支持逐件审查，`MAP_PLACE_RESEARCH_V6.csv`是仅地名研究线索；`GEO_AND_CHRONOLOGY_AUDIT_V6.md`说明异文和空间语义。

`REFERENCE/BUILD_ROUND6.py`为在前五轮基线上一次性执行的复现脚本；**不要对已完成第六轮数据重复运行**，否则源ID碰撞。`MANIFEST_V6.json`与`REFERENCE/SHA256_V6.txt`在打包时生成。

研究来源公开可读不等于档案馆纸本亲阅；所有candidate均需编辑审核后方可与正式Atlas事件关联。
''')
md('GEO_AND_CHRONOLOGY_AUDIT_V6.md',f'''# 第六轮时空、法律与数字口径审查

- 新增事件 {len(new_ids)}；所有新增`longitude/latitude=null`；GeoJSON继承原24个官方现代遗址参考点，新增Point/Line/Polygon为零。
- 1736 Prince of Orange航次与可能1737登陆不同；1752 Marlborough十月起义与1753报纸报道不同。
- 1764 Bradstreet Presque Isle临时议和与Detroit会谈是两处不同政治过程，Gage否决；不得根据现代州界画原住民割地。
- 1773-10-18 Fanny逃走和1774-01-27追逃广告是不同事件，广告推测协助人Moses未被独立确证。
- 1776-04-14 Willoughby追记与1777-06-03向议会递交请愿须分别入史；有报称87人与分列性别、子女人数口径不能加总。
- 1784-08-20(?) Peters/Steel请愿按月精度；1785 Digby各一英亩仅馆方数据，不构成地籍多边形。
- 1797年牙买加通过/批准，1798-12-31生效，1799圣多明各人口强制送离法另立；税额是法定而非税库净收入。
- 1798多米尼加法内部打印1793年批准矛盾，保存作疑点；不能反推为1793年通过。
- 1723/1729/1799法律目录推定日不当确证日。
- 金额、船上购买量、海上死亡、抵岸人口、种植园售出人数须以每艘船与每个阶段分母分开，非书面确认全程总额为null。
- 本轮原始档案研究推荐：英国TNA T70/349–356，地方报纸1753-03-31原版、Nova Scotia RG1 vol359 no65、HC226(1816)多米尼加印本、SlaveVoyages每船条目。
''')
# validations
assert len(E['events'])==old_e+len(new_ids)
assert len(S['sources'])==old_s+len(sources)
assert len({e['id'] for e in E['events']})==len(E['events'])
assert len({s['id'] for s in S['sources']})==len(S['sources'])
assert len({s['url'] for s in S['sources']})==len(S['sources']), 'source URL duplicates remain in base?'
assert all(set(e['source_ids']).issubset({s['id'] for s in S['sources']}) for e in E['events'])
assert all(set(e['topic_ids']).issubset(set(topics)) for e in E['events'])
assert all(e['longitude'] is None and e['latitude'] is None for e in E['events'] if e['id'] in new_ids)
assert len(G['features'])==24
assert len(T['topics'])==49
# CSV roundtrip and date precision check
with (BASE/'EVENT_CANDIDATES.csv').open(encoding='utf-8-sig',newline='') as f: assert len(list(csv.DictReader(f)))==len(E['events'])
assert all(e['day'] is None or re.fullmatch(r'\d{4}-\d{2}-\d{2}',e['date_text']) for e in E['events'] if e['id'] in new_ids)
# auditing counts and source IDs in deep dive
validation={'round':6,'event_total':len(E['events']),'event_new':len(new_ids),'sources_total':len(S['sources']),'sources_new':len(sources),'topics':len(T['topics']),'deep_dive_v6_files':len(list((BASE/'DEEP_DIVES_V6').glob('*.md'))),'law_clauses':len(primary_rows),'ships':len(ships),'claimed_map_points':len(G['features']),'no_coordinate_events':nempty,'day_events':c['day'],'month_events':c['month'],'year_events':c['year'],'new_events_without_coordinates':len(new_ids),'line_or_polygon_count':sum(f['geometry']['type']!='Point' for f in G['features']),'validated_links_by_id':True,'no_duplicate_ids':True,'round_status':'research_only','no_github_changes':True}
save('REFERENCE/VALIDATION_V6.json',validation)
# immutable local SHA digest manifest excluding manifest and checksum themselves
files=[p for p in BASE.rglob('*') if p.is_file() and p.name not in ['MANIFEST_V6.json','SHA256_V6.txt']]
manifest={'schema':'complete-18c-assistant-a-research-package-v6','date':'2026-11-08','status':'research_only','summary':validation,'files':[{'path':str(p.relative_to(BASE)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'size_bytes':p.stat().st_size} for p in sorted(files)]}
save('MANIFEST_V6.json',manifest)
with (BASE/'REFERENCE/SHA256_V6.txt').open('w',encoding='utf-8') as f:
 for p in sorted(q for q in BASE.rglob('*') if q.is_file() and q.name!='SHA256_V6.txt'):
  f.write(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(BASE))+'\n')
zip_path=pathlib.Path('/mnt/data/18c_assistant_A_americas.zip')
with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for p in sorted(q for q in BASE.rglob('*') if q.is_file()):z.write(p,arcname=str(pathlib.Path('18c_assistant_A')/p.relative_to(BASE)))
with zipfile.ZipFile(zip_path) as z:
 assert z.testzip() is None
 assert len(z.namelist())==len(list(BASE.rglob('*')))-len([p for p in BASE.rglob('*') if p.is_dir()])
 assert any(n.endswith('EVENT_CANDIDATES.json') for n in z.namelist())
print(json.dumps({**validation,'package_files':len(list(p for p in BASE.rglob('*') if p.is_file())),'zip_bytes':zip_path.stat().st_size},ensure_ascii=False,indent=2))
