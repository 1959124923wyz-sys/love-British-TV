import json,csv,copy,datetime,collections,os
from pathlib import Path
base=Path('/mnt/data/18c_assistant_A')
def load(name):return json.loads((base/name).read_text(encoding='utf-8'))
def dump(name,obj): (base/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
EV=load('EVENT_CANDIDATES.json'); SR=load('SOURCE_REGISTRY.json'); TOP=load('TOPIC_INDEX.json'); G=load('MAP_CANDIDATES.geojson'); EX=load('PROPOSED_ADDITIONAL_TOPICS_V3.json'); CL=load('EVIDENCE_CLAIMS_V3.json')
existing_urls={s['url']:s['id'] for s in SR['sources'] if s.get('url')}
source_entries=[
('Jamaica government','Saint Mary parish history—Tacky 1760 and 1765 revolt','https://jamaica55.gov.jm/st-mary/st-mary-history/','official_local_history','官网HTML文叙述Fort Haldane军需被夺及1765另起事件；未核原卷'),
('Devin Leigh and Clifton E. Sorrell III; Library of Congress index','How to control the history of a slave rebellion: Blackwall revolt 1765','https://www.loc.gov/item/hlas-bi2023000044/','peer_reviewed_journal_catalogue_summary','书目及图书馆摘要，原论文全文未读取'),
('University of New Brunswick','Laws of Enslavement and Freedom in Anglo-Atlantic World: York and Cuffee 1767','https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1767','transcribed_primary_colonial_legislation','原印本56-57页数字转录HTML全文，立法文字已读，原案卷未亲核'),
('Robin F. A. Fabel et al? author from journal page','Edward Long’s observations on Jamaican slavery and British slave trade abolition','https://academic.oup.com/histres/article/97/278/573/7762616','peer_reviewed_open_access','已读1766-08-06殖民议会报告与限制奴役进口提议未通过的章节；作者须页面再核'),
('Jamaica National Library','Chronology of Resistance in the British West Indies','https://nlj.gov.jm/history-notes/Chronology%20of%20Resistance%20in%20the%20British%20West%20Indies.pdf','national_library_document_search_excerpt','只读取搜索引擎展露的编年文本，并未逐页截图核PDF'),
('Heather Freund, Cambridge University Press','A Place of Refuge to Republicans and Royalists: the French Revolution in British Dominica','https://www.cambridge.org/core/journals/journal-of-british-studies/article/place-of-refuge-to-republicans-and-royalists-the-french-revolution-in-british-dominica/25F4CEF27A430F4653C59D16174A9DE7','peer_reviewed_full_open_access','已读取公开摘要和关于1790年詹姆斯·布鲁斯9月12日信及1794加勒比战争段落'),
('Christopher Taylor, University Press of Mississippi, Oxford Academic','The Black Carib Wars ch.8 Aftermath','https://doi.org/10.14325/mississippi/9781617033100.003.0009','scholarly_book_abstract_only','已读该书章节公开摘要载1797年4月11日、2026抵岸及后续流散，正文付费未读'),
('Garifuna Nation','History: Garifuna People','https://www.garifunanation.org/history/','indigenous_community_historical_account','已读族群社区历史页面4月12日记载、约2500人'),
('Robert J. Griffiths / Outre-Mers','Guadeloupe, savagery and emancipation: British comment of 1794-1796','https://www.persee.fr/doc/outre_0300-9513_1978_num_65_240_2127','peer_reviewed_article_abstract','公开摘要、文章书目及原档ADM/1目录线索；未通读所有注释'),
('Heather Freund / Cambridge University Press','Dominica and Guadeloupe 1794 British capture and Victor Hugues','https://www.cambridge.org/core/journals/journal-of-british-studies/article/place-of-refuge-to-republicans-and-royalists-the-french-revolution-in-british-dominica/25F4CEF27A430F4653C59D16174A9DE7','peer_reviewed_full_open_access','本来源与上面Cambridge文章同一来源，不单独增来源ID'),
('Contested Histories / EuroClio','Memorial ACTe: Guadeloupe case study (2025)','https://contestedhistories.org/wp-content/uploads/OPXV_Memorial-Acte-Guadeloupe.pdf','institutional_report_search_excerpt','仅索引摘要见1794-04-11、24和06-04日期，PDF未逐页截图，不作为日级唯一证明'),
('Journal of the British Studies / Cambridge','Dominica 1790 archive chronology','https://www.cambridge.org/core/journals/journal-of-british-studies/article/place-of-refuge-to-republicans-and-royalists-the-french-revolution-in-british-dominica/25F4CEF27A430F4653C59D16174A9DE7','peer_reviewed_full_open_access','同一研究者网页，不新增独立文献'),
('Library of Congress','1965 Blackwall chronology via academic catalog','https://www.loc.gov/item/hlas-bi2023000044/','peer_reviewed_journal_catalogue_summary','不另计独立来源'),
]
added_sources=[]
for inst,title,url,ty,scope in source_entries:
 if url in existing_urls:continue
 i='V'+str(348+len(added_sources))
 SR['sources'].append({'id':i,'author_or_institution':inst,'title':title,'url':url,'type':ty,'actually_read_scope':scope,'manuscript_inspected':False,'read_scope_note':'网页可读文本/原印本转录或搜索摘要，区分与原纸本卷宗；访问日2026-11-08。','supported_event_candidate_ids':[],'supported_topic_ids':[],'access_verified_at':'2026-11-08','primary_source_type':'transcribed_primary' in ty,'separate_source_identity_note':'不同网页引用相同研究成果不按独立见证重复计。'})
 existing_urls[url]=i;added_sources.append(i)
ids=lambda *urls:[existing_urls[u] for u in urls]
u1='https://jamaica55.gov.jm/st-mary/st-mary-history/'
u2='https://www.loc.gov/item/hlas-bi2023000044/'
u3='https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1767'
u4='https://academic.oup.com/histres/article/97/278/573/7762616'
u5='https://nlj.gov.jm/history-notes/Chronology%20of%20Resistance%20in%20the%20British%20West%20Indies.pdf'
u6='https://www.cambridge.org/core/journals/journal-of-british-studies/article/place-of-refuge-to-republicans-and-royalists-the-french-revolution-in-british-dominica/25F4CEF27A430F4653C59D16174A9DE7'
u7='https://doi.org/10.14325/mississippi/9781617033100.003.0009'
u8='https://www.garifunanation.org/history/'
u9='https://www.persee.fr/doc/outre_0300-9513_1978_num_65_240_2127'
u10='https://contestedhistories.org/wp-content/uploads/OPXV_Memorial-Acte-Guadeloupe.pdf'
byid={e['id']:e for e in EV['events']}
template=copy.deepcopy(EV['events'][-1]);added=[]
def new(id,date,title,topics,actor,desc,place,sources,old=None):
 if id in byid:return
 e=copy.deepcopy(template)
 y=int(date[:4]);m=int(date[5:7]) if len(date)>4 else None;d=int(date[8:10]) if len(date)>7 else None
 e.update({'id':id,'date_text':date,'year':y,'month':m,'day':d,'date_precision':'day' if d else 'month' if m else 'year','topic_ids':topics,'title':title,'actor_entities_text':actor,'historical_description_zh':desc,'historical_place_name':place,'longitude':None,'latitude':None,'modern_reference_site':None,'geo_precision':'no_verified_coordinate','coordinates_support_sources':[],'source_ids':sources,'source_urls':[next(s['url'] for s in SR['sources'] if s['id']==x) for x in sources],'source_support_count':len(set(sources)),'claim_crosscheck_status':'individual_claim_recheck_required_primary_or_secondary_reading_scope' if len(set(sources))==1 else 'multiple_sources_not_independent_line_by_line_confirmation','evidence_status':'evidence_linked_candidate_not_published','previous_17c_story_ids':old or [],'pr289_preexisting_acadia_candidate_ids':[],'publication_status':'research_only','publication_review':'not_submitted','local_research_round':3,'scope_note':'第三轮补充：加勒比地方抵抗、殖民立法与短时占领，候审；不得扩为英国已证实疆界。'})
 EV['events'].append(e);byid[id]=e;added.append(id)
new('E18A3B-TACKY-HALDANE-1760','1760','Tacky领导反抗者夺取圣玛丽郡Fort Haldane的武器弹药',['E18-A07'],'Tacky领导的被奴役反抗者；牙买加殖民军事当局','牙买加政府地方史称St Mary起义者夺取Fort Haldane及弹药后转移。相关Fort Haldane仅为有证历史地名，未输入现代遗址GPS。','Fort Haldane / Port Maria, St Mary, Jamaica',ids(u1),['E6-T08'])
new('E18A3B-BLACKWALL-1765','1765-11','St Mary Blackwall率被奴役者在Whitehall庄园发动反抗',['E18-A06','E18-A07'],'Blackwall及被奴役的Coromantee等群体；牙买加种植园主和殖民军','国家图书馆编年将Blackwall带领的反抗定于1765年11月；1767法令证Whitehall发生实际起义；2021论文指出殖民书写掩盖妇女、马龙盟友身份与不同抵抗者。日级23日只有早期通史记述，本候选保留月级。','Whitehall Plantation, Saint Mary Parish, Jamaica',ids(u2,u3,u5),['E6-T08'])
new('E18A3B-LONG-REPORT-1766','1766-08-06','Edward Long向牙买加殖民议会报告1765年St Mary起义',['E18-A06','E18-A07'],'Edward Long、殖民议会议员及审查委员会','学术研究引述1766年8月6日Long提交殖民议会报告；其主张对Gold Coast部分被强迫贩运人口加征限制性关税，该议案未获得通过。殖民报告的污名化族群修辞不能等同叛乱者自述。','Spanish Town, Jamaica (assembly town representative; exact hearing room not geolocated)',ids(u4,u2),['E6-T08'])
new('E18A3B-WESTMORELAND-1766','1766','Westmoreland郡发生另一次Coromantee被奴役者反抗',['E18-A06'],'被奴役者；牙买加殖民当局','牙买加国家图书馆反抗编年单独登记1766年Westmoreland起义，与1765年St Mary及1760年Tacky战争不同。细节、人员名单及镇压结果待原档。','Westmoreland Parish, Jamaica',ids(u5),['E6-T08'])
new('E18A3B-YORK-CUFFEE-1767','1767-12-21','牙买加殖民议会立法释放York与Cuffee并授权补偿原奴隶主',['E18-A06'],'牙买加副总督、殖民议会、York和Cuffee、Ballard Beckford遗产继承人及James Charles Sholto Douglas','UNB公布的1767年12月21日原法转录明确York和Cuffee获个别解放，并规定原奴隶主分别获140英镑和80英镑法定补偿。金额是授权的定额，实际款项支付单据未核；条文是殖民当局对1765反抗的奖惩叙述，不能代替反抗者自己的口述。','Jamaica colonial assembly',ids(u3,u4),['E6-T08','E6-T07-BARBADOS'])
new('E18A3B-DOMINICA-LETTER-1790','1790-09-12','多米尼加代理总督向伦敦报告法属群岛革命难民与欠款',['E18-A19'],'James Bruce (Dominica acting governor); William Wyndham Grenville','剑桥开放获取论文逐字讨论1790年9月12日James Bruce写给英国内政大臣的函件，报告邻近法属群岛政治动荡、商债收不回及家庭避居多米尼加；移民身份不应一律归为自愿自由民。','Roseau / Dominica, lesser Antilles (administrative reference only)',ids(u6),['E6-T07-LEEWARD'])
new('E18A3B-GUAD-INVASION-1794','1794-04','英军与法王党盟军登陆瓜德罗普争夺奴役制度和殖民控制',['E18-A19'],'British forces and French royalist émigrés; French republican colonial forces','2025制度报告记英军4月11日进攻、UNESCO其他教材记4月9日；因登陆日期来源冲突，此处只用1794年4月，不制造精确日。英军合作的王党派企图保留种植园奴役制度。','Guadeloupe, French Caribbean colony',ids(u10,u6,u9),['E6-T07-LEEWARD'])
new('E18A3B-GUAD-SURRENDER-1794','1794-04-24','瓜德罗普法国驻军向英国侵略军投降形成短时英占',['E18-A19'],'Guadeloupe French Governor Collot; British General Charles Grey','2025历史机构专题及2024 Cambridge论文记英国与法王党合作短暂占据瓜德罗普；法国共和军在4月24日投降的具体日期待法方军令原卷再核。不得将此年的全岛短时军政占据延续到1795。','Basse-Terre, Guadeloupe (municipality reference, no precise capitulation GPS)',ids(u10,u6),['E6-T07-LEEWARD'])
new('E18A3B-GUAD-HUGUES-1794','1794-06-04','法国共和军Victor Hugues登陆瓜德罗普并组织解放被奴役者抵抗英军',['E18-A19'],'Victor Hugues、法国共和军、前被奴役者与自由有色人居民、英军','法国革命政府2月决定废除殖民地奴役；Hugues在6月登陆瓜德罗普组织反攻和发布当地解放政策。部分源记6月4日登陆，详尽军事日记仍待核。当地前被奴役者主动参战是政治主体，不是英法单纯换旗。','Pointe-à-Pitre / Guadeloupe (representative place, no surveyed landing GPS)',ids(u6,u9,u10),['E6-T07-LEEWARD'])
new('E18A3B-GUAD-FRENCH-RECAPTURE-1794','1794','Victor Hugues与获解放居民盟军使瓜德罗普结束短期英国占领',['E18-A19'],'法国共和军和获得解放的当地黑人战士；英军和保王党派','剑桥同行评审研究、1978学术研究一致说明1794年夏后Hugues在曾被奴役居民支持下夺回瓜德罗普；准确逐堡投降日期待军事原卷核，事件年份1794而非假定1890年代仍英占。','Guadeloupe',ids(u6,u9),['E6-T07-LEEWARD'])
# Garifuna historical date conflict: preserve event, correct date to month and log discrepancy
for e in EV['events']:
 if e['id']=='E18A-1797-A16-01':
  e['date_text']='1797-04';e['year']=1797;e['month']=4;e['day']=None;e['date_precision']='month'
  e['source_ids']=list(dict.fromkeys(e['source_ids']+ids(u7,u8)));e['source_urls']=[next(s['url'] for s in SR['sources'] if s['id']==x) for x in e['source_ids']];e['source_support_count']=len(e['source_ids'])
  e['claim_crosscheck_status']='date_conflict_Oxford_academic_11_April_vs_Garifuna_Nation_12_April_1797'
  e['historical_description_zh']+=' 日期争议：Christopher Taylor Oxford Academic章节摘要写1797年4月11日抵达；Garifuna Nation写4月12日，事件档案仅锁定四月，待航海日记原卷校验。'
# Dates count and metadata
EV['last_local_research_extension']={'research_round':3,'addendum':'Caribbean Blackwall, 1767 law, Guadeloupe, Garifuna date audit','new_events_v3b':len(added),'event_ids':added,'status':'research_only'}
SR['last_local_research_extension']={'research_round':3,'addendum':'Blackwall/Guadeloupe/Garifuna sources','sources_added_v3b':len(added_sources),'source_ids':added_sources}
# ALL valid sources, refresh evidence source backlinks
src_by_id={s['id']:s for s in SR['sources']};
for e in EV['events']:
 for sid in e.get('source_ids',[]):
  if sid not in src_by_id: raise ValueError('Unresolved source id '+sid)
  s=src_by_id[sid]
  if s.get('supported_event_candidate_ids') is not None and e['id'] not in s['supported_event_candidate_ids']:s['supported_event_candidate_ids'].append(e['id'])
  if s.get('supported_topic_ids') is not None:
   for tid in e['topic_ids']:
    if tid not in s['supported_topic_ids']:s['supported_topic_ids'].append(tid)
# Update topic index for all A/C - links and counts
for topic in TOP['topics']:
 te=[e for e in EV['events'] if topic['id'] in e.get('topic_ids',[])]
 topic['candidate_event_count']=len(te)
 topic['source_ids']=list(dict.fromkeys(topic.get('source_ids',[])+[z for e in te for z in e['source_ids']]))
 topic['candidate_geo_point_feature_count']=len([f for f in G['features'] if topic['id'] in f.get('properties',{}).get('topic_ids',[])])
 topic['v3_new_events_count']=sum(e.get('local_research_round')==3 for e in te)
 topic['index_refresh']='2026-11-08_round3_postQA'
TOP['last_local_research_extension']={'research_round':3,'total':len(EV['events']),'topic_index_refreshed':True}
# Extra topics (proposals, not PR289 IDs)
for id,title,ev in [('E18-A23','1765 Blackwall起义与1766殖民立法调查及1767 York/Cuffee赔偿法',['E18A3B-BLACKWALL-1765','E18A3B-LONG-REPORT-1766','E18A3B-YORK-CUFFEE-1767']),('E18-A24','1794英国入侵瓜德罗普、法国共和军反攻及解放者抵抗',['E18A3B-GUAD-INVASION-1794','E18A3B-GUAD-SURRENDER-1794','E18A3B-GUAD-HUGUES-1794','E18A3B-GUAD-FRENCH-RECAPTURE-1794'])]:
 if not any(t['id']==id for t in EX['topics']):
  el=[byid[k] for k in ev]; EX['topics'].append({'id':id,'editorial_state':'proposed_only_not_in_PR_289','title':title,'source_checked_event_count':len(ev),'events':ev,'dated_start_year':min(e['year'] for e in el),'dated_end_year':max(e['year'] for e in el),'source_ids':list(dict.fromkeys(z for e in el for z in e['source_ids'])),'boundary_and_GIS_notice':'Only proposal; no new historic boundary or publisher event approval.'})
# Additional quantitative claim, legislative sums authorized not payments
claims=CL.get('claims',[]);print('claims type',type(claims), 'CLkeys',CL.keys())
if isinstance(claims,list):
 claims.append({'claim_id':'E18-V3B-1767-YORK-CUFFEE-STATUTORY-OWNER-COMPENSATION','year':1767,'date':'1767-12-21','topic_ids':['E18-A06'],'source_ids':ids(u3),'claim_text':'牙买加殖民议会规定York原奴隶主遗产应获140英镑、Cuffee原奴隶主应获80英镑','population_or_value_kind':'legislated_owner_compensation_not_audit_of_disbursement','amounts_gbp_nominal':{'york':140,'cuffee':80},'paid_amount_verified':None,'people_freed_by_act':2,'quantitative_limitation':'法律承诺非财政支付凭证；不能当作两人出售价格或任何实际利润'})
# Chinese supplementary deep reports
newd=base/'DEEP_DIVES_V3';newd.mkdir(exist_ok=True)
newdocs={
'BLACKWALL_1765_1767.md':'''# 1765—1767年牙买加Blackwall起义与殖民司法、赔偿法规\n\n**性质：候审研究，不是正式地图事件。** 对应A06/A07；新增E18-A23仅为建议专题。\n\n## 背景\n英国殖民牙买加的糖业种植园由强迫劳动维持。1760年Tacky起义镇压后，St Mary地区Coromantee及其他非洲裔被奴役者继续组织抵抗；不能把1765起义合并为1760战争。\n\n## 决策与实际行动\n牙买加政府史称1760年Tacky一方曾夺取Fort Haldane军备；1765年11月Blackwall率反抗者在St Mary的Whitehall庄园发动起义。牙买加国家图书馆编年只证11月，早期叙述称23日，日级日期待原档；当代法律文书确认了Whitehall起义而以白人殖民者的利益为叙述出发点。\n\n## 司法与立法\n1766年8月6日殖民议员Edward Long提交审查1765起义的报告，建议通过关税阻止来自Gold Coast某些非洲人群的强制输入，但提案未通过。1767年12月21日殖民议会通过特别法释放York与Cuffee，条款规定向原奴隶主（或其遗产）分别支付**140英镑**与**80英镑**补偿。这是**法定授权**，不是已核实际拨款。\n\n## 具体地点\nSaint Mary Parish、Whitehall Plantation、Fort Haldane、Spanish Town（议会行政参考地）。上述事件未有测绘GPS，本包坐标一律null。\n\n## 相关人物与政治主体\nBlackwall、York、Cuffee、Edward Long、Ballard Beckford的遗产承继方、James Charles Sholto Douglas以及被奴役起义参与者。York与Cuffee的法定释放涉及其个人选择，不能简化为英殖民当局主动普遍解放。\n\n## 受害群体与抵抗\n1765被奴役的非洲裔居民及参与起义的妇女、马龙同盟者在殖民文书中可能遭匿名化；2021年Devin Leigh与Clifton E. Sorrell III学术论文专门研究这种书写失衡。\n\n## 经济后果\n确认立法付款额度140、80英镑，但缺收据与财政付款簿，不计入已获支付额。提议限制贩运非洲人的加税议案**未通过**。\n\n## 长期影响与未解决证据\n从Tacky的1760战争到1765另起起义以及1766—67殖民政府处理，构成武装反抗—恐慌—制法的跨年进程。下一步核1765年殖民议会Journal、Whitehall庄园账及受害人证词。\n\n## 主要来源\n- UNB原印本转录：https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1767\n- Cambridge/Oxford学术研究：https://academic.oup.com/histres/article/97/278/573/7762616\n- 美国国会图书馆学术目录：https://www.loc.gov/item/hlas-bi2023000044/\n- 牙买加政府：https://jamaica55.gov.jm/st-mary/st-mary-history/\n- 牙买加国家图书馆编年：https://nlj.gov.jm/history-notes/Chronology%20of%20Resistance%20in%20the%20British%20West%20Indies.pdf（当前仅查索引摘要）\n''',
'GUADELOUPE_1794.md':'''# 1794年英军入侵瓜德罗普、法国共和反攻及黑人解放者抵抗\n\n**性质：研究候审。** 属A19，新增A24仅为建议。\n\n## 背景\n法国大革命期间法属加勒比庄园主与法国共和政体争夺奴役制度；1794年2月法国共和政权宣布废除殖民地奴役，英军与当地法王党势力合作保护财产和奴役种植园。\n\n## 决策\n英国军方欲利用革命内乱取得群岛军事基地；部分法王党种植园主要求外来军事庇护。被奴役者和自由有色居民具有独立政治利益，不是双方指挥员的被动棋子。\n\n## 实际行动与日期\n1794年4月英军入侵。不同材料将登陆日写4月9或11，统一登记为**1794-04**；机构研究载**4月24日**法方殖民军投降。随后法国共和军Victor Hugues于6月率军返回，6月4日是机构研究所引日期，借当地已获解放居民之助收复瓜德罗普。该年度英国占领先发生后结束，不能将其政治状态延到1795年。\n\n## 具体地点\nGuadeloupe、Basse-Terre、Pointe-à-Pitre。仅当代具名地点，未核军事降书具体GPS或历史军控线，坐标保留null。\n\n## 相关人物\n英军、法国保王派、Victor Hugues及他所结盟的受解放黑人兵士与自由有色居民。\n\n## 受害群体与反抗\n被奴役者面对保王派和英军维持奴役经济的风险，获释放的居民参加法国共和军队作战；不同政治阵营中也存在对白人与黑人居民的镇压。\n\n## 经济后果\n短暂英占涉及种植园财产权与奴役制度，但无可核逐庄园没收净收益，本包不记利润和面积。\n\n## 长期影响\n1794年被征服与再征服揭示加勒比殖民版图**在同年多次变化**，地图年度状态应展示阶段事件，年末英占控制必须核为已结束的据点而非持续英属群岛。\n\n## 未决问题\n英国登陆4月9日/11日冲突、各军堡交还日及相关黑人士兵名册、英法押解与私掠账。\n\n## 来源\n- Heather Freund, Cambridge开放获取研究：https://www.cambridge.org/core/journals/journal-of-british-studies/article/place-of-refuge-to-republicans-and-royalists-the-french-revolution-in-british-dominica/25F4CEF27A430F4653C59D16174A9DE7\n- 1978学术研究：https://www.persee.fr/doc/outre_0300-9513_1978_num_65_240_2127\n- 2025机构研究摘要（全文待页核）：https://contestedhistories.org/wp-content/uploads/OPXV_Memorial-Acte-Guadeloupe.pdf\n''',
'GARIFUNA_ROATAN_DATE_CONFLICT.md':'''# Garifuna被迫迁往Roatán：1797年4月11日与12日的冲突\n\n既存`E18A-1797-A16-01`已从日级改为**1797-04**月级。\n\n- 学术专书Christopher Taylor《The Black Carib Wars》chapter 8, Oxford Academic 公开摘要使用**11 April 1797**和2,026名抵岸者，另称其中664名男性、1,362名女性与儿童。网页章节正文限制访问。https://doi.org/10.14325/mississippi/9781617033100.003.0009\n- Garifuna Nation族群历史页写**12 April 1797**、约2,500名抵达；社区观点须保留。https://www.garifunanation.org/history/\n- 其他二次研究反复引用Nancie L. Gonzalez分阶段总数：Baliceaux被扣押、从圣文森特登船、Roatán靠岸、转往Trujillo是四种不同分母；本批不把约2500与2026、2248等混为一个精确总数。\n\n**后续核证目标**：1797年押送舰船日志与海军航海日期格式、岸上登陆记录、英西文件是否采用不同历法和起始时间、4月11日抛锚与4月12日实际登陆是否可分。\n\n**制图语义**：圣文森特—Baliceaux—Roatán地点间的历史关联有证，但未证逐段航迹时只登记文字顺序，严禁画直线航线；坐标仍null。\n'''}
for name,content in newdocs.items(): (newd/name).write_text(content,encoding='utf-8')
# append to original related topic files, once
for tid in ['E18-A06','E18-A07','E18-A16','E18-A19']:
 p=base/'TOPIC_DOSSIERS'/f'{tid}.md'
 section='\n\n## 第三轮后续补充：牙买加Blackwall、瓜德罗普与Garifuna原始证据校验\n'+ ('- 查1765年St Mary的Blackwall另次起义及1766报告、1767特殊解放法；见 `DEEP_DIVES_V3/BLACKWALL_1765_1767.md`。' if tid in ['E18-A06','E18-A07'] else '- 查1797 Roatán上岸日期冲突及不同人口分母；见 `DEEP_DIVES_V3/GARIFUNA_ROATAN_DATE_CONFLICT.md`。' if tid=='E18-A16' else '- 查1794瓜德罗普的英军短时夺取及法国军民反攻；见 `DEEP_DIVES_V3/GUADELOUPE_1794.md`。')+'\n'
 c=p.read_text(encoding='utf-8');
 if section not in c:p.write_text(c+section,encoding='utf-8')
# append conflicts
conf=base/'GAPS_AND_CONFLICTS.md'
with conf.open('a',encoding='utf-8') as out:
 out.write('\n\n## 第三轮最终补充：新核法律、加勒比短时换旗与日级冲突\n')
 out.write('- **1765 Blackwall起义**：牙买加政府和国立图书馆、2021学术论文、1767原法可互补，但殖民法文书以种植园主视角书写；独立调查起义妇女和马龙参与者姓名。\n')
 out.write('- **1767 York/Cuffee赔款**：法规定140和80英镑分别补给原持有人，已核**立法承诺**而非税务收据、已核支付或奴隶拍卖成交价。\n')
 out.write('- **1794瓜德罗普英军登陆**：部分机构资料写4月9，另一些写4月11，候选日期保留四月，不创建臆测登陆GPS。4月24日投降、6月法国反登陆及年内法国收复分别登记，绝不延续英国占领至1795年。\n')
 out.write('- **1797 Garifuna抵Roatán日级冲突**：Taylor/Oxford写4月11日，Garifuna Nation写4月12日，故现将老事件日期统一暂设1797-04并保留两边；2,026与约2,500口径/取整不同，原始押送清单待核。\n')
# progress appended
pr=base/'PROGRESS.md'
with pr.open('a',encoding='utf-8') as out:
 out.write(f'\n\n## 第三轮最终扩展与跨版本封包校验（2026-11-08）\n- 当轮追加**{len(added)}件**加勒比地方行动：Blackwall 1765/殖民议会1766/立法1767、1794瓜德罗普英占与法方反攻等；另新登记**{len(added_sources)}个**独立来源条目。\n- Garifuna 1797年4月11日与12日两种可核出版记载冲突已转为月级事件，不默认挑某日。\n- 在`DEEP_DIVES_V3/`追加3份中文核证报告，所有原49母题仍存在，无GitHub修改。\n')
dump('EVENT_CANDIDATES.json',EV);dump('SOURCE_REGISTRY.json',SR);dump('TOPIC_INDEX.json',TOP);dump('PROPOSED_ADDITIONAL_TOPICS_V3.json',EX);dump('EVIDENCE_CLAIMS_V3.json',CL)
# csv fieldname union preserve field order
names=list(dict.fromkeys(k for e in EV['events'] for k in e))
with (base/'EVENT_CANDIDATES.csv').open('w',encoding='utf-8-sig',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=names);writer.writeheader();
 for e in EV['events']:
  writer.writerow({k:(json.dumps(v,ensure_ascii=False) if isinstance(v,(dict,list)) else v) for k,v in e.items()})
print(json.dumps({'added_event_ids':added,'new_source_ids':added_sources,'total_events':len(EV['events']),'total_sources':len(SR['sources']),'garifuna_month_updated':True,'new_docs':len(newdocs),'new_proposals_total':len(EX['topics'])},ensure_ascii=False,indent=2))
