from pathlib import Path
import json, hashlib, zipfile
r=Path('/mnt/data/18c_assistant_A'); e={a['id']:a for a in json.loads((r/'EVENT_CANDIDATES.json').read_text(encoding='utf-8'))['events']}; p=r/'NUMERICAL_EVIDENCE_V5.json';a=json.loads(p.read_text(encoding='utf-8'))
for row in a['records']:
 ids=[]
 for x in row.get('event_ids',[]):
  if x in e: ids.extend(e[x].get('source_ids',[]))
 if ids:row['source_ids']=sorted(set(ids))
 if row['id']=='V5-NUM-1700-1799-TRANSPORTED': row['value']=None
p.write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
skip={'MANIFEST_V5.json','SHA256_SUMS_V5.txt'}
files=sorted(f for f in r.rglob('*') if f.is_file() and f.name not in skip)
recs=[{'path':str(f.relative_to(r)),'size_bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in files]
(r/'MANIFEST_V5.json').write_text(json.dumps({'schema':'v5-local-archive-file-manifest','date':'2026-11-08','root_directory':'18c_assistant_A','file_count_excluding_manifest_and_sha':len(recs),'records':recs},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(r/'SHA256_SUMS_V5.txt').write_text('\n'.join(f"{x['sha256']}  {x['path']}" for x in recs)+'\n',encoding='utf-8')
out=Path('/mnt/data/18c_assistant_A_americas.zip')
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as z:
 for f in sorted(ff for ff in r.rglob('*') if ff.is_file()):z.write(f,arcname=str(Path('18c_assistant_A')/f.relative_to(r)))
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 print('PASS',len(z.namelist()),'files',out.stat().st_size,'bytes','linked',sum(bool(x['source_ids']) for x in a['records']),'numerical rows')
