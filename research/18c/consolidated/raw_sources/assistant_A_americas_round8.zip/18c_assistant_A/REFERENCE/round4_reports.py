import json, csv, pathlib, collections, hashlib, zipfile, datetime
R=pathlib.Path('/mnt/data/18c_assistant_A'); E=json.loads((R/'EVENT_CANDIDATES.json').read_text());S=json.loads((R/'SOURCE_REGISTRY.json').read_text());T=json.loads((R/'TOPIC_INDEX.json').read_text());v4=[e for e in E['events'] if e.get('local_research_round')==4]
newdir=R/'DEEP_DIVES_V4';newdir.mkdir(exist_ok=True)
lookups={s['id']:s for s in S['sources']}
chapters={
'JAMAICA_1717_1751_PENAL_CAPITAL.md':{
 'title':'1717—1751年牙买加：处决补偿、追捕赏金、火药禁售与杀人刑罚',
 'topics':['E18-A05','E18-A06','E18-A07'],
 'background':'牙买加17世纪已由殖民议会建立世袭奴役与追逃法律；1700年以后，殖民统治不只是种植园个别经营者的暴力，军政财政还把追捕奖励、官员任命、人口买卖和诉讼成本纳入正式法条。早期法条反复提及逃亡山地群体，反映被奴役者通过离开庄园和自组织施加压力。',
 'decision':'1717年法令规定，司法处决奴役者后其原主可请求政府以审判估值给付补偿，每人最高40牙买加流通镑；1718年自愿武装追捕法对抓捕或杀死一名年满14岁的被称“rebellious”奴役者规定每名50镑的法定奖赏，另把未满14岁的被俘儿童直接授予追捕队员及其继承人。这是严重的人口商品化条款，与被处决者原主补偿是不同支付途径，不能把两法金额加总为政府实际支出。',
 'actions':'1730年立法要求有许可的火药零售商在西班牙镇、皇家港、金斯敦经营，设500镑履约保函，法律明确拒绝对被奴役黑人、混血和原住民卖火药，已有自由身份者也必须持军官证明。1744年以“叛乱”称谓进行镇压相关法律并具名释放Hector；1751年法令处理奴役主及其他人杀害奴役者的刑事责任：首犯法律仍承认旧式神职豁免，另有至多12个月监禁，若杀害他人所谓财产则罚60镑给旧主，发生此前已经定罪后再犯才触发更重刑。',
 'places':'地名已查证：Jamaica，St Jago de la Vega（Spanish Town）、Port Royal和Kingston；1718年离首府20英里之外的教区构成法条地理适用条件，但没有同代路程或行政界线校准，地图只保留具名参考点研究线索。',
 'persons':'决策方：殖民总督、议会、2名治安法官签发证明、教区军官和民兵。被法律分类为“rebellious”的人有独立的逃亡与结社行动；儿童被当作奖赏是特别重要的受害群体。1744年Hector为明确见诸具名法案的人，但其整个个人生平仍需查契据与个人账。',
 'resistance':'1718年法律的成立前言直言此前数批常设追逃队未能消除逃亡抵抗，显示马龙社群的长期存续。当地黑人及原住民群体不是殖民法律对象的同质总体，法律文字是立法者的敌对视角，需以反抗者自述、传承和马龙社区档案相补。',
 'economics':'1717每人40镑上限、1718每名成年反抗者50镑法定赏金及未满14岁儿童作为战利品、1730许可商保函500镑、1751杀害他人奴役者60镑均逐项放入法律金额字段；未有财政实际支出账、营收账或奴役者实际身价评估，全部不纳入真实贸易金额统计。',
 'impacts':'这些财政和刑政结构促使殖民政权将逃亡、山地政治自治和种植园投资利益系统联结。后续1739条约、1760起义及1769追逃奖励修改形成制度连续性；是否在各年实际执行需另查TNA CO殖民档、Jamaica Archives议事录和各教区审判账。',
 'map':'不画全岛镇压区，不用现代行政线表示18世纪追捕范围。17世纪前篇E6-T08法律与马龙自治按原年保留；只有具名城市可添加经外部验证的现代参考坐标，暂不输出经纬度。',
 'sources':['V4001','V4002','V4003','V4005','V4008']},
'JAMAICA_NAMED_FREEDOM_1760_1774.md':{
 'title':'1760—1774年牙买加具名人员：殖民议会解放法、镇压奖励和女性个人经历',
 'topics':['E18-A07','E18-A06'],
 'background':'“镇压1760起义”若只按殖民军行动编年，难以看到被奴役人口的不同政治策略。殖民议会法案恰好保存了具名人的信息，但这些人物多是因向当局提供情报或镇压行动而进入白人立法者的文字，不能据此概括全部被奴役者的态度，也不能轻易称被解放者完全免于贫困或歧视。',
 'decision':'1760年12月18日议会一份法令宣布18名具名男女解放，其中有Foster、Pembroke、George、Cuffey、Blackwall、Moll及其子Quaco、Congo Molly等。完整名单有两位不同的Billy，故切勿利用不带主人的姓名直接合并为同一人。该法给每人5镑年金的文字是法律承诺，而不是支付清单。',
 'actions':'1761年12月19日Saint Mary的Jack具名获释，并获5镑年度给付安排；1763年12月1日Westmoreland的Jack Pearson获释并规定原主William Ricketts遗产可收60镑；1764年11月9日Cato获释并规定对Arthur Forrest支付70镑。1772年12月23日Will获释并获每年10镑、其原主遗产获100镑的规定。1774年11月19日Attea作为一名女性被奴役者在针对Westmoreland八月“阴谋”的法律里具名获释。',
 'places':'已知Saint Mary、Westmoreland、Saint Catherine三个牙买加教区和Jones’s Pen具名庄园。法令仅证明历史地名而未记庄园精确坐标；历史教区界线更不能复制现代行政面。',
 'persons':'Congo Molly、Moll与Attea为女性被奴役者具名记录，显示被奴役妇女的社会行动不能在整体“起义人数”中消失。Sam是另一名奴役者，1772年法条追述其因3月31日杀死监工Andrew Ross被定罪并判火刑；除找到法院执行文书外，不能改写为已实际火刑处死。',
 'resistance':'1760年起义和之后若干阴谋调查本身伴随逃亡、跨庄园联络和殖民社会秩序的恐慌。多位获释者参与镇压或提供信息是一种被迫制度下的生存选择，不能用简单二元标签替代不同人的动机。1774年八月“阴谋”目前只见议会单方面前言，仍待审判与当事人陈述。',
 'economics':'1760年18人各5镑年金；1761 Jack每年5镑；1763 Jack Pearson原主遗产60镑；1764 Cato原主70镑；1772 Will每年10镑与原主100镑。法定金额不同币别或年限的项目不能相加为本年预算，所有实际支付账、年金到帐日期、自由者财产权仍为空值。',
 'impacts':'这批具名议会文本为一组可检索的“姓名—日期—旧主—法定赔偿”关系证据，适宜在未来前端显示为人员网络与法律事件，不适宜绘无依据的私人住处和行踪GPS。需进一步查奴役者死亡、遗产和教区登记档、报纸、教会洗礼记录，验证这些人的后续经历。',
 'map':'只标法律事件的教区/城市参照地，地点精度不足者坐标null；不把法案文本提及的教区直接当遇害/战斗现场。',
 'sources':['V4009','V4010','V4012','V4013','V4016','V4018']},
'MAROON_CUDJOE_TREATY_1739_1788.md':{
 'title':'1739—1788年牙买加马龙政治：Cudjoe条约的土地承诺与追逃义务',
 'topics':['E18-A05','E18-A11'],
 'background':'E6-T08的1655—1699年山地逃亡社群已经有明确的政治自主历史。18世纪马龙并非单纯一个战争名称，而是不同山地城镇、领导者、定居农田与贸易空间交错的社群。1739年和约的长期性来自条款、行政修改和马龙人的实际政治活动，而非英国已经完全征服所有山岭。',
 'decision':'1739年3月1日（史料旧历1738-9）Cudjoe、Accompong及其他队长同英国民兵Colonel John Guthrie、Lieutenant Francis Sadler订立协议；第3条规定自Trelawny Town向西北至Cockpits之间共1500英亩予其后裔，第4条准许部分作物贸易，第12条确认有限内部惩戒权。名称及英亩数是合同陈述，并未包含足够的测量点、拐点、地籍回单，不能直接落Polygon。',
 'actions':'条约第6条要求马龙人协助镇压其他反抗者，第9条要求将其控制下的逃亡奴役者送交最近行政长官；后续殖民法律规定报酬。1769年修正案将相关赏金条款自1770年3月1日起调整；1788年1月10日法令又在马龙镇引入白人监管员以及刑罚程序，对此前既存自主作出制度侵蚀。',
 'places':'Trelawny Town、Cockpit Country、Westmoreland、St James、St Elizabeth有源。第13条要求开道路，仅是义务条款，不是道路已经施工完毕的路线证据。A01/A05不应因地图上马龙镇显示英国代表点就把整片山地视作英国直接管控。',
 'persons':'Cudjoe、Accompong、Johnny、Cussoe、Quaw；英方Guthrie、Sadler。双方共同签名/印记说明协议由政治代表谈判，马龙自治不能被写成英国“施予自由”这一单方行动。',
 'resistance':'马龙长期防卫与定居令殖民军难以镇压，形成英方谈判背景。条款同时制造马龙城镇与新逃亡者间紧张关系，历史上不同社区对追捕和英方任命人的反应并不一致。',
 'economics':'1500英亩是协议中的土地产权数量，并非18世纪完成测绘的真实控制面积；法定追捕赏金及距离报酬要与真实支出分开记录。马龙农耕、商品交换和造路负担的收益无法凭条约计算。',
 'impacts':'1795—1796年第二次马龙战争和对Trelawny居民的流放，需接续此前各项条约承诺及后来的行政干预；不能把英国当局的“违约”指控直接当裁定。应核原始地籍及1796押送人口名册。',
 'map':'建议为条约土地声索新建独立线索图层：由1739第3条引出、历史边界未测量，默认不绘面；若未来能找到同时代测量文件，仅可绘审定的虚线界址，并明确既非真实英国领土也非全体马龙领土。',
 'sources':['V4004','V4014','V4020']},
'CARIBBEAN_ISLAND_STATUTES_1767_1784.md':{
 'title':'1767—1784年圣文森特、巴巴多斯、多米尼克、圣基茨、巴哈马：跨岛奴役法律对比',
 'topics':['E18-A06','E18-A14','E18-A19','E18-A22'],
 'background':'英国加勒比殖民地不是统一立法机关，1770年代各岛的法律虽都有种植园奴役制，却在行政批准、继承法、自由身份登记、强制征调和受害者赔偿等方面各有条款。把所有岛屿的“黑人法律”当一份英王统一法律会遮蔽各岛殖民议会责任。',
 'decision':'圣文森特1767年7月11日法律由总督Robert Melvill及岛议会通过，将被奴役者用于继承视作不动产，同时在遗产债务清偿时又视作动产；1773年多米尼克将自由黑人及混血男性纳入由白人军官领导的强制追逃队伍，并规定身份注册。巴巴多斯1766年4月15日地方法案需等1767年7月24日王室核准，体现地方与帝国两道行政步骤。',
 'actions':'圣基茨1783年12月18日法律因残害被奴役者而规定500当地镑处罚，但也允许将受害者扣押及在特定法律条件下公开拍卖。巴哈马1784年法律允许自由证不足者被羁押和拍卖，即便证明自由的黑人仍可能被要求三月内离开群岛或交90当地镑保证金。这些法律要与实际驱逐、处刑、民兵行动的案卷分开调查。',
 'places':'St Vincent、Kingstown、Barbados、Dominica、St Christopher（Basseterre）、Bahamas各地是具名法辖区；巴哈马“群岛”不是逐岛政府掌控边界，也不能为奴役制度本身着真实占地颜色。',
 'persons':'圣文森特殖民总督Robert Melvill；各地殖民议会、司法官、白人军官与警长为制度主体。被奴役黑人、自由黑人与原住民居民的法律身份界限可被法条重新划分，从身份差异反映殖民暴力。',
 'resistance':'自由居民要求证明自身身份、逃亡者避入山区、奴役者结社及寻找庇护的行为可从法律的反向限制窥见。条文的“盗窃”“叛乱”等带殖民当局偏见的词语需要对照当事人视角。',
 'economics':'1767 Saint Vincent继承财产权≠殖民者实际获地数量；1783圣基茨500镑是法定罚金；1784巴哈马90镑是财务担保要求。自由者被卖价或实际拘留次数均未知，不能用法律额计算殖民税收及总利润。',
 'impacts':'岛际比较显示18世纪后期英国殖民统治为种植园主不断设计法律资产权、追逃组织与自由身份管理。未来可设岛屿法令事件节点，但每座岛的政治实控界线、实际驻军控制和种植园地籍必须分别审核。',
 'map':'各岛使用现代官方国家历史遗址参考点需另找官方GPS，禁止随便以首府中心点作为原历史议会大厅的精确位置；无历史地籍则不画多边形。',
 'sources':['V4021','V4022','V4023','V4024','V4025']},
'CHEROKEE_LAND_BOUNDARY_1768_1770.md':{
 'title':'1768—1770年切罗基土地边界外交、英国贸易委员会质疑与条约日次冲突',
 'topics':['E18-C11','E18-C13','E18-C21'],
 'background':'1763王室公告对欧洲移民西进采取限制后，英国殖民地总督、原住民事务总监与豪德诺索尼、切罗基、肖尼等不同政治主体反复交涉。依据英国单一王室地图把北美大片地区涂为“签约后已征服”既忽视不同民族的土地权益，也忽视英方内部对签约权限的争执。',
 'decision':'1768年10月14日Hard Labour条约由John Stuart与Cherokee代表讨论新界线；另有美国国家公园管理局叙述10月17日，日次存在文书阶段差异，目前将既有旧事件维持月级。1768年11月5日Fort Stanwix协议的另一边界由Sir William Johnson及Haudenosaunee等代表议定，牵涉Shawnee、Delaware及Cherokee所主张的不同土地。',
 'actions':'1769年4月25日英国贸易委员会书面批评Johnson在Fort Stanwix偏离指示，指北部条约越过与切罗基先前谈妥的界限，委员会把原住民族各异的权利明确记入报告。1770年10月18日Lochaber开始会议；文书还记10月22日条约安排及12月12日议事会宣读，不能在前端以一天等价不同政治程序。',
 'places':'Hard Labour（南卡罗来纳），Fort Stanwix/Oneida Carry（现纽约州Rome一带），Lochaber（南卡罗来纳）。贸易委员会奏呈于伦敦Whitehall，和土地声索发生地相距甚远；Whitehall事件点仅为行政档案地点，严禁把它连直线当1780前真实军队线路。',
 'persons':'John Stuart、William Johnson、英国贸易委员会官员；切罗基首领Attakullakulla、Oconostota及名单其他代表，六族首领与不同原住民族的代表具有各自政治主张。殖民谈判中不同翻译、测绘和地契持有人可能有相互冲突的利益，待逐方史料。',
 'resistance':'Cherokee等原住民族采用外交协商、界线条件和持续主权诉求回应定居扩张。英方并非唯一谈判者，更不是可以代表所有土地权利者的共同受托人。英国贸易委员会自己承认不同族群利益冲突，就是反对粗略统一着色的重要档案。',
 'economics':'1769年奏呈写Fort Stanwix谈判涉及总估值£10,460 7s 3d的财物与金钱，这是英国报告中的名义价值，不应当作Cherokee、Shawnee及全部人群都真实收到且满意的金额。土地租金、地价与实际移民人数需另查测绘申诉。',
 'impacts':'1770后王室划界继续受到殖民移民、原住民政治和美国革命变化影响；独立后土地交易不能自动计入英国军事扩张。1710/1737等旧地权专题与此为制度后果衔接，不是同一份条约重复发表。',
 'map':'仅保留具名条约地点和文书中的历史河流拐点描述；没有原地图地理配准成果则暂不输出LineString。未来如批准绘制，必须是“1768英国条约声索、不同原住民族争议、虚线概念界”，不得标实际英军占地。',
 'sources':['V4026','V4027','V4028']},
'NYC_SLAVE_HIRE_WALL_STREET_1711.md':{
 'title':'1711年纽约Wall Street奴役劳力雇佣市场：市政档案与17世纪纽约制度接续',
 'topics':['E18-C23','E18-C24'],
 'background':'荷兰新阿姆斯特丹奴役制度与1664/1674英荷政权变化，在E6-T09-NY已有已核连续性前篇。英国统治下的18世纪纽约，不只发生1712年反抗和1741年司法镇压，城市市议会还正式配置奴役者临时雇佣、奴隶主收入与日常劳动秩序。',
 'decision':'纽约市官方档案馆记载1711年11月30日市议会将Wall Street Slip指定为雇佣被奴役非洲及原住民劳动者的地点。这是殖民市政决策，不应把受奴役者所有身体都简化为一处买卖场地；市场的实际经营时数、人口与每人租金待核市议会议事簿、雇佣票证和地方账。',
 'actions':'殖民政府通过市场地点安排强化了奴役人口工作、交通与收费管理。1712年纽约黑人起义与后续严刑法规属于另项同时期事件，需并列呈现但不可声称市场直接引发了全部起义。',
 'places':'Wall Street Slip及New York城市海滨具有历史地名，有不同世纪填海和岸线变化。不能拿当今华尔街路口GPS当1711年市场的精确建筑位置，暂保留空坐标。',
 'persons':'纽约殖民市政委员会、奴役主、被奴役非洲裔及原住民居民构成三种不同身份；档案机构未在这份综述中给出单个劳动者名册，故个体姓名不编。',
 'resistance':'被奴役者通过日常拖延、逃亡、聚会与公开暴动争取生活空间；这些机制须从1712被捕人证词与1720年代法庭记录补证，而不能凭市场管理条例臆测个人动机。',
 'economics':'法令证明劳力作为按日/次出租的商品进入城市市场经济；每年雇佣人数、雇佣金额、租金归属及市政税额未从原文建立，均保留空值。',
 'impacts':'1783英国撤离和1799纽约州渐进解放法的政治主体不同：1799年法令属于美利坚合众国纽约州，若在专题回顾提及，应仅标为英殖民制度的后果，绝不能在英国当年征服/立法年度地图上给英国政府记一件1799政策。',
 'map':'地点仅作“具名历史城市地名待定位”，未来可据历史市政航图校准单个市场参照点。纽约城市的市政管辖不等于其外原住民地权皆消失。',
 'sources':['V4029','V4030']},
'DENE_THANDELTHUR_BEOTHUK_1714_1786.md':{
 'title':'1714—1786年北方原住民政治：Thanadelthur外交与Beothuk土地处境',
 'topics':['E18-C20','E18-C27'],
 'background':'哈德孙湾公司交易站在17世纪就依靠克里等原住民商业网络；18世纪沿岸欧洲主权声索与Dene、Cree自主政治之间仍存在巨大落差。纽芬兰贝奥图克人的海岸生存也不断受到渔业和殖民扩张压力，英方个别“保护”公告不足以结束冲突。',
 'decision':'1714年Dene女性Thanadelthur逃离被俘处境后进入York Factory。1715—1716年她帮助HBC商人William Stuart及Cree团体同Dene谈判，她在翻译、穿越地区与劝说中的主导角色为加拿大公园局正式纪念的历史人物贡献。英国公司想获得毛皮通道，但和平并非公司的单方面命令。',
 'actions':'1717年夏公司在Churchill River建立商站，后续交易也须经原住民社区同意和供应；1768年纽芬兰行政长官派John Cartwright调查Exploits周围Beothuk处境，1769年John Byron发布保护公告，1773年Cartwright绘制岛屿内陆地图，1784年George Cartwright提议保留地，1786年George Christopher Pulling提出派船接触建议。各项文书不能统一成英方有效控制所有内陆地区。',
 'places':'York Factory、Churchill River、Exploits River、Notre Dame Bay、Bishop Falls等史料地名有出处；公园局纪念牌坐标不等于1715一行人真实每一站点，Cartwright画出的河流也不是军事巡逻线。',
 'persons':'Thanadelthur（Dene女性外交家）、William Stuart、Cree谈判代表与Dene政治主体；John Byron、John Cartwright、George Cartwright、George Christopher Pulling及Beothuk社群成员。欧洲文书里原住民个人姓名不全，不能据此消除当地政治主体。',
 'resistance':'Thanadelthur主动谈判、使用多种语言，把她自己民族的和平目标带入跨文化商贸；Beothuk通过保持内陆联系、资源利用与拒绝部分欧洲接触维护生存空间。英国军政公告反映殖民官员对攻击行为已有认识。',
 'economics':'毛皮供给由原住民猎户和协商贸易网络构成；没见准确1717贸易入账、站点利润、Dene人口数和贝奥图克死亡总数，全部留空。',
 'impacts':'该线索给1713 HBC法国战后还堡与1774内陆Cumberland House建站补充原住民自主连续性；不应把“公司设站”画成扩大完整鲁珀特地真实统治。1750—1799纽芬兰渔业权与Beothuk生存地理仍需按海岸段落继续核原始船长日记。',
 'map':'参考点只能依据已定位的公司站点或官方历史纪念遗址；战争路线、外交穿越、Beothuk活动季节范围均暂不绘线或面。',
 'sources':['R27','V4031','V4032','V4033']},
'JAMAICA_1770_1774_URBAN_PORT_AND_FREEDOM.md':{
 'title':'1770—1774年牙买加港镇居所登记、奴役人口进口关税与解放手续',
 'topics':['E18-A04','E18-A06','E18-A07'],
 'background':'跨大西洋奴役不是船卸货后才开始的分散事件；牙买加的城镇居所、海关和乡村种植园互相支撑。1760年之后殖民当局一方面限制镇内被奴役人口居所与聚会，一方面对进口人口设税，并使自由身份获取成为一套金融担保制度。',
 'decision':'1770年12月19日牙买加法令针对Spanish Town、Port Royal、Kingston的奴役者居住棚屋，规定业主登记住所和住户，四座及以上须共同设围墙并维持单入口，未遵守时官员可命拆除；殖民条例自己提到逃亡者在城镇藏身，是有关反抗空间的重要间接证据。',
 'actions':'1774年2月12日殖民议会通过新增进口奴役人口关税法，2月13日Basil Keith批准，属于财政立法而非证明本年已进口的被奴役者总数；1774年12月24日私人释放被奴役者须先安排终身每年5镑保障，属于对自由资格的财政门槛。Westmoreland当局在1774年8月指控奴役者阴谋，11月19日议会具名释放Attea，恰可作为受害者和殖民奖惩制度个案展示。',
 'places':'Spanish Town、Port Royal、Kingston是明示法辖区和居住棚屋网络，Westmoreland是不同的乡村教区。没有棚屋地籍、海关泊位和17世纪老城郭地理转绘，不能制作所谓殖民镇压覆盖区。',
 'persons':'殖民议会、Basil Keith、镇民、海关和船东；Attea及镇内不知名的奴役居者。城市黑人社区既有劳务依赖也有情报传递、聚会与生存空间。',
 'resistance':'1770年法令以担忧逃亡者入住棚屋为由试图限制居所，反向说明逃亡者可能借城市民居寻求帮助。对“阴谋”的自述必须作为殖民当局指控，不能未经原始审讯即作为已证起义。',
 'economics':'1774新进口税的征税基数、单船税单、关税总收入未从法文建立。居所拆除是否涉及财产赔付未知。Attea或其他获释者的法定金额若无法确认实际支出，不与进口关税相加。',
 'impacts':'至世纪末牙买加已形成城内、乡村和跨洋相衔接的殖民管制制度；可按法令条款逐年制作地图信息层，但每类地理含义要分开。',
 'map':'只记相关城市现代代表地名（若后续有可信官方GIS才赋坐标），不要从一段法令把整座城市所有黑人居所标出，也不要把海关税法当船舶具体航路。',
 'sources':['V4015','V4017','V4019','V4018']}
}
heads=[('background','一、历史背景与17世纪承接'),('decision','二、殖民决策及文书性质'),('actions','三、具体行动及时间'),('places','四、历史地点与路线'),('persons','五、当事人物与受害群体'),('resistance','六、原住民或被奴役者的抵抗／政治主动性'),('economics','七、经济后果与金额口径'),('impacts','八、制度延续及长期后果'),('map','九、GIS证据和边界审查')]
for fn,rec in chapters.items():
    events=[e for e in v4 if set(e['topic_ids'])&set(rec['topics'])];events=sorted(events,key=lambda x:(x['year'],x.get('month') or 0,x.get('day') or 0))
    source_ids=sorted(set(rec['sources'])|set(v for e in events for v in e['source_ids']))
    top=f'# {rec["title"]}\n\n**本地研究阶段**：第四轮，2026-11-08。**研究等级**：`research_only`。**相关专题**：'+', '.join(rec['topics'])+'。\n\n**史料层级**：读取了所列在线原始法律／条约转录、政府历史机构文章；不是原始纸本逐页核验。殖民法规记录的是条文、官员陈述及预期结果；未发现实际军政执行和付款凭证时均记为未知。\n\n'
    for k,h in heads:top+=f'## {h}\n\n{rec[k]}\n\n'
    top+='## 十、已入库的相关事件候选（筛选，并非本报告已完成逐件双独立交叉核实）\n\n'
    for e in events:top+=f'- `{e["id"]}`｜{e["date_text"]}｜{e["title"]}。来源：'+', '.join(e['source_ids'])+'。\n'
    top+='\n## 十一、原始文书和阅读说明\n\n'
    for k in source_ids:
        if k in lookups:
            s=lookups[k];top+=f'- `{k}` [{s["title"]}]({s["url"]}) — {s.get("actually_read_scope","")}\n'
    top+='\n## 十二、未解决问题与下一步原档\n\n需要独立核对原始殖民议会记录、官员书信、被捕者口供、登记和财政实付账、当地原住民及马龙口述史；没有证据的伤亡、贸易收入和面积不估算。若地图采用条约边线，先收原图和地籍报告，后做明确标“历史声索、边界不确”的虚线参考，永不当已核实实际军事占领。\n'
    (newdir/fn).write_text(top,encoding='utf8')

# append unique V4 addendum to original 49 reports, preserving old material and IDs
for t in T['topics']:
    related=[e for e in v4 if t['id'] in e['topic_ids']]
    if not related:continue
    path=R/t['dossier_path'];old=path.read_text(encoding='utf8')
    tag='## 第四轮原法/条约原文增补（2026-11-08）'
    if tag in old:continue
    lines=['',tag,'','本轮以新不伦瑞克大学历史立法转录、美国原始条约校订及加拿大/地方官方史研究补足以下独立候审节点。日期按历史文书明示精度登记；殖民当局指控、法定奖惩和实际被执行的事实分开。']
    for e in related:
        lines.extend(['',f'### {e["date_text"]}｜{e["title"]}（`{e["id"]}`）','',e['historical_description_zh'],'',f'**人物/机关**：{e["actor_entities_text"]}。**历史地名**：{e["historical_place_name"]}。**GIS**：无证实精确坐标，`latitude=null`，`longitude=null`。**档案源ID**：'+', '.join(e['source_ids'])+'。'])
    lines.extend(['','**交接要求**：此前研究报告保留原貌；新增法律事件必须分别核实法定行为和实际执行，所有本轮新增对象均为候审，不得把法律适用的整岛范围当“已证实殖民实控”。',''])
    path.write_text(old+'\n'.join(lines),encoding='utf8')

# Evidence for law/claim matrix
with (R/'PRIMARY_LAW_CLAUSE_MATRIX_V4.csv').open('w',encoding='utf-8-sig',newline='') as f:
    cols=['event_id','date_precision','date','topic_ids','action','actor','source_ids','primary_source_links','assertion_level','original_amount_exact','payment_confirmed','executions_confirmed','gps_status','gis_boundary_status','independent_second_source_per_claim','archive_to_verify']
    wr=csv.DictWriter(f,fieldnames=cols);wr.writeheader()
    for e in v4:
        srcs=[lookups[k] for k in e['source_ids']]
        wr.writerow({'event_id':e['id'],'date_precision':e['date_precision'],'date':e['date_text'],'topic_ids':';'.join(e['topic_ids']),'action':e['title'],'actor':e['actor_entities_text'],'source_ids':';'.join(e['source_ids']),'primary_source_links':';'.join(s['url'] for s in srcs),'assertion_level':e.get('evidence_status'),'original_amount_exact':e.get('legal_amount_quoted',''),'payment_confirmed':'UNKNOWN','executions_confirmed':'UNKNOWN','gps_status':'null','gis_boundary_status':'not_applicable_or_unverified','independent_second_source_per_claim':'pending','archive_to_verify':'parish court proceedings, treasury disbursement, estate deed survey, colonial council minute book'})

# separate claims for cartography, no geometries
boundary=[
 {'id':'E18A4-CLAIM-CUDJOE-1739','context':'1739 Cudjoe treaty Article III','source_url':'https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1739','claimed_legal_area_acres':1500,'measured_geo_area_sqkm':None,'geometry':None,'status':'textual_land_rights_legal_grant_unmeasured','graphics_rule':'No Polygon: only research lead for future dashed uncertain surveyed line; not a British occupation outline.'},
 {'id':'E18A4-CLAIM-STANWIX-1768','context':'1768 British treaty claim, contested by Cherokee and other nations; 1769 Board of Trade objection','source_url':'https://encyclopediavirginia.org/primary-documents/representation-of-the-board-of-trade-to-the-king-upon-sir-william-johnsons-treaty-with-the-indians-april-25-1769/','claimed_legal_area_acres':None,'measured_geo_area_sqkm':None,'geometry':None,'status':'contested_treaty_claim_not_actual_control','graphics_rule':'Only after contemporary treaty map georeferencing may annotate claimed line as dashed; do not fill.'},
 {'id':'E18A4-CLAIM-HARDLABOUR-1768','context':'1768 Cherokee negotiations; 14 vs 17 October date split','source_url':'https://encyclopediavirginia.org/primary-documents/the-treaty-of-hard-labor-october-14-1768/','claimed_legal_area_acres':None,'measured_geo_area_sqkm':None,'geometry':None,'status':'date_and_treaty_claim_pending_review','graphics_rule':'No polygons or hand-drawn straight lines. Keep historical month in old 1768 event.'},
 {'id':'E18A4-CLAIM-LOCHABER-1770','context':'1770 Oct 18 congress / Oct 22 Treaty / Dec 12 council reading','source_url':'https://encyclopediavirginia.org/primary-documents/the-treaty-of-lochaber-october-18-1770/','claimed_legal_area_acres':None,'measured_geo_area_sqkm':None,'geometry':None,'status':'chronology_multiple_actions_boundary_pending','graphics_rule':'No invented survey; reference as legal boundary claim only.'},
 {'id':'E18A4-CLAIM-MAROON-1788','context':'1788 colonial legislation over Maroon towns','source_url':'https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1788-0','claimed_legal_area_acres':None,'measured_geo_area_sqkm':None,'geometry':None,'status':'colonial_administrative_assertion_not_proof_of_full_maroon_town_control','graphics_rule':'No actual control Polygon derived from legislative grant.'},
 {'id':'E18A4-CLAIM-BEOTHUK-1773','context':'Cartwright 1773 interior geographic map research','source_url':'https://www.heritage.nf.ca/articles/exploration/newfoundland-interior.php','claimed_legal_area_acres':None,'measured_geo_area_sqkm':None,'geometry':None,'status':'historic_travel_map_not_territorial_conquest','graphics_rule':'Historic map to be inspected before adding study reference points; no travel line.'},
]
(R/'BOUNDARY_CLAIM_EVIDENCE_V4.json').write_text(json.dumps({'schema':'claim-only-gis-no-geometry-v1','status':'research_only','layer_authority':'not_approved_for_publication','no_polygons_generated':True,'no_linestrings_generated':True,'records':boundary},ensure_ascii=False,indent=2)+'\n',encoding='utf8')
# research names and sites no coordinates, with ref support
names=[('Trelawny Town','Jamaica','1739 Maroon Treaty Art III','1739','V4004'),('Cockpits','Jamaica','1739 Maroon treaty north-west reference','1739','V4004'),('Westmoreland Parish','Jamaica','1774 Attea law + 1763 Jack Pearson','1763;1774','V4018'),('Saint Mary Parish','Jamaica','1761 Jack manumission','1761','V4010'),('Jones’s Pen, Saint Catherine','Jamaica','1772 Sam / Will legal record','1772','V4016'),('Spanish Town / St Jago de la Vega','Jamaica','1730 gunpowder, 1770 slave huts','1730;1770','V4003'),('Kingston','Jamaica','1730 gunpowder, 1770 slave huts','1730;1770','V4015'),('Port Royal','Jamaica','1730 gunpowder, 1770 slave huts','1730;1770','V4015'),('Kingstown','Saint Vincent','1767 plantation laws','1767','V4022'),('Basseterre','Saint Christopher','1783 public auction clause','1783','V4024'),('Bahamas unspecified island','Bahamas','1784 freedom proof law legal jurisdiction only','1784','V4025'),('Hard Labour','South Carolina','1768 Cherokee treaty','1768','V4026'),('Lochaber','South Carolina','1770 Cherokee meeting','1770','V4027'),('Fort Stanwix','New York','1768 treaty and 1758 first log','1758;1768','V4031'),('Wall Street Slip','New York','1711 hired slave labor market','1711','V4029'),('York Factory','Manitoba','1714 Thanadelthur refuge','1714','R27'),('Churchill River','Manitoba','1717 summer HBC trade station','1717','R27'),('Exploits River','Newfoundland','Cartwright study and Beothuk lands','1768;1773','V4033'),('Whitehall','London','1769 Board of Trade opinion place','1769','V4028'),('Dominica interior','Dominica','1773 anti-runaway militia statutory jurisdiction','1773','V4023')]
with (R/'MAP_PLACE_RESEARCH_V4.csv').open('w',encoding='utf-8-sig',newline='') as f:
    cols=['historical_name','island_or_region','year_anchors','supported_claim','source_id','latitude','longitude','precision','point_creation_authorized','control_boundary_polygon_authorized']
    w=csv.DictWriter(f,fieldnames=cols);w.writeheader()
    for name,place,claim,years,sid in names:
        w.writerow(dict(historical_name=name,island_or_region=place,year_anchors=years,supported_claim=claim,source_id=sid,latitude='',longitude='',precision='historical_place_named_no_independent_geodetic_verification',point_creation_authorized='no',control_boundary_polygon_authorized='no'))
# Readable standalone source-to-scope rationale
note='''# 第四轮原始法令及政治边界史料质量说明\n\n**最重要的纠错规则**：数据库对许多无法核到月日的法令以 `YYYY-01-01` 作为检索占位。绝不可因此声称当年1月1日已通过该法。第四轮对应事件统一按来源明示的准确日期／年级保存。\n\n- 1739年马龙条约有明确的 `March 1st 1738-9` 原始日期，为现代历法纪年1739年3月1日；1500英亩为条约授地文字，并非实际测绘面。\n- 1718年追捕法文字极端重要：抓捕/杀害14岁以上所谓“反抗者”每人法定50牙买加流通镑；14岁以下的被俘儿童可以被追捕队作为财产留下。每个人的实际处境和后来结果需另查。\n- 1760年12月18日具名解放18人的法条与同日对所谓Obeah和出行的压制法属于**两个法条**，不能合并为单一事件。\n- 1769年牙买加法律修订，自1770年3月1日起生效；“from and after”是合法施行时点而非真实首宗抓捕案例。\n- 1770 Lochaber 10月18日开会、10月22日文书中的Treaty议程、12月12日英国行政议事会读报属于不同记录阶段。1768 Hard Labour十月14和十月17的来源日次冲突保留月级。\n- 1772年Sam遭烧死刑判决是法院文书被殖民议会追述，**未知是否执行及日期**；Will、Attea、Jack等获具名法定解放并不证实后续实际领款。\n- 1783圣基茨刑罚和1784巴哈马自由证明制度的金钱及拍卖为**法定手段**，并未凭条文推出真实出售/刑罚执行人数。\n- 纽约1799渐进解放法属于英国退出该地区之后的美国纽约州法规，若研究后果必须标明1799法律政治主体是美国，不能算作英国殖民政府新立法。\n\nGIS：本轮独立候审新增事件均留经纬度null；已有24条官方现代遗址参考点不改；不生成殖民疆界Polygon和船舶路线。原始图层`MAP_CANDIDATES.geojson`原样保留。\n'''
(R/'GEO_AND_CHRONOLOGY_AUDIT_V4.md').write_text(note,encoding='utf8')
print('V4 reports',len(chapters),'V4 candidate events',len(v4),'place research names',len(names),'master dossier appended',sum(bool(t.get('v4_new_event_ids')) for t in T['topics']))
