#!/usr/bin/env python3
"""Round 7 second-pass, local-only North American campaign, prison, atrocity and displacement survey.
Source-text access is public institution HTML (not manuscript leaves unless transcription explicitly visible).
"""
from pathlib import Path
import json,csv
R=Path('/mnt/data/18c_assistant_A')
EP=R/'EVENT_CANDIDATES.json';SP=R/'SOURCE_REGISTRY.json';TP=R/'TOPIC_INDEX.json'
ev=json.loads(EP.read_text());reg=json.loads(SP.read_text());idx=json.loads(TP.read_text());tmap={t['id']:t for t in idx['topics']}
usedids={e['id'] for e in ev['events']}; oldcount=len(ev['events']);oldsrc=len(reg['sources'])
urlmap={s.get('url','').rstrip('/'):s['id'] for s in reg['sources'] if s.get('url')}
sources={
 'MAINE_LETTER':('Maine Historical Society / Maine Memory Network','1775-10-19 Captain Mowat report to Admiral Graves, digital object and description','https://www.mainememory.net/record/159024','museum_digital_archival_object_metadata','Mowat letter report Oct 19 following Oct 18 destruction, Graves orders to punish 9 settlements; collection notes transcription linked; original artifact page indexed','digital_description_of_primary_report'),
 'MAINE_DIARY':('Maine Historical Society','Stephen Longfellow II original 1775 diary entry','https://www.mainememory.net/record/102228','museum_primary_document_transcription','Oct 18 1775 diary explicitly records town burned by King troops, individual property loss; document in collection','primary_document_visible_transcription'),
 'MAINE_BPL':('Boston Public Library','Revolution in Massachusetts: Burning of Falmouth','https://guides.bpl.org/c.php?g=800717&p=10424695','public_library_research_guide','Oct 18 1775 Henry Mowat Royal Navy burned Falmouth; Vice Adm Graves coastal punitive order','public_library_explanation'),
 'NPS_PRISON':('US National Park Service','The Prison Ship Martyrs','https://www.nps.gov/articles/000/prison-ship-martyrs.htm','federal_history_article','1776-83 New York Wallabout Bay British floating prisons, captivity disease neglect deaths, survivor Thomas Dring testimony; page erroneously states 240-gun Jersey—DO NOT USE that detail','institutional_history'),
 'NPS_CHARLESTON':('US National Park Service','Siege of Charleston 1780','https://www.nps.gov/articles/siege-of-charleston-1780.htm','federal_campaign_history','1780 April 1 first British siege parallel, April 8 Royal Navy breaks past Fort Moultrie, April 13 shelling, April 14 Moncks Corner, May 12 surrender, June 3 Clinton loyalty decree','institutional_history'),
 'NPS_YORKTOWN':('US National Park Service Yorktown','Events Leading to the Siege of Yorktown, 1781','https://www.nps.gov/york/learn/historyculture/eventstoyorktown.htm','federal_chronology','Savannah taken Dec 29 1778, Charleston surrendered May 12 1780; separate dates from alternative erroneous NPS WPA timeline','institutional_history'),
 'NPS_HENRY':('US National Park Service','Henry Clinton','https://www.nps.gov/people/henry-clinton.htm','federal_person_history','May 12 surrender, June 3 parole requirement and loyalty, local resistance','institutional_history'),
 'NPS_CHAR_EXIT':('US National Park Service','Liberty Won and Lost: British Evacuation of Charleston','https://www.nps.gov/articles/000/british-evacuation-of-charleston.htm','federal_thematic_history','Dec 14 1782 Charleston withdrawal: approx 4200 loyalists, >5000 Africans many forcibly relocated as enslaved by loyalists, some free, total ~14000 all aboard 130 British ships; overlap note','institutional_history'),
 'NPS_KINGS':('US National Park Service historical handbook','Kings Mountain: Conquest of Georgia South Carolina','https://npshistory.com/handbooks/historical/22/hh22c.htm','federal_historic_handbook','British Savannah Dec 29 1778 and Charleston May 12 1780, military and economic control of named ports, not entire colony','institutional_history'),
 'CT_STATE':('Connecticut State Library','Battle of Groton Heights and Burning of New London','https://libguides.ctstatelibrary.org/History-Day/1775-1815/Groton-Heights-New-London','state_library_historical_guide','Sept 6 1781 British troops land both sides of Thames; Benedict Arnold orders New London burning, Col William Ledyard and African American defender Jordan Freeman killed at Fort Griswold; sword death is contested','institutional_history'),
 'CT_FAIR':('Fairfield Museum and History Center','The Burning of Fairfield','https://www.fairfieldhistory.org/burning-of-fairfield/','museum_history_with_eyewitness_testimonies','1779 July 7 landing then July 7-8 town burning; contains references to sworn testimony of women witnesses; counts are local descriptions not audited building census','museum_history'),
 'CT_CTLEG':('Connecticut House of Representatives','Burning of Fairfield July 1779','https://housedems.ct.gov/node/26023','state_legislature_historical_commemoration','1779 July British Hessian raids; local civilian flight/looting/burning property','state_government_history'),
 'CT_TRYON':('George Washington Mount Vernon','Connecticut Raids','https://www.mountvernon.org/library/digitalhistory/digital-encyclopedia/article/connecticut-raids','historian_edited_academic_public_history','1779 July British Tryon punitive raids at New Haven, Fairfield, Norwalk, sources note political blowback and burned homes','academic_edited_public_history'),
 'CT_NOR':('Norwalk Current','The Burning of Norwalk historical archive retrospective','https://www.norwalkcurrent.com/from-the-archives-the-burning-of-norwalk/','local_history_journalism_using_1779_newspapers','July 11-12 1779 British landing and burning; local papers, journals and conflicting date interpretation; July 12 burn is most consistent','historical_journalism_archive'),
 'PA_KITT':('Armstrong County Historical Society','Kittanning or Attiqué Indian Town Marker','https://www.historicarmstrong.org/armstrong-county-history','local_history_institution','Lenape settlement attacked by PA militia led John Armstrong Sept 8 1756; entire territory cannot be treated occupied from one raid','local_history_society'),
 'PA_COUNTY':('Armstrong County, Pennsylvania','Comprehensive Plan 2005: County History','https://co.armstrong.pa.us/images/departments/planning/plansdocs/accp2005.pdf','local_government_report_search_extract','September 1756 Armstrong attacked and destroyed Kittanning settlement; PDF only search excerpt, no full page inspection','county_government_publication_snippet_only'),
 'VA_LIB':('Library of Virginia','Index of Virginia Printing: Session Laws October 1780','https://www.lva.virginia.gov/collections/virginia-print/imprints/1781.011','state_library_bibliographic_catalogue','1781 Jan 5 Arnold raid Richmond damaged Dixon Nicolson printing office and disrupted session laws publication; catalog record not original printing read','official_library_catalogue'),
 'VA_CHEST':('Chesterfield County Government, Virginia','American Revolution 250th Commemoration','https://www.chesterfield.gov/rev250','county_government_history','British Arnold captured Richmond Jan 5 1781, burned military stores tobacco, damaged ironworks at Westham, militia resistance','county_government_history'),
 'VA_LOC':('US Library of Congress','Thomas Jefferson Papers Timeline 1774-1783','https://www.loc.gov/collections/thomas-jefferson-papers/articles-and-essays/the-thomas-jefferson-papers-timeline-1743-to-1827/1774-to-1783/','national_library_historical_timeline','Arnold invasion Jan 6-10 1781, Jefferson government fled, military/printing disruption; individual Jan 5 from VA government','library_scholarly_timeline'),
 'CT_EPIS':('Episcopal Church in Connecticut Archives','St Pauls Norwalk historical research','https://ecct1archives.omeka.net/items/show/2557','church_archival_historical_essay','Norwalk 1779 British burn, loyalist relocation, official 11 July vs 12 July date discrepancy; keep date window if strict','archival_community_history')
}
newsrc={}
for key,(inst,title,url,typ,scope,depth) in sources.items():
 u=url.rstrip('/')
 if u in urlmap: newid=urlmap[u]
 else:
  newid=f'R7{len([x for x in reg["sources"] if x["id"].startswith("R7")])+1:03d}'
  reg['sources'].append({'id':newid,'author_or_institution':inst,'institution':inst,'title':title,'url':url,'type':typ,'access_level':depth,'actually_read_scope':scope,'original_manuscript_personally_inspected':False,'manuscript_inspected':False,'supported_event_candidate_ids':[],'supported_topic_ids':[],'access_verified_at':'2026-11-08','read_scope_note':'实际阅读在线机构正文、检索记录或可见转录；原纸本和外链PDF页未逐页核对，不得声称原卷审阅。','source_identity_note':'同机构的相关页面不自动当作独立学者双核。'});urlmap[u]=newid
 newsrc[key]=newid
new=[]
def add(slug,date,title,description,actors,loc,topics,source_keys,impact='major',quant=None,conflict=None):
 year=int(date[:4]);mn=int(date[5:7]) if len(date)>=7 else None;day=int(date[8:10]) if len(date)>=10 else None
 sids=list(dict.fromkeys(newsrc[k] for k in source_keys));urls=[next(x['url'] for x in reg['sources'] if x['id']==s) for s in sids]
 id=f'E18A7-{year}-{slug}'
 assert id not in usedids and id not in [z['id'] for z in new],id
 e={'id':id,'date_text':date,'year':year,'month':mn,'day':day,'date_precision':'day' if day else 'month' if mn else 'year','topic_ids':topics,'title':title,'actor_entities_text':actors,'historical_description_zh':description,'historical_place_name':loc,'longitude':None,'latitude':None,'modern_reference_site':None,'geo_precision':'no_verified_coordinate','coordinates_support_sources':[],'source_ids':sids,'source_urls':urls,'source_support_count':len(set(urls)),'claim_crosscheck_status':'institutional_two_or_more_links_claim_level_check_still_required' if len(set(urls))>=2 else 'single_source_second_check_pending','evidence_status':'research_only_public_institutional_sources','previous_17c_story_ids':sorted(set(q for t in topics for q in tmap[t].get('previous_story_ids',[]))),'historical_control_boundary_verified':False,'actual_military_control_polygon':False,'political_claim_not_actual_control':True,'area_sqkm':None,'historical_line_or_route_surveyed':False,'estimated_casualties_count':None,'estimated_trade_sum':None,'publication_status':'research_only','publication_review':'not_submitted','local_research_round':7,'impact_category':impact,'quantitative_qualification':quant,'source_conflict_note':conflict}
 new.append(e)
 for s in sids:
  r=next(z for z in reg['sources'] if z['id']==s)
  r.setdefault('supported_event_candidate_ids',[]).append(id)
  r['supported_topic_ids']=list(dict.fromkeys(r.get('supported_topic_ids',[])+topics))
add('PA-KITTAN-RAID','1756-09-08','宾州民兵攻袭并焚毁莱纳佩人的Kittanning/Attiqué聚落','宾夕法尼亚殖民民兵由John Armstrong率领袭击俄亥俄流域Lenape聚落，使村庄遭受火攻和破坏。莱纳佩此前在英国殖民者进入前已有政治及河流道路网络；单场军事胜利未使整个河谷成为英方实控地。','Pennsylvania provincial militia; John Armstrong; Lenape residents','Kittanning / Attiqué, Allegheny River, PA',['E18-C11','E18-C25'],['PA_KITT','PA_COUNTY'],'indigenous_town_destruction',quant='伤亡、被掳与营房数量待核双方原始材料；当前留null。')
add('MAINE-FALMOUTH-ORDER','1775-10','英国海军司令Graves发布惩罚新英格兰沿岸城镇的命令','Maine Historical Society馆藏说明Graves要求Mowat焚毁多个支持殖民地独立的海港城镇，最终舰长只执行对Falmouth的摧毁。命令拟攻击的其他城镇不能写作已毁。','Vice-Admiral Samuel Graves; Captain Henry Mowat','Boston naval command and coast of Massachusetts Bay',['E18-C17'],['MAINE_LETTER','MAINE_BPL'],'british_punitive_policy',conflict='Graves命令所列九城及各城市军事理由尚需读Mowat原始逐段报告。')
add('MAINE-FALMOUTH-BURN','1775-10-18','Mowat英国军舰炮击并纵火摧毁法尔茅斯市镇','1775年10月18日英国皇家海军炮击Falmouth Neck（今Portland），焚毁居民住宅、仓库和教堂。Stephen Longfellow II当日私人日记及次日英军舰长上呈报告均被Maine Historical Society数字馆藏收录；1776年幸存者书信显示民居损失和被迫逃离。','Captain Henry Mowat; Royal Navy; townspeople','Falmouth Neck / Portland, Maine',['E18-C17'],['MAINE_DIARY','MAINE_LETTER','MAINE_BPL'],'british_urban_destruction',quant='房屋精确毁损数量不同书籍口径差异，不使用未经原账核对的确切值。')
add('NY-PRISONSHIPS-START','1776','英国占领纽约后把战俘及其他拘押者关进Wallabout湾囚船','自1776年英国据点扩张起在纽约港区、布鲁克林Wallabout Bay设囚船拘押军人、水手、私掠船员及若干平民。NPS记载卫生、饮水、营养和疫病条件恶劣。该船群是拘押地点，不构成海面上的殖民领土面。','British Royal Navy and army custodians; captured patriots','Wallabout Bay, Brooklyn, New York',['E18-C17'],['NPS_PRISON'],'wartime_forced_confinement',quant='NPS所列约11,500死亡数属于纪念和后世合计估算，本轮不录为已精确核实死亡人数。')
add('NY-JERSEY-PRISON','1780','英国Jersey囚船成为纽约港拥挤拘押体系的代表性事件','HMS Jersey在独立战争期间充作囚船，Thomas Dring等幸存者记录强迫船上生活与疾病。确切转换年份尚未用船籍档逐航次校对，因此以1780年代研究观察点归档，并不主张1780年某天开始使用。','Royal Navy prison-ship administrators; Thomas Dring; prisoners','HMS Jersey, Wallabout Bay and New York Harbor',['E18-C17'],['NPS_PRISON'],'forced_confinement_research_anchor',conflict='此为1780年代阶段锚点，具体Jersey开始作囚船的年份在馆藏介绍中需另核，不能当确切1780年事件。')
add('GEORGIA-SAVANNAH-CAP','1778-12-29','英军攻取萨凡纳港并在佐治亚建立南方战场基地','Archibald Campbell率英国远征军在1778年12月29日攻取Savannah，随后企图通过州内保皇派和奴役种植园经济支撑英国对美国南方的统治。此港的占领不能当作Georgia所有原住民内陆土地由英国实占。','Archibald Campbell; British Southern expedition; Georgian inhabitants','Savannah, Georgia',['E18-C17'],['NPS_YORKTOWN','NPS_CHARLESTON','NPS_KINGS'],'strategic_port_occupation')
add('CT-NEW-HAVEN-RAID','1779-07-05','Tryon英军从海上袭击New Haven并掠夺港镇物资','英军在纽约总司令Clinton部署下对Connecticut沿海进行袭击，New Haven为首个目标；其登陆、焚烧军事储备和对部分民居掠夺须分开核实。','William Tryon; British and Loyalist soldiers','New Haven, Connecticut',['E18-C17'],['CT_TRYON','CT_NOR'],'british_coastal_punitive_raid')
add('CT-FAIRFIELD-LAND','1779-07-07','Tryon军登陆Fairfield并迫使居民逃离','Fairfield博物馆与Connecticut州议会史记7月7日约两千英军及德意志辅助军登陆，民兵阻击同时居民逃散。人数是部队规模估计，不能转作平民受害人数。','William Tryon; British-Hessian expedition; Fairfield militia','Fairfield Beach, Connecticut',['E18-C17'],['CT_FAIR','CT_CTLEG'],'colonial_coastal_invasion',quant='约2000英军/黑森士兵为部署估数，不是被害居民人数。')
add('CT-FAIRFIELD-BURN','1779-07-08','英军焚毁Fairfield大量住宅商铺和民用设施','在7月7日登陆后，英军至7月8日焚毁Fairfield市镇大片住宅、仓库、作坊及农场；多个公民证词后来被收集。实际烧毁栋数须从遗产调查账与财产损失清单逐项审计。','William Tryon; British military forces; affected Fairfield residents','Fairfield center, Connecticut',['E18-C17'],['CT_FAIR','CT_TRYON','CT_CTLEG'],'british_urban_destruction',conflict='地方文献对焚毁的起止具体日存在7日夜间至8日早晨的不同叙述，标题采用8日为持续行动后段。')
add('CT-NORWALK-LAND','1779-07-11','英军从长岛渡海袭击Norwalk港区并登陆','William Tryon部由Long Island跨海逼近Norwalk，在Calf Pasture等处登陆；当地民兵与独立派居民准备抵抗并撤出家属。','William Tryon; Royal Navy; Loyalist auxiliaries','Norwalk, Connecticut',['E18-C17'],['CT_NOR','CT_TRYON','CT_EPIS'],'british_coastal_invasion')
add('CT-NORWALK-BURN','1779-07-12','英军纵火焚毁Norwalk大量住宅、店铺、磨坊与教堂','Tryon军1779年7月11—12日的突袭导致Norwalk城镇大规模毁坏，建筑类型包括民房、商店、谷仓、磨坊、教堂；战争区军民财产损失和民兵伤亡不可混算。','William Tryon; British-Loyalist raiders; Norwalk residents','Norwalk town center, Connecticut',['E18-C17'],['CT_TRYON','CT_NOR','CT_EPIS'],'british_urban_destruction',conflict='不同机构把纵火概括为7月11日或12日，最终日期建议1779-07-11/12时间窗；此记录按更具体的地面行动阶段置12日。')
add('SC-CHARLESTON-LINES','1780-04-01','Clinton英军开始修筑查尔斯顿围城第一道平行壕','英国围城军在Charleston Neck修第一道围城平行壕，逐步逼近城市与居民并切断军队补给；军事攻防不等于全部周边郡县已归英国实控。','Sir Henry Clinton; British engineers; Benjamin Lincoln defenders','Charleston Neck, South Carolina',['E18-C17'],['NPS_CHARLESTON'],'siege_infrastructure')
add('SC-CHARLESTON-NAVY','1780-04-08','皇家海军舰队突破Fort Moultrie海防进入查尔斯顿港','Arbuthnot率英海军舰队4月8日驶过Fort Moultrie炮台，切断被围军港上联络；海上实际航迹仍无本轮校准GIS线。','Admiral Mariot Arbuthnot; British Royal Navy; American defenders','Charleston Harbor, South Carolina',['E18-C17'],['NPS_CHARLESTON'],'naval_siege')
add('SC-CHARLESTON-SHELL','1780-04-13','英国围城炮兵开始连续炮击查尔斯顿','国家公园局记录英军4月13日展开大规模炮击，炮火延续至5月投降，居民区财产及政治压力扩大；未核具名单栋损失账。','British Army artillery; Charleston civilians and garrison','Charleston, South Carolina',['E18-C17'],['NPS_CHARLESTON'],'urban_bombardment')
add('SC-MONCKS-CORNER','1780-04-14','Tarleton英军在Moncks Corner击散大陆军骑兵阻断撤路','英国军官Banastre Tarleton在Moncks Corner击溃Isaac Huger的独立军骑兵，帮助英国封锁查尔斯顿的陆上撤退。不同类型俘虏与战死人数需原军报核对。','Banastre Tarleton; Isaac Huger; British cavalry and American cavalry','Moncks Corner, South Carolina',['E18-C17'],['NPS_CHARLESTON'],'british_encirclement')
add('SC-CHARLESTON-CAP','1780-05-12','查尔斯顿美军投降，英国军政取得城市驻防和战俘','1780年5月12日Lincoln部投降，英国占据Charleston城、防御炮台与港口；较低阶军官及普通兵被关押在拥挤的监狱船上。NPS叙述英国俘获炮弹及武器，但各项数量不可重复合计。','Henry Clinton; Benjamin Lincoln; Mariot Arbuthnot','Charleston, South Carolina',['E18-C17'],['NPS_CHARLESTON','NPS_YORKTOWN','NPS_HENRY'],'urban_control_change_and_prisoners')
add('SC-CLINTON-LOYALTY','1780-06-03','Clinton英国总司令命令获假释居民改为效忠英国并服役','英国指挥官在此前假释/宽赦框架下要求当地男性宣誓效忠并在命令下服军役，引发部分人员转投独立派。此诏令是殖民权力要求，不能以命令自动推算所有居民服役。','Sir Henry Clinton; paroled former rebels; British occupation officials','Charleston, South Carolina',['E18-C17'],['NPS_CHARLESTON','NPS_HENRY'],'political_repression')
add('VA-RICHMOND-ARNOLD','1781-01-05','叛离独立派的英军指挥官Arnold攻入Richmond毁坏军事物资','Arnold率英国部队攻入Virginia首府Richmond，焚毁军工厂、仓储及大量烟草；州政府和Jefferson逃往内陆；印刷商Dixon与Nicolson业务被破坏，影响议会法案印行。','British Brigadier General Benedict Arnold; Governor Thomas Jefferson','Richmond and Westham, Virginia',['E18-C17'],['VA_CHEST','VA_LIB','VA_LOC'],'city_raid_supply_destruction',conflict='Library of Congress总叙述把行动列为1月6—10日，Chesterfield郡和更早文献称1月5日攻入；1月5按县政府记载，若需原日志逐时核应保留争议。')
add('CT-NEWLONDON-RAID','1781-09-06','Arnold英军攻击New London并纵火焚毁城市建筑','Benedict Arnold指挥的英军9月6日从New London侧登陆，攻入后下令烧毁港口军事补给和大量市镇建筑。另一支从Groton侧进攻Fort Griswold，行动须分开落点。','Benedict Arnold; Royal British and loyalist troops','New London, Connecticut',['E18-C17'],['CT_STATE'],'british_urban_destruction')
add('CT-GROTON-GRISWOLD','1781-09-06','英军攻陷Fort Griswold，守军William Ledyard与Jordan Freeman阵亡','英国军队在Groton侧攻取Fort Griswold，司令William Ledyard被杀，参战非洲裔自由战士Jordan Freeman也死亡。英军是否使用Ledyard佩剑处决，州立图书馆明确标为有争议的报道，不能写成定论。','British troops; Colonel William Ledyard; Jordan Freeman','Fort Griswold, Groton Heights, Connecticut',['E18-C17'],['CT_STATE'],'fort_assault_and_killing',conflict='Ledyard遭自己军刀杀害只是有争议的口述传统，不采用。')
add('SC-CHARLESTON-EXIT','1782-12-14','英国撤出查尔斯顿，结束当地两年多军事占领','英国后卫部从Gadsden’s Wharf登船撤出Charles Town，独立军随即进入；英方将军队、忠诚派及大量被奴役人口一并由军舰/运输船转移。不能将疏散人口数量当全部解放人口。','British Army rear guard; Royal Navy; American Army; Loyalists','Gadsden’s Wharf, Charleston, South Carolina',['E18-C17','E18-C18'],['NPS_CHAR_EXIT'],'end_of_urban_occupation',quant='NPS约14000登船是全部撤离人口估数，约4200忠诚派与5000多非洲裔不应简单相加作整体分母。')
add('SC-CHARLESTON-ENSLAVED-REMOVAL','1782-12-14','随英国军队撤离的忠诚派奴隶主强制携带数千被奴役非洲裔离开查尔斯顿','国家公园局指出5000多名非洲裔随撤离船队离开查尔斯顿，其中多数仍是忠诚派奴隶主所持被奴役人口、被迫迁往别处；也有此前逃往英国战线而获自由者。必须把被迫跨地贩运与获得自由者的自主迁徙区分。','Loyalist enslavers; British naval evacuation; enslaved Africans; self-emancipated Black loyalists','Charleston Harbor, South Carolina',['E18-C17','E18-C18'],['NPS_CHAR_EXIT'],'mass_forced_population_transfer',quant='>5000是全体非洲裔撤离估计（自由与被奴役合并），并非5000全为被奴役者；确切被奴役人数未知。')
assert all(e['id'] not in usedids for e in new)
ev['events'].extend(new)
for t in idx['topics']:
 ts=[e for e in ev['events'] if t['id'] in e.get('topic_ids',[])]
 t['candidate_event_count']=len(ts);t['v7_new_events_count']=sum(e.get('local_research_round')==7 for e in ts)
 t['source_ids']=list(dict.fromkeys(t.get('source_ids',[])+[s for e in new if t['id'] in e['topic_ids'] for s in e['source_ids']]))
 t['index_refresh']='2026-11-08-round7-extended'
for t in tmap:
 subset=[e for e in new if t in e['topic_ids']]
 if not subset:continue
 p=R/'TOPIC_DOSSIERS'/f'{t}.md'
 with p.open('a') as f:
  f.write('\n\n## 第七轮第二批｜独立战争军占、惩罚性军事行动与人口转移\n')
  for e in subset:
   f.write(f'\n### {e["date_text"]}｜{e["title"]}（{e["id"]}）\n\n{e["historical_description_zh"]}\n\n主体：{e["actor_entities_text"]}；地点：{e["historical_place_name"]}；证据：'+', '.join(f'`{s}`' for s in e['source_ids'])+'；制图：坐标空值、不自动增补实占边界。\n')
   if e.get('quantitative_qualification'):f.write('\n口径：'+e['quantitative_qualification']+'\n')
   if e.get('source_conflict_note'):f.write('\n未解决冲突：'+e['source_conflict_note']+'\n')
for p,o in [(EP,ev),(SP,reg),(TP,idx)]:p.write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n')
cp=R/'EVENT_CANDIDATES.csv'
with cp.open(newline='',encoding='utf-8-sig') as f:cols=csv.DictReader(f).fieldnames
cols=list(dict.fromkeys(cols+[k for e in ev['events'] for k in e]))
with cp.open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.DictWriter(f,fieldnames=cols,extrasaction='ignore');w.writeheader()
 for e in ev['events']:
  w.writerow({k:(json.dumps(v,ensure_ascii=False) if isinstance(v,(dict,list)) else '' if v is None else v) for k,v in e.items()})
print('ROUND7_SECOND_BATCH_SAVED',oldcount,'+',len(new),'=',len(ev['events']), 'sources',oldsrc,'+',len(reg['sources'])-oldsrc,'=',len(reg['sources']))
