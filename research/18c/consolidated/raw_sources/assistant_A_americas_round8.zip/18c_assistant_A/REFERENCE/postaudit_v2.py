#!/usr/bin/env python3
"""Independent local research QA / de-dup and source precision; never contacts GitHub."""
from pathlib import Path
import csv, json, re, hashlib, zipfile, collections
root=Path('/mnt/data/18c_assistant_A'); P=lambda name:root/name
read=lambda name:json.loads(P(name).read_text(encoding='utf-8'))
write=lambda name, obj:P(name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
base, reg, index, claims, geo=map(read,['EVENT_CANDIDATES.json','SOURCE_REGISTRY.json','TOPIC_INDEX.json','EVIDENCE_CLAIMS_V2.json','MAP_CANDIDATES.geojson'])
events=base['events']
source_by_id={x['id']:x for x in reg['sources']}
event_by_id={x['id']:x for x in events}
assert len(events)==215 and len(reg['sources'])==165
removed_ids={'E18A2-NY-1741-FIRE-CONTEXT','E18A2-BERMUDA-FREE-BLACK-LIMIT','E18A2-ZONG-INSURANCE'}
for iid in removed_ids:assert iid in event_by_id
base['events']=[e for e in events if e['id'] not in removed_ids]
# Retain all previous original event identifiers; enrich, not double-count them.
for eid,sources,extra in [
 ('E18A-1741-C24-01',['R10'],'另见纽约州法院历史学会审判研究；同一次1741年殖民司法恐慌不可另登记一个重叠事件。'),
 ('E18A-1730-A22-01',['R31'],'另见UNB数字殖民法条：数据库规范化年份不证明1730年1月1日通过。'),
 ('E18A-1783-A09-01',['R30'],'另见伦敦博物馆对宗号案的法院解释；法律赔偿争议不是杀人案刑事审判。')]:
 e=next(x for x in base['events'] if x['id']==eid)
 e['source_ids']=list(dict.fromkeys(e['source_ids']+sources))
 e['source_urls']=list(dict.fromkeys(e['source_urls']+[source_by_id[s]['url'] for s in sources]))
 e['source_support_count']=len(e['source_ids'])
 e['historical_description_zh']=e['historical_description_zh'].rstrip()+ ' '+extra
# Remove two redundant unused source IDs where exactly same URLs already R12 and R18.
reg['sources']=[s for s in reg['sources'] if s['id'] not in {'R37','R38'}]
source_by_id={x['id']:x for x in reg['sources']}
source_by_id['R29']['author_or_institution']='SlaveVoyages Consortium'
source_by_id['R29']['title']='Voyage 84106: Zong, 1781 (online transatlantic slave voyages record)'
source_by_id['R31']['actually_read_scope']=re.sub(r'1930\? no,?\s*','',source_by_id['R31']['actually_read_scope'])
# Directly checked institutionally supported sources, explicit partial-reading scope.
new_sources=[
 dict(id='R39',author_or_institution='Archives of Ontario / Government of Ontario',title='Grade 7 Black History: Digital Document Box (Slavery and Abolition in Upper Canada, page 5)',url='https://www.archives.gov.on.ca/ao-content/media/uploads/2026/02/Grade-7-Document-Box.pdf',type='provincial_archives_educational_source_with_archival_document_reproductions',actually_read_scope='PDF可检索文字第5页记1793-03-14 Chloe Cooley遭出售、1793-06-19 John White提案；附1793法印本图片。网页PDF截图因文件体积20MB+接口报错；未称亲读原始手稿',manuscript_inspected=False,primary_source_type=False),
 dict(id='R40',author_or_institution='Dictionary of Canadian Biography (University of Toronto / Université Laval)',title='COOLEY, CHLOE – Dictionary of Canadian Biography',url='https://www.biographi.ca/en/bio/cooley_chloe_4E.html',type='scholarly_biography_primary_source_based',actually_read_scope='1793 Cooley被绑过河、1793-06-19 John White提案、1793-07-09获王室同意、立法妥协、1798恢复奴役法案未通过；网页正文部分',manuscript_inspected=False,primary_source_type=False),
 dict(id='R41',author_or_institution='Insurance Museum / John Lane',title='The Zong Massacre (1781) – An Insurer’s Perspective',url='https://insurance.museum/history-article-the-zong-massacre-1781-an-insurers-perspective',type='museum_history_2025_professional_insurance_interpretation',actually_read_scope='2025保险博物馆文章明列Zong 1781-12-22抵达牙买加、理赔争议；其杀人/船员人数口径不等同SlaveVoyages，由单一文献核读',manuscript_inspected=False,primary_source_type=False),
 dict(id='R42',author_or_institution='University of New Brunswick – British North American Legislative Database',title='An Act to prevent the further introduction of Slaves, and to limit the Term of contracts for Servitude within this Province (33 Geo III c7, 1793)',url='https://bnald.lib.unb.ca/legislation/act-prevent-further-introduction-slaves-and-limit-term-contracts-servitude-within',type='historical_legislation_metadata_with_transcribed_act_index',actually_read_scope='UNB学术法规数据库确认上加拿大1793年33 George III第7章法律身份、名称、条数及原版图像索引；原件没全本逐字校勘',manuscript_inspected=False,primary_source_type=False),
]
for src in new_sources:
 src.update(read_scope_note='本地本轮实际读取网页可见文字、法律索引或PDF文字提取；纸质档案、当年原文法案影印图像未亲自逐页校核。',supported_event_candidate_ids=[],supported_topic_ids=[],access_verified_at='2026-11-08',separate_source_identity_note='机构整理、档案文字编本及同源PDF不是相互独立的历史见证。')
reg['sources']+=new_sources
source_by_id={x['id']:x for x in reg['sources']}
for eid,news in [
 ('E18A2-CHLOE-MARCH14',['R39','R40']),
 ('E18A2-CHLOE-BILL',['R39','R40']),
 ('E18A2-CHLOE-ACT',['R40','R42']),
 ('E18A2-ZONG-ARRIVAL',['R41'])]:
 e=next(x for x in base['events'] if x['id']==eid)
 e['source_ids']=list(dict.fromkeys(e['source_ids']+news))
 e['source_urls']=list(dict.fromkeys(e['source_urls']+[source_by_id[s]['url'] for s in news]))
 e['source_support_count']=len(e['source_ids'])
 e['claim_crosscheck_status']='distinct_institutional_sources_on_event_no_original_manuscript_read'
# South Carolina topics don't belong to Virginia legislation topic E18-C22.
sc_ids={'E18A2-STONO-REVOLT','E18A2-SC-CODE-1740','E18A2-SC-FLIGHT-AID-1754'}
for e in base['events']:
 if e['id'] in sc_ids:
  e['topic_ids']=[x for x in e['topic_ids'] if x!='E18-C22']
  e['topic_window_alignment'].pop('E18-C22',None)
# New historical background topic recommendations, not changes to PR289 IDs.
proposed={
 'E18-C28':('1711—1713塔斯卡罗拉战争、强掳与殖民土地侵入','E18A2-TUS-'),
 'E18-C29':('1739 Stono奴役者起义、1740南卡奴役法与后续刑事镇压','E18A2-STONO-|E18A2-SC-'),
 'E18-C30':('1759—1761切罗基战争、使节人质、毁村与英方殖民土地战争','E18A2-CHER-'),
 'E18-C31':('1793 Chloe Cooley贩卖抵抗与上加拿大渐进废奴法','E18A2-CHLOE-'),
 'E18-C32':('1763匹兹堡堡天花物品与英军司令信札','E18A2-FORTPITT-')}
for e in base['events']:
 extras=[p for p,(title,rx) in proposed.items() if re.match('(?:'+rx+')',e['id'])]
 if extras:
  e['proposed_additional_topic_ids']=extras
  e['topic_window_context_notice']='本条为原49母题未单列的重要事件系列；见PROPOSED_ADDITIONAL_TOPICS_V2.json。既有topic_ids仅供上下文检索，发生年份超出母题原研究窗时不得误认窗内已审核事件。'
  e['topic_window_alignment']={k:('in_core_research_window' if  (lambda a,b:a<=e['year']<=b)(next(t['research_window']['start_year'] for t in index['topics'] if t['id']==k),next(t['research_window']['end_year'] for t in index['topics'] if t['id']==k)) else 'outside_core_context_only') for k in e['topic_ids']}
# One additionally documented original 1798 policy counter-move from DCB academic biography.
added1798={
 'id':'E18A2-UC-RENEW-SLAVERY-1798','date_text':'1798','year':1798,'month':None,'day':None,'date_precision':'year',
 'topic_ids':['E18-C18'],'title':'上加拿大议会中恢复扩张奴役的1798年提案遭阻',
 'actor_entities_text':'Christopher Robinson（议员）、Richard Cartwright、Robert Hamilton、上加拿大立法议会',
 'historical_description_zh':'加拿大人物传记辞典记录Christopher Robinson于1798年推动拟扩大殖民地奴役制度的议案，Richard Cartwright和Robert Hamilton在立法委员会抵制，使法案未获通过。研究必须将「议案提出」与「法律已实施」分开。这是1793渐进限制后的反动企图，不把未通过议案写成已生效强迫劳动法。',
 'historical_place_name':'Upper Canada Legislative Council (Newark / York, exact proceedings location unverified)',
 'longitude':None,'latitude':None,'modern_reference_site':None,'geo_precision':'named_historical_location_reference_without_independently_verified_WGS84',
 'coordinates_support_sources':[],'source_ids':['R40'],'source_urls':[source_by_id['R40']['url']],
 'source_support_count':1,'claim_crosscheck_status':'single_scholarly_biography_second_source_needed',
 'evidence_status':'academic_secondary_candidate_needs_legislative_journals',
 'previous_17c_story_ids':[],'pr289_preexisting_acadia_candidate_ids':[],
 'historical_control_boundary_verified':False,'political_claim_not_actual_control':True,'area_sqkm':None,'historical_line_or_route_surveyed':False,
 'estimated_casualties_count':None,'estimated_trade_sum':None,'publication_status':'research_only','publication_review':'not_submitted',
 'topic_window_alignment':{'E18-C18':'outside_core_context_only'},'topic_window_context_notice':'1798事件已超过E18-C18规定的1783—1792范围，仅作北美黑人奴役法律后果的关联材料；拟增专题E18-C31。',
 'proposed_additional_topic_ids':['E18-C31'],'evidence_kind':'scholarly_biographical_legislation_review', 'added_in_local_extension':'2026-11-08-v2'}
base['events'].append(added1798)
assert len({e['id'] for e in base['events']})==len(base['events'])
# Zong source date 1781-12-22 stems from insurance museum narrative, not SlaveVoyages voyage key.
e=next(x for x in base['events'] if x['id']=='E18A2-ZONG-ARRIVAL')
e['historical_description_zh']+=' 其中抵港日期引自Insurance Museum的2025整理文（R41）；SlaveVoyages（R29）仅作为航次人数口径资料。'
# Do not wrongly claim 'July 3' as a verified 1793 statutory cutoff.
gaps=P('GAPS_AND_CONFLICTS.md').read_text(encoding='utf-8')
gaps=gaps.replace('1793年7月3日是法定新生子女分界日期，7月9日是安大略档案所记通过日期，两者不同。','1793年6月19日为议案提交日，7月9日为获王室同意日期；儿童适用年龄与出生时点须以1793法令原文逐款核，不得误造7月3日的法律分界。')
gaps=gaps.split('\n\n### 第二轮复核（原始法律与独立信息）',1)[0]
gaps+='''\n\n### 第二轮复核（原始法律与独立信息）\n\n- 史料来源 `R39` 是安大略省档案馆的**教育PDF（含历史原文图像）**，已读取可检索文本，但在线截图接口因PDF文件过大失败；通过大学编撰《Dictionary of Canadian Biography》`R40`、UNB立法数据库 `R42` 及加拿大公园局 `R20/R21` 交叉审定1793年3月14日强迫出售、6月19日法案提出、7月9日皇家同意三种时间节点。\n- 1798年上加拿大曾有恢复扩张奴役的议员提案，但据学术人物传记该案未获通过；原议会两院期刊未在本批逐页检查，候审状态保留。\n- 新确立五个原PR289母题没单独分类但值得新增的专题：C28 Tuscarora；C29 Stono与南卡法律；C30 Cherokee；C31 Upper Canada奴役；C32 Fort Pitt。详见 `PROPOSED_ADDITIONAL_TOPICS_V2.json`，不自动增补已规划49个母题。\n- 结构去重：1741年纽约火灾、1730年百慕大奴役法、1783年Zong理赔诉讼原有事件已经存在；第二轮新增同事事件整合到旧事件来源而非重复计数。\n'''
P('GAPS_AND_CONFLICTS.md').write_text(gaps,encoding='utf-8')
# Proposed topic register supplies coherent separate links without modifying existing 49 topics.
proposed_records=[]
for pid,(title,rx) in proposed.items():
 rs=sorted((e for e in base['events'] if pid in e.get('proposed_additional_topic_ids',[])), key=lambda x:(x['date_text'],x['id']))
 proposed_records.append({'id':pid,'editorial_state':'proposed_only_not_in_PR_289','title':title,'source_checked_event_count':len(rs),'events':[e['id'] for e in rs], 'dated_start_year':min([e['year'] for e in rs],default=None),'dated_end_year':max([e['year'] for e in rs],default=None),'source_ids':sorted(set(s for e in rs for s in e['source_ids'])),'boundary_and_GIS_notice':'Not an existing 18c master topic; no annual political geometry inferred.'})
write('PROPOSED_ADDITIONAL_TOPICS_V2.json',dict(schema='proposed-18c-topic-extensions-research-only',notes=['These identifiers are proposed additions, not present in PR 289 and not published.','All events already appear in EVENT_CANDIDATES; do not double-count.'],topics=proposed_records))
# Revised source usage derived from all persisted event rows.
for source in reg['sources']:
 evs=[e for e in base['events'] if source['id'] in e['source_ids']]
 source['supported_event_candidate_ids']=sorted({e['id'] for e in evs})
 source['supported_topic_ids']=sorted({t for e in evs for t in e['topic_ids']})
# Rebuild just the second-round dossier appendix; keep every first-round chapter unchanged.
bytopic=collections.defaultdict(list)
for event in base['events']:
 if event.get('added_in_local_extension')=='2026-11-08-v2':
  for tid in event['topic_ids']:bytopic[tid].append(event)
assert len(bytopic)>=15, len(bytopic)
for tid in sorted({x['id'] for x in index['topics']}):
 rows=bytopic.get(tid,[])
 p=P('TOPIC_DOSSIERS')/(tid+'.md')
 doc=p.read_text(encoding='utf-8')
 head=doc.split('\n\n## 十一、2026-11-08第二轮深度核证与新增原始档案节点',1)[0]
 if not rows:
  if head!=doc:p.write_text(head.rstrip()+'\n',encoding='utf-8')
  continue
 sections=['','## 十一、2026-11-08第二轮深度核证与新增原始档案节点','',
           '下述条目为原有候审事件之外的新行动证据；已去重，**新增ID仅用于本地研究**。相邻母题的时间窗之外的关联事项见拟增专题，不作为母题本身审核通过。地图历史地点的WGS84未独立核定者一律空坐标。','']
 for e in sorted(rows,key=lambda z:(z['date_text'],z['id'])):
  sections += [f"### {e['date_text']}｜{e['title']} (`{e['id']}`)",'',
      f"**行动主体**：{e['actor_entities_text']}。**历史地点**：{e['historical_place_name']}（尚无独立验证的事件GPS）。",'',
      e['historical_description_zh'],'',
      '**证据**：'+'；'.join(f"[`{s}`]({source_by_id[s]['url']})" for s in e['source_ids'])+f"。**核证标记**：`{e['evidence_status']}`；不据此凭空绘画领土。",'']
  if e.get('proposed_additional_topic_ids'):sections += ['**专题归档提醒**：关联拟增 '+', '.join(e['proposed_additional_topic_ids'])+'；原PR289母题研究窗须单独审核。','']
 rel=[c for c in claims['claims'] if tid in c['topic_ids']]
 if rel:
  sections+=['### 此轮数量与争议来源口径','']
  for c in rel:
   sections.append(f"- `{c['id']}`：{c['claim_zh']} **口径**：{c.get('caveat') or '待原卷核验'}；来源：{', '.join(c['source_ids'])}。")
  sections.append('')
 p.write_text(head+'\n'.join(sections).rstrip()+'\n',encoding='utf-8')
# Rebuild map place research table from actual second-round event rows; null GIS fields.
places={}
for e in base['events']:
 if e.get('added_in_local_extension')!='2026-11-08-v2':continue
 name=e['historical_place_name']
 if name not in places:places[name]=dict(historical_place_name=name,event_ids=[],topic_ids=[],latitude=None,longitude=None,coordinate_status='NOT_VERIFIED_18C_EVENT_WGS84',historical_claim_area_verified=False,draw_as_verified_control_polygon=False,source_ids=[])
 item=places[name];item['event_ids'].append(e['id']);item['topic_ids']=sorted(set(item['topic_ids']+e['topic_ids']));item['source_ids']=sorted(set(item['source_ids']+e['source_ids']))
with P('MAP_PLACE_RESEARCH_V2.csv').open('w',encoding='utf-8-sig',newline='') as f:
 fields=['historical_place_name','latitude','longitude','coordinate_status','historical_claim_area_verified','draw_as_verified_control_polygon','event_ids','topic_ids','source_ids']
 w=csv.DictWriter(f,fields);w.writeheader()
 for row in places.values():w.writerow({k:';'.join(row[k]) if isinstance(row[k],list) else row[k] for k in fields})
# Dossier topic index original 49, no silent ID additions.
for t in index['topics']:
 tid=t['id'];linked=[e for e in base['events'] if tid in e['topic_ids']]
 t['candidate_event_count']=len(linked)
 t['source_ids']=list(dict.fromkeys(t['source_ids']+[s for e in linked for s in e['source_ids']]))
 t['v2_new_events_count']=len(bytopic.get(tid,[]))
index['last_local_research_extension']='2026-11-08-v2-postaudit'
base['last_local_research_extension']='2026-11-08-v2-postaudit'
reg['last_local_research_extension']='2026-11-08-v2-postaudit'
for name,obj in [('EVENT_CANDIDATES.json',base),('SOURCE_REGISTRY.json',reg),('TOPIC_INDEX.json',index)]:write(name,obj)
# Detailed raw CSV, preserving both date precision and duplicate topic linkage.
rows=base['events'];columns=list(dict.fromkeys(key for row in rows for key in row))
with P('EVENT_CANDIDATES.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=columns);w.writeheader()
 for r in rows:w.writerow({k:json.dumps(r[k],ensure_ascii=False) if isinstance(r.get(k),(list,dict)) else r.get(k) for k in columns})
# Update first-round counts as a marked snapshot, second-round actual post-audit counts prominently.
second=[e for e in base['events'] if e.get('added_in_local_extension')=='2026-11-08-v2']
summary=dict(original_events=158,second_round_new_unique_events=len(second),all_events=len(rows),original_source_entries=127,second_round_new_source_entries=len(reg['sources'])-127,all_source_register_entries=len(reg['sources']),unique_document_urls=len({s['url'].rstrip('/') for s in reg['sources']}),dossiers_total=len(list(P('TOPIC_DOSSIERS').glob('E18-*.md'))),dossiers_extended=len(bytopic),date_precision_day_new=sum(e['date_precision']=='day' for e in second),date_precision_month_new=sum(e['date_precision']=='month' for e in second),date_precision_year_new=sum(e['date_precision']=='year' for e in second),claim_context_records=len(claims['claims']),existing_gis_points_retained=len(geo['features']),new_gis_points=0,new_named_locations_without_approved_gps=len(places),proposed_additional_topics=len(proposed),no_GitHub_writes=True)
progress=P('PROGRESS.md').read_text(encoding='utf-8')
progress=progress.split('\n\n## 第二轮深挖（2026-11-08',1)[0]
progress+='\n\n## 第二轮深入研究（2026-11-08｜逐条复核、去重、保存）\n\n'
progress+=f"- 累计 **{summary['all_events']}件独立事件候选**，比初版158件**净增加{len(second)}件**；新事件日级{summary['date_precision_day_new']}件、月级{summary['date_precision_month_new']}件、年级{summary['date_precision_year_new']}件。\n"
progress+=f"- 来源注册合计 **{summary['all_source_register_entries']}条ID登记**，其中本轮净增{summary['second_round_new_source_entries']}条；去重后网页URL {summary['unique_document_urls']}个，来源ID不等于独立原始见证。\n"
progress+=f"- 49份A/C专题档案均保留，**{len(bytopic)}篇进一步加深**。新增14条主张数量和冲突口径、{len(places)}个有证历史地名未核事件WGS84、5项拟增专题独立索引。\n"
progress+='- 既存有据GeoJSON保留22个官方现代遗址参考点；新增有地理依据且已查明历史事件精确GPS的点0、虚构路线0、历史实控Polygon0。年份源自史料明确记载，法律通过、实施与未通过议案分开。\n'
progress+='- 深挖主档：Nova Scotia Archives 1755年Winslow原军官日记及1798年Holland海图；上加拿大1793法律、1711—13 Tuscarora、1739 Stono、1759—61 Cherokee、1763 Fort Pitt、1784 Shelburne、1781 Zong、HBC Thanadelthur和平外交等。\n'
progress+='- 已剔除3个与第一轮重复的事件条目，将新增出处并入原事件；安大略省档案馆PDF可检索文字已读、网页PDF屏幕截图工具因文件超限失败；原纸本与逐航次原始账本尚待深入。\n'
progress+='- **全部文件已实际写入本地**；没有修改、上传、创建GitHub分支或PR。正式地图历史事件尚待逐主张审校及空间审计。\n'
P('PROGRESS.md').write_text(progress,encoding='utf-8')
# Add evidence QA and historical list with explicit exclusions
qa='''# 2026-11-08 第二轮内容审校与地图研究限制\n\n- 49个现有A/C主专题ID未发生更改；新增C28-C32只是建议编号。\n- 去重处理：1741年纽约火灾、1730年百慕大法、1783年宗号民事诉讼已于第一版存在，第二轮相同事件的新增线索用于加强来源字段，防重复统计。\n- 1793年Chloe Cooley案：安大略省档案馆PDF数字教育资料提供3月14日／6月19日日期，加拿大大学学术人物传记提供6月19日／7月9日；Parks Canada独立说明法并未当即释放已有被奴役者。PDF在线截图服务因20MB以上体积失败，但页面文字可检索；未宣称完成实物卷宗核验。\n- 1781 Zong：12月22日抵岸来自保险博物馆2025年说明，SlaveVoyages则独立提供航次登记估计；440-208差值不可当作直接谋杀人数。\n- 1763 Fort Pitt：独立标注6月24日现场毯子交易与7月7、13、16日的后续军事信件，避免将较晚的书信反推为此前交易的必然命令；死亡后果无证填null。\n- 1798上加拿大扩张奴役草案只是未通过提案，不能作已施行法律；州立地图的历史港湾图未完成EPSG:4326配准，不得以现代城区代替历史疆界。\n- 对2026年仍在PR289待审的18世纪Atlas没有推送、部署或覆盖行为。\n'''
P('REFERENCE/QA_POSTAUDIT_V2.md').write_text(qa,encoding='utf-8')
# Validate all links and correctness, files, GIS invariants, JSON-CSV parity.
ids={e['id'] for e in base['events']};sourceset={s['id'] for s in reg['sources']};topicset={t['id'] for t in index['topics']}
assert len(ids)==len(rows)==summary['all_events'] and len(sourceset)==len(reg['sources'])
assert len(topicset)==49 and len(list(P('TOPIC_DOSSIERS').glob('E18-*.md')))==49
assert all(set(e['source_ids'])<=sourceset for e in rows)
assert all(set(e['topic_ids'])<=topicset for e in rows)
assert all(e.get('latitude') is None and e.get('longitude') is None for e in second)
assert all(x['geometry']['type']=='Point' for x in geo['features'])
assert not any(e['id'] in removed_ids for e in rows)
assert len(second)==len(events)-158-len(removed_ids)+1
assert all(not (e['id'].startswith('E18A2-SC-') and 'E18-C22' in e['topic_ids']) for e in second)
with P('EVENT_CANDIDATES.csv').open(encoding='utf-8-sig',newline='') as f:assert sum(1 for _ in csv.DictReader(f))==len(rows)
write('REFERENCE/VALIDATION_V2.json',{'result':'PASS','summary':summary,'event_id_unique':True,'all_event_sources_resolve':True,'all_topics_exist':True,'csv_json_counts_match':True,'all_new_coords_null':True,'only_official_first_round_gis_points':True,'cross_topic_duplicates_deduplicated':True,'publication_status':'research_only','github_writes':0})
zip_path=root.parent/'18c_assistant_A_americas.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(root.rglob('*')):
  if p.is_file() and '__pycache__' not in p.parts:z.write(p,p.relative_to(root.parent))
with zipfile.ZipFile(zip_path) as z:
 assert z.testzip() is None
 total=len(z.namelist())
print(json.dumps({'summary':summary,'zip_path':str(zip_path),'zip_members':total,'zip_size':zip_path.stat().st_size,'zip_sha256':hashlib.sha256(zip_path.read_bytes()).hexdigest()},ensure_ascii=False,indent=2))
