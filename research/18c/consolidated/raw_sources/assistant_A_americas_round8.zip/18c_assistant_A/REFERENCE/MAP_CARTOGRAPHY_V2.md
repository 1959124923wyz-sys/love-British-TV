# 地图第二轮史料判断 | 不捏造GPS或历史版图

## 一、具有真实历史测绘来源的图

- 1798-07-12 Captain Holland《Plan of Port Roseway Harbour》，新斯科舍省档案馆地图239号：嵌图标示 Birchtown 和 Black Town。原件索引：https://archives.novascotia.ca/maps/archives/?ID=225 。这是1798年的具名历史区域地图，适合未来进行地理配准和城镇落点核验。**目前没有经配准的WGS84线/多边形，也不能把1798聚落边界复制到1784年骚乱年份。**
- 1755年 Winslow 军官日记证实 Gaspereau、Canard、Habitant、Pero、Chépody、Petitcodiac 具名受袭村庄与日期。逐建筑事件的确切位置和历史村界没有逐宗地契/测绘对应，`MAP_PLACE_RESEARCH_V2.csv`仅留具名地点。
- Nooherooka 1713战斗，北卡州图书馆确认近今Snow Hill、Greene County，但现存防御工事与纪念/考古保护区不是英军统治区。需要州考古部门对原址位置坐标的正式资料后才能落具名点。
- Saint Vincent Garifuna、1796 Maroon、北美原住民作战路线等，本次未获得有据历史坐标，不绘造线段或武装影响Polygon。

## 二、坐标与图形判断

现有 `MAP_CANDIDATES.geojson` 保留第一轮22个官方现代遗址参考点。新增候选默认 `latitude=null`、`longitude=null`、`historical_control_boundary_verified=false`。后续只要证实*局部具名范围*但边线不确定，可考虑淡色虚线示意；当前材料中没有证明可画准确的领土多边形。公司商业站、王室法律纸面声索、编纂地图地点和军队短期占领分层。

## 三、跨世纪及独立年份

1798图证仅对应1798，1800年Jamaican Maroon从Halifax前往Sierra Leone是十九世纪事件，**不纳入1700—1799年代滑块**；1699年渔业法只有生效条款进入1700年的起始事件。
