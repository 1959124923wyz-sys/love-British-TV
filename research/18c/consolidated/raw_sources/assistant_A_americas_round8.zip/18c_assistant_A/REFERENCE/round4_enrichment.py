#!/usr/bin/env python3
"""Locally enrich A/C research data with read primary law and treaty transcriptions.
Research-only: no invented GPS/claims polygons/actual payments; never writes to GitHub.
"""
import csv, datetime, hashlib, json, pathlib, collections, zipfile
R=pathlib.Path('/mnt/data/18c_assistant_A')
O=lambda p:json.loads((R/p).read_text(encoding='utf8'))
W=lambda p,o:(R/p).write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
E=O('EVENT_CANDIDATES.json'); S=O('SOURCE_REGISTRY.json'); T=O('TOPIC_INDEX.json')
existing_ids={e['id'] for e in E['events']}; su={s['id'] for s in S['sources']}; byurl={s['url'].rstrip('/'):s['id'] for s in S['sources']}
new=[]; new_source=[]
def src(key,url,institution,title,read_scope,kind='primary_law_transcription'):
    if url.rstrip('/') in byurl:return byurl[url.rstrip('/')]
    i=f'V4{len(new_source)+1:03d}'
    if i in su:raise ValueError(i)
    s={'id':i,'author_or_institution':institution,'title':title,'url':url,'type':kind,'actually_read_scope':read_scope,'manuscript_inspected':False,'read_scope_note':'已核对网上转录正文；属原始历史文件的现代转录／机构解说，未亲自查阅收藏机构纸质原卷。数据库以1月1日占位而没有日证据时，事件仅记年份。','supported_event_candidate_ids':[],'supported_topic_ids':[],'access_verified_at':'2026-11-08','primary_source_type':kind.startswith('primary_'),'separate_source_identity_note':'同一数据库内多页历史立法是不同历史文件，但单一条款不自动获得独立第二证；独立交叉证明仍需法院/档案原件。'}
    S['sources'].append(s);su.add(i);byurl[url.rstrip('/')]=i;new_source.append(i);return i
U='https://slaveryandfreedomlaws.lib.unb.ca/laws/'
L={}
for k,path,year,title,scope in [
 ('J1717','jamaica-1717',1717,'Jamaica 1717 slave trials and owner reimbursement statute','授权对被判死刑后奴隶主的价值补偿，单人法定估值上限40牙买加镑，非实际付款'),
 ('J1718','node/324',1718,'Jamaica 1718 armed runaway-hunting law','动员追捕逃亡者、设法定奖励，是否成立实际队伍另核'),
 ('J1730','jamaica-1730',1730,'Jamaica 1730 gunpowder retail restrictions','限特定港镇许可商销售火药及对外出售禁令，罚金与履约保证金为法定上限'),
 ('J1739','jamaica-1739',1739,'Jamaica 1739 treaty with Cudjoe and legislative ratification','1739-03-01（旧历文书标1738-9）Trelawny签署、15条款、1500英亩法定赠地而非实测边界、追捕奖励'),
 ('J1744','jamaica-1744-0',1744,'Jamaica 1744 rebellion and Hector freedom statute','对所谓起义惩罚与Hector具名释放和财政承诺，若干人数和处决事实待原卷'),
 ('J1748','jamaica-1748',1748,'Jamaica 1748 testimony restrictions','证人身份证明、自由有色人士证言适用条件'),
 ('J1749','jamaica-1749',1749,'Jamaica 1749 anti-runaway statute','逃亡者和包庇者的法律惩罚'),
 ('J1751','jamaica-1751',1751,'Jamaica 1751 acts against killing enslaved persons','首犯刑罚与向其他主人支付60牙买加镑的法定民事补偿，非已收款'),
 ('J1760','jamaica-1760-0',1760,'Jamaica 1760 manumission of 18 named persons','1760-12-18具名Foster/Pembroke/George/Cuffey/Billy/Blackwall/Yankee/Philip/London/Moll/Quaco/Nero/Congo Molly/Beckford/Silver/Jemmy/Will；姓名Billy重复为两人；对每人法定5镑年金'),
 ('J1761J','jamaica-1761-0',1761,'Jamaica 1761 named manumission of Jack','1761-12-19 Jack获法定释放，5牙买加镑年金'),
 ('J1761R','jamaica-1761',1761,'Jamaica 1761 free status certificate amendment','自由证书更新期限改为七年'),
 ('J1763','jamaica-1763',1763,'Jamaica 1763 manumission of Jack Pearson','1763-12-01法律释放Jack Pearson，60牙买加镑向原奴隶主遗产的补偿'),
 ('J1764','jamaica-1764',1764,'Jamaica 1764 manumission of Cato','1764-11-09释放Cato；70牙买加镑为法定向原主补偿'),
 ('J1769','jamaica-1769',1769,'Jamaica 1769 law regarding Maroon runaway returns','1769通过，1770-03-01生效的追捕逃亡人口奖励修正；日期及兑现分开'),
 ('J1770','jamaica-1770',1770,'Jamaica 1770 slave huts registry','1770-12-19 Spanish Town、Port Royal、Kingston奴役人口居所登记与围墙管理'),
 ('J1772','jamaica-1772',1772,'Jamaica 1772 manumission of Will and Sam sentencing account','1772-03-31 Jones Pen奴役者Sam被控杀害Andrew Ross；刑事判决写烧死不等于已执行；1772-12-23 Will获释放与法定年金'),
 ('J1774I','jamaica-1774-2',1774,'Jamaica 1774 slave import customs act','1774-02-12议会通过、1774-02-13副总督Basil Keith批准；新增进口税但不能套用旧税率'),
 ('J1774A','sites/default/files/pdf/jamaica-1774-1.pdf',1774,'Jamaica 1774 manumission of Attea','1774-11-19原法有关Westmoreland当年8月所谓阴谋与Attea释放及议会赔偿额'),
 ('J1774F','jamaica-1774',1774,'Jamaica 1774 statute on provision for freed persons','1774-12-24奴役者释放人口须提供法定终身5镑保障，并非每个解放者真实获领'),
 ('J1788M','jamaica-1788-0',1788,'Jamaica 1788 Maroon towns discipline statute','1788-01-10法律设置白人监管、马龙社群法庭和追捕逃亡人口任务；限制公司/政府权的自治空间'),
 ('B1767','barbados-1767',1767,'Barbados 1766 passage, 1767 confirmation of amendment','1766-04-15殖民议会通过，1767-07-24王室核准；无票据者拘捕处分程序'),
 ('V1767','st-vincent-1767',1767,'Saint Vincent 1767 act making enslaved persons inheritable estate','1767-07-11通过、07-13公布，1768-01-27登记：奴役人口对继承属real estate，债务清偿可为chattels'),
 ('D1773','dominica-1773',1773,'Dominica 1773 coerced free Black militia pursuit and freedom registration','自由有色男性依法征调为追逃队伍，涉及自由证登记、拒绝征召罚款和出售风险；不能视作已执行人数'),
 ('K1783','st-christopher-1783',1783,'Saint Christopher 1783 legal penalties for mutilation and forced resale','1783-12-18法定500当地镑罚款，受害奴役者可被羁押及拍卖；法定罚款不等于已追缴'),
 ('BA1784','bahamas-1784',1784,'Bahamas 1784 racialized freedom-proof law','自由证不足者可羁押并拍卖；即便认定自由者仍需离境或提供90当地镑担保'),
]:
 url=(U+path) if not path.startswith('sites/') else 'https://slaveryandfreedomlaws.lib.unb.ca/'+path
 L[k]=src(k,url,'新不伦瑞克大学｜Laws of Enslavement and Freedom in the Anglo-Atlantic World',title,scope)
L['H1768']=src('H1768','https://encyclopediavirginia.org/primary-documents/the-treaty-of-hard-labor-october-14-1768/','Encyclopedia Virginia（历史原始文书校订）','1768 Treaty of Hard Labour with Cherokee','1768-10-14文书与英国官员John Stuart、切罗基政治代表；地理系文本描述非经验证GIS','primary_treaty_transcription')
L['L1770']=src('L1770','https://encyclopediavirginia.org/primary-documents/the-treaty-of-lochaber-october-18-1770/','Encyclopedia Virginia（弗吉尼亚历史学会文书校订）','1770 Treaty of Lochaber','1770-10-18代表集会；文内另有10-22 Treaty、12-12 council reading，不强制统一成签署一日','primary_treaty_transcription')
L['B1769']=src('B1769','https://encyclopediavirginia.org/primary-documents/representation-of-the-board-of-trade-to-the-king-upon-sir-william-johnsons-treaty-with-the-indians-april-25-1769/','Encyclopedia Virginia（英国贸易委员会原始奏呈转录）','Board of Trade report on Fort Stanwix 1769-04-25','英国贸易委员会承认各原住民族利益不同、指出与切罗基声索冲突；£10460 7s 3d属报告所列财物及金钱估值','primary_government_report_transcription')
L['NY1711']=src('NY1711','https://www.archives.nyc/slavery-records','纽约市市政档案馆','NYC slavery records and 1711 Wall Street slave hire market','1711-11-30城市管理机关将Wall Street Slip用于招募奴役劳力、1799纽约州渐进解放法律之美利坚独立后背景','official_city_archives')
L['NY1711b']=src('NY1711b','https://www.archives.nyc/blog/2023/1/20/from-marketfield-to-the-greenmarket-part-i','纽约市市政档案馆','NYC From Marketfield to Greenmarket','1711租用奴役劳动力市场的城市史研究；与档案馆同机构不可当独立第二文书','official_city_archives')
L['NPS1758']=src('NPS1758','https://www.nps.gov/articles/000/a-timeline-history-of-the-oneida-carry.htm','美国国家公园管理局','Oneida Carry Fort Stanwix timeline','1758-08-26英军堡垒首根木料立起；与Oneida人的协商与承诺拆堡的文书史叙述','national_park_history')
L['NF1769']=src('NF1769','https://www.heritage.nf.ca/articles/indigenous/beothuk-institution.php','纽芬兰纪念大学历史遗产项目','Institutional Efforts to End Beothuk Hostilities','1769 John Byron公告、1786 George Christopher Pulling政策建议；均属英方倡议而非证明冲突结束','university_history')
L['NF1773']=src('NF1773','https://www.heritage.nf.ca/articles/exploration/newfoundland-interior.php','纽芬兰纪念大学历史遗产项目','Newfoundland interior exploration and cartography','1768、1773 Cartwright北部内陆与Exploits地图出版，1780年代原住民抵抗背景；不把现代河谷当英国控制','university_history')
# directly reuse Canada Parks Thanadelthur R27
L['THAN']=byurl.get('https://parks.canada.ca/culture/designation/personnage-person/thanadelthur')
if not L['THAN']:L['THAN']=src('THAN','https://parks.canada.ca/culture/designation/personnage-person/thanadelthur','加拿大公园局','Thanadelthur National Historic Person','1714逃入York Factory、1715—16德内克里和平、1717夏丘吉尔河站','national_park_history')

def dateparts(date):
    v=date.split('-');return int(v[0]),(int(v[1]) if len(v)>1 else None),(int(v[2]) if len(v)>2 else None),['year','month','day'][len(v)-1]

def add(date, topic, title, actor, desc, place, keys, previous=None, extra=None):
    y,m,d,prec=dateparts(date)
    idf=f'E18A4-{len(new)+1:03d}-{y}'
    if idf in existing_ids:raise RuntimeError('duplicate id')
    ids=[L[k] for k in keys]
    lookup={x['id']:x for x in S['sources']}
    ev={'id':idf,'date_text':date,'year':y,'month':m,'day':d,'date_precision':prec,'topic_ids':[topic],'title':title,'actor_entities_text':actor,'historical_description_zh':desc,'historical_place_name':place,'longitude':None,'latitude':None,'modern_reference_site':None,'geo_precision':'no_verified_coordinate','coordinates_support_sources':[],'source_ids':ids,'source_urls':[lookup[k]['url'] for k in ids], 'source_support_count':len(ids),'claim_crosscheck_status':'primary_transcription_read_other_independent_source_pending' if len(set(ids))==1 else 'two_sources_but_independence_not_automatically_proven','evidence_status':'primary_document_clause_candidate_needs_case_archives','previous_17c_story_ids':previous or [],'pr289_preexisting_acadia_candidate_ids':[],'historical_control_boundary_verified':False,'political_claim_not_actual_control':True,'area_sqkm':None,'historical_line_or_route_surveyed':False,'estimated_casualties_count':None,'estimated_trade_sum':None,'publication_status':'research_only','publication_review':'not_submitted','local_research_round':4,'v4_source_type':'read_primary_law_or_treaty_transcription_or_institution_history','v4_amount_assertion_policy':'legal_cap_or_order_only_not_confirmed_payment','scope_note':'按发生年份记录局部行动；法律、报告、条约与实际执行分别归档；无经证图形。'}
    if extra:ev.update(extra)
    new.append(ev);return idf

# Jamaica law series: distinct legislative actions and individually identified people
add('1717','E18-A06','牙买加议会规定被处死奴役者的原主可向殖民财政索赔','牙买加议会、地方法官、奴隶主及被奴役者','1717年法条建立审判后原主申领补偿的程序，并限定对每名被判死刑奴役者的法定估值最高40牙买加流通镑；这是法律上限，并非当年实际死亡人数或已支付额。','Jamaica（法令适用全岛，具体受害村庄未知）',['J1717'],['E6-T08'],{'legal_amount_quoted':'每人法定估值上限40牙买加流通镑','observed_actual_payment':None})
add('1718','E18-A05','牙买加殖民议会资助武装追捕逃亡奴役者','牙买加殖民议会、民兵、逃亡奴役者','1718年法令安排搜捕逃亡奴役者的殖民追捕财政和奖励制度；只能确认法令设立，实际每次追捕的人数及死伤须查民兵账。','Jamaica',['J1718'],['E6-T08'])
add('1730','E18-A06','牙买加殖民议会严格限制出售火药和枪械材料','牙买加殖民议会、军需商人、逃亡及被奴役社群','1730年殖民立法将火药零售集中于Spanish Town、Port Royal、Kingston等持证商人；恐惧被奴役者武装行动是历史解释，不能推定每次交易实际阻断。','Spanish Town / Port Royal / Kingston, Jamaica',['J1730'],['E6-T08'])
add('1744','E18-A06','牙买加1744年针对所谓叛乱施刑与具名Hector解放法律','殖民议会、法官、遭指控者、Hector及Thomas Fuller','1744年法文把对叛乱惩罚和Hector具名解放纳入法案，并写入向有关主人的法定赔偿；殖民地官方所说阴谋不等于全部指控经独立审查成立。','Jamaica',['J1744'],['E6-T08'])
add('1748','E18-A06','牙买加议会限制自由有色者与原住民司法证言条件','牙买加殖民议会、殖民法院、自由黑人及原住民居民','1748年法令调整特定类型证言的适用资格及程序；必须依原法具体案件核哪些证人实际被接纳或排斥。','Jamaica',['J1748'],['E6-T08'])
add('1749','E18-A06','牙买加针对长期逃亡与收留者修改严刑条款','牙买加殖民议会、被奴役逃亡者及提供庇护者','1749年立法提高长期逃亡与协助逃亡行为的法律风险；具体追诉、死刑判决人数未从该条法令得出。','Jamaica',['J1749'],['E6-T08'])
add('1751','E18-A06','牙买加限制杀害被奴役者的刑罚并保护原主财产权','牙买加殖民议会、奴役主、殖民法院','1751年法令对故意杀害奴役者首犯仍设所谓神职豁免与不超过12个月监禁；杀害他人奴役财产者须依法赔偿60牙买加流通镑；再犯死刑取决于先前定罪。不能推定某年实际判刑或支付。','Jamaica',['J1751'],['E6-T08'],{'legal_amount_quoted':'法定对他人奴役人口死亡赔偿60牙买加镑','observed_actual_payment':None})
add('1760-12-18','E18-A07','牙买加议会具名释放18名协助镇压者','牙买加副总督、殖民议会、Foster、Pembroke、Congo Molly、Moll及其他具名被奴役者','1760年12月18日法令逐名宣告18人获得解放，包括女性Moll、Congo Molly，规定各人5镑终身年金作为奖励。法律前言采用殖民当局对“阴谋”的主张，个别人的自主选择与处境不能全由该前言推断。','Jamaica',['J1760'],['E6-T08'],{'count_in_statute':18,'count_denominator':'此一法条逐个被释放的具名人数，含重名Billy两位','legal_amount_quoted':'每人5牙买加镑年度法定年金','observed_actual_payment':None})
add('1761-12-19','E18-A07','牙买加殖民议会解放Saint Mary教区的Jack','牙买加殖民议会、Jack、庄园主Peter Thomas','1761年12月19日法条宣布Jack因协助发现和镇压殖民当局所指起义获得人身释放，规定次年5月1日起每年5镑年金；个人真实实际领款待财政册。','St Mary Parish, Jamaica',['J1761J'],['E6-T08'])
add('1761','E18-A06','牙买加修改自由身份证书续期频率','殖民议会、自由黑人及自由有色居民','1761年修法调整自由证书续期制度为七年；自由证明控制强化种族化身份审核，但仍需核各教区登记具体执行日期。','Jamaica',['J1761R'],['E6-T08'])
add('1763-12-01','E18-A07','牙买加议会为Jack Pearson颁发具名释放法','牙买加殖民议会、Jack Pearson、William Ricketts遗产管理人','1763年12月1日法令认定Jack Pearson在1760年Westmoreland叛乱镇压中协助当局，释放他并规定向原主遗产支付60牙买加镑，属于议会给定额度。','Westmoreland Parish, Jamaica',['J1763'],['E6-T08'])
add('1764-11-09','E18-A07','牙买加殖民议会释放Cato并授权向旧主付款','牙买加殖民议会、Cato、Arthur Forrest','1764年11月9日法令宣布Cato因追捕起义者及提供信息获得自由，并命令财政向Arthur Forrest支付70牙买加流通镑；法令不是付讫证明。','Jamaica',['J1764'],['E6-T08'])
add('1769','E18-A05','牙买加修订马龙人押返逃亡奴役者的法定报酬','牙买加殖民议会、马龙自治社区、逃亡奴役者','1769年法律修改追捕并交还逃亡者的奖赏与时限，规定1770年3月1日等施行节点；不同马龙社区和实际执行仍须逐村档案。','Jamaica Maroon towns（具体镇址未核）',['J1769'],['E6-T08'])
add('1770-12-19','E18-A06','牙买加将三座港镇奴役者居所登记和围栏纳入法律','牙买加殖民议会、Kingston/Port Royal/Spanish Town地方官、被奴役城镇居民','1770年12月19日立法要求登记奴役者使用的居所，并附有围墙、违章拆除等规定；这是城镇管理政策，不能据此臆造住屋地图和实际拆屋数。','Kingston; Port Royal; Spanish Town, Jamaica',['J1770'],['E6-T08'])
add('1772-03-31','E18-A06','牙买加Jones’s Pen奴役者Sam被殖民法庭定罪','奴役者Sam、庄园监工Andrew Ross、牙买加殖民法院','1772年12月法律的追述部分称，3月31日Sam杀死Andrew Ross，此后经殖民司法判处火刑；来源证实的是官方定罪及判决叙述，真实行刑日期和过程未核。','Jones’s Pen, Saint Catherine Parish, Jamaica',['J1772'],['E6-T08'],{'sentence_evidence':'colonial_statute_retrospective_conviction_and_sentence','confirmed_execution':None})
add('1772-12-23','E18-A06','牙买加议会将具名Will解放并承诺终身年金','奴役者Will、殖民议会、William Jones遗产代理人','1772年12月23日法令释放Will以奖励其调查Sam案件，赋予每年10镑年金，并授权向原奴隶主遗产代理人支付100镑；均属财政法定给付安排。','Saint Catherine Parish, Jamaica',['J1772'],['E6-T08'],{'legal_amount_quoted':'Will：每年10镑；原奴隶主遗产代表100镑','observed_actual_payment':None})
add('1774-02-12','E18-A04','牙买加议会对进口奴役人口增加税收','牙买加殖民议会、海关、参与贩卖非洲人的船东','1774年2月12日议会与委员会分别通过增加奴役人口进口税的法令，2月13日副总督Basil Keith批准。现存法条前言涉及此前税种，不能混作本法新增税率或已征收入。','Jamaica colonial legislature（具体会议厅GPS未核）',['J1774I'],['E6-T08','E6-T11-VOYAGES'],{'date_of_governor_assent':'1774-02-13','actual_tax_collected':None})
add('1774-08','E18-A07','Westmoreland殖民议会声称侦知奴役者谋划起事','牙买加殖民议会、Westmoreland被奴役社群、Attea','1774年11月法律序言称8月Westmoreland存在拟起事阴谋；这是殖民政府的单方控诉，缺独立审判证据时只记“当局声称”，不肯定地记为发生起义。','Westmoreland Parish, Jamaica',['J1774A'],['E6-T08'],{'evidence_status':'colonial_state_allegation_not_independently_adjudicated'})
add('1774-11-19','E18-A07','牙买加议会通过释放女奴役者Attea的个人法案','牙买加殖民议会、Attea、George Williams遗产继承人','1774年11月19日法条具名释放Attea，称其通报当局所说的Westmoreland叛乱策划；文书中的奖赏及主人的索赔属于法律安排，实际领款与其全部生活处境仍须档案。','Westmoreland Parish, Jamaica',['J1774A'],['E6-T08'])
add('1774-12-24','E18-A06','牙买加规定释放奴役者时由原主保障最低生活','牙买加殖民议会、获得释放的居民、原奴役主','1774年12月24日法律要求办理释放者的原主设法确保每年5镑供给；这一带有财务义务的解放制度也限制贫穷被奴役者自由申请的可行性。','Jamaica',['J1774F'],['E6-T08'])
add('1788-01-10','E18-A05','牙买加立法赋予马龙镇内白人监督员惩戒权','牙买加殖民议会、各马龙镇领导者、殖民政府委任白人监督员','1788年1月10日马龙镇法律赋予白人监督员与马龙领袖联合审理、惩戒及协助追捕逃亡者的权力，并禁止马龙人购买奴役人口。不能推断每个自治社区即刻服从所有条文。','Jamaica Maroon towns（具体镇点需核）',['J1788M'],['E6-T08'],{'policy_and_enforcement_separated':True})
# Caribbean inter-island law & status
add('1767-07-24','E18-A06','巴巴多斯1688年逃亡者鞭刑机制修订获王室核准','巴巴多斯殖民议会、王室行政、庄园主、被奴役者','法律1766年4月15日在当地通过、1767年7月24日获王室核准；限制某些外人可自行鞭打路上无出行票据的奴役者，但奴役主和监工惩罚权仍保留。两个时间点分别是地方立法与王室批准。','Barbados',['B1767'],['E6-T07-BARBADOS'])
add('1767-07-11','E18-A14','圣文森特殖民议会将奴役人口作为可继承财产立法','圣文森特殖民议会、Robert Melvill总督、被奴役居民','1767年7月11日通过、7月13日公布：法令把被奴役者按继承安排视作不动产，又可在遗产债务不足清偿时当动产；1788年议会抄本展示实务法权，不把被奴役者视作土地面积。','Kingstown / Saint Vincent（现代地名参照，法庭地点未核）',['V1767'],['E6-T07-LEEWARD'])
add('1773','E18-A19','多米尼克殖民当局授权征调自由黑人男子搜捕逃亡者','多米尼克殖民议会、总督、自由黑人和自由混血男性、逃亡奴役者','1773年法律允许组成由白人军官指挥、自由有色男性参与的追捕队；规定强征、轮值、工资、罚款与自由身份登记。法律授权不等于真实出勤人数、伤亡和具体追捕路线。','Dominica',['D1773'],['E6-T07-LEEWARD'])
add('1783-12-18','E18-A19','圣基茨禁止残害奴役者的法律同时维持受害者拍卖制度','圣基茨殖民议会、奴役主、警长、受伤被奴役居民','1783年12月18日法律针对割耳等残害行为规定500当地镑罚金与监禁，同时可在原奴隶主不能自证未伤害时由警长扣押受伤者并拍卖；处罚不是独立司法执行记录。','Basseterre, Saint Christopher / Saint Kitts',['K1783'],['E6-T07-LEEWARD'])
add('1784','E18-A22','巴哈马颁布可将缺乏自由身份证明者拍卖的刑政法律','巴哈马殖民议会、警长、自由黑人及原住民居民','1784年法条允许自由身份证明遭质疑的人在短期羁押后被拍卖，并要求已证明自由者限期离境或提供90当地镑担保。该年是法规年份，资料未提供可安全使用的月日。','Bahamas（适用群岛，逐岛实践未核）',['BA1784'],['E6-T16-ATLANTIC-ISLANDS'],{'legal_amount_quoted':'自由人留居担保90当地镑；为法定金额非收缴总额','evidence_status':'read_statute_year_only'})
# North American treaties, records, and indigenous agency
add('1769-04-25','E18-C13','英国贸易委员会批评斯坦威克斯堡条约越权与不同原住民族地权冲突','英王贸易委员会、William Johnson、Haudenosaunee六族、Cherokee、Shawnee、Delaware等','1769年4月25日英贸易委员会致国王奏呈明确承认原住民族各自具有不同的土地利益，并指出1768年北部条约与切罗基界线相冲突；奏呈提及£10460 7s 3d的财货估值，不能当各族真实领取且承认全部界线的凭据。','Whitehall, London（行政奏呈地点）；Fort Stanwix历史背景',['B1769'],['E6-T09-PENNSYLVANIA','E6-T09-CAR'],{'legal_amount_quoted':'贸易委员会记货物和货币估值£10,460 7s 3d，非付款凭证','actual_indigenous_receipt':None})
add('1711-11-30','E18-C23','纽约殖民市议会指定Wall Street Slip作为出租奴役者劳动的市场','纽约市殖民市政委员会、被奴役非洲裔与原住民劳动者','1711年11月30日纽约殖民市议会将Wall Street水边指定为雇佣被奴役黑人和原住民劳力的市场地点。官方档案网页与同档案馆博客属于同一机构，不能算彼此独立的两份原件。','Wall Street Slip, New York（具体市场历史GIS未复核）',['NY1711','NY1711b'],['E6-T09-NY'],{'claim_crosscheck_status':'same_institution_two_explanations_primary_city_record_catalogue_not_read'})
add('1758-08-26','E18-C11','英军在Oneida Carry放置Fort Stanwix第一根筑堡木料','英国驻北美军队、Oneida代表、原住民运输和协商网络','美国国家公园管理局记1758年8月26日建堡首根木料放置于Oneida Carry；军事建设依赖与Oneida人的交涉，筑堡地点与其宣称的全部土地之间必须区分。','Oneida Carry / Fort Stanwix, present-day Rome, New York',['NPS1758'],['E6-T06'])
add('1769','E18-C20','纽芬兰英方总督John Byron发布针对Beothuk遭袭的公告','John Byron、英国纽芬兰军政当局、Beothuk','纽芬兰纪念大学历史遗产项目记1769年John Byron就Beothuk遭殖民者攻击发布保护性公告；公告本身并未阻止其后的暴力、排斥及土地资源竞争。','Newfoundland（行政政策适用地区，具体公告发地待核）',['NF1769'],['E6-T10-NEWFOUNDLAND'])
add('1773','E18-C20','John Cartwright制作纽芬兰Exploits河流历史地图','John Cartwright、英国海军及殖民官员、Beothuk社群','1773年Cartwright发表Exploits河谷内陆地图，反映英国测绘知识扩张；测绘地图与Beothuk原住民实际土地政治权利不能混为一谈，待核原始地图扫描再提取地名边界。','Exploits River, Newfoundland',['NF1773'],['E6-T10-NEWFOUNDLAND'])
add('1786','E18-C20','George Christopher Pulling提出尝试缓和Beothuk冲突的官方建议','George Christopher Pulling、英国军政官员、Beothuk','1786年殖民相关官员提出派船接触与改善对Beothuk关系的建议；现阶段只能确认为政策倡议，尚未确认所有行动实际执行。','Newfoundland coast（实施航线未知）',['NF1769'],['E6-T10-NEWFOUNDLAND'])
add('1717-07','E18-C27','Thanadelthur调停后哈德孙湾公司夏季在丘吉尔河建商站','Dene外交家Thanadelthur、Cree使者、哈德孙湾公司','加拿大公园局说明Thanadelthur于1715—1716年促成Dene与Cree之间的和平交涉，贸易关系扩大后哈德孙湾公司于1717年夏天建立Churchill River商站；夏季记录不等于7月份，需按季节另记。','Churchill River, Hudson Bay（准确1717商站GPS未核）',['THAN'],['E6-T10-HBC'],{'date_text':'1717','month':None,'date_precision':'year','chronological_note':'原史料仅写summer 1717，不准转化为7月','event_phase_season':'summer'})
# No independent 1799 New York new act because USA post-independence; documented in dedicated note rather than British imperial event.

# Improve existing directly checked records without duplicating underlying event
byid={e['id']:e for e in E['events']}
def update(old,source,addendum,more=None):
    if old not in byid:return
    ev=byid[old]; ev.setdefault('v4_verified_primary_clauses',[]).append(addendum)
    if source not in ev['source_ids']:
        ev['source_ids'].append(source);ev['source_urls'].append(next(s['url'] for s in S['sources'] if s['id']==source))
    ev['source_support_count']=len(ev['source_ids'])
    ev['v4_primary_read']='online_transcription_not_original_physical_manuscript'
    if more:ev.update(more)
update('E18A-1739-A05-01',L['J1739'],'原文Trelawny营地1738-9年3月1日（现代1739），第3条法定1500英亩、第6和第9条追捕逃亡者、第13条道路义务；1500不是实测土地GIS。',{'historical_control_boundary_verified':False,'legal_area_acres_clause':1500,'actual_territory_polygon':None})
update('E18A-1760-A06-01',L['J1760'],'同日第23章具名释放18人，含Congo Molly与Moll；与第22章针对逃亡和Obeah的限制分别建候审事件。')
update('E18A3-1768-HARD-LABOUR',L['H1768'],'Encyclopedia Virginia所辑原始条约将日期记1768-10-14；另一NPS来源提出10月17日不同日次，仍仅用月精度并逐项保留异文。',{'date_conflict_zh':'已读原始条约转录10月14日，NPS另记10月17日；待原始议事日记/批准文书解决，保持month。'})
update('E18A3-1770-LOCHABER',L['L1770'],'条约转录：10月18日各首领会议，10月22日文本列Treaty议程，12月12日向议会宣读；原候审日精确指会议起始，不宜笼统称当日所有法律步骤完成。',{'title':'1770年10月18日英国与Cherokee首领开始Lochaber边界议约会议','v4_date_event_nature':'assembly_on_1770-10-18; treaty_proceedings_on_10-22; council_read_on_12-12'})
update('E18A-1715-C27-01',L['THAN'],'Parks Canada列Dene女性Thanadelthur作为翻译与谈判者主导与Cree和平；可证1715—16跨年，不能定位路线。')
update('E18A2-HBC-DENE-ESCAPE',L['THAN'],'Parks Canada明确1714年Thanadelthur逃离俘虏处境进入York Factory；地点仅官方遗产区域，不准创精确路程。')
update('E18A2-HBC-DENE-PEACE',L['THAN'],'Parks Canada明确是1715—1716跨年和平交涉；其政治贡献应为Dene主动外交，不可全部写为HBC代行。')
update('E18A-1768-C20-01',L['NF1769'],'纪念大学独立机构史说明Palliser与Cartwright 1768接触Beothuk及1769 Byron政策，不混为一次原住民让地。')
update('E18A-1784-C20-01',L['NF1769'],'纪念大学官方研究记1784 Cartwright提出保留区倡议；未证明此建议立即落实。')

# Refresh source pointer linkages for all A/C topics; do not collapse historical original event IDs.
E['events'].extend(new)
E['last_local_research_extension']={'round':4,'date':'2026-11-08','new_distinct_events':len(new),'new_source_records':len(new_source),'original_event_count':len(existing_ids),'scope':'Jamaica 1717-1788 named legal persons, Caribbean colonial law, Cherokee treaty contest, Indigenous mapping/diplomacy, 1711 NYC slave labor market','publication_status':'research_only'}
S['last_local_research_extension']={'round':4,'new_sources':len(new_source),'verified_as_of':'2026-11-08','no_duplicate_url_ids_created':True}
valid_s={s['id'] for s in S['sources']}
for e in E['events']:
    assert len(e['source_ids'])==len(set(e['source_ids']))
    assert set(e['source_ids']).issubset(valid_s),e['id']
    assert e['latitude'] is None and e['longitude'] is None or (e['latitude'] is not None and e['longitude'] is not None)
    if e['id'].startswith('E18A4-'):
        assert e['latitude'] is None and e['longitude'] is None and e['area_sqkm'] is None
for s in S['sources']:
    for e in new:
        if s['id'] in e['source_ids']:
            s.setdefault('supported_event_candidate_ids',[]).append(e['id'])
            for t in e['topic_ids']:
                if t not in s.setdefault('supported_topic_ids',[]):s['supported_topic_ids'].append(t)
# topic index is master 49 scopes
for t in T['topics']:
    evs=[e for e in E['events'] if t['id'] in e.get('topic_ids',[])]
    t['candidate_event_count']=len(evs)
    for v in new:
        if t['id'] in v['topic_ids']:
            t.setdefault('v4_new_event_ids',[]).append(v['id'])
            for x in v['source_ids']:
                if x not in t['source_ids']:t['source_ids'].append(x)
    t['index_refresh']='2026-11-08_round4_local'
T['last_local_research_extension']={'round':4,'added':len(new),'source_added':len(new_source)}
W('EVENT_CANDIDATES.json',E);W('SOURCE_REGISTRY.json',S);W('TOPIC_INDEX.json',T)
# CSV all known original columns + new columns; nested fields JSON serialized
fields=[]
for e in E['events']:
    for k in e.keys():
        if k not in fields:fields.append(k)
with (R/'EVENT_CANDIDATES.csv').open('w',newline='',encoding='utf-8-sig') as f:
    wr=csv.DictWriter(f,fieldnames=fields);wr.writeheader()
    for e in E['events']:
        wr.writerow({k:(json.dumps(v,ensure_ascii=False) if isinstance(v,(list,dict)) else v) for k,v in e.items()})
print('new_events',len(new),'total_events',len(E['events']),'new_sources',len(new_source),'total_sources',len(S['sources']))
