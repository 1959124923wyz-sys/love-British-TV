from pathlib import Path
import json,csv,collections,datetime,zipfile,hashlib
ROOT=Path('/mnt/data/18c_assistant_A')
TOPIC_DATA='''
A01|跨大西洋英国船运与被奴役人口买卖|1700|1799|S02,S03,S38,N01|E6-T11,E6-T11-VOYAGES,E6-T13,E6-T17-AFRICAN-FORTS
A02|南海公司与西属美洲Asiento奴隶供应权|1713|1748|S02,S38,N12|E6-T11,E6-T11-VOYAGES,E6-T14-NAV,E6-T15
A03|皇家非洲公司余业与私人商人竞争|1700|1799|S02,S03,S38,S82|E6-T13
A04|伦敦—布里斯托尔—利物浦奴役贸易与造船保险|1700|1799|S04,S38,N08|E6-T15
A05|牙买加第一次马龙战争与1739年和约|1730|1739|S02,N02,N03|E6-T08
A06|巴巴多斯、牙买加糖业奴役与殖民法律|1700|1799|S38,S56,N09|E6-T07,E6-T07-BARBADOS
A07|牙买加Tacky起义与殖民军镇压|1760|1761|S02,N04,N05|E6-T08
A08|Somerset案与英格兰强制遣返合法性限制|1772|1772|S02,N13|E6-T11-VOYAGES
A09|宗号海上杀人事件与伦敦保险诉讼|1781|1783|S03,S05,N06|E6-T11,E6-T11-VOYAGES
A10|英国废奴舆论、被奴役者叙述与仍持续的贸易|1787|1799|S02,N07,N01|E6-T11-VOYAGES
A11|牙买加第二次马龙战争|1795|1796|S25,S26,N02|E6-T08
A12|牙买加Trelawny马龙人强制流放新斯科舍|1796|1796|S25,S26,N15|E6-T08
A13|格林纳达Fédon起义与英国殖民当局反扑|1795|1796|S24,N16,N17|E6-T07-LEEWARD
A14|圣文森特第一次Carib战争|1772|1773|S54,S59|E6-T07,E6-T07-LEEWARD
A15|圣文森特第二次Carib战争|1795|1796|S24,N18|E6-T07,E6-T07-LEEWARD
A16|Garifuna从圣文森特经Baliceaux被流放至Roatán|1796|1797|S24,N18|E6-T07-LEEWARD
A17|西印度军团采购被奴役非洲人入伍|1795|1799|S41,N19|E6-T07-BARBADOS
A18|英国介入法属圣多明各与奴役制度重建企图|1793|1798|S56,N20|E6-T11-VOYAGES
A19|向风群岛与背风群岛易手、奴役种植园扩展|1763|1799|S56,N16|E6-T07-LEEWARD
A20|西非—加勒比海的奴役船死亡与船长处罚制度|1700|1799|S03,S38,S05,N01|E6-T11-VOYAGES
A21|安提瓜1736年‘阴谋’审判与殖民当局处决|1701|1736|S84,N21|E6-T07,E6-T07-LEEWARD
A22|百慕大与巴哈马殖民管理、私掠活动及奴役制度延续|1700|1799|S56,N22|E6-T16-ATLANTIC-ISLANDS
C01|英军夺取皇家港及阿卡迪亚控制转换|1710|1710|S44,N23|E6-T10,E6-T10-ACADIA
C02|乌得勒支条约的阿卡迪亚转让与原住民未让地|1713|1713|S11,N24|E6-T10,E6-T10-ACADIA
C03|米克马克和Wolastoqiyik抵抗、英方条约谈判|1722|1728|S44,N25|E6-T10-ACADIA
C04|英国在Kjipuktuk建立哈利法克斯|1749|1749|S42,S69|E6-T10-ACADIA
C05|哈利法克斯当局对米克马克战争与赏金文件|1749|1752|S42,S44,N26|E6-T10-ACADIA
C06|英军建Fort Edward巩固Pisiquid地区|1750|1750|S10,S63|E6-T10-ACADIA
C07|阿卡迪亚大驱逐的命令、押船与人口损失|1755|1762|S06,S08,N27|E6-T10-ACADIA
C08|Grand-Pré/Les Mines居民扣押与驱逐|1755|1755|S07,S65|E6-T10-ACADIA
C09|Pisiquid/Fort Edward地区居民押船驱逐|1755|1755|S10,S63|E6-T10-ACADIA
C10|Île Saint-Jean/Skmaqn阿卡迪亚居民被驱逐|1758|1758|S09,S66|E6-T10-ACADIA
C11|七年战争北美扩张、地方盟约与战后领土|1754|1763|S32,S34,N28,N29|E6-T10-QUEBEC-KIRKE
C12|Pontiac及其他原住民反抗英军堡垒|1763|1765|S32,N30|E6-T06
C13|1763王室公告的原住民土地与定居边界|1763|1763|S32,N31|E6-T09-NE-DOMINION
C14|Paxton Boys杀害Susquehannock社区|1763|1763|S39,N32|E6-T09-PENNSYLVANIA,E6-T09-CAR
C15|印花税法、英国财政索取与殖民地抵抗|1765|1765|S34,N33|E6-T14-NAV
C16|波士顿驻军对平民开火|1770|1770|S33|E6-T09-NE-DOMINION
C17|英国镇压北美殖民地独立战争与奴役社会|1775|1783|S34,N34,N35|E6-T05,E6-T06,E6-T14-NAV
C18|新斯科舍黑人效忠派遭遇土地授予歧视|1783|1792|S35,N36|E6-T05
C19|黑人效忠派由新斯科舍迁居塞拉利昂|1792|1792|S35,S36,N36|E6-T11-VOYAGES
C20|纽芬兰Beothuk与英法渔业、殖民者冲突|1700|1799|S44,N37,N38|E6-T10-NEWFOUNDLAND
C21|卡罗来纳原住民贸易债务与1715—1718年亚马西战争|1707|1718|S73,N39|E6-T09,E6-T09-CAR
C22|弗吉尼亚1705奴役法律总编与1748年制度修订|1705|1748|S74,N40,N41|E6-T05
C23|纽约被奴役黑人1712年起义、处决与新法|1712|1712|S83,N42|E6-T09,E6-T09-NY
C24|纽约1741年‘奴役阴谋’审判、处决与流放|1741|1741|S75|E6-T09,E6-T09-NY
C25|宾州1737年步行购买对Lenape的土地剥夺|1735|1758|S76,S77,S86,S87,N43|E6-T09,E6-T09-PENNSYLVANIA
C26|纽芬兰1699渔业法1700年生效及1729行政转变|1700|1729|S79,S80,N44|E6-T10,E6-T10-NEWFOUNDLAND
C27|哈德孙湾公司1713堡垒返还、Dene—Cree外交与内陆贸易|1713|1774|S81,S85,N45|E6-T10,E6-T10-HBC
'''
TOPICS={}
for ln in TOPIC_DATA.strip().splitlines():
 x=ln.split('|');code,title,start,end,sources,old=x
 tid='E18-'+code
 TOPICS[tid]={'id':tid,'title':title,'research_window':{'start_year':int(start),'end_year':int(end)},'source_ids':sources.split(','),'previous_story_ids':old.split(','),'status':'research_only','publication_review':'not_submitted'}
# Source record: ID | 机构/作者 | 文献真实标题/性质 | URL | 本次实际读取级别 | 支持事实与限制
SOURCE_DATA='''
S02|Historic England|Timeline of the Transatlantic Slave Trade and Abolition|https://historicengland.org.uk/research/inclusive-heritage/the-slave-trade-and-abolition/time-line/|institutional_webpage_read|1698垄断结束、1713 Asiento、1730/1739马龙战争、1772 Somerset；年表不能替代原件
S03|The National Archives UK|British transatlantic slave trade records|https://www.nationalarchives.gov.uk/help-with-your-research/research-guides/british-transatlantic-slave-trade-records/|archive_guide_only|馆藏查档路线，未逐页核原卷
S04|The National Archives UK|Transatlantic slave trade Georgian collection|https://www.nationalarchives.gov.uk/explore-the-collection/explore-by-time-period/georgians/transatlantic-slave-trade/|institutional_web_context|1749布里斯托商业清单CO 388/45背景；须核原单
S05|London Museum|The Zong Massacre Trial|https://www.londonmuseum.org.uk/collections/london-stories/zong-massacre-trial/|institutional_webpage_read|1781 Zong约130/133人遭杀、1783民事保险诉讼；死亡人数页面内部有不同表述
S06|Parks Canada|Acadian Deportation National Historic Event|https://www.pc.gc.ca/apps/dfhd/page_nhs_eng.aspx?id=1508|repository_reference_not_individually_opened|旧PR官方事件锚点，需复核页面更新
S07|Parks Canada|History of Grand-Pré|https://parks.canada.ca/lhn-nhs/ns/grandpre/culture/histoire-history|institutional_webpage_read|1755 Les Mines约2200人、1764返回后旧地已占
S08|Parks Canada|The great upheaval Fort Beauséjour|https://parks.canada.ca/lhn-nhs/nb/beausejour/culture/histoire-history/deportation|institutional_webpage_read|1755-07-28命令、多个地区押送、1759抵抗、1761捕获、1764棚屋388人
S09|Parks Canada|Skmaqn–Port-la-Joye–Fort Amherst|https://parks.canada.ca/culture/designation/lieu-site/skmaqn|repository_reference_not_individually_opened|1758 Île Saint-Jean驱逐，灾难航次；数字另核
S10|Parks Canada|History Fort Edward|https://parks.canada.ca/lhn-nhs/ns/edward/culture/histoire-history|institutional_webpage_read|1750 Fort Edward修建与1755 Pisiquid约1200驱逐
S11|Parks Canada|A village caught in the crossfire Beaubassin|https://parks.canada.ca/lhn-nhs/ns/beaubassin/culture/village|institutional_webpage_read|1704袭击、1713边界不定、1722船只、1730宣誓、1750受迫迁移
S24|Douglas Hamilton|To prevent any succour to the insurgents: Royal Navy in Caribbean|https://journals.sagepub.com/doi/full/10.1177/08438714231219455|peer_reviewed_fulltext_read|1795 Grenada军事行动、1795—96 St Vincent及镇压中的皇家海军；不推测船位
S25|Parks Canada|The Jamaican Maroons in Nova Scotia|https://www.parks.canada.ca/lhn-nhs/ns/halifax/culture/histoire-history/marrons-maroons|institutional_webpage_read|1796强迫迁徙500余人、1800迁塞拉利昂
S26|Government of Canada Parks Canada|Jamaican Maroons national historic significance|https://www.canada.ca/en/parks-canada/news/2024/07/the-government-of-canada-honours-the-national-historic-significance-of-the-jamaican-maroons-in-nova-scotia.html|official_commemoration_catalogue|1796 Trelawny马龙被驱逐和后续抵抗
S32|US National Park Service|American Revolution in the Ohio Country|https://www.nps.gov/articles/000/american-revolution-in-the-ohio-country.htm|repository_reference_not_individually_opened|1763 Pontiac等原住民抵抗与英方政策
S33|US National Park Service|Boston Massacre|https://home.nps.gov/articles/000/boston-massacre.htm|repository_reference_not_individually_opened|1770波士顿开枪历史
S34|US National Park Service|American Revolution Timeline|https://www.nps.gov/subjects/americanrevolution/timeline.htm|institutional_webpage_read|1763—1783战争、1775解放公告
S35|Canadian Museum of Immigration at Pier 21|Shaping a Community: Black Refugees in Nova Scotia|https://pier21.ca/research/immigration-history/shaping-a-community-black-refugees-in-ns|museum_article_read|1783黑人效忠派约3000、1792迁约1200、土地歧视
S36|University of New Brunswick|CO 270: Sierra Leone Company and Colonial records 1792–1801|https://loyalist.lib.unb.ca/record/sessional-papers-sierra-leone-co-270-1792-1801|archive_catalogue_only|档案目录，非逐页查阅
S38|Historic England|The Transatlantic Slave Economy and England's Built Environment|https://historicengland.org.uk/research/results/reports/8203/TheTransatlanticSlaveEconomyandEnglandsBuiltEnvironmentAResearchAudit|research_audit_web_index|英国港市与奴隶经济联系；不得假设所有从业者利润
S39|US National Park Service|Susquehanna Paxton Boys Indigenous landscape study|https://www.nps.gov/cajo/learn/upload/ICL-Susquehanna-Part-2-Faull-508.pdf|pdf_catalogue_and_search_snippet_not_page_inspected|1763 Paxton Boys杀害Conestoga/Susquehannock社区；原PDF未逐页核
S41|National Army Museum|The West India Regiments|https://www.nam.ac.uk/explore/west-india-regiments|institutional_webpage_read|1795—1807估计购入13400名奴役士兵，切不可当1795—1799数
S42|Parks Canada|Four Citadels, Halifax Citadel|https://www.parks.canada.ca/lhn-nhs/ns/halifax/culture/histoire-history/citadelles-4-citadels|repository_reference_not_individually_opened|1749 Kjipuktuk英国殖民军镇；现代参照点
S44|Parks Canada|Fort Anne History|https://parks.canada.ca/lhn-nhs/ns/fortanne/culture/histoire-history|institutional_webpage_read|1710皇家港投降、1713声索、1726和约
S54|Cambridge University Press|Scene of a Foul Transaction: St Vincent 1772|https://www.cambridge.org/core/books/abs/evaluating-empire-and-confronting-colonialism-in-eighteenthcentury-britain/scene-of-a-foul-transaction/906EF209084CD56104D5E3A04D22F006|academic_book_abstract_only|1772英国对Black Caribs的远征及当时英国批评，未读全文
S56|The National Archives UK|Caribbean social and cultural history|https://www.nationalarchives.gov.uk/help-with-your-research/research-guides/caribbean-social-and-cultural-history/|archive_guide_only|CO殖民地档案查档入口，不是特定法律内容原件
S59|Wellcome Collection|1773年圣文森特远征议会原始小册目录|https://wellcomecollection.org/works/spweptwq|contemporary_source_catalogue_only|当时议会信息有出处，尚未读原版
S63|Parks Canada|Directions Fort Edward|https://www.parcs.canada.ca/lhn-nhs/ns/edward/visit/directions|official_modern_site_coordinate_from_pr289|Fort Edward现代遗址坐标；与PR候审点略有记录差异
S64|Natural Resources Canada CGNDB|Fort Beauséjour official placename|https://geonames.nrcan.gc.ca/search-place-names/unique?id=DZAAD|official_modern_placename_coordinate_from_pr289|Fort Beauséjour现代地名；不是1755军队GPS
S65|Natural Resources Canada CGNDB|Grand-Pré official placename|https://toponymes.rncan.gc.ca/search-place-names/unique?id=CBUWX|official_modern_placename_coordinate_from_pr289|Grand-Pré现代地名；不是船舶码头GPS
S66|Parks Canada|Skmaqn Port-la-Joye visitor coordinates|https://parks.canada.ca/lhn-nhs/pe/skmaqn/visit/location?wbdisable=true|official_modern_site_coordinate_from_pr289|Skmaqn现代站点GPS；不是全部驱逐地
S67|Parks Canada|Fort Anne visitor directions|https://www.parcs.canada.ca/lhn-nhs/ns/fortanne/visit/directions|official_modern_site_coordinate_from_pr289|Fort Anne现代参照坐标
S69|Parks Canada|National historic sites directory|https://parks.canada.ca/lhn-nhs/recherche-search|official_modern_site_coordinate_from_pr289|Halifax城堡现代参照坐标
S70|Parks Canada|Fort Anne Visitor Guide|https://parks.canada.ca/lhn-nhs/ns/fortanne/visit/carte-map/guidedevisiteur-visitorguide|official_visitor_guide_from_pr289|1755 Annapolis Royal附近1664人遭驱逐；地区人数非单点人数
S73|Michael P Morris / South Carolina Encyclopedia|Yamassee War|https://www.scencyclopedia.org/sce/entries/yamassee-war/|regional_scholarly_article_read|1707监管失败、1715-04-15冲突、1716政府管制
S74|University of Virginia VCDH|Slavery Laws 1700–1750|https://www2.vcdh.virginia.edu/gos/laws1700-1750.html|primary_legislation_directory_from_pr289|1705/1748各法条，部分全文另见N40/N41
S75|Historical Society of the New York Courts|Slave Conspiracy Trials 1741|https://history.nycourts.gov/case/slave-conspiracy-trials/|institutional_legal_history_read|1741-03-08火、04-21开庭、约200受审、30判死与70流放；审判证词争议
S76|Haverford College / UPenn finding aids|Walking Purchase papers 1735–1738|https://findingaids.library.upenn.edu/records/HAVERFORD_HC.MC.950.175|archive_catalogue_only|馆藏登记不是原始地契通读
S77|Bucks County Pennsylvania|Walking Purchase|https://www.buckscounty.gov/1567/Walking-Purchase|county_official_site_from_pr289|1737步行购买Lenape土地纷争
S79|Memorial University Newfoundland Heritage|King William's Act of 1699|https://www.heritage.nl.ca/lawfoundation/articles/doc2_1699william.html|primary_law_transcription_read|法律原文与1700渔季适用日期
S80|Newfoundland and Labrador Provincial Courts|Historical overview|https://www.court.nl.ca/provincial/about/court-profile/historical-overview/|official_court_history_from_pr289|1729 Osborn海军总督与法庭行政
S81|Manitoba Historical Society|Manitoba Timeline|https://www.mhs.mb.ca/docs/features/timeline.shtml|institutional_chronology_read|1713返堡、1715 Thanadelthur、1774 Cumberland House
S82|UK Parliament|Parliament regulates the Africa trade|https://www.parliament.uk/about/living-heritage/transformingsociety/tradeindustry/slavetrade/overview/parliament-regulates-the-africa-trade/|institutional_webpage_read|1698皇家非洲公司垄断结束而非公司贸易终止
S83|NYC Commission on Human Rights|Anti Black Racism Report|https://home4.nyc.gov/assets/cchr/downloads/pdf/publications/AntiBlackRacism_Report.pdf|repository_pdf_reference_not_page_inspected|1712纽约奴役起义和司法反应
S84|Mike Dash / Smithsonian Magazine|Antigua's Disputed Slave Conspiracy of 1736|https://www.smithsonianmag.com/history/antiguas-disputed-slave-conspiracy-of-1736-117569/|history_scholar_summary_read|Prince Klaas、88处死说、132定罪口径、所谓阴谋证据争议
S85|Manitoba Historical Society|Prince of Wales Fort|https://www.mhs.mb.ca/docs/transactions/3/princeofwalesfort.shtml|institutional_article_from_pr289|HBC海湾堡垒与原住民商业联系
S86|University of Pennsylvania|Lenape Walking Purchase digital history|https://dia.upenn.edu/en/content/LeechM001/|academic_digital_history_from_pr289|1737地契与后续莱纳佩反抗，未核宗号地图边界
S87|Delaware Tribe of Indians|Lenape History|https://delawaretribe.org/cultural-education/culture-and-language/lenape-history/|indigenous_community_bibliography_from_pr289|Lenape主体的当代研究目录
N01|SlaveVoyages|Trans-Atlantic Slave Trade Estimates 1501–1866|https://legacy.slavevoyages.org/assessment/estimates|research_database_table_read|英国船旗1701—1725=410597、1726—1750=554042、1751—1775=832047、1776—1800=748612；估计被迫登船，最后一个区间含1800
N02|National Library of Jamaica|The Maroons historical notes|https://www.nlj.gov.jm/history-notes/The%20Maroons%20edited%20final.htm|national_library_history_read|1734夺Nanny Town、1739-03-01 Cudjoe和约、1739-12-23 Quao和约
N03|Jamaica Information Service|Nanny of the Maroons|https://jis.gov.jm/heroes/nanny-of-the-maroons/|national_agency_biography_read|Nanny与Quao不同马龙政治主体；和约异议
N04|Institute of Historical Research|Colonial History Collections Tacky’s Revolt|https://www.history.ac.uk/library/collections/colonial-history-collections|university_research_guide_read|1760 Tacky起义原始日记、Long及当时官方叙述存在偏差
N05|JSTOR Open Access|Archival Irruptions Jamaican Obeah studies|https://www.jstor.org/content/oa_book_monograph/jj.33506907|academic_open_access_index_read|1760-04爆发及Mesopotamia消息；网页可见节摘要
N06|The National Archives UK|Slave trade Zong archival research guide|https://www.nationalarchives.gov.uk/help-with-your-research/research-guides/british-transatlantic-slave-trade-records/|archive_guide_only|宗号保险案件进一步追KB 122/479
N07|UK Parliament|Wilberforce makes the case|https://www.parliament.uk/about/living-heritage/transformingsociety/tradeindustry/slavetrade/overview/wilberforce-makes-the-case/|parliamentary_history_read|1787组织、1788调查、1789国会发言、1792议会停滞
N08|Historic England|Transatlantic Slave Economy research audit|https://historicengland.org.uk/research/results/reports/8203/TheTransatlanticSlaveEconomyandEngland|academic_research_pdf_search_summary_only|布里斯托尔1720—1730年代重要港口；未逐页检查PDF
N09|The National Archives UK|Caribbean social cultural history guide|https://www.nationalarchives.gov.uk/help-with-your-research/research-guides/caribbean-social-and-cultural-history/|archive_guide_only|庄园人口、殖民法案和CO系列进一步查档
N12|UK Parliament|Parliament and British Slave Trade Key dates|https://www.parliament.uk/about/living-heritage/transformingsociety/tradeindustry/slavetrade/key-dates/|parliamentary_timeline_read|1713 Asiento贸易、1756—63岛屿政权变更
N13|US National Park Service|John Hannigan: Service with the British Army|https://home.nps.gov/articles/000/john-hannigan-patriots-of-color-paper-2.htm|institutional_history_read|Somerset 1772与Dunmore相关法权区分
N15|Parks Canada|The Jamaican Maroons in Nova Scotia National Historic Event|https://parks.canada.ca/culture/designation/evenement-event/marrons-maroons|official_detailed_study_read|1796约150家庭500余人、July抵达、1800-09-30 HMS Asia至Freetown载550人
N16|Tessa Murphy / HAL|A Reassertion of Rights: Fedon's Rebellion|https://ideas.repec.org/p/hal/journl/hal-01856739.html|peer_reviewed_abstract_read|1795—96非裔、法国天主教徒等诉求多元
N17|Kit Candlin / Slavery & Abolition|The Role of the Enslaved in Fedon's Rebellion|https://www.tandfonline.com/doi/abs/10.1080/0144039X.2018.1464623|peer_reviewed_abstract_read|研究估计1795—96约7000被奴役者死亡，需核原文统计来源
N18|Douglas Hamilton / Sage|Royal Navy counterinsurgency 1795–1832|https://journals.sagepub.com/doi/10.1177/08438714231219455|peer_reviewed_fulltext_read|圣文森特第二次战争、Grenada 1795反叛及海军阻断
N19|National Army Museum|West India Regiments gallery artefact|https://collection.nam.ac.uk/detail.php?acc=1975-08-55-3|primary_object_catalogue_read|1801年购272人的账非18世纪统计，1795-1807综合估计分母
N20|Cambridge University Press|From Slaves and Servants to Citizens?|https://www.cambridge.org/core/journals/international-review-of-social-history/article/from-slaves-and-servants-to-citizens-regulating-dependency-race-and-gender-in-revolutionary-france-and-the-french-west-indies/B116464991B8994CF9C2CDA63EA85F73|peer_reviewed_fulltext_read|1793法属圣多明各废奴及英国干预、1798停战
N21|Smithsonian Magazine / Mike Dash|Antigua's Disputed Slave Conspiracy|https://www.smithsonianmag.com/history/antiguas-disputed-slave-conspiracy-of-1736-117569/|history_magazine_scholar_summary_read|1736年处刑口径与口供争议；与S84同源不算独立交叉核查
N22|UK National Archives|Caribbean archive research guide|https://www.nationalarchives.gov.uk/help-with-your-research/research-guides/caribbean-social-and-cultural-history/|archive_guide_only|百慕大巴哈马逐岛具体法律仍需补查
N23|Parks Canada|Fort Anne People of Significance|https://www.parks.canada.ca/lhn-nhs/ns/fortanne/culture/personnes-people|official_site_history_read|1710 Francis Nicholson率军取Port Royal及五公里堡周范围
N24|Parks Canada|Fort Anne History|https://parks.canada.ca/lhn-nhs/ns/fortanne/culture/histoire-history|official_site_history_read|1710-10-16投降、1713阿卡迪亚范围未定
N25|Parks Canada|Peace and Friendship Treaty of 1726|https://parks.canada.ca/culture/designation/evenement-event/traite-1726-treaty|official_commemoration_full_read|1726-06-04在Annapolis Royal缔约、64名领袖出席、并未向英方割让所有土地
N26|Parks Canada|Halifax Citadel history|https://www.parks.canada.ca/lhn-nhs/ns/halifax/culture/histoire-history/citadelles-4-citadels|official_site_history_from_pr289|1749军事建镇，头皮赏金原卷待核
N27|Parks Canada|Fort Beausejour siege 1755|https://www.parks.canada.ca/lhn-nhs/nb/beausejour/culture/histoire-history/siege-1755|official_military_site_history_read|1755-06-02英军登陆、06-16法堡降，实际取堡非整区域已控
N28|Parks Canada|History Battle of Restigouche|https://parks.canada.ca/lhn-nhs/qc/ristigouche/culture/histoire-history/contexte|official_site_history_read|1758-07-26 Louisbourg、1759-09-13魁北克战、09-18投降、1760-04-28 Sainte-Foy
N29|Parks Canada|Fortress Louisbourg History|https://parks.canada.ca/lhn-nhs/ns/louisbourg/decouvrir-discover/histoire-history|official_site_history_read|1745英殖民军取堡、1748归法、1758复取及毁城防
N30|Canada Department of National Defence|The Imperial Wars Indigenous Peoples and Canadian Military|https://www.canada.ca/en/department-national-defence/services/military-history/history-heritage/popular-books/aboriginal-people-canadian-military/imperial-wars.html|government_military_history_read|1760原住民外交、1763 Pontiac抵抗及礼物贸易政策
N31|US National Archives Museum|Roots of Rebellion|https://visit.archives.gov/whats-on/explore-exhibits/roots-rebellion|national_archives_museum_read|1763-10-07王室公告禁止殖民者越阿巴拉契亚扩张；实效有限
N32|US National Park Service|Susquehanna Indigenous Cultural Landscape Study|https://www.nps.gov/cajo/learn/upload/ICL-Susquehanna-Part-2-Faull-508.pdf|pdf_search_catalogue_only|Paxton事件原PDF待页码核读
N33|US National Park Service|American Revolution Timeline|https://www.nps.gov/subjects/americanrevolution/timeline.htm|official_timeline_read|1765印花税前后政策背景；法条另核
N34|US National Park Service|War and Politics 1675–1781|https://www.nps.gov/articles/warpoli.htm|institutional_webpage_read|1775-11-07 Dunmore公告、12-09 Great Bridge败战
N35|US National Park Service|Chapter 1 Race Slavery and Freedom|https://www.nps.gov/articles/000/chapter-1-race-slavery-and-freedom-the-contagion-of-liberty.htm|institutional_webpage_read|1775 Dunmore招募奴役者，需限定为效忠英国营地的个体
N36|US National Archives|Forgotten Soldier - Book of Negroes|https://prologue.blogs.archives.gov/2019/07/15/forgotten-soldier-at-american-revolution-museum-at-yorktown/|national_archive_history_read|1783姓名登记与1792赴塞拉利昂；不能以册页当所有幸存者人数
N37|Memorial University Newfoundland Heritage|Post-Contact Beothuk History|https://www.heritage.nl.ca/articles/indigenous/beothuk-history.php|university_heritage_research_read|1768 John Cartwright沿Exploits调查、1797 Waldegrave公告、18世纪猎捕冲突
N38|Ralph T Pastore / Memorial University|The Beothuk|https://www.heritage.nl.ca/articles/indigenous/beothuk.php|university_academic_essay_read|英法渔业向Notre Dame Bay扩张、Beothuk海岸生计被挤压
N39|NCpedia / North Carolina State Library|Yamassee War|https://www.ncpedia.org/yamassee-war|state_library_scholarly_reference_read|1715-04-15战事及多原住民群体参与
N40|Virginia General Assembly / Encyclopedia Virginia|An Act concerning Servants and Slaves 1705|https://encyclopediavirginia.org/primary-documents/an-act-concerning-servants-and-slaves-1705/|primary_law_transcription_read|1705年10月法令逐条，Hening 1823校印本3卷447-463
N41|University of New Brunswick|An Act concerning Servants and Slaves|https://slaveryandfreedomlaws.lib.unb.ca/laws/virginia-1705-1|primary_law_abridged_1722_edition_read|1722缩写文本与1705原文不能当独立法令
N42|NYC Landmarks Preservation Commission|African Burial Grounds and the Commons District|https://s-media.nyc.gov/agencies/lpc/lp/1901.pdf|municipal_landmark_pdf_search_only|1712被处决21名非洲裔可能在Commons处决/埋葬；原PDF未页级核查
N43|Bucks County government|Walking Purchase official history|https://www.buckscounty.gov/1567/Walking-Purchase|county_site_from_repo289|1737步行购买受害族群、测绘需原合同和地图
N44|Memorial University|Primary Documents Newfoundland law|https://www.heritage.nl.ca/lawfoundation/articles/primary.html|primary_law_guide_read|1699法和1729行政变革，1700为受规制渔季
N45|Manitoba Historical Society|Manitoba Historical Timeline|https://www.mhs.mb.ca/docs/features/timeline.shtml|historical_chronology_read|1713 HBC、1715 Thanadelthur、1774 Cumberland House
'''
SOURCES={}
for ln in SOURCE_DATA.strip().splitlines():
 k,org,title,url,level,support=ln.split('|',5)
 SOURCES[k]={'id':k,'author_or_institution':org,'title':title,'url':url,'type':level,'actually_read_scope':support,'manuscript_inspected':level.startswith('primary_law_transcription') or level.startswith('primary_law_abridged'), 'read_scope_note':'只有标记read的网页正文/官方概述已本轮浏览；仅目录/索引/搜索摘要资料未逐页复核。'}
# Additional archival finds discovered during full-scope pass; accessible depth is explicit.
for k,org,t,url,level,fact in [
('N46','Smithsonian NMAAHC','An Act for Extending and Improving the Trade to Africa 1750','https://collections.si.edu/search/detail/edanmdm%3Anmaahc_2019.28.2?print=yes','original_legal_print_catalogue','1750商业公司改组法22页馆藏目录与法案内容说明'),
('N47','Columbia University MAAP','Slave Revolt of 1712','https://maap.columbia.edu/place/34.html','university_digital_history_read','1712-04-06起义发生Maiden Lane、当时纽约司法处刑不同统计'),
('N48','PBS WGBH','New York The Revolt of 1712','https://cgi.pbs.org/wgbh/aia/part1/1p285.html','public_history_read','1712-04-06夜起义，人数及审判后果可与Columbia交叉核对'),
('N49','US National Endowment for the Humanities','Benjamin Franklin and the Pamphlet Wars','https://www.neh.gov/article/benjamin-franklin-and-pamphlet-wars','federal_public_history_with_quoted_contemporary_text','1763-12-14与12-27 Conestoga居民遭杀，重印Franklin当年文字'),
('N50','Garifuna Nation','History of the Garifuna People','https://www.garifunanation.org/history/','indigenous_community_history_read','自述1797-04-12约2500人在Roatan登陆；人数和日期须与运输卷宗交叉'),
('N51','Bahamas Government National Archives','Woodes Rogers First Royal Governor','https://cdn.bahamas.gov.bs/tenant/tenantbahamasnationalarchives/documents/All%20Documents/woodes-rogers-20240612150828.pdf','official_archive_pdf_search_only','1718-02-06就任、07-26抵达、1729议会；PDF需逐页截图'),
('N52','David Wilson / Cambridge UP','Woodes Rogers and Private Enterprise in New Providence','https://www.cambridge.org/core/books/abs/suppressing-piracy-in-the-early-eighteenth-century/woodes-rogers-and-private-enterprise-in-new-providence/261417D327F28381E829F4387C645E32','peer_reviewed_book_chapter_summary_read','1718-07-26到New Providence并接管港堡'),
('N53','University of New Brunswick','Bermuda Act for extirpating free Black and Indigenous persons','https://slaveryandfreedomlaws.lib.unb.ca/laws/bermuda-1730-0','primary_law_metadata_and_title_read','1730年限获释黑人和原住民不得停留超过六个月的法案；全文未读'),
('N54','University of New Brunswick','Bermuda Act for regulating Negroes and slaves','https://slaveryandfreedomlaws.lib.unb.ca/laws/bermuda-1730','primary_law_metadata_and_title_read','1730年奴役者审判处罚法规，书籍页94-97；未复刻全文'),
('N55','University of Prince Edward Island Tku Atlasma’lit Archive','Mi’kmaq land rights petition CO217 vol9 p116','https://upei.cairnrepo.org/islandora/object/12674','primary_petition_catalogue_read','1748-09-23 Mi’kmaq申诉土地是其所有，1749-10-01殖民议会决议；具体原文PDF待比对'),
('N56','Royal Nova Scotia Historical Society / John G Reid','The Three Lives of Edward Cornwallis','https://www.rnshs.ca/wp-content/uploads/2018/02/RNSHS_ThreeLivesEdwardCornwallis_JohnGReid_2013.pdf','academic_pdf_search_and_notes_only','1749-10-07公告、1750-06赏金增加、1752-07-17取消、1756-05-14重启；PDF未页级截图'),
('N57','Nova Scotia Archives','1749 St John Chebucto Renewal treaty transcript','https://archives.novascotia.ca/mikmaq/archives/?ID=621&Page=201605005&Transcript=1','original_document_transcription_read','1749-09-04 St John地区确认1749-08-15 Chebucto关系，非普遍让地'),
('N58','Parks Canada','Bloody Creek National Historic Site','https://parks.canada.ca/lhn-nhs/ns/bloodycreek/culture','official_site_history_read','1711-06-10旧历(现历6月21日)安纳波利斯一带冲突'),
('N59','Newfoundland Heritage Memorial University','Palliser Act 1775','https://www.heritage.nl.ca/lawfoundation/articles/doc4_1775palliser.html','primary_law_transcription_read','1775年赏金渔业法、1776-01-01开始相关奖补；限定渔业法规不等于全部岛控'),
('N60','US Department of State Office of Historian','Proclamation Line of 1763','https://history.state.gov/milestones/1750-1775/proclamation-line-1763','official_diplomatic_history_read','Pontiac外交反抗及1763公告执行不足'),
('N61','Mackinac State Historic Parks','Colonial Michilimackinac timeline','https://www.mackinacparks.com/explore/history/colonial-michilimackinac-history/','state_historic_site_read','1763 Ojibwa夺堡、1764返交英军；精确地点现代城堡遗址待坐标核'),
('N62','Cambridge UP / Cambridge journal Itinerario','Considering Him Not as a Prisoner British Saint-Domingue','https://www.cambridge.org/core/journals/itinerario/article/considering-him-not-as-a-prisoner-but-as-a-refugee-the-categorisation-of-french-refugees-in-jamaica-during-the-time-of-the-haitian-revolution-and-the-revolutionary-wars/352FDE5E8A34AAD90DBCB71EAC5FF6D5','peer_reviewed_fulltext_read','1793占圣多明各西南、1798撤离、殖民难民迁往牙买加'),
('N63','University of Pennsylvania / Pennsylvania historical research','Walking Purchase Haverford archive reference','https://findingaids.library.upenn.edu/records/HAVERFORD_HC.MC.950.175','archive_catalogue_only','1735—1738账册可读性待核，未作地块界线'),
('N64','University of South Carolina / Encyclopedia','Yamassee War by Morris','https://www.scencyclopedia.org/sce/entries/yamassee-war/','university_scholarly_history_read','1715-04-15 Pocotaligo战事和1716印第安贸易改制'),
('N65','Jamaica Information Service','Famous Maroons','https://jis.gov.jm/information/get-the-facts/famous-maroons/','national_agency_history_read','Nanny、Quao和Cudjoe的各自军事行动'),
]:
 SOURCES[k]={'id':k,'author_or_institution':org,'title':t,'url':url,'type':level,'actually_read_scope':fact,'manuscript_inspected':False,'read_scope_note':'原文、摘要、目录的读取深度逐项标识，不得混淆。'}

# Each line: date|topic codes|short title|actors|historic place|documented conduct|source ids|modern reference point key
# NOTE: spans marked YYYY/YYYY are NOT treated as a distinct annually occurring action.
EVENT_LINES='''
1700|A03|皇家非洲公司专营被打破后的私商准入制度延续|英国议会、皇家非洲公司、私营商人|伦敦及西非贸易港|1698法令在十八世纪初的商业竞争条件；1700仅表示本世纪承接观察节点，暂无1700年单一行政行为记录|S82,S02|
1713|A02,A01|《乌得勒支条约》相关Asiento奴役人口供应权转交英国方面|英国政府、南海公司、西班牙王室|欧洲签约及西属加勒比|英国方面取得向西班牙海外殖民地供给被奴役非洲人的特许；是贸易合同而非西属岛屿主权|S02,N12|
1713|A04,A02|南海公司特许把奴役人口运输纳入金融与殖民贸易|南海公司、英国政府|伦敦|贸易特许与跨洋商业融资研究节点；个船、个股东收益须另核|S02,S38|
1749|A04,A01|布里斯托奴役航船商业名录留下贸易调查线索|布里斯托商人、奴役船船主|布里斯托尔|英国国家档案馆披露CO 388/45存1749年船只名单；船名、实际人数暂空等待逐行誊录|S04,S03|
1750|A03,A01|议会通过《扩展及改进非洲贸易法》改组非洲贸易公司|英国议会、非洲贸易商人|伦敦|史密森尼收藏1750年印行22页法令，以Company of Merchants Trading to Africa体系改组并强调种植园人口需求；未逐页核法条|N46,S82|
1730|A05|牙买加马龙抵抗促使殖民战争升级|牙买加殖民政府、山地马龙社区|牙买加山地|历史机构将此年作为第一次马龙战争阶段起点，实际冲突早于此年|S02,N02|
1734|A05|英殖民部队攻占Nanny Town但未终结马龙抵抗|殖民军、Nanny及Windward马龙人|Nanny Town|牙买加国家图书馆记1734殖民军袭击并取据点；原址现代精确位置待核|N02,N03|
1739-03-01|A05|Cudjoe与英国殖民当局缔结Leeward Maroon和约|Cudjoe、牙买加殖民政府|牙买加西部马龙地区|和约承认有关马龙群体自由与地方权利，同时规定追捕逃亡奴役者等条款；不适用于所有马龙社区|N02,S02|
1739-12-23|A05|Quao代表Windward Maroon签署独立条约|Quao、牙买加殖民当局|牙买加东部马龙地区|国家图书馆称Quao另行缔约；并存Nanny反对和约的叙述，需以原件与口述史再核|N02,N03|
1760-04|A07|牙买加St Mary地区被奴役者发动Tacky起义|Tacky及被奴役反抗者、种植园政府|St Mary Parish|1760年4月起奴役者有组织袭击殖民剥削秩序，后蔓延，英殖民军与民兵镇压|N04,N05,S02|
1760-05-26|A07|Mesopotamia附近传教士记录起义情势|当地被奴役者、Moravian传教站人员|Mesopotamia plantation地区|一份传教士书信记录附近发生持续反抗及民兵动员；为当事人一方的偏向记载|N05,N04|
1772|A08|英格兰Somerset诉讼限制强迫把被奴役者送往殖民地|James Somerset、Mansfield法官、奴役人|伦敦|判决核心是英格兰未有明确法律支持可强制拘禁并送出被奴役人；殖民地奴役法律并未因此集体废止|S02,N13|
1781|A09,A20|Zong船上被奴役非洲人遭船员抛海杀害|Zong船长及船员、被奴役非洲人|西非至牙买加航次上的不确海域|伦敦博物馆叙述约130/133人遭分批杀害；具体船位和遇害分母存在口径冲突|S05,S03|
1783-03|A09|宗号船主与保险商在伦敦诉讼理赔|船主、保险商、英国民事法院|伦敦Guildhall|当时关注保险责任而非以谋杀审理；首次判决与上诉须分开|S05,S03|
1787|A10|英国废除奴隶贸易运动形成组织化议会游说|伦敦废奴委员会、英国民间活动者|伦敦|组织请愿和联络Wilberforce等议员，奴役船运仍继续|N07,S02|
1788|A10,A20|英国议会审查奴役船贸易及实施载运规制|英国议会、奴役船船主|伦敦|议会启动调查并通过Dolben载运管理法规；限制船员/人数制度不等于终止奴役贸易|N07,S02|
1789|A10|Wilberforce在下院进行废奴贸易动议宣传|William Wilberforce、英国议会|伦敦威斯敏斯特|议会委员会讨论延续、1789发表重点演说；未成功禁运|N07,S02|
1792|A10|议会废奴辩论仍未结束英国奴隶贸易|Wilberforce及下院议员|伦敦威斯敏斯特|议会已正式高度关注，但贸易继续，详细表决票数待原议事录核实|N07,S02|
1795|A11|第二次牙买加马龙战争爆发|Trelawny Town马龙人、牙买加殖民军|Trelawny Town/Cockpit Country|西部马龙自治与当局矛盾升级，英国殖民军动员；马龙人主动防卫|S25,N15|
1796|A11|牙买加殖民军结束战事后决定放逐Trelawny社区|殖民政府、Trelawny马龙人|牙买加西部|战事后惩罚性集体驱逐反映自治条约地位遭剥夺|S25,N15|
1796-04|A12|超过500名Trelawny马龙人被强制运离牙买加|牙买加殖民政府、被驱逐马龙家庭|Trelawny Town、牙买加离港地点未核|Parks Canada记约150户500余人被运送，家族整体遭流放；起运港和船队顺序待核|N15,S25|
1796-07|A12|马龙流亡船队抵达新斯科舍后被征调筑堡|殖民当局、马龙流亡家庭|Halifax Citadel一带|抵达后部分马龙人被要求修建哈利法克斯工事，后在Preston从事低薪劳动|N15,S25|halifax
1796|A12|Trelawny马龙群体向英方抗议劳动及定居安排|被流放的马龙领导人与家庭、英国殖民当局|Preston Township|社区采取拒绝劳动和请愿寻求离开的策略，部分人士另迁Boydville|N15,S25|
1795-03-02|A13|Julien Fédon起义攻占Gouyave及La Baye|Julien Fédon、自由有色人、被奴役起义者、英属Grenada当局|Gouyave、La Baye (Grenada)|反抗队伍攻取两处港镇并依托Belvidere山区；军事真实控制边界待核|S24,N16|
1795-07|A13,A17|殖民政府把约400名非洲裔武装编为Loyal Black Rangers|英属Grenada殖民军政府、非洲裔战士|St George's Grenada|研究论述1795年7月招募约400人，身份包括被奴役者，未普遍授予自由|N17,S24|
1796|A13|英国殖民军与皇家海军合力镇压Fédon起义|英国殖民军、皇家海军、起义联盟|Grenada沿海与山区|英军依赖海上阻断和镇压重夺殖民统治；人数和具体山地路线另核|S24,N17|
1772|A14|英国对圣文森特Black Caribs领地发起军事远征|英国军事政府、Garifuna/Black Carib政治群体|圣文森特|源于英国扩殖要求的军事行动，英国社会也对战争正当性产生批评；非岛内所有原住民统一立场|S54,S59|
1773|A14|第一次Carib战争进入谈判与协议阶段|英国殖民官员、圣文森特Garifuna领袖|圣文森特|战争后双方就居住、土地与政治关系达成谈判；具体签约日、边界待查条约原件|S54,S59|
1795|A15|圣文森特Garifuna对英国统治再次进行武装抵抗|Garifuna领袖、法国共和军盟友、英属殖民军|圣文森特|第二次Carib战争与邻近法英战争联动，抵抗者捍卫土地及自治|S24,N18|
1796|A15,A16|第二次Carib战争后英方拘押并决定驱逐Garifuna群体|英国殖民军、Garifuna社区|圣文森特至Baliceaux|战后大规模流放，必须另核每批被拘捕者与在Baliceaux死亡人数|S24,N18,N50|
1797-04-12|A16|Garifuna群体被英方运抵Roatán|英国远征及运输方、Garifuna流亡家庭|Roatán岛|Garifuna Nation记当天约2500人抵达，为族群记忆所述人数；运输名册与死亡差额待交叉|N50,S24|
1795|A17|英国在西印度群岛组建黑人正规军团|英国War Office、West India Regiments成员|英国加勒比殖民地|1795年第一批军团成立，军队从殖民地庄园和奴隶船购买被奴役男子补充，分年度人数不详|S41,N19|
1793|A18|英国军队介入法属圣多明各革命战争|英国军政当局、法属殖民保王派、圣多明各反抗军|Saint-Domingue南部、西部|英国应保王派请求占领法属殖民地若干地区；对奴役劳动的维持和复辟目的须逐地核账|N62,N20|
1794|A18|法国革命政府确认殖民地废奴与英方占区形成制度冲突|法国国民公会、英军、圣多明各革命军|圣多明各/法国|法国废奴命令与英国军事干预并存，前者不可误记为英国推动的解放|N20,N62|
1798|A18|英国军队结束对圣多明各占领并撤离|英国军队、Toussaint Louverture等革命政权力量|Saint-Domingue|英国撤军与革命一方谈判并存，具体条款和撤离港口待逐案核实|N62,N20|
1763|A19|七年战争后英国获得格林纳达、圣文森特等岛声索|英国、法国及岛上原住民族|Grenada、St Vincent、Dominica、Tobago|英法条约与英国殖民法主张变化；不可据条约直接宣称各岛原住民土地完全实控|N12,S56|
1779|A19|格林纳达战争期间重新被法国夺取|法国军事当局、英国殖民军|Grenada|1779的战争转手是殖民权力变更；不能断言种植园所有权瞬时同步转移|N16,S56|
1783|A19|和平条约后格林纳达重新归英国殖民管理|英国、法国、殖民种植园主|Grenada|条约恢复英国声索，岛内不同群体的法权与土地关系尚待分别核|N16,S56|
1736|A21|安提瓜当局揭发所谓Prince Klaas起义阴谋并大规模审判|Prince Klaas/Kwaku Takyi、被奴役者、殖民法庭|St John's Antigua|当局声称有炸药及夺城计划，但实物证据不充分，供词是否受胁迫引学界争议|S84|
1736|A21|安提瓜殖民法庭处罚、处死数十名被奴役者|安提瓜殖民法庭、被判处奴役者|Antigua|Smithsonian史学综述记132人定罪与88人被处决的口径；独立法庭清册仍待核|S84|
1718-07-26|A22|Woodes Rogers接管Nassau并执行国王赦盗政策|Woodes Rogers、皇家海军、英属巴哈马殖民者及海盗|Nassau, New Providence|王室总督率船兵进入Nassau、接管堡垒，海盗团体的接受/逃离存在个体差异|N52,N51|
1729|A22|巴哈马王室总督Woodes Rogers推动殖民议会选举|Woodes Rogers及殖民选民|Nassau|巴哈马国家档案馆总督史记录1729年议会形成；原议会记录待核|N51,N52|
1730|A22|百慕大议会通过限制自由黑人与原住民居留的法律|百慕大殖民议会、非洲裔与原住民居民|Bermuda|殖民法令对获得释放者的居留作期限限制，法令已印行；需核实际驱逐人数|N53,N54|
1730|A22|百慕大议会强化对被奴役者刑事案件的处罚规定|百慕大殖民议会、被奴役居民|Bermuda|1730年《进一步监管黑奴和其他奴隶法》法条有原本目录，逐条与实施卷待核|N54,N53|
1783|A22|美国独立战争后效忠英王殖民者迁入巴哈马并携奴役人口|黑人被奴役者、英王效忠派及岛屿殖民当局|Bahamas/Eleuthera|巴哈马官方历史记效忠派携奴役人口到Eleuthera；运输总量与各岛流向未知|N52,S56|
'''
EVENT_LINES+='''
1704|C02|新英格兰殖民武装再次袭击Beaubassin|新英格兰殖民民兵、阿卡迪亚居民|Beaubassin/Chignecto|加拿大公园局官方年表记1704年战争袭击，尚须查损毁与抵抗详细档案|S11|
1710-10-16|C01|Francis Nicholson军队迫使法国Port-Royal驻军投降|英军、英属新英格兰军、法国总督Subercase|Port-Royal/Annapolis Royal|投降对象为堡垒及其附近约五公里区域；是局部军占，不是整个Mi'kma'ki领土|S44,N23,N24|fort_anne
1711-06-10|C01,C03|Bloody Creek冲突反映英国堡垒占据尚受地方反抗|阿卡迪亚居民、原住民盟友、英属驻军|Bloody Creek/Annapolis Royal附近|公园局注明1711-06-10旧历与当今6月21日相对应；不凭该地名推定全区军界|N58,S44|
1713|C02,C01|《乌得勒支条约》承认英国阿卡迪亚声索但边界含混|英国与法国王室、米克马克政治共同体|Acadia/Chignecto|英国取得法王关于阿卡迪亚的条约割让措辞，Mi'kmaq与其他原住民族未被征询也未随之让地|S11,N24,N25|
1722|C03|Mi'kmaw武装夺取Chignecto外海英属渔船|Mi'kmaq船员、英殖民商船船员|Chignecto coastal waters|加拿大公园局明确记载该年事件；没有船只坐标及人名|S11,N25|
1725-12|C03|Wabanaki代表与马萨诸塞总督William Dummer在波士顿议和|Wabanaki代表、William Dummer、殖民当局|Boston|本次议和为1726年安纳波利斯核准条款的前史；代表权和不同族群政治主张须区分|N25,S44|
1726-06-04|C03|Mi’kmaw、Wəlastəkokewiyik等领袖在Annapolis Royal核准和平友好条约|Mi’kmaq、Wəlastəkokewiyik、Peskətəmohkatewey领导者及英王代表|Fort Anne/Annapolis Royal|Parks Canada明确载64名领袖会晤，条约强调共存、捕猎渔业生活，不是向英国全部割让土地|N25,S44|fort_anne
1728|C03|更多Wabanaki领袖续签及确认1726协议|原住民族政治领袖、英属官员|Maritime Northeast|后续确认并非所有领袖一次性签约，也不等于完全放弃抵抗|N25,S44|
1730|C02,C03|阿卡迪亚居民争取附免于对法及Mi’kmaq作战条件的效忠誓言|阿卡迪亚居民、Nova Scotia殖民当局|Grand-Pré/Annapolis地区|殖民政府曾承认附带不参战条件，后对有效性产生冲突；本节点记录誓约制度|S07,S11|fort_anne
1747|C03,C07|Grand-Pré战斗中法方及原住民联军袭击英国驻兵|法军、当地原住民盟友、英国和新英格兰驻军|Grand-Pré|英属驻兵在阿卡迪亚村镇附近遭攻击，殖民战争联盟性质须分别核|S07,N28|grand_pre
1748-09-23|C05|Mi'kmaq领导者请愿声明自身土地所有权|Nalhukonneich及Port Toulouse Mi'kmaq请愿者、殖民官员|Antigonish、Port Toulouse及政府文书送达地|UPEI档案登记有原请愿及CO217/9第116页；请愿地图位置不能等于英方声索边界|N55,N25|
1749-06-21|C04|英殖民政府在Kjipuktuk建Halifax军港城市|英国总督Edward Cornwallis、殖民者、当地Mi'kmaq|Halifax/Kjipuktuk|英方移民和军建逐步扩展，传统Mi’kmaw土地政治主张持续|S42,S11|halifax
1749-09-04|C03,C05|St John原住民首领正式确认此前Chebucto条约条款|Wolastoqiyik等地方领导、殖民议会代表|Saint John River|Nova Scotia档案馆原文转录载9月4日确认8月15日签订文本，非所有部族签约|N57,N25|
1749-10-01|C05|Nova Scotia殖民议会将Mi'kmaq定位为敌对叛乱者|Edward Cornwallis及殖民议会、Mi'kmaq|Halifax|存在同期Mi'kmaq土地权利请愿；殖民议会在10月1日将抵抗表述为对王权叛乱，具体赏金文本另核|N55,N56|halifax
1749-10|C05|Edward Cornwallis殖民当局授权对Mi'kmaq人实施头皮赏金|Edward Cornwallis、英属Nova Scotia殖民议会、Mi'kmaq|Halifax/Nova Scotia|研究资料定位1749年10月公告与10 guinea悬赏；公告签发日存在7日、14日、20日旧历等不同版本，暂只精确至月份|N56,N55|halifax
1750-06|C05|殖民当局扩大针对Mi'kmaq的赏金金额|Cornwallis殖民官员、殖民武装|Halifax/Nova Scotia|学术二手校勘记赏金提高，货币单位与旧历日期应回查CO217/9及议会纪要|N56,N55|halifax
1752-07-17|C05|殖民议会暂停针对Mi'kmaq的赏金政策|Nova Scotia殖民议会、Mi'kmaq外交代表|Halifax|John G Reid校勘指赏金于17 July 1752取消，后1756再度开启；原卷未读|N56,N25|halifax
1750|C04,C06|英军在Chignecto推进并建Fort Lawrence|英国殖民军、法军、Acadian居民|Beaubassin/Fort Lawrence|英军进逼致地区居民迁移；部分焚村行为应判为撤退法军及盟友所为，不能误归英军|S11,N27|beaubassin
1750-06|C06|英国部队修筑Fort Edward加强Pisiquid交通与驻军|英国军队及殖民官员、地方Acadian与Mi'kmaq|Fort Edward/Windsor|筑堡目的涵盖Halifax到Annapolis陆路交通及治理Pisiquid，不能推整个村镇实控地界|S10|fort_edward
1751|C06,C07|法国在Chignecto修建Fort Beauséjour对抗英国增堡|法军、Acadian居民、部分Mi'kmaq及其他群体|Fort Beauséjour|法国据点扩建是英法对峙的反向力量，不得误写成英国新建据点|S11,N27|beausejour
1755-06-02|C07,C11|Robert Monckton率英军与新英格兰兵登Chignecto|Robert Monckton、英国正规军、新英格兰殖民军|Chignecto Isthmus|公园局记载270正规军加约2000新英格兰兵登陆，为作战投入兵力而非实际死亡人数|N27,S08|
1755-06-16|C07,C11|法军向英国殖民军交出Fort Beauséjour|Robert Monckton、法国指挥官de Vergor|Fort Beauséjour/Fort Cumberland|英方获得这座具体堡垒控制，非周围所有原住民政区真实占领；公园局记三名Acadian守军战死|N27,S08|beausejour
1755-07-28|C07|新斯科舍Halifax议会决定驱逐阿卡迪亚居民|Charles Lawrence、Nova Scotia Council、Acadian居民|Halifax|正式强制迁徙政策决议，先后在多个地区执行至1762|S08,S07|halifax
1755-08|C07|Fort Cumberland周围首先拘押并驱逐阿卡迪亚人|英国军队、当地Acadian居民|Fort Cumberland/Beauséjour|Parks Canada记Beauséjour地区约1100人被驱逐，约2000人逃往别处；为不同处理类别|S08,N27|beausejour
1755-09|C07,C08|John Winslow在Grand-Pré组织拘押和驱逐Les Mines家庭|John Winslow、新英格兰驻军、Acadian家庭|Grand-Pré/Les Mines|加拿大公园局记整个Les Mines地区约2200人被驱逐，不等于国家历史纪念堂处关押了2200人|S07,S08|grand_pre
1755-10|C07,C09|Fort Edward成为Pisiquid约1200人驱逐中心|英国军队及Nova Scotia官员、Acadian居民|Fort Edward/Pisiquid|约1200为整个Pisiquid周边村庄人口来源数，堡垒只作现代位置参照|S10,S08|fort_edward
1755-12|C07|Annapolis Royal区域居民被英国当局强制运离|英国驻军、Acadian家庭|Annapolis Royal/Fort Anne|已有公园局游客指南候审记该地区1664名；人数与同一时期其他区口径不可重复合计|S70,S44|fort_anne
1755|C07|Joseph Broussard与Acadian反抗者及Mi'kmaq继续对英作战|Joseph Broussard、Acadian游击队、Mi'kmaq及英军|Fort Cumberland附近|公园局人物传记记Broussard参与1755军事抵抗、后转私掠船活动|N27,S08|
1758|C10,C07|英军攻占Île Saint-Jean后组织强制驱逐居民|英国驻军、Acadian家庭、地方Mi’kmaq|Skmaqn/Port-la-Joye、Île Saint-Jean|公园局记大批Acadian居民被迫送法国，海上沉船与疾病致死情况需与逐船名录核对|S09,S08|skmaqn
1759-01|C07|Bloody Bridge附近Acadian抵抗英国驻军|Acadian反抗者、英军|Fort Cumberland附近的Bloody Bridge|公园局记1759年1月战斗，不用现代城堡点代替冲突现场GPS|S08|
1761|C07|英军抓获Miramichi流亡中的部分Acadian平民|英属军队、流亡Acadian家庭|Miramichi River/Restigouche地区|Parks Canada记一次镇压后约200妇孺男子被捕，并押至多处堡垒；非全区逃亡总数|S08|
1764|C07|Fort Cumberland附近仍有约73户388名Acadian住临时棚屋|Acadian流亡家庭、殖民当局|Fort Cumberland|这是一处居民/家庭口径快照，依靠劳役换口粮，并非全部被拘押人口；属于C07后果续接超窗|S08|beausejour
1764|C07,C08|英国允许Acadian返回但原有农地多已重新分配|英国殖民官员、Acadian返乡者、新英格兰移民|Nova Scotia/Grand-Pré|返乡许可与回原庄园产权不同，公园局说明旧农地已由新英格兰移民占用|S07,S08|grand_pre
1754|C11|俄亥俄流域英法战争扩大原住民同盟竞争|英国及英属殖民军、法国军、多个原住民族|Ohio Valley|英法争夺贸易军事据点，本地原住民各有外交决策，不能视为两国附庸|N28,N30|
1758-07-26|C11|英国军队迫使Louisbourg堡垒投降|英国海陆军、法国驻军|Louisbourg, Île Royale|七周围城后法国军事堡垒移交，不能据此涂满全部现代Cape Breton岛|N28,N29|
1759-09-13|C11|英法军队在魁北克亚伯拉罕平原作战|英国军、法国军、地方原住民盟友|Plains of Abraham/Québec|攻城战地而非主权边界：战争尚未在此日结束|N28,N29|
1759-09-18|C11|魁北克市法国守军向英国军队投降|英国军、法国驻军|Québec city|加拿大公园局特别说明英国并未因此掌握整个新法兰西|N28,N29|
1760-04-28|C11|Sainte-Foy法军获胜迫使英军退至魁北克城墙|法军、英军|Sainte-Foy/Québec|英军城市驻防并未因此自动终结，后续军政控制须逐堡确认|N28,N29|
1760-09-08|C11|法国蒙特利尔驻军签署投降|法国总督Vaudreuil、英国军队、地方原住民盟友|Montréal|是殖民军事移交；原住民族保留本身社会与土地权利|N30,N28|
1763-02-10|C11,C13|《巴黎和约》重新分配英法北美殖民声索|英国、法国、西班牙三国|巴黎签约、加拿大/佛罗里达|条约主权声索与各原住民族实际领土、堡垒实控继续分开|N30,S34|
1763|C12|Odawa等原住民政治联盟围攻Detroit的英军据点|Pontiac/Odawa及区域原住民族、英军|Fort Detroit|原住民反对英国贸易驻堡政策并作军事组织；各部族独立行动不等于单一中央政权|N60,N30|
1763|C12|Ojibwa勇士夺取Michilimackinac英军堡垒|Ojibwa/Ojibwe领导与战士、英属守军|Fort Michilimackinac|州历史公园核实该年取堡，1764返交；不以某现代州界推全域实控|N61,N60|
1763|C12|原住民族对Fort Pitt等英堡实施围困与袭击|多族原住民联盟、英军|Fort Pitt|英方Fort Pitt和Detroit仍坚守，其他若干堡垒失守；微生物战资料另查原始信件|N60,S32|
1764|C12|Ojibwa将Michilimackinac堡返交英国|Ojibwa政治代表、英军|Michilimackinac|堡的军事控制转手与原住民在周边土地仍有政治权利必须区分|N61,N60|
1763-10-07|C13,C12|英王乔治三世公告限制殖民定居越过阿巴拉契亚分界线|英王政府、殖民定居者、原住民族|北美阿巴拉契亚分界|公告作为法律主张调整，边界线精确几何要参历史原图；施行不力|N31,N60|
1763-12-14|C14|Paxton定居者武装袭击Conestoga村并杀六名居民|Paxton Boys定居者民兵、Conestoga/Susquehannock居民|Conestoga Manor Lancaster|当代Franklin文书载六人遇害及房屋焚毁；执行者为殖民定居者团伙而非英军|N49,S39|
1763-12-27|C14|Paxton Boys在Lancaster拘留所杀害14名避难Conestoga|Paxton Boys、Conestoga居民、未能保护居民的地方官员|Lancaster Workhouse|十四名原住民被集中保护却遭攻入杀害；区分执行凶手和殖民政府失职|N49,S39|
1765|C15|英国议会颁布Stamp Act在北美殖民地征收印花税|英国议会、北美殖民税务官、抗议者|伦敦立法、北美各殖民地|该征税争议和殖民者抗议是独立政治事件；与原住民被剥地和被奴役者处境分开叙述|S34,N33|
1770-03-05|C16|英军在波士顿与平民冲突中开枪造成死亡|英国驻军、波士顿居民|Boston King Street|波士顿惨案为英军射击事件，确切死亡与庭审证词须见NPS档案专题|S33,S34|
1775-04-19|C17|英军与马萨诸塞殖民军在Lexington和Concord交战|英军、殖民民兵|Lexington/Concord|战争爆发军事节点，单次交战不应创建北美英方占领多边形|S34,N34|
1775-11-07|C17|Virginia王室总督Dunmore承诺逃向英军的叛乱者奴役人口自由|Lord Dunmore、被奴役者、皇家军队|Virginia/Norfolk|公告以参与英军为条件，许多非洲裔利用政策自主逃离，未覆盖所有殖民地被奴役者|N34,N35|
1775-12-09|C17|英属Loyalist力量在Great Bridge作战失败|英国军、Dunmore忠王军、殖民反英军|Great Bridge, Virginia|败战削弱王室对弗吉尼亚的实地军控，军队变化不等于奴役制立即结束|N34,S34|
1776|C17|美国殖民地宣布独立并继续与英军作战|独立派大陆会议、英王政府、原住民多方|Philadelphia及13殖民地|政治独立宣告、英军驻地、各原住民族联盟和奴役法律必须按地分列|S34,N35|
1781|C17|Yorktown战役英军主力陷入围困并投降|Cornwallis率英军、美法联军、当地居民|Yorktown Virginia|军事战败与1783条约承认独立日期不同|S34,N34|
1783|C17,C18|英军撤离纽约时运走并登记一批求自由非洲裔|英国军事撤离机构、Black Loyalists、原奴役主|New York Harbor|1783 Book of Negroes名册包含不同身份类型；登记册非全体非洲裔黑人估计分母|N36,S35|
1783|C18|数千名Black Loyalists抵达新斯科舍|求自由的黑人效忠派、英殖民土地办公室|Birchtown、Shelburne、Halifax|加拿大移民博物馆记超过约3000人抵达、许多承受土地不平等及廉价劳动|S35,N36|
1785|C18|黑人效忠派社区创办自己的教会学校并请求土地|Black Loyalist居民、Nova Scotia政府|Birchtown/Preston一带|Pier 21记到1785年前后多数社区已建立独立教会且部分设学校；授地难题延续|S35,N36|
1792|C19,C18|约1200名黑人效忠派从新斯科舍迁往Sierra Leone|Black Loyalist社区领袖、塞拉利昂公司|Halifax至Freetown航路未核|受歧视与授地失信影响，自行选择迁居；航线仅文字描述，不能画单船GPS航线|S35,S36,N36|
1768|C20|英国纽芬兰海军总督委John Cartwright到Exploits调查Beothuk|Hugh Palliser、John Cartwright、Beothuk群体|Exploits River, Newfoundland|Cartwright发现住居迹象但未与Beothuk人接触；原住民并非已加入英国管辖体系|N37,N38|
1784|C20|George Cartwright建议在Notre Dame Bay建立Beothuk保留地|George Cartwright及英国行政官、Beothuk|Notre Dame Bay|研究记录此保护倡议与猎捕矛盾；尚无证明实际建成边界|N37,N38|
1792|C20|纽芬兰Chief Justice Reeves请求英国当局保护Beothuk|John Reeves、伦敦行政当局、Beothuk|纽芬兰和伦敦|法官请愿与执行成效不同，失去生计资源持续|N37,N38|
1797|C20|英国纽芬兰总督Waldegrave发出禁止袭击Beothuk公告|William Waldegrave、定居猎人、Beothuk|Newfoundland|行政禁令与移民侵占矛盾并存，缺执法卷不计算实际获救人次|N37,N38|
1707|C21|南卡罗来纳政府设置Indian Commissioners试图规制掳奴贸易|殖民政府、Thomas Nairne、Yamasee及其他部族|Charles Town, Carolina|商业债务、掳奴和鹿皮贸易仍造成原住民土地压力|S73,N39|
1715-04-14|C21|Thomas Nairne等与Yamasee在Pocotaligo会谈|Thomas Nairne、Yamasee领导者、殖民商人|Pocotaligo Town|会谈发生在战前一天，Yamasee领导者目标不能被英国商人叙事完全替代|S73,N39|
1715-04-15|C21|Yamasee及盟友起兵攻打Carolina贸易商和定居点|Yamasee与不同原住民族战士、殖民商人、殖民政府|Pocotaligo、Port Royal以西|大学百科与北卡州史均记4月15日起义，贸易债务/掳奴与越界定居是关键背景|S73,N39|
1716|C21|South Carolina政府加强对印第安贸易的直接规制|殖民政府、不同原住民族商人和居民|Charles Town|战后州政府进一步直接监管印第安贸易；各部族失地范围仍需地契|S73,N39|
1718|C21|Yamasee战争阶段结束而原住民地权冲突持续|Yamasee、Creek、Cherokee等及殖民政府|Carolinas/Georgia borderlands|1715—1718为学术战争分期，不是1718全部土地产权和主权自动转移|S73,N39|
1705-10|C22|Virginia殖民议会通过奴役与仆役综合法|Virginia General Assembly、被奴役非洲裔与原住民|Williamsburg/Virginia|法律汇编把族裔身份、非基督教出生、世袭奴役、惩罚与主人权力制度化，须逐条分开|N40,N41,S74|
1748|C22|Virginia殖民地汇编修订奴役相关法律|Virginia殖民议会、奴役者与被奴役者|Virginia|大学资料提供1748制度索引，具体条款尚待逐条照录及与1705差异核查|S74,N40|
1712-04-06|C23|黑人及少数原住民在纽约Maiden Lane地区起义|被奴役非洲裔和原住民、殖民民兵|Maiden Lane, New York City|哥大历史地图与PBS确认6日夜起义，并对参与者数目有口径差异|N47,N48,S83|
1712|C23|纽约殖民政府大规模审讯并处决被奴役起义者|纽约殖民法院、被控非洲裔、自由居民|New York City|哥大研究记43人受审、25定罪、20绞刑3火刑；其他报告称21被处死，数字须分开|N47,N48,S83|
1712|C23|殖民议会进一步收紧纽约奴役与解放规定|New York殖民议会、被奴役与自由黑人|New York|作为起义后法律后果记录，具体立法条文及生效日待原法索引|N47,S83|
1741-03-08|C24|New York Fort George火灾引发所谓奴役阴谋案恐慌|纽约殖民居民、被奴役者、皇家官员|Fort George New York|纽约法院史学会记3月8日起火、后有多起火灾；是否存在统一阴谋高度争议|S75|
1741-04-21|C24|法院召开大陪审团调查所谓纽约奴役纵火阴谋|Daniel Horsmanden、Mary Burton及受指控者|New York City Hall|关键证词来自被威胁及奖赏诱导的证人，刑事定罪无法直接作阴谋事实证据|S75|
1741-05-11|C24|New York法院展开大规模奴役阴谋指控审判|殖民法院、Daniel Horsmanden、被奴役黑人及白人被告|New York City Hall|机构记约200人被审、30人被判死及70人强制发配加勒比；角色须一一核|S75|
1735|C25|宾州殖民家族步行购买相关文书开始出现|Penn家族、土地测量与Lenape族领导者|Bucks County Pennsylvania|Haverford馆藏有1735—1738账册，未核页不能虚构每份签署正文|S76,S87|
1737|C25|宾州殖民当局使用Walking Purchase扩大自称地权|Thomas Penn及Penn家族、Lenape及步行者|Bucks County/Delaware Valley|Penn家族凭争议协议与竞走/测量扩大土地声索，Lenape抗议；地图边线待同代地契复核|S76,S77,S86|
1758|C25|Easton外交后Lenape土地纠纷进入另一议约阶段|Lenape政治代表、宾州殖民官员|Easton Pennsylvania|诉求是承认土地与政治权利；此前1737所谓步行购买的合法性并未自动消失|S86,S87|
1700-03-25|C26|1699 Newfoundland渔业贸易法部分渔季规定开始适用|英国议会、季节渔业船长、岛上原住民|Newfoundland渔业港口|商业船到港日期影响fishing admiral选定及渔场使用，不能把英国海上法律赋权当岛内原住民土地已让渡|S79,N44|
1729|C26|纽芬兰出现正式海军总督与行政司法调整|Osborn海军总督、捕鱼船长、殖民法庭|St John's/Newfoundland|王室行政变化不意味着1729前所有渔业完全无规范或全岛同时实控|S80,N44|
1713|C27|乌得勒支后哈德孙湾公司部分贸易据点归英国控制|英国、法国、Hudson's Bay Company、当地Cree/Dene|Hudson Bay河口堡垒|双方条约涉及堡垒返还，具体每堡实际交接日及皮毛贸易主动权需分别查|S81,S85|
1715|C27|Dene女性外交家Thanadelthur协助Dene和Cree达成谈判|Thanadelthur、Dene与Cree领袖、HBC官员|Hudson Bay西北部|原住民妇女主导外交与贸易协调，不能写作公司自行征服两族|S81,S85|
1754|C27|Anthony Henday在Cree向导帮助下赴内陆|Anthony Henday、Cree向导及政治共同体、HBC|加拿大草原/贸易通路未核|原住民网络提供必要向导和经济选择，非英国军政占领|S81,S85|
1770|C27|Dene领袖Matonabbee引导Samuel Hearne向北旅行|Matonabbee、Samuel Hearne、原住民同伴|Hudson Bay至Coppermine方向|1770—1772原住民主导路线谈判，逐站航迹需日记与测绘核对|S81,S85|
1774|C27|Hudson's Bay Company设立Cumberland House内陆据点|HBC、Samuel Hearne、当地Cree及其他原住民族商贸者|Cumberland House/Saskatchewan River|Manitoba历史会记1774年为公司第一个内陆交易据点，与掌握整片流域政治主权不同|S81,S85|
'''
# 2026-11-08 supplementary primary-law findings; transcription is not a scanned-manuscript examination.
for k,org,title,url,level,scope in [
 ('N66','Kit Candlin / Slavery & Abolition','A successful counterinsurgency? Enslaved and loyal black rangers in Grenada','https://www.tandfonline.com/doi/full/10.1080/0144039X.2024.2337727','peer_reviewed_article_search_and_abstract','1795年7月400人Loyal Black Rangers的背景；待核正文'),
 ('N67','Bahamas Ministry of Tourism','Our History: Bahamas','https://www.bahamas.com/our-history','national_tourism_institutional_history','1783后效忠派及其奴役人口进入巴哈马；人数、各岛轨迹未核'),
 ('N68','UK Parliament','Key dates in Britain’s slave trade','https://www.parliament.uk/about/living-heritage/transformingsociety/tradeindustry/slavetrade/key-dates/','parliamentary_timeline_read','1788年Dolben船运限制法与1789议会辩论'),
 ('N69','University of New Brunswick','Barbados: An Act to secure peaceable possession of Negroes and other Slaves','https://slaveryandfreedomlaws.lib.unb.ca/laws/barbados-1709','historical_legislation_transcription_read','1709-06-24巴巴多斯奴役人口财产占有法，具体页188–201'),
 ('N70','University of New Brunswick','Barbados: An Act for the better governing of Negroes','https://slaveryandfreedomlaws.lib.unb.ca/laws/barbados-1733','historical_legislation_transcription_read','1733巴巴多斯限制奴役者贩售、议会强化1668条款'),
 ('N71','University of New Brunswick','Jamaica: Act to remedy irregular Assemblies of Slaves','https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1760','historical_legislation_transcription_read','1760-12-18严格限奴役者旅行、鼓/宗教、强化Obeah罪名和自由有色者身份证'),
 ('N72','University of New Brunswick','Jamaica: An Act to confirm Quao-Bennett Articles','https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1740-0','historical_legislation_transcription_read','1740新法确认Quao条约并付捕逃奖励、安排4名白人驻马龙镇；网页日期1740-01-01为不精确索引'),
 ('N73','University of New Brunswick','Jamaica: Consolidated Act for the Government of Slaves','https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1788','historical_legislation_transcription_read','1788-11-06奴役法典再编，仍保留奴役及惩罚机制'),
 ('S71','Parks Canada','Beaubassin National Historic Site official modern site location','https://parks.canada.ca/lhn-nhs/recherche-search','modern_site_coordinate_from_pr289','Beaubassin参考点，非18世纪村落细节测绘'),
]:
 SOURCES[k]={'id':k,'author_or_institution':org,'title':title,'url':url,'type':level,'actually_read_scope':scope,'manuscript_inspected':False,'read_scope_note':'本轮仅核网页转录或摘要及PR原官方参照，不能冒充在馆亲阅原件。'}
for s in SOURCES.values():
 s['manuscript_inspected']=False
 if s['url'].endswith('TheTransatlanticSlaveEconomyandEngland'):
  s['url']='https://historicengland.org.uk/research/results/reports/8203/TheTransatlanticSlaveEconomyandEnglandsBuiltEnvironmentAResearchAudit'
EVENT_LINES+='''
1709-06-24|A06|巴巴多斯议会保障奴役人口作为所有物的占有权|巴巴多斯殖民议会、奴役种植园主、被奴役人口|Barbados|1709年6月24日法律将被奴役人口视为可争讼占有之财产；法令与劳动实际情形应分账|N69,S38|
1733|A06|巴巴多斯加强限制奴役人口自主交易的殖民法律|巴巴多斯殖民议会、奴役人口|Barbados|1733年法律规定强化对奴役者售卖、交易的行政与惩罚管制；需在各教区实施卷核对|N70,S38|
1740|A06,A05|牙买加议会通过确认Quao条约的法律|牙买加殖民议会、Quao领导的马龙人、Colonel Bennett|Jamaica|1740年立法将1739年Quao谈判条款正式纳入殖民法律并规定捉逃奴隶奖励；法律网页所列1月1日标记日期不精确|N72,N02|
1760-12-18|A06,A07|牙买加议会推出针对反抗及Obeah的惩罚性奴役法规|牙买加副总督、议会、被奴役者与自由有色居民|Jamaica|起义后颁法限制奴役者未经票证旅行、集会、携武和宗教活动；自由黑人等需登记、持自由证并佩标识|N71,S02|
1788-11-06|A06|牙买加重新整合奴役法与审讯惩罚程序|牙买加议会、被奴役人口|Jamaica|所谓提供保护的1788年改革同时继续法定奴役及刑罚机制；不能将法律名称当作已经废奴|N73,S38|
'''
# Correct two reference linkages discovered by comparing document scope.
EVENT_LINES=EVENT_LINES.replace('Loyal Black Rangers|英属Grenada殖民军政府、非洲裔战士|St George\'s Grenada|研究论述1795年7月招募约400人，身份包括被奴役者，未普遍授予自由|N17,S24|', 'Loyal Black Rangers|英属Grenada殖民军政府、非洲裔战士|St George\'s Grenada|研究论述1795年7月招募约400人，身份包括被奴役者，未普遍授予自由|N66,S24|')
EVENT_LINES=EVENT_LINES.replace('到Eleuthera；运输总量与各岛流向未知|N52,S56|','到Eleuthera；运输总量与各岛流向未知|N67,S56|')
# Topic-specific four-part synthetic editorial reading notes. These are hypotheses and
# historically bounded research narratives, NOT new primary evidence.
# code|context/decision|resistance/agency|economic consequences|what primary archive/map work remains
TOPIC_NOTES='''
A01|1698年前后开放私商竞争后，英国旗船和英国港口商人扩大与西非、加勒比之间的强迫人口输送。应把每个航次的船旗、注册港、船主、装船地、抵岸地与贸易年份分开。|被奴役者在押送途中拒食、逃离、夺船和结社，不能只把他们列为货物；未经航海日志确认的个别起义不可给具体年份。|量化“被迫登船”“抵达美洲”“航次数量”和“英国相关港口利润”使用不同分母；SlaveVoyages最后一个25年统计窗含1800年。|逐航次核SlaveVoyages voyage ID、TNA BT/CO商业账、港口关税、航海日志及英国船旗1776—1799严格截取。
A02|1713年英国因欧洲外交而得西班牙殖民市场奴役人口供应特许；南海公司与王室财政权力结合，相关账目和债务转换须按不同期间核。|非洲被掳人口和美洲被奴役者的抵抗与西班牙当地港市的实际接受、拒绝或走私状况应分别研究。|特许合同应与实际船次、人头、税费以及公司股价分开，禁止把1713年获得合同写作西属美洲割地。|检Utrecht原文、South Sea Company minute books、Asiento账簿、Jamaica周转港及公司赔款谈判。
A03|皇家非洲公司1698年失去排他贸易地位后继续贸易，1750年英国议会再度改变西非堡垒财政供养结构；不能当作贸易当年终结。|西非港口王国和商业主体控制当地政治交易条件，奴隶贸易堡垒外围与英国居民的活动区并非英国全境主权。|公司盈利、英国纳税补助、商人奴隶船规模是三本不同的账，须按年度比较。|核1750法案逐条原版、Cape Coast Castle军需账、African Company章程及私人商行账。
A04|伦敦、布里斯托、利物浦在不同年代以资金、造船、保险、回运货物参与奴役贸易，商人关系不能凭城市标签推定。|非洲及加勒比受害者的名字多出现在商业记录空白中，应尝试追查诉讼、奴隶船广告、逃亡档案中的行动。|1749布里斯托名单属于具体馆藏，只有拿到原表才能统计航次数和人数；城镇受益不可替代逐商人的利润账。|CO 388/45逐行抄录，Bristol Port Books、Liverpool customs、保险保单、船龄与资本股权交叉。
A05|牙买加马龙社区由逃亡被奴役者及后裔组织，殖民军持续派兵但无法简单消灭山区自治，1739年签订至少两套政治协议。|Cudjoe、Quao、Nanny有不同选择，和约的逃亡者追捕义务与马龙自由、土地承诺之间存在政治张力。|殖民政府给付、土地、奖励和追逃机制需要按条款核；把马龙领土全涂成英国直辖会抹去自治。|1739/1740条约原卷、逐村划界、Colonel Bennett报告、马龙口述史、Nanny Town位置。
A06|巴巴多斯1661奴役法典的制度框架跨世纪延续，1709与1733的修法及牙买加1760、1788立法强化种族化劳动力产权和管理。|奴役者借市场、宗教活动、集会、逃亡维护自主空间，1760年牙买加法的禁令也表明当局针对已存在的网络。|甘蔗种植与糖品贸易高度依赖奴役劳动；具体产值、庄园利润和病亡率必须对应庄园账或贸易报表。|检巴巴多斯议会Acts逐条及执行账、庄园收支、个人被买卖与反抗裁判、糖进口税单。
A07|1760年牙买加Tacky起义从圣玛丽地区扩散，殖民民兵与正规军采取镇压与报复，年底针对Obeah/集会的法律回应。|组织者、宗教实践者和逃亡者有各自目标；殖民官员称“叛乱”应和被奴役者解放诉求同时呈现。|种植园受损、奴役人口死亡与审判惩罚缺可靠同口径数据；1760法律非事件全部战况。|教区民兵报告、Moravian书信全文、Long 1774原书、全部处决名册和起义点位。
A08|1772年英格兰法院Somerset案限制在英格兰境内无成文依据强制拘押并送离人员的做法。|James Somerset的诉讼与英国黑人社群支持、法律代理工作构成主动行动。|英国本土强制遣返权的法律疑义与加勒比持续买卖奴役人口形成地理法域差异。|Lord Mansfield判决文本及庭审记录、Somerset个人证词、后续船长司法实践。
A09|1781年Zong船员杀害被奴役者并被船主纳入保险索赔逻辑，1783年伦敦发生民事保险争讼。|被害人的个体姓名多不可考，抗议者Olaudah Equiano与Granville Sharp围绕案情传播形成政治行动。|保险理赔、淡水与死亡人数存在明显证据冲突；伦敦博物馆同文出现130与133，统一数应暂留区间。|KB 122/479、海事航海日志、1783各次庭审书记、保险契约、死亡明细及航位。
A10|1787废奴运动组织化，1788出现限载法，1789和1792议会辩论，但18世纪末英国奴隶运输没有停止。|被奴役非洲裔作者的证词、伦敦黑人群体、妇女抵制糖品行动须按确证姓名、文本、场所收录。|反奴运法律与贸易规模并存；不能把一项限载法规标为1790年废奴。|议会Hansard、Committee Evidence、Clarkson和Equiano版本年代、各港同期航次数据库。
A11|1795西部Trelawny马龙人再与牙买加政府武装冲突，1739年条约权利因殖民军事战略受到挑战。|马龙团体自卫、谈判与拒绝不利条件，应列出具体领导者的文献版差异。|战争费用、殖民赔偿与战后社区损失现均无同口径账，不能虚增利益或伤亡。|战役报告、条约文本、战俘名册、殖民法院议事、Cockpit Country村址。
A12|第二次战争后约150户500余名马龙人被惩罚性驱往加拿大，抵达后面对劳动与粮食问题。|Trelawny社区在Preston、Halifax提出请愿与拒工，以集体决定争取下一步迁移。|1796抵加拿大人数与1800迁塞拉利昂数字不同年度、不同范围，不能相加估算损失。|1796抵港船名、Halifax军工工钱、1800 Asia船员名单（作为19世纪后续链接）。
A13|1795—96年Fédon反英起义牵涉自由有色人、被奴役者、法国共和派和英国殖民政府，多主体的土地和公民权诉求并不一致。|起义者控制山地据点且招募被奴役者，英国也组织非洲裔兵员；不能简化成英国白人与单一黑人阵营。|殖民出口、庄园损毁与死亡估数差异极大，7000是研究口径而非已核逐名记录。|Gouyave日期、Belvidere指挥地、乡镇换旗、法殖民卷及死亡统计分母。
A14|1772—73年英国军事远征企图削弱圣文森特Garifuna/Kalinago领地自主，英国本土有人公开批评扩殖动机。|Garifuna首领采取战术抵抗和外交谈判；Black Caribs称谓是殖民文书分类，不可替代族群自称。|英国扩张种植园土地的收益动机与实际交地地契须区别。|1773原条约日期、族群签约人、1772登陆路线、议会调查小册及土地边界。
A15|1795—96第二次Carib战争与英法战争交织，英军寻求击败Garifuna及其盟军，以重分配土地和劳动力。|Garifuna拥有独立政治与军事策略；盟友法国革命力量不应代替其主体地位。|战后地权重组与军事开支未有逐项可靠表，土地面积不宜画实线。|各月战斗、领袖死亡细节、英海军文书及实际占据堡垒。
A16|1796战后英国将Garifuna家庭拘禁Baliceaux并船运Roatán，发生毁灭性的流离与疾病死亡。|被驱逐群体及幸存者把语言与文化带入中美洲，Roatán抵达并不表示任一殖民政府可代表其选择。|Roatán约2500抵达为族群记忆口径，拘禁、发船和上岸人口需分阶段核对。|Baliceaux营地死亡登记、1797船名与人数、运输停港、Roatán登陆位置。
A17|英国1795年起采购被奴役男子填补西印度军团，既服务帝国战争又维护加勒比奴役制度。|士兵在军队服役时的自由权利、叛逃、薪酬、家庭状况须按部队区分，而非统一称为全部已解放。|国家陆军博物馆13400名的期间为1795—1807，绝不可填成18世纪单年或1795—99总数。|War Office WO档逐名、岛屿采购价、营级编制与1800之后延续情况。
A18|英国自1793年介入法属圣多明各革命，殖民保王派寻求在英国保护下恢复旧有奴役秩序，1798年英方撤军。|Toussaint Louverture领导的革命力量及当地政治共同体主动改变军事局势，法属地区不能直接归类英国永久殖民地。|短期军事占据、英国保王派许诺的劳动力体系和实际经营成果必须分开。|1793英法协定原文、占城时间表、远征伤亡军籍、1798撤离条款和实际控制地图。
A19|1763年英法和约重新划分向风群岛与背风群岛的欧洲宗主权声索，1779与1783等再次发生岛屿政权转移。|Garifuna/Kalinago、被奴役非洲裔、法国殖民居民的地方政治选择跨越欧洲双边条约。|种植园转换税项、法英更替后财产权重新确认并不等于所有地产即时实际易手。|1763、1783岛屿列表各条约款、1779战役与撤军、岛内地产账、族群地界。
A20|强迫航运的死亡与海事法律反映英国商人对被奴役人口的财产化管理以及保险体系。|船上被掳者的反抗、船医/船员证言和幸存口供需逐人归档，不能把沉默档案等同没有抵抗。|船舶损耗、死亡、被理赔人数、航次损失率与港口总贸易额不能混用；1788载运法不是对杀人事件的刑事定罪。|船籍档与船上日记、Dolben限载法原版、Zong民事案卷及独立航位证据。
A21|1736年安提瓜当局宣称发现Prince Klaas组织的大规模起义计划，继而采用审讯、处决和恐惧政治。|被审者被迫招供的风险与真实秘密组织可能并存，独立史学已质疑殖民方“阴谋”叙事。|132被定罪与88处决来自同一篇Smithsonian历史综述，不可当两独立来源校验后的真实总数。|1736教区会议、安提瓜殖民司法记录、供词逐字版本、行刑名册和当时种植园损失账。
A22|百慕大与巴哈马18世纪存在不同的法律、王室治理与海盗／私掠经历；1718 Nassau重新被王室占领，1730百慕大强化种族限制。|岛上黑人、原住民居民、解放者以及私掠水手不可合并成一种法律人口。|海盗赦免、奴役人口随效忠派迁入和岛屿贸易利益，应按岛与年份计量，不画包围海水的全群岛实控面。|Rogers总督原始命令、Bahamas National Archives、百慕大法案执行、1783效忠派奴役人口名册。
C01|1710 Nicholson夺取Port-Royal堡垒，英法军事驻点再度易手；原堡以外Mi'kmaq政治地理仍有自主权。|阿卡迪亚居民与原住民联盟持续对英驻军抵抗，1711 Bloody Creek显示接管并非安定。|堡垒及近旁约五公里投降范围不能外推整个阿卡迪亚的地税或政治实控。|1710投降条款原本、1711旧/新历换算、周边村落临时军营地图。
C02|1713乌得勒支条约让法国向英国割让阿卡迪亚王室权利，但条约文字对地理范围不清晰，米克马克未随之让地。|Mi'kmaq、Wəlastəkokewiyik及阿卡迪亚民众分别使用外交、条件誓言和军事手段捍卫利益。|殖民地法律声索、征税权与村庄实际进驻是三层不同记录。|条约法英原文字、双方1730年代边界图、殖民地地契及原住民答复。
C03|1722—28多部族的抵抗与和平友好缔约过程交错，1726年6月4日约64名首领在安纳波利斯皇家城确认协议。|各原住民政体的身份、缔约代表权和狩猎捕鱼权利须逐条体现，不以“全族一次转让土地”概括。|渔业、毛皮和居民定居竞争在条约之后仍存在。|查1725 Dummer会议原件、1726签署人原始名册、1728续约文书与地籍。
C04|1749 Cornwallis在Kjipuktuk建立Halifax，英方推动殖民军镇与外来聚居。|当地Mi'kmaq并未因新军镇建立放弃土地政治主张，随后武装与请愿并行。|移民人数为移民人口，不是被害人数或英国控制土地面积。|1749船舶名单及建城测绘、军需账、原住民居住聚落图、较早Mi'kmaw地名。
C05|1748—56 Mi'kmaq土地请愿、1749英国议会敌对宣言和头皮赏金互相叠加，须按公文署日排列。|原住民抗争不能只通过英国对其的“叛乱”定性转述，1748请愿文书可保留自己的政治语言。|所谓每头皮10英镑金几尼仅是奖赏宣布标准，不能推定实际领取人数或实际支出。|CO217/9请愿原文，1749-10不同公告署日期，1750调额、1752撤销、1756重启原件。
C06|1750英国Fort Edward建设连接Halifax与Annapolis Royal路线，军事驻点成为Pisiquid地区驱逐的物流中心。|阿卡迪亚村民可选择逃亡、保护家人和寻求Mi'kmaq盟友，但各个人行动须有史料逐案佐证。|1750修筑工程与1755驱逐约1200人为不同事件、不同会计口径。|1750原堡测绘与驻军日志、1755驱逐船单与沿河村庄坐标。
C07|1755-07-28新斯科舍殖民当局决定大规模驱逐，行动在Chignecto、Mines、Pisiquid、Annapolis及1758岛屿多区推进。|阿卡迪亚居民的逃亡与返回、米克马克盟友的支持和地方抵抗持续到1760年代。|Les Mines约2200、Pisiquid约1200、Annapolis约1664和岛屿逾3000属不同地域年份，须去重后才能形成总和。|继承PR289已有18件候审事件和14个现代参考点；深化船名出发港/登陆港、死者名册、1764土地新占人清册。
C08|1755年Grand-Pré与Les Mines英军对居民进行拘押、分船转运；其中约2200为Les Mines地区总口径。|当地居民抵抗和逃亡个案须使用押船军令、家书和后世谱系分别校验。|回归者发现原土地被新殖民者占用，是农业地权转移而非一次性所有交易。|Saint-Charles教堂扣押日期原档、每批船单、1760年代宗教/民事地契。
C09|Fort Edward既是1750军事堡垒，又是1755年Pisiquid地区约1200人被逐的执行节点。|旧时Pisiquid居民的逃亡、收容及后裔返回需区分不同村庄。|约1200并不是单次押入堡垒人数或单船人数，切勿反推堡垒容量。|英军驻军档、船只名册、Pisiquid农田逐村地产调换与旧地图。
C10|1758英国征服Île Saint-Jean后由Skmaqn/Port-la-Joye附近组织驱逐阿卡迪亚居民，海上船难造成严重生命损失。|岛上阿卡迪亚农民与Mi'kmaq政治共同体是不同主体，不应以驱逐居民人口替代原住民人口。|“逾3000人被驱逐”与部分研究1649途中死亡是不同口径，真实存活抵达者需船单对表。|按船次查逾3000人口出发、沉船、抵港、法国接收卷，Skmaqn现代坐标只作站点参照。
C11|1754—63英法在北美开展据点争夺，Louisbourg、魁北克与蒙特利尔的实际转手日期需逐地记录。|Haudenosaunee、Anishinaabe及其他原住民族政治主体自行谈判、结盟、停战，不能只当英法附庸。|1763条约王权交替与内陆真实控地边界不同，站点胜负无法直接变大面积实占多边形。|各城投降条款、1760 Montréal文书、1763巴黎条约原文与原住民地权持续争议。
C12|1763英方占法堡垒和改革礼物贸易引发Great Lakes原住民多点武装行动，Michilimackinac等据点受冲击。|Odawa领袖Pontiac及Ojibwe、Wyandot等有各自议程，不把多族军事行动写成某一人单线下令。|皮毛贸易、英军补给及堡垒接管在战争中受损；缺统一年度金额。|各堡驻军日志、6月袭击日、移交旧/新历与堡垒真实边界。
C13|1763-10-07王室公告限制殖民者越过阿巴拉契亚山以西购地和定居，并设国家声索协调机制。|原住民政治主体可以继续谈判与抗争，公告由英王颁发而非诸族交出土地。|皇家公告是殖民者地权规则，执行力有限；地契是否撤销要个案核。|1763官方英文全文、地图原底本、后续1770条约与购地卷。
C14|1763-12-14和12-27宾州Paxton定居者袭击Conestoga/Susquehannock和平村社，包括Lancaster拘留收容者。|受害社区求庇护但仍遭凶杀；Benjamin Franklin写小册批评暴力，施暴者与殖民政府须严格区分。|村庄财物与土地承接记录须查县档，不能把实际遇害者人数与英军战场死伤混同。|尸检与警署卷、12月事件逐名名单、Paxton民团成员、1830年代纪念性地图不可倒当1763边界。
C15|1765英国议会印花税法强化向北美殖民地征税，引发商业和街头抵抗。|殖民城镇的抗议不应概括为各原住民与被奴役者获得同等公民权利。|议会预计税收、实际征到税额和抵制贸易损失是不同会计项目。|1765原法及各邮政/法院印花税收账，1776后议事持续性另核。
C16|1770波士顿英军对平民开枪，发生多名死亡并引发法庭争论和殖民政治传播。|被杀者Crispus Attucks的族裔描述应按可靠传记；群体与士兵之间冲突经过存证多版本。|当地军政关系和商业抵制成本缺可靠账目，不应虚构。|1770法庭卷与独立目击证言、King Street历史现场定位、人物身份文献。
C17|1775—83北美革命既是英王政府与殖民独立派的战争，也改变奴役者逃离、原住民结盟与后来的移民格局。|Dunmore公告邀请某些反英奴役主人的奴役者加入英方，黑人效忠派行动自主；多数原住民族政治选择不能据英方名单归为英国控制。|伦敦财政军事支出、北美战后失地与赔偿必须按国别和不同制度统计；1778等战区不算永属领土。|英军军需与Liberation卷、Book of Negroes逐名、特定战役坐标与1783条约后归属。
C18|1783后黑人效忠派被安排新斯科舍定居，但遭土地测绘迟滞、分配较差土地与不公待遇。|逃离奴役的黑人家庭通过宗教、诉愿和建立Birchtown等社区捍卫自由与耕作。|约3000到达与约1200在1792迁走不能相减推算死亡人数或全部获得地权面积。|1783—92逐宗land grants与surveys、Birchtown村址、佃工契约和工资。
C19|1792部分新斯科舍黑人效忠派经英国组织迁往塞拉利昂，复杂涉及当地Temne等政治关系。|移居者选择、Freetown地方居民权利、迁徙过程中的妇女与家庭行动需独立叙述。|约1200为特定迁徙队伍估值，不是北美其他非洲裔撤离人数。|1792 Freetown地权议约、CO270逐页、船名单与1800马龙群体另章。
C20|纽芬兰17世纪渔业殖民与Beothuk传统海岸活动竞争在18世纪强化，欧洲渔民定居挤压海岸资源。|Beothuk利用内陆空间避袭和抵抗，不能依殖民当局纸上保护公告推定其行动全部已消失。|渔季捕捞权益与Beothuk土地、生计丧失的因果须找定居与猎取记录，不使用传说死亡总数。|海岸定居图、1768 Cartwright日记、1797 Waldegrave公告、Beothuk遗物考古和原住民研究。
C21|卡罗来纳掳奴贸易与欠账、土地扩张诱发1715年亚马西战争，1716贸易规则和1717/18战争余波须细分。|Yamasee、Catawba、Cherokee等作战决策并不完全一致；区分盟友与曾独立议和的群体。|贸易债务与原住民俘虏买卖必须从商人账及新规查，不能用后来种植园人口估算战争规模。|Pocotaligo原址、1740年代地图、各族条约、港口捕奴账、1716 Indian Trade Act原法。
C22|弗吉尼亚1705年法令汇总奴役与契约仆役地位，1748又修订，有效对象和不同法条须分别核。|被奴役黑人/原住民人口借逃亡、诉讼与集体行动挑战世袭身份和惩罚，殖民法院记录可查。|人口被财产化、民兵追捕与种植园生产联系实际税册和契据；不能把《法令》当人口数量。|1705原议会Journal、Hening册校勘、1748法律正文具体条款、执行案件。
C23|1712-04-06纽约被奴役人群行动并引发市政镇压、审讯及新禁令。|反抗群体包含非洲裔不同族群和宗教背景，白人审讯材料未必准确记其政治诉求。|被处死20/21人的不同口径、被拘捕43/70等数字须按调查、定罪、执行分栏。|1712殖民法院庭审及法令原本、Maiden Lane现场、Commons处刑地现代仅地名参照。
C24|1741一连串纽约火灾后殖民检控把黑人和低收入白人纳入“阴谋”案，审讯依证词和恐慌传播。|被告的抗辩、奴役身份和强迫告发应与判决逐人区分，后世学界广泛质疑所谓广泛起义计划。|法院机构约200受审、30判死、70流放只是其说明口径，不等于所有实际已处死。|Horsmanden原文各版、1741火场位置、发配加勒比船单及火灾案件鉴别。
C25|1737 Penn家族借争议步行购买宣称大片Lenape土地，1735—38账册记交易与测量实践。|Lenape领袖否认协议真正有效、抗议土地掠夺，并继续通过外交维持地权主张。|理论购买范围、测量所得、实际定居农场是三个不同数据层；缺原地籍时不得用现代县界补齐。|1735账本逐页、1686所谓原契约真伪、1737行走路线、1758 Easton谈判原件。
C26|1699渔业法的部分条款1700-03-25开始适用，1729 Osborn推动海军总督行政司法转换。|Beothuk及渔港社区并非王室渔场法律的被动客体，其资源权与欧洲商船行政属不同政治层次。|Fishing Admirals季节贸易管制与王室行政的经济收益需逐港记录。|1699法原条、1729海军委任、1729捕捞船数量、Beothuk沿海渔区地名。
C27|HBC 1670特许纸上鲁珀特地范围巨大，但1713涉及沿湾堡垒返还，1774首个内陆Cumberland House代表商站拓展。|Thanadelthur、Dene与Cree谈判和向导网络决定毛皮流向；原住民族有贸易自主性、不可写公司征服河流全域。|毛皮、火器、礼物交易总量须由HBC原始ledger和贸易日记记账。|1713具体堡垒交接、1715会谈地点、Henday 1754日记、Hearne 1770旅行与1774据点实址。
'''
NOTES={}
for ln in TOPIC_NOTES.strip().splitlines():
 code,*sections=ln.split('|')
 if len(sections)!=4: raise ValueError(('notes_fields',code,len(sections)))
 NOTES['E18-'+code]=sections
assert len(NOTES)==49,(len(NOTES),set(TOPICS)-set(NOTES))
from urllib.parse import urlsplit
from datetime import date
from collections import defaultdict, Counter

GEO_POINTS={
 'fort_anne': {'coordinates':[-65.518724,44.741533],'modern_site':'Fort Anne National Historic Site, Annapolis Royal','source_ids':['S67','N24']},
 'halifax': {'coordinates':[-63.580392,44.647308],'modern_site':'Halifax Citadel National Historic Site','source_ids':['S69','S42']},
 'beaubassin': {'coordinates':[-64.261052,45.847286],'modern_site':'Beaubassin National Historic Site','source_ids':['S71','S11']},
 'fort_edward': {'coordinates':[-64.134978,44.996456],'modern_site':'Fort Edward National Historic Site','source_ids':['S63','S10']},
 'beausejour': {'coordinates':[-64.292126,45.863618],'modern_site':'Fort Beauséjour National Historic Site','source_ids':['S64','N27']},
 'grand_pre': {'coordinates':[-64.311792,45.108775],'modern_site':'Grand-Pré National Historic Site official modern placename','source_ids':['S65','S07']},
 'skmaqn': {'coordinates':[-63.13553805555556,46.19543972222222],'modern_site':'Skmaqn–Port-la-Joye–Fort Amherst National Historic Site','source_ids':['S66','S09']},
}
PR289_ACADIAN={
 'E18C-ACD-1713-UTRECHT':'1713条约争议',
 'E18C-ACD-1726-ANNAPOLIS-TREATY':'1726原住民和平友好协议',
 'E18C-ACD-1730-CONDITIONAL-OATH':'1730阿卡迪亚有条件誓言',
 'E18C-ACD-1749-HALIFAX-SETTLEMENT':'1749 Kjipuktuk建城',
 'E18C-ACD-1750-BEAUBASSIN-BURNING':'1750 Beaubassin烧毁',
 'E18C-ACD-1750-FORT-EDWARD-BUILT':'1750 Fort Edward建堡',
 'E18C-ACD-1751-BEAUSEJOUR-FRENCH':'1751法国筑Beauséjour堡',
 'E18C-ACD-1755-BEAUSEJOUR-CAPTURE':'1755夺Beauséjour',
 'E18C-ACD-1755-HALIFAX-ORDER':'1755-07-28驱逐决定',
 'E18C-ACD-1755-FORT-CUMBERLAND-ROUNDUP':'1755 Fort Cumberland驱逐',
 'E18C-ACD-1755-GRANDPRE-EXPEL':'1755 Les Mines驱逐',
 'E18C-ACD-1755-PISIQUID-EXPEL':'1755 Pisiquid驱逐',
 'E18C-ACD-1755-ANNAPOLIS-EXPEL':'1755 Annapolis驱逐',
 'E18C-ACD-1758-SKMAQN-ISLAND-EXPEL':'1758 Epekwitk驱逐',
 'E18C-ACD-1759-ACADIAN-RESISTANCE':'1759阿卡迪亚反抗',
 'E18C-ACD-1761-MIRAMICHI-REFUGEES':'1761 Miramichi难民',
 'E18C-ACD-1764-CUMBERLAND-SHELTERS':'1764 Cumberland棚屋',
 'E18C-ACD-1764-RETURN-LANDS':'1764返乡与土地剥夺',
}
OLD_STORY_FILES={
 'E6-T07-BARBADOS':'data/stories/serial/e6-t07-barbados.json',
 'E6-T07-LEEWARD':'data/stories/serial/e6-t07-leeward-kalinago-colonial-wars.json',
 'E6-T08':'data/stories/serial/e6-t08-jamaica-conquest-maroons.json',
 'E6-T09-PENNSYLVANIA':'data/stories/serial/e6-t09-pennsylvania-lenape-land-1681-1696.json',
 'E6-T09-CAR':'data/stories/serial/e6-t09-carolina-land-enslavement.json',
 'E6-T09-NY':'data/stories/serial/e6-t09-new-netherland-new-york.json',
 'E6-T10-ACADIA':'data/stories/serial/e6-t10-acadia-migmaqi-port-royal.json',
 'E6-T10-HBC':'data/stories/serial/e6-t10-hudson-bay-fur-trade.json',
 'E6-T10-NEWFOUNDLAND':'data/stories/serial/e6-t10-newfoundland-beothuk-fisheries.json',
 'E6-T11-VOYAGES':'data/stories/serial/e6-t11-atlantic-slave-voyages-quant-resistance.json',
 'E6-T13':'data/stories/serial/e6-t13-royal-african-company.json',
 'E6-T16-ATLANTIC-ISLANDS':'data/stories/serial/e6-t16-bermuda-bahamas-1609-1695.json',
}
OLD_STORY_SPECIFIC={
 'E6-T07-BARBADOS':'旧篇1661巴巴多斯法典—1692举报制度；接1709、1733、1760、1788新法时法律效力逐案更新。',
 'E6-T07-LEEWARD':'旧篇圣基茨Kalinago遇袭、英法战争与安提瓜奴役法；接1736安提瓜和1772—97 Garifuna战争。',
 'E6-T08':'旧篇1655英军仅占牙买加部分城港及山区马龙自主、1661—1699法制；接1739两个不同和约及1795—96战争。',
 'E6-T09-PENNSYLVANIA':'旧篇1681特许、1682地契与1687 Holm图限于部分可核地权；1737步行购买不能套现代州界。',
 'E6-T09-CAR':'旧篇1663/1665卡罗来纳王室纸面声索、原住民掳奴交易；接1715 Yamasee武装冲突。',
 'E6-T09-NY':'旧篇1664英军夺城、1673荷兰反占、1674英重占与非洲裔地权诉愿；接1712/1741黑人司法镇压。',
 'E6-T10-ACADIA':'旧篇1629苏格兰Charles Fort独立政体与1654/1670/1690实占变化；1710堡垒接管及1755驱逐另立候审阶段。',
 'E6-T10-HBC':'旧篇1670 HBC特许纸面权与1668—1699英法沿湾堡垒反复易手；1713必须逐堡核交接。',
 'E6-T10-NEWFOUNDLAND':'旧篇1699法案有部分1700-03-25适用条款；捕鱼法律与Beothuk土地政治独立。',
 'E6-T11-VOYAGES':'旧篇1601—1700计数包含1700，不与18世纪其他窗口机械求和，保留航次数据库口径和未编码抵抗。',
 'E6-T13':'旧篇1698皇家非洲公司独占终止并非废奴；新篇继续公司贸易及1750议会改制。',
 'E6-T16-ATLANTIC-ISLANDS':'旧篇1612百慕大定居、1684归王室、巴哈马1647—49定居；1718 Nassau接管另记。',
}
# Per-event preliminary crosswalk to existing candidate identifiers; no change to PR original IDs.
def match_pr_acadian(year,title,codes):
 if not any(t in codes for t in ['C01','C02','C03','C04','C05','C06','C07','C08','C09','C10']):return []
 if year==1713 and '条约' in title:return ['E18C-ACD-1713-UTRECHT']
 if year==1726 and '条约' in title:return ['E18C-ACD-1726-ANNAPOLIS-TREATY']
 if year==1730 and '效忠' in title:return ['E18C-ACD-1730-CONDITIONAL-OATH']
 if year==1749 and 'Halifax军港' in title:return ['E18C-ACD-1749-HALIFAX-SETTLEMENT']
 if year==1750 and 'Beaubassin' in title:return ['E18C-ACD-1750-BEAUBASSIN-BURNING']
 if year==1750 and 'Fort Edward' in title:return ['E18C-ACD-1750-FORT-EDWARD-BUILT']
 if year==1751 and 'Beauséjour' in title:return ['E18C-ACD-1751-BEAUSEJOUR-FRENCH']
 if year==1755 and 'Beauséjour' in title:return ['E18C-ACD-1755-BEAUSEJOUR-CAPTURE']
 if year==1755 and '驱逐' in title and 'Halifax' in title:return ['E18C-ACD-1755-HALIFAX-ORDER']
 if year==1755 and 'Fort Cumberland' in title:return ['E18C-ACD-1755-FORT-CUMBERLAND-ROUNDUP']
 if year==1755 and 'Grand-Pré' in title:return ['E18C-ACD-1755-GRANDPRE-EXPEL']
 if year==1755 and 'Pisiquid' in title:return ['E18C-ACD-1755-PISIQUID-EXPEL']
 if year==1755 and 'Annapolis' in title:return ['E18C-ACD-1755-ANNAPOLIS-EXPEL']
 if year==1758 and ('Île Saint-Jean' in title or 'Skmaqn' in title):return ['E18C-ACD-1758-SKMAQN-ISLAND-EXPEL']
 if year==1759 and 'Acadian' in title:return ['E18C-ACD-1759-ACADIAN-RESISTANCE']
 if year==1761 and 'Miramichi' in title:return ['E18C-ACD-1761-MIRAMICHI-REFUGEES']
 if year==1764 and 'Fort Cumberland' in title:return ['E18C-ACD-1764-CUMBERLAND-SHELTERS']
 if year==1764 and 'Acadian' in title:return ['E18C-ACD-1764-RETURN-LANDS']
 return []

# Additional archive-led named incidents: not previously in PR #289; dates without direct month/day remain year-only.
for k,org,title,url,level,support in [
 ('N74','UK National Archives','The Transatlantic Slave Trade: RAC 1700 shipping evidence','https://www.nationalarchives.gov.uk/explore-the-collection/explore-by-time-period/georgians/transatlantic-slave-trade/','official_primary_object_curatorial_context','官方说明1700年RAC跨大西洋运送逾4000被奴役非洲人；该数是单年公司口径、不是全部英旗船估数'),
 ('N75','Encyclopedia Virginia / William Snelgrave','Ferrers Galley mutiny recollection (1734 printed first-person source)','https://encyclopediavirginia.org/primary-documents/mutiny-on-the-ferrers-galley-an-excerpt-from-a-new-account-of-some-parts-of-guinea-and-the-slave-trade-by-william-snelgrave-1734/','primary_1734_print_transcription_read','Snelgrave记1722年伦敦Ferrers Galley被掳者起义、船长Messervy遇害、船员开炮、其称约80名被奴役者遭杀与落海；殖民船长目击/转述混合偏向'),
 ('N76','PortCities Bristol','18th Century: Bristol and Transatlantic Slavery Timeline','https://www.discoveringbristol.org.uk/slavery/timeline/18th-century/','regional_museum_style_historical_timeline_read','1711—13商人反公司垄断、1737 Bristol 37船、1744反奴运保护奏议、1750 King David船上起义、1761 Nevis、1765/1777牙买加、1786—88废奴出版组织'),
 ('N78','London Museum','Olaudah Equiano: Writer & Abolitionist','https://www.londonmuseum.org.uk/collections/london-stories/olaudah-equiano-writer-abolitionist/','official_museum_historical_biography_read','1789-03-24 Equiano自传首次出版并在伦敦登记；关于出身地仍有学界争议'),
 ('N79','University of Oxford English Faculty','The Interesting Narrative by Olaudah Equiano','https://english.web.ox.ac.uk/ten-minute-book-club/equiano-the-interesting-narrative','academic_literary_study_read','1789年第一版，讨论出生地学者争议，不能用其自述出生地当无争议地理事实'),
 ('N80','New York Public Library','Ottobah Cugoano 1787 Thoughts and Sentiments','https://old-digitalcollections.nypl.org/items/926cb8fd-d622-c14f-e040-e00a1806498a','primary_book_catalogue_metadata_read','1787 Cugoano在伦敦发表论奴役贸易批判著作，馆藏发行年及书目'),
 ('N81','Library and Archives Canada','Loyalists: British Headquarters Papers, Book of Negroes','https://www.canada.ca/en/library-archives/collection/research-help/genealogy-family-history/loyalists.html','official_archive_catalogue_and_record_guide','1783 Book of Negroes列黑人效忠派姓名、身体特征和撤离船名；未逐行核原簿'),
 ('N82','Dictionary of Canadian Biography','Boston King biographical account','https://www.biographi.ca/en/bio/king_boston_5E.html?print=1','peer_reviewed_biographical_dictionary_read','1783-08-27 Boston King到Birchtown参与社区建设、1784-01 muster 1521人口；实际按该地名册'),
 ('N83','Parks Canada','Black Loyalist Experience National Historic Event','https://www.pc.gc.ca/apps/dfhd/page_nhs_eng.aspx?id=1576','official_commemoration_read','1783年8月Birchtown建立，约3500（Nova Scotia+New Brunswick）英国黑人效忠派；不同于Nova Scotia约3000'),
]:
 SOURCES[k]={'id':k,'author_or_institution':org,'title':title,'url':url,'type':level,'actually_read_scope':support,'manuscript_inspected':False,'read_scope_note':'逐项标记编年概述、原始船长印本转录与档案目录，不将转述当案卷逐页核对。'}
EVENT_LINES+='''
1700|A03,A01|皇家非洲公司在1700年跨洋运送超过4000名被奴役非洲人|皇家非洲公司船主及商人、遭强制运送的非洲人|西非至英属美洲具体船港未核|英国国家档案馆官方展览举出1700年公司运送逾4000人，属该公司当年运输口径，不等于英国旗船全部航次或每个人抵岸|N74,S03|
1704|A06|牙买加殖民当局报告规模较小的奴役者反抗|牙买加被奴役者、殖民官员|Jamaica具体教区未核|Bristol历史时间轴记录1704年报告一次小规模起义；具体地名、人数和军事结果未确认，仅保留年级候审|N76|
1706|A08|英国首席法官Holt对英格兰境内黑人自由状态发表判词|Sir John Holt、Smith v Brown and Cooper诉讼当事人|London|法律史编年索引记Holt提出入境英国黑人的法律地位论述，后续实际判例未一致遵守；该条为1772案的法律前史|N76|
1711|A03,A04|布里斯托商人组织反对恢复皇家非洲公司独占的游说|Bristol Corporation、Society of Merchant Venturers、私人奴隶贸易商|Bristol/London|1711—1713商人从港口利益出发要求维持参与奴隶贸易的自由；具体请愿日期与署名需议会卷核|N76,S82|
1722|A01,A20|Ferrers Galley被奴役乘员组织起义并遭船员开炮镇压|被奴役非洲人、船长Messervy、船员、证人William Snelgrave|Cetre-Crue至Jamaica航路海域不确|1734年Snelgrave印行的偏向性证词记1722年船上起义、船长死亡及船员开炮；称约80名被奴役者被杀或落海，但他并非亲眼见证海上行动，数量待独立核|N75,S03|
1729|A08|Yorke和Talbot提出奴役身份不随英国境内停留而自动消失的法律意见|英国Attorney General Philip Yorke、Charles Talbot、奴役主|London|地区历史年表记1729司法意见；为1772 Somerset法域变化的反面历史背景，需核1729原意见书文本|N76|
1737|A04|布里斯托奴隶船远航数量达到地方历史记录高点|Bristol船主、港市商会、被奴役非洲人|Bristol|地方公共历史编年称当年有37个奴役航次、超伦敦；需要按当地港口船单与航次数据库交叉核实|N76,S04|
1742|A06|牙买加部分被奴役者与对殖民政府不满的马龙人结盟反抗|牙买加被奴役者、部分马龙社群、殖民民兵|Jamaica具体地区待核|地区历史时间轴仅记1742年局部起义；此处不把所有马龙群体视作统一参战一方|N76|
1744|A04|布里斯托市政当局向英王提交保护非洲奴隶贸易的请愿|Bristol Corporation、英国王室、奴隶贸易商|Bristol/London|战争期间地方商界请求皇家保护非洲人口贩运，体现市政与商业奴役网络联动；请愿原本待核|N76,S04|
1747|A04|利物浦贸易港对英国奴隶船运的影响超过布里斯托|Liverpool与Bristol奴役贸易商|Liverpool/Bristol|地区史时间轴标注1747出现规模变化，49与20为不同口径的年数/均值，暂不当作两港同一年度精确航次数比较|N76,S38|
1750|A01,A20|Bristol船King David发生被奴役者大规模船上反抗|被奴役非洲人、King David船主及船员|King David船航线未核|Bristol历史时间轴记1750年此船发生重大船上起义；船旗、死亡和航行具体海位待原航志核|N76,S03|
1761|A06|Nevis殖民地被奴役者发动起义|被奴役Nevis岛居民、殖民军政当局|Nevis|地区历史年表记1761年奴役者反抗，尚缺可核处刑名册及具体庄园地名|N76,S56|
1765|A06|牙买加多个庄园遭遇奴役者反抗|牙买加被奴役者、各庄园主与殖民军|Jamaica不同教区|Bristol年表记17处庄园起义，尚未查明17是当期庄园总数、报告地或不同记录复叠；不入权威统计表|N76|
1777|A06|牙买加Hanover和Westmoreland教区出现奴役者起义|被奴役当地居民、牙买加殖民民兵|Hanover and Westmoreland parishes Jamaica|地方历史年表记短期反抗；参与者姓名及镇压人数待教区原档|N76|
1786|A10|Thomas Clarkson出版针对奴隶贸易的思想论著|Thomas Clarkson、英国废奴人士|London|Bristol历史年表确认Clarkson《Essay on the Slavery and Commerce of the Human Species》于1786出版，为1787组织化运动前史|N76|
1787|A10|Ottobah Cugoano发表《奴役贸易之罪恶》批判论著|Ottobah Cugoano、非洲裔废奴作者群体|London|纽约公共图书馆藏书目录确认1787年出版，体现非洲裔作者自主发声，不能只归功白人议员|N80,N07|
1788|A10|布里斯托尔废奴运动在Guildhall召开首次公开大会|Bristol奴隶贸易废除倡导者|Bristol Guildhall|地区历史年表记1788年Guildhall公开会议；该年Dolben法律另作议会事件，日期尚待地方报纸核|N76,N07|
1789-03-24|A10|Olaudah Equiano于伦敦出版自传《Interesting Narrative》|Olaudah Equiano、伦敦出版商和非洲裔读者|London/Fitzrovia|伦敦博物馆确认1789-03-24首次出版并登记；作者自述籍贯有学术争论，不能据此强制给出生村落现代GPS|N78,N79|
1791|A10|英国下议院否决Wilberforce禁止奴隶贸易方案|Wilberforce及议会表决成员|Westminster London|Bristol年表记1791废奴提案受阻，贸易仍继续；精确议院票数与提案文本需英国议会议事录核|N76,N07|
1798|A06|牙买加Kofi相关奴役者反抗见地方时间轴|Kofi及牙买加被奴役者、殖民当局|Jamaica具体教区未核|地方历史编年仅给“1798 Kofi's rebellion”一行；是否与同名历史叙述重叠、个人拼写与地点均待独立审计|N76|
1783-08-27|C18|Boston King到达Birchtown并参与建立黑人效忠派社区|Boston King、黑人效忠派家庭、英国殖民测量员|Birchtown/Nova Scotia|加拿大人物传记据其行踪记1783-08-27参与Birchtown聚落建设，地方团体组织争取土地和宗教生活|N82,N83|
1784-01|C18|Birchtown黑人效忠派登记册记录1521名住民|当地黑人效忠派家庭、殖民档案官员|Birchtown Nova Scotia|加拿大人物辞典记1784年1月该村人口清点1521，明确是该村当月名册，不可当全部新斯科舍黑人数|N82,N81|
1783|C17,C18|英国撤离纽约时编制黑人效忠派《Book of Negroes》|英军总部、登记官、撤离的黑人效忠派|New York City|Library and Archives Canada确认1783名册列姓名、身份及撤离船名，原卷尚未逐行誊录|N81,N36|
'''

CANDIDATES=[]
ids_counter=Counter()
for ln in EVENT_LINES.splitlines():
 if not ln.strip():continue
 fields=ln.strip().split('|')
 if len(fields)!=8:raise ValueError(f'bad event 8 fields: {fields}')
 ds,codes_str,title,actor,place,description,source_str,geokey=fields
 date_parts=ds.split('-')
 year=int(date_parts[0]);month=int(date_parts[1]) if len(date_parts)>1 else None
 day=int(date_parts[2]) if len(date_parts)>2 else None
 if month and day:date(year,month,day)
 elif month and not (1<=month<=12):raise ValueError(('month',ln))
 if not 1700<=year<=1799:raise ValueError(('out_of_scope',ln))
 codes=codes_str.split(',')
 tids=['E18-'+code for code in codes]
 for t in tids:
  if t not in TOPICS: raise ValueError(('unknown_topic',t))
 src_ids=source_str.split(',')
 for sid in src_ids:
  if sid not in SOURCES:raise ValueError(('unknown_source',sid,title))
 ids_counter[(year,codes[0])]+=1
 evid=f'E18A-{year}-{codes[0]}-{ids_counter[(year,codes[0])]:02}'
 old_ids=sorted(set(v for tid in tids for v in TOPICS[tid]['previous_story_ids']))
 if geokey and geokey not in GEO_POINTS:raise ValueError(('unknown_geokey',geokey))
 pt=GEO_POINTS.get(geokey)
 crosswalk=match_pr_acadian(year,title,codes)
 if ds=='1700' and codes==['A03']:
  status='continuity_seed_not_single_year_action'
 else:status='dated_event_candidate_needs_editorial_review'
 CANDIDATES.append({
  'id':evid,'date_text':ds,'year':year,'month':month,'day':day,
  'date_precision':('day' if day else 'month' if month else 'year'),
  'topic_ids':tids,'title':title,'actor_entities_text':actor,
  'historical_description_zh':description,'historical_place_name':place,
  'longitude':pt['coordinates'][0] if pt else None,
  'latitude':pt['coordinates'][1] if pt else None,
  'modern_reference_site':pt['modern_site'] if pt else None,
  'geo_precision':('modern_official_site_representative_not_event_GPS' if pt else 'no_verified_coordinate'),
  'coordinates_support_sources':pt['source_ids'] if pt else [],
  'source_ids':src_ids,'source_urls':[SOURCES[s]['url'] for s in src_ids],
  'source_support_count':len(src_ids),
  'claim_crosscheck_status':'claim_by_claim_independent_primary_source_review_pending',
  'evidence_status':status,'previous_17c_story_ids':old_ids,
  'pr289_preexisting_acadia_candidate_ids':crosswalk,
  'historical_control_boundary_verified':False,'political_claim_not_actual_control':True,
  'area_sqkm':None,'historical_line_or_route_surveyed':False,
  'estimated_casualties_count':None,'estimated_trade_sum':None,
  'publication_status':'research_only','publication_review':'not_submitted'
 })
assert len(CANDIDATES)==len({e['id'] for e in CANDIDATES})
assert set(TOPICS)==set(tid for e in CANDIDATES for tid in e['topic_ids'])
assert all(not x['historical_control_boundary_verified'] and x['area_sqkm'] is None for x in CANDIDATES)

# Hand-authored precision caveats for research, also reproduced per individual topic.
GLOBAL_GAPS='''
## 需要优先处理的统计、年代、法律争议
1. **英国旗船运量时间窗**：SlaveVoyages 的1701—1725、1726—1750、1751—1775三组估计登船人数可以逐组引用；1776—1800 **包括1800年**，与本项目1700—1799不同。1699/1700附近与17世纪旧篇亦不能重复计数。必须按航次逐条筛选才可求严格1700—1799合计。
2. **分类分母**：航次数、登船人数、到岸人数、贸易港口国别、船籍登记、实际英国投资者、奴隶出生地、战俘、营地拘禁与强制劳动分别存字段，不将它们视为一项人数或利润。
3. **阿卡迪亚人口**：Les Mines约2200、Pisiquid约1200、Annapolis地区1664、Chignecto约1100、Île Saint-Jean逾3000，属于不同地区与年份；可能存在逃亡、反复驱逐、重叠地域，未核原船单不得简单累加。1758船损失“1649死”是其他研究估计，尚待按船名、起运口径复算。
4. **PR #289的18件阿卡迪亚候审史事及14个Parks Canada现代参照点**：本档继承此前成果并补日月与新资料，不宣称重复事件是独立增加的真实发生次数，也不覆盖PR中稳定ID。现代遗址GPS不是原始军港、村落、押船码头或受害者集合GPS。
5. **1749 Nova Scotia Mi'kmaq头皮赏金**：殖民议会敌对宣言、公告签日、允许兑现日期分别查；学术索引有10月7日及旧历差异，现仅录“1749-10”，10 guinea标准须核公告原件，不能当实际支出或实际杀害人数。
6. **1711 Bloody Creek历法**：Parks Canada标旧历6月10日，换算为新历6月21日；数据库保留文书旧历日期并注明历法，不据此杜撰不同两场战斗。
7. **纽约1712**：Columbia/PBS与市政文件所列“被捕/被审/被定罪/已处决/烧死”等人数不同；不得把20、21、25简单描述为同一真实处决总数。
8. **纽约1741**：所谓纵火/奴役阴谋有严重逼供、举报和以推测定罪问题；“200审、30死刑、70发配”是法庭历史机构概述数字，尚需法庭原始被告行核查。
9. **Antigua 1736**：132定罪、88被处死来自同一历史综述（S84和N21同源），不属于两来源交叉核实。计划中的阴谋是否真实及所谓“炸药”物证存在争议。
10. **Zong 1781/1783**：London Museum同页约130和133两种死亡人数；完整船上死亡、抛海分批日期、当前位置和保险讼案阶段须核英国国家档案馆KB 122/479及保险合同。海域保持空坐标。
11. **Garifuna 1796–97**：Baliceaux拘押、登船、Roatán上岸及中途死亡必须四本分母。Garifuna Nation所记1797-04-12与约2500人属社区纪念资料，待帝国运输清单交叉。不得以任意两岛之间直线声称实际航线。
12. **英属西印度军团**：国家陆军博物馆所述1795—1807约13400名购买入伍是跨19世纪的累计估计，禁止录为1795—99总数，也不把战时全部黑人士兵身份写成奴役。
13. **1795–96 Fédon战争**：部分史学研究估“七千被奴役者死亡”为一项学术模型/推断，并非已证死亡名单；约400名Loyal Black Rangers另需核Candlin新论文原文。
14. **1772 Somerset**：本土英格兰司法拘押和强迫输送限制≠英国议会废除殖民地奴役，殖民法域另列。
15. **哈德孙湾公司**：1670英王纸面鲁珀特地与1713实际堡垒交还、1774内陆单站贸易完全不同；无人逐年测绘内陆政治疆域，禁止将整个现代流域填色为英方实控。
16. **宾州1737 Walking Purchase**：须证伪/证实声称的1686原契、1737步行路线、测量范围和Lenape抗议，未核同代地籍时不能从现今县界生成地权Polygon。
17. **1763 Paxton Boys**：施暴者是宾州定居者武装，不能自动归为“英国正规军奉政府命令屠杀”；实际被害者名单与地方官员保护失败另核。
18. **英法条约与原住民主权**：1713、1763与1783欧洲条约不构成Mi'kmaq、Lenape、Garifuna、Cree/Dene等群体已向欧洲国家割让土地的证据。商馆、王室特许、法令、军事驻地、实际村落控制与原住民土地权是不同图层。
19. **Beothuk历史**：不同殖民记录含相互指责与对原住民族的刻板描述；需原住民及考古研究双重校验，避免以未证的“赏金灭绝令”当事实。
20. **经济后果**：全研究批次没有核定任何单船净利润、庄园净收益、殖民政府税收及战后真实赔款支付汇总。未逐行核商业账簿前保留`null`，不据港口影响推算具体商人收益。
21. **档案阅读分级**：National Archives/法院/大学仅有目录或数字转录的文件已逐项标出；没有亲阅原稿的任何文件均是`manuscript_inspected=false`。
22. **地图精度**：只有加拿大公园局、自然资源部门已与PR #289关联的现代国家历史遗址代表点可输出Point，不能据同地名反推1755年军队GPS。所有北美、加勒比、西非航程、边界、战区面及收入面积均不画未经审核的Polygon、LineString。
'''

# Body for numeric source-statistics snapshots. No fabricated exact 18c total.
NUMERIC_EVIDENCE=[
 {'id':'Q01','topic_ids':['E18-A01','E18-A20'],'start_year':1701,'end_year':1725,'count':410597,'unit':'estimated_persons_forcibly_embarked','classification':'estimated_British_flag','source_ids':['N01'],'note':'SlaveVoyages estimate; 25-year interval, not exact individual voyage count'},
 {'id':'Q02','topic_ids':['E18-A01','E18-A20'],'start_year':1726,'end_year':1750,'count':554042,'unit':'estimated_persons_forcibly_embarked','classification':'estimated_British_flag','source_ids':['N01'],'note':'SlaveVoyages estimate; 25-year interval'},
 {'id':'Q03','topic_ids':['E18-A01','E18-A20'],'start_year':1751,'end_year':1775,'count':832047,'unit':'estimated_persons_forcibly_embarked','classification':'estimated_British_flag','source_ids':['N01'],'note':'SlaveVoyages estimate; 25-year interval'},
 {'id':'Q04','topic_ids':['E18-A01','E18-A20'],'start_year':1776,'end_year':1800,'count':748612,'unit':'estimated_persons_forcibly_embarked','classification':'estimated_British_flag','source_ids':['N01'],'note':'OUT OF PERIOD for 1700-1799 because 1800 included; DO NOT sum into century total'},
 {'id':'Q05','topic_ids':['E18-A17'],'start_year':1795,'end_year':1807,'count':13400,'unit':'estimated_people_purchased_for_military_recruitment','classification':'British West India Regiments period estimate','source_ids':['S41'],'note':'EXTENDS INTO 19C; cannot be recast as 1795-1799'},
 {'id':'Q06','topic_ids':['E18-C08','E18-C07'],'start_year':1755,'end_year':1755,'count':2200,'unit':'estimated_residents_expelled','classification':'Les Mines regional people','source_ids':['S07'],'note':'Grand-Pré memorial is spatial reference, not location of all 2200'},
 {'id':'Q07','topic_ids':['E18-C09','E18-C07'],'start_year':1755,'end_year':1755,'count':1200,'unit':'estimated_residents_expelled','classification':'Pisiquid regional people','source_ids':['S10'],'note':'Not Fort Edward instantaneous detainee count'},
 {'id':'Q08','topic_ids':['E18-C07'],'start_year':1755,'end_year':1762,'count':7000,'unit':'rough_upper_bound_of_expelled_residents','classification':'Parks Canada approx 6000–7000 across period','source_ids':['S08'],'note':'Use range 6000–7000, not precise 7000 or a sum of subregions'},
 {'id':'Q09','topic_ids':['E18-C07'],'start_year':1764,'end_year':1764,'count':388,'unit':'residents_in_temporary_shelters','classification':'73 households near Fort Cumberland','source_ids':['S08'],'note':'Not Acadian total number in captivity'},
 {'id':'Q10','topic_ids':['E18-A12'],'start_year':1796,'end_year':1796,'count':500,'unit':'people_forcibly_deported_approx_lower_text','classification':'over 500 Jamaican Maroons, approximately 150 families','source_ids':['N15','S25'],'note':'Parks says over 500, not precise 500'},
 {'id':'Q11','topic_ids':['E18-A16'],'start_year':1797,'end_year':1797,'count':2500,'unit':'persons_reported_landed_approx','classification':'Garifuna Nation remembrance','source_ids':['N50'],'note':'Need colonial shiplist independent check'},
 {'id':'Q12','topic_ids':['E18-A21'],'start_year':1736,'end_year':1736,'count':88,'unit':'persons_reportedly_executed','classification':'one Smithsonian history synthesis, disputed record','source_ids':['S84'],'note':'S84=N21 same source; not independently verified'},
 {'id':'Q13','topic_ids':['E18-C03'],'start_year':1726,'end_year':1726,'count':64,'unit':'Indigenous leaders_reported_present','classification':'Parks Canada 1726-06-04 gathering','source_ids':['N25'],'note':'Participants at negotiation, not land ceded'},
 {'id':'Q14','topic_ids':['E18-C24'],'start_year':1741,'end_year':1741,'count':70,'unit':'persons_reported_deported_to_Caribbean','classification':'New York Courts historical overview','source_ids':['S75'],'note':'Review individual accused and deportation ship rolls'},
]
# The draft PR research_window is a topic's main focus, not a prohibition on contextual prior/after events.
# Explicitly tag such context rather than silently claiming it occurred in the topic's core window.
for e in CANDIDATES:
 e['topic_window_alignment']={tid: ('in_core_research_window' if TOPICS[tid]['research_window']['start_year']<=e['year']<=TOPICS[tid]['research_window']['end_year'] else 'contextual_pre_or_post_topic_window') for tid in e['topic_ids']}
 e['topic_window_context_notice']='Some joined-topic IDs are contextual links and are not dated actions inside that narrow topic research window.' if 'contextual_pre_or_post_topic_window' in e['topic_window_alignment'].values() else None
# Additional bounded numbers copied only from named institutional source statements.
NUMERIC_EVIDENCE.extend([
 {'id':'Q15','topic_ids':['E18-A03','E18-A01'],'start_year':1700,'end_year':1700,'count':4000,'unit':'lower_bound_enslaved_persons_transported','classification':'Royal African Company specific 1700 year','source_ids':['N74'],'note':'The National Archives states OVER 4000, not precise 4000; do not add to SlaveVoyages multi-year aggregates.'},
 {'id':'Q16','topic_ids':['E18-C18'],'start_year':1784,'end_year':1784,'count':1521,'unit':'persons_in_muster','classification':'Birchtown Jan 1784 local muster (Black Loyalist settlement)','source_ids':['N82'],'note':'One local settlement January muster; not all Nova Scotia Black Loyalists and not a century-wide population.'},
 {'id':'Q17','topic_ids':['E18-C18'],'start_year':1783,'end_year':1783,'count':3500,'unit':'approx_people_settled_combined_provinces','classification':'Black Loyalists in Nova Scotia AND New Brunswick','source_ids':['N83'],'note':'Parks Canada says at least 3500 combined two provinces; do not compare directly with Nova Scotia only 3000 estimate.'},
])
# Source index includes all sources named in initial project draft and added current research;
# each source contains explicit access-level metadata and no inspected-manuscript assertions.
for sid,src in SOURCES.items():
 src['supported_event_candidate_ids']=[e['id'] for e in CANDIDATES if sid in e['source_ids']]
 src['supported_topic_ids']=[t for t in TOPICS if sid in TOPICS[t]['source_ids'] or any(t in e['topic_ids'] and sid in e['source_ids'] for e in CANDIDATES)]
 src['access_verified_at'] = '2026-11-08' if any(flag in src['type'] for flag in ['_read','fulltext','transcription']) else None
 src['primary_source_type']=any(flag in src['type'] for flag in ['primary','historical_legislation','original_document'])
 src['separate_source_identity_note']='同网址或同一作者/机构的不同ID不可计为互相独立的第二证据。'
 assert urlsplit(src['url']).scheme=='https',(sid,src['url'])

TOPIC_EVENT_MAP={t:sorted((e for e in CANDIDATES if t in e['topic_ids']),key=lambda e:(e['year'],e['month'] or 0,e['day'] or 0,e['id'])) for t in TOPICS}

# Candidate point features ONLY; null-coordinate events remain in main CSV/JSON, not map features.
GEO_FEATURES=[]
for e in CANDIDATES:
 if e['latitude'] is None: continue
 assert e['longitude'] is not None
 GEO_FEATURES.append({
  'type':'Feature','id':e['id'],
  'geometry':{'type':'Point','coordinates':[e['longitude'],e['latitude']]},
  'properties':{
   'id':e['id'],'date':e['date_text'],'topic_ids':e['topic_ids'],
   'name':e['title'],'historical_place_name':e['historical_place_name'],
   'modern_reference_site':e['modern_reference_site'],
   'description_zh':e['historical_description_zh'],'source_ids':e['source_ids'],
   'coordinate_source_ids':e['coordinates_support_sources'],
   'geolocation_limit_zh':'仅官方现代历史遗址/地名位置参照；并非18世纪事件、伤亡、船只或全部行动地GPS。',
   'geo_precision':'modern_official_site_representative_not_event_GPS',
   'mapping_method':'PR #289官方加拿大历史遗址参考点（位置含微小机构差异），新事件按名称严格复用；未查得18世纪实测GPS。',
   'representative_map_point':True,'boundary_verified':False,
   'historical_boundary_confirmed':False,'fill_authorized':False,
   'territorial_claim':False,'actual_military_control_polygon':False,
   'area_sqkm':None,'exclude_from_area_aggregation':True,
   'publication_status':'research_only','publication_review':'not_submitted',
  }
 })

# Files outside the requested core set document replicable work, stage continuity and numeric caveats.
ROOT.mkdir(exist_ok=True,parents=True)
(ROOT/'TOPIC_DOSSIERS').mkdir(exist_ok=True,parents=True)
(ROOT/'REFERENCE').mkdir(exist_ok=True,parents=True)

def writej(path,obj):
 path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def is_legal_law(tid):return tid in ['E18-A06','E18-A08','E18-A22','E18-C22','E18-C26']
def subject_groups(tid):
 if tid.startswith('E18-A'):
  n=int(tid[-2:]);
  if n in [5,11,12]:return '马龙社区及其妇女、儿童和不同领导团体；同时分清直接战斗和被迫流放中的不同受害者。'
  if n in [14,15,16]:return 'Garifuna/Kalinago政治共同体、战斗者、被拘押和被迫移走的家庭；承认其自主民族认同。'
  if n in [1,2,3,4,6,7,9,17,18,20,21]:return '被掳、被贩卖、遭奴役的非洲裔人口及其后代，也记录不同法律身份的自由有色居民。'
  return '殖民经济与军事制度影响下的非洲裔、原住民与殖民地居民，按具体航次、法域及岛屿辨别。'
 n=int(tid[-2:])
 if n in range(1,11):return '阿卡迪亚民众、Mi’kmaq和Wolastoqiyik等原住民族；需要区分法属农民被驱逐与原住民权利。'
 if n in [11,12,13,14,20,21,25,27]:return '具名原住民族及各自治共同体，另列当地被奴役者、战场居民和逃难人群。'
 if n in [18,19,22,23,24]:return '被奴役和已获自由的非洲裔居民及其家庭，法律身份按当期制度具体划分。'
 return '地方平民、被奴役居民、政治诉愿者与各原住民族，不能以单一英方主体替代。'

def era_note(tid):
 if tid.startswith('E18-A'):return '注意1707年前英格兰和苏格兰是独立政体；英国旗船分类与实际商人国籍、公司港口不同。'
 return '地图区分欧洲王室纸面声索、堡垒实际驻军、种植园地权和原住民政治领土。'

def make_dossier(tid,topic):
 events=TOPIC_EVENT_MAP[tid]
 ctx,res,econ,gap=NOTES[tid]
 obs=Counter(e['date_precision'] for e in events)
 yearlist=', '.join(f"{e['date_text']} {e['title']}" for e in events[:8])
 years=f"{topic['research_window']['start_year']}—{topic['research_window']['end_year']}"
 oldid=', '.join(f'`{x}`' for x in topic['previous_story_ids'])
 src_used=sorted(set(topic['source_ids']) | {s for e in events for s in e['source_ids']})
 source_lines=[]
 for sid in src_used:
  s=SOURCES[sid]
  source_lines.append(f"- **{sid}** [{s['title']}]({s['url']}) — {s['author_or_institution']}；阅读层级：`{s['type']}`；支持范围：{s['actually_read_scope']}")
 event_rows=[]
 for e in events:
  geotag=(f"**现代遗址代表点** ({e['latitude']:.6f}, {e['longitude']:.6f})" if e['latitude'] is not None else '无经证坐标')
  event_rows.append(f"### {e['date_text']}｜{e['title']}（{e['id']}）\n\n**行动主体**：{e['actor_entities_text']}。**历史地点**：{e['historical_place_name']}；{geotag}。\n\n{e['historical_description_zh']}\n\n**依据**：{', '.join('`'+s+'`' for s in e['source_ids'])}。**精度**：{e['date_precision']}，`{e['evidence_status']}`。本件尚待逐项交叉核原文。\n")
 pr_ids=sorted(set(x for e in events for x in e['pr289_preexisting_acadia_candidate_ids']))
 pri=('、'.join('`'+p+'`' for p in pr_ids) if pr_ids else '无自动逐事件对应；旧PR其他相关候审事件在专题总登记中保留')
 numeric=[q for q in NUMERIC_EVIDENCE if tid in q['topic_ids']]
 num_lines=[]
 for q in numeric:
  num_lines.append(f"- `{q['id']}`：{q['start_year']}—{q['end_year']}，{q['count']:,}（{q['unit']}），来源 {', '.join(q['source_ids'])}。**口径说明**：{q['note']}")
 numtext='\n'.join(num_lines) if num_lines else '本轮尚未建立具有足够证据的独立人数/金额总账，不填未经审核数字。'
 mpts=sorted({e['modern_reference_site'] for e in events if e['modern_reference_site']})
 locs='；'.join(mpts) if mpts else '尚无经来源核对且可独立复用的GPS参照点。'
 narrative=f'''# {tid}｜{topic['title']}（1700—1799候审史料）

**研究覆盖**：{years}（此区间是研究窗，不声称逐年有事件；其他年份为跨题背景连接，见事件字段`topic_window_alignment`）。**证据状态**：`research_only / not_submitted`。**已列具名候审节点**：{len(events)}件（日级{obs['day']}、月级{obs['month']}、年级{obs['year']}）；已含跨专题重复指向，同一事件不可在全项目再次累算。**17世纪前篇**：{oldid}。

## 一、背景

{ctx} {era_note(tid)}

## 二、殖民决策、法律和政策

上述研究线索涉及王室、殖民议会、公司、军队和独立商人的不同决策。需把正式的议会立法、公司特许、军事命令、地方议约及实际执行分开登记。对本专题已确定可列出的具体政治/法律行动，可见下方逐事件时间轴；没有正式证据的政策背景只作研究说明。 {'此专题涉及历史立法，数据以法令原文转录或官方刊本日期为准，同时标示哪条法律仅是目录。' if is_legal_law(tid) else ''}

## 三、实际行动与日期证据

本次候审事件按文献明示的年份、月份、日次收录；只按年确证的事件绝不补月日。重要锚点包括：{yearlist}。

{chr(10).join(event_rows)}

## 四、具体地点与地图证据

历史地名由逐件事件给出。此篇**{len([e for e in events if e['latitude'] is not None])}件**候审节点指向官方现代参考点，涉及：{locs}。这些是现代官方史迹标位而不是同代测量的事件GPS；其余事件的经纬度均为`null`。不得画出没有同代地籍、堡垒调查或具体战区证据的实控面、虚假航海轨迹、现代岛屿包围海面或按点缓冲估算面积。

## 五、相关人物与行动主体

主体逐件核对，现已记录：{'; '.join(sorted(set(e['actor_entities_text'] for e in events[:9])))}。同一人物代表王室还是私人公司、某一原住民族政治领袖还是欧方描述中的“附庸”，都应按原件判定；未得到姓名的被掳者不补造姓名。

## 六、受影响群体

{subject_groups(tid)} 逐件登记的受害人数、被迫登船人数、政策涉及人数等按来源独立记账，原件未核部分不得创造精确总计。

## 七、反抗、谈判与其他主体的政治主张

{res} 对具体被奴役者、原住民或流亡者是否签署协议，不能用其后集体标签替代逐个当事人的选择与政治主体身份。

## 八、经济后果、统计证据及统计口径

{econ}

{numtext}

所有经济金额、折现收益、土地亩数、人口总额未有同样可追溯口径的单一证明时留空。禁止把种植园受益机制当净利润、将法院索赔当已收到赔款。

## 九、长期影响与和前世纪连接

对照17世纪前篇的制度及政治连续性，不能自动延续其1699年政治实控和面积边线。本篇承接其历史背景，但每次18世纪战争、驱逐、立法、岛屿换旗有自己的证据与日期。PR #289阿卡迪亚旧候审事件对照：{pri}。英国王室文书影响与受害者实际遭遇还须个案跟踪到19世纪，后世纪事件不能混入本批1700—1799正式数据。

## 十、证据缺口及下一轮原档路线

{gap} 对本专题最需要完成的后续审计是逐项“双独立来源”声明对照：同页重复转载不视为两个来源；档案目录与原件未读区别。若存在生效年、历法、参与人数、地理边界争议，详见总文档 `../GAPS_AND_CONFLICTS.md`。

## 史料登记（可点击原始出处）

{chr(10).join(source_lines)}

---
*本文件是调查员候审研究稿，未修改GitHub，未进入正式历史地图；研究窗与参考点均不能替代已审查的原始事实。*
'''
 return narrative

for tid,top in sorted(TOPICS.items()):
 (ROOT/'TOPIC_DOSSIERS'/f'{tid}.md').write_text(make_dossier(tid,top),encoding='utf-8')

writej(ROOT/'EVENT_CANDIDATES.json',{
 'schema':'love-british-tv-18c-assistant-a-event-candidates-v1',
 'period':[1700,1799], 'status':'research_only','publication_review':'not_submitted',
 'notice':'本资料为18C独立候审事件：日期只精确到已核年月；空坐标保留，含现代GPS仅为官方历史遗址代表点。不得无审核并入正式Atlas。',
 'ids_generated_for_local_research_only':True,'events':CANDIDATES
})
CSV_KEYS=['id','date_text','year','month','day','date_precision','topic_ids','title','actor_entities_text','historical_description_zh','historical_place_name','longitude','latitude','geo_precision','modern_reference_site','coordinates_support_sources','source_ids','source_urls','source_support_count','claim_crosscheck_status','evidence_status','previous_17c_story_ids','pr289_preexisting_acadia_candidate_ids','historical_control_boundary_verified','historical_line_or_route_surveyed','estimated_casualties_count','estimated_trade_sum','publication_status']
with (ROOT/'EVENT_CANDIDATES.csv').open('w',newline='',encoding='utf-8-sig') as f:
 writer=csv.DictWriter(f,fieldnames=CSV_KEYS);writer.writeheader()
 for e in CANDIDATES:
  item={k:(';' .join(e[k]) if isinstance(e[k],list) else '' if e.get(k) is None else e[k]) for k in CSV_KEYS}
  writer.writerow(item)
writej(ROOT/'SOURCE_REGISTRY.json',{
 'schema':'love-british-tv-18c-assistant-a-sources-v1',
 'status':'research_only','access_as_of':'2026-11-08',
 'reading_rule':'原稿未实际在档案馆亲阅；政府机构网页、现代转录法条、PDF搜索摘要、学术摘要与原件目录按字段区分，源不等同于所有主张已交叉核。',
 'independent_confirmation_rule':'S84与N21、S03与N06等同网址/同机构重复索引不可算两独立来源。',
 'sources':[SOURCES[k] for k in sorted(SOURCES)]
})
writej(ROOT/'MAP_CANDIDATES.geojson',{
 'type':'FeatureCollection','name':'18c_assistant_A_verified_modern_reference_points_only',
 'schema':'love-british-tv-map-research-only-v1',
 'status':'research_only','publication_review':'not_submitted',
 'metadata':{
  'meaning':'ONLY modern official historic site reference points with traceable sources, NOT event-GPS, ship routes, historical control or sovereignty',
  'excluded_unknown_coordinate_events':len(CANDIDATES)-len(GEO_FEATURES),
  'polygon_count':0,'linestring_count':0,'all_areas_unquantified':True,
  'location_reuse':'Parks Canada/NRCan official site positions originally carried into draft PR #289',
  'no_derived_polygons_from_modern_borders':True,
  'all_unknown_real_historical_boundaries':'no geometry; only separately supported dotted approximations after editorial review'
 },'features':GEO_FEATURES
})
writej(ROOT/'TOPIC_INDEX.json',{
 'schema':'18c-assistant-a-49-topic-index-v1','status':'research_only',
 'topics':[dict(t,dossier_path=f'TOPIC_DOSSIERS/{tid}.md',candidate_event_count=len(TOPIC_EVENT_MAP[tid]),candidate_geo_point_feature_count=sum(e['latitude'] is not None for e in TOPIC_EVENT_MAP[tid])) for tid,t in sorted(TOPICS.items())]
})
writej(ROOT/'REFERENCE'/'QUANTITATIVE_EVIDENCE.json',{
 'status':'research_only','notice':'数值均含原统计年窗、分母和限定；严禁据此推算严格1700—1799合计','entries':NUMERIC_EVIDENCE,
 'uk_flag_embarkations_1701_to_1775_estimate':410597+554042+832047,
 'uk_flag_embarkations_1700_to_1799_estimate':None,
 'uk_flag_embarkations_1776_to_1800_estimate_not_strict18c':748612,
})
writej(ROOT/'REFERENCE'/'PR289_ACADIA_EXISTING.json',{
 'source':'https://github.com/1959124923wyz-sys/love-British-TV/pull/289',
 'branch':'research/18c-master-agenda-acadian-map-20261105',
 'original_event_count':len(PR289_ACADIAN),'original_geo_reference_feature_count':14,
 'existing_candidates':PR289_ACADIAN,
 'mapping':{'semantics':'Narrative continuity crosswalk only, original IDs remain unchanged. Newly drafted candidates are not automatically extra occurrences.'},
 'status':'research_only'
})
writej(ROOT/'REFERENCE'/'SEVENTEENTH_CENTURY_ALIGNMENT.json',{
 'source':'GitHub main data/stories/serial/index.json plus original full story bodies read through GitHub connector',
 'seventeenth_century_articles_read_count':len(OLD_STORY_FILES),
 'read_predecessors':[{'id':k,'story_path':p,'editorial_continuity_note':OLD_STORY_SPECIFIC[k]} for k,p in OLD_STORY_FILES.items()],
 'topics_continuity':[{'topic_id':tid,'predecessor_stable_ids':t['previous_story_ids'],'old_articles_directly_read':[x for x in t['previous_story_ids'] if x in OLD_STORY_FILES], 'status':'story_research_continuity_not_1699_to_1700_territory_approval'} for tid,t in sorted(TOPICS.items())],
 'notes':['In the draft PR #289 all 36 prior series IDs are aligned to the 18C research topics; this dossier reads the 12 most directly relevant published original stories, not their primary archive manuscripts.','Never carry 1699 historical control polygons into 1700 without yearly audit.']
})

GAP_DOC=f'''# 第一调查员：1700—1799年美洲、大西洋研究缺口与来源冲突

截至2026-11-08。状态：**research_only**；没有修改或发布GitHub。A01—A22与C01—C27全部建立待审档案，具体已标为候选、目录或转录证据。

{GLOBAL_GAPS}

## 分专题逐件下一步原档任务（49项）
'''
for tid,t in sorted(TOPICS.items()):
 GAP_DOC+=f"\n### {tid}｜{t['title']}\n\n{NOTES[tid][3]} 本轮已列{len(TOPIC_EVENT_MAP[tid])}件事件候选，其中{sum(e['latitude'] is None for e in TOPIC_EVENT_MAP[tid])}件坐标为空；仍未逐件核所有相关原始卷宗，待核军队/公司/当地诉愿原件。\n"
GAP_DOC+='''
## 地理审查门禁

每一地点应按“历史地名→现代官方参考点→史料可证具体行动地点→当期实际控制范围”逐级处理。Point不推导Polygon，事件次序不推导航线；任何有来源但边线不确定的地理区域，只能建议主编未来用清晰标识的淡色虚线，并明确「声索／行动范围／未实测」。本批没有任何可独立审定的历史控制Polygon或历史船舶航线。

## 原档优先级

**P0**：英国国家档案馆Zong庭审案卷KB 122/479与CO奴役贸易原档；阿卡迪亚1755分区押船与船名清单；纽约1741原庭审；Garifuna 1797船名单。  **P1**：Royal African Company账本、南海Asiento合同；1749 Cornwallis官方文书、1715 Yamasee原住民外交、1737 Walking Purchase逐宗地契与原住民记录。 **P2**：1755—99殖民地各岛逐年报表、渔业季节账、HBC trade journals、黑人效忠派地籍、岛屿糖产税册及逃亡者通告。
'''
(ROOT/'GAPS_AND_CONFLICTS.md').write_text(GAP_DOC,encoding='utf-8')

readme=f'''# 爱英TV 18世纪第一调查员 | 本地候审成果

- **唯一仓库参考**：[love-British-TV](https://github.com/1959124923wyz-sys/love-British-TV)，**研究草稿**：[PR #289](https://github.com/1959124923wyz-sys/love-British-TV/pull/289)。全部研究成果仅写本地，仓库无更动。
- 读取项目规范 `AGENTS.md` 与 `docs/templates/16c-story-map-standard/README.md`，PR的 `research/18c/MAJOR_TOPICS.json`、`SOURCE_REGISTRY.json`、`CROSS_CENTURY_STORY_CONTINUITY.json`、阿卡迪亚候审三文件及17世纪原专题12篇。
- 目录组织：`TOPIC_DOSSIERS/`为49个详查专题；`EVENT_CANDIDATES.json/.csv`为事件级登记；`SOURCE_REGISTRY.json`为来源逐项读取深度；`MAP_CANDIDATES.geojson`只含官方现代历史遗址代表点；`REFERENCE/`含统计口径、17世纪承接与PR289既有ID对应；`GAPS_AND_CONFLICTS.md`集中存疑。
- **编审控制**：所有数据`research_only`。日期只保留证据实有的年/月/日。商馆不是领土，欧洲领土声索不是原住民土地让渡，统计窗不同不能相加，现代遗址GPS不当史事GPS，无经证政治边界或航线不绘面线。
- `REFERENCE/build_research.py`包含本轮整理的事件、来源及可重生文件的代码，保留以便主编独立审核；运行该代码会重建本地文件并且不写GitHub。
'''
(ROOT/'REFERENCE'/'README.md').write_text(readme,encoding='utf-8')

# Validate and audit saved artifacts before final status output.
summary={
 'topic_count':len(TOPICS),'A_topic_count':sum(t.startswith('E18-A') for t in TOPICS),
 'C_topic_count':sum(t.startswith('E18-C') for t in TOPICS),
 'distinct_candidate_event_count':len(CANDIDATES),
 'event_assignments_across_topics':sum(len(e['topic_ids']) for e in CANDIDATES),
 'dated_candidates_to_day':sum(e['date_precision']=='day' for e in CANDIDATES),
 'dated_candidates_to_month':sum(e['date_precision']=='month' for e in CANDIDATES),
 'dated_candidates_year_only':sum(e['date_precision']=='year' for e in CANDIDATES),
 'source_records_in_registry':len(SOURCES),
 'map_point_features':len(GEO_FEATURES),'map_unique_reference_positions':len({tuple(f['geometry']['coordinates']) for f in GEO_FEATURES}),
 'unmapped_event_count':len(CANDIDATES)-len(GEO_FEATURES),
 'map_polygons':0,'map_lines':0,
 'pr289_preexisting_acadian_candidates_acknowledged':len(PR289_ACADIAN),
 'pr289_preexisting_geo_features_acknowledged':14,
 'seventeenth_century_original_story_articles_read':len(OLD_STORY_FILES),
 'primary_manuscripts_personally_inspected':0,
 'release_status':'research_only / not_submitted / no GitHub modifications'
}
assert sum(summary[x] for x in ['dated_candidates_to_day','dated_candidates_to_month','dated_candidates_year_only'])==len(CANDIDATES)
assert len(list((ROOT/'TOPIC_DOSSIERS').glob('E18-*.md')))==49
assert len(json.loads((ROOT/'EVENT_CANDIDATES.json').read_text(encoding='utf-8'))['events'])==len(CANDIDATES)
assert all(f['geometry']['type']=='Point' and f['properties']['area_sqkm'] is None for f in GEO_FEATURES)
assert set(e['id'] for e in CANDIDATES)==set(row['id'] for row in csv.DictReader((ROOT/'EVENT_CANDIDATES.csv').open(encoding='utf-8-sig',newline='')))
writej(ROOT/'REFERENCE'/'VALIDATION.json',{'summary':summary,'result':'PASS','all_49_topic_reports_exist':True,'all_event_source_ids_resolve':True,'unknown_coordinates_are_null':True,'no_unverified_polygons_or_lines':True,'github_write_operations':0})
progress=f'''# 爱英TV | 第一调查员 A/C 范围 | 工作状态

**保存时间**：2026-11-08（本次对话本地执行）。 **仓库写操作**：0。**研究等级**：`research_only`，所有事件均待主编核原始卷宗、地图与出版审核。

## 已完成及本地文件

- A01—A22：**{summary['A_topic_count']}/22**专题各有单独中文档案。
- C01—C27：**{summary['C_topic_count']}/27**专题各有单独中文档案。
- `TOPIC_DOSSIERS/`：**49篇**，每篇背景、决策、具名行动、现代点位、相关人物、受害群体、抵抗、经济后果、长期影响和下一步缺口。
- `EVENT_CANDIDATES.json`、`EVENT_CANDIDATES.csv`：**{len(CANDIDATES)}件**候审事件（跨专题关联计**{summary['event_assignments_across_topics']}次**；日级**{summary['dated_candidates_to_day']}**、月级**{summary['dated_candidates_to_month']}**、年级**{summary['dated_candidates_year_only']}**）。含明确的连续性观察节点，不冒充单年行政事实。
- `SOURCE_REGISTRY.json`：**{len(SOURCES)}个**唯一来源ID；给出实际可见网页、学术摘要、数字法条、馆藏目录等访问深度。**亲阅原馆纸本/手稿原卷：0份**。
- `MAP_CANDIDATES.geojson`：**{len(GEO_FEATURES)}个**候审Point要素、**{summary['map_unique_reference_positions']}个**唯一现代官方遗址参考坐标；其他**{summary['unmapped_event_count']}件**保持空坐标；历史Polygon**0**、路线LineString**0**。
- `REFERENCE/QUANTITATIVE_EVIDENCE.json`：**{len(NUMERIC_EVIDENCE)}组**来源统计与口径限制。17世纪旧专题**{len(OLD_STORY_FILES)}篇**已读取对应原文并记录连续性，PR289旧阿卡迪亚**18项事件/14项参考点**作为前序成果登记。
- `GAPS_AND_CONFLICTS.md`：**22条**跨专题争议与49专题独立后续原档问题。
- `REFERENCE/build_research.py`：本轮数据编排及文件生成代码；`REFERENCE/VALIDATION.json`：保存后的结构检查记录。

## 未完成 / 需要继续核实

- 不能声称完成全年逐航次、逐笔地产、逐家种植园、逐日殖民法庭的穷尽核档；现有**{len(CANDIDATES)}件**只是可追溯事件候选而非49个专题的彻底结束。
- 原档未逐页核全部死亡、奴役、税额、作战战斗范围、逐年政治实控；目前不批准任何18世纪严格总人口/收益，也不画未核历史疆界与海上路线。
- PR289的阿卡迪亚已有研究保留稳定ID，不重复对同一次驱逐求总数；本轮同一历史事实的新增候选只作为档案深化和交叉索引。
- 各候审事件`claim_crosscheck_status`仍为逐主张独立资料审计待做，即便列出两份链接也不声称所有细节已经双证确证。

## 下一批优先行动（供主编或接任者）

1. 先处理**1755阿卡迪亚押船实录、1797 Garifuna强制迁徙船单、1781 Zong案卷、1741纽约法院原卷**，这是具名受害者、日月与GIS最可能有实质增益的高优先级档案。
2. 再逐港筛取 SlaveVoyages **1700—1799**航次而不是25年含1800的宽窗；从TNA商业名册建立船主—船名—强迫登船人群数据。
3. 法律类对照1705弗吉尼亚、1709/1733巴巴多斯、1760/1788牙买加原印本逐条生效、执行和地域适用，补商业获益与抵抗者证词。
4. 地图按官方史址点→原件地图→逐地军占范围的门禁推进；若只可证概略边缘，只提交**虚线参考方案**，不承认纸面划界为已核实控。

全部任务记录是本轮本地保存状态，不表示远程仓库已收到任何新成果。
'''
(ROOT/'PROGRESS.md').write_text(progress,encoding='utf-8')

# Persist an explicit inventory with checksums, then package in one zip with the requested folder prefix.
inventory=[]
for p in sorted(ROOT.rglob('*')):
 if p.is_file() and p.name!='INVENTORY.json':
  b=p.read_bytes()
  inventory.append({'path':p.relative_to(ROOT).as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
writej(ROOT/'REFERENCE'/'INVENTORY.json',{'generated_at':'2026-11-08','files':inventory,'file_count_excluding_inventory':len(inventory),'output_schema_validation':'PASS'})

zip_path=ROOT.parent/'18c_assistant_A_americas.zip'
with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=7) as z:
 for p in sorted(ROOT.rglob('*')):
  if p.is_file():z.write(p,arcname=f'{ROOT.name}/{p.relative_to(ROOT).as_posix()}')
assert zipfile.is_zipfile(zip_path)
with zipfile.ZipFile(zip_path) as z:
 assert z.testzip() is None
 names=z.namelist()
 assert any(x.endswith('EVENT_CANDIDATES.json') for x in names)
 assert len([x for x in names if '/TOPIC_DOSSIERS/E18-' in x and x.endswith('.md')])==49
print(json.dumps({'zip_file':str(zip_path),'zip_bytes':zip_path.stat().st_size,'zip_members':len(names),'summary':summary},ensure_ascii=False,indent=2))
