#!/usr/bin/env python3
"""Finalize and validate seventh-round research; no GitHub writes. Source-limited, local only."""
from pathlib import Path
from collections import Counter,defaultdict
import json,csv,hashlib,zipfile,datetime,re,os
R=Path('/mnt/data/18c_assistant_A'); ZIP=Path('/mnt/data/18c_assistant_A_americas.zip')
EV=R/'EVENT_CANDIDATES.json';SR=R/'SOURCE_REGISTRY.json';TI=R/'TOPIC_INDEX.json';GJ=R/'MAP_CANDIDATES.geojson'
ev=json.loads(EV.read_text()); reg=json.loads(SR.read_text()); idx=json.loads(TI.read_text());gj=json.loads(GJ.read_text())
# Remove chronological placeholder, which is explicitly not an individual 1780 event. Retain in research dossier narrative only.
bad='E18A7-1780-NY-JERSEY-PRISON'
if any(e['id']==bad for e in ev['events']):
 ev['events']=[e for e in ev['events'] if e['id']!=bad]
 for s in reg['sources']:
  s['supported_event_candidate_ids']=[q for q in s.get('supported_event_candidate_ids',[]) if q!=bad]
 for topic in idx['topics']:
  if topic['id']=='E18-C17':
   topic['v7_new_events_count']=sum(e.get('local_research_round')==7 and topic['id'] in e.get('topic_ids',[]) for e in ev['events'])
   topic['candidate_event_count']=sum(topic['id'] in e.get('topic_ids',[]) for e in ev['events'])
 # Preserve research trace that this event was deliberately withdrawn, not silently disappeared
 (R/'REFERENCE'/'WITHDRAWN_EVENT_V7.json').write_text(json.dumps({'withdrawn_id':bad,'reason':'Was an approximate 1780 research marker for prison ship Jersey, not a verified new event with a concrete 1780 action. Retained actual prison ships system event in 1776 candidate and narrative; no invented 1780 event.'},ensure_ascii=False,indent=2)+'\n')
# Clear historical date entry conflicts only in claimed precision not in source event metadata.
for e in ev['events']:
 if e['id']=='E18A7-1761-CAR-1761-DOMINICA':
  e['title']='英国海陆军远征多米尼克的欧洲殖民驻点'
  e['historical_description_zh']=e['historical_description_zh'].replace('法属多米尼克','多米尼克')
# Rewrite CSV with same schema as json
cols=[]
with (R/'EVENT_CANDIDATES.csv').open(newline='',encoding='utf-8-sig') as f:cols=csv.DictReader(f).fieldnames
cols=list(dict.fromkeys(cols+[k for x in ev['events'] for k in x]))
with (R/'EVENT_CANDIDATES.csv').open('w',newline='',encoding='utf-8-sig') as f:
 wr=csv.DictWriter(f,fieldnames=cols,extrasaction='ignore');wr.writeheader()
 for x in ev['events']:
  wr.writerow({k:(json.dumps(v,ensure_ascii=False) if isinstance(v,(list,dict)) else '' if v is None else v) for k,v in x.items()})
new=[x for x in ev['events'] if x.get('local_research_round')==7]
# Retain original status, not overwrite earlier research publication state
for t in idx['topics']:
 t['candidate_event_count']=sum(t['id'] in e.get('topic_ids',[]) for e in ev['events'])
 t['v7_new_events_count']=sum(t['id'] in e.get('topic_ids',[]) for e in new)
 t['last_local_round']=7
for p,v in [(EV,ev),(SR,reg),(TI,idx)]:p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
# Topic proposals beyond 49 original numbered subjects; not altering main atlas or editorial PR
proposals=[
 ('V7-P01','1702—1728英属卡罗来纳攻击西班牙佛罗里达原住民传教村与劫掳人口','Florida/Carolina 1702–1728','E18-C21','英殖民军事、原住民盟军与Apalachee/Guale/Yamasee政治权利'),
 ('V7-P02','1704新英格兰袭击阿卡迪亚村庄与1755驱逐的前史','Acadia 1704','E18-C01','Church军袭击Beaubassin与Grand-Pré,不重做阿卡迪亚主专题'),
 ('V7-P03','1756宾夕法尼亚民兵Kittanning袭村及莱纳佩地方自治','Pennsylvania 1756','E18-C25','具名村镇、火攻与后续地产转移'),
 ('V7-P04','1775英国皇家海军焚毁法尔茅斯的命令、实施与房产损失','Maine 1775','E18-C17','皇家海军作战命令、当日日记和财产账'),
 ('V7-P05','1776—1783纽约港英国囚船、拘押死亡与战争司法','NY harbor 1776–1783','E18-C17','Wallabout Bay/Jersey/Thomas Dring; 具体年度逐船须核'),
 ('V7-P06','1779英国海军惩罚性攻击康涅狄格沿海城镇','Connecticut 1779','E18-C17','New Haven/Fairfield/Norwalk逐日事件与居民证词'),
 ('V7-P07','1778—1782英军南方殖民港城的占领、监狱船和财政','Georgia/Carolina 1778–1782','E18-C17','Savannah/Charleston港、围城、效忠政策'),
 ('V7-P08','1781英国Arnold远征焚毁Richmond与New London','Virginia/Connecticut 1781','E18-C17','档案印刷损害和Groton被杀的非洲裔守军'),
 ('V7-P09','1782英国撤离Charleston时忠诚派奴隶主强制运走被奴役者','Charleston 1782','E18-C18','区分被奴役人口和已经自由的黑人效忠者'),
 ('V7-P10','1761—1797英国在小安的列斯群岛的入侵与英法殖民地转移','Lesser Antilles 1761–1797','E18-A19','Dominica/Martinique/Tobago/St Lucia/Trinidad 的具体换旗'),
 ('V7-P11','1793—1798英国干涉圣多明各革命和恢复奴役制度的军事企图','Haiti 1793–1798','E18-A18','Jérémie、Môle St Nicolas、Port-au-Prince与海地军民抵抗'),
 ('V7-P12','1795—1796英国海军参与镇压Grenada及St Vincent反抗','Grenada/St Vincent 1795–1796','E18-A15','逐艘战舰日志与Kalinago海上补给破坏'),
 ('V7-P13','1796英国占领圭亚那沿岸荷属殖民地与奴役种植园','Guiana 1796–1799','E18-A19','Demerara/Essequibo/Berbice三地投降和制度连续'),
 ('V7-P14','1749—1763英军扩大北美各据点与原住民土地协商的关系','Ohio/Acadia 1749–1763','E18-C11','Fort Pitt与未签署让地的民族分别记录')]
proposals.extend([
 ('V7-P15','1739—1741英国皇家海军袭击巴拿马Portobelo与哥伦比亚Cartagena','Spanish Caribbean mainland 1739–1741','E18-A19','海军掠获/临时占领/殖民地防御与英国错误胜利宣传'),
 ('V7-P16','1781年英国侵占圣尤斯特歇斯岛及犹太商人驱逐','St Eustatius 1781','E18-A19','Royal Navy战利品、商品没收、族群差别处置与议会异议')])
props={'schema':'18c-assistant-a-expanded-major-topic-proposals-round7','publication_status':'research_only','base_topic_family_count':49,'proposals':[{'proposal_id':i,'title_zh':t,'region_time':region,'existing_parent_topic_id':p,'research_focus':focus,'source_link_policy':'see matching E18A7 event candidate source_ids; no independent publish/territory claim','new_editorial_topic_id_assigned':False} for i,t,region,p,focus in proposals]}
(R/'PROPOSED_ADDITIONAL_TOPICS_V7.json').write_text(json.dumps(props,ensure_ascii=False,indent=2)+'\n')
# 13 deep dive reports. Narratives are author syntheses cross-checked against listed sources; no unsourced quantitative totals.
cases=[
 ('01-FLORIDA-INDIGENOUS-SLAVING', '1702—1728｜卡罗来纳对佛罗里达的军事袭击与原住民奴役', ['FL-1702','FL-1703','FL-1704','FL-1705','FL-1715','FL-1728'],
 '英属卡罗来纳的殖民者试图利用与西班牙佛罗里达的军事竞争扩大港口势力及被俘人口交易。1702年卡罗来纳议会鼓励远征参与者分享掠获品及被迫奴役的人口，随后James Moore率部围攻圣奥古斯丁；城堡未被攻取，英军撤离时焚毁城市。1704年行动转向Apalachee的传教村及原住民政治网络。',
 '必须区分Moore率领的英属殖民军、自己参与战争且拥有独立政治动机的Creek/Apalachicola盟友、Apalachee抵抗者以及西班牙驻军。San Luis的焚毁系当地居民和西班牙驻军为防落入英军而自行拆毁，不能归责为英军亲自焚城。1715年Guale首领Jospogue的家人遭奴役是具名微观受害，原交易、赎回档案尚待核。',
 '诸传教村只是有证地点；英方远征没有据此获得佛罗里达内陆实控。巨额俘虏人数仍有口径争议；查找1702州议会原决议、Moore行动记与西班牙mission visitas，需兼用当代Apalachee社区材料。'),
 ('02-ACADIA-1704-BEFORE-DEPORTATION','1704｜阿卡迪亚前驱战事：Beaubassin与Grand-Pré',['ACAD-1704'],
 '新英格兰殖民军Benjamin Church在1704年沿阿卡迪亚殖民聚落实施袭击，先后涉及Beaubassin与Grand-Pré。加拿大公园局叙述支持上述地方行动，但并未证明此时英国已控制Mi’kma’ki全境。',
 '与1755年新斯科舍殖民政府的正式驱逐政策分别记录：1704是战争袭击，1755是实施多处系统性强制迁移。Mi’kmaq与Wolastoqiyik条约政治不从英国和法国之间的占领叙事中消失。',
 '地点使用旧阿卡迪亚遗址参考，不追加任意海岸线或烧毁建筑GPS。继续核Church远征日记和Parks Canada跨世纪同名村落对应旧专题ID。'),
 ('03-KITTANNING-1756-LENAPE','1756｜Kittanning火攻、莱纳佩抵抗及殖民报复',['PA-KITTAN'],
 'Pennsylvania的殖民民兵1756年9月8日由John Armstrong攻击Allegheny河畔Kittanning/Attiqué的Lenape聚落。当地既是原住民生活与贸易网络的一部分，也曾成为反击英国殖民定居者的武装活动区域。',
 '宾州殖民部队摧毁了具名聚落，但不能从这一日战争行动推论所有Lenape认同法或英王对整片河谷拥有主权。地方历史会和县政府规划文件支持日期与地名，原双方伤亡统计仍须另核。',
 '应寻找Armstrong战报、殖民议会报销和被毁村庄地图，以及Lenape部族保存的自有史料。历史村镇可找官方定位点，但本轮未把现代县界作为1700年代军控面。'),
 ('04-FALMOUTH-ROYAL-NAVY','1775｜皇家海军法尔茅斯焚城事件：命令、证词与毁损',['MAINE-FALMOUTH'],
 '皇家海军Graves的海岸惩罚性命令与Henry Mowat的实际攻击可从军官次日向上级呈报以及镇民同日私人日记交叉追溯。1775年10月18日英舰炮击并纵火焚毁Falmouth Neck（今Portland）民居和公共建筑。',
 '下令袭击更多城镇的纸面计划与唯一实际攻击的Falmouth必须区分。当地居民被迫撤离，房屋被毁，战争期间民间财产损失可以通过地契、赔偿诉求和房产税登记复核；数目未核算入总损失。',
 'Maine Historical Society的Captain Mowat档与Stephen Longfellow当日日记是真实馆藏，网页机构摘录与原件高清图像应注明阅读层次；旧建筑的精确街址缺同时代配准，不画城市焚毁Polygon。'),
 ('05-NY-HARBOR-PRISON-SHIPS','1776—1783｜纽约港英国战俘船与被拘押者死亡',['NY-PRISONSHIPS'],
 '英国驻纽约军队与皇家海军将大量俘虏置于Wallabout Bay和港内改装废船，拘押对象包括大陆军、水手、私掠船员及部分平民。Thomas Dring等幸存者留下船内空间、食物及染病情况的回忆。',
 '港内军用囚船的制度史与具体Jersey船的使用年份、一次次病亡必须分清。美国国家公园管理局对广为流传的死亡人数给予纪念性介绍，但没有给出逐船逐月完整分母，故数据库不填一个所谓精确死亡总数。',
 '核查ADM 51/军方战俘押送清册、Dring原书不同版本与墙外湾土地遗骸记录。官方NPS网页把Jersey写作240门炮舰显然异常，不能搬用这一明显有误的技术细节。'),
 ('06-CT-COASTAL-PUNITIVE-RAIDS','1779｜康涅狄格沿岸三城掠夺与焚毁',['CT-NEW-HAVEN','CT-FAIRFIELD','CT-NORWALK'],
 '英国将纽约据点作为出发地，William Tryon率领的军队陆续袭击New Haven、Fairfield、Norwalk。馆藏与地方居民证词支持在7月7—8日Fairfield广泛焚毁住房与商业建筑，Norwalk在7月11—12日遭大规模损毁。',
 '应区分英国正规军、德意志辅助军与保皇派辅助人员的具体行为；城市居民、当地民兵、神职人员及拥王居民有不同政治选择。英军称目标是打击海岸反英军事活动和物资，但实际造成大批民用建筑被毁。',
 'New Haven、Fairfield、Norwalk需分别绘制城市代表点。Fairfield住民证词原卷与Connecticut报纸、Tryon报告将用于校正被毁建筑统计；Norwalk“11日/12日焚烧”争议只取时间窗，不编造精确焚烧开始分钟。'),
 ('07-BRITISH-SOUTHERN-CAMPAIGN','1778—1780｜萨凡纳与查尔斯顿的英国围城和军事控制',['GEORGIA-SAVANNAH','SC-CHARLESTON','SC-MONCKS'],
 '英国战略从北方港口延伸至南方种植园及海港。1778年12月29日英军夺取Savannah；1780年查尔斯顿围城中，4月1日修壕、4月8日海军突破炮台、4月13日炮击、4月14日切断撤路，5月12日守军投降。',
 '占领查尔斯顿的英军随后拘押大批战俘，部分在拥挤的监狱船内死亡。英军取得海港和军用据点，也试图争取忠诚派人力和南方农业产出，然而乡间政治忠诚、奴役人口身份与原住民领土应分别对待。',
 '查尔斯顿港和Savannah可落官方现代城市代表点，但1780年城墙、营垒和英军控制下各地农庄边界均需古地图配准。不同来源的战俘人数、武器数、伤亡人数不可同口径相加。'),
 ('08-RICHMOND-NEWLONDON-1781','1781｜英军两处烧毁行动与非洲裔守军',['VA-RICHMOND','CT-NEWLONDON','CT-GROTON'],
 'Benedict Arnold转投英方后于1781年1月5日前后进攻Richmond并破坏军资和烟草，还波及州政府依赖的Dixon/Nicolson印刷事务。九月六日Arnold又带英国部队对New London及河对岸Groton发起突袭。',
 'Connecticut州立图书馆明确记载William Ledyard与非洲裔士兵Jordan Freeman在Fort Griswold被杀。有关Ledyard被自己佩剑杀害的故事属于有争议的后世说法，应保留来源差异；地方民兵及平民的防卫不应被英国正规军叙述完全覆盖。',
 'Richmond的1月5日入城与LOC 1月6—10日整个攻势时间窗不矛盾，但仍应核原始行军日记。New London与Groton分别成两个位置，不绘横跨整条河的占领面。'),
 ('09-CHARLESTON-ENSLAVED-EVACUATION','1782｜查尔斯顿撤军、忠诚派迁移与被奴役人口转运',['SC-CHARLESTON-EXIT','SC-CHARLESTON-ENSLAVED'],
 '1782年12月14日英国军队从Gadsden’s Wharf完成撤出Charleston；美国国家公园管理局记载忠诚派随船出走，另有5000余名非洲裔被转移，其中多数仍为忠诚派奴隶主掌握的人身财产。',
 '同一撤军既包含英方从奴隶制社会撤出的政治结果，也包含强迫把他人带往英帝国其他殖民地的个人灾难。部分非洲裔此前逃往英国战线并获得自由，不能把这批自由人士与被带走的被奴役者统一计算为单一人口类型。',
 '约14000全部登船、约4200忠诚派、5000余非洲裔是同一来源不同交叉人口集合，不用加法产生新总人数。航线、运送目的地和逐船乘客名单需要运输船册；地图只列Gadsden’s Wharf现代地名，未核具体码头战时坐标则空值。'),
 ('10-CARIBBEAN-CONQUEST-AND-SLAVERY','1761—1797｜小安的列斯群岛殖民权转换、种植园和战争',['CAR-1761','CAR-1762','CAR-1763','CAR-1793','CAR-1794','CAR-1796','CAR-1797'],
 '七年战争和法国革命战争时期，英国通过海军、陆军攻击相继控制或短期占领Dominica、Martinique、Tobago、St Lucia、Trinidad等不同岛屿。1794年Martinique攻城时，英国与一部分反法国革命废奴政策的殖民庄园主结盟。',
 '要把“欧洲殖民当局换旗”“被奴役者所处法律制度是否改变”“原住民及逃亡者武装行动”区别记录；英军夺下一处港堡不等于全岛原住民失去土地政治自主。1793夺Tobago和1797夺Trinidad分别有英国国家陆军博物馆馆藏图画题名与战例说明。',
 '1761 Dominica的法英归属在条约以前具有特殊性质，不能简单标为英国攻取既成的法国主权岛。多岛屿未得有据逐日占领界线，保留单点或无坐标，无任何跨岛主权Polygon。'),
 ('11-SAINT-DOMINGUE-INVASION','1793—1798｜英国入侵圣多明各与恢复奴役制度的企图',['HAITI-1793','HAITI-1794','HAITI-1798'],
 '英国军队于1793年在法属Saint-Domingue若干沿海港口建立占领据点，在部分殖民庄园主支持下试图保住对岛内劳动力的奴役制度。行动延伸到Jérémie、Môle-Saint-Nicolas与Port-au-Prince等地。',
 '海地革命参与者以及获得自由的黑人武装组织具有独立的战略目标，不能写成英法战争的被动附属。英国1798年撤出主要沿海据点，显示英军原先未实现全岛军事征服或永久英属主权。',
 '此项依赖大学研究PDF检索摘要及美国国会图书馆原书目录，尚未逐页核卷，尤其1794年6月4日和1798年各港撤离日期需由战斗日志重新校准。海地沿岸多个港口保持空坐标及逐点核证。'),
 ('12-GARIFUNA-NAVAL-BLOCKADE','1795—1796｜皇家海军镇压Grenada与St Vincent抗争',['VINCENT-1795','VINCENT-1796'],
 'Douglas Hamilton的同行评审研究汇引英国海军日志，显示英军舰艇攻击圣文森特Kalinago/Black Carib运输独木舟、岸上集会及与欧洲革命力量之间的联系，以断绝反抗者跨岛支援。',
 '英军行动涉及地方自治、战争俘虏和随后Garifuna强制流放。对于海军日志列出的船只毁坏数，只能记录对应行动、日期和计数对象；不能等同于当场被杀人数或推断驱逐过程中全部死亡人数。',
 '文献引用ADM档案但本批没有亲阅ADM原卷。航船路线、岸炮射击角度、Garifuna被拘地点需原逐页日志和航海地图方可制图。'),
 ('13-GUIANA-1796-SLAVE-PLANTATIONS','1796—1799｜英军夺取荷属圭亚那种植园殖民地',['GUY-1796','GUY-1799'],
 '1796英国军队在加勒比及南美北岸战争中接管荷属Demerara、Essequibo、Berbice，各地有不同投降时间。当地糖业与奴役劳动网络原本建立在荷兰殖民管理之上，英国取得港口控制后继续依赖原先庄园与拍卖设施。',
 '原住民族内陆社区与被奴役人口未因殖民总督换旗自动接受新君主主权。1799年Stabroek的Werk-en-Rust市镇整合是局部地产与行政发展，不是英国对圭亚那整片内陆完成测绘征服。',
 '三处殖民地降服日主要依赖19世纪海军史及国家信托机构，圭亚那议会二手年表存在1795/1796年份争议。必须找各地殖民议事会与海军正式投降书原件再批准精准日期。')
]

cases.extend([
 ('14-PORTOBELO-CARTAGENA-1739-1741','1739—1741｜英国皇家海军对西属加勒比港口的袭击与失败',['PORTO-','CARTAGENA-'],
 '1739年英西进入海军殖民战争阶段，Edward Vernon指挥皇家舰队攻击西属加勒比要港Portobelo。英国海军实际于11月21日围攻港口防御、11月22日接受西班牙守军投降，拆毁军事设施并取得部分战利品。1741年又以更大规模远征进攻Cartagena de Indias，却未成功夺下城市。',
 '实际战事不仅有英国舰队和西班牙守军，也牵涉西属美洲港口的民间商业和被奴役人口。皇家格林尼治博物馆收藏了英国曾预先宣传Cartagena胜利的奖章，馆藏文字明确指出占领失败，因此奖章文字绝对不能作为地图换旗证据。',
 'Portobelo沿海军事行动只能标具名堡垒和港口，不能沿地图填出巴拿马大陆实控区。馆藏所记公款分配、投降条款一万美元与英国实际战利品净收益须分开核实。'),
 ('15-SAINT-EUSTATIUS-1781-MERCHANTS','1781｜英国圣尤斯特歇斯岛占领、财物没收与犹太居民驱逐',['STATIA-'],
 '1781年2月3日英国海军上将George Brydges Rodney及陆军John Vaughan攻占荷兰自由贸易港St Eustatius。该港是加勒比、欧洲和北美间重要转运站，英方查封大量在港货物、储藏设施和船只。',
 '受害人包括荷兰、英国籍商人和塞法迪犹太居民。独立学术论述援引2月13日英军集中搜查犹太男性户主、驱逐部分商人的证据；2月16日社区还提出具名请愿，质疑处罚法律依据。对Rodney是否主要出于宗教仇恨动机有学术争论，但没收和集体区别对待已获支持。3月30日英国王室限缩合法没收财产的指示不等于实际已返还财物。',
 '英国舰队占领的是荷兰港城与军事设施，不能把现代圣尤斯特歇斯岛全图当成精准1781年实控边界；荷兰原有商贸设施、黑人奴役劳动和自由群体需单列。英军货物估值、后续拍卖净额与商人诉讼判决仍应留null，优先查CO 318/7-8、ADM 1/314、奖品法庭和议会文字。')])
DD=R/'DEEP_DIVES_V7';DD.mkdir(exist_ok=True)
slist={s['id']:s for s in reg['sources']}
for fname,title,prefixes,bg,agency,mapnotes in cases:
 es=[e for e in new if any(e['id'].split('-'+str(e['year'])+'-',1)[-1].startswith(p) for p in prefixes)]
 # explicit matching fallback for event ids E18A7-1775-MAINE...
 if not es:es=[e for e in new if any(p in e['id'] for p in prefixes)]
 sources_used=list(dict.fromkeys(s for e in es for s in e['source_ids']))
 lines=['# '+title,'','**定位**：第七轮地区扩查深入调查；`research_only`。本篇为逐条有来源的事件候选整合，非已刊发地图故事。','',
 '## 背景—决策','',bg,'','## 实际行动、具名地点与时间','']
 if not es:lines.append('本篇主要为历史背景和方法校核：详细逐件记录见 `EVENT_CANDIDATES.json`；本篇具体ID可能需用全文题名查询。')
 for e in sorted(es,key=lambda x:(x['year'],x.get('month') or 0,x.get('day') or 0)):
  lines.extend([f'### {e["date_text"]}｜{e["title"]}', '',f'事件ID：`{e["id"]}`。{e["historical_description_zh"]}', '',f'**行为主体**：{e["actor_entities_text"]}；**地点**：{e["historical_place_name"]}；**证据来源**：{", ".join(e["source_ids"])}。',''])
  if e.get('source_conflict_note'):lines.extend(['**争议**：'+e['source_conflict_note'],''])
  if e.get('quantitative_qualification'):lines.extend(['**数字口径**：'+e['quantitative_qualification'],''])
 lines.extend(['## 受影响群体、抵抗、经济后果与长期影响','',agency,'','## 地图和统计审查','',mapnotes,'','本篇事件的经纬度若为空，即只能以历史地名呈现；一切现代遗址Point仅作为**现代位置参照**，未经核实的主权边界、种植园面积、强迫迁移航迹全部不绘Polygon/LineString。','','## 资料来源与实际阅读范围',''])
 for k in sources_used:
  s=slist.get(k,{});lines.append(f'- `{k}`：{s.get("title",s.get("scope", "史料"))}；{s.get("url","")}；**阅读层级**：{s.get("actually_read_scope",s.get("access_level","机构说明"))}。')
 lines+=['','## 下一阶段具体查核','', '依事件来源ID逐件查原卷或国家机构提供的数字副本，记录卷号、页码、原文异文与反方当事人证词；画地图之前再审历史名称及权属。','']
 (DD/(fname+'.md')).write_text('\n'.join(lines),encoding='utf8')
# Structured new claims and place names
new_src_rows=[];new_geo_rows=[]
for e in new:
 for sid in e['source_ids']:
  s=slist[sid]
  new_src_rows.append({'event_id':e['id'],'event_date':e['date_text'],'topic_ids':';'.join(e['topic_ids']),'claim':e['title'],'source_id':sid,'source_institution':s.get('institution',s.get('author_or_institution','')),'source_url':s.get('url',''),'actual_read_scope':s.get('actually_read_scope',s.get('access_level','')),'source_level':'institutional/scholarly online, manuscript original not inspected' if not s.get('manuscript_inspected') else 'see source registry','crosscheck_status':e.get('claim_crosscheck_status',''),'conflict_or_caveat':e.get('source_conflict_note','') or ''})
 new_geo_rows.append({'event_id':e['id'],'year':e['year'],'place_original':e.get('historical_place_name',''),'coord_lon':e.get('longitude'),'coord_lat':e.get('latitude'),'precision':e.get('geo_precision','no_verified_coordinate'),'source_ids':';'.join(e.get('source_ids',[])),'point_or_control':'modern_site_point_only' if e.get('longitude') is not None else 'text_only_no_map_geometry','historical_polygon_authorized':'false','historical_route_authorized':'false'})
def csvwrite(name,rows):
 with (R/name).open('w',encoding='utf-8-sig',newline='') as f:
  wr=csv.DictWriter(f,fieldnames=list(rows[0]));wr.writeheader();wr.writerows(rows)
csvwrite('CLAIM_SOURCE_MATRIX_V7.csv',new_src_rows)
csvwrite('MAP_PLACE_RESEARCH_V7.csv',new_geo_rows)
# new focus failures and methodological control
urlgroups=defaultdict(list)
for s in reg['sources']:
 url=s.get('url');
 if url:urlgroups[url.rstrip('/').lower()].append(s['id'])
dups={u:ids for u,ids in urlgroups.items() if len(ids)>1}
conflicts=[e for e in new if e.get('source_conflict_note')]
word='\n'.join([
 '# 第七轮｜地图地理、年代、史料冲突审查', '',
 '## 1. 版图分层', '',
 '军事袭击或城市短暂占领只构成具名地点的候审行动；外交/特许必须与实际驻军分开；非洲裔自由与奴役人口单独记账。',
 f'本轮新增事件 **{len(new)}**，其中有现代经纬度参考的事件 **{sum(x.get("longitude") is not None and x.get("latitude") is not None for x in new)}**，其余 **{sum(x.get("longitude") is None for x in new)}** 保持空值。',
 f'全库GeoJSON **{len(gj["features"])}** 个要素，未批准任何历史领土Polygon/LineString。',
 '', '## 2. 必须保留的冲突', '',
 '- 1704 San Luis撤离：西班牙驻军及Apalachee社区自行焚毁以避英军，不可写为英军纵火；准确7月31日系PDF摘录，整事件降为年级。',
 '- 1756 Kittanning：宾州民兵袭击是殖民军事行动，不能以此一项证明英国已永久控制俄亥俄流域。',
 '- 1775 Falmouth：Mowat/Graves下令攻击多城，仅Falmouth的实际焚毁已从原材料核出。',
 '- 1779 Fairfield：登陆7月7日、纵火7—8日；Norwalk火灾历史叙述存在11/12日差，使用时间窗。',
 '- 1781 Richmond：入城1月5日与LOC对整次攻势1月6—10日的记载需分别理解。',
 '- 1781 Groton：Ledyard死于战事可证，以其佩剑处死的具体说法有争议。',
 '- 1782 Charleston：五千余非洲裔撤离者包括仍被奴役及已获自由两种人，不能把全部视为已获解放或全部被贩卖。',
 '- 1793—1798 Saint-Domingue：大学PDF摘要与书籍目录不能冒充已读原始军令及舰船日志；英军对若干港口的短占非全岛征服。',
 '- 1796 圭亚那：部分议会年表记1795而海军叙述记1796，对投降契约原卷仍未核。',
 '- 若同一个URL被登记在多个旧ID下，应按来源**独立URL及机构作者**判定双证，不按ID数量简单认定。',
 '', '## 3. 原始网页中可确认的技术错误', '',
 '- NPS对HMS Jersey的说明出现“240-gun warship”，与18世纪军舰常识不符，该具体枪炮数被排除，保留拘押制度史及幸存者叙述线索。',
 '- 增量写作期间一度制作1780年Jersey囚船“阶段锚点”，因缺证明其1780年发生独立具名行动，已从EVENT_CANDIDATES删除；记录在REFERENCE/WITHDRAWN_EVENT_V7.json。',
 '', f'## 4. 第七轮逐件尚存具体冲突：{len(conflicts)}条', ''])
for e in conflicts:word+=f'\n- `{e["id"]}`：{e["source_conflict_note"]}\n'
word+='\n## 5. 原档申请和缺失字段\n\n向Maine Historical Society查Mowat report和市镇财产损失卷；向英国国家档案馆查ADM 51舰长日志、CO西印度议事会记录；向圭亚那国家档案馆查1796三殖民地降服和Court of Policy；向宾州档案查Kittanning战报与地籍；向法属殖民档案查Saint-Domingue各港逐日驻军。无法调阅的原卷不填写精确死亡、交易总额、航路和土地面积。\n'
(R/'GEO_AND_CHRONOLOGY_AUDIT_V7.md').write_text(word)
with (R/'GAPS_AND_CONFLICTS.md').open('a') as f:f.write('\n\n---\n\n'+word+'\n')
source_audit={'schema':'18c-assistant-source-audit-round7','source_entries_total':len(reg['sources']),'distinct_url_count':len(urlgroups),'duplicate_url_groups':len(dups),'duplicate_url_details':[{'url':u,'ids':v} for u,v in sorted(dups.items())],'new_source_ids':[s['id'] for s in reg['sources'] if str(s['id']).startswith('R7')],'caveat':'multiple source IDs or URLs from same research institution do not guarantee independent corroboration','primary_manuscripts_personally_inspected_this_round':0}
(R/'SOURCE_AUDIT_V7.json').write_text(json.dumps(source_audit,ensure_ascii=False,indent=2)+'\n')
# Consistency checks
E=ev['events'];SRC={s['id'] for s in reg['sources']};T={t['id'] for t in idx['topics']};IDS=[e['id'] for e in E];SIDS=[s['id'] for s in reg['sources']];G=gj['features']
assert len(IDS)==len(set(IDS)), 'duplicate event IDs'
assert len(SIDS)==len(set(SIDS)), 'duplicate source IDs'
assert len(T)==49
assert all(1700<=e['year']<=1799 for e in E)
assert all(set(e.get('source_ids',[]))<=SRC for e in E), 'missing source id'
assert all(set(e.get('topic_ids',[]))<=T for e in E), 'missing topic id'
assert all(e.get('publication_status')!='published' for e in new)
assert all(f.get('geometry',{}).get('type')=='Point' for f in G), 'Not allowed unauthorized geometry'
assert all(not f.get('properties',{}).get('fill_authorized',False) for f in G)
with (R/'EVENT_CANDIDATES.csv').open(encoding='utf-8-sig',newline='') as f:
 rows=list(csv.DictReader(f));assert len(rows)==len(E), (len(rows),len(E));assert {x['id'] for x in rows}==set(IDS)
assert len(list((R/'TOPIC_DOSSIERS').glob('E18-[AC]*.md')))==49
assert all((R/'TOPIC_DOSSIERS'/f'{t}.md').exists() for t in T)
counts=Counter(x['date_precision'] for x in E);counter=Counter(x['impact_category'] for x in new)
result={'run':'round7','local_research_state':'research_only','date':'2026-11-08','previous_events':407,'new_events_round7':len(new),'events_total':len(E),'new_sources_round7':len(reg['sources'])-335,'source_entries_total':len(reg['sources']),'source_distinct_urls':len(urlgroups),'original_topic_dossiers':49,'new_deep_dives_round7':len(cases),'proposed_additional_topics_round7':len(proposals),'geospatial_points_total':len(G),'event_candidates_with_coordinates':sum(x.get('longitude') is not None and x.get('latitude') is not None for x in E),'event_candidates_null_coordinates':sum(x.get('longitude') is None or x.get('latitude') is None for x in E),'date_precision_totals':dict(counts),'research_only_all_new_events':True,'no_polygons_or_linestrings':True,'source_id_validated':True,'topic_id_validated':True,'csv_json_parity_validated':True,'user_or_repo_github_write':'none'}
(R/'REFERENCE'/'VALIDATION_V7.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
# Concise handoff as most recent progress at top, historical existing progress preserved as audit
progress=R/'PROGRESS.md';older=progress.read_text();older=older.split('---\n\n',1)[1] if older.startswith('# 第七轮最新状态') and '---\n\n' in older else older
line=f'''# 第七轮最新状态（2026-11-08）\n\n**本轮地区扩查已完成并在本地保存。当前累计：{len(E)}件候审事件、{len(reg['sources'])}条来源记录（去重网址{len(urlgroups)}）、49个原A/C专题、额外{len(cases)}份第七轮深挖报告、{len(G)}个GeoJSON Point参考位置。**\n\n- 第七轮净新增：**{len(new)}件不同候选事件**、**{len(reg['sources'])-335}条来源记录**；新专题建议：{len(proposals)}项（尚未修改49个原始主题编号）。\n- 事件日期精度：{counts.get('day',0)}件日级、{counts.get('month',0)}件月级、{counts.get('year',0)}件年级。\n- 全部事件坐标为空：{result['event_candidates_null_coordinates']}件；已有参考坐标事件：{result['event_candidates_with_coordinates']}件。**没有新历史实控面Polygon和推测海路LineString**。\n- A01—A22 / C01—C27共49份原专题的适当章节已追加新事件；另见`DEEP_DIVES_V7/`。\n- 重点：1702—1728卡罗来纳袭击佛罗里达原住民传教村、1704阿卡迪亚先前战争、1756Kittanning、1775Falmouth、1779康州沿岸惩罚性掠袭、1776—1783纽约战俘船、1778—1782南方港口战争与奴役人口转运、1790年代小安的列斯群岛换旗与圣多明各干涉、1796荷属圭亚那占领及种植园制度延续。\n- 新文件：`CLAIM_SOURCE_MATRIX_V7.csv`、`MAP_PLACE_RESEARCH_V7.csv`、`GEO_AND_CHRONOLOGY_AUDIT_V7.md`、`SOURCE_AUDIT_V7.json`、`PROPOSED_ADDITIONAL_TOPICS_V7.json`、`REFERENCE/VALIDATION_V7.json`。\n- 待查：英方ADM/CO原始卷册、被奴役人口逐船名册、土地测量草图、战时民居损失清单、条约正本；详见地理审查与各深挖专题。\n- 本轮**未修改GitHub**；全部`research_only`且原档亲阅仍未全部完成。\n\n---\n\n'''
progress.write_text(line+older)
(R/'README_ROUND7.md').write_text(f'''# 爱英TV 18世纪第一调查员｜第七轮扩大调查包\n\n**用途**：只供主编离线审核研究，未发到网页、GitHub和正式Atlas。\n\n事件候选累计{len(E)}条；来源累计{len(reg['sources'])}条（去重网址{len(urlgroups)}）；49份原专题保留；本轮{len(cases)}篇新长文；{len(G)}个现代遗址点。\n\n## 目录导读\n\n- `EVENT_CANDIDATES.json/.csv`：逐行动候选与证据门禁，其他年份不应随意补行。\n- `SOURCE_REGISTRY.json`、`SOURCE_AUDIT_V7.json`：文献和实际阅读范围，重复链接审计。\n- `TOPIC_DOSSIERS/`：全部49个A/C原始专题及本轮内容续写。\n- `DEEP_DIVES_V7/`：13篇跨地区重大影响个案；直接按题名阅读。\n- `PROPOSED_ADDITIONAL_TOPICS_V7.json`：只提出14个待主编批准的新母题，不动项目既有编号。\n- `CLAIM_SOURCE_MATRIX_V7.csv`：第七轮逐事件对照来源的审查表。\n- `MAP_PLACE_RESEARCH_V7.csv`、`MAP_CANDIDATES.geojson`：历史地名与目前已核官方现代遗址点，无未经证实的多边形。\n- `GEO_AND_CHRONOLOGY_AUDIT_V7.md`及`GAPS_AND_CONFLICTS.md`：日期争议、人口数字和历史实控的不确定性。\n- `PROGRESS.md`及`REFERENCE/VALIDATION_V7.json`：状态和检验记录。\n\n## 统计规则\n\n上述来源是数据库记录数量，并非独立学者互证篇数；去重网址只用于查重，不自动作为第二个独立史料。多个记录针对同一大事件的不同日/不同地点/不同主体行动单列，禁止把事件条目数说成死亡人数。\n\n这份离线压缩包仅供历史研究候审（research_only）；GitHub未修改。\n''')
# Write validation before manifest, with predictable files, exclude self and zip
allfiles=sorted(p for p in R.rglob('*') if p.is_file() and p.name not in ('SHA256_SUMS_V7.txt','MANIFEST_V7.json'))
manifest={'schema':'18c-a-round7-local-manifest','generated_at':'2026-11-08','research_only':True,'file_count_excluding_manifest_and_sha':len(allfiles),'files':[{'path':p.relative_to(R).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in allfiles]}
(R/'MANIFEST_V7.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
(R/'SHA256_SUMS_V7.txt').write_text('\n'.join(f'{f["sha256"]}  {f["path"]}' for f in manifest['files'])+'\n')
# ZIP atomic replacement
zt=ZIP.with_suffix('.zip.tmp')
with zipfile.ZipFile(zt,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for f in sorted(p for p in R.rglob('*') if p.is_file()):
  z.write(f,arcname='18c_assistant_A/'+f.relative_to(R).as_posix())
with zipfile.ZipFile(zt) as z:
 assert z.testzip() is None
 members=z.namelist()
 assert len(members)==len(list(R.rglob('*')))-sum(p.is_dir() for p in R.rglob('*')), (len(members),'file_count')
 assert '18c_assistant_A/REFERENCE/VALIDATION_V7.json' in members
 assert '18c_assistant_A/PROPOSED_ADDITIONAL_TOPICS_V7.json' in members
assert zt.stat().st_size>100000
zt.replace(ZIP)
result['zip_member_count']=len(members);result['zip_bytes']=ZIP.stat().st_size;result['zip_sha256']=hashlib.sha256(ZIP.read_bytes()).hexdigest()
print(json.dumps(result,ensure_ascii=False,indent=2))
