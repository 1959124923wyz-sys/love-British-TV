from pathlib import Path
import json,copy,csv,collections,zipfile,hashlib,os,datetime
P=Path('/mnt/data/18c_assistant_A')
def read(f):return json.loads((P/f).read_text(encoding='utf-8'))
def write(f,o):(P/f).write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
E=read('EVENT_CANDIDATES.json');S=read('SOURCE_REGISTRY.json');T=read('TOPIC_INDEX.json');M=read('MAP_CANDIDATES.geojson');PR=read('PROPOSED_ADDITIONAL_TOPICS_V3.json')
for s in S['sources']:
 if s['id']=='V351':s['author_or_institution']='Historical Research / Oxford Academic (具体作者未核)'
# Additional authoritative museum/primary treaty documents
urls={s['url']:s['id'] for s in S['sources'] if s.get('url')}
newdocs=[('美国密歇根大学Clements Library','Guadeloupe 1759 British capture; May 1 dual capitulations','https://clements.umich.edu/exhibit/1759-britains-year-of-victories/case-13/','university_primary_manuscript_exhibit','馆藏目录与介绍：驻民及总督分开签1759-05-01投降协议；馆藏卷Frederick Mackenzie Papers Vol B，未逐页阅原卷'),('美国国会图书馆','Francophone Caribbean collections: Guadeloupe timeline','https://guides.loc.gov/francophone-caribbean-collections-library-of-congress/guadeloupe','national_library_history_timeline','网页编年记录1759—1763英军占领和1794反复争夺'),('英国皇家格林尼治博物馆','1759 Guadeloupe capture medal and Treaty of Paris context','https://www.rmg.co.uk/collections/objects/rmgc-object-38744','national_museum_historical_object','1759奖章、5月投降和1763归法条约背景'),('American Battlefield Trust','Treaty of Paris of 1763 Article VIII—British restitution of Guadeloupe','https://www.battlefields.org/learn/primary-sources/treaty-paris-1763','transcribed_primary_treaty','已读第VIII条：法国恢复瓜德罗普、马提尼克、玛丽加朗特、德西拉德；签约日不等于实物驻军撤离日')]
source_added=[]
for inst,title,url,typ,scope in newdocs:
 if url in urls:continue
 sid='V'+str(357+len(source_added));source_added.append(sid)
 S['sources'].append({'id':sid,'author_or_institution':inst,'title':title,'url':url,'type':typ,'actually_read_scope':scope,'manuscript_inspected':False,'read_scope_note':'核定的HTML馆藏说明或条约转录；未触及原稿原卷。','supported_event_candidate_ids':[],'supported_topic_ids':[],'access_verified_at':'2026-11-08','primary_source_type':typ=='transcribed_primary_treaty','separate_source_identity_note':'投降文书馆藏与讲述互相区分，不作独立复核人数。'});urls[url]=sid
# Proposed additional IDs must not collide existing A23 Sally A24 Havana
wanted=[('E18-A27','1765 Blackwall起义与1766殖民立法调查及1767 York/Cuffee赔偿法',['E18A3B-BLACKWALL-1765','E18A3B-LONG-REPORT-1766','E18A3B-YORK-CUFFEE-1767']),('E18-A28','1794英国入侵瓜德罗普、法国共和军反攻及解放者抵抗',['E18A3B-GUAD-INVASION-1794','E18A3B-GUAD-SURRENDER-1794','E18A3B-GUAD-HUGUES-1794','E18A3B-GUAD-FRENCH-RECAPTURE-1794'])]
eindex={e['id']:e for e in E['events']}
for t,title,ids in wanted:
 if not any(x['id']==t for x in PR['topics']):
  es=[eindex[k] for k in ids]
  PR['topics'].append({'id':t,'editorial_state':'proposed_only_not_in_PR_289','title':title,'source_checked_event_count':len(ids),'events':ids,'dated_start_year':min(x['year'] for x in es),'dated_end_year':max(x['year'] for x in es),'source_ids':list(dict.fromkeys(k for x in es for k in x['source_ids'])),'boundary_and_GIS_notice':'Local research proposal, not an approved master topic or any historical polygon.'})
# 1759 British capture and Feb 1763 treaty official papers
for id,date,title,desc,refs in [
('E18A3B-GUAD-1759-MAY1-CAPITULATIONS','1759-05-01','瓜德罗普庄园代表和法国总督签署分别的英国受降条款','密歇根大学Clements馆藏保存1759年5月1日瓜德罗普法国总督及居民代表两份投降协定。英军Barrington将军前已袭击海岸庄园；受降文件须和英军逐地占领、种植园主继续控制其庄园的社会事实分开。',['https://clements.umich.edu/exhibit/1759-britains-year-of-victories/case-13/','https://www.rmg.co.uk/collections/objects/rmgc-object-38744']),
('E18A3B-GUAD-1759-1763-ENSLAVED-PLANTATIONS','1759','英国在七年战争中占领瓜德罗普并通过贸易为当地种植园供应奴役劳动','美国国会图书馆编年确认1759—1763英国占领瓜德罗普。英军受降并未废除种植园奴役制度；其间英国商人输入被奴役非洲人的账目数须依来源与运输口径逐项核定，本事件不设置估算运量。',['https://guides.loc.gov/francophone-caribbean-collections-library-of-congress/guadeloupe','https://clements.umich.edu/exhibit/1759-britains-year-of-victories/case-13/']),
('E18A3B-PARIS-1763-CARIB-RESTITUTION','1763-02-10','巴黎和约第八条规定英国向法国归还瓜德罗普等加勒比岛屿','1763年《巴黎和约》第八条规定英国归还Guadeloupe、Marie-Galante、La Désirade及Martinique等，允许英国商人以特定时限处理地产和债务。签约日是欧洲法定决定，并非各岛英军实际离岛的精确日期。',['https://www.battlefields.org/learn/primary-sources/treaty-paris-1763','https://guides.loc.gov/francophone-caribbean-collections-library-of-congress/guadeloupe'])]:
 if id in eindex:continue
 e=copy.deepcopy(E['events'][-1]);y=int(date[:4]); mo=int(date[5:7]) if len(date)>4 else None;day=int(date[8:10]) if len(date)>7 else None
 source_ids=[urls[r] for r in refs]
 e.update({'id':id,'date_text':date,'year':y,'month':mo,'day':day,'date_precision':'day' if day else 'month' if mo else 'year','topic_ids':['E18-A19'],'title':title,'historical_description_zh':desc,'actor_entities_text':'英国皇家海陆军、法国驻军、加勒比种植园经营者及遭奴役劳动者','historical_place_name':'Guadeloupe and neighboring French Caribbean islands','longitude':None,'latitude':None,'modern_reference_site':None,'geo_precision':'no_verified_coordinate','coordinates_support_sources':[],'source_ids':source_ids,'source_urls':refs,'source_support_count':2,'claim_crosscheck_status':'institutional_two_sources_topic_level_not_all_subclaims','evidence_status':'evidence_linked_candidate_not_published','previous_17c_story_ids':['E6-T07-LEEWARD'],'pr289_preexisting_acadia_candidate_ids':[],'publication_status':'research_only','publication_review':'not_submitted','local_research_round':3,'scope_note':'捕获—条约归还：必须区分条约纸面与驻军实际交接年份。'})
 E['events'].append(e);eindex[id]=e
# fix previous 1794 short occupation statement, no implied 1795 occupancy
for sid,s in list((s['id'],s) for s in S['sources']):
 s['supported_event_candidate_ids']=[] if s.get('supported_event_candidate_ids') is not None else None
 s['supported_topic_ids']=[] if s.get('supported_topic_ids') is not None else None
sr={s['id']:s for s in S['sources']}
for e in E['events']:
 for sid in e['source_ids']:
  if sid not in sr:raise ValueError(f'missing source {sid} in {e["id"]}')
  s=sr[sid]
  if isinstance(s.get('supported_event_candidate_ids'),list):s['supported_event_candidate_ids'].append(e['id'])
  if isinstance(s.get('supported_topic_ids'),list):
   for tid in e.get('topic_ids',[]):
    if tid not in s['supported_topic_ids']:s['supported_topic_ids'].append(tid)
# Refresh 49 indexes
for topic in T['topics']:
 linked=[e for e in E['events'] if topic['id'] in e['topic_ids']]
 topic['candidate_event_count']=len(linked)
 topic['source_ids']=list(dict.fromkeys(topic.get('source_ids',[])+[z for e in linked for z in e['source_ids']]))
 topic['v3_new_events_count']=sum(e.get('local_research_round')==3 for e in linked)
 topic['candidate_geo_point_feature_count']=sum(topic['id'] in f.get('properties',{}).get('topic_ids',[]) for f in M['features'])
T['last_local_research_extension']={'research_round':3,'topic_index_refreshed':True,'total_event_ids':len(E['events'])}
# Details additional
p=P/'DEEP_DIVES_V3'/'GUADELOUPE_1759_1763.md'
p.write_text('''# 1759—1763英国占领瓜德罗普：双投降协议、奴役经济、和约归还\n\n**本地候审研究**；A19与跨世纪E6-T07-LEEWARD。\n\n## 背景与决策\n七年战争中英国海军和陆军联合攻打法属瓜德罗普。英将John Barrington对沿海种植园进行袭击，企图迫使法国殖民当局和种植园主投降。\n\n## 行动及日期\n- **1759年5月1日**：密歇根大学Clements Library展出两份分别由法国总督、殖民居民代表签署的投降条款馆藏索引，不能混成一份协议。\n- **1759—1763年**：美国国会图书馆编年确认短期英国占领。种植园的被奴役劳动依旧持续，英国商人跨洋供应奴役者有商业关系，但本档未核完整航次与具体总数。\n- **1763年2月10日**：《巴黎和约》第八条规定英国将瓜德罗普、Marie-Galante、La Désirade、马提尼克等归还法国，给英商以有限期整理债务地产；法定归还与军队实际离岛需分开。\n\n## 地点与人物\n瓜德罗普、Fort Royal、Basse-Terre；英军John Barrington、法国总督与庄园主、从事强迫种植园劳动的被奴役非洲人。未加入古代边界或测量错误的GPS。\n\n## 受害者、抵抗、经济后果\n奴役劳动者在英军受降协定及殖民统治下继续处于强制经济系统。岛屿生产扩大等研究结论尚待在奴役运输账、庄园收入与海关账交叉确认，暂不填未经验证的运输量或利润。\n\n## 长期结果\n1759年短时英国殖民占领须在1763和约阶段终止，不得简单沿用到1794年第二次短时夺取，亦不得根据岛屿轮廓计算1759确证实际占领平方公里。\n\n## 史料\n- Clements原始投降协议目录：https://clements.umich.edu/exhibit/1759-britains-year-of-victories/case-13/\n- 美国国会图书馆历史编年：https://guides.loc.gov/francophone-caribbean-collections-library-of-congress/guadeloupe\n- 皇家格林尼治博物馆1759征服纪念币：https://www.rmg.co.uk/collections/objects/rmgc-object-38744\n- 1763条约第八条全文：https://www.battlefields.org/learn/primary-sources/treaty-paris-1763\n''',encoding='utf-8')
a=P/'TOPIC_DOSSIERS'/'E18-A19.md';a.write_text(a.read_text(encoding='utf-8')+'\n\n## 第三轮新增1759—1763瓜德罗普专题\n另见`DEEP_DIVES_V3/GUADELOUPE_1759_1763.md`，新登记1759双投降、英军短时占领与1763第八条归还。必须同时区别1794英国第二次短时夺取。\n',encoding='utf-8')
with (P/'GAPS_AND_CONFLICTS.md').open('a',encoding='utf-8') as f:f.write('\n- **1759瓜德罗普双份投降文书**：Clements Library馆藏记居民代表和总督在1759年5月1日分别签降书；两份原件未逐页读取，英国控制每块种植园的具体日期仍未知。1763年2月10日条约第VIII条说明应归还各岛，不等于当日逐堡交付。\n')
with (P/'PROGRESS.md').open('a',encoding='utf-8') as f:f.write('\n- 第三轮最终收尾补核1759年瓜德罗普两份投降条款和1763《巴黎和约》第八条，另增1份深挖报告；两个新候审提案稳定ID设为E18-A27及E18-A28，不与既有A23(Sally)和A24(哈瓦那)冲突。\n')
# Write all JSON/CSV
write('EVENT_CANDIDATES.json',E);write('SOURCE_REGISTRY.json',S);write('TOPIC_INDEX.json',T);write('PROPOSED_ADDITIONAL_TOPICS_V3.json',PR)
EV=E['events'];sources=S['sources'];features=M['features'];date_count=collections.Counter(e['date_precision'] for e in EV);missing=sum(e['longitude'] is None and e['latitude'] is None for e in EV)
fs=list(dict.fromkeys(k for ev in EV for k in ev))
with (P/'EVENT_CANDIDATES.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=fs);w.writeheader()
 for ev in EV:w.writerow({k:json.dumps(v,ensure_ascii=False) if isinstance(v,(dict,list)) else v for k,v in ev.items()})
# hard validation
assert len(EV)==len(set(e['id'] for e in EV))
assert len(sources)==len(set(s['id'] for s in sources))
assert all((ev['date_precision']=='day')==(ev['day'] is not None) for ev in EV)
assert all(len(ev['source_ids'])>0 and all(sid in sr for sid in ev['source_ids']) for ev in EV)
assert all(ev['year'] in range(1700,1800) for ev in EV)
assert all(set(ev['topic_ids'])<=set(t['id'] for t in T['topics']) for ev in EV)
assert len(T['topics'])==49
assert all((P/t['dossier_path']).is_file() for t in T['topics'])
assert all(f['geometry']['type']=='Point' for f in features)
assert not any(f['geometry']['type'] in ('Polygon','LineString','MultiPolygon','MultiLineString') for f in features)
assert all(ev['area_sqkm'] is None for ev in EV)
assert all(ev['historical_control_boundary_verified'] is False for ev in EV)
assert all(f['properties'].get('area_sqkm') is None for f in features)
# coordinate count, unique physical sites
uniq=set(tuple(f['geometry']['coordinates']) for f in features)
assert len(features)==24 and len(uniq)==9
assert all(-180<=f['geometry']['coordinates'][0]<=180 and -90<=f['geometry']['coordinates'][1]<=90 for f in features)
# flat csv unique
with (P/'EVENT_CANDIDATES.csv').open('r',encoding='utf-8-sig',newline='') as f:csvlines=sum(1 for _ in csv.DictReader(f));assert csvlines==len(EV)
files=[p for p in P.rglob('*') if p.is_file()]
source_count=sum(1 for p in files if p.parent.name=='TOPIC_DOSSIERS');deep_count=sum(1 for p in files if p.parent.name=='DEEP_DIVES_V3')
summary={'date':'2026-11-08','research_round':3,'publication_state':'research_only','events_round1':158,'events_round2':213,'events_round3_final':len(EV),'net_new_vs_round2':len(EV)-213,'sources_round2':167,'sources_final':len(sources),'new_sources_vs_round2':len(sources)-167,'date_precision':dict(date_count),'topic_dossiers':source_count,'deep_dives_round3':deep_count,'proposed_extra_topics':len(PR['topics']),'map_point_features':len(features),'unique_official_modern_reference_sites':len(uniq),'events_without_coordinates':missing,'historical_polygons':0,'historical_routes':0,'source_registry_resolves':True,'csv_event_rows':csvlines,'source_urls_unique':len(set(s['url'] for s in sources)),'github_write_operations':0,'important_open_issues':['Garifuna 1797-04-11 vs 12','Guadeloupe 1794-04-09 vs 11 invasion','1767 York/Cuffee legal compensation but no actual payment documents','no accurate historic area polygons or ship lanes']}
write('REFERENCE/VALIDATION_V3.json',summary)
# Prepend latest progress index with prior snapshots still shown for traceability
progress=P/'PROGRESS.md';old=progress.read_text(encoding='utf-8')
prefix='# 当前最新总计｜2026-11-08 第三轮累计状态（旧版本数字见下方历史记录）\n\n'+f'- **{len(EV)}件事件候选**（较上轮213增加{len(EV)-213}件），**{len(sources)}条来源ID**（增加{len(sources)-167}条，独立网页URL {summary["source_urls_unique"]}个），**49份正式母题档案**与**{deep_count}份第三轮深挖报告**。\n'+f'- 日期精度：日级{date_count["day"]}，月级{date_count["month"]}，年级{date_count["year"]}。地图现代位置24个点要素／9处官方遗址参照坐标；{missing}件事件无坐标；历史多边形0、航路0。\n'+f'- 新增拟扩母题{len(PR["topics"])}项，但仍未进入PR #289原有49个编号。所有输出本地，**GitHub写入0**。Garifuna 1797抵岸11/12日之争仍保持月级候审。\n\n---\n\n'
if not old.startswith('# 当前最新总计'):
 progress.write_text(prefix+old,encoding='utf-8')
# Manifest with file-level sha256 (excluding itself)
manifest=[]
for p in sorted(P.rglob('*')):
 if p.is_file() and p.name!='MANIFEST_V3.json':
  by=p.read_bytes();manifest.append({'path':p.relative_to(P).as_posix(),'size_bytes':len(by),'sha256':hashlib.sha256(by).hexdigest()})
write('MANIFEST_V3.json',{'schema':'local-18c-investigator-archive-manifest-v3','status':'research_only','total_files_excluding_manifest':len(manifest),'files':manifest,'date':'2026-11-08'})
zip_path=Path('/mnt/data/18c_assistant_A_americas.zip')
with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=7) as z:
 for p in sorted(P.rglob('*')):
  if p.is_file():z.write(p,arcname='18c_assistant_A/'+p.relative_to(P).as_posix())
with zipfile.ZipFile(zip_path) as z:
 bad=z.testzip();assert bad is None
 assert len(z.namelist())==len(manifest)+1
 assert z.read('18c_assistant_A/REFERENCE/VALIDATION_V3.json')== (P/'REFERENCE/VALIDATION_V3.json').read_bytes()
summary.update({'zip_path':str(zip_path),'zip_size_bytes':zip_path.stat().st_size,'zip_file_count':len(manifest)+1,'zip_sha256':hashlib.sha256(zip_path.read_bytes()).hexdigest()})
print(json.dumps(summary,ensure_ascii=False,indent=2))
