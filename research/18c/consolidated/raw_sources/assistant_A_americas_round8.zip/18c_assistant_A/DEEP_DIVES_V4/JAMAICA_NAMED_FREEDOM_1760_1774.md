# 1760—1774年牙买加具名人员：殖民议会解放法、镇压奖励和女性个人经历

**本地研究阶段**：第四轮，2026-11-08。**研究等级**：`research_only`。**相关专题**：E18-A07, E18-A06。

**史料层级**：读取了所列在线原始法律／条约转录、政府历史机构文章；不是原始纸本逐页核验。殖民法规记录的是条文、官员陈述及预期结果；未发现实际军政执行和付款凭证时均记为未知。

## 一、历史背景与17世纪承接

“镇压1760起义”若只按殖民军行动编年，难以看到被奴役人口的不同政治策略。殖民议会法案恰好保存了具名人的信息，但这些人物多是因向当局提供情报或镇压行动而进入白人立法者的文字，不能据此概括全部被奴役者的态度，也不能轻易称被解放者完全免于贫困或歧视。

## 二、殖民决策及文书性质

1760年12月18日议会一份法令宣布18名具名男女解放，其中有Foster、Pembroke、George、Cuffey、Blackwall、Moll及其子Quaco、Congo Molly等。完整名单有两位不同的Billy，故切勿利用不带主人的姓名直接合并为同一人。该法给每人5镑年金的文字是法律承诺，而不是支付清单。

## 三、具体行动及时间

1761年12月19日Saint Mary的Jack具名获释，并获5镑年度给付安排；1763年12月1日Westmoreland的Jack Pearson获释并规定原主William Ricketts遗产可收60镑；1764年11月9日Cato获释并规定对Arthur Forrest支付70镑。1772年12月23日Will获释并获每年10镑、其原主遗产获100镑的规定。1774年11月19日Attea作为一名女性被奴役者在针对Westmoreland八月“阴谋”的法律里具名获释。

## 四、历史地点与路线

已知Saint Mary、Westmoreland、Saint Catherine三个牙买加教区和Jones’s Pen具名庄园。法令仅证明历史地名而未记庄园精确坐标；历史教区界线更不能复制现代行政面。

## 五、当事人物与受害群体

Congo Molly、Moll与Attea为女性被奴役者具名记录，显示被奴役妇女的社会行动不能在整体“起义人数”中消失。Sam是另一名奴役者，1772年法条追述其因3月31日杀死监工Andrew Ross被定罪并判火刑；除找到法院执行文书外，不能改写为已实际火刑处死。

## 六、原住民或被奴役者的抵抗／政治主动性

1760年起义和之后若干阴谋调查本身伴随逃亡、跨庄园联络和殖民社会秩序的恐慌。多位获释者参与镇压或提供信息是一种被迫制度下的生存选择，不能用简单二元标签替代不同人的动机。1774年八月“阴谋”目前只见议会单方面前言，仍待审判与当事人陈述。

## 七、经济后果与金额口径

1760年18人各5镑年金；1761 Jack每年5镑；1763 Jack Pearson原主遗产60镑；1764 Cato原主70镑；1772 Will每年10镑与原主100镑。法定金额不同币别或年限的项目不能相加为本年预算，所有实际支付账、年金到帐日期、自由者财产权仍为空值。

## 八、制度延续及长期后果

这批具名议会文本为一组可检索的“姓名—日期—旧主—法定赔偿”关系证据，适宜在未来前端显示为人员网络与法律事件，不适宜绘无依据的私人住处和行踪GPS。需进一步查奴役者死亡、遗产和教区登记档、报纸、教会洗礼记录，验证这些人的后续经历。

## 九、GIS证据和边界审查

只标法律事件的教区/城市参照地，地点精度不足者坐标null；不把法案文本提及的教区直接当遇害/战斗现场。

## 十、已入库的相关事件候选（筛选，并非本报告已完成逐件双独立交叉核实）

- `E18A4-001-1717`｜1717｜牙买加议会规定被处死奴役者的原主可向殖民财政索赔。来源：V4001。
- `E18A4-003-1730`｜1730｜牙买加殖民议会严格限制出售火药和枪械材料。来源：V4003。
- `E18A4-004-1744`｜1744｜牙买加1744年针对所谓叛乱施刑与具名Hector解放法律。来源：V4005。
- `E18A4-005-1748`｜1748｜牙买加议会限制自由有色者与原住民司法证言条件。来源：V4006。
- `E18A4-006-1749`｜1749｜牙买加针对长期逃亡与收留者修改严刑条款。来源：V4007。
- `E18A4-007-1751`｜1751｜牙买加限制杀害被奴役者的刑罚并保护原主财产权。来源：V4008。
- `E18A4-008-1760`｜1760-12-18｜牙买加议会具名释放18名协助镇压者。来源：V4009。
- `E18A4-010-1761`｜1761｜牙买加修改自由身份证书续期频率。来源：V4011。
- `E18A4-009-1761`｜1761-12-19｜牙买加殖民议会解放Saint Mary教区的Jack。来源：V4010。
- `E18A4-011-1763`｜1763-12-01｜牙买加议会为Jack Pearson颁发具名释放法。来源：V4012。
- `E18A4-012-1764`｜1764-11-09｜牙买加殖民议会释放Cato并授权向旧主付款。来源：V4013。
- `E18A4-022-1767`｜1767-07-24｜巴巴多斯1688年逃亡者鞭刑机制修订获王室核准。来源：V4021。
- `E18A4-014-1770`｜1770-12-19｜牙买加将三座港镇奴役者居所登记和围栏纳入法律。来源：V4015。
- `E18A4-015-1772`｜1772-03-31｜牙买加Jones’s Pen奴役者Sam被殖民法庭定罪。来源：V4016。
- `E18A4-016-1772`｜1772-12-23｜牙买加议会将具名Will解放并承诺终身年金。来源：V4016。
- `E18A4-018-1774`｜1774-08｜Westmoreland殖民议会声称侦知奴役者谋划起事。来源：V4018。
- `E18A4-019-1774`｜1774-11-19｜牙买加议会通过释放女奴役者Attea的个人法案。来源：V4018。
- `E18A4-020-1774`｜1774-12-24｜牙买加规定释放奴役者时由原主保障最低生活。来源：V4019。

## 十一、原始文书和阅读说明

- `V4001` [Jamaica 1717 slave trials and owner reimbursement statute](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1717) — 授权对被判死刑后奴隶主的价值补偿，单人法定估值上限40牙买加镑，非实际付款
- `V4003` [Jamaica 1730 gunpowder retail restrictions](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1730) — 限特定港镇许可商销售火药及对外出售禁令，罚金与履约保证金为法定上限
- `V4005` [Jamaica 1744 rebellion and Hector freedom statute](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1744-0) — 对所谓起义惩罚与Hector具名释放和财政承诺，若干人数和处决事实待原卷
- `V4006` [Jamaica 1748 testimony restrictions](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1748) — 证人身份证明、自由有色人士证言适用条件
- `V4007` [Jamaica 1749 anti-runaway statute](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1749) — 逃亡者和包庇者的法律惩罚
- `V4008` [Jamaica 1751 acts against killing enslaved persons](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1751) — 首犯刑罚与向其他主人支付60牙买加镑的法定民事补偿，非已收款
- `V4009` [Jamaica 1760 manumission of 18 named persons](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1760-0) — 1760-12-18具名Foster/Pembroke/George/Cuffey/Billy/Blackwall/Yankee/Philip/London/Moll/Quaco/Nero/Congo Molly/Beckford/Silver/Jemmy/Will；姓名Billy重复为两人；对每人法定5镑年金
- `V4010` [Jamaica 1761 named manumission of Jack](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1761-0) — 1761-12-19 Jack获法定释放，5牙买加镑年金
- `V4011` [Jamaica 1761 free status certificate amendment](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1761) — 自由证书更新期限改为七年
- `V4012` [Jamaica 1763 manumission of Jack Pearson](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1763) — 1763-12-01法律释放Jack Pearson，60牙买加镑向原奴隶主遗产的补偿
- `V4013` [Jamaica 1764 manumission of Cato](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1764) — 1764-11-09释放Cato；70牙买加镑为法定向原主补偿
- `V4015` [Jamaica 1770 slave huts registry](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1770) — 1770-12-19 Spanish Town、Port Royal、Kingston奴役人口居所登记与围墙管理
- `V4016` [Jamaica 1772 manumission of Will and Sam sentencing account](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1772) — 1772-03-31 Jones Pen奴役者Sam被控杀害Andrew Ross；刑事判决写烧死不等于已执行；1772-12-23 Will获释放与法定年金
- `V4018` [Jamaica 1774 manumission of Attea](https://slaveryandfreedomlaws.lib.unb.ca/sites/default/files/pdf/jamaica-1774-1.pdf) — 1774-11-19原法有关Westmoreland当年8月所谓阴谋与Attea释放及议会赔偿额
- `V4019` [Jamaica 1774 statute on provision for freed persons](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1774) — 1774-12-24奴役者释放人口须提供法定终身5镑保障，并非每个解放者真实获领
- `V4021` [Barbados 1766 passage, 1767 confirmation of amendment](https://slaveryandfreedomlaws.lib.unb.ca/laws/barbados-1767) — 1766-04-15殖民议会通过，1767-07-24王室核准；无票据者拘捕处分程序

## 十二、未解决问题与下一步原档

需要独立核对原始殖民议会记录、官员书信、被捕者口供、登记和财政实付账、当地原住民及马龙口述史；没有证据的伤亡、贸易收入和面积不估算。若地图采用条约边线，先收原图和地籍报告，后做明确标“历史声索、边界不确”的虚线参考，永不当已核实实际军事占领。
