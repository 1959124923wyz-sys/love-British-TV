# 1770—1774年牙买加港镇居所登记、奴役人口进口关税与解放手续

**本地研究阶段**：第四轮，2026-11-08。**研究等级**：`research_only`。**相关专题**：E18-A04, E18-A06, E18-A07。

**史料层级**：读取了所列在线原始法律／条约转录、政府历史机构文章；不是原始纸本逐页核验。殖民法规记录的是条文、官员陈述及预期结果；未发现实际军政执行和付款凭证时均记为未知。

## 一、历史背景与17世纪承接

跨大西洋奴役不是船卸货后才开始的分散事件；牙买加的城镇居所、海关和乡村种植园互相支撑。1760年之后殖民当局一方面限制镇内被奴役人口居所与聚会，一方面对进口人口设税，并使自由身份获取成为一套金融担保制度。

## 二、殖民决策及文书性质

1770年12月19日牙买加法令针对Spanish Town、Port Royal、Kingston的奴役者居住棚屋，规定业主登记住所和住户，四座及以上须共同设围墙并维持单入口，未遵守时官员可命拆除；殖民条例自己提到逃亡者在城镇藏身，是有关反抗空间的重要间接证据。

## 三、具体行动及时间

1774年2月12日殖民议会通过新增进口奴役人口关税法，2月13日Basil Keith批准，属于财政立法而非证明本年已进口的被奴役者总数；1774年12月24日私人释放被奴役者须先安排终身每年5镑保障，属于对自由资格的财政门槛。Westmoreland当局在1774年8月指控奴役者阴谋，11月19日议会具名释放Attea，恰可作为受害者和殖民奖惩制度个案展示。

## 四、历史地点与路线

Spanish Town、Port Royal、Kingston是明示法辖区和居住棚屋网络，Westmoreland是不同的乡村教区。没有棚屋地籍、海关泊位和17世纪老城郭地理转绘，不能制作所谓殖民镇压覆盖区。

## 五、当事人物与受害群体

殖民议会、Basil Keith、镇民、海关和船东；Attea及镇内不知名的奴役居者。城市黑人社区既有劳务依赖也有情报传递、聚会与生存空间。

## 六、原住民或被奴役者的抵抗／政治主动性

1770年法令以担忧逃亡者入住棚屋为由试图限制居所，反向说明逃亡者可能借城市民居寻求帮助。对“阴谋”的自述必须作为殖民当局指控，不能未经原始审讯即作为已证起义。

## 七、经济后果与金额口径

1774新进口税的征税基数、单船税单、关税总收入未从法文建立。居所拆除是否涉及财产赔付未知。Attea或其他获释者的法定金额若无法确认实际支出，不与进口关税相加。

## 八、制度延续及长期后果

至世纪末牙买加已形成城内、乡村和跨洋相衔接的殖民管制制度；可按法令条款逐年制作地图信息层，但每类地理含义要分开。

## 九、GIS证据和边界审查

只记相关城市现代代表地名（若后续有可信官方GIS才赋坐标），不要从一段法令把整座城市所有黑人居所标出，也不要把海关税法当船舶具体航路。

## 十、已入库的相关事件候选（筛选，并非本报告已完成逐件双独立交叉核实）

- `E18A4-001-1717`｜1717｜牙买加议会规定被处死奴役者的原主可向殖民财政索赔。来源：V4001。
- `E18A4-003-1730`｜1730｜牙买加殖民议会严格限制出售火药和枪械材料。来源：V4003。
- `E18A4-004-1744`｜1744｜牙买加1744年针对所谓叛乱施刑与具名Hector解放法律。来源：V4005。
- `E18A4-005-1748`｜1748｜牙买加议会限制自由有色者与原住民司法证言条件。来源：V4006。
- `E18A4-006-1749`｜1749｜牙买加针对长期逃亡与收留者修改严刑条款。来源：V4007。
- `E18A4-007-1751`｜1751｜牙买加限制杀害被奴役者的刑罚并保护原主财产权。来源：V4008。
- `E18A4-008-1760`｜1760-12-18｜牙买加议会具名释放18名协助镇压者。来源：V4009。
- `E18A4-010-1761`｜1761｜牙买加修改自由身份证书续期频率。来源：V4011。
- `E18A4-009-1761`｜1761-12-19｜牙买加殖民议会解放Saint Mary教区的Jack。来源：V4010。
- `E18A4-011-1763`｜1763-12-01｜牙买加议会为Jack Pearson颁发具名释放法。来源：V4012。
- `E18A4-012-1764`｜1764-11-09｜牙买加殖民议会释放Cato并授权向旧主付款。来源：V4013。
- `E18A4-022-1767`｜1767-07-24｜巴巴多斯1688年逃亡者鞭刑机制修订获王室核准。来源：V4021。
- `E18A4-014-1770`｜1770-12-19｜牙买加将三座港镇奴役者居所登记和围栏纳入法律。来源：V4015。
- `E18A4-015-1772`｜1772-03-31｜牙买加Jones’s Pen奴役者Sam被殖民法庭定罪。来源：V4016。
- `E18A4-016-1772`｜1772-12-23｜牙买加议会将具名Will解放并承诺终身年金。来源：V4016。
- `E18A4-017-1774`｜1774-02-12｜牙买加议会对进口奴役人口增加税收。来源：V4017。
- `E18A4-018-1774`｜1774-08｜Westmoreland殖民议会声称侦知奴役者谋划起事。来源：V4018。
- `E18A4-019-1774`｜1774-11-19｜牙买加议会通过释放女奴役者Attea的个人法案。来源：V4018。
- `E18A4-020-1774`｜1774-12-24｜牙买加规定释放奴役者时由原主保障最低生活。来源：V4019。

## 十一、原始文书和阅读说明

- `V4001` [Jamaica 1717 slave trials and owner reimbursement statute](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1717) — 授权对被判死刑后奴隶主的价值补偿，单人法定估值上限40牙买加镑，非实际付款
- `V4003` [Jamaica 1730 gunpowder retail restrictions](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1730) — 限特定港镇许可商销售火药及对外出售禁令，罚金与履约保证金为法定上限
- `V4005` [Jamaica 1744 rebellion and Hector freedom statute](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1744-0) — 对所谓起义惩罚与Hector具名释放和财政承诺，若干人数和处决事实待原卷
- `V4006` [Jamaica 1748 testimony restrictions](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1748) — 证人身份证明、自由有色人士证言适用条件
- `V4007` [Jamaica 1749 anti-runaway statute](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1749) — 逃亡者和包庇者的法律惩罚
- `V4008` [Jamaica 1751 acts against killing enslaved persons](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1751) — 首犯刑罚与向其他主人支付60牙买加镑的法定民事补偿，非已收款
- `V4009` [Jamaica 1760 manumission of 18 named persons](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1760-0) — 1760-12-18具名Foster/Pembroke/George/Cuffey/Billy/Blackwall/Yankee/Philip/London/Moll/Quaco/Nero/Congo Molly/Beckford/Silver/Jemmy/Will；姓名Billy重复为两人；对每人法定5镑年金
- `V4010` [Jamaica 1761 named manumission of Jack](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1761-0) — 1761-12-19 Jack获法定释放，5牙买加镑年金
- `V4011` [Jamaica 1761 free status certificate amendment](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1761) — 自由证书更新期限改为七年
- `V4012` [Jamaica 1763 manumission of Jack Pearson](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1763) — 1763-12-01法律释放Jack Pearson，60牙买加镑向原奴隶主遗产的补偿
- `V4013` [Jamaica 1764 manumission of Cato](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1764) — 1764-11-09释放Cato；70牙买加镑为法定向原主补偿
- `V4015` [Jamaica 1770 slave huts registry](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1770) — 1770-12-19 Spanish Town、Port Royal、Kingston奴役人口居所登记与围墙管理
- `V4016` [Jamaica 1772 manumission of Will and Sam sentencing account](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1772) — 1772-03-31 Jones Pen奴役者Sam被控杀害Andrew Ross；刑事判决写烧死不等于已执行；1772-12-23 Will获释放与法定年金
- `V4017` [Jamaica 1774 slave import customs act](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1774-2) — 1774-02-12议会通过、1774-02-13副总督Basil Keith批准；新增进口税但不能套用旧税率
- `V4018` [Jamaica 1774 manumission of Attea](https://slaveryandfreedomlaws.lib.unb.ca/sites/default/files/pdf/jamaica-1774-1.pdf) — 1774-11-19原法有关Westmoreland当年8月所谓阴谋与Attea释放及议会赔偿额
- `V4019` [Jamaica 1774 statute on provision for freed persons](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1774) — 1774-12-24奴役者释放人口须提供法定终身5镑保障，并非每个解放者真实获领
- `V4021` [Barbados 1766 passage, 1767 confirmation of amendment](https://slaveryandfreedomlaws.lib.unb.ca/laws/barbados-1767) — 1766-04-15殖民议会通过，1767-07-24王室核准；无票据者拘捕处分程序

## 十二、未解决问题与下一步原档

需要独立核对原始殖民议会记录、官员书信、被捕者口供、登记和财政实付账、当地原住民及马龙口述史；没有证据的伤亡、贸易收入和面积不估算。若地图采用条约边线，先收原图和地籍报告，后做明确标“历史声索、边界不确”的虚线参考，永不当已核实实际军事占领。
