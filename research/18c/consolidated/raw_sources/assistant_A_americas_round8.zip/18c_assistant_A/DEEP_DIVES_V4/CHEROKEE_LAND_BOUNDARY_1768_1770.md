# 1768—1770年切罗基土地边界外交、英国贸易委员会质疑与条约日次冲突

**本地研究阶段**：第四轮，2026-11-08。**研究等级**：`research_only`。**相关专题**：E18-C11, E18-C13, E18-C21。

**史料层级**：读取了所列在线原始法律／条约转录、政府历史机构文章；不是原始纸本逐页核验。殖民法规记录的是条文、官员陈述及预期结果；未发现实际军政执行和付款凭证时均记为未知。

## 一、历史背景与17世纪承接

1763王室公告对欧洲移民西进采取限制后，英国殖民地总督、原住民事务总监与豪德诺索尼、切罗基、肖尼等不同政治主体反复交涉。依据英国单一王室地图把北美大片地区涂为“签约后已征服”既忽视不同民族的土地权益，也忽视英方内部对签约权限的争执。

## 二、殖民决策及文书性质

1768年10月14日Hard Labour条约由John Stuart与Cherokee代表讨论新界线；另有美国国家公园管理局叙述10月17日，日次存在文书阶段差异，目前将既有旧事件维持月级。1768年11月5日Fort Stanwix协议的另一边界由Sir William Johnson及Haudenosaunee等代表议定，牵涉Shawnee、Delaware及Cherokee所主张的不同土地。

## 三、具体行动及时间

1769年4月25日英国贸易委员会书面批评Johnson在Fort Stanwix偏离指示，指北部条约越过与切罗基先前谈妥的界限，委员会把原住民族各异的权利明确记入报告。1770年10月18日Lochaber开始会议；文书还记10月22日条约安排及12月12日议事会宣读，不能在前端以一天等价不同政治程序。

## 四、历史地点与路线

Hard Labour（南卡罗来纳），Fort Stanwix/Oneida Carry（现纽约州Rome一带），Lochaber（南卡罗来纳）。贸易委员会奏呈于伦敦Whitehall，和土地声索发生地相距甚远；Whitehall事件点仅为行政档案地点，严禁把它连直线当1780前真实军队线路。

## 五、当事人物与受害群体

John Stuart、William Johnson、英国贸易委员会官员；切罗基首领Attakullakulla、Oconostota及名单其他代表，六族首领与不同原住民族的代表具有各自政治主张。殖民谈判中不同翻译、测绘和地契持有人可能有相互冲突的利益，待逐方史料。

## 六、原住民或被奴役者的抵抗／政治主动性

Cherokee等原住民族采用外交协商、界线条件和持续主权诉求回应定居扩张。英方并非唯一谈判者，更不是可以代表所有土地权利者的共同受托人。英国贸易委员会自己承认不同族群利益冲突，就是反对粗略统一着色的重要档案。

## 七、经济后果与金额口径

1769年奏呈写Fort Stanwix谈判涉及总估值£10,460 7s 3d的财物与金钱，这是英国报告中的名义价值，不应当作Cherokee、Shawnee及全部人群都真实收到且满意的金额。土地租金、地价与实际移民人数需另查测绘申诉。

## 八、制度延续及长期后果

1770后王室划界继续受到殖民移民、原住民政治和美国革命变化影响；独立后土地交易不能自动计入英国军事扩张。1710/1737等旧地权专题与此为制度后果衔接，不是同一份条约重复发表。

## 九、GIS证据和边界审查

仅保留具名条约地点和文书中的历史河流拐点描述；没有原地图地理配准成果则暂不输出LineString。未来如批准绘制，必须是“1768英国条约声索、不同原住民族争议、虚线概念界”，不得标实际英军占地。

## 十、已入库的相关事件候选（筛选，并非本报告已完成逐件双独立交叉核实）

- `E18A4-029-1758`｜1758-08-26｜英军在Oneida Carry放置Fort Stanwix第一根筑堡木料。来源：V4031。
- `E18A4-027-1769`｜1769-04-25｜英国贸易委员会批评斯坦威克斯堡条约越权与不同原住民族地权冲突。来源：V4028。

## 十一、原始文书和阅读说明

- `V4026` [1768 Treaty of Hard Labour with Cherokee](https://encyclopediavirginia.org/primary-documents/the-treaty-of-hard-labor-october-14-1768/) — 1768-10-14文书与英国官员John Stuart、切罗基政治代表；地理系文本描述非经验证GIS
- `V4027` [1770 Treaty of Lochaber](https://encyclopediavirginia.org/primary-documents/the-treaty-of-lochaber-october-18-1770/) — 1770-10-18代表集会；文内另有10-22 Treaty、12-12 council reading，不强制统一成签署一日
- `V4028` [Board of Trade report on Fort Stanwix 1769-04-25](https://encyclopediavirginia.org/primary-documents/representation-of-the-board-of-trade-to-the-king-upon-sir-william-johnsons-treaty-with-the-indians-april-25-1769/) — 英国贸易委员会承认各原住民族利益不同、指出与切罗基声索冲突；£10460 7s 3d属报告所列财物及金钱估值
- `V4031` [Oneida Carry Fort Stanwix timeline](https://www.nps.gov/articles/000/a-timeline-history-of-the-oneida-carry.htm) — 1758-08-26英军堡垒首根木料立起；与Oneida人的协商与承诺拆堡的文书史叙述

## 十二、未解决问题与下一步原档

需要独立核对原始殖民议会记录、官员书信、被捕者口供、登记和财政实付账、当地原住民及马龙口述史；没有证据的伤亡、贸易收入和面积不估算。若地图采用条约边线，先收原图和地籍报告，后做明确标“历史声索、边界不确”的虚线参考，永不当已核实实际军事占领。
