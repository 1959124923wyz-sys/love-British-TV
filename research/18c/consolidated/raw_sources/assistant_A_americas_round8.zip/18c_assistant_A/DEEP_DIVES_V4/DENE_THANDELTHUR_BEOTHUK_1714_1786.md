# 1714—1786年北方原住民政治：Thanadelthur外交与Beothuk土地处境

**本地研究阶段**：第四轮，2026-11-08。**研究等级**：`research_only`。**相关专题**：E18-C20, E18-C27。

**史料层级**：读取了所列在线原始法律／条约转录、政府历史机构文章；不是原始纸本逐页核验。殖民法规记录的是条文、官员陈述及预期结果；未发现实际军政执行和付款凭证时均记为未知。

## 一、历史背景与17世纪承接

哈德孙湾公司交易站在17世纪就依靠克里等原住民商业网络；18世纪沿岸欧洲主权声索与Dene、Cree自主政治之间仍存在巨大落差。纽芬兰贝奥图克人的海岸生存也不断受到渔业和殖民扩张压力，英方个别“保护”公告不足以结束冲突。

## 二、殖民决策及文书性质

1714年Dene女性Thanadelthur逃离被俘处境后进入York Factory。1715—1716年她帮助HBC商人William Stuart及Cree团体同Dene谈判，她在翻译、穿越地区与劝说中的主导角色为加拿大公园局正式纪念的历史人物贡献。英国公司想获得毛皮通道，但和平并非公司的单方面命令。

## 三、具体行动及时间

1717年夏公司在Churchill River建立商站，后续交易也须经原住民社区同意和供应；1768年纽芬兰行政长官派John Cartwright调查Exploits周围Beothuk处境，1769年John Byron发布保护公告，1773年Cartwright绘制岛屿内陆地图，1784年George Cartwright提议保留地，1786年George Christopher Pulling提出派船接触建议。各项文书不能统一成英方有效控制所有内陆地区。

## 四、历史地点与路线

York Factory、Churchill River、Exploits River、Notre Dame Bay、Bishop Falls等史料地名有出处；公园局纪念牌坐标不等于1715一行人真实每一站点，Cartwright画出的河流也不是军事巡逻线。

## 五、当事人物与受害群体

Thanadelthur（Dene女性外交家）、William Stuart、Cree谈判代表与Dene政治主体；John Byron、John Cartwright、George Cartwright、George Christopher Pulling及Beothuk社群成员。欧洲文书里原住民个人姓名不全，不能据此消除当地政治主体。

## 六、原住民或被奴役者的抵抗／政治主动性

Thanadelthur主动谈判、使用多种语言，把她自己民族的和平目标带入跨文化商贸；Beothuk通过保持内陆联系、资源利用与拒绝部分欧洲接触维护生存空间。英国军政公告反映殖民官员对攻击行为已有认识。

## 七、经济后果与金额口径

毛皮供给由原住民猎户和协商贸易网络构成；没见准确1717贸易入账、站点利润、Dene人口数和贝奥图克死亡总数，全部留空。

## 八、制度延续及长期后果

该线索给1713 HBC法国战后还堡与1774内陆Cumberland House建站补充原住民自主连续性；不应把“公司设站”画成扩大完整鲁珀特地真实统治。1750—1799纽芬兰渔业权与Beothuk生存地理仍需按海岸段落继续核原始船长日记。

## 九、GIS证据和边界审查

参考点只能依据已定位的公司站点或官方历史纪念遗址；战争路线、外交穿越、Beothuk活动季节范围均暂不绘线或面。

## 十、已入库的相关事件候选（筛选，并非本报告已完成逐件双独立交叉核实）

- `E18A4-033-1717`｜1717｜Thanadelthur调停后哈德孙湾公司夏季在丘吉尔河建商站。来源：R27。
- `E18A4-030-1769`｜1769｜纽芬兰英方总督John Byron发布针对Beothuk遭袭的公告。来源：V4032。
- `E18A4-031-1773`｜1773｜John Cartwright制作纽芬兰Exploits河流历史地图。来源：V4033。
- `E18A4-032-1786`｜1786｜George Christopher Pulling提出尝试缓和Beothuk冲突的官方建议。来源：V4032。

## 十一、原始文书和阅读说明

- `R27` [Thanadelthur National Historic Person](https://parks.canada.ca/culture/designation/personnage-person/thanadelthur) — 1714 self-liberation from captivity, 1715-16 female Dene guide diplomacy, 1717 Churchill River post; primary journals cited but not accessed
- `V4031` [Oneida Carry Fort Stanwix timeline](https://www.nps.gov/articles/000/a-timeline-history-of-the-oneida-carry.htm) — 1758-08-26英军堡垒首根木料立起；与Oneida人的协商与承诺拆堡的文书史叙述
- `V4032` [Institutional Efforts to End Beothuk Hostilities](https://www.heritage.nf.ca/articles/indigenous/beothuk-institution.php) — 1769 John Byron公告、1786 George Christopher Pulling政策建议；均属英方倡议而非证明冲突结束
- `V4033` [Newfoundland interior exploration and cartography](https://www.heritage.nf.ca/articles/exploration/newfoundland-interior.php) — 1768、1773 Cartwright北部内陆与Exploits地图出版，1780年代原住民抵抗背景；不把现代河谷当英国控制

## 十二、未解决问题与下一步原档

需要独立核对原始殖民议会记录、官员书信、被捕者口供、登记和财政实付账、当地原住民及马龙口述史；没有证据的伤亡、贸易收入和面积不估算。若地图采用条约边线，先收原图和地籍报告，后做明确标“历史声索、边界不确”的虚线参考，永不当已核实实际军事占领。
