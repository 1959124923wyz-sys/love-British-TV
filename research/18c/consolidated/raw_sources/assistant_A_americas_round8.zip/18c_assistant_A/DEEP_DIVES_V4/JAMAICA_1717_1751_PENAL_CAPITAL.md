# 1717—1751年牙买加：处决补偿、追捕赏金、火药禁售与杀人刑罚

**本地研究阶段**：第四轮，2026-11-08。**研究等级**：`research_only`。**相关专题**：E18-A05, E18-A06, E18-A07。

**史料层级**：读取了所列在线原始法律／条约转录、政府历史机构文章；不是原始纸本逐页核验。殖民法规记录的是条文、官员陈述及预期结果；未发现实际军政执行和付款凭证时均记为未知。

## 一、历史背景与17世纪承接

牙买加17世纪已由殖民议会建立世袭奴役与追逃法律；1700年以后，殖民统治不只是种植园个别经营者的暴力，军政财政还把追捕奖励、官员任命、人口买卖和诉讼成本纳入正式法条。早期法条反复提及逃亡山地群体，反映被奴役者通过离开庄园和自组织施加压力。

## 二、殖民决策及文书性质

1717年法令规定，司法处决奴役者后其原主可请求政府以审判估值给付补偿，每人最高40牙买加流通镑；1718年自愿武装追捕法对抓捕或杀死一名年满14岁的被称“rebellious”奴役者规定每名50镑的法定奖赏，另把未满14岁的被俘儿童直接授予追捕队员及其继承人。这是严重的人口商品化条款，与被处决者原主补偿是不同支付途径，不能把两法金额加总为政府实际支出。

## 三、具体行动及时间

1730年立法要求有许可的火药零售商在西班牙镇、皇家港、金斯敦经营，设500镑履约保函，法律明确拒绝对被奴役黑人、混血和原住民卖火药，已有自由身份者也必须持军官证明。1744年以“叛乱”称谓进行镇压相关法律并具名释放Hector；1751年法令处理奴役主及其他人杀害奴役者的刑事责任：首犯法律仍承认旧式神职豁免，另有至多12个月监禁，若杀害他人所谓财产则罚60镑给旧主，发生此前已经定罪后再犯才触发更重刑。

## 四、历史地点与路线

地名已查证：Jamaica，St Jago de la Vega（Spanish Town）、Port Royal和Kingston；1718年离首府20英里之外的教区构成法条地理适用条件，但没有同代路程或行政界线校准，地图只保留具名参考点研究线索。

## 五、当事人物与受害群体

决策方：殖民总督、议会、2名治安法官签发证明、教区军官和民兵。被法律分类为“rebellious”的人有独立的逃亡与结社行动；儿童被当作奖赏是特别重要的受害群体。1744年Hector为明确见诸具名法案的人，但其整个个人生平仍需查契据与个人账。

## 六、原住民或被奴役者的抵抗／政治主动性

1718年法律的成立前言直言此前数批常设追逃队未能消除逃亡抵抗，显示马龙社群的长期存续。当地黑人及原住民群体不是殖民法律对象的同质总体，法律文字是立法者的敌对视角，需以反抗者自述、传承和马龙社区档案相补。

## 七、经济后果与金额口径

1717每人40镑上限、1718每名成年反抗者50镑法定赏金及未满14岁儿童作为战利品、1730许可商保函500镑、1751杀害他人奴役者60镑均逐项放入法律金额字段；未有财政实际支出账、营收账或奴役者实际身价评估，全部不纳入真实贸易金额统计。

## 八、制度延续及长期后果

这些财政和刑政结构促使殖民政权将逃亡、山地政治自治和种植园投资利益系统联结。后续1739条约、1760起义及1769追逃奖励修改形成制度连续性；是否在各年实际执行需另查TNA CO殖民档、Jamaica Archives议事录和各教区审判账。

## 九、GIS证据和边界审查

不画全岛镇压区，不用现代行政线表示18世纪追捕范围。17世纪前篇E6-T08法律与马龙自治按原年保留；只有具名城市可添加经外部验证的现代参考坐标，暂不输出经纬度。

## 十、已入库的相关事件候选（筛选，并非本报告已完成逐件双独立交叉核实）

- `E18A4-001-1717`｜1717｜牙买加议会规定被处死奴役者的原主可向殖民财政索赔。来源：V4001。
- `E18A4-002-1718`｜1718｜牙买加殖民议会资助武装追捕逃亡奴役者。来源：V4002。
- `E18A4-003-1730`｜1730｜牙买加殖民议会严格限制出售火药和枪械材料。来源：V4003。
- `E18A4-004-1744`｜1744｜牙买加1744年针对所谓叛乱施刑与具名Hector解放法律。来源：V4005。
- `E18A4-005-1748`｜1748｜牙买加议会限制自由有色者与原住民司法证言条件。来源：V4006。
- `E18A4-006-1749`｜1749｜牙买加针对长期逃亡与收留者修改严刑条款。来源：V4007。
- `E18A4-007-1751`｜1751｜牙买加限制杀害被奴役者的刑罚并保护原主财产权。来源：V4008。
- `E18A4-008-1760`｜1760-12-18｜牙买加议会具名释放18名协助镇压者。来源：V4009。
- `E18A4-010-1761`｜1761｜牙买加修改自由身份证书续期频率。来源：V4011。
- `E18A4-009-1761`｜1761-12-19｜牙买加殖民议会解放Saint Mary教区的Jack。来源：V4010。
- `E18A4-011-1763`｜1763-12-01｜牙买加议会为Jack Pearson颁发具名释放法。来源：V4012。
- `E18A4-012-1764`｜1764-11-09｜牙买加殖民议会释放Cato并授权向旧主付款。来源：V4013。
- `E18A4-022-1767`｜1767-07-24｜巴巴多斯1688年逃亡者鞭刑机制修订获王室核准。来源：V4021。
- `E18A4-013-1769`｜1769｜牙买加修订马龙人押返逃亡奴役者的法定报酬。来源：V4014。
- `E18A4-014-1770`｜1770-12-19｜牙买加将三座港镇奴役者居所登记和围栏纳入法律。来源：V4015。
- `E18A4-015-1772`｜1772-03-31｜牙买加Jones’s Pen奴役者Sam被殖民法庭定罪。来源：V4016。
- `E18A4-016-1772`｜1772-12-23｜牙买加议会将具名Will解放并承诺终身年金。来源：V4016。
- `E18A4-018-1774`｜1774-08｜Westmoreland殖民议会声称侦知奴役者谋划起事。来源：V4018。
- `E18A4-019-1774`｜1774-11-19｜牙买加议会通过释放女奴役者Attea的个人法案。来源：V4018。
- `E18A4-020-1774`｜1774-12-24｜牙买加规定释放奴役者时由原主保障最低生活。来源：V4019。
- `E18A4-021-1788`｜1788-01-10｜牙买加立法赋予马龙镇内白人监督员惩戒权。来源：V4020。

## 十一、原始文书和阅读说明

- `V4001` [Jamaica 1717 slave trials and owner reimbursement statute](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1717) — 授权对被判死刑后奴隶主的价值补偿，单人法定估值上限40牙买加镑，非实际付款
- `V4002` [Jamaica 1718 armed runaway-hunting law](https://slaveryandfreedomlaws.lib.unb.ca/laws/node/324) — 动员追捕逃亡者、设法定奖励，是否成立实际队伍另核
- `V4003` [Jamaica 1730 gunpowder retail restrictions](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1730) — 限特定港镇许可商销售火药及对外出售禁令，罚金与履约保证金为法定上限
- `V4005` [Jamaica 1744 rebellion and Hector freedom statute](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1744-0) — 对所谓起义惩罚与Hector具名释放和财政承诺，若干人数和处决事实待原卷
- `V4006` [Jamaica 1748 testimony restrictions](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1748) — 证人身份证明、自由有色人士证言适用条件
- `V4007` [Jamaica 1749 anti-runaway statute](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1749) — 逃亡者和包庇者的法律惩罚
- `V4008` [Jamaica 1751 acts against killing enslaved persons](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1751) — 首犯刑罚与向其他主人支付60牙买加镑的法定民事补偿，非已收款
- `V4009` [Jamaica 1760 manumission of 18 named persons](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1760-0) — 1760-12-18具名Foster/Pembroke/George/Cuffey/Billy/Blackwall/Yankee/Philip/London/Moll/Quaco/Nero/Congo Molly/Beckford/Silver/Jemmy/Will；姓名Billy重复为两人；对每人法定5镑年金
- `V4010` [Jamaica 1761 named manumission of Jack](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1761-0) — 1761-12-19 Jack获法定释放，5牙买加镑年金
- `V4011` [Jamaica 1761 free status certificate amendment](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1761) — 自由证书更新期限改为七年
- `V4012` [Jamaica 1763 manumission of Jack Pearson](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1763) — 1763-12-01法律释放Jack Pearson，60牙买加镑向原奴隶主遗产的补偿
- `V4013` [Jamaica 1764 manumission of Cato](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1764) — 1764-11-09释放Cato；70牙买加镑为法定向原主补偿
- `V4014` [Jamaica 1769 law regarding Maroon runaway returns](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1769) — 1769通过，1770-03-01生效的追捕逃亡人口奖励修正；日期及兑现分开
- `V4015` [Jamaica 1770 slave huts registry](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1770) — 1770-12-19 Spanish Town、Port Royal、Kingston奴役人口居所登记与围墙管理
- `V4016` [Jamaica 1772 manumission of Will and Sam sentencing account](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1772) — 1772-03-31 Jones Pen奴役者Sam被控杀害Andrew Ross；刑事判决写烧死不等于已执行；1772-12-23 Will获释放与法定年金
- `V4018` [Jamaica 1774 manumission of Attea](https://slaveryandfreedomlaws.lib.unb.ca/sites/default/files/pdf/jamaica-1774-1.pdf) — 1774-11-19原法有关Westmoreland当年8月所谓阴谋与Attea释放及议会赔偿额
- `V4019` [Jamaica 1774 statute on provision for freed persons](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1774) — 1774-12-24奴役者释放人口须提供法定终身5镑保障，并非每个解放者真实获领
- `V4020` [Jamaica 1788 Maroon towns discipline statute](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1788-0) — 1788-01-10法律设置白人监管、马龙社群法庭和追捕逃亡人口任务；限制公司/政府权的自治空间
- `V4021` [Barbados 1766 passage, 1767 confirmation of amendment](https://slaveryandfreedomlaws.lib.unb.ca/laws/barbados-1767) — 1766-04-15殖民议会通过，1767-07-24王室核准；无票据者拘捕处分程序

## 十二、未解决问题与下一步原档

需要独立核对原始殖民议会记录、官员书信、被捕者口供、登记和财政实付账、当地原住民及马龙口述史；没有证据的伤亡、贸易收入和面积不估算。若地图采用条约边线，先收原图和地籍报告，后做明确标“历史声索、边界不确”的虚线参考，永不当已核实实际军事占领。

**进一步核查结果**：1748年一项相关法令扩大了自由黑人、原住民与自由混血居民彼此之间作证的权利，同时仍排除向具有白人权利者作证、并对新获释者设六个月等待。来源：https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1748 。
