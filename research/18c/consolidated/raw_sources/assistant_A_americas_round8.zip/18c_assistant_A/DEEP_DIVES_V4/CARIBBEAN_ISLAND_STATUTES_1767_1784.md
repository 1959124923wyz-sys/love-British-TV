# 1767—1784年圣文森特、巴巴多斯、多米尼克、圣基茨、巴哈马：跨岛奴役法律对比

**本地研究阶段**：第四轮，2026-11-08。**研究等级**：`research_only`。**相关专题**：E18-A06, E18-A14, E18-A19, E18-A22。

**史料层级**：读取了所列在线原始法律／条约转录、政府历史机构文章；不是原始纸本逐页核验。殖民法规记录的是条文、官员陈述及预期结果；未发现实际军政执行和付款凭证时均记为未知。

## 一、历史背景与17世纪承接

英国加勒比殖民地不是统一立法机关，1770年代各岛的法律虽都有种植园奴役制，却在行政批准、继承法、自由身份登记、强制征调和受害者赔偿等方面各有条款。把所有岛屿的“黑人法律”当一份英王统一法律会遮蔽各岛殖民议会责任。

## 二、殖民决策及文书性质

圣文森特1767年7月11日法律由总督Robert Melvill及岛议会通过，将被奴役者用于继承视作不动产，同时在遗产债务清偿时又视作动产；1773年多米尼克将自由黑人及混血男性纳入由白人军官领导的强制追逃队伍，并规定身份注册。巴巴多斯1766年4月15日地方法案需等1767年7月24日王室核准，体现地方与帝国两道行政步骤。

## 三、具体行动及时间

圣基茨1783年12月18日法律因残害被奴役者而规定500当地镑处罚，但也允许将受害者扣押及在特定法律条件下公开拍卖。巴哈马1784年法律允许自由证不足者被羁押和拍卖，即便证明自由的黑人仍可能被要求三月内离开群岛或交90当地镑保证金。这些法律要与实际驱逐、处刑、民兵行动的案卷分开调查。

## 四、历史地点与路线

St Vincent、Kingstown、Barbados、Dominica、St Christopher（Basseterre）、Bahamas各地是具名法辖区；巴哈马“群岛”不是逐岛政府掌控边界，也不能为奴役制度本身着真实占地颜色。

## 五、当事人物与受害群体

圣文森特殖民总督Robert Melvill；各地殖民议会、司法官、白人军官与警长为制度主体。被奴役黑人、自由黑人与原住民居民的法律身份界限可被法条重新划分，从身份差异反映殖民暴力。

## 六、原住民或被奴役者的抵抗／政治主动性

自由居民要求证明自身身份、逃亡者避入山区、奴役者结社及寻找庇护的行为可从法律的反向限制窥见。条文的“盗窃”“叛乱”等带殖民当局偏见的词语需要对照当事人视角。

## 七、经济后果与金额口径

1767 Saint Vincent继承财产权≠殖民者实际获地数量；1783圣基茨500镑是法定罚金；1784巴哈马90镑是财务担保要求。自由者被卖价或实际拘留次数均未知，不能用法律额计算殖民税收及总利润。

## 八、制度延续及长期后果

岛际比较显示18世纪后期英国殖民统治为种植园主不断设计法律资产权、追逃组织与自由身份管理。未来可设岛屿法令事件节点，但每座岛的政治实控界线、实际驻军控制和种植园地籍必须分别审核。

## 九、GIS证据和边界审查

各岛使用现代官方国家历史遗址参考点需另找官方GPS，禁止随便以首府中心点作为原历史议会大厅的精确位置；无历史地籍则不画多边形。

## 十、已入库的相关事件候选（筛选，并非本报告已完成逐件双独立交叉核实）

- `E18A4-001-1717`｜1717｜牙买加议会规定被处死奴役者的原主可向殖民财政索赔。来源：V4001。
- `E18A4-003-1730`｜1730｜牙买加殖民议会严格限制出售火药和枪械材料。来源：V4003。
- `E18A4-004-1744`｜1744｜牙买加1744年针对所谓叛乱施刑与具名Hector解放法律。来源：V4005。
- `E18A4-005-1748`｜1748｜牙买加议会限制自由有色者与原住民司法证言条件。来源：V4006。
- `E18A4-006-1749`｜1749｜牙买加针对长期逃亡与收留者修改严刑条款。来源：V4007。
- `E18A4-007-1751`｜1751｜牙买加限制杀害被奴役者的刑罚并保护原主财产权。来源：V4008。
- `E18A4-010-1761`｜1761｜牙买加修改自由身份证书续期频率。来源：V4011。
- `E18A4-023-1767`｜1767-07-11｜圣文森特殖民议会将奴役人口作为可继承财产立法。来源：V4022。
- `E18A4-022-1767`｜1767-07-24｜巴巴多斯1688年逃亡者鞭刑机制修订获王室核准。来源：V4021。
- `E18A4-014-1770`｜1770-12-19｜牙买加将三座港镇奴役者居所登记和围栏纳入法律。来源：V4015。
- `E18A4-015-1772`｜1772-03-31｜牙买加Jones’s Pen奴役者Sam被殖民法庭定罪。来源：V4016。
- `E18A4-016-1772`｜1772-12-23｜牙买加议会将具名Will解放并承诺终身年金。来源：V4016。
- `E18A4-024-1773`｜1773｜多米尼克殖民当局授权征调自由黑人男子搜捕逃亡者。来源：V4023。
- `E18A4-020-1774`｜1774-12-24｜牙买加规定释放奴役者时由原主保障最低生活。来源：V4019。
- `E18A4-025-1783`｜1783-12-18｜圣基茨禁止残害奴役者的法律同时维持受害者拍卖制度。来源：V4024。
- `E18A4-026-1784`｜1784｜巴哈马颁布可将缺乏自由身份证明者拍卖的刑政法律。来源：V4025。

## 十一、原始文书和阅读说明

- `V4001` [Jamaica 1717 slave trials and owner reimbursement statute](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1717) — 授权对被判死刑后奴隶主的价值补偿，单人法定估值上限40牙买加镑，非实际付款
- `V4003` [Jamaica 1730 gunpowder retail restrictions](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1730) — 限特定港镇许可商销售火药及对外出售禁令，罚金与履约保证金为法定上限
- `V4005` [Jamaica 1744 rebellion and Hector freedom statute](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1744-0) — 对所谓起义惩罚与Hector具名释放和财政承诺，若干人数和处决事实待原卷
- `V4006` [Jamaica 1748 testimony restrictions](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1748) — 证人身份证明、自由有色人士证言适用条件
- `V4007` [Jamaica 1749 anti-runaway statute](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1749) — 逃亡者和包庇者的法律惩罚
- `V4008` [Jamaica 1751 acts against killing enslaved persons](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1751) — 首犯刑罚与向其他主人支付60牙买加镑的法定民事补偿，非已收款
- `V4011` [Jamaica 1761 free status certificate amendment](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1761) — 自由证书更新期限改为七年
- `V4015` [Jamaica 1770 slave huts registry](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1770) — 1770-12-19 Spanish Town、Port Royal、Kingston奴役人口居所登记与围墙管理
- `V4016` [Jamaica 1772 manumission of Will and Sam sentencing account](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1772) — 1772-03-31 Jones Pen奴役者Sam被控杀害Andrew Ross；刑事判决写烧死不等于已执行；1772-12-23 Will获释放与法定年金
- `V4019` [Jamaica 1774 statute on provision for freed persons](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1774) — 1774-12-24奴役者释放人口须提供法定终身5镑保障，并非每个解放者真实获领
- `V4021` [Barbados 1766 passage, 1767 confirmation of amendment](https://slaveryandfreedomlaws.lib.unb.ca/laws/barbados-1767) — 1766-04-15殖民议会通过，1767-07-24王室核准；无票据者拘捕处分程序
- `V4022` [Saint Vincent 1767 act making enslaved persons inheritable estate](https://slaveryandfreedomlaws.lib.unb.ca/laws/st-vincent-1767) — 1767-07-11通过、07-13公布，1768-01-27登记：奴役人口对继承属real estate，债务清偿可为chattels
- `V4023` [Dominica 1773 coerced free Black militia pursuit and freedom registration](https://slaveryandfreedomlaws.lib.unb.ca/laws/dominica-1773) — 自由有色男性依法征调为追逃队伍，涉及自由证登记、拒绝征召罚款和出售风险；不能视作已执行人数
- `V4024` [Saint Christopher 1783 legal penalties for mutilation and forced resale](https://slaveryandfreedomlaws.lib.unb.ca/laws/st-christopher-1783) — 1783-12-18法定500当地镑罚款，受害奴役者可被羁押及拍卖；法定罚款不等于已追缴
- `V4025` [Bahamas 1784 racialized freedom-proof law](https://slaveryandfreedomlaws.lib.unb.ca/laws/bahamas-1784) — 自由证不足者可羁押并拍卖；即便认定自由者仍需离境或提供90当地镑担保

## 十二、未解决问题与下一步原档

需要独立核对原始殖民议会记录、官员书信、被捕者口供、登记和财政实付账、当地原住民及马龙口述史；没有证据的伤亡、贸易收入和面积不估算。若地图采用条约边线，先收原图和地籍报告，后做明确标“历史声索、边界不确”的虚线参考，永不当已核实实际军事占领。
