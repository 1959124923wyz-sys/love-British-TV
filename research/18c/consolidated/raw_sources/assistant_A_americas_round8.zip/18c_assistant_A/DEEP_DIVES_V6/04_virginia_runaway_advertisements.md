# 第六轮深入调查｜C22｜弗吉尼亚Gazette广告中的具名逃亡者

**范围**：1700—1799；**状态**：研究候审；新关联事件 10 件。

## 一、背景及跨世纪起点

Peter、Amy、Sam、Fanny、John Newton和John Hedgman等人的证据来自奴隶主或监狱公告，反映主动逃亡与严密追捕，但奴隶主的推测不等于被追捕者自己的供述。

## 二、决策机构与执行人

按下列行动节点分别核对殖民议会、皇家总督、海上船长、公司和殖民民兵。法令、海关账、船客清单与实际登陆是不同类别，任何经纬度空值均有意保留。

## 三、具名事件、地点、行动和直接证据

### 1729｜马里兰议会授权对被奴役重罪犯施行肢解及死刑

- **行动主体**：马里兰领主殖民议会
- **历史地点**：Maryland；坐标未核。
- **实际行动与性质**：针对被奴役者被裁定特定杀人、纵火罪行，允许砍手、绞刑和分尸展示；目录日期1729-07-01注明inexact，记录年精度。
- **来源**：[V6004](https://slaveryandfreedomlaws.lib.unb.ca/laws/maryland-1729)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1736-11-05｜弗吉尼亚Gazette刊登Poplar与Planter两名逃亡者追捕广告

- **行动主体**：被奴役者Poplar、Planter；登广告奴隶主
- **历史地点**：Williamsburg, Virginia (newspaper publication)；坐标未核。
- **实际行动与性质**：1736-11-05刊报，两人实际出走分别早于刊报。Poplar被奴隶主称为outlawed是对方法律话语；刊报地点不等于逃亡GPS。
- **来源**：[V6020](https://research.colonialwilliamsburg.org/Foundation/journal/Autumn10/ads.cfm)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1769-02-09｜弗吉尼亚Gazette记载Peter擅长写通行证以逃避奴役追捕

- **行动主体**：被奴役者Peter；声索人William Macon
- **历史地点**：Williamsburg (newspaper) / Virginia；坐标未核。
- **实际行动与性质**：William Macon在广告中抱怨Peter能读写、曾自行写通行证；这反映抵抗技术，是奴隶主的指控而非独立取得的Peter证言。
- **来源**：[V6012](https://www.colonialwilliamsburg.org/discover/sources/the-virginia-gazettes/slavery-and-the-virginia-gazette/)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1769-11-09｜弗吉尼亚Gazette刊登追捕Amy广告，记述以服饰争取自由

- **行动主体**：被奴役女性Amy；奴隶主Parker Hare
- **历史地点**：Williamsburg, Virginia (newspaper)；坐标未核。
- **实际行动与性质**：报纸称Amy约30岁，携银扣及换洗衣物外逃，可能借衣着被视为自由人；具体逃亡日期、地点未证，刊报时间确证。
- **来源**：[V6012](https://www.colonialwilliamsburg.org/discover/sources/the-virginia-gazettes/slavery-and-the-virginia-gazette/)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1771-01-10｜弗吉尼亚Gazette刊登追捕Sam及三人的广告

- **行动主体**：被奴役者Sam等四人；奴隶主James Walker
- **历史地点**：Williamsburg, Virginia (newspaper)；坐标未核。
- **实际行动与性质**：广告记载Sam遭鞭打旧伤，以及四名被奴役者离开；报纸奴隶主的定性不可当作抵抗者自身主张。
- **来源**：[V6012](https://www.colonialwilliamsburg.org/discover/sources/the-virginia-gazettes/slavery-and-the-virginia-gazette/)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1773-10-18｜弗吉尼亚被奴役少女Fanny自行逃离John Lewis

- **行动主体**：Fanny；奴隶主John Lewis
- **历史地点**：Williamsburg / Tidewater Virginia (route unverified)；坐标未核。
- **实际行动与性质**：殖民威廉斯堡据1774广告重建15岁左右Fanny在1773-10-18逃离；可能去见母亲Joan但路线和最终去向都不明。
- **来源**：[V6013](https://www.colonialwilliamsburg.org/discover/18th-century-people/stories-of-black-life/underground-allies-the-incomplete-story-of-fanny-and-moses/)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1774-01-27｜John Lewis刊登搜捕Fanny广告并怀疑Moses协助

- **行动主体**：奴隶主John Lewis；Fanny；被怀疑的Moses
- **历史地点**：Williamsburg, Virginia (newspaper)；坐标未核。
- **实际行动与性质**：广告指控另一名被奴役者Moses可能保护Fanny；怀疑为奴隶主一方说法，不写成已证Moses实际窝藏。
- **来源**：[V6013](https://www.colonialwilliamsburg.org/discover/18th-century-people/stories-of-black-life/underground-allies-the-incomplete-story-of-fanny-and-moses/)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1774-03-10｜Prince William监狱刊报拘押John Hedgman

- **行动主体**：John Hedgman；地方监狱官员
- **历史地点**：Prince William County / Virginia Gazette Williamsburg；坐标未核。
- **实际行动与性质**：报纸记23岁John Hedgman因被怀疑逃亡而拘留；是否合法奴役身份或最终解送未证。
- **来源**：[V6012](https://www.colonialwilliamsburg.org/discover/sources/the-virginia-gazettes/slavery-and-the-virginia-gazette/)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1774-12-15｜弗吉尼亚被奴役织工Gabriel逃亡通缉广告刊登

- **行动主体**：Gabriel；声索人John Fox
- **历史地点**：Williamsburg, Virginia (newspaper)；坐标未核。
- **实际行动与性质**：殖民威廉斯堡馆方引述广告称Gabriel会织布、读书、拉小提琴，广告时间确证而出走准确日未知。
- **来源**：[V6012](https://www.colonialwilliamsburg.org/discover/sources/the-virginia-gazettes/slavery-and-the-virginia-gazette/)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1776-07-19｜弗吉尼亚Gazette刊载对原住民出身John Newton的搜捕

- **行动主体**：John Newton；登广告殖民居民
- **历史地点**：Williamsburg / Virginia Gazette；坐标未核。
- **实际行动与性质**：1776-07-19刊报称John Newton为出生于原住民社群的混合血统契约仆役；法律身份原话servant，不能从广告直接改写为终身动产奴隶。
- **来源**：[V6012](https://www.colonialwilliamsburg.org/discover/sources/the-virginia-gazettes/slavery-and-the-virginia-gazette/)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

## 四、居民/被奴役者/原住民族的能动性与抵抗

本篇不得把受压制者归为被动受害者：其逃亡、组织、谈判、船上起义、争取土地和法律申诉都是独立行动。部分证词仅留于敌对殖民者的追捕公告，须按发话主体还原。

## 五、法律、经济及长期影响

有数字的船货、赏金、进口税与土地面积只采当时文书明确的“法定、估计、登记、报称”口径；无法独立核实的实际支付、船东净利润、死亡总数和真实区域面积一律null。跨18世纪后的生效/到期条款应标后续调查，不把1801年事件塞回1799年滑条。

## 六、地图GIS审查

所有此批事件仅具名地点（并不等于准确事件GPS）。船舶海上路线与跨岛强制迁运不绘直线；殖民纸面司法管辖不当主权实占；可据同时代测绘但未校准边界仅在主编审核后以虚线概略方案呈现。

## 七、下步逐页原档

优先获取相应登船账、宣誓副本、殖民法律原刊或报纸整版、原住民社区记录及人名/地名同一性证据，以便把故事节点从候审提高至可出版级。

## 第六轮增补：新增独立验证的具体行动

### 1761-08-20｜华盛顿刊广告追捕Peres、Jack、Neptune及Cupid四名逃亡者

Maryland Gazette于1761-08-20刊布对四位逃亡者的赏额及身体描述，是奴役者提供的文字，不等于当日逃亡、被抓或出售；报纸印刷地不当逃亡GPS。。具体行动者：四位被奴役者；奴役者George Washington。历史地名：Dogue Run, Fairfax County Virginia / Maryland Gazette newspaper。

[V6020](https://research.colonialwilliamsburg.org/Foundation/journal/Autumn10/ads.cfm)

