# 第六轮深入调查｜C17｜Dunmore时期逃亡家庭与Willoughby请愿

**范围**：1700—1799；**状态**：研究候审；新关联事件 6 件。

## 一、背景及跨世纪起点

以殖民威廉斯堡馆方摘录的1777请愿、1776名单、1781庄园清册观察英国许诺自由与具体家庭风险，分清登记人口、声索人数与真实获释人数。

## 二、决策机构与执行人

按下列行动节点分别核对殖民议会、皇家总督、海上船长、公司和殖民民兵。法令、海关账、船客清单与实际登陆是不同类别，任何经纬度空值均有意保留。

## 三、具名事件、地点、行动和直接证据

### 1776-04-14｜Willoughby记录奴役者约87人逃向英军控制区

- **行动主体**：约87位自我解放者；奴隶主John Willoughby Jr
- **历史地点**：Norfolk / Virginia；坐标未核。
- **实际行动与性质**：原请愿核为1777-06-03，追记1776-04-14有约87位被他声索的奴役者离开；约数与妇女21男人16及儿童分母不得简单加总。
- **来源**：[V6014](https://www.colonialwilliamsburg.org/discover/18th-century-people/stories-of-women/escaping-to-freedom/)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1776-07-19｜弗吉尼亚Gazette刊载对原住民出身John Newton的搜捕

- **行动主体**：John Newton；登广告殖民居民
- **历史地点**：Williamsburg / Virginia Gazette；坐标未核。
- **实际行动与性质**：1776-07-19刊报称John Newton为出生于原住民社群的混合血统契约仆役；法律身份原话servant，不能从广告直接改写为终身动产奴隶。
- **来源**：[V6012](https://www.colonialwilliamsburg.org/discover/sources/the-virginia-gazettes/slavery-and-the-virginia-gazette/)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1777-06-03｜John Willoughby向弗吉尼亚议会递交赔偿请愿

- **行动主体**：John Willoughby Jr.；弗吉尼亚议会
- **历史地点**：Virginia House of Delegates；坐标未核。
- **实际行动与性质**：请愿为奴隶主声索的损失，并记1776年逃离人群；金额与获赔金额不能从请愿书直接推断。
- **来源**：[V6014](https://www.colonialwilliamsburg.org/discover/18th-century-people/stories-of-women/escaping-to-freedom/)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1781｜Randolph庄园Nanny、Eve、Aggy、Lucy等人逃往英军

- **行动主体**：被奴役者Nanny、Eve、Aggy、Lucy及另外四人
- **历史地点**：Williamsburg / Tidewater Virginia；坐标未核。
- **实际行动与性质**：Colonial Williamsburg依据庄园清册旁注推测1781年八人赴英军，其中女性四人有名字；被奴役者各人是否抵达英军及长期自由未逐一证实。
- **来源**：[V6014](https://www.colonialwilliamsburg.org/discover/18th-century-people/stories-of-women/escaping-to-freedom/)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1782-07-20｜Betty Randolph遗嘱补充条款记录曾变卖Eve

- **行动主体**：奴隶主Betty Randolph；被奴役女性Eve
- **历史地点**：Williamsburg, Virginia；坐标未核。
- **实际行动与性质**：1782-07-20遗嘱附记称把Eve卖出并提及bad behaviour，前一年Eve曾被记录逃往英方；是否因此变卖尚待更直接文书，不能擅自归因。
- **来源**：[V6014](https://www.colonialwilliamsburg.org/discover/18th-century-people/stories-of-women/escaping-to-freedom/)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1783-04-23｜英国在纽约开始登记赴新斯科舍黑人效忠派船客

- **行动主体**：Guy Carleton驻纽约英方行政；黑人效忠派及家属
- **历史地点**：New York (registration context)；坐标未核。
- **实际行动与性质**：新斯科舍档案馆指出《黑人名册》登记窗口为1783-04-23至11-30，约3000人名单是申请/登船记录人口，不等于均获得土地或法律保障。
- **来源**：[V6015](https://archives.novascotia.ca/africanns/book-of-negroes/)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

## 四、居民/被奴役者/原住民族的能动性与抵抗

本篇不得把受压制者归为被动受害者：其逃亡、组织、谈判、船上起义、争取土地和法律申诉都是独立行动。部分证词仅留于敌对殖民者的追捕公告，须按发话主体还原。

## 五、法律、经济及长期影响

有数字的船货、赏金、进口税与土地面积只采当时文书明确的“法定、估计、登记、报称”口径；无法独立核实的实际支付、船东净利润、死亡总数和真实区域面积一律null。跨18世纪后的生效/到期条款应标后续调查，不把1801年事件塞回1799年滑条。

## 六、地图GIS审查

所有此批事件仅具名地点（并不等于准确事件GPS）。船舶海上路线与跨岛强制迁运不绘直线；殖民纸面司法管辖不当主权实占；可据同时代测绘但未校准边界仅在主编审核后以虚线概略方案呈现。

## 七、下步逐页原档

优先获取相应登船账、宣誓副本、殖民法律原刊或报纸整版、原住民社区记录及人名/地名同一性证据，以便把故事节点从候审提高至可出版级。

## 第六轮增补：新增独立验证的具体行动

### 1779｜被奴役女性Judith Jackson逃到英军阵营争取自由

Colonial Williamsburg人物档案记Judith Jackson于1779年离开Norfolk的奴役生活投奔英国军事阵营；具体路线与最终抵达时刻未核。。具体行动者：Judith Jackson；其声索人John Clain；英国军队。历史地名：Norfolk, Virginia。

[V6014](https://www.colonialwilliamsburg.org/discover/18th-century-people/stories-of-women/escaping-to-freedom/)

### 1782-02-02｜Randolph家族刊广告追捕曾赴英国阵营的Eve

Colonial Williamsburg指出1782-02-02报纸刊登追捕Eve广告，反映1781逃亡后仍被追捕，不能把刊报日当实际逃亡日；之后又有1782-07-20变卖条款。。具体行动者：Eve；Randolph庄园殖民声索方。历史地名：Virginia Gazette / Williamsburg Virginia。

[V6014](https://www.colonialwilliamsburg.org/discover/18th-century-people/stories-of-women/escaping-to-freedom/)

### 1794-11-19｜英国Grenville与美国John Jay签订条约约定撤离西部堡垒

《杰伊条约》1794年11月19日在伦敦签署；第二条约定1796-06-01前撤出被1783条约划归美国的驻军堡垒，签署日不等于各据点实控交接日，原住民族领土权利仍另行调查。。具体行动者：英国外交大臣Lord Grenville、美国John Jay。历史地名：London, England (treaty signing)。

[V6024](https://guides.loc.gov/jays-treaty); [V6025](https://avalon.law.yale.edu/18th_century/jay.asp); [V6021](https://www.nps.gov/articles/jay-s-treaty.htm)

### 1795-06-24｜美国参议院对杰伊条约附条件表示批准同意

国会图书馆史料指1795年6月24日参院以20比10作出同意，须与1794签署、1795批准交换、1796实际军事撤离分开。。具体行动者：美国参议院、英国外交机关。历史地名：Philadelphia / United States Senate (deliberation city pending)。

[V6024](https://guides.loc.gov/jays-treaty); [V6025](https://avalon.law.yale.edu/18th_century/jay.asp)

