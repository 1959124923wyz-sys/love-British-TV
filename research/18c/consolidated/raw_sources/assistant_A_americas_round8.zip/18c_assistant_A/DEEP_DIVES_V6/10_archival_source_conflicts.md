# 第六轮深入调查｜第六轮文献异文与统计分母：跨专题审计

**范围**：1700—1799；**状态**：研究候审；新关联事件 19 件。

## 一、背景及跨世纪起点

馆方网站中可能有自相矛盾的旧文献印记、出版者年代、人口统计以及立法日期。审查必须逐件；不得为了达到数量把同一法令条款分裂为多场战争。

## 二、决策机构与执行人

按下列行动节点分别核对殖民议会、皇家总督、海上船长、公司和殖民民兵。法令、海关账、船客清单与实际登陆是不同类别，任何经纬度空值均有意保留。

## 三、具名事件、地点、行动和直接证据

### 1736｜Prince of Orange号从布里斯托尔经营奴役航次

- **行动主体**：船东Richard Farr & Co；船长Japhet Bird
- **历史地点**：Bristol / West African coast；坐标未核。
- **实际行动与性质**：馆方记载1736年航次并在西非购买、跨海贩运被奴役者；船期具体日和非洲交易点尚待原航次账。
- **来源**：[V6011](https://www.discoveringbristol.org.uk/slavery/routes/bristol-to-africa/shipping/four-ships-fortunes/)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1736｜Prince of Orange号载运者在圣基茨附近跳海抵抗

- **行动主体**：非洲被奴役者；船长Japhet Bird与船员
- **历史地点**：near Saint Kitts (St Kitts)；坐标未核。
- **实际行动与性质**：同一1736航次馆方记约100名男性跳海，33人溺亡，船长售出240名；实际海上位置、哪一天靠近圣基茨以及各人后来命运未知。1736航次与个别来源1737到达区分。
- **来源**：[V6011](https://www.discoveringbristol.org.uk/slavery/routes/bristol-to-africa/shipping/four-ships-fortunes/)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1752-03｜奴隶船Marlborough号由布里斯托尔前往西非

- **行动主体**：船东William Lougher & Co；船长Robert Codd
- **历史地点**：Bristol / Anomabu / Bonny；坐标未核。
- **实际行动与性质**：1752年3月离港，沿黄金海岸及博尼购买并非法商品化人口；后续西非地区航次各站具体天数未知。
- **来源**：[V6011](https://www.discoveringbristol.org.uk/slavery/routes/bristol-to-africa/shipping/four-ships-fortunes/)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1752-10｜Marlborough号被奴役者反抗、控制船舶并返回博尼

- **行动主体**：船上被奴役非洲人；船长Robert Codd；船员
- **历史地点**：off Bonny, West Africa (location approximate, no coordinate)；坐标未核。
- **实际行动与性质**：馆方记至10月购入420人、启航约三天发生反抗，舰被迫返Bonny；来源对不同地区被奴役者去向有记述，船的最终去向未证，海上位置保留null。
- **来源**：[V6011](https://www.discoveringbristol.org.uk/slavery/routes/bristol-to-africa/shipping/four-ships-fortunes/)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1783｜《黑人名册》记Betty被英方交还声称拥有她的Thomas Smith

- **行动主体**：逃亡女性Betty；Thomas Smith；英国登记官员
- **历史地点**：New York / embarkation administration；坐标未核。
- **实际行动与性质**：新斯科舍档案馆明确记载英当局接受奴隶主Thomas Smith的声索，将Betty交还；与另案Betty Truant身份未知，不合并为同一人。
- **来源**：[V6015](https://archives.novascotia.ca/africanns/book-of-negroes/)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1783-04-23｜英国在纽约开始登记赴新斯科舍黑人效忠派船客

- **行动主体**：Guy Carleton驻纽约英方行政；黑人效忠派及家属
- **历史地点**：New York (registration context)；坐标未核。
- **实际行动与性质**：新斯科舍档案馆指出《黑人名册》登记窗口为1783-04-23至11-30，约3000人名单是申请/登船记录人口，不等于均获得土地或法律保障。
- **来源**：[V6015](https://archives.novascotia.ca/africanns/book-of-negroes/)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1783-11-30｜赴新斯科舍黑人效忠派登记阶段结束

- **行动主体**：纽约英方登记官；黑人移民
- **历史地点**：New York departure ports；坐标未核。
- **实际行动与性质**：档案馆将名册内英国版的船客登记结束于1783-11-30；这里是清单覆盖窗口末日，不能当所有黑人最后一船到岸日。
- **来源**：[V6015](https://archives.novascotia.ca/africanns/book-of-negroes/)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1784-08｜Black Pioneers老兵Peters与Murphy Steel请愿平等分地

- **行动主体**：Thomas Peters；Murphy Steel；新斯科舍殖民政府
- **历史地点**：Nova Scotia / Digby；坐标未核。
- **实际行动与性质**：新斯科舍档案馆RG1卷359件65署1784年8月20(?)，书写日存在疑问；两位士官要求与白人效忠派退伍军人同等土地待遇。
- **来源**：[V6016](https://archives.novascotia.ca/africanns/archives/?ID=32)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1785｜Black Pioneers老兵仅获Digby各一英亩授地

- **行动主体**：Black Pioneers退伍军人；新斯科舍殖民政府
- **历史地点**：Digby, Nova Scotia；坐标未核。
- **实际行动与性质**：新斯科舍档案馆说明在1785年仅各获一英亩，土地实际位置与权属测图未逐宗读档；按州档声明区分授地文书和实际耕作。
- **来源**：[V6016](https://archives.novascotia.ca/africanns/archives/?ID=32)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1787｜Juba号航次从旧卡拉巴尔购买230名被奴役非洲人

- **行动主体**：船东James Rogers & Co；船长John Kennedy；被奴役非洲人
- **历史地点**：Bristol / Old Calabar, Nigeria；坐标未核。
- **实际行动与性质**：馆方记1787年购买230名被奴役者并装运象牙、棕榈油和红木；时间为航次年，确切交易日未知。
- **来源**：[V6011](https://www.discoveringbristol.org.uk/slavery/routes/bristol-to-africa/shipping/four-ships-fortunes/)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1787｜Juba号抵达圣文森特贩卖幸存者

- **行动主体**：被奴役非洲人；Juba船员与种植园买主
- **历史地点**：Saint Vincent, Caribbean；坐标未核。
- **实际行动与性质**：Bristol研究记230名购入、201名抵达，29人未能抵达；出海死亡人数需核博物馆原文定义，不能当整个航次总死亡额和已付款。
- **来源**：[V6011](https://www.discoveringbristol.org.uk/slavery/routes/bristol-to-africa/shipping/four-ships-fortunes/)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1792｜African Queen号从布里斯托尔启程前往旧卡拉巴尔购买被奴役者

- **行动主体**：船东James Rogers；船长Samuel Stribling；非洲被奴役者
- **历史地点**：Bristol / Old Calabar；坐标未核。
- **实际行动与性质**：馆方记1792航次及贩运；页面不同段落人数口径不一致，所有候选人口损失统计保持空值，原账待查。
- **来源**：[V6011](https://www.discoveringbristol.org.uk/slavery/routes/bristol-to-africa/shipping/four-ships-fortunes/)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1793｜African Queen号贩运被奴役者抵达牙买加

- **行动主体**：African Queen船员；被奴役非洲人；牙买加种植园购买者
- **历史地点**：Jamaica (landing point unknown)；坐标未核。
- **实际行动与性质**：馆方记1793抵达牙买加；对其船上死亡数和人口分母同馆不同网页出现冲突，不能据此计算死者、利润或平均死亡率。
- **来源**：[V6011](https://www.discoveringbristol.org.uk/slavery/routes/bristol-to-africa/shipping/four-ships-fortunes/)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1797-12-18｜牙买加议会通过针对25岁以上被奴役非洲人的进口税草案

- **行动主体**：牙买加议会；Speaker Don Campbell
- **历史地点**：Spanish Town / Jamaica government (legislature location unverified)；坐标未核。
- **实际行动与性质**：1797-12-18议会通过、12-20上院通过的文字在法律转录末尾有记载，法定£10不是实际征税收入。
- **来源**：[V6007](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1797-1)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1797-12-23｜总督Balcarres批准牙买加年龄歧视性奴役进口税法

- **行动主体**：牙买加总督Balcarres、议会
- **历史地点**：Jamaica (exact signing room unverified)；坐标未核。
- **实际行动与性质**：1797-12-23签署，定自1798-12-31对25岁以上从非洲输入的被奴役者收£10殖民地币税；不同生效日单独记录。
- **来源**：[V6007](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1797-1)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1798-04-30｜多米尼加公布取缔支持山区逃亡社群的殖民法律

- **行动主体**：多米尼加总督、议会与当地逃亡者
- **历史地点**：Roseau, Dominica；坐标未核。
- **实际行动与性质**：1798年法规禁止向逃亡被奴役社群供应食物、衣服、武器，并有限度允许奴隶证词用于指控自由人；法条说明存在抗争但具体供给者姓名与有罪人数未知。
- **来源**：[V6009](https://slaveryandfreedomlaws.lib.unb.ca/laws/dominica-1798-0)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1798-04-30｜多米尼加正式公布追捕逃亡者及拍卖羁押者法

- **行动主体**：多米尼加议会、Provost Marshal、逃亡者
- **历史地点**：Roseau, Dominica；坐标未核。
- **实际行动与性质**：1798-04-30刊布，设追捕赏额和逾期卖出制度；法条却在批准行中出现与1797议会和1798议会日期相悖的1793-03-15，列为原刊异文冲突。
- **来源**：[V6008](https://slaveryandfreedomlaws.lib.unb.ca/laws/dominica-1798)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1798-12-31｜牙买加对输入25岁以上被奴役者征£10法定税开始生效

- **行动主体**：牙买加征税官与进口船舶商人
- **历史地点**：Jamaica ports (unspecified)；坐标未核。
- **实际行动与性质**：1797法律规定的生效点是1798-12-31，实际应税人数与实缴总税款尚无核实账册。
- **来源**：[V6007](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1797-1)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1799｜牙买加法律命令部分法属圣多明各关联被奴役者六个月内离境

- **行动主体**：牙买加殖民议会；Saint-Domingue相关被奴役移民
- **历史地点**：Jamaica / Kingston / Port Royal；坐标未核。
- **实际行动与性质**：1799法令针对1791-08-23起居住在法属岛屿的被奴役者，设强制送离和部分认证豁免；来源为1819法律摘录，目录的1799-01-01不作为确证日。
- **来源**：[V6010](https://slaveryandfreedomlaws.lib.unb.ca/laws/jamaica-1799)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

## 四、居民/被奴役者/原住民族的能动性与抵抗

本篇不得把受压制者归为被动受害者：其逃亡、组织、谈判、船上起义、争取土地和法律申诉都是独立行动。部分证词仅留于敌对殖民者的追捕公告，须按发话主体还原。

## 五、法律、经济及长期影响

有数字的船货、赏金、进口税与土地面积只采当时文书明确的“法定、估计、登记、报称”口径；无法独立核实的实际支付、船东净利润、死亡总数和真实区域面积一律null。跨18世纪后的生效/到期条款应标后续调查，不把1801年事件塞回1799年滑条。

## 六、地图GIS审查

所有此批事件仅具名地点（并不等于准确事件GPS）。船舶海上路线与跨岛强制迁运不绘直线；殖民纸面司法管辖不当主权实占；可据同时代测绘但未校准边界仅在主编审核后以虚线概略方案呈现。

## 七、下步逐页原档

优先获取相应登船账、宣誓副本、殖民法律原刊或报纸整版、原住民社区记录及人名/地名同一性证据，以便把故事节点从候审提高至可出版级。

## 第六轮增补：新增独立验证的具体行动

### 1779｜被奴役女性Judith Jackson逃到英军阵营争取自由

Colonial Williamsburg人物档案记Judith Jackson于1779年离开Norfolk的奴役生活投奔英国军事阵营；具体路线与最终抵达时刻未核。。具体行动者：Judith Jackson；其声索人John Clain；英国军队。历史地名：Norfolk, Virginia。

[V6014](https://www.colonialwilliamsburg.org/discover/18th-century-people/stories-of-women/escaping-to-freedom/)

### 1782-02-02｜Randolph家族刊广告追捕曾赴英国阵营的Eve

Colonial Williamsburg指出1782-02-02报纸刊登追捕Eve广告，反映1781逃亡后仍被追捕，不能把刊报日当实际逃亡日；之后又有1782-07-20变卖条款。。具体行动者：Eve；Randolph庄园殖民声索方。历史地名：Virginia Gazette / Williamsburg Virginia。

[V6014](https://www.colonialwilliamsburg.org/discover/18th-century-people/stories-of-women/escaping-to-freedom/)

### 1794-11-19｜英国Grenville与美国John Jay签订条约约定撤离西部堡垒

《杰伊条约》1794年11月19日在伦敦签署；第二条约定1796-06-01前撤出被1783条约划归美国的驻军堡垒，签署日不等于各据点实控交接日，原住民族领土权利仍另行调查。。具体行动者：英国外交大臣Lord Grenville、美国John Jay。历史地名：London, England (treaty signing)。

[V6024](https://guides.loc.gov/jays-treaty); [V6025](https://avalon.law.yale.edu/18th_century/jay.asp); [V6021](https://www.nps.gov/articles/jay-s-treaty.htm)

### 1795-06-24｜美国参议院对杰伊条约附条件表示批准同意

国会图书馆史料指1795年6月24日参院以20比10作出同意，须与1794签署、1795批准交换、1796实际军事撤离分开。。具体行动者：美国参议院、英国外交机关。历史地名：Philadelphia / United States Senate (deliberation city pending)。

[V6024](https://guides.loc.gov/jays-treaty); [V6025](https://avalon.law.yale.edu/18th_century/jay.asp)

