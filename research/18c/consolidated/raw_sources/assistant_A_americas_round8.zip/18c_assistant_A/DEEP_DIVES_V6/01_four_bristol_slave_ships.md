# 第六轮深入调查｜A01·A04·A20｜布里斯托尔四艘具名奴役船、货物账与反抗

**范围**：1700—1799；**状态**：研究候审；新关联事件 10 件。

## 一、背景及跨世纪起点

船东、船长、交易地点及统计口径应按每一艘船每一段航次独立登记。Prince of Orange 约100人跳海、Marlborough船上起义返航、Juba人数账、African Queen口径冲突，不可互相补数。

## 二、决策机构与执行人

按下列行动节点分别核对殖民议会、皇家总督、海上船长、公司和殖民民兵。法令、海关账、船客清单与实际登陆是不同类别，任何经纬度空值均有意保留。

## 三、具名事件、地点、行动和直接证据

### 1736｜Prince of Orange号从布里斯托尔经营奴役航次

- **行动主体**：船东Richard Farr & Co；船长Japhet Bird
- **历史地点**：Bristol / West African coast；坐标未核。
- **实际行动与性质**：馆方记载1736年航次并在西非购买、跨海贩运被奴役者；船期具体日和非洲交易点尚待原航次账。
- **来源**：[V6011](https://www.discoveringbristol.org.uk/slavery/routes/bristol-to-africa/shipping/four-ships-fortunes/)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1736｜Prince of Orange号载运者在圣基茨附近跳海抵抗

- **行动主体**：非洲被奴役者；船长Japhet Bird与船员
- **历史地点**：near Saint Kitts (St Kitts)；坐标未核。
- **实际行动与性质**：同一1736航次馆方记约100名男性跳海，33人溺亡，船长售出240名；实际海上位置、哪一天靠近圣基茨以及各人后来命运未知。1736航次与个别来源1737到达区分。
- **来源**：[V6011](https://www.discoveringbristol.org.uk/slavery/routes/bristol-to-africa/shipping/four-ships-fortunes/)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1752-03｜奴隶船Marlborough号由布里斯托尔前往西非

- **行动主体**：船东William Lougher & Co；船长Robert Codd
- **历史地点**：Bristol / Anomabu / Bonny；坐标未核。
- **实际行动与性质**：1752年3月离港，沿黄金海岸及博尼购买并非法商品化人口；后续西非地区航次各站具体天数未知。
- **来源**：[V6011](https://www.discoveringbristol.org.uk/slavery/routes/bristol-to-africa/shipping/four-ships-fortunes/)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1752-10｜Marlborough号被奴役者反抗、控制船舶并返回博尼

- **行动主体**：船上被奴役非洲人；船长Robert Codd；船员
- **历史地点**：off Bonny, West Africa (location approximate, no coordinate)；坐标未核。
- **实际行动与性质**：馆方记至10月购入420人、启航约三天发生反抗，舰被迫返Bonny；来源对不同地区被奴役者去向有记述，船的最终去向未证，海上位置保留null。
- **来源**：[V6011](https://www.discoveringbristol.org.uk/slavery/routes/bristol-to-africa/shipping/four-ships-fortunes/)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1753-03-31｜幸存水手John Harris对Marlborough反抗的书信见报

- **行动主体**：船员John Harris；Felix Farley’s Bristol Journal
- **历史地点**：Bristol (publication place)；坐标未核。
- **实际行动与性质**：馆方指出1753年3月31日报纸刊载John Harris致父亲关于Marlborough事件的书信；没有亲阅报纸扫描，证据等级为博物馆引述。
- **来源**：[V6011](https://www.discoveringbristol.org.uk/slavery/routes/bristol-to-africa/shipping/four-ships-fortunes/)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1787｜Juba号航次从旧卡拉巴尔购买230名被奴役非洲人

- **行动主体**：船东James Rogers & Co；船长John Kennedy；被奴役非洲人
- **历史地点**：Bristol / Old Calabar, Nigeria；坐标未核。
- **实际行动与性质**：馆方记1787年购买230名被奴役者并装运象牙、棕榈油和红木；时间为航次年，确切交易日未知。
- **来源**：[V6011](https://www.discoveringbristol.org.uk/slavery/routes/bristol-to-africa/shipping/four-ships-fortunes/)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1787｜Juba号抵达圣文森特贩卖幸存者

- **行动主体**：被奴役非洲人；Juba船员与种植园买主
- **历史地点**：Saint Vincent, Caribbean；坐标未核。
- **实际行动与性质**：Bristol研究记230名购入、201名抵达，29人未能抵达；出海死亡人数需核博物馆原文定义，不能当整个航次总死亡额和已付款。
- **来源**：[V6011](https://www.discoveringbristol.org.uk/slavery/routes/bristol-to-africa/shipping/four-ships-fortunes/)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1792｜African Queen号从布里斯托尔启程前往旧卡拉巴尔购买被奴役者

- **行动主体**：船东James Rogers；船长Samuel Stribling；非洲被奴役者
- **历史地点**：Bristol / Old Calabar；坐标未核。
- **实际行动与性质**：馆方记1792航次及贩运；页面不同段落人数口径不一致，所有候选人口损失统计保持空值，原账待查。
- **来源**：[V6011](https://www.discoveringbristol.org.uk/slavery/routes/bristol-to-africa/shipping/four-ships-fortunes/)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1793｜African Queen号贩运被奴役者抵达牙买加

- **行动主体**：African Queen船员；被奴役非洲人；牙买加种植园购买者
- **历史地点**：Jamaica (landing point unknown)；坐标未核。
- **实际行动与性质**：馆方记1793抵达牙买加；对其船上死亡数和人口分母同馆不同网页出现冲突，不能据此计算死者、利润或平均死亡率。
- **来源**：[V6011](https://www.discoveringbristol.org.uk/slavery/routes/bristol-to-africa/shipping/four-ships-fortunes/)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1798-04-30｜多米尼加正式公布追捕逃亡者及拍卖羁押者法

- **行动主体**：多米尼加议会、Provost Marshal、逃亡者
- **历史地点**：Roseau, Dominica；坐标未核。
- **实际行动与性质**：1798-04-30刊布，设追捕赏额和逾期卖出制度；法条却在批准行中出现与1797议会和1798议会日期相悖的1793-03-15，列为原刊异文冲突。
- **来源**：[V6008](https://slaveryandfreedomlaws.lib.unb.ca/laws/dominica-1798)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

## 四、居民/被奴役者/原住民族的能动性与抵抗

本篇不得把受压制者归为被动受害者：其逃亡、组织、谈判、船上起义、争取土地和法律申诉都是独立行动。部分证词仅留于敌对殖民者的追捕公告，须按发话主体还原。

## 五、法律、经济及长期影响

有数字的船货、赏金、进口税与土地面积只采当时文书明确的“法定、估计、登记、报称”口径；无法独立核实的实际支付、船东净利润、死亡总数和真实区域面积一律null。跨18世纪后的生效/到期条款应标后续调查，不把1801年事件塞回1799年滑条。

## 六、地图GIS审查

所有此批事件仅具名地点（并不等于准确事件GPS）。船舶海上路线与跨岛强制迁运不绘直线；殖民纸面司法管辖不当主权实占；可据同时代测绘但未校准边界仅在主编审核后以虚线概略方案呈现。

## 七、下步逐页原档

优先获取相应登船账、宣誓副本、殖民法律原刊或报纸整版、原住民社区记录及人名/地名同一性证据，以便把故事节点从候审提高至可出版级。
