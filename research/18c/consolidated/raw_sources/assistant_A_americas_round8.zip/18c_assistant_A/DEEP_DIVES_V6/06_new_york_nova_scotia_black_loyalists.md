# 第六轮深入调查｜C18·C19｜纽约撤离名册与新斯科舍黑人退伍军人土地抗争

**范围**：1700—1799；**状态**：研究候审；新关联事件 6 件。

## 一、背景及跨世纪起点

1783年船客名册、Betty被送回声索者、1784年Peters和Steel请愿、1785年Digby每人一英亩和1792迁居塞拉利昂草案，揭示自由与土地之间的持续争取。

## 二、决策机构与执行人

按下列行动节点分别核对殖民议会、皇家总督、海上船长、公司和殖民民兵。法令、海关账、船客清单与实际登陆是不同类别，任何经纬度空值均有意保留。

## 三、具名事件、地点、行动和直接证据

### 1783｜《黑人名册》记Betty被英方交还声称拥有她的Thomas Smith

- **行动主体**：逃亡女性Betty；Thomas Smith；英国登记官员
- **历史地点**：New York / embarkation administration；坐标未核。
- **实际行动与性质**：新斯科舍档案馆明确记载英当局接受奴隶主Thomas Smith的声索，将Betty交还；与另案Betty Truant身份未知，不合并为同一人。
- **来源**：[V6015](https://archives.novascotia.ca/africanns/book-of-negroes/)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1783-04-23｜英国在纽约开始登记赴新斯科舍黑人效忠派船客

- **行动主体**：Guy Carleton驻纽约英方行政；黑人效忠派及家属
- **历史地点**：New York (registration context)；坐标未核。
- **实际行动与性质**：新斯科舍档案馆指出《黑人名册》登记窗口为1783-04-23至11-30，约3000人名单是申请/登船记录人口，不等于均获得土地或法律保障。
- **来源**：[V6015](https://archives.novascotia.ca/africanns/book-of-negroes/)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1783-11-30｜赴新斯科舍黑人效忠派登记阶段结束

- **行动主体**：纽约英方登记官；黑人移民
- **历史地点**：New York departure ports；坐标未核。
- **实际行动与性质**：档案馆将名册内英国版的船客登记结束于1783-11-30；这里是清单覆盖窗口末日，不能当所有黑人最后一船到岸日。
- **来源**：[V6015](https://archives.novascotia.ca/africanns/book-of-negroes/)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1784-08｜Black Pioneers老兵Peters与Murphy Steel请愿平等分地

- **行动主体**：Thomas Peters；Murphy Steel；新斯科舍殖民政府
- **历史地点**：Nova Scotia / Digby；坐标未核。
- **实际行动与性质**：新斯科舍档案馆RG1卷359件65署1784年8月20(?)，书写日存在疑问；两位士官要求与白人效忠派退伍军人同等土地待遇。
- **来源**：[V6016](https://archives.novascotia.ca/africanns/archives/?ID=32)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1785｜Black Pioneers老兵仅获Digby各一英亩授地

- **行动主体**：Black Pioneers退伍军人；新斯科舍殖民政府
- **历史地点**：Digby, Nova Scotia；坐标未核。
- **实际行动与性质**：新斯科舍档案馆说明在1785年仅各获一英亩，土地实际位置与权属测图未逐宗读档；按州档声明区分授地文书和实际耕作。
- **来源**：[V6016](https://archives.novascotia.ca/africanns/archives/?ID=32)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1792-01-07｜新斯科舍行政长官拟任命John Clarkson护送自愿迁塞拉利昂黑人

- **行动主体**：Richard Bulkeley；John Clarkson；新斯科舍黑人社群
- **历史地点**：Halifax, Nova Scotia；坐标未核。
- **实际行动与性质**：Nova Scotia RG1卷419第17号公开转录的是1792-01-07拟稿，为希望迁往塞拉利昂者提供船只与护送；不得将草案直接等同每个人实际登船。
- **来源**：[V6017](https://archives.novascotia.ca/diaspora/archives/?ID=17&Page=201112037&Transcript=1)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

## 四、居民/被奴役者/原住民族的能动性与抵抗

本篇不得把受压制者归为被动受害者：其逃亡、组织、谈判、船上起义、争取土地和法律申诉都是独立行动。部分证词仅留于敌对殖民者的追捕公告，须按发话主体还原。

## 五、法律、经济及长期影响

有数字的船货、赏金、进口税与土地面积只采当时文书明确的“法定、估计、登记、报称”口径；无法独立核实的实际支付、船东净利润、死亡总数和真实区域面积一律null。跨18世纪后的生效/到期条款应标后续调查，不把1801年事件塞回1799年滑条。

## 六、地图GIS审查

所有此批事件仅具名地点（并不等于准确事件GPS）。船舶海上路线与跨岛强制迁运不绘直线；殖民纸面司法管辖不当主权实占；可据同时代测绘但未校准边界仅在主编审核后以虚线概略方案呈现。

## 七、下步逐页原档

优先获取相应登船账、宣誓副本、殖民法律原刊或报纸整版、原住民社区记录及人名/地名同一性证据，以便把故事节点从候审提高至可出版级。

## 第六轮增补：新增独立验证的具体行动

### 1799｜Mary Perth前往英格兰并参与跨大西洋黑人社群活动

殖民威廉斯堡据新斯科舍及塞拉利昂黑人社群家史，记Mary Perth于1799年赴英格兰后返回塞拉利昂；仅提年，不能推断具体抵港日和行船路线。。具体行动者：Mary Perth、Caesar、Patience家族。历史地名：England (destination not documented to city precision)。

[V6014](https://www.colonialwilliamsburg.org/discover/18th-century-people/stories-of-women/escaping-to-freedom/)

