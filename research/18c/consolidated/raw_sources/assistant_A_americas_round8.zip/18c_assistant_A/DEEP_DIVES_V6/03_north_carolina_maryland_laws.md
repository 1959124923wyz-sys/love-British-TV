# 第六轮深入调查｜C21·C22｜北卡税制与马里兰惩罚法

**范围**：1700—1799；**状态**：研究候审；新关联事件 15 件。

## 一、背景及跨世纪起点

以殖民议会、地方白人业主、被奴役者与自由有色居民为不同政治行动主体；目录推定日不可伪造立法日，惩罚许可不可充作已执行处刑数。

## 二、决策机构与执行人

按下列行动节点分别核对殖民议会、皇家总督、海上船长、公司和殖民民兵。法令、海关账、船客清单与实际登陆是不同类别，任何经纬度空值均有意保留。

## 三、具名事件、地点、行动和直接证据

### 1712-06-07｜南卡殖民议会规定基督教洗礼不得改变被奴役法律身份

- **行动主体**：南卡罗来纳殖民议会与总督Charles Craven
- **历史地点**：Charles Town / South Carolina；坐标未核。
- **实际行动与性质**：1712年6月7日法令第XXXIV条允许受洗但拒绝因基督教洗礼获得自由；该法本身未证明任何个体受洗后被怎样处置。
- **来源**：[V6001](https://slaveryandfreedomlaws.lib.unb.ca/laws/south-carolina-1712-0)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1723｜北卡殖民议会向12岁以上自由黑人及混合血统居民征收人头税

- **行动主体**：北卡罗来纳领主政府与殖民议会
- **历史地点**：Edenton, North Carolina；坐标未核。
- **实际行动与性质**：法条对12岁及以上自由黑人与混合血统居民规定税负，并涉及与该群体结婚的白人；1月1日为目录归档推定日，真实通过日未知。
- **来源**：[V6002](https://slaveryandfreedomlaws.lib.unb.ca/laws/north-carolina-1723)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1723｜北卡法条规定已获释者离境义务并惩罚重新入境

- **行动主体**：北卡殖民议会
- **历史地点**：North Carolina；坐标未核。
- **实际行动与性质**：法律指出获释者应于六个月内离境，并修订重新进入辖区者的拘捕/劳动处罚；它陈述既存和新增法律，未证明卖身/驱逐已发生的人数。
- **来源**：[V6002](https://slaveryandfreedomlaws.lib.unb.ca/laws/north-carolina-1723)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1726-03-11｜南卡法令强制种植园主配置白人雇员监控奴役劳动

- **行动主体**：南卡殖民议会与Arthur Middleton
- **历史地点**：Charles Town / South Carolina；坐标未核。
- **实际行动与性质**：条例要求拥有被奴役者的庄园至少雇两名白人，并按超过20名男性被奴役者后每10人增加一名白人；标准是法律义务，不是落实名单。
- **来源**：[V6003](https://slaveryandfreedomlaws.lib.unb.ca/laws/south-carolina-1726)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1729｜马里兰议会授权对被奴役重罪犯施行肢解及死刑

- **行动主体**：马里兰领主殖民议会
- **历史地点**：Maryland；坐标未核。
- **实际行动与性质**：针对被奴役者被裁定特定杀人、纵火罪行，允许砍手、绞刑和分尸展示；目录日期1729-07-01注明inexact，记录年精度。
- **来源**：[V6004](https://slaveryandfreedomlaws.lib.unb.ca/laws/maryland-1729)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1736-11-05｜弗吉尼亚Gazette刊登Poplar与Planter两名逃亡者追捕广告

- **行动主体**：被奴役者Poplar、Planter；登广告奴隶主
- **历史地点**：Williamsburg, Virginia (newspaper publication)；坐标未核。
- **实际行动与性质**：1736-11-05刊报，两人实际出走分别早于刊报。Poplar被奴隶主称为outlawed是对方法律话语；刊报地点不等于逃亡GPS。
- **来源**：[V6020](https://research.colonialwilliamsburg.org/Foundation/journal/Autumn10/ads.cfm)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1741｜北卡奴役法规将交易与逃亡追捕纳入殖民地法院程序

- **行动主体**：北卡罗来纳议会
- **历史地点**：North Carolina；坐标未核。
- **实际行动与性质**：1741年仆役与奴役法律规定未经主人许可不得与被奴役者交易、对部分不法将自由人当奴隶出售者设置诉讼权；其自由权诉讼仍有差别待遇。
- **来源**：[V6006](https://slaveryandfreedomlaws.lib.unb.ca/laws/north-carolina-1741)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1769-02-09｜弗吉尼亚Gazette记载Peter擅长写通行证以逃避奴役追捕

- **行动主体**：被奴役者Peter；声索人William Macon
- **历史地点**：Williamsburg (newspaper) / Virginia；坐标未核。
- **实际行动与性质**：William Macon在广告中抱怨Peter能读写、曾自行写通行证；这反映抵抗技术，是奴隶主的指控而非独立取得的Peter证言。
- **来源**：[V6012](https://www.colonialwilliamsburg.org/discover/sources/the-virginia-gazettes/slavery-and-the-virginia-gazette/)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1769-11-09｜弗吉尼亚Gazette刊登追捕Amy广告，记述以服饰争取自由

- **行动主体**：被奴役女性Amy；奴隶主Parker Hare
- **历史地点**：Williamsburg, Virginia (newspaper)；坐标未核。
- **实际行动与性质**：报纸称Amy约30岁，携银扣及换洗衣物外逃，可能借衣着被视为自由人；具体逃亡日期、地点未证，刊报时间确证。
- **来源**：[V6012](https://www.colonialwilliamsburg.org/discover/sources/the-virginia-gazettes/slavery-and-the-virginia-gazette/)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1771-01-10｜弗吉尼亚Gazette刊登追捕Sam及三人的广告

- **行动主体**：被奴役者Sam等四人；奴隶主James Walker
- **历史地点**：Williamsburg, Virginia (newspaper)；坐标未核。
- **实际行动与性质**：广告记载Sam遭鞭打旧伤，以及四名被奴役者离开；报纸奴隶主的定性不可当作抵抗者自身主张。
- **来源**：[V6012](https://www.colonialwilliamsburg.org/discover/sources/the-virginia-gazettes/slavery-and-the-virginia-gazette/)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1773-10-18｜弗吉尼亚被奴役少女Fanny自行逃离John Lewis

- **行动主体**：Fanny；奴隶主John Lewis
- **历史地点**：Williamsburg / Tidewater Virginia (route unverified)；坐标未核。
- **实际行动与性质**：殖民威廉斯堡据1774广告重建15岁左右Fanny在1773-10-18逃离；可能去见母亲Joan但路线和最终去向都不明。
- **来源**：[V6013](https://www.colonialwilliamsburg.org/discover/18th-century-people/stories-of-black-life/underground-allies-the-incomplete-story-of-fanny-and-moses/)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1774-01-27｜John Lewis刊登搜捕Fanny广告并怀疑Moses协助

- **行动主体**：奴隶主John Lewis；Fanny；被怀疑的Moses
- **历史地点**：Williamsburg, Virginia (newspaper)；坐标未核。
- **实际行动与性质**：广告指控另一名被奴役者Moses可能保护Fanny；怀疑为奴隶主一方说法，不写成已证Moses实际窝藏。
- **来源**：[V6013](https://www.colonialwilliamsburg.org/discover/18th-century-people/stories-of-black-life/underground-allies-the-incomplete-story-of-fanny-and-moses/)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1774-03-10｜Prince William监狱刊报拘押John Hedgman

- **行动主体**：John Hedgman；地方监狱官员
- **历史地点**：Prince William County / Virginia Gazette Williamsburg；坐标未核。
- **实际行动与性质**：报纸记23岁John Hedgman因被怀疑逃亡而拘留；是否合法奴役身份或最终解送未证。
- **来源**：[V6012](https://www.colonialwilliamsburg.org/discover/sources/the-virginia-gazettes/slavery-and-the-virginia-gazette/)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1774-12-15｜弗吉尼亚被奴役织工Gabriel逃亡通缉广告刊登

- **行动主体**：Gabriel；声索人John Fox
- **历史地点**：Williamsburg, Virginia (newspaper)；坐标未核。
- **实际行动与性质**：殖民威廉斯堡馆方引述广告称Gabriel会织布、读书、拉小提琴，广告时间确证而出走准确日未知。
- **来源**：[V6012](https://www.colonialwilliamsburg.org/discover/sources/the-virginia-gazettes/slavery-and-the-virginia-gazette/)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

### 1776-07-19｜弗吉尼亚Gazette刊载对原住民出身John Newton的搜捕

- **行动主体**：John Newton；登广告殖民居民
- **历史地点**：Williamsburg / Virginia Gazette；坐标未核。
- **实际行动与性质**：1776-07-19刊报称John Newton为出生于原住民社群的混合血统契约仆役；法律身份原话servant，不能从广告直接改写为终身动产奴隶。
- **来源**：[V6012](https://www.colonialwilliamsburg.org/discover/sources/the-virginia-gazettes/slavery-and-the-virginia-gazette/)
- **证据等级**：原文转录／机构解读可读，尚未完整手稿逐页复核；`research_only`。

## 四、居民/被奴役者/原住民族的能动性与抵抗

本篇不得把受压制者归为被动受害者：其逃亡、组织、谈判、船上起义、争取土地和法律申诉都是独立行动。部分证词仅留于敌对殖民者的追捕公告，须按发话主体还原。

## 五、法律、经济及长期影响

有数字的船货、赏金、进口税与土地面积只采当时文书明确的“法定、估计、登记、报称”口径；无法独立核实的实际支付、船东净利润、死亡总数和真实区域面积一律null。跨18世纪后的生效/到期条款应标后续调查，不把1801年事件塞回1799年滑条。

## 六、地图GIS审查

所有此批事件仅具名地点（并不等于准确事件GPS）。船舶海上路线与跨岛强制迁运不绘直线；殖民纸面司法管辖不当主权实占；可据同时代测绘但未校准边界仅在主编审核后以虚线概略方案呈现。

## 七、下步逐页原档

优先获取相应登船账、宣誓副本、殖民法律原刊或报纸整版、原住民社区记录及人名/地名同一性证据，以便把故事节点从候审提高至可出版级。
