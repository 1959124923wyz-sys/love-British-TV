# 第六轮累计研究包说明（最终）

本地保存前六轮全部调查资料：**407件独立候审事件**（本轮新增49）、**335条来源记录**（本轮新增25，其中305个唯一URL，历史底账存在29组重复URL）、**49个A/C系列专题档案**。193件事件精确到日，50件到月，164件到年。

新增 `DEEP_DIVES_V6/` 十篇深入调查、`CRITICAL_CASE_STUDIES_V6/` 五篇重点证据个案；`PRIMARY_LAW_CLAUSE_MATRIX_V6.csv/json` 记录24项原文法条证据，`SHIP_VOYAGES_V6.csv/json` 汇总四艘具名贩奴航次，`CLAIM_SOURCE_MATRIX_V6.csv/json` 提供逐事来源关联。

地图 `MAP_CANDIDATES.geojson` 仅保留24个有据官方现代遗址代表点；383件事件经纬度缺乏精准证据仍为null；**无新增历史实控Polygon、无捏造海上路线**。新地名线索见 `MAP_PLACE_RESEARCH_V6.csv`，争议见 `GAPS_AND_CONFLICTS.md` 和 `GEO_AND_CHRONOLOGY_AUDIT_V6.md`。

**研究数据并非正式地图已发表事实**；来源原始法律数字化转录也不代表馆藏原件逐页亲核。跨来源使用时务必以不同网址和独立档案为准，不得把同一原文不同入口视为双重确认。

`REFERENCE/BUILD_ROUND6.py` 仅可在第五轮原始基线上一次性运行；**不要在当前完整包重复运行以免新增事件ID撞车**。校验结果在`REFERENCE/VALIDATION_V6.json`，逐文件散列在`MANIFEST_V6.json`和`REFERENCE/SHA256_V6.txt`。GitHub未修改。
