# 第三轮地理研究与边界证据门禁

- **Fort Stanwix**：现代NPS纪念地参照点`43.210534,-75.455576`（纬、经，`V345`）；NPS另有Willett入口`43.210338,-75.457701`（`V303`），前者用于本地图候选，绝不混用后者去称条约签字GPS。
- **1768边界地图原图**：美国NPS `V301` 展示Guy Johnson按既有Evans图修订的历史界线；原地图的红线描述的是英王/六族协议中的**政治声索、地权争议**，不是英军实际军管面。尚未进行原图地理配准，也未核地图版式/测绘误差，暂不绘LineString，未来如批准只能为**注明出处和不确定性的虚线**，不可进入真实占地面积。
- **Castillo de San Marcos**：Recreation.gov/NPS `V344` `29.89785701,-81.31217173`仅现代西班牙堡垒参考点；1740年英国Oglethorpe在城外的围城阵地、Fort Mose与攻防路线没有来源GPS，均不以此点重复代替。
- **Fort Mose**：Florida State Parks `V313`/NPS `V314`明确是可定位的历史地区，但本次未证原堡堤围WGS84，留空坐标等待历史遗址数字测绘。
- **Sally号航线**：1764 Providence；1765 西非River Grande、巴巴多斯、安提瓜、Providence各地可证，原航海账本并未在本轮逐页扫描，所有开放海域事件坐标null；严禁直线模拟商船真实航迹。
- **GHS 1733 treaty**：Yamacraw Bluff与现代Wright Square上的Tomochichi纪念物是两处不同地点；`V346`墓址GPS不用于1733条约发生地。
- **1774 Dunmore & 1724 Norridgewock**：河流交汇、村落遗址尚未找到来源经证现代代表点，均保留null。
- **Havana**：可证具体城港，但无法凭城市中心经纬度说明1762港内战舰和炮位，暂留null。

汇总：**新增2个现代官方地点参照坐标，新增2个GeoJSON Point事件要素，0个控制Polygon、0条虚构航海或历史边界LineString。**
