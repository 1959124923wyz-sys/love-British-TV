# 爱英TV助手2：工程来源与跨世纪对接说明

- 读取仓库：`1959124923wyz-sys/love-British-TV`；PR #289 暂存头分支 `research/18c-master-agenda-acadian-map-20261105`。
- 阅读 `AGENTS.md`、`docs/templates/16c-story-map-standard/README.md`、`docs/MAP_FIRST_CARTOGRAPHY_STANDARD.md`、`docs/HISTORICAL_SPATIAL_NARRATIVE_STANDARD.md`。16C模板是专题证据、事件叙事与可点击位置交互参考，不作为18C事实数据。
- PR文件：`research/18c/MAJOR_TOPICS.json`、`research/18c/SOURCE_REGISTRY.json`、`research/18c/CROSS_CENTURY_STORY_CONTINUITY.json`。37个B/E专题ID均按原清单保留，原研究窗只表示研究范围。
- `E6-T12`：英格兰东印度公司1600—1698年商馆/据点，18世纪本古伦1719起义迫撤、1723恢复，1757普拉西、1765 Diwani等形成不同性质的公司权力变化。原17C条目带1874历史公司寿命元数据不是1874年真实政治控制审定。
- `E6-T13`：皇家非洲公司1698前商业经营继续进入1700年代；1698贸易特权变化与1750新商人公司制度变化分别研究。
- `E6-T17-AFRICAN-FORTS`：海岸角等沿岸英方堡垒可续查；17C丹吉尔1684年已撤，不许续到18C。
- 原跨世纪注册表写明上述所有 `geometry_auto_carry=false`、`year1700_state=requires_separate_political_and_cartographic_verification`，本包没有替原项目核准任何殖民政治Polygon。
- 18C原PR `SOURCE_REGISTRY.json` 的源代号S12、S13、S14、S15、S16、S17、S18、S27、S28、S29、S30、S31、S35、S36、S38、S47、S49、S50、S51、S52、S55、S58、S59、S78等是项目编辑参考；本包采用独立`BSxx`，实体URL与原档号写在`SOURCE_REGISTRY.json`，不能无证据按数字强行合并。
- 权力类别：EIC商馆贸易许可、EIC实际驻军与税权、英国海军临时占城、英国议会监督、盟友领土、当地国家独立、主权争议地区，均要逐年分开。
- 未经编辑审批，所有产物仅研究候选；无GitHub提交。
