# AB-NEW-044｜1700—1799黄金海岸英商堡垒多节点：Nzema、Ahanta、Ga/Fante自主

状态：`research_only` / `propose_to_editor`。原有E18-B/E系列ID保持不动。

**推荐与原项目交叉索引：** `E18-E10`。

## 问题与发现
并列具体堡垒开建、当地准许和包围抵抗，修复只在海岸角和阿诺马布落点的缺口。

## 逐件证据事件
### AB-NEW-044-001｜1700｜Dixcove英商堡垒在Infuma/Ahanta抗争下延宕施工
- 行动者：English traders; local Infuma/Ahanta chiefs; Dutch interests；地点：Dixcove, Ghana；日期精度：year。
- 事实与权利：GMMB记英方1692开建后遭当地多次围困；1700有否在建需查堡守日记，本行仅作为17C→18C待核连续性。
- 法权分类：`coastal_fort_local_agency_not_colonial_territory`；可验证程度：`year1700_continuity_pending_contemporary_log`。
- 证据：[BS156](https://gmmb.gov.gh/fort-metal-cross-dixcove-1692/)

### AB-NEW-044-002｜{'start_year': 1720, 'end_year': 1729, 'interpretation': 'decade-only; year null'}｜英商在Tantumquery修小堡（具体年份未核）
- 行动者：English traders; coastal local authorities；地点：Otuam / Tantumquery, Ghana；日期精度：decade。
- 事实与权利：GMMB确定为1720年代，年份栏留空，先按1720—1729年研究窗，不编造1721年为确年。
- 法权分类：`small_trading_fort_not_hinterland_colony`；可验证程度：`1720s_only`。
- 证据：[BS157](https://gmmb.gov.gh/the-fort-at-tantumquery/)

### AB-NEW-044-003｜1742｜Prampram新建Fort Vernon英商堡（建筑年份来源相互矛盾）
- 行动者：British coastal traders; Ga coastal communities；地点：Prampram, Ghana；日期精度：year。
- 事实与权利：GMMB单堡网页记1742，大学加纳堡垒表列1745，暂按双方冲突记录并在地图终稿年核实前不自动启用。
- 法权分类：`fort_site_history_date_dispute`；可验证程度：`year_conflict_1742_vs_1745`。
- 证据：[BS158](https://gmmb.gov.gh/fort-vernon-prampram/)

### AB-NEW-044-004｜1750｜Dixcove堡至1750装炮据馆方称可容25门
- 行动者：British Gold Coast fort personnel; Ahanta people；地点：Fort Metal Cross, Dixcove；日期精度：year。
- 事实与权利：GMMB称堡至1750年具备容纳至多25门炮的设施，该数为设计/装载能力，不是逐门现存清单。
- 法权分类：`military_fort_capacity_not_area`；可验证程度：`confirmed_in_cited_secondary_or_printed_edition`。
- 证据：[BS156](https://gmmb.gov.gh/fort-metal-cross-dixcove-1692/)

### AB-NEW-044-005｜1768｜Nzema酋长许可下英国商人修建Apollonia堡
- 行动者：Nzema chief Amenihyia; Committee of Merchants Trading to Africa；地点：Beyin / Cape Apollonia, Ghana；日期精度：year。
- 事实与权利：1766起筹料、1768开建；酋长允许建堡以平衡荷方势力并促贸易，不能视为Nzema国家主权移转。
- 法权分类：`local_permission_for_fort_not_nzema_sovereignty`；可验证程度：`confirmed_in_cited_secondary_or_printed_edition`。
- 证据：[BS155](https://gmmb.gov.gh/fort-apollonia-beyin-1768/)

## 经济或人口分项（若有）

现有足额/实收货币账无法确认，保持null；不得推断成本、利润或净汇出。

## 地图与下一步
所有本专题地理对象先作具名点或未定位参考；不得将地方胡椒贸易许可、宗主关系、陆军战场或现代省界填成公司实占多边形；有确切让地条文也必须先核逐村或历史岛岸边界。

**核查缺口**：需核条约的当地语言版本、年度实际税收和付款凭据、当事人答辩、原档页影及能够校准的历史地籍。
**档案声明**：18世纪物理原件未亲阅；1909编辑出版条约文字与馆藏目录保留不同阅读等级。

## 第四轮最终地理考据（禁用时代错置）

- 现代 **Fort Victoria** 按[加纳博物馆机构](https://gmmb.gov.gh/fort-victoria-cape-coast/)建于**1821年**，所在地前建筑是**1712年Phipps Tower**。因此现代坐标只定位1712旧堡所在之地，不把1821建筑倒画成1712堡垒。新增事件`AB-NEW-044-006`。
- English Komenda早期筑堡年：联合国教科文组织报告提1672，加纳政府页面含明显1974排版错误，加纳大学堡垒表列1708；保留不同建筑阶段/年代待核，不能挑其中一年宣称有确证新征服。
- 《Making an African City》研究指出1730年代Ga人仍控制沿海交易，Fort James英商驻点并非英国占有整个Accra和Ga政治社会。
