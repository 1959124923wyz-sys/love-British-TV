# AB-NEW-011｜1750年非洲贸易法设Company of Merchants Trading to Africa

- **原母题关联**：`E18-E10`
- **独立新专题必要性**：原1750法案和Royal African Company的解散/堡垒制度切换

## 可核参考

- [BS62 1750 Act for Extending and Improving Trade to Africa original printed booklet catalogue](https://collections.si.edu/search/detail/edanmdm%3Anmaahc_2019.28.2?print=yes)；阅读等级：original_printed_act_catalogue_read。

## 待核原件与地图

进入新专题须主编决定新正式编号，补足原始公司日志、财政原卷、地方视角；现阶段既不自动上图，也不改变项目原专题ID。
