# AB-NEW-075｜1773—1799年孟加拉鸦片垄断与农民契约强制

> **research_only / 第七轮**；法定许可、组织实施、已知问题与个别越权必须分证据等级。

## 历史过程与机制：鸦片农民被卷入国家采购制度

1773年Hastings掌握Patna鸦片采购并在合同限制强迫；后续禁强迫条款被取消，1788年Cornwallis发现部分农民被认为必须继续种植。1785年公司重新招标，1797年设Patna与Benaras鸦片代理，1799年第VI号规章禁止不合规定的私人种植。

## 归责与当地行动

有正式垄断，也有执法强迫知情线索，但应单列明确法权、默许的合同操作、承包商个人暴力及农民反抗的证据，不能全称法律明文授予鞭打权。

## 本轮新增时间线与证据

### AB-R7-POL-019｜1773｜1773年公司将比哈尔鸦片采购改为统一专卖管理

公司实施鸦片垄断采购；最初合同曾明令不得强迫农民种罂粟，后此项保护被取消。

**涉事主体**：Warren Hastings、东印度公司Patna管理人员；种植农民。**地点/行政层级**：Patna, Bihar。**来源**：[BS18](https://www.cambridge.org/core/journals/international-review-of-social-history/article/emancipation-of-the-opium-cultivators-in-benares/094C2D32BEC39A82574A5FA91E64226F)。

**GIS限制**：不引入历史实控面，法规的通过地点与受影响的地区互不等同。

### AB-R7-POL-022｜1785｜1785年7月公司对鸦片承包合同公开竞价

Cambridge研究记公司因征收问题、农民压迫和质量变化，于11 July 1785决定公开竞价未来四年合同。

**涉事主体**：东印度公司理事会；Patna鸦片承包商；种植农民。**地点/行政层级**：Patna / Bengal。**来源**：[BS253](https://www.cambridge.org/core/journals/international-review-of-social-history/article/contract-work-and-resistance-boatmen-in-early-colonial-eastern-india-1760s1850s/F839EA9C4FFBB04A9DC2F6A9145CD0E8)。

**GIS限制**：不引入历史实控面，法规的通过地点与受影响的地区互不等同。

### AB-R7-POL-023｜1788｜1788年Cornwallis调查发现农民种植鸦片受习惯性强迫

尽管合同无明确强迫授权，1788年调查发现普遍认为农民被强迫继续种罂粟；属于当局已知并调查的实践，不虚构法律允许所有强迫手段。

**涉事主体**：Lord Cornwallis；种植农民；公司鸦片代理与承包商。**地点/行政层级**：Bihar / Benaras。**来源**：[BS18](https://www.cambridge.org/core/journals/international-review-of-social-history/article/emancipation-of-the-opium-cultivators-in-benares/094C2D32BEC39A82574A5FA91E64226F)。

**GIS限制**：不引入历史实控面，法规的通过地点与受影响的地区互不等同。

### AB-R7-POL-033｜1797｜1797年公司改行Patna与Benaras鸦片代理制

公司撤销主要私人承包制，设两地代理统一管理种植数量与采购。

**涉事主体**：东印度公司、Patna与Benares鸦片代理、农民。**地点/行政层级**：Patna and Benaras。**来源**：[BS252](https://www.cambridge.org/core/journals/modern-asian-studies/article/poor-mans-crop-evading-opium-monopoly/199D0743201BF76C8ADA72F625B85FAD)。

**GIS限制**：不引入历史实控面，法规的通过地点与受影响的地区互不等同。

### AB-R7-POL-034｜1799｜1799年公司Regulation VI限制私种罂粟与私人鸦片贸易

1799 Regulation VI限定鸦片种植田亩与交货，限制私人种植和交易并设惩罚；具体规章原版需对校。

**涉事主体**：公司孟加拉政府、种植农民、鸦片代理。**地点/行政层级**：Bihar / Benares。**来源**：[BS252](https://www.cambridge.org/core/journals/modern-asian-studies/article/poor-mans-crop-evading-opium-monopoly/199D0743201BF76C8ADA72F625B85FAD)。

**GIS限制**：不引入历史实控面，法规的通过地点与受影响的地区互不等同。

## 经济/人口证据与原卷缺口

每个地区需要种植面积、合同最低供应价、交货与扣款、实际利润和惩处登记，以及1799原令译本。

### 来源阅读深度

| ID | 网址或档案 | 本轮实际阅读级别 |
|---|---|---|
| BS18 | [Emancipation of opium cultivators in Benares](https://www.cambridge.org/core/journals/international-review-of-social-history/article/emancipation-of-the-opium-cultivators-in-benares/094C2D32BEC39A82574A5FA91E64226F) | journal_extract_read；原史料纸卷未亲读 |
| BS252 | [Poor Man’s Crop: Evading Opium Monopoly](https://www.cambridge.org/core/journals/modern-asian-studies/article/poor-mans-crop-evading-opium-monopoly/199D0743201BF76C8ADA72F625B85FAD) | peer_reviewed_html_read；原史料纸卷未亲读 |
| BS253 | [Boatmen contract work and resistance, Company opium governance](https://www.cambridge.org/core/journals/international-review-of-social-history/article/contract-work-and-resistance-boatmen-in-early-colonial-eastern-india-1760s1850s/F839EA9C4FFBB04A9DC2F6A9145CD0E8) | peer_reviewed_html_search_excerpt_read；原史料纸卷未亲读 |

**候审地图**：全部无可靠历史边界，本篇事件仅作为时间轴、财政/政策关联和将来核实堡垒或城市参考点的研究素材。
