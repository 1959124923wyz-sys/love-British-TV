# AB-NEW-024｜1758—1783年英属塞内冈比亚省、阿拉伯胶专利与圣路易易手

**范围与状态：1700—1799研究候审，未发表；保留原37母题ID不变。**

**对应母题：** `E18-E07`。**单立理由：**1765正式殖民省在1758军事占领和1779法国反攻之间形成，1783和约又明确恢复，远超过单次夺堡。

## 一、背景与权力性质

英国1758年夺取法国在塞内加尔河的Saint-Louis，此前后还有Gorée、Podor及Galam的不同国际条约处理。Newton的研究明确英国1765—1779年在西非设“Province of Senegambia”（塞内冈比亚省），试图将当地军事防御、阿拉伯胶贸易和奴役贸易组织成可统筹的殖民管理网络。

## 二、具体过程与收益链

1763《巴黎和约》第10条承认法国恢复Gorée而英方取得塞内加尔若干贸易位置；1765设省并不等于英军控制整个塞内加尔—冈比亚河流域。John Carter Brown馆藏1779年法国地图说明当年法军重夺Saint-Louis，剑桥研究另显示英军1779重占Gorée。1783《凡尔赛和约》第9条重新将Gorée、Saint-Louis、Podor、Galam和部分岸点交法国。不同年份的Gorée驻军与法理必须有拆分记录。

## 三、当地政治主体与证据冲突

周边沃洛夫、Moorish和其他塞内冈比亚统治者与商人持续拥有自己的政治、关税与土地权益；英法条约未能替他们签署土地让渡。2024学术研究特别关注欧洲人同当地君主谈判的合作与纠纷。

## 四、地图可执行限制

可以核地名为Saint-Louis、Gorée、Fort James等港堡点；“Province”行政声索范围暂只有名称和时间，需查省内教区/海岸管辖表后方可提出局部虚线研究包络。

## 五、已有逐项事件（需主编审核）

## 六、经济数据引用（不重复加总）

当前尚无可核实的原币值或实收金额，本专题经济证据为空值，后续查账。

## 七、实际使用的来源与阅读深度

- **BS122 · Taylor and Francis / Journal for Maritime Research：** [Joshua D Newton Naval power and the Province of Senegambia, 1758–1779](https://www.tandfonline.com/doi/full/10.1080/21533369.2013.851840)；档案号 `无`；已读层级 `peer_reviewed_abstract_read`；纸质原始手稿未亲读。
- **BS125 · John Carter Brown Library Brown University：** [1779 rare manuscript map Senegal and Gambia dedicated to Duc de Lauzun](https://jcblibrary.org/news/carte-du-cours-des-fleuves-du-senegal-et-de-gambie-dediee-et-presentee-monsieur-le-duc-de/)；档案号 `无`；已读层级 `university_library_map_context_read`；纸质原始手稿未亲读。
- **BS127 · Cambridge University Press / History in Africa：** [2024 study Senegambian treaties and local political rulers 1679–1815](https://www.cambridge.org/core/journals/history-in-africa/article/vivre-en-paix-et-en-bonne-intelligence-avec-les-princes-locaux-in-senegambia-in-the-age-of-slave-economy-diplomatic-treaties-trade-conflicts-and-peace-in-interaction-16791815/3D78436EE79DD7C86CF0CBDC3AD00DD5)；档案号 `无`；已读层级 `peer_reviewed_html_read`；纸质原始手稿未亲读。
- **BS128 · University of Perpignan digital legal history：** [French 1783 Treaty of Versailles full text articles 9-11](https://mjp.univ-perp.fr/traites/1783versailles.htm)；档案号 `无`；已读层级 `digitised_primary_treaty_transcription_read`；纸质原始手稿未亲读。

## 八、下一轮原档优先查验

1. 1765省行政成立原决议和任官档案
2. 1779圣路易夺堡具体月份与Gorée重占交接军报
3. 1783条约后实际撤军月日、甘比亚河内陆政治主体的协议

**制图审核声明：**任何已确认的现代坐标仅可作为历史事件的现代参考点，不可作为当年实控边界。条约、征税、战利品或人物获利不自动形成主权多边形。
