# AB-NEW-015｜1762—1764年马尼拉印度sepoy驻军劳动与逃兵政治

- **原母题关联**：`E18-E01`
- **独立新专题必要性**：Megan Thomas全文研究强调公司征兵体系和印度士兵自治与欠饷

## 可核参考

- [BS27 Securing Trade: military labor British Manila occupation](https://www.cambridge.org/core/journals/international-review-of-social-history/article/securing-trade-the-military-labor-of-the-british-occupation-of-manila-17621764/6DD8E645C2627FFD682DAA81FB59E35B)；阅读等级：scholarly_full_html_read。

## 待核原件与地图

进入新专题须主编决定新正式编号，补足原始公司日志、财政原卷、地方视角；现阶段既不自动上图，也不改变项目原专题ID。
