# AB-NEW-078｜1793年永久地税、土地所有权与民事税务法庭分权

> **research_only / 第七轮**；法定许可、组织实施、已知问题与个别越权必须分证据等级。

## 历史过程与机制：永久地税与民事司法分权的两面性

1793年Regulation I将1789–90各省十年期税额经董事批准转为长期固定，并确认若干地主产权。Regulation II将原由征税官兼任法官的Mal Adalat收入诉讼转至Diwani民事法院；这是为建立更可预测的产权和征税秩序。

## 归责与当地行动

法律文本自身强调地产经营与农作投资，但实际佃农租额、欠税没产及争讼费用对不同阶层作用分化。没有每个庄园地籍不可把现代省界当永久税制适用地实测图斑。

## 本轮新增时间线与证据

### AB-R7-POL-030｜1793｜1793年永久地税法将十年税额转为永久固定

Regulation I 1793在1789–90十年期税额基础上宣告永久固定，提高某些地主的产权保障；佃农地权和租额争议仍需各项法条逐核。

**涉事主体**：Cornwallis政府；公司董事会；孟加拉zamindar与ryot。**地点/行政层级**：Bengal, Bihar, Orissa。**来源**：[BS254](https://indiankanoon.org/doc/183597006/)。

**GIS限制**：不引入历史实控面，法规的通过地点与受影响的地区互不等同。

### AB-R7-POL-031｜1793｜1793年孟加拉地税法院权限转移到Diwani民事法院

Regulation II 1793废止Mal Adalat税务法庭并将若干诉讼交民事法院，政策文本试图避免征税者兼裁判者。

**涉事主体**：Cornwallis政府；税务Collectors；Diwani judges；本地居民。**地点/行政层级**：Calcutta / Bengal。**来源**：[BS185](https://indiankanoon.org/doc/117474657/)。

**GIS限制**：不引入历史实控面，法规的通过地点与受影响的地区互不等同。

## 经济/人口证据与原卷缺口

检查1793年原印法令修改版本、逐地主地契、1711/1793地税差异、法庭案件和农户份地。

### 来源阅读深度

| ID | 网址或档案 | 本轮实际阅读级别 |
|---|---|---|
| BS185 | [Bengal Land-Revenue Regulation II of 1793 text with later editorial amendments](https://indiankanoon.org/doc/117474657/) | secondary_legislation_reproduction_full_html_read；原史料纸卷未亲读 |
| BS254 | [Bengal Permanent Settlement Regulation 1793](https://indiankanoon.org/doc/183597006/) | historical_law_transcription_read；原史料纸卷未亲读 |

**候审地图**：全部无可靠历史边界，本篇事件仅作为时间轴、财政/政策关联和将来核实堡垒或城市参考点的研究素材。
