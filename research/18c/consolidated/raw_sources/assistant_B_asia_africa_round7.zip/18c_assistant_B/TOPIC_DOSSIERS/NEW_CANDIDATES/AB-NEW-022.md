# AB-NEW-022｜1775年Nandakumar刑事审判与加尔各答英式法院法权冲突

**范围与状态：1700—1799研究候审，未发表；保留原37母题ID不变。**

**对应母题：** `E18-B09`。**单立理由：**1774设法院后1775发生争议性审判处决，应独立核档案中法律适用与政治影响，不预断谋杀阴谋。

## 一、背景与权力性质

1773 Regulating Act后加尔各答新设最高法院与公司行政权之间的关系成为政治冲突场域。1775年Nandakumar（亦作Nuncomar）因伪造罪定罪并执行死刑，学界长期争论该案英式刑法适用、对Hastings指控的关联与法院政治地位。

## 二、具体过程与收益链

现有2026同行评审研究摘要提供法权争议与政治解释的线索，但刑事卷宗、法官意见、控诉与辩护陈词并未逐页亲查。研究档案只能准确陈述“判决、执行、争议”，既不直接把有罪判决转换为现代史学真相，也不在缺审判档时认定已证实的政治谋杀。

## 三、当地政治主体与证据冲突

Nandakumar本人、法院法官、公司总督委员会及孟加拉本地诉讼惯例均属不同主体。

## 四、地图可执行限制

只可落加尔各答法院城市代表点；司法权变化不对应可绘的“全部孟加拉新吞并领土”。

## 五、已有逐项事件（需主编审核）

## 六、经济数据引用（不重复加总）

当前尚无可核实的原币值或实收金额，本专题经济证据为空值，后续查账。

## 七、实际使用的来源与阅读深度

- **BS105 · British Library：** [IOR/L/PARL/2/9a Bengal Narrative: Rohilla, salt labour, 1764-1775 revenues](https://searcharchives.bl.uk/catalog/040-001116470)；档案号 `IOR/L/PARL/2/9a`；已读层级 `archive_catalogue_only`；纸质原始手稿未亲读。
- **BS116 · Elsevier / Asian Journal of Social Science：** [2026 study Colonial justice on trial: Maharaja Nandakumar, Warren Hastings and 1775 execution](https://www.sciencedirect.com/science/article/pii/S1568484926000298)；档案号 `无`；已读层级 `peer_reviewed_abstract_read`；纸质原始手稿未亲读。

## 八、下一轮原档优先查验

1. 1775 Supreme Court原案卷与庭审陈述
2. 1773法令有关最高法院管辖与当地居民适用条款
3. 总督委员会内关于Nandakumar指控的 contemporaneous correspondence

**制图审核声明：**任何已确认的现代坐标仅可作为历史事件的现代参考点，不可作为当年实控边界。条约、征税、战利品或人物获利不自动形成主权多边形。
