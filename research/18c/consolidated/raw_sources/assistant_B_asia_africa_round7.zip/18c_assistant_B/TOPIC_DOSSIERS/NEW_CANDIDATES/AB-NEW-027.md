# AB-NEW-027｜1763与1783英法和约对印度商馆、Gorée和塞内加尔不同归属

**范围与状态：1700—1799研究候审，未发表；保留原37母题ID不变。**

**对应母题：** `E18-E07`。**单立理由：**1763与1783分别恢复法方港岛/商馆及英方部分商贸地，必须记录条约名和年份；不将贸易站误作广域土地。

## 一、背景与权力性质

18世纪各欧洲国王的和约条款与海外实控相脱节。在西非，英法1763、1783两次改订戈雷和塞内加尔河据点归属；在印度，1763条约又要求归还法国1749年已拥有的商馆。区域法律地位、堡垒本体与商馆许可需做独立状态。

## 二、具体过程与收益链

1763《巴黎和约》第10条归还Gorée法国并涉及英方获得的塞内加尔据点；第11条规定法国恢复印度沿岸Coromandel、Orissa、Malabar、Bengal各贸易商馆。1783《凡尔赛和约》第9条让法国恢复Saint-Louis、Podor、Galam及Gorée；第10条确认英方甘比亚Fort James权利但其1779已遭破坏。以上仅为已读取的法律转录文本主张，具体驻军接防须另查军事日记。

## 三、当地政治主体与证据冲突

马拉塔、孟加拉、科罗曼德海岸印度政权与塞内加尔当地统治者既非“英法国民”，亦非条约自动消灭的自治政治。

## 四、地图可执行限制

同一座堡垒可有“条约确认主体”“实际驻军主体”“被毁而无驻军”三套时间字段，不能采用单一按年全域国旗。

## 五、已有逐项事件（需主编审核）

## 六、经济数据引用（不重复加总）

当前尚无可核实的原币值或实收金额，本专题经济证据为空值，后续查账。

## 七、实际使用的来源与阅读深度

- **BS128 · University of Perpignan digital legal history：** [French 1783 Treaty of Versailles full text articles 9-11](https://mjp.univ-perp.fr/traites/1783versailles.htm)；档案号 `无`；已读层级 `digitised_primary_treaty_transcription_read`；纸质原始手稿未亲读。
- **BS129 · University of Ottawa：** [1763 Treaty of Paris archival legal transcription articles 10–11](https://www.uottawa.ca/about-us/official-languages-bilingualism-institute/clmc/linguistic-history/historic-documents/treaty-paris-1763)；档案号 `无`；已读层级 `primary_treaty_transcription_read`；纸质原始手稿未亲读。

## 八、下一轮原档优先查验

1. 1763 Pondicherry等每一商馆实际交还的独立时间
2. 1783圣路易、Gorée、詹姆斯堡条款实际执行
3. 法国和英国外交文本与当地政权契据核对

**制图审核声明：**任何已确认的现代坐标仅可作为历史事件的现代参考点，不可作为当年实控边界。条约、征税、战利品或人物获利不自动形成主权多边形。
