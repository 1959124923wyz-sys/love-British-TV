# AB-NEW-072｜1788—1799年《奴隶船规制法》与废奴争议期间持续贸易

> **research_only / 第七轮**；法定许可、组织实施、已知问题与个别越权必须分证据等级。

## 历史过程与机制：议会对奴役运输持续管理

1788年枢密院及议会已经调查奴役贸易，英国随后制定载人密度、关税登记、医生死亡记录、保险范围、超载罚金和死亡率分级奖励。法令并设商人损失审查委员会。1789、1792年法令继续允许但规制奴役运输；1807才正式禁止英国奴役贸易。

## 归责与当地行动

这是国家层级授权的最完整证据链：立法许可、监管、死亡报告、财政奖励、对损失作赔偿调查；各项法定预算/罚金/奖金不同于实际支付。

## 本轮新增时间线与证据

### AB-R7-POL-025｜1788｜1788年英国立法限制奴隶船载人密度但仍准许运输

28 Geo.III c.54规定船舶吨位与最大强制运载人数及超载罚金，属于官方对贸易过程的规制而非废除奴役运输。

**涉事主体**：英国议会；贩奴船船长、港口海关和被奴役者。**地点/行政层级**：Westminster / British slave shipping ports。**来源**：[BS244](https://www.pdavis.nl/Legis_21.htm)；[BS243](https://www.parliament.uk/about/living-heritage/transformingsociety/tradeindustry/slavetrade/overview/the-first-parliamentary-debates/)。

**GIS限制**：不引入历史实控面，法规的通过地点与受影响的地区互不等同。

### AB-R7-POL-026｜1788｜1788年枢密院调查奴役贸易商业和人口后果

1788年2月Pitt委托枢密院调查奴隶贸易的经济与影响，同年仍采取有限规制而非立即取消贸易。

**涉事主体**：英国首相Pitt、枢密院委员会、英国议会和非洲被奴役者。**地点/行政层级**：London。**来源**：[BS243](https://www.parliament.uk/about/living-heritage/transformingsociety/tradeindustry/slavetrade/overview/the-first-parliamentary-debates/)。

**GIS限制**：不引入历史实控面，法规的通过地点与受影响的地区互不等同。

### AB-R7-POL-027｜1789｜1789年英国续修奴隶船规制法

29 Geo.III c.66继续按吨位、成年人/儿童分类限制奴役人口运输；保留合法贩奴业务框架。

**涉事主体**：英国议会、港口海关、贩奴船主和受害者。**地点/行政层级**：Westminster, London。**来源**：[BS245](https://www.pdavis.nl/Legis_20.htm)。

**GIS限制**：不引入历史实控面，法规的通过地点与受影响的地区互不等同。

### AB-R7-POL-028｜1791｜1791年国会继续审查贩奴贸易却未通过全面废止

议会继续听取相关证据并辩论，但实际全面废除发生于1807年，需与1791年的法律状态区分。

**涉事主体**：英国议会；废奴倡议者、奴役贸易商人。**地点/行政层级**：Westminster, London。**来源**：[BS247](https://www.parliament.uk/about/living-heritage/transformingsociety/tradeindustry/slavetrade/key-dates/)；[BS248](https://researchbriefings.files.parliament.uk/documents/LLN-2019-0104/LLN-2019-0104.pdf)。

**GIS限制**：不引入历史实控面，法规的通过地点与受影响的地区互不等同。

### AB-R7-POL-029｜1792｜1792年英国再次续行奴隶船运输规制法

32 Geo.III c.52续行1788年以来船舶吨位配额和罚金体系；奴役运输仍依法进行。

**涉事主体**：英国议会、贩奴船主、非洲被奴役者。**地点/行政层级**：Westminster, London。**来源**：[BS246](https://www.pdavis.nl/Legis_64.htm)。

**GIS限制**：不引入历史实控面，法规的通过地点与受影响的地区互不等同。

### AB-R7-ACT-01｜1788｜1788年《奴隶船规制法》要求船医登记死亡并呈报海关

1788 Act s.IV mandates named surgeon journals recording deaths, causes, and numbers and certified returns on arrival. This enabled knowledge production and enforcement, not abolition.

**涉事主体**：英国议会、船医、海关、被奴役者。**地点/行政层级**：British slave-voyage ports。**来源**：[BS244](https://www.pdavis.nl/Legis_21.htm)。

**GIS限制**：不引入历史实控面，法规的通过地点与受影响的地区互不等同。

### AB-R7-ACT-02｜1788｜1788年英国为低奴役者死亡率航次发船长与船医奖金

28 Geo III c54 s.XIV authorizes captain £100/surgeon £50 if mortality ≤2%; alternatively £50/£25 if ≤3%. Legal bonus levels are not confirmed actual disbursements.

**涉事主体**：英国财政部/海关、英国贩奴船长与船医。**地点/行政层级**：Westminster / British Caribbean ports。**来源**：[BS244](https://www.pdavis.nl/Legis_21.htm)。

**GIS限制**：不引入历史实控面，法规的通过地点与受影响的地区互不等同。

### AB-R7-ACT-03｜1788｜1788年法令要求评估奴役贸易商因新规遭受的财产损失

28 Geo III c54 s.XV establishes commissioners for merchant loss claims occasioned by limits; compensation amounts are undecided, not proven paid.

**涉事主体**：英国议会、商人Brook Watson等委员、船主。**地点/行政层级**：Westminster / British shipping ports。**来源**：[BS244](https://www.pdavis.nl/Legis_21.htm)。

**GIS限制**：不引入历史实控面，法规的通过地点与受影响的地区互不等同。

### AB-R7-ACT-04｜1788｜1788年英国议会授权最多£2,000资助奴役贸易规制执行委员会

28 Geo III c54 s.XVI authorizes spending up to £2,000 on clerks/administrative costs; ceiling not actual spent or slave-merchant payout.

**涉事主体**：英国国库、奴役贸易规制委员会。**地点/行政层级**：London, Treasury。**来源**：[BS244](https://www.pdavis.nl/Legis_21.htm)。

**GIS限制**：不引入历史实控面，法规的通过地点与受影响的地区互不等同。

### AB-R7-ACT-05｜1788｜1788年法令保留奴役“货物”特定海险保险赔偿范围

28 Geo III c54 s.XII limits permitted insurance to sea peril, piracy, mutiny, wartime capture, crew misconduct and fire. Shows market legally framed people as insured property; amount unknown.

**涉事主体**：英国议会、海上保险商人、被奴役非洲人。**地点/行政层级**：Westminster / London insurance market。**来源**：[BS244](https://www.pdavis.nl/Legis_21.htm)。

**GIS限制**：不引入历史实控面，法规的通过地点与受影响的地区互不等同。

## 经济/人口证据与原卷缺口

逐年核查船医航海死亡日志、海关罚款台账、法定奖金真实给付、申请补偿名单及起诉结果。未核实际补偿不能宣称已赔。

### 来源阅读深度

| ID | 网址或档案 | 本轮实际阅读级别 |
|---|---|---|
| BS243 | [The first parliamentary debates on slave trade, 1788 Dolben Act](https://www.parliament.uk/about/living-heritage/transformingsociety/tradeindustry/slavetrade/overview/the-first-parliamentary-debates/) | institutional_html_read；原史料纸卷未亲读 |
| BS244 | [1788 Slave Trade Regulation / Dolben Act](https://www.pdavis.nl/Legis_21.htm) | contemporary_act_transcription_html_read；原史料纸卷未亲读 |
| BS245 | [1789 Slave Trade Regulation extension](https://www.pdavis.nl/Legis_20.htm) | contemporary_act_transcription_html_read；原史料纸卷未亲读 |
| BS246 | [1792 Slave Trade Regulation continuation](https://www.pdavis.nl/Legis_64.htm) | contemporary_act_transcription_html_read；原史料纸卷未亲读 |
| BS247 | [Slave trade key dates 1788–1807](https://www.parliament.uk/about/living-heritage/transformingsociety/tradeindustry/slavetrade/key-dates/) | institutional_chronology_html_read；原史料纸卷未亲读 |
| BS248 | [Britain and the Transatlantic Slave Trade briefing 2019](https://researchbriefings.files.parliament.uk/documents/LLN-2019-0104/LLN-2019-0104.pdf) | pdf_search_excerpt_only_not_page_verified；原史料纸卷未亲读 |

**候审地图**：全部无可靠历史边界，本篇事件仅作为时间轴、财政/政策关联和将来核实堡垒或城市参考点的研究素材。
