# AB-NEW-034 | 财政征收结构逐阶段更替

**研究级，未发表。** 日期：2026-11-08。

## 史料核查结果

西孟加拉档案由埃克塞特大学转录并编写引言：1781-02-09地方Provincial Councils of Revenue结束，Calcutta Revenue Committee集中管理、依赖Diwan和县级征收官；1786再由Board of Revenue接替。须从原条例确认各district Collector准确职权，不能把1772年全国统一直接管理写成唯一制度。

## 原始来源与阅读级别

- [BS136](https://famineanddearth.exeter.ac.uk/displayhtml.html?id=fp_00374_en_committeeofrevenue25thseptember-30thoctober1783)。来源性质见`../../SOURCE_REGISTRY.json`；未读取博物馆/馆藏手稿原件。

## 地图交接

目前只有已证明的具名地点、地方税权和条约年份；精确行政边界和现场坐标未审核，一律不得生成实控Polygon或面积。史料可以研究虚线范围，但必须先具名点及有据示意方法。
