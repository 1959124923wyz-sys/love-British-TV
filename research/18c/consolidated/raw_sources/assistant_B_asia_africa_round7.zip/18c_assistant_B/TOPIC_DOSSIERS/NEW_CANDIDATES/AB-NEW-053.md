# AB-NEW-053｜1795—1797年科钦荷属堡垒移交、VOC资产清点与科钦王国权利争议

- 编辑关系：`E18-E05`；候选独立议题，不改变原母题ID。
- 研究状态：`research_only`；原纸档、地理边界尚未审定。

## 可核时间序列
- **1791｜Cochin王与英国驻王廷官员签协议保留旧荷方合约关系**：Brill学者指出1791英公司保证不侵害Cochin王与VOC先有条约；1795英方主张继承荷方特权不得变成默认王国自愿割让。 （来源：BS189；事件ID：`AB-F5-IN-009`）
- **1795-10-19｜英国Petrie与荷方Van Spall签署Cochin城堡投降条款**：Francis Day 1863年出版的历史条约副本含1795年10月19日投降条款及签名；签署日与实际移交不混作同一事实。 （来源：BS191；事件ID：`AB-F5-IN-010`）
- **1795-10｜公司接管Cochin荷商军械仓库、港务房屋与税权文书**：Brill学者指出英方征用VOC仓库、炮械和行政建筑、审查荷方港口税权文书与荷方雇员，出现双套行政一段时间；Raja的独立统治须单独检验。 （来源：BS189, BS190；事件ID：`AB-F5-IN-011`）

## 权力与政治主体
英军先取得荷商堡垒，逐项清查仓库、税权与地方政体，不能扩大为整个Cochin独立王国被吞并
地图请保持Fante、当地王侯／法荷殖民地、印度各邦和其他非英国政治主体为独立对象；公司贸易许可证、官员礼金、税权、驻军、实际城堡占据及英国国王主权不得合并。

## 金额／数量／会计口径
- 本候选暂无经核可量化财务数字；不补造收益。

## 来源与阅读深度
- `BS189` Life after the VOC: Cochin after the October 1795 takeover：https://brill.com/previewpdf/book/9789004190252/Bej.9789004168169.i-317_007.xml；阅读级别：`publisher_book_chapter_pdf_extracted_text_read_screenshot_not_supported`；原始手稿本人亲阅：否。
- `BS190` IOR/F/4/21/801: Questions concerning civil administration of Cochin and dependants, Nov 1795-Oct 1797：https://searcharchives.bl.uk/catalog/041-000736178；阅读级别：`archive_catalogue_only`；原始手稿本人亲阅：否。
- `BS191` The Land of the Permauls, or Cochin: 19 October 1795 surrender terms reproduced：https://upload.wikimedia.org/wikipedia/commons/3/3f/The_Land_of_the_Permauls_or_Cochin%2C_Its_Past_and_Its_Present_%28IA_landofpermaulsor00fran%29.pdf；阅读级别：`1863_compiled_historical_treaty_transcript_indexed_pdf_text`；原始手稿本人亲阅：否。

## GIS与后续查核
- 无实测控制 Polygon；具名地点可待地名文献复核后画现代参考点，严禁凭堡垒地点涂整国或整省。
- 未核项：原卷连续性、当地政治主体史料、精确军占起止日、金额实际清算、历史边界。
