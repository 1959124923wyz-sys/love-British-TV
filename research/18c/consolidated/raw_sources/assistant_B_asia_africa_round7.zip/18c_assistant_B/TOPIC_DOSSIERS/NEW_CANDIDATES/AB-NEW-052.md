# AB-NEW-052｜1726—1753年印度三大公司港市法院、司法特许与当地居民诉讼范围

- 编辑关系：`E18-B01`；候选独立议题，不改变原母题ID。
- 研究状态：`research_only`；原纸档、地理边界尚未审定。

## 可核时间序列
- **1726-09-24｜王室1726特许在孟买、马德拉斯和加尔各答设市长法院**：1726年9月24日Letters Patent设置市长法院并将特定诉讼/审理权授公司城镇机构；不能将之泛化为整个莫卧儿印度的英国司法主权。 （来源：BS187, BS188；事件ID：`AB-F5-IN-004`）
- **1753-01-08｜1753新特许重新设立三大公司港市法院**：1753年1月8日新宪章重建Mayor’s Courts，另设受理5帕戈达及以下诉讼的简易法院；具体当地原始法庭簿册仍未读。 （来源：BS187, BS188；事件ID：`AB-F5-IN-005`）

## 权力与政治主体
公司港市内部法院司法权独立于莫卧儿/当地社会主权；一项有文书证的商业→司法权转型
地图请保持Fante、当地王侯／法荷殖民地、印度各邦和其他非英国政治主体为独立对象；公司贸易许可证、官员礼金、税权、驻军、实际城堡占据及英国国王主权不得合并。

## 金额／数量／会计口径
- 本候选暂无经核可量化财务数字；不补造收益。

## 来源与阅读深度
- `BS187` State of Maharashtra v Kusum C B Upadhye: historical 1726/1753 Mayors Courts charters：https://indiankanoon.org/doc/252279/；阅读级别：`later_judicial_primary_judgment_recounting_18c_charters`；原始手稿本人亲阅：否。
- `BS188` Calcutta Mayor’s Court records and copies of 1753 charter; collection identifier 71859-6CSB-01：https://britishonlinearchives.com/collections/20/volumes/89/records-of-the-calcutta-mayors-court-c1765-1766；阅读级别：`archive_catalogue_only`；原始手稿本人亲阅：否。

## GIS与后续查核
- 无实测控制 Polygon；具名地点可待地名文献复核后画现代参考点，严禁凭堡垒地点涂整国或整省。
- 未核项：原卷连续性、当地政治主体史料、精确军占起止日、金额实际清算、历史边界。
