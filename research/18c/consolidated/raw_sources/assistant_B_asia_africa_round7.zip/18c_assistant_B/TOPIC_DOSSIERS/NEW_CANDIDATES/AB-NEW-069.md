# AB-NEW-069｜1798—1799南印度Kattabomman/Palayakkarar税收与反殖民战争

> research_only｜第六轮扩大地区调查，主编审批前不得视为已发布地图。

## 历史机制与受害、抵抗者

帕拉亚卡拉尔拥有地方武装与财政职责；公司征税与解除武装成为冲突焦点。独立性不等于现代民族主义组织；各地方首领对公司的立场并不一致。泰米尔纳德邦考古机构证实古堡残址，**35英亩是现代考古遗址规模，不是1799英国实控面积**。

## 候审事件

### AB-R6-069-01｜1798｜Kattabomman与公司税务官发生征收权争执

- 公司试图扩大对Palayakkarar的地税控制，本地统治者反对；具体接见日期及冲突细节需一手Revenue Consultations复核。
- 地点：Panchalankurichi / Tirunelveli；主体：Kattabomman; EIC Tirunelveli collector
- 史料：[BS234](https://www.cambridge.org/core/journals/journal-of-asian-studies/article/abs/bandits-and-kings-moral-authority-and-resistance-in-early-colonial-india/F5C6466E58EA233E8678A2917D81159D)
- 地图：地点名可做文字，历史边界不可直接绘制；公司关税、地方割据与王室主权不能混同。

### AB-R6-069-02｜1799｜英公司军围攻Panchalankurichi堡

- 1799年英公司军攻打Kattabomman的堡垒，当地地方首领反抗并有部分首领支持公司；堡垒被攻战经过须核军报。
- 地点：Panchalankurichi；主体：EIC Major Bannerman; Kattabomman; local allied chiefs
- 史料：[BS234](https://www.cambridge.org/core/journals/journal-of-asian-studies/article/abs/bandits-and-kings-moral-authority-and-resistance-in-early-colonial-india/F5C6466E58EA233E8678A2917D81159D), [BS235](https://www.tnarch.gov.in/panchalankurichi)
- 地图：地点名可做文字，历史边界不可直接绘制；公司关税、地方割据与王室主权不能混同。

### AB-R6-069-03｜1799｜Kattabomman被地方统治者拘捕并移交公司

- 公司及结盟地方统治者抓捕Kattabomman，体现当地政治身份复杂；不得将所有Tamil政治主体描为一个反英集团。
- 地点：Pudukkottai / Kayathar；主体：Kattabomman; Pudukkottai authorities; EIC officers
- 史料：[BS234](https://www.cambridge.org/core/journals/journal-of-asian-studies/article/abs/bandits-and-kings-moral-authority-and-resistance-in-early-colonial-india/F5C6466E58EA233E8678A2917D81159D), [BS239](https://www.tnhc.org.in/docs/proceedings/Chidambaram-2012.pdf)
- 地图：地点名可做文字，历史边界不可直接绘制；公司关税、地方割据与王室主权不能混同。

### AB-R6-069-04｜1799｜公司处决Kattabomman

- 1799年Kattabomman因反抗公司政权遭处刑；文献对10月16或17日的确切日期有分歧，目前保留年份。
- 地点：Kayathar / Tirunelveli；主体：Kattabomman; EIC officers
- 史料：[BS234](https://www.cambridge.org/core/journals/journal-of-asian-studies/article/abs/bandits-and-kings-moral-authority-and-resistance-in-early-colonial-india/F5C6466E58EA233E8678A2917D81159D)
- 地图：地点名可做文字，历史边界不可直接绘制；公司关税、地方割据与王室主权不能混同。

## 文献阅读级别

- BS234 Bandits and Kings: Moral Authority and Resistance in Early Colonial India — https://www.cambridge.org/core/journals/journal-of-asian-studies/article/abs/bandits-and-kings-moral-authority-and-resistance-in-early-colonial-india/F5C6466E58EA233E8678A2917D81159D；阅读：journal_abstract_read；18世纪原始手稿：未亲自查验。
- BS235 Panchalankurichi archaeology fort palace — https://www.tnarch.gov.in/panchalankurichi；阅读：official_archaeology_site_read；18世纪原始手稿：未亲自查验。
- BS239 Proceedings: Poligar Rebellion, primary archive series list — https://www.tnhc.org.in/docs/proceedings/Chidambaram-2012.pdf；阅读：conference_pdf_search_excerpt_not_page_visual_verified；18世纪原始手稿：未亲自查验。

## 具体缺口

需要1799 Revenue Consultations、军事报告核攻城与处决日期；1801年73位poligars被运槟城属19世纪后续，应列跨世纪，不进入1799年事件/金额。
