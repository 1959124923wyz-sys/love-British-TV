# AB-NEW-032 | 1760孟加拉三个税区的错时转移

**研究级，未发表。** 日期：2026-11-08。

## 史料核查结果

Henry Vansittart 1766年出版自辩书转述：EIC Select Committee为取得年约50 lakh卢比预期财政收入，支持Mir Qasim取代Mir Jafar并交换Burdwan、Midnapore、Chittagong税权。1940 Calcutta University学术书另记1760-11-17 Burdwan年税划拨、1760-12 Chittagong转移，并称Midnapore至1765仍有部分地区未被实际接管。

年50 lakh为谈判预计财政规模，不是已经收到的收入。zaminadri/assignment、原有地主权益与名义主权并存。

## 原始来源与阅读级别

- [BS134](https://famineanddearth.exeter.ac.uk/displayhtml.html?id=fp_00175_en_narrativeoftransactionsinbengal_vol01)。来源性质见`../../SOURCE_REGISTRY.json`；未读取博物馆/馆藏手稿原件。
- [BS140](https://gsl.lbsnaa.gov.in/opac-tmpl/bootstrap/Books/106122.pdf)。来源性质见`../../SOURCE_REGISTRY.json`；未读取博物馆/馆藏手稿原件。

## 地图交接

目前只有已证明的具名地点、地方税权和条约年份；精确行政边界和现场坐标未审核，一律不得生成实控Polygon或面积。史料可以研究虚线范围，但必须先具名点及有据示意方法。
