# AB-NEW-005｜1765年阿拉哈巴德和约中阿瓦德50 lakh卢比赔款

- **原母题关联**：`E18-B06`
- **独立新专题必要性**：原条约Mss Eur G49，和Diwani征税分开

## 可核参考

- [BS14 Treaty of Allahabad with Nawab of Oudh 16 Aug 1765](https://searcharchives.bl.uk/?f%5Blevel_ssi%5D%5B%5D=%5B32%5D+Fonds&f%5Brelated_names_ssim%5D%5B%5D=Shuja-ud-daula%2C+Nawab+of+Oudh%2C+1754-1775&f%5Burl_non_blank_si%5D%5B%5D=No&search_field=all_fields&sort=date-desc)；阅读等级：archive_search_result_read。

## 待核原件与地图

进入新专题须主编决定新正式编号，补足原始公司日志、财政原卷、地方视角；现阶段既不自动上图，也不改变项目原专题ID。
