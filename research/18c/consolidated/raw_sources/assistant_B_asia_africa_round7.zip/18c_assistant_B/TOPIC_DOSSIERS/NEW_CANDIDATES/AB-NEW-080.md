# AB-NEW-080｜1792—1800年塞拉利昂黑人定居者土地自由保有权与司法自治争议

> **research_only / 第七轮**；法定许可、组织实施、已知问题与个别越权必须分证据等级。

## 历史过程与机制：塞拉利昂自由居民被殖民公司限制土地权

新斯科舍黑人效忠派及其他居民迁抵塞拉利昂，曾选出tithingmen、hundreders参与自治；伦敦投资者掌握的Sierra Leone Company不让他们拥有完全土地自由保有权，1799年紧张加剧。UNB收藏TNA CO270 1792–1801记录，明载1800年爆发反抗。

## 归责与当地行动

公司号称自由定居和法权庇护，土地保障和居民政治权利却与投资者利益冲突。1799年的对抗与1800年的起义应分开。当地Temne等政治实体不能被当作无主地。

## 本轮新增时间线与证据

### AB-R7-POL-041｜1799｜1799年塞拉利昂黑人定居者要求土地权利而投资公司拒绝自由保有权

UNB TNA CO270藏品说明，1799年投资者拒绝授予永久土地所有权引发紧张；1800暴动单列下世纪。

**涉事主体**：Sierra Leone Company London investors、Nova Scotia Black Settlers。**地点/行政层级**：Freetown, Sierra Leone。**来源**：[BS165](https://loyalist.lib.unb.ca/record/sessional-papers-sierra-leone-co-270-1792-1801)。

**GIS限制**：不引入历史实控面，法规的通过地点与受影响的地区互不等同。

## 经济/人口证据与原卷缺口

查TNA CO270/4–5自由保有权原文、Temne土地协议、settler选举和1800年法律请愿原稿；勿把19世纪土地规则提前。

### 来源阅读深度

| ID | 网址或档案 | 本轮实际阅读级别 |
|---|---|---|
| BS165 | [TNA CO 270/2-6 Freetown council minutes 1792–1801](https://loyalist.lib.unb.ca/record/sessional-papers-sierra-leone-co-270-1792-1801) | archival_inventory_with_detailed_description；原史料纸卷未亲读 |

**候审地图**：全部无可靠历史边界，本篇事件仅作为时间轴、财政/政策关联和将来核实堡垒或城市参考点的研究素材。
