# AB-NEW-058｜1789—1796安达曼流放殖民地与原住民领土压迫

> 研究阶段 research_only。此次新增候选，未经主编出版审核；不构造未经证实的控制面。

**原项目关联母题**：`E18-E11`

## 新增原因及主要发现

Cambridge同行评审全文记载道路被单方用作权利边界，证据来源为Blair殖民材料；必须区别长期原住民岛屿主权与公司短暂占据的局部清林。

**受影响群体/利益**：安达曼原住民土地、被流放囚犯和英印海军后勤

## 有据史事 / 地图语义

### AB-R6-058-01｜1789｜公司在南安达曼Chatham岛开设流放殖民据点

- 地方与主体：Chatham Island / Phoenix Bay, South Andaman；Archibald Blair; EIC convicts; Andamanese peoples
- 史实：1789年公司建立港口与监禁殖民据点并清理Chatham岛及Phoenix Bay相邻林地。
- 控制语义：`convict_settlement_and_local_land_displacement`；不据此生成英国领土面积。
- 日期精度：`year`；日期补充：无

### AB-R6-058-02｜1791｜安达曼殖民当局筑路形成武装压迫的边界

- 地方与主体：Phoenix Bay / South Andaman；EIC garrison; indigenous Andaman peoples
- 史实：研究记道路及火枪、舰炮约束形成单方强加的定居区界线，路址与确切年份需要历史工程图，不可绘历史边界。
- 控制语义：`militarised_frontier_not_precise_line`；不据此生成英国领土面积。
- 日期精度：`year`；日期补充：{'confidence': 'phase_circa_1789_1792', 'year_window': '1789–1792'}

### AB-R6-058-03｜1792–1793｜东印度公司将安达曼殖民据点迁往Port Cornwallis

- 地方与主体：Port Cornwallis, North Andaman；Archibald Blair; EIC
- 史实：研究描述1792–1793间移至Port Cornwallis，具体月份与名称沿革须核对原日记。
- 控制语义：`outpost_relocation`；不据此生成英国领土面积。
- 日期精度：`range_only`；日期补充：{'year_window': '1792–1793', 'confidence': 'date_dispute_1792_1793'}

### AB-R6-058-04｜1796｜东印度公司放弃早期安达曼殖民驻点

- 地方与主体：Port Cornwallis / Andaman Islands；East India Company; settlers and prisoners
- 史实：由于健康条件和港口战略效用变化，殖民据点1796年撤弃；不能从1789据点延长整个19世纪的驻军控制。
- 控制语义：`settlement_withdrawal`；不据此生成英国领土面积。
- 日期精度：`year`；日期补充：无

## 资料来源与实际阅读层级

- [BS211](https://www.cambridge.org/core/journals/comparative-studies-in-society-and-history/article/developing-terra-nullius-colonialism-nationalism-and-indigeneity-in-the-andaman-islands/8F0B5F996A88F1DB8E8B5D7B54AD8E8F) Developing Terra Nullius: Colonialism, Nationalism, Indigeneity in Andaman Islands；机构：Cambridge University Press / Comparative Studies in Society and History；阅读级别：`journal_full_html_read`；原始手稿亲阅：否；档案编号：无。

## 尚待攻克

Chatham岛与Phoenix Bay局部地籍、1789–1796囚犯名单、具体道路测绘图和死亡资料。

## 地图纪律

所有地点均为具名文本参考，尚未匹配正式权威参考坐标；该专题不可自动生成实控Polygon、军事行动缓冲圆面积、历史海运精确路线或现代行政区。
