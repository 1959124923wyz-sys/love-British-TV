# AB-NEW-043｜1795—1796康提国王对英盟约、荷属锡兰海岸易手与公司官员治理

状态：`research_only` / `propose_to_editor`。原有E18-B/E系列ID保持不动。

**推荐与原项目交叉索引：** `E18-E05`。

## 问题与发现
1795与康提的两次谈判和1796荷城降约，均非康提被吞并。

## 逐件证据事件
### AB-NEW-043-001｜1795｜康提国王与英国订友好同盟条约
- 行动者：King of Kandy; EIC envoys；地点：Kandy, Sri Lanka；日期精度：day。
- 事实与权利：1909官方条约汇编目录记1795-10-12友好同盟；此为康提外交主体行权，未证明英国吞并康提。
- 法权分类：`independent_kandy_treaty_not_cession`；可验证程度：`confirmed_in_cited_secondary_or_printed_edition`。
- 证据：[BS164](https://ignca.gov.in/Asi_data/14009.pdf)

### AB-NEW-043-002｜1796｜康提国王与英国订进一步和平约文
- 行动者：King of Kandy; Company representatives；地点：Kandy, Sri Lanka；日期精度：day。
- 事实与权利：1909官方汇编目录载1796-02-12对康提和平约文，与1796-02-15科伦坡荷军投降区分。
- 法权分类：`kandyan_diplomatic_agreement_independent`；可验证程度：`confirmed_in_cited_secondary_or_printed_edition`。
- 证据：[BS164](https://ignca.gov.in/Asi_data/14009.pdf)

## 经济或人口分项（若有）

现有足额/实收货币账无法确认，保持null；不得推断成本、利润或净汇出。

## 地图与下一步
所有本专题地理对象先作具名点或未定位参考；不得将地方胡椒贸易许可、宗主关系、陆军战场或现代省界填成公司实占多边形；有确切让地条文也必须先核逐村或历史岛岸边界。

**核查缺口**：需核条约的当地语言版本、年度实际税收和付款凭据、当事人答辩、原档页影及能够校准的历史地籍。
**档案声明**：18世纪物理原件未亲阅；1909编辑出版条约文字与馆藏目录保留不同阅读等级。
