# AB-NEW-041｜1708—1765马拉巴尔沿岸Tellicherry堡、胡椒专卖与地方政体

状态：`research_only` / `propose_to_editor`。原有E18-B/E系列ID保持不动。

**推荐与原项目交叉索引：** `E18-B01`。

## 问题与发现
多个地方Nayar国君的胡椒贸易特许和特定岛屿/堡垒让与须区别。

## 逐件证据事件
### AB-NEW-041-001｜1708｜Tellicherry要塞筑防条款在公司与地方政权间成立
- 行动者：EIC; local Malabar political authorities；地点：Thalassery/Tellicherry；日期精度：day。
- 事实与权利：1909官方汇编列1708-08-20筑防协定，属于一具名堡的权力许可与潜在军事驻点，不是全Malabar主权。
- 法权分类：`fortification_permission_specific_site`；可验证程度：`confirmed_in_cited_secondary_or_printed_edition`。
- 证据：[BS164](https://ignca.gov.in/Asi_data/14009.pdf)

### AB-NEW-041-002｜1719｜Kurangot Nayar向英商特许胡椒贸易专卖
- 行动者：Kurangot Nayar; EIC；地点：Kurangot, Malabar；日期精度：year。
- 事实与权利：1719胡椒专卖Grant记录为公司商业权，贸易垄断不赋领地司法管辖。
- 法权分类：`pepper_trade_monopoly_license_not_sovereignty`；可验证程度：`confirmed_in_cited_secondary_or_printed_edition`。
- 证据：[BS164](https://ignca.gov.in/Asi_data/14009.pdf)

### AB-NEW-041-003｜1722｜Kolattiri地区胡椒专卖让给英商
- 行动者：Kolattiri ruler; EIC；地点：Kolattiri, Malabar；日期精度：year。
- 事实与权利：1722商业Grant，地方统治者仍保政治身份。
- 法权分类：`regional_commodity_trade_monopoly`；可验证程度：`confirmed_in_cited_secondary_or_printed_edition`。
- 证据：[BS164](https://ignca.gov.in/Asi_data/14009.pdf)

### AB-NEW-041-004｜1734｜Dharmapattanam岛让与东印度公司
- 行动者：Malabar local rulers; EIC；地点：Dharmapattanam island；日期精度：year。
- 事实与权利：1734有特定岛屿Cession文本，应核原契和小岛历史海岸线，不得拿现代Taluk多边形表示。
- 法权分类：`island_grant_requires_historic_boundary`；可验证程度：`confirmed_in_cited_secondary_or_printed_edition`。
- 证据：[BS164](https://ignca.gov.in/Asi_data/14009.pdf)

### AB-NEW-041-005｜1765｜Chirakkal Regent与英商签Randatara省让与安排
- 行动者：Regent of Chirakkal; EIC；地点：Randatara, Malabar；日期精度：day。
- 事实与权利：1765-03-23地方协议，候审地图仅用历史地名空几何；政治权利与征税交付仍待核。
- 法权分类：`district_cession_contract_not_verified_possession`；可验证程度：`confirmed_in_cited_secondary_or_printed_edition`。
- 证据：[BS164](https://ignca.gov.in/Asi_data/14009.pdf)

## 经济或人口分项（若有）

现有足额/实收货币账无法确认，保持null；不得推断成本、利润或净汇出。

## 地图与下一步
所有本专题地理对象先作具名点或未定位参考；不得将地方胡椒贸易许可、宗主关系、陆军战场或现代省界填成公司实占多边形；有确切让地条文也必须先核逐村或历史岛岸边界。

**核查缺口**：需核条约的当地语言版本、年度实际税收和付款凭据、当事人答辩、原档页影及能够校准的历史地籍。
**档案声明**：18世纪物理原件未亲阅；1909编辑出版条约文字与馆藏目录保留不同阅读等级。

## 第四轮第二批：独立证据链

原始财政科目与法权转换按条文分开，以下均处候审阶段：

- **AB-NEW-041-003**（1722）：Kolattiri地区胡椒专卖让给英商。1722商业Grant，地方统治者仍保政治身份。 证据：[1909年政府条约汇编](https://ignca.gov.in/Asi_data/14009.pdf)。
- **AB-NEW-041-004**（1734）：Dharmapattanam岛让与东印度公司。1734有特定岛屿Cession文本，应核原契和小岛历史海岸线，不得拿现代Taluk多边形表示。 证据：[1909年政府条约汇编](https://ignca.gov.in/Asi_data/14009.pdf)。
- **AB-NEW-041-005**（1765）：Chirakkal Regent与英商签Randatara省让与安排。1765-03-23地方协议，候审地图仅用历史地名空几何；政治权利与征税交付仍待核。 证据：[1909年政府条约汇编](https://ignca.gov.in/Asi_data/14009.pdf)。
- **AB-NEW-041-006**（1725）：Kadattanad地方酋长向公司给予胡椒贸易专卖。1909汇编目录列1725年胡椒商业特许，此为排他采购关系，未展示司法主权转移。 证据：[1909年政府条约汇编](https://ignca.gov.in/Asi_data/14009.pdf)。
- **AB-NEW-041-007**（1748）：Kotayam的胡椒专卖权让给公司。1909条约集记录1748年商业专卖；不得以现代Kottayam行政县全域代表公司控制。 证据：[1909年政府条约汇编](https://ignca.gov.in/Asi_data/14009.pdf)。
- **AB-NEW-041-008**（1760）：Kolattiri摄政者准公司征收指定关税。1760年11月22日条款授公司关税征收特权；税权地域与实收款额须依档案核，而非贸易港一整个区都为英国版图。 证据：[1909年政府条约汇编](https://ignca.gov.in/Asi_data/14009.pdf)。
- **AB-NEW-041-009**（1792）：Chirakkal王与公司签订马拉巴尔划定辖区的管理安排。1792-10-12对公司得到的地区订立settlement；表明割地之后仍有王室/地方行政安排，边界需当年签约清单及地籍。 证据：[1909年政府条约汇编](https://ignca.gov.in/Asi_data/14009.pdf)。
- **AB-NEW-041-010**（1793）：Calicut王与公司重新约定地区行政管理。1793-06-29行政条约及1792早期基础须分开记录；地方政体的司法和行政存续程度需参原文条款。 证据：[1909年政府条约汇编](https://ignca.gov.in/Asi_data/14009.pdf)。
- **AB-NEW-041-011**（1793）：Cannanore的Bibi同意就Laccadive群岛支付贡金。1793年4月11日有关拉克沙群岛贡赋与积欠的两项协议；公司获得贡金权不等于实际占据群岛各岛。 证据：[1909年政府条约汇编](https://ignca.gov.in/Asi_data/14009.pdf)。
