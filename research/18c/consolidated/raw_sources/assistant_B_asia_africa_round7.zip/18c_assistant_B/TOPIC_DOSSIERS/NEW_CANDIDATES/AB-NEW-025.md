# AB-NEW-025｜1702—1806年阿诺马布Fort Charles与Fort William及Fante政治自主

**范围与状态：1700—1799研究候审，未发表；保留原37母题ID不变。**

**对应母题：** `E18-E10`。**单立理由：**1731英国拆堡、1753—1757新堡建造、非洲Fante商人谈判及被奴役者转运可独立展开；1806超世纪只作结局上下文。

## 一、背景与权力性质

加纳文物管理局记阿诺马布存在1700年代早期英国Fort Charles、1731拆堡、1753议会拨款及1757建成Fort William的多次改变。英国不能把新堡完工之前的所有年份都连续描绘为同一永久英式堡垒。

## 二、具体过程与收益链

该机构还转述一名英籍船长1717年报告，称1702年1月至1708年8月自Anomabu输往巴巴多斯和牙买加超过或至少30,141名被奴役者。数字应标明为“1717年船长陈述，涵盖1702—1708”，不是现代清点的航次档、也不是本期可再加入跨洋运输数据库的净新增人数。1753的议会拨款需查批准数、年款和是否按时发放；1757建堡和堡内拘押空间可按实地官方建筑研究，但不能捏造关押人数。

## 三、当地政治主体与证据冲突

Ty M Reese强调Fante领导者与英国商馆有利益谈判和实际制衡；Fort William驻堡贸易不是英王对整个Fante族地直接主权。1794法军袭堡结果待确认，不提前断言占领易手。

## 四、地图可执行限制

阿诺马布Fort Charles与Fort William重建地理关系须通过遗产测绘定点；暂无独立核定位时不伪造精确坐标。

## 五、已有逐项事件（需主编审核）

## 六、经济数据引用（不重复加总）

当前尚无可核实的原币值或实收金额，本专题经济证据为空值，后续查账。

## 七、实际使用的来源与阅读深度

- **BS120 · Ghana Museums and Monuments Board：** [Official Fort William Anomabu 1753–57 and 1717 ship captain estimate](https://gmmb.gov.gh/fort-william-anomabu-1753/)；档案号 `无`；已读层级 `national_museum_history_search_extract_read`；纸质原始手稿未亲读。
- **BS121 · Taylor and Francis / Journal of Imperial and Commonwealth History：** [Ty M Reese Controlling the Company: Fante-British Relations 1750–1821](https://www.tandfonline.com/doi/abs/10.1080/03086534.2013.762162)；档案号 `无`；已读层级 `peer_reviewed_abstract_read`；纸质原始手稿未亲读。

## 八、下一轮原档优先查验

1. 1717船长原始汇报的笔录与船只、港口统计
2. 1731拆堡、法国修建、1753拨款、1757完工的原公司/议会记录
3. 1794袭击守军与当地民众遭受结果

**制图审核声明：**任何已确认的现代坐标仅可作为历史事件的现代参考点，不可作为当年实控边界。条约、征税、战利品或人物获利不自动形成主权多边形。
