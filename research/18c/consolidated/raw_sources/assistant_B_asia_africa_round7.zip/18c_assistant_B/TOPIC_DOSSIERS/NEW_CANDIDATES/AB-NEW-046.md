# AB-NEW-046｜1795开普征服逐次驻点、Khoikhoi士兵与布尔民兵抵抗

状态：`research_only` / `propose_to_editor`。原有E18-B/E系列ID保持不动。

**推荐与原项目交叉索引：** `E18-E06`。

## 问题与发现
不能把王室与荷属东印度公司的协议直接等同驻军征服过程，保留本地群体政治。

## 逐件证据事件
### AB-NEW-046-001｜1795｜英海军在开普False Bay和Simon’s Town部署
- 行动者：Vice-Admiral Elphinstone; VOC command; local militias；地点：Simon’s Town, Cape；日期精度：month。
- 事实与权利：1795年6月英舰抵False Bay、英军同VOC谈判而后进驻Simon’s Town；到8月仍未占领Cape Town城。
- 法权分类：`military_staging_not_entire_cape_colony`；可验证程度：`confirmed_in_cited_secondary_or_printed_edition`。
- 证据：[BS168](https://sahistory.org.za/place/battle-muizenburg-monument-muizenburg)；[BS170](https://sahistory.org.za/place/dutch-and-british-coastal-fortifications-cape-good-hope-1665-1829)

### AB-NEW-046-002｜1795｜英军8月7日炮击Muizenberg荷军防线
- 行动者：British navy and soldiers; VOC defenders; Corps Pandoeren and burghers；地点：Muizenberg near Rust en Vrede；日期精度：day。
- 事实与权利：VOC守军及由有色士兵构成的Korps Pandoeren、布尔民兵参与反抗；现今历史遗迹并非全1795战线。
- 法权分类：`battlefield_temporary_military_action`；可验证程度：`confirmed_in_cited_secondary_or_printed_edition`。
- 证据：[BS167](https://www.capetown.gov.za/media-and-news/city-secures-battle-of-muizenberg-site-as-a-provincial-heritage-site/)；[BS168](https://sahistory.org.za/place/battle-muizenburg-monument-muizenburg)；[BS173](https://resource.capetown.gov.za/documentcentre/Documents/City%20research%20reports%20and%20review/Stories_of_the_South_Peninsula_chapter_08_2014-06.pdf)

### AB-NEW-046-003｜1795｜开普VOC当局9月16日向英军投降
- 行动者：VOC Commissioner Sluysken; British command；地点：Cape Town；日期精度：day。
- 事实与权利：Britain在战事后取得开普殖民行政据点；保留Khoikhoi、San及内陆非欧政治体自主，城堡投降不是现代西开普省全域法权。
- 法权分类：`voc_to_british_occupation_not_modern_country_control`；可验证程度：`confirmed_in_cited_secondary_or_printed_edition`。
- 证据：[BS168](https://sahistory.org.za/place/battle-muizenburg-monument-muizenburg)

## 经济或人口分项（若有）

现有足额/实收货币账无法确认，保持null；不得推断成本、利润或净汇出。

## 地图与下一步
所有本专题地理对象先作具名点或未定位参考；不得将地方胡椒贸易许可、宗主关系、陆军战场或现代省界填成公司实占多边形；有确切让地条文也必须先核逐村或历史岛岸边界。

**核查缺口**：需核条约的当地语言版本、年度实际税收和付款凭据、当事人答辩、原档页影及能够校准的历史地籍。
**档案声明**：18世纪物理原件未亲阅；1909编辑出版条约文字与馆藏目录保留不同阅读等级。
