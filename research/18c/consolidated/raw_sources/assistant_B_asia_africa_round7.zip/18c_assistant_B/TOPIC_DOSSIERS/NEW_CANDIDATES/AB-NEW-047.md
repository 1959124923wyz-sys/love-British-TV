# AB-NEW-047｜1750—1755年阿诺马布堡扩建、被奴役劳动与Fante地方首领的土地谈判

- 编辑关系：`E18-E10`；候选独立议题，不改变原母题ID。
- 研究状态：`research_only`；原纸档、地理边界尚未审定。

## 可核时间序列
- **1750｜1750法案创立非洲商人公司并重组RAC堡垒资产**：23 Geo II c31推进非洲公司替代；明载在非洲堡垒服务大西洋人口奴役买卖，而非新的沿岸全域主权。 （来源：BS179；事件ID：`AB-F5-GH-001`）
- **1750-08-06｜公司在伦敦首次选举委员会主席、设置秘书薪酬**：伦敦委员会首次会议：Charles Pole抽签任主席，William Hollier秘书兼会计年薪100英镑、须交500英镑保证金。 （来源：BS179；事件ID：`AB-F5-GH-002`）
- **1751-02-05｜皇家非洲公司与新商人公司协商Cape Coast官员接替**：1751年2月5日伦敦会议约定委任Thomas Melvil等；分清董事组织变迁和驻堡实际移交。 （来源：BS179；事件ID：`AB-F5-GH-003`）
- **1751-04-17｜公司指示海岸角总管登记被奴役者与贩奴船航次**：给Melvil的命令要求记录堡中被奴役者名册、沿岸到港船舶所载人数、来去港；公司参与人口奴役贸易的管理体系。 （来源：BS179；事件ID：`AB-F5-GH-004`）
- **1752-04-10｜1752法案撤销RAC原公司财产并移交城堡与被奴役者**：25 Geo II c40据1762年出版汇编转引文本：规定旧公司自1752年4月10日失去所列财产／公司权利；各堡实际交割需另核。 （来源：BS179；事件ID：`AB-F5-GH-005`）
- **1752-06-10｜阿诺马布新堡设计拟从冈比亚调被奴役者清理工程**：委员会提出扩大旧堡的炮台并从冈比亚运被奴役者协助施工，属于规划命令，未凭此声称全部人数确实抵达。 （来源：BS179；事件ID：`AB-F5-GH-006`）
- **1753-01｜阿诺马布委员申报1752年建筑材料成本**：委员会报告此前由1752年10,000英镑议会拨款中挪用6,116英镑3先令9便士采购材料，呼吁补充预算；子额不可和总拨款再加。 （来源：BS179；事件ID：`AB-F5-GH-007`）
- **1753-01-25｜Fante阿诺马布地方首领反对英国商堡扩大占地**：Apperley 1753年3月9日回顾称1月25日拟扩堡时地方首领因旧堡英官苛待而反对，John Currantee调解且英方拟缩小棱堡面宽；土地边界无据。 （来源：BS179；事件ID：`AB-F5-GH-008`）
- **1753-03-09｜阿诺马布工程师承认动用被奴役者与当地居民装卸材料**：Apperley工程师致军械委员会日记记公司被奴役者和镇上居民帮忙装卸；未从词句推断所有当地居民都被强迫。 （来源：BS179；事件ID：`AB-F5-GH-009`）
- **1754-09-25｜非洲公司准付两名被带至英国非洲少年的寄养支出**：委员会批准报销Cockburn对两名非洲少年的£79 4s 1d费用；同期文件显示企图以教育建立与海岸首领外交关系；不推断二人遭奴役。 （来源：BS179；事件ID：`AB-F5-GH-010`）
- **1757-01-05｜伦敦非洲公司为西非征募士兵支付人头费**：批准按每征10名派往Cape Coast士兵支付每人£1 11s 6d佣金；合同价格不是军事净收益。 （来源：BS179；事件ID：`AB-F5-GH-011`）
- **1759-06-27｜英国非洲公司请海军介入Komenda英荷争夺登陆地**：1759年6月27日呈海军部备忘录称荷堡试图排斥英国使用公共登陆地，英荷堡已发生敌对行动；材料是英方的权利主张，不代表本地首领认可。 （来源：BS179；事件ID：`AB-F5-GH-012`）
- **1760-11-12｜公司要求各西非贸易堡宣读乔治三世继位公告**：伦敦委员会指示各堡宣告君主继位；殖民公司要求在贸易影响范围公开宣读，并不证明非洲各本地政体接受英国直接主权。 （来源：BS179；事件ID：`AB-F5-GH-013`）

## 权力与政治主体
1753工程师与Fante地方首领约束英方新堡尺寸；英国商堡受当地政治限制，并有被奴役者劳动和议会拨款
地图请保持Fante、当地王侯／法荷殖民地、印度各邦和其他非英国政治主体为独立对象；公司贸易许可证、官员礼金、税权、驻军、实际城堡占据及英国国王主权不得合并。

## 金额／数量／会计口径
- `FISC-F5-1750-Africa-secretary`：100 GBP_nominal_per_year。appointed secretary and accountant annual salary, not total payroll。限制：Committee salary grant not evidence of actual annual payment
- `FISC-F5-1750-Africa-secretary-bond`：500 GBP_nominal_security_bond。security bond required of accountant, not annual salary or paid revenue。限制：Bond promised, not annual net income, and not necessarily deposited cash
- `FISC-F5-1751-Africa-supplies`：10000 GBP_nominal_parliamentary_allocation。parliamentary grant toward African forts as explicitly noted in 1751 instructions。限制：Grant is British fiscal expense to maintain slave trade network, NOT profit
- `FISC-F5-1751-Cape-Coast-hire`：650 GBP_nominal_ship_hire_quote。Captain Bonell hired Flying Flambro (~370 ton) for 60 passengers and 30 crew。限制：Charter cost quoted; no proof full cash clearing and not slave count
- `FISC-F5-1753-Anomabo-material-cost-pounds`：6116 GBP_pounds_component_3shillings_9pence。Anomabo new fort imported stores cost £6,116 3s 9d; GBP component for searchable numeric。限制：FULL ORIGINAL £6116:3:9 (pounds/shillings/pence). Included in £10,000 1752 grant; never add as separate grant. GBP pounds component only.
- `FISC-F5-1754-African-youth-education-cost`：79 GBP_pounds_component_4s_1d。Committee repaid account £79 4s 1d for two young African persons (historical terminology biased)。限制：£79:4:1 not proof children were enslaved; not slave-sale proceeds
- `FISC-F5-1757-recruitment-per-soldier`：1 GBP_pounds_component_11s_6d_per_recruit。Recruiter John Blackwood allowance £1 11s 6d per recruited soldier。限制：Unit price has shillings/pence; not full GBP £1.00 and no evidence of paid total
- `FISC-F5-1757-recruitment-target`：10 persons_recruitment_target。ten soldiers specified in committee contract; actual embarkation not established。限制：Recruitment agreement headcount not precise live garrison

## 来源与阅读深度
- `BS179` Records Relating to the Gold Coast Settlements from 1750 to 1874, pp.10–36; reproduces eighteenth-century committee minutes, statutes and engineer letters：https://api.pageplace.de/preview/DT0400.9781136960703_A23876854/preview-9781136960703_A23876854.pdf；阅读级别：`historical_1923_compilation_extracts_read_pdf_screens_pages_10_23_24_36`；原始手稿本人亲阅：否。
- `BS182` Controlling the Company: Fante-British Relations on the Gold Coast 1750–1821：https://www.tandfonline.com/doi/full/10.1080/03086534.2013.762162；阅读级别：`peer_reviewed_abstract_read_only`；原始手稿本人亲阅：否。
- `BS193` Anomabo Fort William architecture and John Apperley fort building 1753：https://ufdcimages.uflib.ufl.edu/UF/E0/04/13/66/00001/micots_c.pdf；阅读级别：`university_thesis_indexed_excerpt_read`；原始手稿本人亲阅：否。

## GIS与后续查核
- 无实测控制 Polygon；具名地点可待地名文献复核后画现代参考点，严禁凭堡垒地点涂整国或整省。
- 未核项：原卷连续性、当地政治主体史料、精确军占起止日、金额实际清算、历史边界。
