# AB-NEW-067｜1780年第一场Pollilur战役与1781年不同结局之对照

> 研究阶段 research_only。此次新增候选，未经主编出版审核；不构造未经证实的控制面。

**原项目关联母题**：`E18-B13`

## 新增原因及主要发现

Royal Collection RCIN 734067展示的是1781胜利，绝不能用于证明1780英军败退的实际战线；当代军人绘图不等于整个Kanchipuram区域被英国实占。

**受影响群体/利益**：迈索尔独立政权与公司印度兵、英军战俘、Kanchipuram附近居民

## 有据史事 / 地图语义

### AB-R6-067-01｜1780｜Hyder Ali与Tipu军在Pollilur击败Baillie公司军

- 地方与主体：Pollilur / Pullalur near Kanchipuram；Hyder Ali; Tipu Sultan; Colonel John Baillie; EIC sepoys
- 史实：1780年9月10日迈索尔军击败公司Baillie纵队，大量军官伤亡或被俘；这场胜利不是1781第二场同名战役。
- 控制语义：`company_military_defeat_not_British_acquisition`；不据此生成英国领土面积。
- 日期精度：`day`；日期补充：{'month': 9, 'day': 10}

### AB-R6-067-02｜1781｜Pollilur第二战由公司将领Coote击败迈索尔军

- 地方与主体：Pollilur near Kanchipuram；Eyre Coote; Hyder Ali forces
- 史实：Royal Collection原军图标注1781年8月27日英军战胜Hyder Ali军；两战时间、胜败不同，地图需双事件。
- 控制语义：`company_military_victory_no_auto_annexation`；不据此生成英国领土面积。
- 日期精度：`day`；日期补充：{'month': 8, 'day': 27}

## 资料来源与实际阅读层级

- [BS226](https://publishing.cdlib.org/ucpressebooks/public/book/dialogue-and-history-constructing-south-india-1795-1895.html) Dialogue and History: The Battle of Pullalur and the Naturalization of the British；机构：University of California Press；阅读级别：`scholarly_full_html_read`；原始手稿亲阅：否；档案编号：无。
- [BS227](https://militarymaps.rct.uk/other-18th/19th-century-conflicts/map-of-the-battle-of-pollilur-1781-pollilur-near-kanchipuram-tamil-nadu-india-12deg5000n-79deg4300e) Original military map of Second Battle of Pollilur (1781) RCIN 734067；机构：Royal Collection Trust；阅读级别：`museum_map_catalogue_and_transcription_read`；原始手稿亲阅：否；档案编号：RCIN 734067。

## 尚待攻克

1780双方战报、战俘名单及战场遗址对应；军图坐标为现代城镇参照。

## 地图纪律

所有地点均为具名文本参考，尚未匹配正式权威参考坐标；该专题不可自动生成实控Polygon、军事行动缓冲圆面积、历史海运精确路线或现代行政区。
