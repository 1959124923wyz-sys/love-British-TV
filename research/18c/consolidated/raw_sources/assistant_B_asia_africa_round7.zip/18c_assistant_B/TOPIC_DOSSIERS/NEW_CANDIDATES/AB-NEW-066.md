# AB-NEW-066｜1727达荷美国王Agaja夺取Ouidah后英商堡贸易与当地权力

> 研究阶段 research_only。此次新增候选，未经主编出版审核；不构造未经证实的控制面。

**原项目关联母题**：`E18-E10`

## 新增原因及主要发现

1727是Dahomey对Hueda的征服，不是英国进攻；英国在此的殖民经济活动主要是强迫人口贩运和港市堡垒贸易。1690s英国实际堡址及1790退出时间仍未核。

**受影响群体/利益**：Hueda和达荷美国王、商人与被奴役人口，英法葡欧洲贸易据点

## 有据史事 / 地图语义

### AB-R6-066-01｜1727｜达荷美王Agaja军队征服Hueda/Ouidah

- 地方与主体：Ouidah / Hueda (present-day Benin)；King Agaja; Dahomean army; Hueda authorities; English traders
- 史实：1727年3月达荷美攻占原Hueda区域，英法葡商堡随后在达荷美王权和港务规则下经营。
- 控制语义：`african_polity_conquest_not_British_occupation`；不据此生成英国领土面积。
- 日期精度：`year`；日期补充：{'month': 3}

### AB-R6-066-02｜1755｜达荷美国王Tegbesu要求英法商堡确保港口和平

- 地方与主体：Ouidah；King Tegbesu; English, French and Portuguese fort directors
- 史实：1755年达荷美国王要求不同欧洲商堡尊重港内和平通行，反映本地对港口贸易的管治权。
- 控制语义：`african_sovereignty_over_european_forts`；不据此生成英国领土面积。
- 日期精度：`year`；日期补充：无

### AB-R6-066-03｜1762｜英国船射击法国堡补给船后达荷美王公开抗议

- 地方与主体：Ouidah coastal anchorage；British vessel; French fort suppliers; King Tegbesu
- 史实：达荷美王抗议英国船向法国据点供给独木舟开火，明确要求欧洲商船遵守其港口秩序。
- 控制语义：`local_royal_regulation_of_armed_trade`；不据此生成英国领土面积。
- 日期精度：`year`；日期补充：无

## 资料来源与实际阅读层级

- [BS224](https://www.cambridge.org/core/books/abs/ouidah/dahomian-conquest-of-ouidah/56386651A8A853276C32FFDE9920427B) Ouidah, chapter The Dahomian Conquest of Ouidah；机构：Cambridge / Robin Law；阅读级别：`book_chapter_summary_read`；原始手稿亲阅：否；档案编号：无。
- [BS225](https://www.cambridge.org/core/books/abs/ouidah/operation-of-the-atlantic-slave-trade/8C586FD8A07B0E31C6AFF7BBFE8BE677) Ouidah, chapter The Operation of Atlantic Slave Trade；机构：Cambridge / Robin Law；阅读级别：`book_chapter_summary_read`；原始手稿亲阅：否；档案编号：无。

## 尚待攻克

具体英国堡名称及1755/1762原通信，1767之后英船人口奴役航次个案。

## 地图纪律

所有地点均为具名文本参考，尚未匹配正式权威参考坐标；该专题不可自动生成实控Polygon、军事行动缓冲圆面积、历史海运精确路线或现代行政区。
