# AB-NEW-074｜1772—1784年东印度公司议会调查、救助贷款与监管制度

> **research_only / 第七轮**；法定许可、组织实施、已知问题与个别越权必须分证据等级。

## 历史过程与机制：公司财政危机后的国家介入与持续管治

1772公司金融危机推动英国议会调查，1773政府贷款并通过Regulating Act让公司继续治理印度领土，1784建立Board of Control。1783年议会第九报告档案列明丝、棉布、盐、鸦片、硝石和财政投资。Exeter档案另记1771董事接收税务直接管理命令。

## 归责与当地行动

国家对公司行为存在多层监督、贷款和政策设计，不能将1772调查说成议会已经批准每个贪污行为。当地纳瓦卜、zamindar和农民并非同一政府层级。

## 本轮新增时间线与证据

### AB-R7-POL-015｜1772｜1772年孟加拉税务委员会决定推行五年期租税承包竞标

税务委员会1772年5月14日决议以竞标承租征税权，涉及高价承包和农民负担；具体各pargana税率与实缴差距待原档核查。

**涉事主体**：Warren Hastings及Bengal Committee of Revenue；zamindar；tax farmers。**地点/行政层级**：Calcutta / Bengal parganas。**来源**：[BS05](https://searcharchives.bl.uk/catalog/041-001116388)；[BS265](https://famineanddearth.exeter.ac.uk/displayhtml.html?id=fp_00358_en_committeeofcircuit_7thjuly-20thaugust1772)。

**GIS限制**：不引入历史实控面，法规的通过地点与受影响的地区互不等同。

### AB-R7-POL-016｜1772｜1772年英国议会启动东印度公司财务与行政调查

东印度公司陷入财务危机，议会设特别和秘密委员会调查其治理；可核监督与知情，尚不能等同所有官员个人腐败获议会许可。

**涉事主体**：英国议会、英国财政政府、东印度公司股东及董事。**地点/行政层级**：Westminster, London。**来源**：[BS01](https://www.parliament.uk/about/living-heritage/evolutionofparliament/legislativescrutiny/parliament-and-empire/parliament-and-the-american-colonies-before-1765/parliament-and-the-east-india-company/)。

**GIS限制**：不引入历史实控面，法规的通过地点与受影响的地区互不等同。

### AB-R7-POL-017｜1773｜1773年议会对东印度公司发放财政救助贷款

英国图书馆公司档案目录记1773规制法后的政府贷款£1,400,000；属于对公司提供贷款，不是英国从印度掠夺收益。

**涉事主体**：英国政府、议会、东印度公司。**地点/行政层级**：Westminster, London。**来源**：[BS250](https://searcharchives.bl.uk/catalog/036-000178727)。

**GIS限制**：不引入历史实控面，法规的通过地点与受影响的地区互不等同。

### AB-R7-POL-018｜1773｜1773年《规制法》保留公司统治同时确立总督及议会监督

Regulating Act将公司统治置于国家监督体系内，设总督和委员会；王室并未当年直接接管整个印度。

**涉事主体**：英国议会、Company Court of Directors、Bengal Governor-General。**地点/行政层级**：Westminster / Calcutta。**来源**：[BS01](https://www.parliament.uk/about/living-heritage/evolutionofparliament/legislativescrutiny/parliament-and-empire/parliament-and-the-american-colonies-before-1765/parliament-and-the-east-india-company/)。

**GIS限制**：不引入历史实控面，法规的通过地点与受影响的地区互不等同。

### AB-R7-POL-020｜1783｜1783年议会第九报告系统审查印度税收采购和贸易垄断

IOR/L/PARL/2/15/4目录收录盐、鸦片、丝绸、棉布、硝石和Bengal revenue investment调查及公司《规制法》缺陷。报告原文未逐页读。

**涉事主体**：英国议会Select Committee、东印度公司董事和驻印官员。**地点/行政层级**：Westminster, London。**来源**：[BS251](https://searcharchives.bl.uk/catalog/041-001116495)。

**GIS限制**：不引入历史实控面，法规的通过地点与受影响的地区互不等同。

### AB-R7-POL-021｜1784｜1784年《印度法》建立伦敦Board of Control

英政府任命的监督委员会获得指导公司印度政策权力，英国政府对公司行为的制度性掌控加强。

**涉事主体**：英国议会、Board of Control、东印度公司。**地点/行政层级**：London / Bengal。**来源**：[BS01](https://www.parliament.uk/about/living-heritage/evolutionofparliament/legislativescrutiny/parliament-and-empire/parliament-and-the-american-colonies-before-1765/parliament-and-the-east-india-company/)。

**GIS限制**：不引入历史实控面，法规的通过地点与受影响的地区互不等同。

### AB-R7-POL-035｜1771｜1771年8月伦敦董事下令公司直接掌握孟加拉征税管理

Exeter引西孟加拉档案序言：1771年8月董事指示由公司接管全部征收管理，1772年组成巡视委员会。

**涉事主体**：东印度公司伦敦董事会；Hastings孟加拉管理层。**地点/行政层级**：London / Calcutta。**来源**：[BS265](https://famineanddearth.exeter.ac.uk/displayhtml.html?id=fp_00358_en_committeeofcircuit_7thjuly-20thaugust1772)。

**GIS限制**：不引入历史实控面，法规的通过地点与受影响的地区互不等同。

### AB-R7-POL-036｜1772｜1772年7月董事指示调查灾荒期间夺取农户口粮和种粮的控诉

Exeter译档记董事批评英方人员囤积谷物与迫使农户出售种粮，并要求调查；此事证明文书知情及调查指令，是否追责另待核。

**涉事主体**：东印度公司董事会；公司雇员；受灾农户。**地点/行政层级**：London / Bengal。**来源**：[BS265](https://famineanddearth.exeter.ac.uk/displayhtml.html?id=fp_00358_en_committeeofcircuit_7thjuly-20thaugust1772)。

**GIS限制**：不引入历史实控面，法规的通过地点与受影响的地区互不等同。

### AB-R7-POL-037｜1772｜1772年8月普尔尼亚多个地区农民提交征粮、加租及烙刑控诉

1772年8月5日委员会收录多个农户、地主控诉Debi Singh低价强购谷物、加租、殴打及烙刑；均为请愿指控，不可将每项当作已裁定罪行。

**涉事主体**：Dharampur、Purnea、Tajpur等地ryot和zamindar；Raja Debi Singh。**地点/行政层级**：Purnea and Tajpur districts。**来源**：[BS265](https://famineanddearth.exeter.ac.uk/displayhtml.html?id=fp_00358_en_committeeofcircuit_7thjuly-20thaugust1772)。

**GIS限制**：不引入历史实控面，法规的通过地点与受影响的地区互不等同。

### AB-R7-POL-038｜1772｜1772年8月公司Purnea Collector否认Debi Singh的各项控诉

同一档案记8月24日Ducarel称控诉不实并附文件；事实裁判尚未核，对照农民与公司官员两方来源。

**涉事主体**：英国公司Collector G.G. Ducarel；地方ryot和Raja Debi Singh。**地点/行政层级**：Purnea。**来源**：[BS265](https://famineanddearth.exeter.ac.uk/displayhtml.html?id=fp_00358_en_committeeofcircuit_7thjuly-20thaugust1772)。

**GIS限制**：不引入历史实控面，法规的通过地点与受影响的地区互不等同。

### AB-R7-POL-039｜1773｜1773年1月税务委员会命令公司士兵追击Sannyasi势力

Exeter译档载军官部队被命令向Bengal地方Sannyasi据点行动，含地名与武力部署；官员敌情数字未经独立证实。

**涉事主体**：Captain Robert Stuart及公司税务委员会；Sannyasi/Fakir团体。**地点/行政层级**：Dinajpur and Rangpur。**来源**：[BS266](https://famineanddearth.exeter.ac.uk/displayhtml.html?id=fp_00355_en_committeeofcircuit_2ndfebruary-9thfebruary1773)。

**GIS限制**：不引入历史实控面，法规的通过地点与受影响的地区互不等同。

### AB-R7-POL-040｜1773｜1773年2月公司报告占领Baikunthpur并驱逐Sannyasi力量

1773年2月15日公司来信摘要报告占领Baikunthpur，属于当事方战报且现存版本仅Press List，实际驻军期限未证。

**涉事主体**：Captain Robert Stuart；Darap Deo与Sannyasi forces；Company Revenue Committee。**地点/行政层级**：Baikunthpur / Jalpaiguri。**来源**：[BS267](https://famineanddearth.exeter.ac.uk/displayhtml.html?id=fp_00359_en_committeeofcircuit_15thfebruary-18thfebruary1773)。

**GIS限制**：不引入历史实控面，法规的通过地点与受影响的地区互不等同。

### AB-R7-ACT-06｜1773｜1773年公司贷款兼有要求对王室支付两年一度费用的安排

UK Parliament institutional history says Company kept political control of its territories under state authority for £40,000 payment per two years; chronology of actual cash payment requires UK fiscal records.

**涉事主体**：英国政府、议会、东印度公司。**地点/行政层级**：Westminster, London。**来源**：[BS01](https://www.parliament.uk/about/living-heritage/evolutionofparliament/legislativescrutiny/parliament-and-empire/parliament-and-the-american-colonies-before-1765/parliament-and-the-east-india-company/)。

**GIS限制**：不引入历史实控面，法规的通过地点与受影响的地区互不等同。

## 经济/人口证据与原卷缺口

英国议会1773《规制法》、1783第九报告原卷、Bengal Committee of Circuit各pargana投标及惩戒决定均待全文逐页读。

### 来源阅读深度

| ID | 网址或档案 | 本轮实际阅读级别 |
|---|---|---|
| BS01 | [Parliament and the East India Company](https://www.parliament.uk/about/living-heritage/evolutionofparliament/legislativescrutiny/parliament-and-empire/parliament-and-the-american-colonies-before-1765/parliament-and-the-east-india-company/) | full_html_read；原史料纸卷未亲读 |
| BS05 | [Bengal revenue and 1770 famine Sixth Report](https://searcharchives.bl.uk/catalog/041-001116388) | archive_catalogue_read；原史料纸卷未亲读 |
| BS250 | [IOR/A/2: Secret and Select Committees of East India Company](https://searcharchives.bl.uk/catalog/036-000178727) | archive_catalogue_read；原史料纸卷未亲读 |
| BS251 | [IOR/L/PARL/2/15/4 Ninth Report on Company law and Asian trade](https://searcharchives.bl.uk/catalog/041-001116495) | archive_catalogue_read；原史料纸卷未亲读 |
| BS265 | [Proceedings of Committee of Circuit 1772 July–August: Purnea peasants and directors letters](https://famineanddearth.exeter.ac.uk/displayhtml.html?id=fp_00358_en_committeeofcircuit_7thjuly-20thaugust1772) | digitized_primary_excerpt_transcription_read；原史料纸卷未亲读 |
| BS266 | [Proceedings of Committee of Circuit 1773 February 2–9](https://famineanddearth.exeter.ac.uk/displayhtml.html?id=fp_00355_en_committeeofcircuit_2ndfebruary-9thfebruary1773) | digitized_primary_excerpt_transcription_read；原史料纸卷未亲读 |
| BS267 | [Proceedings of Committee of Circuit 1773 February 15–18](https://famineanddearth.exeter.ac.uk/displayhtml.html?id=fp_00359_en_committeeofcircuit_15thfebruary-18thfebruary1773) | archival_press_list_excerpt_read；原史料纸卷未亲读 |

**候审地图**：全部无可靠历史边界，本篇事件仅作为时间轴、财政/政策关联和将来核实堡垒或城市参考点的研究素材。
