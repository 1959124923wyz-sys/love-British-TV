# AB-NEW-001｜1702—1709年东西两家东印度公司合并与重组

- **原母题关联**：`E18-B01`
- **独立新专题必要性**：重组法律决定谁具有合同、债务、军队和商馆持有身份，不能把17世纪Old Company ID一直延长

## 可核参考

- [BS13 East India Company Charters IOR/A/1 merger 1709](https://searcharchives.bl.uk/catalog/036-000178601)；阅读等级：archive_catalogue_read。

## 待核原件与地图

进入新专题须主编决定新正式编号，补足原始公司日志、财政原卷、地方视角；现阶段既不自动上图，也不改变项目原专题ID。
