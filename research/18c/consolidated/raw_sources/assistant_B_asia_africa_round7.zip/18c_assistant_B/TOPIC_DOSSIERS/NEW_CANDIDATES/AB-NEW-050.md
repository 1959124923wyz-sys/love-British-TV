# AB-NEW-050｜1770年Komenda受奴役者审判与跨大西洋惩罚移送提议

- 编辑关系：`E18-E10`；候选独立议题，不改变原母题ID。
- 研究状态：`research_only`；原纸档、地理边界尚未审定。

## 可核时间序列
- **1770-11-21｜Komenda地方审判决定惩罚八名涉嫌杀死奴主者**：英文城堡会议记录称各当地首领按地方习俗审理8名在堡内暂拘者，最终决定4人被交付处死、4人拟送英属美洲种植园；实际跨洋运输执行未证实。 （来源：BS179；事件ID：`AB-F5-GH-014`）

## 权力与政治主体
英堡作为拘禁地点，Fante/当地权力举行审判，裁决包含移送英国种植园提议；实际移送执行未明
地图请保持Fante、当地王侯／法荷殖民地、印度各邦和其他非英国政治主体为独立对象；公司贸易许可证、官员礼金、税权、驻军、实际城堡占据及英国国王主权不得合并。

## 金额／数量／会计口径
- 本候选暂无经核可量化财务数字；不补造收益。

## 来源与阅读深度
- `BS179` Records Relating to the Gold Coast Settlements from 1750 to 1874, pp.10–36; reproduces eighteenth-century committee minutes, statutes and engineer letters：https://api.pageplace.de/preview/DT0400.9781136960703_A23876854/preview-9781136960703_A23876854.pdf；阅读级别：`historical_1923_compilation_extracts_read_pdf_screens_pages_10_23_24_36`；原始手稿本人亲阅：否。

## GIS与后续查核
- 无实测控制 Polygon；具名地点可待地名文献复核后画现代参考点，严禁凭堡垒地点涂整国或整省。
- 未核项：原卷连续性、当地政治主体史料、精确军占起止日、金额实际清算、历史边界。
