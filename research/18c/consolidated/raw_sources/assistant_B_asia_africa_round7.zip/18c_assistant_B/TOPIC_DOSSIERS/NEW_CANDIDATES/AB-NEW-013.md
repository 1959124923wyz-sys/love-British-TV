# AB-NEW-013｜1799年Seringapatam Prize Committee战利品出售与种族化分配

- **原母题关联**：`E18-B15`
- **独立新专题必要性**：国家陆军博物馆有奖品委员会原签收记录，需查数额和印度sepoy分配

## 可核参考

- [BS11 Tipu Sultan war turban and Committee of Prize](https://www.nam.ac.uk/explore/tipu-sultans-war-turban)；阅读等级：full_html_read。

## 待核原件与地图

进入新专题须主编决定新正式编号，补足原始公司日志、财政原卷、地方视角；现阶段既不自动上图，也不改变项目原专题ID。
