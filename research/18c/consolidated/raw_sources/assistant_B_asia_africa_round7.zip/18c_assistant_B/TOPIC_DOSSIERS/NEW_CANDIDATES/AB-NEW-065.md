# AB-NEW-065｜1719—1720苏格兰贩奴船Hannover航次的非洲采购链

> 研究阶段 research_only。此次新增候选，未经主编出版审核；不构造未经证实的控制面。

**原项目关联母题**：`E18-E10`

## 新增原因及主要发现

三个地点已分别收21/22/75人；同一航次共可重算118名采购人口，未经船舱存活和美洲抵港名单不能称118名实际到岸。注意1719英苏已经联合王国。

**受影响群体/利益**：被奴役非洲人、Scottish私人商人和船员、多处非洲自主港市

## 有据史事 / 地图语义

### AB-R6-065-01｜1719｜Port Glasgow船Hannover起航贩奴航次

- 地方与主体：Port Glasgow to West Africa；Shipowner Robert Bogle Jr; Alexander Horsburgh; crew
- 史实：1719年末Hannover出航，后由外科医生Horsburgh主持购买被奴役者和补给品，不能把航次数当实际到岸奴役人数。
- 控制语义：`ship_voyage_not_maritime_territorial_rule`；不据此生成英国领土面积。
- 日期精度：`year`；日期补充：无

### AB-R6-065-02｜1720｜Hannover于Windward Coast购买21名被奴役者

- 地方与主体：Windward Coast (specific shore not fixed)；Horsburgh; local traders; enslaved Africans
- 史实：1720年3月购买21名被奴役者与粮食，确切购买点未核。
- 控制语义：`documented_captive_purchase`；不据此生成英国领土面积。
- 日期精度：`year`；日期补充：无

### AB-R6-065-03｜1720｜Hannover于黄金海岸购买22名被奴役者

- 地方与主体：Gold Coast；Horsburgh; local traders; enslaved Africans
- 史实：1720年4月5日至5月2日购买22名被奴役者，另采粮食；原航迹不能由海岸点连直线代替。
- 控制语义：`documented_captive_purchase`；不据此生成英国领土面积。
- 日期精度：`year`；日期补充：{'month': 4}

### AB-R6-065-04｜1720｜Hannover于Old Calabar购买75名被奴役者

- 地方与主体：Old Calabar；Horsburgh; Old Calabar merchants; enslaved Africans
- 史实：1720年5月下旬至7月上旬购买75名被奴役者；该数仅为本港购买人数，不是死亡或抵岸人数。
- 控制语义：`documented_captive_purchase`；不据此生成英国领土面积。
- 日期精度：`year`；日期补充：{'month': 5}

## 资料来源与实际阅读层级

- [BS223](https://www.cambridge.org/core/journals/history-in-africa/article/abs/african-merchants-notables-and-the-slave-trade-at-old-calabar-1720-evidence-from-the-national-archives-of-scotland/4260269CC4899A46AC1E0DA57BA6F7A0) African Merchants, Notables, Slave Trade at Old Calabar, 1720: Scottish Archives；机构：Cambridge / History in Africa；阅读级别：`journal_extract_read`；原始手稿亲阅：否；档案编号：National Archives Scotland (secondary cited, shelfmark unresolved)。

## 尚待攻克

Horsburgh原航次日志的苏格兰档案shelfmark、具体抵岸人数与船上死亡、原海上日志行程。

## 地图纪律

所有地点均为具名文本参考，尚未匹配正式权威参考坐标；该专题不可自动生成实控Polygon、军事行动缓冲圆面积、历史海运精确路线或现代行政区。
