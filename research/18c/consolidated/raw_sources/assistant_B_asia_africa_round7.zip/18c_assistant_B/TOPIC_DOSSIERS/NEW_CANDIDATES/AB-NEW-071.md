# AB-NEW-071｜1750年《非洲贸易法》与英政府在西非奴役贸易的制度建设

> **research_only / 第七轮**；法定许可、组织实施、已知问题与个别越权必须分证据等级。

## 历史过程与机制：国家立法组织西非奴役贸易

英国议会1750年法令不是私人贸易的边缘性口头许可，而是明确将种植园劳动力供应列为制度目的。Smithsonian藏1750历史印本说明法令重组西非商人公司、开放英国对非洲贸易；英国国家档案馆T70则保存贸易堡垒文书、堡内遭奴役者劳动及地方Fante社会的交涉。

## 归责与当地行动

国家法令和公司商贸体系构成持续制度链。Fante首领和非洲其他独立政体并不因公司在海岸拥有堡垒就丧失主权。

## 本轮新增时间线与证据

### AB-R7-POL-005｜1750｜1750年议会以奴役人口供应需求为由重组非洲贸易公司

23 Geo. II c.31公开宣称殖民地种植园需要可供购买的被奴役人口，设立贸易公司与堡垒安排。

**涉事主体**：英国议会、王室、Company of Merchants Trading to Africa、非洲海岸政体。**地点/行政层级**：Westminster, London / West Africa coast。**来源**：[BS240](https://nmaahc.si.edu/object/nmaahc_2019.28.2?form=FUNKKCZRWSJ&s_src=H0000PWBUTTON)。

**GIS限制**：不引入历史实控面，法规的通过地点与受影响的地区互不等同。

### AB-R7-POL-006｜{'start_year': 1750, 'end_year': 1799}｜1750年代英国西非堡垒公司保有被奴役劳工

T70 Detached Papers学术研究确认堡垒使用被奴役者劳动，并存Fante与英方行政人员的往来；此条保留整个研究时间窗，地点不能当所有堡垒实测范围。

**涉事主体**：Company of Merchants Trading to Africa；Fante首领、堡垒遭奴役者。**地点/行政层级**：Cape Coast/Anomabo and other named West African forts。**来源**：[BS249](https://doi.org/10.1017/abd.2025.10025)。

**GIS限制**：不引入历史实控面，法规的通过地点与受影响的地区互不等同。

## 经济/人口证据与原卷缺口

需要取得23 Geo II c31整册逐条影像及T70堡垒资产移交、获准贡金与用工名册，确定哪些堡垒实际换管、何时换管。

### 来源阅读深度

| ID | 网址或档案 | 本轮实际阅读级别 |
|---|---|---|
| BS240 | [1750 Act for Extending and Improving the Trade to Africa, object 2019.28.2](https://nmaahc.si.edu/object/nmaahc_2019.28.2?form=FUNKKCZRWSJ&s_src=H0000PWBUTTON) | institutional_object_catalogue_read；原史料纸卷未亲读 |
| BS249 | [The enslaved, the Fante, and the governors: Detached Papers of the Company of Merchants](https://doi.org/10.1017/abd.2025.10025) | peer_reviewed_abstract_html_read；原史料纸卷未亲读 |

**候审地图**：全部无可靠历史边界，本篇事件仅作为时间轴、财政/政策关联和将来核实堡垒或城市参考点的研究素材。
