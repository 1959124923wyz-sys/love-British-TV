# AB-NEW-008｜1773—1793年比哈尔鸦片合同、事实强制与形式放宽

- **原母题关联**：`E18-B20`
- **独立新专题必要性**：Wright论文显示1773合同禁止强迫→1788事实强制→1793明文自愿

## 可核参考

- [BS18 Emancipation of opium cultivators in Benares](https://www.cambridge.org/core/journals/international-review-of-social-history/article/emancipation-of-the-opium-cultivators-in-benares/094C2D32BEC39A82574A5FA91E64226F)；阅读等级：journal_extract_read。

## 待核原件与地图

进入新专题须主编决定新正式编号，补足原始公司日志、财政原卷、地方视角；现阶段既不自动上图，也不改变项目原专题ID。
