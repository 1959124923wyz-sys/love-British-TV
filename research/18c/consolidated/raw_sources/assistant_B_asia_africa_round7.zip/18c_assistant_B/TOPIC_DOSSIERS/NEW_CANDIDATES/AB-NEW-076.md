# AB-NEW-076｜1788—1799年孟加拉盐专卖拍卖制、价格与本地商人的应对

> **research_only / 第七轮**；法定许可、组织实施、已知问题与个别越权必须分证据等级。

## 历史过程与机制：食盐消费品成为公司财政垄断

孟加拉食盐已在公司生产与销售控制下，1788年公司改行拍卖定价，以提高财政收入。学者Miki及IRSH研究显示当地商业网络依然发挥定价与分销作用，故不能将本地商户从历史叙事中抹去。

## 归责与当地行动

盐工的低报酬、地方商人议价、民众购买负担需要按市场细分。约300万maund是制度定额概数，不是已运往英国的盐或实际出售量。

## 本轮新增时间线与证据

### AB-R7-POL-024｜1788｜1788年孟加拉食盐专卖由定价销售改为拍卖

公司为提高盐业收入实行拍卖定价，出产配额约300万maund系研究引用的制度概数，不是1790年某一批实际销售量。

**涉事主体**：东印度公司税务当局；孟加拉盐工；本地贸易商。**地点/行政层级**：Calcutta / Bengal salt districts。**来源**：[BS113](https://www.jstage.jst.go.jp/article/sehs/68/2/68_KJ00004582558/_article/-char/en)；[BS237](https://www.cambridge.org/core/journals/international-review-of-social-history/article/environmental-changes-the-emergence-of-a-fuel-market-and-the-working-conditions-of-salt-makers-in-bengal-c-17801845/EFF95B979EA1BC59C12DAFD1E623FB58)。

**GIS限制**：不引入历史实控面，法规的通过地点与受影响的地区互不等同。

## 经济/人口证据与原卷缺口

按年度检查Patna/Calcutta盐税销售表、盐工工资、拍卖价、黑市及质量登记，确认历史maund/sey计量。

### 来源阅读深度

| ID | 网址或档案 | 本轮实际阅读级别 |
|---|---|---|
| BS113 | [Sayako Miki 2002 Bengal salt auction monopoly 1788-1836](https://www.jstage.jst.go.jp/article/sehs/68/2/68_KJ00004582558/_article/-char/en) | peer_reviewed_abstract_read；原史料纸卷未亲读 |
| BS237 | [Environmental Changes, Fuel Market, Working Conditions of Bengal Salt Makers c.1780–1845](https://www.cambridge.org/core/journals/international-review-of-social-history/article/environmental-changes-the-emergence-of-a-fuel-market-and-the-working-conditions-of-salt-makers-in-bengal-c-17801845/EFF95B979EA1BC59C12DAFD1E623FB58) | journal_full_html_read；原史料纸卷未亲读 |

**候审地图**：全部无可靠历史边界，本篇事件仅作为时间轴、财政/政策关联和将来核实堡垒或城市参考点的研究素材。
