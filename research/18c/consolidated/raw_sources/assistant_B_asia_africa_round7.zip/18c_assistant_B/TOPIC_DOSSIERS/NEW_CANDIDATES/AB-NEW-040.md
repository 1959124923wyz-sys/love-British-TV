# AB-NEW-040｜1762—1799坦贾武尔王室、纳戈尔授地和公司军事财政

状态：`research_only` / `propose_to_editor`。原有E18-B/E系列ID保持不动。

**推荐与原项目交叉索引：** `E18-B21`。

## 问题与发现
277村庄和Nagore的176?授地与1799后合同不等于全部王国直接领土。

## 逐件证据事件
### AB-NEW-040-001｜1778｜坦贾武尔王授Nagore及277个村镇给东印度公司
- 行动者：Raja of Tanjore; EIC；地点：Nagore and Muarugoddy district, Tamil Nadu；日期精度：day。
- 事实与权利：1778-06-17王室Sanad列含Nagore港在内277村镇，另有土地灌溉与当地宗教权益条款；必须逐村证据定位，不能整坦贾武尔涂色。
- 法权分类：`specific_village_jagir_grant_not_tanjore_annexation`；可验证程度：`confirmed_in_cited_secondary_or_printed_edition`。
- 证据：[BS164](https://ignca.gov.in/Asi_data/14009.pdf)

### AB-NEW-040-002｜1799｜坦贾武尔王室1799年与公司签新治理条约
- 行动者：Raja of Tanjore; East India Company；地点：Thanjavur/Tanjore；日期精度：day。
- 事实与权利：政府条约汇编列1799-10-25关于Tanjore政体新治理安排；须查实际税收交割和王室继续存在范围。
- 法权分类：`governance_treaty_not_verified_territory_boundary`；可验证程度：`confirmed_in_cited_secondary_or_printed_edition`。
- 证据：[BS164](https://ignca.gov.in/Asi_data/14009.pdf)

## 经济或人口分项（若有）

现有足额/实收货币账无法确认，保持null；不得推断成本、利润或净汇出。

## 地图与下一步
所有本专题地理对象先作具名点或未定位参考；不得将地方胡椒贸易许可、宗主关系、陆军战场或现代省界填成公司实占多边形；有确切让地条文也必须先核逐村或历史岛岸边界。

**核查缺口**：需核条约的当地语言版本、年度实际税收和付款凭据、当事人答辩、原档页影及能够校准的历史地籍。
**档案声明**：18世纪物理原件未亲阅；1909编辑出版条约文字与馆藏目录保留不同阅读等级。

## 第四轮第二批：独立证据链

原始财政科目与法权转换按条文分开，以下均处候审阶段：

- **AB-NEW-040-003**（1762）：坦贾武尔王与卡纳提克纳瓦卜定期赔付220万卢比。1762年两王签约一次性220万卢比，分1762至1764五期。英国公司为履约担保人而非全部款项的最终债权人。 证据：[1909年政府条约汇编](https://ignca.gov.in/Asi_data/14009.pdf)。
- **AB-NEW-040-004**（1762）：坦贾武尔王另承诺每年向纳瓦卜缴纳40万卢比。1762条约约定每年20万卢比莫卧儿peshkash及20万卢比礼品与durbar费，不能把两者均归东印度公司收入。 证据：[1909年政府条约汇编](https://ignca.gov.in/Asi_data/14009.pdf)。
- **AB-NEW-040-005**（1787）：坦贾武尔王1787年订英印军费条约日期待核。1909政府条约卷目录记10 Apr 1787，但签署页行文为20 Apr 1787；档内冲突，先只用年精度。 证据：[1909年政府条约汇编](https://ignca.gov.in/Asi_data/14009.pdf)。
- **AB-NEW-040-006**（1793）：坦贾武尔条约按三种科目设定军费贡赋与私债。1793年6月11日签约；每年350000 Star Pagodas军费、114285 Star Pagodas贡赋转付、60000 Star Pagodas私人债务；贡赋先延期三年，头三年需按合同每年缴460000（包括50000积欠摊付）。 证据：[1909年政府条约汇编](https://ignca.gov.in/Asi_data/14009.pdf)。
- **AB-NEW-040-007**（1793）：坦贾武尔欠款15天后可被公司接管指定地区收税。条约第7条：分期款到期逾15天，公司可在清单所列整区收税，设8%借贷往来科目；某些还款情形下归还，另一些条件可持续管理。原条约条款与实际执行须分开。 证据：[1909年政府条约汇编](https://ignca.gov.in/Asi_data/14009.pdf)。
- **FISC-1762-Tanjore-Carnatic-lump-sum**：2200000 rupee_nominal_1762；1762 total indemnity/arrears under Raja vs Nawab treaty；限制：Legal obligation with instalments, not actual paid amount; EIC guaranteed, do NOT classify as Company revenue.
- **FISC-1762-Tanjore-Carnatic-tribute**：200000 rupee_nominal_1762；annual Mughal peshkash due by Raja to Nawab；限制：Legal annual dues to indigenous Nawab; not company income.
- **FISC-1762-Tanjore-Carnatic-durbar**：200000 rupee_nominal_1762；annual durbar present separate from peshkash；限制：Annual present distinct from tribute; do not aggregate with company transfers.
- **FISC-1793-Tanjore-military**：350000 star_pagoda_nominal；military subsidy owed each year to Company treasury；限制：Promised, not actual cash collected; same first-3-year aggregate component, do not double count.
- **FISC-1793-Tanjore-tribute**：114285 star_pagoda_nominal；Tanjore peshkash originally payable Nawab of Carnatic, transferred entitlement to Company；限制：Reassigned legal claim; first three years suspended, not paid cash every 1793 year.
- **FISC-1793-Tanjore-private-debt**：60000 star_pagoda_nominal；private debts repayment (Company acts collector)；限制：Private creditors are final recipients, not company net profits.
- **FISC-1793-Tanjore-arrears**：50000 star_pagoda_nominal；first 3 years periodic past peshkash arrears repayment；限制：Same aggregate 460000 includes this; not separately additional income.
- **FISC-1793-Tanjore-first-3y-total**：460000 star_pagoda_nominal；first 3 years annual sum of military+arrears+private debts, 350k+50k+60k；限制：Composite total: subsets are already separate table entries. NOT additional amount. Actual cash receipts unknown.
- **FISC-1793-Tanjore-postponed-peshkash**：342855 star_pagoda_nominal；three years deferred peshkash 114285 * 3；限制：Stock of arrears after three years, not independent annual recurring levy; excerpt states later amortization.
- **FISC-1793-Tanjore-balance-interest**：8 percent_per_annum；contractual interest rate on balance account after district receivership；限制：Contract rate, no principal or actual realised interest confirmed.
