# AB-NEW-061｜1772—1783布罗奇/Broach城区征税及马拉塔交割

> 研究阶段 research_only。此次新增候选，未经主编出版审核；不构造未经证实的控制面。

**原项目关联母题**：`E18-B11`

## 新增原因及主要发现

IOR/G/5同时记录1803重新取得，但本研究严格截至1799。马拉塔辛迪亚不是英国王室下属行政机构。

**受影响群体/利益**：Broach居民、纳瓦卜、Scindia马拉塔的财政权与贸易

## 有据史事 / 地图语义

### AB-R6-061-01｜1772｜东印度公司取得Broach地区行政与税权

- 地方与主体：Broach / Bharuch, Gujarat；EIC Bombay; Nawab of Broach; local residents
- 史实：1772年布罗奇由公司军政控制，公司档案IOR/G/5收1772–1783的地区管理；边界尚待实测档图。
- 控制语义：`district_administration_not_gujarat_annexation`；不据此生成英国领土面积。
- 日期精度：`year`；日期补充：无

### AB-R6-061-02｜1773｜Broach税官编录城市细目税及收入

- 地方与主体：Bharuch；EIC revenue officials; Bharuch town residents
- 史实：1773年当时公司文书记录多种市镇税及实际征收，研究已分析其潜在加重的负担；未直接读取文书细目。
- 控制语义：`company_micro_taxation`；不据此生成英国领土面积。
- 日期精度：`year`；日期补充：无

### AB-R6-061-03｜1783｜公司将Broach地区移交马拉塔Scindia

- 地方与主体：Broach / Bharuch；EIC; Mahadji Scindia / Maratha polity
- 史实：英国图书馆官档说明1783年交予Scindia，不能把1772控制延续为1784–1799持续公司实占。
- 控制语义：`territory_transferred_to_maratha`；不据此生成英国领土面积。
- 日期精度：`year`；日期补充：无

## 资料来源与实际阅读层级

- [BS216](https://searcharchives.bl.uk/catalog/036-000173372) Factory records Broach: EIC district 1772–1783 and handover to Scindia；机构：British Library / India Office；阅读级别：`archive_catalogue_read`；原始手稿亲阅：否；档案编号：IOR/G/5。
- [BS217](https://journals.sagepub.com/doi/10.1177/0262728003232004) Town Revenues and Taxes in Eighteenth-Century Gujarat；机构：SAGE / South Asia Research；阅读级别：`journal_abstract_read`；原始手稿亲阅：否；档案编号：无。

## 尚待攻克

1772战事签字文件与1783实际行政交割日、历史布罗奇边界地图和税率原件。

## 地图纪律

所有地点均为具名文本参考，尚未匹配正式权威参考坐标；该专题不可自动生成实控Polygon、军事行动缓冲圆面积、历史海运精确路线或现代行政区。
