# AB-NEW-079｜1701—1736年英国保护本国纺织业的亚洲棉布关税、禁令和殖民市场转运

> **research_only / 第七轮**；法定许可、组织实施、已知问题与个别越权必须分证据等级。

## 历史过程与机制：英国纺织保护主义与印度商品进入英国市场的制度门槛

1701英国限制特定亚洲花布销售，1721通过国内棉布法令及殖民市场转运限制，1736又调整部分产业禁令。议会官网说明1721法令受本地纺织业请愿推动，剑桥研究证实东印度公司对英属美洲的进口路径获更有利地位。

## 归责与当地行动

欧洲贸易法和孟加拉织工的采购强迫是互补但不同的机制。Om Prakash指出第二个过程存在强迫中间商和工匠，但同时质疑“一夕之间纺织工业全灭”的简单叙述。

## 本轮新增时间线与证据

### AB-R7-POL-001｜1701｜1701年英国限制亚洲彩色织物在英零售

英国议会限制彩色丝绸和花布在国内消费，允许转运/出口等例外；对英国内需市场而非直接印度工厂关闭。

**涉事主体**：英格兰议会；东印度公司；英国毛纺生产者与印度供应商。**地点/行政层级**：London, English market。**来源**：[BS257](https://www.metmuseum.org/exhibitions/listings/2013/interwoven-globe)。

**GIS限制**：不引入历史实控面，法规的通过地点与受影响的地区互不等同。

### AB-R7-POL-002｜1721｜1721年英国进一步限制本地销售印花棉布

1721法令为保护英国毛纺业限制穿用若干印花棉布；对东印度公司转口贸易及印度商人冲击应另核。

**涉事主体**：英国议会；英国产业请愿者；印度棉布商。**地点/行政层级**：Westminster, London。**来源**：[BS256](https://www.parliament.uk/about/living-heritage/transformingsociety/tradeindustry/industrycommunity/overview/textileindustries/)。

**GIS限制**：不引入历史实控面，法规的通过地点与受影响的地区互不等同。

### AB-R7-POL-003｜1721｜1721年议会限制美洲殖民地绕开英国输入东印度商品

针对直接从外国市场向英属美洲殖民地转运东印度商品的法律障碍，强化英国中转和公司垄断贸易渠道。

**涉事主体**：英国议会；东印度公司；英属美洲商人。**地点/行政层级**：Westminster, London。**来源**：[BS258](https://www.cambridge.org/core/journals/journal-of-british-studies/article/calico-madams-and-south-sea-cheats-global-trade-finance-and-popular-protest-in-early-hanoverian-england/A42541469AC2D07D56DB379D6B34EFAA)。

**GIS限制**：不引入历史实控面，法规的通过地点与受影响的地区互不等同。

### AB-R7-POL-004｜1736｜1736年Manchester Act放宽混纺布制造限制

英国调整1721年以来的纺织贸易保护法，表明这套法规存在持续的产业游说和修订。

**涉事主体**：英国议会；Lancashire棉纺和毛纺行业。**地点/行政层级**：Westminster, London。**来源**：[BS256](https://www.parliament.uk/about/living-heritage/transformingsociety/tradeindustry/industrycommunity/overview/textileindustries/)。

**GIS限制**：不引入历史实控面，法规的通过地点与受影响的地区互不等同。

## 经济/人口证据与原卷缺口

须补英国当年进口/转口布匹海关账、各产品豁免、孟加拉布价与织工工钱；不得仅靠禁令推算死亡与工业衰退率。

### 来源阅读深度

| ID | 网址或档案 | 本轮实际阅读级别 |
|---|---|---|
| BS256 | [Textile industries: 1721 Act, 1736 Manchester Act](https://www.parliament.uk/about/living-heritage/transformingsociety/tradeindustry/industrycommunity/overview/textileindustries/) | institutional_html_read；原史料纸卷未亲读 |
| BS257 | [Interwoven Globe: textiles timeline 1708–1736](https://www.metmuseum.org/exhibitions/listings/2013/interwoven-globe) | museum_history_timeline_excerpt_read；原史料纸卷未亲读 |
| BS258 | [Calico Madams and South Sea Cheats: 1721 trade controls](https://www.cambridge.org/core/journals/journal-of-british-studies/article/calico-madams-and-south-sea-cheats-global-trade-finance-and-popular-protest-in-early-hanoverian-england/A42541469AC2D07D56DB379D6B34EFAA) | peer_reviewed_html_search_excerpt_read；原史料纸卷未亲读 |

**候审地图**：全部无可靠历史边界，本篇事件仅作为时间轴、财政/政策关联和将来核实堡垒或城市参考点的研究素材。
