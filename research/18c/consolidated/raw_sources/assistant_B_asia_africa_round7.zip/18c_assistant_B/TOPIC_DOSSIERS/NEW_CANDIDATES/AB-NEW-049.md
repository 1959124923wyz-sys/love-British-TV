# AB-NEW-049｜1782年英国袭击荷属Elmina与五处西非堡垒

- 编辑关系：`E18-E10`；候选独立议题，不改变原母题ID。
- 研究状态：`research_only`；原纸档、地理边界尚未审定。

## 可核时间序列
- **1782-02-17｜英军联合海陆兵力攻击荷属Elmina但被击退**：Crooks前言综述1782年2月17—21日英国进攻Elmina失败；原发报副本与军队名单未直接核对，攻城区域不要自行推算。 （来源：BS179；事件ID：`AB-F5-GH-015`）
- **1782-03｜Shirley上尉在西非海岸短期夺取五座荷属堡**：1923文献前言称1782年3月英舰Leander攻下五堡，但摘录未列堡名、坐标与归还时间；保持地区文字事件、不生成五个地理点。 （来源：BS179；事件ID：`AB-F5-GH-016`）
- **1782-02｜英国派两支独立连至海岸角堡准备进攻荷堡**：英军两连于1782年2月抵达Cape Coast，原总额200人；六月以后编制剧降的原因、统计期间需复核。 （来源：BS179；事件ID：`AB-F5-GH-017`）

## 权力与政治主体
1782 Feb17–21 Elmina攻城失败、3月Shirley取五座荷属堡；据点短期军占不等于加纳领土吞并
地图请保持Fante、当地王侯／法荷殖民地、印度各邦和其他非英国政治主体为独立对象；公司贸易许可证、官员礼金、税权、驻军、实际城堡占据及英国国王主权不得合并。

## 金额／数量／会计口径
- `FISC-F5-1782-West-Africa-two-company-men`：200 persons_initial_force_claim。Crooks 1923 historical preface says two Independent Companies landing total strength 200。限制：Not a count of enslaved persons nor complete military campaign casualty statistics
- `FISC-F5-1782-West-Africa-strength-six-months`：60 persons_remaining_force_claim。Historical preface claims force reduced to 60 within 6 months; desertion and detachments, do not infer deaths。限制：200 minus 60 not attributable to deaths alone; no duplicate casualty calculation

## 来源与阅读深度
- `BS179` Records Relating to the Gold Coast Settlements from 1750 to 1874, pp.10–36; reproduces eighteenth-century committee minutes, statutes and engineer letters：https://api.pageplace.de/preview/DT0400.9781136960703_A23876854/preview-9781136960703_A23876854.pdf；阅读级别：`historical_1923_compilation_extracts_read_pdf_screens_pages_10_23_24_36`；原始手稿本人亲阅：否。

## GIS与后续查核
- 无实测控制 Polygon；具名地点可待地名文献复核后画现代参考点，严禁凭堡垒地点涂整国或整省。
- 未核项：原卷连续性、当地政治主体史料、精确军占起止日、金额实际清算、历史边界。
