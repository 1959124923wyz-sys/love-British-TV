# AB-NEW-042｜1787—1795特拉凡哥尔军费附属、1793胡椒合同及1791科钦政治关系

状态：`research_only` / `propose_to_editor`。原有E18-B/E系列ID保持不动。

**推荐与原项目交叉索引：** `E18-B21`。

## 问题与发现
军费、贸易排他权与政治联盟独立建模，不得以胡椒合同涂色独立王国。

## 逐件证据事件
### AB-NEW-042-001｜1791｜科钦王向公司签订关系条约
- 行动者：Raja of Cochin; EIC；地点：Kochi / Cochin；日期精度：day。
- 事实与权利：官方汇编列1791-01-06科钦成为英国tributary的条约；按相关义务单列，科钦王权仍在。
- 法权分类：`tributary_treaty_not_direct_annexation`；可验证程度：`confirmed_in_cited_secondary_or_printed_edition`。
- 证据：[BS164](https://ignca.gov.in/Asi_data/14009.pdf)

### AB-NEW-042-002｜1793｜特拉凡哥尔王室与孟买公司签十年胡椒供货合同
- 行动者：Raja of Travancore; Dewan Guswa Pillai; Governor Robert Abercromby；地点：Travancore/Malabar；日期精度：day。
- 事实与权利：1793-01-28合同供胡椒换军火及欧洲商品，期限十年；合同贸易收益与军事费用非一项。
- 法权分类：`pepper_supply_contract_not_sovereignty`；可验证程度：`confirmed_in_cited_secondary_or_printed_edition`。
- 证据：[BS164](https://ignca.gov.in/Asi_data/14009.pdf)

### AB-NEW-042-003｜1795｜特拉凡哥尔同意英印公司军队支持与临时补贴
- 行动者：Raja of Travancore; Jonathan Duncan; EIC；地点：near Anjengo / Anchuthengu；日期精度：day。
- 事实与权利：1795-11-17三条临时协定以一营印度士兵费用为基本补贴，额外军事援助另定，系附属关系非土地吞并。
- 法权分类：`subsidiary_military_treaty_not_annexation`；可验证程度：`confirmed_in_cited_secondary_or_printed_edition`。
- 证据：[BS164](https://ignca.gov.in/Asi_data/14009.pdf)

## 经济或人口分项（若有）

- `FISC-1793-travancore-pepper-tenure`：10 years_contract_duration（1793-01-28 contractual term）；pepper supply duration as stipulated in trade contract。**口径：** Duration only, not quantity, profit, or forced labor total.

## 地图与下一步
所有本专题地理对象先作具名点或未定位参考；不得将地方胡椒贸易许可、宗主关系、陆军战场或现代省界填成公司实占多边形；有确切让地条文也必须先核逐村或历史岛岸边界。

**核查缺口**：需核条约的当地语言版本、年度实际税收和付款凭据、当事人答辩、原档页影及能够校准的历史地籍。
**档案声明**：18世纪物理原件未亲阅；1909编辑出版条约文字与馆藏目录保留不同阅读等级。

## 第四轮第二批：独立证据链

原始财政科目与法权转换按条文分开，以下均处候审阶段：

- **AB-NEW-042-003**（1795）：特拉凡哥尔同意英印公司军队支持与临时补贴。1795-11-17三条临时协定以一营印度士兵费用为基本补贴，额外军事援助另定，系附属关系非土地吞并。 证据：[1909年政府条约汇编](https://ignca.gov.in/Asi_data/14009.pdf)。
- **AB-NEW-042-004**（1788）：特拉凡哥尔与公司确定英军驻其边境的协议。1788-06-19双方关于英军边境布置的协议，区别军事驻地与地方王权。 证据：[1909年政府条约汇编](https://ignca.gov.in/Asi_data/14009.pdf)。
- **FISC-1793-travancore-pepper-tenure**：10 years_contract_duration；pepper supply duration as stipulated in trade contract；限制：Duration only, not quantity, profit, or forced labor total.
