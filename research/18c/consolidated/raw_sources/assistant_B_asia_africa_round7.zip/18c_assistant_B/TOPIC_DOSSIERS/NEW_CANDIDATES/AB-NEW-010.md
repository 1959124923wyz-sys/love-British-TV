# AB-NEW-010｜1704—1748年本古伦跨印度洋奴役劳动网络

- **原母题关联**：`E18-E15`
- **独立新专题必要性**：公司从圣赫勒拿与马达加斯加转运奴役者修筑堡垒和加工胡椒

## 可核参考

- [BS34 The Making and Unmaking of a Presidency British Bencoolen 1685-1825](https://www.cambridge.org/core/journals/journal-of-british-studies/article/making-and-unmaking-of-a-presidency-envisioning-empire-in-british-bencoolen-16851825/4C0CA8C6BF1E88181DA0CEACBC33C47A)；阅读等级：scholarly_full_html_read。

## 待核原件与地图

进入新专题须主编决定新正式编号，补足原始公司日志、财政原卷、地方视角；现阶段既不自动上图，也不改变项目原专题ID。
