# AB-NEW-048｜1728—1794年邦斯岛堡弃守、私人贩奴公司接手与战时袭击

- 编辑关系：`E18-E09`；候选独立议题，不改变原母题ID。
- 研究状态：`research_only`；原纸档、地理边界尚未审定。

## 可核时间序列
- **1728｜皇家非洲公司放弃塞拉利昂河Bunce岛堡**：1752年英国议会法案追述RAC及职员在1728年弃守Bance堡；没有把本地居民自治消失或岛周边海岸英国管治当作法律后果。 （来源：BS179, BS181；事件ID：`AB-F5-SL-001`）
- **1752-04-10｜1752议会法保留Grant、Sargent与Oswald对Bance岛堡占有**：25 Geo II c40对私人商人的具体例外：其对岛屿堡垒及建筑占有继续，不随RAC整体移交新的Africa Merchants Company。 （来源：BS179, BS181；事件ID：`AB-F5-SL-002`）
- **1794｜Bunce岛私商声称因法英战争遭美法来袭受损**：1807年请愿追述1794战时入侵导致岛上财产毁坏不少于20,000英镑；归类为**1807年业主索赔宣称**，不是经验证真损失、亦非保险到账。 （来源：BS181；事件ID：`AB-F5-SL-003`）

## 权力与政治主体
1728 RAC弃守，1752议会在法中确认私人业主持有；1794损失数额见1807年业主利益请愿
地图请保持Fante、当地王侯／法荷殖民地、印度各邦和其他非英国政治主体为独立对象；公司贸易许可证、官员礼金、税权、驻军、实际城堡占据及英国国王主权不得合并。

## 金额／数量／会计口径
- `FISC-F5-1794-Bunce-owner-loss-claim`：20000 GBP_nominal_claim_lower_bound。Anderson brothers in February 1807 petition claim loss upwards of £20,000 on Bunce Island in 1794 attack。限制：Claim is self-interested and not an audited loss, actual compensation or received revenue

## 来源与阅读深度
- `BS179` Records Relating to the Gold Coast Settlements from 1750 to 1874, pp.10–36; reproduces eighteenth-century committee minutes, statutes and engineer letters：https://api.pageplace.de/preview/DT0400.9781136960703_A23876854/preview-9781136960703_A23876854.pdf；阅读级别：`historical_1923_compilation_extracts_read_pdf_screens_pages_10_23_24_36`；原始手稿本人亲阅：否。
- `BS180` Bunce Island History: RAC / Grant Oswald / Anderson succession and slave trade：https://macmillan.yale.edu/glc/bunce-island-history；阅读级别：`academic_university_site_full_html_read`；原始手稿本人亲阅：否。
- `BS181` Petitions Against the Slave Trade Abolition Bill, 17 Feb 1807; Anderson owners recount Bance Island 1752 rights and claimed 1794 loss：https://api.parliament.uk/historic-hansard/commons/1807/feb/17/petitions-against-the-slave-trade；阅读级别：`digitised_1807_primary_parliamentary_petition_transcription_read`；原始手稿本人亲阅：否。

## GIS与后续查核
- 无实测控制 Polygon；具名地点可待地名文献复核后画现代参考点，严禁凭堡垒地点涂整国或整省。
- 未核项：原卷连续性、当地政治主体史料、精确军占起止日、金额实际清算、历史边界。
