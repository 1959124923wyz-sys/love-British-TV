# AB-NEW-004｜1757—1759年孟加拉24 Parganas zamindari授地

- **原母题关联**：`E18-B03`
- **独立新专题必要性**：对Calcutta周边公司合法收入地权需另查具体授地年、村名、地籍和承诺/交割差异

## 可核参考

- [BS23 Plassey 23 June 1757 engraving catalogue](https://collection.nam.ac.uk/detail.php?acc=1961-10-51--1)；阅读等级：museum_artifact_context_read。

## 待核原件与地图

进入新专题须主编决定新正式编号，补足原始公司日志、财政原卷、地方视角；现阶段既不自动上图，也不改变项目原专题ID。
