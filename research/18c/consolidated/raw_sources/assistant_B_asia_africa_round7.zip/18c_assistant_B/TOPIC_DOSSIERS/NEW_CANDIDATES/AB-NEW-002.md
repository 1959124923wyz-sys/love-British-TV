# AB-NEW-002｜1717年法鲁赫西亚尔关税敕令、dastak私商滥用及纳瓦卜回应

- **原母题关联**：`E18-B01`
- **独立新专题必要性**：明确固定款3000卢比与准税货物的边界，以及公司职员个人贸易

## 可核参考

- [BS12 Farrukh Siyar Farman 1717](https://en.banglapedia.org/index.php/Farrukh_Siyar%E2%80%99s_Farman)；阅读等级：full_html_read。

## 待核原件与地图

进入新专题须主编决定新正式编号，补足原始公司日志、财政原卷、地方视角；现阶段既不自动上图，也不改变项目原专题ID。
