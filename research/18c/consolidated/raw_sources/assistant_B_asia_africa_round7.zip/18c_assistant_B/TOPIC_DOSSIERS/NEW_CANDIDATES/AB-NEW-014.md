# AB-NEW-014｜1746—1748年法国短占Madras圣乔治堡

- **原母题关联**：`E18-B02`
- **独立新专题必要性**：港城驻地年末易手直接影响18世纪控制连续性

## 可核参考

- [BS04 IOR/G East India Company general archive](https://searcharchives.bl.uk/catalog/032-000173250)；阅读等级：archive_catalogue_read。

## 待核原件与地图

进入新专题须主编决定新正式编号，补足原始公司日志、财政原卷、地方视角；现阶段既不自动上图，也不改变项目原专题ID。
