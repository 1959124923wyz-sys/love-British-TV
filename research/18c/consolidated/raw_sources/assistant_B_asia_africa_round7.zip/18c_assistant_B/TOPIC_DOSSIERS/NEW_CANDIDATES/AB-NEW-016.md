# AB-NEW-016｜1763—1783年英国佛罗里达替换哈瓦那的条约收益

- **原母题关联**：`E18-E13`
- **独立新专题必要性**：1763战争占港换永久殖民属战略交换，相关北美主题需与助手1协调

## 可核参考

- [BS71 British Heritage Trail: Havana exchange for Florida](https://dos.fl.gov/historical/preservation/heritage-trails/british-heritage-trail/)；阅读等级：state_historical_explanation_read。

## 待核原件与地图

进入新专题须主编决定新正式编号，补足原始公司日志、财政原卷、地方视角；现阶段既不自动上图，也不改变项目原专题ID。
