# AB-NEW-060｜1759—1800苏拉特城堡夺取与英国商船保护勒索

> 研究阶段 research_only。此次新增候选，未经主编出版审核；不构造未经证实的控制面。

**原项目关联母题**：`E18-B01`

## 新增原因及主要发现

专题论文注释明确：至1800年苏拉特多数居民仍被视为莫卧儿臣民。1759城堡职权不可改写为全部城市的“英国直接统治”，城堡控制也不同于马拉塔分成权利。

**受影响群体/利益**：苏拉特印度航运商、城堡办公人员、莫卧儿名义臣民及马拉塔税权争议

## 有据史事 / 地图语义

### AB-R6-060-01｜1759｜东印度公司武装取得苏拉特城堡长官职权

- 地方与主体：Surat Castle / Surat；EIC Surat factory; Surat castle governor; city Nawab
- 史实：1759年军事行动针对城堡控制者，公司工厂首席继承城堡长官权力；城市Nawab和穆斯林/印度商人权利分属其他法权。
- 控制语义：`castle_office_not_whole_city_annexation`；不据此生成英国领土面积。
- 日期精度：`year`；日期补充：无

### AB-R6-060-02｜1759｜苏拉特堡垒税收报表编成

- 地方与主体：Surat Castle and Tanka；EIC Surat officials; local merchants
- 史实：1759年11月5日Erskine关于城堡和Tanka收入报告现可在IOR/G/36/119目录定位；档案目录未提供实际数额。
- 控制语义：`revenue_document_archive_lead`；不据此生成英国领土面积。
- 日期精度：`year`；日期补充：{'month': 11, 'day': 5}

### AB-R6-060-03｜1759–1800｜公司官员对苏拉特—波斯湾海上贸易设保护与垄断条件

- 地方与主体：Surat to Arabian/Persian Gulf ports；EIC officials; Indian ship-owning merchants
- 史实：1759—1800间对印度商船主实施保护费及贸易限制，印度船东持续抗争；海运关系非公司控制海面领土。
- 控制语义：`maritime_exaction_not_sovereignty`；不据此生成英国领土面积。
- 日期精度：`multi_decade`；日期补充：{'year_window': '1759–1800'}

## 资料来源与实际阅读层级

- [BS213](https://www.cambridge.org/core/journals/journal-of-the-royal-asiatic-society/article/abs/british-monopoly-on-the-surat-trade-to-the-middle-east-and-the-indian-shipowning-merchants-struggle-against-it-17591800/ED95E21E566D5BD586BC830431D79449) The British Monopoly on Surat Trade to the Middle East and Indian shipowners struggle 1759–1800；机构：Cambridge / Journal of Royal Asiatic Society；阅读级别：`journal_html_abstract_and_notes_read`；原始手稿亲阅：否；档案编号：无。
- [BS214](https://www.cambridge.org/core/journals/modern-asian-studies/article/abs/mughal-nobles-indian-merchants-and-the-beginning-of-british-conquest-in-western-india-the-case-of-surat-17561759/AAA9C1720689652875326A6380922029) Mughal Nobles, Indian Merchants and Beginning of British Conquest: Surat 1756–59；机构：Cambridge / Modern Asian Studies；阅读级别：`journal_abstract_read`；原始手稿亲阅：否；档案编号：无。
- [BS215](https://searcharchives.bl.uk/?f%5Bcollection_area_ssi%5D%5B%5D=India+Office+Records+and+Private+Papers&f%5Bmaterial_type_si%5D%5B%5D=Archives+and+Manuscripts&f%5Bproject_collections_ssim%5D%5B%5D=India+Office+Records&f%5Burl_non_blank_si%5D%5B%5D=Yes+%28available%29&page=10&per_page=100&sort=date) Factory records Surat: revenue report of 5 November 1759；机构：British Library / India Office；阅读级别：`archive_catalogue_read`；原始手稿亲阅：否；档案编号：IOR/G/36/119。

## 尚待攻克

Surat Castle和Tanka的同期财税实数及商人向公司的诉状。

## 地图纪律

所有地点均为具名文本参考，尚未匹配正式权威参考坐标；该专题不可自动生成实控Polygon、军事行动缓冲圆面积、历史海运精确路线或现代行政区。
