# AB-NEW-018｜1775—1781年贝拿勒斯Chait Singh与东印度公司财政索取及反抗

**范围与状态：1700—1799研究候审，未发表；保留原37母题ID不变。**

**对应母题：** `E18-B17`。**单立理由：**1775权力转接、1776 zamindari sanad、1778后新增征兵税索、1781王公反抗，超出泛称公司战争；查原约、贡赋与当地行动。

## 一、背景与权力性质

贝拿勒斯的案例不能用“英国征服城市”概括。1775年阿瓦德与公司间权利调整后，公司就Chait Singh所掌Benares与Ghazipur的zamindari地租／年款取得直接协商地位。1776年4月15日的sanad明确作为一份独立文书存在，具体地权、司法、军事征调义务须逐条读全文，不可由签约这一个动作推断所有村社已经进入英属直辖。

## 二、具体过程与收益链

Fisher编辑的十八世纪士兵旅行叙事提供了Hastings追加战时征索、1781年拘捕Chait Singh失败、军队撤往Chunar及其后地方继任政治重组的完整链条。记载的原定约2,340,249卢比年款、其后4,000,000卢比要求应分别登记为不同年度与法律口径，不能算作既已征收的现金；“额外要求”中征兵与现金亦不可以双算。1781年11月Bijigarh堡垒交降后约400万卢比的现银、首饰等属于缴获财物估计，与军官的294,000卢比、22,478卢比、士兵50卢比分发口径存在包含关系，不能累加成公司总净收益。公司事后索回军奖显示战利品占有与归公司财产并非同一回事。

## 三、当地政治主体与证据冲突

Chait Singh的抵抗、地方军队的行动及继任Mahip Narain的zamindari关系须独立叙述。1782年村民对军官Baker私自索财的指控，学术编辑亦提到军官受到调查并获澄清；应在地图写成“地方投诉—召回调查”，而非刑责已经确认。

## 四、地图可执行限制

贝拿勒斯、Chunar、Bijigarh、Ghazipur、Kalpi是互不相同的事件和税收地点；无原地籍时只画具名点，不能把今日北方邦边界当英国1781年治地。

## 五、已有逐项事件（需主编审核）

## 六、经济数据引用（不重复加总）

当前尚无可核实的原币值或实收金额，本专题经济证据为空值，后续查账。

## 七、实际使用的来源与阅读深度

- **BS101 · British Library：** [IOR/H/633 Miscellaneous Treaties 1771-1784: Purandhar, Wadgaon, Salbai, Mangalore, Benares](https://searcharchives.bl.uk/catalog/040-000004727)；档案号 `IOR/H/633`；已读层级 `archive_catalogue_only`；纸质原始手稿未亲读。
- **BS107 · British Library：** [IOR/H/246 1781 correspondence: Benares rebellion, Nawab of Arcot debt](https://searcharchives.bl.uk/catalog/040-000004288)；档案号 `IOR/H/246`；已读层级 `archive_catalogue_only`；纸质原始手稿未亲读。
- **BS108 · University of California Press：** [Michael H Fisher, The Travels of Dean Mahomet (1997), Benares 1781 context](https://publishing.cdlib.org/ucpressebooks/public/book/the-travels-of-dean-mahomet-an-eighteenth-century-journey-through-india.html)；档案号 `无`；已读层级 `academic_edition_html_read`；纸质原始手稿未亲读。
- **BS118 · University of Nottingham Manuscripts：** [Portland PlC/4/26 Hastings report to directors on Benares 20 Mar 1783](https://mss-cat.nottingham.ac.uk/CALMVIEW/Record.aspx?id=PlC%2F4%2F26&src=CalmView.Catalog)；档案号 `PlC/4/26`；已读层级 `archive_catalogue_only`；纸质原始手稿未亲读。

## 八、下一轮原档优先查验

1. IOR/H/633 pp.47–56 的1776 zamindari sanad全文与1781 pp.73–90继任约文
2. 1781军队缴获原始估价册、军奖领取名单及Company追回账
3. Hastings—公司董事来信与Chait Singh、Mahip Narain的印度语契据

**制图审核声明：**任何已确认的现代坐标仅可作为历史事件的现代参考点，不可作为当年实控边界。条约、征税、战利品或人物获利不自动形成主权多边形。
