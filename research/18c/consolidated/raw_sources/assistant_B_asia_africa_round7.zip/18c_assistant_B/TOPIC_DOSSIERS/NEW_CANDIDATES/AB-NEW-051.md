# AB-NEW-051｜1793—1799年本地治里重占、政治清查及居民强制远航

- 编辑关系：`E18-B22`；候选独立议题，不改变原母题ID。
- 研究状态：`research_only`；原纸档、地理边界尚未审定。

## 可核时间序列
- **1748-08｜Boscawen率英舰在本地治里围攻法军失败**：英国国家陆军博物馆记1748年8月约30艘舰船和陆军围困法属本地治里约两个月终撤；死者“超过1000”系馆方历史概述，未查原军籍。 （来源：BS192；事件ID：`AB-F5-IN-006`）
- **1793-08-23｜英印军围攻后法属本地治里投降**：剑桥2025文献明载7月被围与8月23日投降；1990年代前的法国定居点自由度和英方占领持续性分别记录。 （来源：BS186；事件ID：`AB-F5-IN-007`）
- **1799-02-08｜英印军在本地治里拘捕52名平民并以囚船遣往英国**：剑桥学术文据法印殖民档记52名本地治里男子遭拘捕、上船，另载船上此前已有300名法军战俘；两个群体不可混为352名本地平民；未证各人的最终下落。 （来源：BS186；事件ID：`AB-F5-IN-008`）

## 权力与政治主体
23 Aug 1793落城、1799 Feb8 52名当地居民遭英印军拘捕与囚船遣送，是具体法权、监控及暴力事件
地图请保持Fante、当地王侯／法荷殖民地、印度各邦和其他非英国政治主体为独立对象；公司贸易许可证、官员礼金、税权、驻军、实际城堡占据及英国国王主权不得合并。

## 金额／数量／会计口径
- `FISC-F5-1799-Pondicherry-arrested`：52 persons_arrested。52 civilian men rounded up by East India Company troops 8 Feb 1799。限制：Detained persons, not entire city population or 300 French prisoners already on vessel
- `FISC-F5-1799-Pondicherry-POW`：300 persons_french_POW_aboard。Article describes 300 French POW already aboard ship before 52 residents arrived。限制：Distinct category, not additional 300 local civilian arrests

## 来源与阅读深度
- `BS186` The Politics of Colonial Lists: Conspiracies, Deportations, and Knowledge in 1790s Pondicherry：https://www.cambridge.org/core/journals/comparative-studies-in-society-and-history/article/politics-of-colonial-lists-conspiracies-deportations-and-knowledge-in-1790s-pondicherry/B25DED3C8D5AC160E3CB88C8F262B1BA；阅读级别：`peer_reviewed_academic_full_text_opened`；原始手稿本人亲阅：否。

## GIS与后续查核
- 无实测控制 Polygon；具名地点可待地名文献复核后画现代参考点，严禁凭堡垒地点涂整国或整省。
- 未核项：原卷连续性、当地政治主体史料、精确军占起止日、金额实际清算、历史边界。
