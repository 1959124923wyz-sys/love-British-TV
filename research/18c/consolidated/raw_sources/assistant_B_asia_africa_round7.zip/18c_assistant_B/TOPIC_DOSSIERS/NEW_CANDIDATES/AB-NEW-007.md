# AB-NEW-007｜1760—1765年Northern Circars对尼扎姆与公司的地权安排

- **原母题关联**：`E18-B02`
- **独立新专题必要性**：地方行政辖区和租税、军费协议需与1765 Diwani区别

## 可核参考

- [BS03 Armies of the East India Company](https://www.nam.ac.uk/explore/armies-east-india-company)；阅读等级：full_html_read。

## 待核原件与地图

进入新专题须主编决定新正式编号，补足原始公司日志、财政原卷、地方视角；现阶段既不自动上图，也不改变项目原专题ID。
