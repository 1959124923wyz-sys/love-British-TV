# AB-NEW-062｜1760—1799孟加拉Sannyasi、Fakir与Jungle Mahals地方反抗

> 研究阶段 research_only。此次新增候选，未经主编出版审核；不构造未经证实的控制面。

**原项目关联母题**：`E18-B16`

## 新增原因及主要发现

区分教团性行动、贫农抗租、地方酋长保地和殖民官称“Chuar”的群体；不存在可描满贝尔地区的统一英军占领面。

**受影响群体/利益**：Bengal/Bihar/Odisha土地与农户财政权、反抗者本地自主行动

## 有据史事 / 地图语义

### AB-R6-062-01｜1760s–1790s｜Sannyasi与Fakir团体反抗税权、土地剥夺和公司统治

- 地方与主体：North Bengal / Rajshahi / Bengal；Sannyasi; Fakir; peasants; EIC revenue officials
- 史实：1760年代至18世纪后期多处发生异质的宗教、农民及地方领导者反抗，不能虚构统一起义军和单一战线。
- 控制语义：`regional_resistance_multiple_groups`；不据此生成英国领土面积。
- 日期精度：`range_only`；日期补充：{'year_window': '1760s–1790s'}

### AB-R6-062-02｜1769｜Rajshahi地主地税核定与实际收款不一致

- 地方与主体：Rajshahi / Bengal；Rajshahi zamindari; tenants; EIC revenue officials
- 史实：1769–1770财政年核定2,601,000卢比、实际征得2,438,342卢比，来源为后世地方史研究，需向Firminger原表核查。
- 控制语义：`district_revenue_assessment_vs_receipts`；不据此生成英国领土面积。
- 日期精度：`financial_year`；日期补充：无

### AB-R6-062-03｜1770｜Rajshahi饥荒期地税核定高于实际收款

- 地方与主体：Rajshahi；Rajshahi zamindari; EIC tax collectors; Bengal residents
- 史实：1770–1771核定2,676,000卢比、实际征得2,146,247卢比；该数据仅属Rajshahi地区，勿与全孟加拉合计。
- 控制语义：`district_tax_after_crop_shock`；不据此生成英国领土面积。
- 日期精度：`financial_year`；日期补充：无

### AB-R6-062-04｜1799｜Midnapore Jungle Mahals地方武装发动大规模地权反抗

- 地方与主体：Jungle Mahals / Midnapore；Adivasi communities; sirdars; paiks; ryots; EIC officials
- 史实：史学论文叙述被收回jagir用地的Adivasi、paik与农民1799年反抗，殖民档习惯称Chuar rebellion；名称含殖民歧视性，不可当客观族称。
- 控制语义：`land_rights_resistance_not_unified_enemy`；不据此生成英国领土面积。
- 日期精度：`year`；日期补充：无

## 资料来源与实际阅读层级

- [BS218](https://journals.sagepub.com/doi/10.1177/03769836221105972) Revisiting the Early Anti-colonial Rebellions in Bengal and Odisha, 1760–1856；机构：SAGE / Indian Historical Review；阅读级别：`journal_abstract_read`；原始手稿亲阅：否；档案编号：无。
- [BS219](https://online.ucpress.edu/esr/article-abstract/36/1/127/34172/Tribal-led-People-s-Resistance-in-Transition-1765) Tribal-led Peoples Resistance in Transition 1765–1800；机构：University of California Press / Ethnic Studies Review；阅读级别：`journal_abstract_read`；原始手稿亲阅：否；档案编号：无。
- [BS230](https://rc.gov.bd/jss/fakir-sannyasi-movement-in-rajshahi-regional-study-of-a-pioneer-peasant-resistance-in-colonial-bengal/) Fakir-Sannyasi Movement in Rajshahi; revenue assessed and collected 1769–72；机构：Rajshahi College / Journal of Social Science；阅读级别：`secondary_research_full_html_read`；原始手稿亲阅：否；档案编号：Firminger and Mahmood cited indirectly。

## 尚待攻克

Sannyasi/Fakir每次袭击的同期日记、Rajshahi各年度税款原簿及Jungle Mahals地契。

## 地图纪律

所有地点均为具名文本参考，尚未匹配正式权威参考坐标；该专题不可自动生成实控Polygon、军事行动缓冲圆面积、历史海运精确路线或现代行政区。
