# AB-NEW-070｜1781—1782马德拉斯粮食危机、战争破坏与赈济

> research_only｜第六轮扩大地区调查，主编审批前不得视为已发布地图。

## 历史机制与受害、抵抗者

战争中迈索尔军破坏乡村粮食来源，公司在战事中防卫Madras并采取粮米交易干预；不能把全部平民死亡归因单个参与方。统计为UCL学位论文引用18世纪地方材料的摘要表，网页PDF截图因大小限制失败，已明确降低阅读级别。

## 候审事件

### AB-R6-070-01｜1781｜迈索尔战争期间马德拉斯周边出现严重食物短缺

- 1780–81战争摧毁粮食供给地区及乡村，殖民城市粮价恶化；居民损害须与战争各方行为分别归责。
- 地点：Madras / Carnatic；主体：Hyder Ali army; EIC Madras; local civilians
- 史料：[BS236](https://discovery.ucl.ac.uk/1444928/1/U592238.pdf)
- 地图：地点名可做文字，历史边界不可直接绘制；公司关税、地方割据与王室主权不能混同。

### AB-R6-070-02｜1782｜马德拉斯救济机构Monegar Choultry开始设立

- UCL历史表记1782年1月设救济设施、放宽粮食进口限制等；为后世学术表重引，原政府拨款凭证尚未读。
- 地点：Madras city；主体：Madras government; local poor and famine victims
- 史料：[BS236](https://discovery.ucl.ac.uk/1444928/1/U592238.pdf)
- 地图：地点名可做文字，历史边界不可直接绘制；公司关税、地方割据与王室主权不能混同。

### AB-R6-070-03｜1782｜马德拉斯官方采购孟加拉米并收到捐助报告

- UCL表记孟加拉欧洲居民筹送30,000卢比，购买孟加拉米；是否实际到库及账户分摊须查同时期来信与收据。
- 地点：Madras / Bengal；主体：Madras government; Bengal European residents; famine-affected households
- 史料：[BS236](https://discovery.ucl.ac.uk/1444928/1/U592238.pdf)
- 地图：地点名可做文字，历史边界不可直接绘制；公司关税、地方割据与王室主权不能混同。

## 文献阅读级别

- BS236 Famine, Disease, Medicine and State in Madras Presidency (1876-78), Historical Table 0.1 — https://discovery.ucl.ac.uk/1444928/1/U592238.pdf；阅读：pdf_text_extracted_screenshot_failed_large_file；18世纪原始手稿：未亲自查验。
- BS238 Map of the Carnatic marches 1781–1784 — https://militarymaps.rct.uk/other-18th/19th-century-conflicts/map-of-the-carnatic-1781-4-tamil-nadu-india；阅读：museum_map_catalogue_read；18世纪原始手稿：未亲自查验。

## 具体缺口

必须取得1782年Madras原始食品价格和Monegar Choultry账单及各月受灾死亡报告。
