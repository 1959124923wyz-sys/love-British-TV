# AB-NEW-068｜1789—1794印度南部Doji bara与北Circar饥荒、战争及征税

> 研究阶段 research_only。此次新增候选，未经主编出版审核；不构造未经证实的控制面。

**原项目关联母题**：`E18-B07`

## 新增原因及主要发现

1770 Bengal与1790年代Doji bara不同，不能直接比较规模或叠加死亡。需要区分气候干旱、粮价机制、运输成本及公司决策。

**受影响群体/利益**：Madras和Northern Circars农户、儿童、地方行政与种粮经济

## 有据史事 / 地图语义

### AB-R6-068-01｜1789–1794｜1789—1794印度多区域干旱与粮食危机

- 地方与主体：Northern Circars and south India；Indian cultivators; zamindars; EIC Madras officers
- 史实：1789—1794间不同地区遭遇多轮旱灾/饥荒，战争前置破坏与粮食征集、市场运输相互作用，不能制造全印度死亡总数。
- 控制语义：`multi_region_famine_no_surveyed_boundary`；不据此生成英国领土面积。
- 日期精度：`range_only`；日期补充：{'year_window': '1789–1794'}

### AB-R6-068-02｜1792｜北部Circars地方报告农民因饥饿食用未成熟庄稼

- 地方与主体：Northern Circars；local zamindars; labourers; EIC Madras Presidency
- 史实：当时的地方地主报告田间劳动力在成熟前食用作物，牲畜也被杀来充饥；资料是地方官和地主自述而非全区精确户数。
- 控制语义：`crop_failure_and_household_distress`；不据此生成英国领土面积。
- 日期精度：`year`；日期补充：无

### AB-R6-068-03｜1792｜Madras行政人员提出公共开支供养受灾儿童

- 地方与主体：Madras Presidency；Acting governor Oakeley; district officials; children
- 史实：担心父母售卖子女，Oakeley指示地方官员以公共资金供养儿童；资金拨付与执行仍待账目确认。
- 控制语义：`famine_child_relief_instruction_not_verified_payment`；不据此生成英国领土面积。
- 日期精度：`year`；日期补充：无

## 资料来源与实际阅读层级

- [BS229](https://academic.oup.com/book/61892/chapter/548192041) Naturalizing Famine: Doji bara Famine and Madras 1789–94；机构：Oxford University Press；阅读级别：`scholarly_chapter_excerpt_read`；原始手稿亲阅：否；档案编号：无。

## 尚待攻克

1790–94各地人口/粮价/地税/救助经费的同口径原档与战争损失。

## 地图纪律

所有地点均为具名文本参考，尚未匹配正式权威参考坐标；该专题不可自动生成实控Polygon、军事行动缓冲圆面积、历史海运精确路线或现代行政区。
