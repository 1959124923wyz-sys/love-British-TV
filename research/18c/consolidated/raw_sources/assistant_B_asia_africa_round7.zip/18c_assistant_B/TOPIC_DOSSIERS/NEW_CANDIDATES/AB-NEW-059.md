# AB-NEW-059｜1792—1794阿萨姆Ahom王国求援、公司军事干预与军事测绘

> 研究阶段 research_only。此次新增候选，未经主编出版审核；不构造未经证实的控制面。

**原项目关联母题**：`E18-B21`

## 新增原因及主要发现

剑桥书章摘录可读，原1792–1794书信/测绘未亲阅。Moamoria为本地政治主体；有王室请求不意味着所有地方团体同意英军干预。

**受影响群体/利益**：Ahom王廷、Moamoria反抗者、Guwahati居民、Bengal–Assam沿线贸易

## 有据史事 / 地图语义

### AB-R6-059-01｜1792｜Ahom王Gaurinath Singha请求公司镇压境内叛乱

- 地方与主体：Ahom Kingdom / Assam；Ahom king Gaurinath Singha; Moamoria rebels; EIC
- 史实：地方统治者面临Moamoria等反抗与武装集团冲突而请求英印军队援助，不能称英王征服阿萨姆。
- 控制语义：`indigenous_kingdom_alliance_not_annexation`；不据此生成英国领土面积。
- 日期精度：`year`；日期补充：无

### AB-R6-059-02｜1792｜Captain Welsh出兵阿萨姆、行动集中在Guwahati

- 地方与主体：Guwahati, Assam；Captain Thomas Welsh; EIC sepoys; Ahom court
- 史实：公司军队进入Ahom王国并参与恢复王权军事行动，局部部署不等于整个阿萨姆英公司行政领地。
- 控制语义：`temporary_military_intervention`；不据此生成英国领土面积。
- 日期精度：`year`；日期补充：无

### AB-R6-059-03｜1794｜公司以军政调查形式记录阿萨姆政权与地理

- 地方与主体：Assam / Guwahati；Captain Welsh; Ensign Wood; EIC Calcutta
- 史实：1794年的询问书与测绘记录要求解释国王、诸首领权力结构；文件用于未来商贸与军事情报。
- 控制语义：`colonial_intelligence_survey_not_sovereignty`；不据此生成英国领土面积。
- 日期精度：`year`；日期补充：无

## 资料来源与实际阅读层级

- [BS212](https://www.cambridge.org/core/books/abs/landscape-culture-and-belonging/geographical-exploration-and-historical-investigation-john-peter-wade-in-assam/FD71BBD7370CA6C116FBCE04A20ACACF) Geographical Exploration and Historical Investigation: John Peter Wade in Assam；机构：Cambridge University Press；阅读级别：`scholarly_chapter_summary_read`；原始手稿亲阅：否；档案编号：无。

## 尚待攻克

Captain Welsh原始日记及公司指令、临时营地地点和实际撤军日期；不把1794作为经证撤兵年。

## 地图纪律

所有地点均为具名文本参考，尚未匹配正式权威参考坐标；该专题不可自动生成实控Polygon、军事行动缓冲圆面积、历史海运精确路线或现代行政区。
