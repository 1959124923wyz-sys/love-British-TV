# AB-NEW-039｜1763—1792卡纳提克纳瓦卜债务、年贡、公司条件税收和战时接管

状态：`research_only` / `propose_to_editor`。原有E18-B/E系列ID保持不动。

**推荐与原项目交叉索引：** `E18-B18`。

## 问题与发现
公司军费条约与地方国库间的政治及财政控制；分清纳瓦卜继续在位和公司战时接管。

## 逐件证据事件
### AB-NEW-039-001｜1763｜阿尔科特纳瓦卜授公司卡纳提克七个Magsans
- 行动者：Nawab Muhammad Ali of Arcot; EIC；地点：Carnatic Payanghat；日期精度：day。
- 事实与权利：1909官方条约汇编存1763-10-16纳瓦卜给七个Magsans的Sanad与后续Chengalpet授地，实际核地不可套现代District。
- 法权分类：`jagir_grant_specific_districts_not_whole_carnatic`；可验证程度：`confirmed_in_cited_secondary_or_printed_edition`。
- 证据：[BS164](https://ignca.gov.in/Asi_data/14009.pdf)

### AB-NEW-039-002｜1765｜1765年卡纳提克授地有收入表、累计2201个村庄
- 行动者：Nawab of Arcot; Mughal emperor; EIC；地点：Carnatic / Chengalpet；日期精度：day。
- 事实与权利：汇编有关授地税册总计24区、2201 villages、4,42,881 pagodas 3½ annas plus 32,283 chucrams 0；为历史税额表，不可加作同一币种或实际拨款。
- 法权分类：`jagir_grant_revenue_schedule_not_cash`；可验证程度：`confirmed_in_cited_secondary_or_printed_edition`。
- 证据：[BS164](https://ignca.gov.in/Asi_data/14009.pdf)

### AB-NEW-039-003｜1781｜公司与阿尔科特纳瓦卜签五年卡纳提克税收移交安排
- 行动者：Nawab Muhammad Ali; Fort St George EIC Council；地点：Carnatic；日期精度：day。
- 事实与权利：1781-12-02条约约定公司管理Carnatic收益五年，纳瓦卜留1/6供私用；条约订立与逐区实际接管需分别核。
- 法权分类：`temporary_revenue_assignment_not_annexation`；可验证程度：`confirmed_in_cited_secondary_or_printed_edition`。
- 证据：[BS164](https://ignca.gov.in/Asi_data/14009.pdf)

### AB-NEW-039-004｜1785｜纳瓦卜债款偿付与每年多种Pagoda义务重新协商
- 行动者：Nawab Muhammad Ali; EIC Madras; private creditors；地点：Arcot/Carnatic；日期精度：year。
- 事实与权利：1785初步条款约定每年1200000 pagodas债务偿付与400000 current charges；两者不得与1787新条约各条叠算。
- 法权分类：`promised_debt_service_and_current_charges`；可验证程度：`confirmed_in_cited_secondary_or_printed_edition`。
- 证据：[BS164](https://ignca.gov.in/Asi_data/14009.pdf)

### AB-NEW-039-005｜1787｜纳瓦卜支付90万Pagodas军费及逾期接税权
- 行动者：Nawab Muhammad Ali; East India Company；地点：Arcot / Fort St George；日期精度：day。
- 事实与权利：1787-02-24条约订立，按Fasli周期1787-07-12起计90万Star Pagodas/年，逾期公司可在指定地区委收税；纳瓦卜仍保民事治理名义。
- 法权分类：`conditional_revenue_enforcement_and_military_subsidy`；可验证程度：`confirmed_in_cited_secondary_or_printed_edition`。
- 证据：[BS164](https://ignca.gov.in/Asi_data/14009.pdf)

### AB-NEW-039-006｜1792｜1792年卡纳提克纳瓦卜重新签军费附属条约
- 行动者：Nawab Muhammad Ali; East India Company；地点：Carnatic；日期精度：day。
- 事实与权利：1792-07-12条约年贡90万帕戈达，战时条件下公司取得财政管理权，纳瓦卜仍以其名义收贡；注意与1787文本相近但不可视为一份。
- 法权分类：`1792_revised_subsidiary_treaty`；可验证程度：`confirmed_in_cited_secondary_or_printed_edition`。
- 证据：[BS164](https://ignca.gov.in/Asi_data/14009.pdf)

## 经济或人口分项（若有）

- `FISC-1781-carnatic-private-retained-fraction`：1/6 revenue_fraction（1781 pact for five years）；1781 revenue assignment reserved one-sixth for Nawab private use。**口径：** 分配比例不是税收或净汇出金额；转化现款需当年已收税册。
- `FISC-1785-arcot-debt-service`：1200000 pagoda_18c_nominal（annually under preliminary 1785 arrangement）；preliminary 1785 annual proposed debt repayment to Company and private creditors。**口径：** 承诺偿债不等于实际偿付；1787新约重复规定不得叠加。
- `FISC-1785-arcot-current-charges`：400000 pagoda_18c_nominal（annually under preliminary 1785 arrangement）；preliminary annual current charges distinct from debt service。**口径：** 独立于债务偿付120万Pagodas；收入科目与后续1792修约不同。
- `FISC-1787-carnatic-peace-establishment`：900000 star_pagoda_18c_nominal（annual: 300000 Nov + 600000 Mar）；annual military peace establishment contribution commencing Fasli 1197 July 12。**口径：** 条约义务非实际收款，不推断主权转让。
- `FISC-1787-carnatic-kist-nov`：300000 star_pagoda_18c_nominal（November yearly）；November instalment subset of annual 900000 military contribution。**口径：** 年贡的子项，绝不可与900000加总。
- `FISC-1787-carnatic-kist-mar`：600000 star_pagoda_18c_nominal（March yearly）；March instalment subset of annual 900000 military contribution。**口径：** 年贡的子项，绝不可与900000加总。
- `FISC-1765-carnatic-jagir-pagodas`： pagoda_18c_schedule_partial（1763 and 1765 grants consolidated）；1763+1765 grant total schedule stated as 4,42,881 pagodas 3½ annas plus 32,283 chucrams 0; 24 historical mehers and 2,201 villages。**口径：** Mixed historical subunits; no conversion/aggregation; grant assessed revenue NOT confirmed collected cash.
- `FISC-1792-carnatic-military`：900000 pagoda_18c_nominal（annual, 1792 revised treaty）；annual Carnatic defence subsidy under revised treaty。**口径：** Same style as 1787 but treaty revision; alternative obligations not additive.
- `FISC-1792-carnatic-debt-charge`：621105 pagoda_18c_nominal（annual after 1792 agreement）；annual debt assignment following 1792 revised treaty according to govt narrative。**口径：** Not actual cash transfers; need period and payer split.

## 地图与下一步
所有本专题地理对象先作具名点或未定位参考；不得将地方胡椒贸易许可、宗主关系、陆军战场或现代省界填成公司实占多边形；有确切让地条文也必须先核逐村或历史岛岸边界。

**核查缺口**：需核条约的当地语言版本、年度实际税收和付款凭据、当事人答辩、原档页影及能够校准的历史地籍。
**档案声明**：18世纪物理原件未亲阅；1909编辑出版条约文字与馆藏目录保留不同阅读等级。
