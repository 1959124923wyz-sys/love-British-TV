# AB-NEW-077｜1757—1773年Mir Jafar转款、Clive私地收入与国会调查

> **research_only / 第七轮**；法定许可、组织实施、已知问题与个别越权必须分证据等级。

## 历史过程与机制：普拉西后公共赔款与私人财产分流

Mir Jafar转款的历史账本存在1757–1759公司收付记录、1757–60股东会议、1764 Clive jagir对账、1765–1770 Calcutta土地毛净入账表；英国图书馆都给出具体分册编号，但这轮未看到原卷表格数字。

## 归责与当地行动

不能把Clive个人jagir、海军战利品、军官礼物与公司利润简单相加。Mir Jafar既有政治盟约及政权压迫，也是独立作出决定的地方君主。

## 本轮新增时间线与证据

### AB-R7-POL-007｜1757｜1757年Mir Jafar条约相关账册开始登记公司收入与个人受赠

档案Mss Eur G37/4/1 ff.63–67保存1757–1759条约引致账目，区分公司赔偿、私人赠金与实际偿付尚需查历史原卷。

**涉事主体**：Mir Jafar；East India Company；Clive、海军和公司职员。**地点/行政层级**：Bengal, Murshidabad / Calcutta。**来源**：[BS262](https://searcharchives.bl.uk/catalog/041-000799999)。

**GIS限制**：不引入历史实控面，法规的通过地点与受影响的地区互不等同。

### AB-R7-POL-008｜{'start_year': 1757, 'end_year': 1760}｜1757—1760公司股东会议调查Mir Jafar向军官和公司官员付款

Mss Eur G37/11/2 ff.30–32保存公司股东会议的1757–1760会议摘录，记载对Mir Jafar付款的调查；具体每笔金额未从原账取得。

**涉事主体**：东印度公司General Court；Robert Clive；Mir Jafar。**地点/行政层级**：London / Bengal。**来源**：[BS259](https://searcharchives.bl.uk/catalog/041-000800570)。

**GIS限制**：不引入历史实控面，法规的通过地点与受影响的地区互不等同。

### AB-R7-POL-009｜1764｜1764年3月Clive个人jagir收据与公司账户存在专卷

Mss Eur G37/8/10 ff.1–2收录1763年12月至1764年2月jagir收款对账，时间为档案落款，不是每笔银款转账日。

**涉事主体**：Robert Clive；东印度公司。**地点/行政层级**：Bengal / London。**来源**：[BS263](https://searcharchives.bl.uk/catalog/041-000800345)。

**GIS限制**：不引入历史实控面，法规的通过地点与受影响的地区互不等同。

### AB-R7-POL-010｜{'start_year': 1765, 'end_year': 1770}｜1765—1770公司拥有1757年Mir Jafar转授加尔各答土地收入逐年统计

Mss Eur G37/82/6 f.48是1765–1770总收入与净收入表原件目录，金额暂留空，不能将地租等同公司从全孟加拉所得净利润。

**涉事主体**：东印度公司；Mir Jafar；Calcutta居民。**地点/行政层级**：Calcutta land grant area, Bengal。**来源**：[BS261](https://searcharchives.bl.uk/catalog/041-000808909)。

**GIS限制**：不引入历史实控面，法规的通过地点与受影响的地区互不等同。

## 经济/人口证据与原卷缺口

优先领取Mss Eur G37/4/1 ff63–67；G37/11/2 ff30–32；G37/82/6 f48；G37/8/10 ff1–2，核原始单位、实际支付、年份及是否重复。

### 来源阅读深度

| ID | 网址或档案 | 本轮实际阅读级别 |
|---|---|---|
| BS259 | [Clive Collection general court minutes 1757–1760, Mir Jafar grants](https://searcharchives.bl.uk/catalog/041-000800570) | archive_catalogue_read；原史料纸卷未亲读 |
| BS261 | [Clive Collection: Calcutta land gross/net revenues 1765–1770](https://searcharchives.bl.uk/catalog/041-000808909) | archive_catalogue_read；原史料纸卷未亲读 |
| BS262 | [Mir Jafar treaty Company receipts and accounts 1757–1759](https://searcharchives.bl.uk/catalog/041-000799999) | archive_catalogue_read；原史料纸卷未亲读 |
| BS263 | [Clive jagir receipts 1763–1764](https://searcharchives.bl.uk/catalog/041-000800345) | archive_catalogue_read；原史料纸卷未亲读 |

**候审地图**：全部无可靠历史边界，本篇事件仅作为时间轴、财政/政策关联和将来核实堡垒或城市参考点的研究素材。
