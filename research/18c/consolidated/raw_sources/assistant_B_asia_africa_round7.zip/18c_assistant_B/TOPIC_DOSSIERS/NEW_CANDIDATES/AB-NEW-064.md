# AB-NEW-064｜1767英国贩奴船长参与Old Calabar大屠杀与强制流放

> 研究阶段 research_only。此次新增候选，未经主编出版审核；不构造未经证实的控制面。

**原项目关联母题**：`E18-E10`

## 新增原因及主要发现

Old Town、Duke Town、Creek Town为不同地方势力；英国船长与一派结盟并未取得尼日利亚领土主权。历史估算300+是参与者/历史研究人数而非可定位现场的GPS，须保留确切死亡名单缺失。

**受影响群体/利益**：Old Town受害商人及家属，后被运往美洲的非洲自由人；Calabar政治结构

## 有据史事 / 地图语义

### AB-R6-064-01｜1767｜英国贩奴船长与Duke Town一方合谋伏击Old Town

- 地方与主体：Old Calabar / Calabar River, present-day Nigeria；British slave-ship captains; Duke Town and Creek Town allies; Old Town traders
- 史实：参与者以调解贸易冲突为名把Old Town商人诱至船上，并与对方地方派系配合发动攻击。
- 控制语义：`shipboard_coordinated_local_massacre`；不据此生成英国领土面积。
- 日期精度：`year`；日期补充：无

### AB-R6-064-02｜1767｜Old Calabar伏击造成300人以上遇害与被奴役

- 地方与主体：Old Calabar River；Old Town victims; British sailors; local allies
- 史实：牛津2024年学术章节记被杀逾300人，另有人被英船运往美洲沦为奴役者；不能把死亡估计与奴役人数混算。
- 控制语义：`lethal_violence_and_forced_atlantic_deportation`；不据此生成英国领土面积。
- 日期精度：`year`；日期补充：无

### AB-R6-064-03｜1767–1770s｜Old Calabar屠杀后地方政治冲突继续

- 地方与主体：Old Calabar；Old Town residents; Duke Town; British slavers
- 史实：剑桥研究记1767年伏击严重破坏当地商贸信任，双方冲突之后数年仍未立即终结。
- 控制语义：`long_term_conflict_no_British_land_annexation`；不据此生成英国领土面积。
- 日期精度：`range_only`；日期补充：{'year_window': '1767–1770s'}

## 资料来源与实际阅读层级

- [BS221](https://academic.oup.com/book/58166/chapter-abstract/485239549) Mutiny on the Black Prince Chapter 4: Old Calabar；机构：Oxford University Press / James H. Sweet；阅读级别：`book_chapter_abstract_read`；原始手稿亲阅：否；档案编号：无。
- [BS222](https://www.cambridge.org/core/journals/transactions-of-the-royal-historical-society/article/abs/cultures-of-exchange-atlantic-africa-in-the-era-of-the-slave-trade/CCB6F191757555706151856EC26C4287) Cultures of Exchange: Atlantic Africa in Era of Slave Trade；机构：Cambridge / Royal Historical Society；阅读级别：`journal_html_notes_read`；原始手稿亲阅：否；档案编号：无。

## 尚待攻克

1767涉案具体船名和船长、运输人口在Slave Voyages的个案交叉、1767同期原证词。

## 地图纪律

所有地点均为具名文本参考，尚未匹配正式权威参考坐标；该专题不可自动生成实控Polygon、军事行动缓冲圆面积、历史海运精确路线或现代行政区。
