# AB-NEW-081｜1770年饥荒、征税与公司军费：穆尔希达巴德通信档案

- **研究等级：** research_only，不得合并主线。
- **档案来源：** Exeter Famine and Dearth 转录1919年Bengal Secretariat Press历史出版的 *Letter Copy Books of the Murshidabad Durbar*，`BS268`。已直接阅读数字转录；没有声称亲阅18世纪手写原卷。
- **时间线：** 1770-04-24 Grose描述Rangpur无薪Pyke勒索50,000–80,000 Rs（其自述消息/估算）和粮食囤积；05-23 Harwood称Bhagalpur的Sujan Singh应纳30,000 Rs，只交2,500并要求退税维持部属；06-19 Grose报告Rangpur上年应征917,250 Rs、汇交632,797、其余284,453为费用扣减或拖欠；07-07 Grose报告10,000 Rs税款押Sepoys，另支付1,932 Rs欠薪；07-16 Harwood称Rajmahal严重缺粮；08-07 Grose记录暴雨、稻谷毁损，Rangpur 1卢比能购20 seer降为12，另地粗paddy为8–10 seer。
- **行政决策：** 同时可见税收监督、减少地方胥吏额外勒索和粮食市场干预请求，以及为维持军队支出确保收入的压力。不可将这写成公司各官员意见一致，亦不可由局部书信推导完整灾难死亡率。
- **地方政治：** Harwood提及山地Rajah Sujan Singh和当地首领、Rangpur监督员与Cooch Behar Rajah之间的粮米外运谈判。其税务、政治自主及粮食供应权须分别保存。
- **经济定义：** Rangpur应征总额不是收到金额；城中汇款不是汇往英国；欠薪军饷是费用；单位是18世纪卢比，不能按现代汇率换英镑。所有10条 `R7-LET-FISC-XX` 已分口径记录。
- **GIS：** 只记Rangpur、Bhagalpur、Rajmahal具名城市地理索引，现代定位点没有额外验证，坐标维持null，殖民控制边界保持null。
- **史料冲突：** 1770年官方自认贪腐/囤积问题，与1772年Purnea请愿有联系，但不是同一官员同一事件，应使用原文上下文及审理结果复核。

Source: https://famineanddearth.exeter.ac.uk/displayhtml.html?id=fp_00462_en_lettercopybooksofthemurshidabaddurbar
