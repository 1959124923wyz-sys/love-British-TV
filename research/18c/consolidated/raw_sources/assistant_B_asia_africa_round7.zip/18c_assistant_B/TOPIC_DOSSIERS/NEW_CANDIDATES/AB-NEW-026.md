# AB-NEW-026｜1709—1779年冈比亚詹姆斯堡毁弃与1783主权承诺脱节

**范围与状态：1700—1799研究候审，未发表；保留原37母题ID不变。**

**对应母题：** `E18-E10`。**单立理由：**国际法和约确认英国对已毁堡的声索，不等于堡垒实驻；UNESCO确认1779破坏后保持废墟。

## 一、背景与权力性质

James Island（今Kunta Kinteh Island）位于冈比亚河，18世纪英国公司堡垒与奴役人口装船网络须分离于英国声索的整条冈比亚河岸。联合国教科文组织明确称1779年法国军队造成该堡最后重大毁坏，此后遗址维持废墟状态。

## 二、具体过程与收益链

1783英法《凡尔赛和约》第10条保障英国在冈比亚河及Fort James的地位；法理声索在1779堡垒破坏之后发生，不能直接从和约文本推定已重建、长期驻军已恢复。地点官方UNESCO现代经纬度为13°19′3.51″N、16°21′40.87″W，只用作现代文化遗产坐标，不当历史城垣或控制面积。

## 三、当地政治主体与证据冲突

附近非洲贸易势力、河口社区与被掳被奴役者的遭遇必须保留；和约只由法国、英国政府缔结。

## 四、地图可执行限制

地图可用UNESCO参考Point，并按1779终止“有建筑存在”状态、1783另记法律权利候审点；不能从海岛现代面积统计英国实控。

## 五、已有逐项事件（需主编审核）

## 六、经济数据引用（不重复加总）

当前尚无可核实的原币值或实收金额，本专题经济证据为空值，后续查账。

## 七、实际使用的来源与阅读深度

- **BS123 · UNESCO World Heritage Centre：** [Kunta Kinteh Island and related sites UNESCO summary, James Fort destroyed by French in 1779](https://whc.unesco.org/en/list/761)；档案号 `无`；已读层级 `UNESCO_heritage_history_read`；纸质原始手稿未亲读。
- **BS124 · UNESCO World Heritage Centre：** [Kunta Kinteh Island UNESCO geolocation for James Island 761-001](https://whc.unesco.org/en/list/761/maps/)；档案号 `无`；已读层级 `UNESCO_official_modern_reference_coordinates_read`；纸质原始手稿未亲读。
- **BS128 · University of Perpignan digital legal history：** [French 1783 Treaty of Versailles full text articles 9-11](https://mjp.univ-perp.fr/traites/1783versailles.htm)；档案号 `无`；已读层级 `digitised_primary_treaty_transcription_read`；纸质原始手稿未亲读。

## 八、下一轮原档优先查验

1. 1779法军炮击/毁堡清单和是否留下守军
2. 1783之后英国是否再建堡、何年重新驻军的独立证据
3. 贸易公司、英政府和冈比亚地方政治的关系

**制图审核声明：**任何已确认的现代坐标仅可作为历史事件的现代参考点，不可作为当年实控边界。条约、征税、战利品或人物获利不自动形成主权多边形。
