# AB-NEW-073｜1769—1793年英国国家主导印度税收盈余汇款与贸易垄断续约

> **research_only / 第七轮**；法定许可、组织实施、已知问题与个别越权必须分证据等级。

## 历史过程与机制：政府指示印度财政盈余转移

1765年公司取得Diwani财政权以后，税入、国库借贷和公司的出口采购混合影响其贸易能力。经济史学者Cuenca-Esteban明确指出英国政府1769年传达促进印度财政余额输英政策、1793年Dundas继续维护公司在亚洲垄断；海贸商品也常经中国商品形式结算。

## 归责与当地行动

这种系统政策与公司股东私人礼物是不同的利润渠道：税收毛入、净余额、资本利得、汇票和英国净国际收支不能全部相加。

## 本轮新增时间线与证据

### AB-R7-POL-011｜1769｜1769年英国推动印度税收余额通过公司贸易输往英国

经济史研究确认1769年英国政策已明确鼓励将印度财政盈余通过公司贸易机制汇英；净额按年度另核，尚无授权海运路线坐标。

**涉事主体**：英国政府、东印度公司董事会及孟加拉财政治理人员。**地点/行政层级**：London / Bengal。**来源**：[BS231](https://www.sciencedirect.com/science/article/pii/S0014498305000859)。

**GIS限制**：不引入历史实控面，法规的通过地点与受影响的地区互不等同。

### AB-R7-POL-012｜1770｜1770年孟加拉饥荒中的公司继续征税与内部灾情通信

1769–1772公司内部往来讨论粮食短缺、死亡、粮价与税收，同时继续徴税；旱灾、市场、税制须并列解释。

**涉事主体**：东印度公司孟加拉理事会、地方税务官、村户与佃农。**地点/行政层级**：Birbhum / Bengal。**来源**：[BS24](https://academic.oup.com/book/61892/chapter/548190343)；[BS07](https://www.cambridge.org/core/books/abs/land-and-local-kingship-in-eighteenthcentury-bengal/famine-of-1770/932B785B5186FD79ADB4EC5FF5127F85)。

**GIS限制**：不引入历史实控面，法规的通过地点与受影响的地区互不等同。

### AB-R7-POL-014｜1771｜1771年公司董事收到饥荒期间粮食倒卖报告并要求追责

后世史学引1771年8月28日董事来信批评部分公司雇员利用gomastha囤积粮食、迫使农户售出种粮；显示知情和书面谴责，实际追责另核。

**涉事主体**：伦敦东印度公司董事；孟加拉驻地人员；被迫出售种粮的农民。**地点/行政层级**：London / Bengal。**来源**：[BS117](https://journals.sagepub.com/doi/10.1177/001946468602300403)。

**GIS限制**：不引入历史实控面，法规的通过地点与受影响的地区互不等同。

### AB-R7-POL-020｜1783｜1783年议会第九报告系统审查印度税收采购和贸易垄断

IOR/L/PARL/2/15/4目录收录盐、鸦片、丝绸、棉布、硝石和Bengal revenue investment调查及公司《规制法》缺陷。报告原文未逐页读。

**涉事主体**：英国议会Select Committee、东印度公司董事和驻印官员。**地点/行政层级**：Westminster, London。**来源**：[BS251](https://searcharchives.bl.uk/catalog/041-001116495)。

**GIS限制**：不引入历史实控面，法规的通过地点与受影响的地区互不等同。

### AB-R7-POL-032｜1793｜1793年英国议会续授权公司亚洲贸易垄断和印度政治管治

1793 Charter续行公司商业政治体系；学术研究将其视为维护印度财政盈余通过垄断贸易汇英的政策决策。

**涉事主体**：Henry Dundas、英国议会、Board of Control及东印度公司。**地点/行政层级**：Westminster / British India presidencies。**来源**：[BS231](https://www.sciencedirect.com/science/article/pii/S0014498305000859)；[BS255](https://www.parliament.uk/about/living-heritage/evolutionofparliament/legislativescrutiny/parliament-and-empire/parliament-and-the-american-colonies-before-1765/east-india-company-and-raj-1785-1858/)。

**GIS限制**：不引入历史实控面，法规的通过地点与受影响的地区互不等同。

## 经济/人口证据与原卷缺口

需查1769政府—董事指令原本、年度Company investment表、亚洲贸易账及伦敦汇票登记，核每期净余额与贸易利润/海军军费。

### 来源阅读深度

| ID | 网址或档案 | 本轮实际阅读级别 |
|---|---|---|
| BS01 | [Parliament and the East India Company](https://www.parliament.uk/about/living-heritage/evolutionofparliament/legislativescrutiny/parliament-and-empire/parliament-and-the-american-colonies-before-1765/parliament-and-the-east-india-company/) | full_html_read；原史料纸卷未亲读 |
| BS07 | [The famine of 1770, Land and Local Kingship in Eighteenth-Century Bengal](https://www.cambridge.org/core/books/abs/land-and-local-kingship-in-eighteenthcentury-bengal/famine-of-1770/932B785B5186FD79ADB4EC5FF5127F85) | book_chapter_summary_read；原史料纸卷未亲读 |
| BS117 | [Rajat Datta 1986 Merchants and peasants: late 18th century Bengal grain trade](https://journals.sagepub.com/doi/10.1177/001946468602300403) | peer_reviewed_article_preview_and_footnotes_read；原史料纸卷未亲读 |
| BS231 | [India Contribution to British Balance of Payments 1757–1812](https://www.sciencedirect.com/science/article/pii/S0014498305000859) | journal_article_excerpt_read；原史料纸卷未亲读 |
| BS24 | [Observing Famine (new study)](https://academic.oup.com/book/61892/chapter/548190343) | scholarly_chapter_excerpt_read；原史料纸卷未亲读 |
| BS251 | [IOR/L/PARL/2/15/4 Ninth Report on Company law and Asian trade](https://searcharchives.bl.uk/catalog/041-001116495) | archive_catalogue_read；原史料纸卷未亲读 |
| BS255 | [East India Company and Raj 1785–1858: 1793 charter](https://www.parliament.uk/about/living-heritage/evolutionofparliament/legislativescrutiny/parliament-and-empire/parliament-and-the-american-colonies-before-1765/east-india-company-and-raj-1785-1858/) | institutional_html_read；原史料纸卷未亲读 |

**候审地图**：全部无可靠历史边界，本篇事件仅作为时间轴、财政/政策关联和将来核实堡垒或城市参考点的研究素材。
