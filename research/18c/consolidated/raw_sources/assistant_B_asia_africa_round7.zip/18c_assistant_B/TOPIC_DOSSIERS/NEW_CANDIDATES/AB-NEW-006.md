# AB-NEW-006｜1753—1770年代孟加拉纺织采购gomashta制度与织工反抗

- **原母题关联**：`E18-B19`
- **独立新专题必要性**：Om Prakash研究强调1753制度转向与1769年19个采购行政节点

## 可核参考

- [BS19 European Companies and Indian Textile Producers: Coercion and resistance (LSE working paper)](https://www.lse.ac.uk/Economic-History/Assets/Documents/Research/GEHN/GEHNConferences/conf5/PrakashGEHN5.pdf)；阅读等级：search_excerpt_only。

## 待核原件与地图

进入新专题须主编决定新正式编号，补足原始公司日志、财政原卷、地方视角；现阶段既不自动上图，也不改变项目原专题ID。
