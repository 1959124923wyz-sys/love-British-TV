# AB-NEW-057｜1781—1783阿瓦德王室女性土地与宫廷金库剥夺

> 研究阶段 research_only。此次新增候选，未经主编出版审核；不构造未经证实的控制面。

**原项目关联母题**：`E18-B18`

## 新增原因及主要发现

Cambridge 2022/2023 Modern Asian Studies全文基于波斯文当地材料及公司文书重新解释财库究竟属王室私人财产、纳瓦卜国库还是公司债务抵押。不能因为Hastings的指控便宣布Begams确证支持起义。

**受影响群体/利益**：阿瓦德王室女性及宫廷官员；征税债务与东印度公司对附属盟友的预算控制

## 有据史事 / 地图语义

### AB-R6-057-01｜1775｜阿瓦德Bahu Begam财产保证与公司承诺关系

- 地方与主体：Faizabad / Awadh；Bahu Begam; Asaf-ud-Daula; EIC
- 史实：1775年保证关系是后来公司强制干预时被争辩的权利基础；保证条款与王室内部继承需另读原件。
- 控制语义：`treaty_guarantee_disputed_not_territorial_rule`；不据此生成英国领土面积。
- 日期精度：`year`；日期补充：无

### AB-R6-057-02｜1781｜贝拿勒斯反抗后Hastings要求剥夺Begams世袭收入

- 地方与主体：Awadh / Faizabad；Warren Hastings; Asaf-ud-Daula; Bahu Begam; Sadr-un-Nissa Begam
- 史实：公司官员认为Begams支持反抗，要求阿瓦德纳瓦卜收回其jagir并取得争议财库，所称支持程度与涉事者说法有争议。
- 控制语义：`extraction_order_over_local_jagir_revenue`；不据此生成英国领土面积。
- 日期精度：`year`；日期补充：无

### AB-R6-057-03｜1782｜公司驻扎与纳瓦卜部队包围法扎巴德宫殿

- 地方与主体：Faizabad；EIC Resident; Asaf-ud-Daula; Bahu Begam
- 史实：1782年1月纳瓦卜征收人员进入Begam的jagir，公司驻扎部队协同包围宫殿，驻城一年以上。
- 控制语义：`military_pressure_not_royal_annexation`；不据此生成英国领土面积。
- 日期精度：`year`；日期补充：{'month': 1}

### AB-R6-057-04｜1782｜法扎巴德宫廷高级宦官被拘押并被迫交出资金

- 地方与主体：Faizabad；Awadh palace eunuch officials; EIC forces; Nawab
- 史实：有高级宦官遭拘押直至交出可观现金；需要逐笔查收款与最终入公司账，尚不把财物一概记为英国净受益。
- 控制语义：`detention_and_exaction_not_accounted_profit`；不据此生成英国领土面积。
- 日期精度：`year`；日期补充：无

## 资料来源与实际阅读层级

- [BS209](https://www.cambridge.org/core/journals/modern-asian-studies/article/it-all-comes-from-me-bahu-begam-and-the-making-of-the-awadh-nawabi-circa-17651815/D7AEE97EA7821335A01B32B82AAB3FB0) It all comes from me: Bahu Begam and making of the Awadh nawabi；机构：Cambridge University Press / Modern Asian Studies；阅读级别：`journal_full_html_read`；原始手稿亲阅：否；档案编号：无。
- [BS210](https://searcharchives.bl.uk/?f%5Bcollection_area_ssi%5D%5B%5D=India+Office+Records+and+Private+Papers&f%5Blanguage_ssim%5D%5B%5D=English&f%5Broot_ancestor_reference_ssi%5D%5B%5D=IOR%2FL%2FPARL&page=2&per_page=50&sort=date) Warren Hastings papers, Part I regarding Oudh Begams；机构：British Library / India Office；阅读级别：`archive_catalogue_read`；原始手稿亲阅：否；档案编号：IOR/L/PARL/2/347。

## 尚待攻克

IOR/L/PARL/2/347全文及当时收到款项单、所谓55 lakh数值须回账本；绝不可将强制支出自动等同汇英国。

## 地图纪律

所有地点均为具名文本参考，尚未匹配正式权威参考坐标；该专题不可自动生成实控Polygon、军事行动缓冲圆面积、历史海运精确路线或现代行政区。
