# AB-NEW-063｜1796—1800锡兰海岸税制和地方权威改变后的反抗

> 研究阶段 research_only。此次新增候选，未经主编出版审核；不构造未经证实的控制面。

**原项目关联母题**：`E18-E05`

## 新增原因及主要发现

论文挑战将不同抗议解释为一场单因椰园税起义的史叙。Kandyan Kingdom持续独立，海岸公司税政不是康提国王被吞并。

**受影响群体/利益**：海岸村落、头人阶层、征税承包人和抗争居民

## 有据史事 / 地图语义

### AB-R6-063-01｜1796｜公司统治锡兰荷属旧海岸地区后撤换地方官员

- 地方与主体：Ceylon maritime provinces；EIC Madras administration; mudaliyars; amildars; coastal villagers
- 史实：当地头人原有申诉中介地位被征税承包人或新官员削弱，村庄申诉途径受损，抗议不能全归一项椰园税。
- 控制语义：`local_governance_replacement`；不据此生成英国领土面积。
- 日期精度：`year`；日期补充：无

### AB-R6-063-02｜1797｜锡兰海岸多个地区发生反对新财政与行政的抗议

- 地方与主体：Sri Lankan maritime districts；Ceylonese coastal residents; EIC revenue contractors and troops
- 史实：1796–1800发生多次和平与暴力抗议，1797年为重要节点；地点须逐份请愿或军报核，不假定全岛联合起义。
- 控制语义：`revolts_against_company_revenue_system`；不据此生成英国领土面积。
- 日期精度：`year`；日期补充：{'year_window': '1796–1800'}

### AB-R6-063-03｜1796–1800｜锡兰英国军事反抗镇压与持续请愿

- 地方与主体：Maritime Ceylon；EIC soldiers; coastal villagers; local officials
- 史实：研究指出镇压手段有时严酷，但各地有不同动机和抗议形式；在1799年前不能虚构所有村落的具体战役。
- 控制语义：`repression_and_petitions_localized`；不据此生成英国领土面积。
- 日期精度：`range_only`；日期补充：{'year_window': '1796–1800'}

## 资料来源与实际阅读层级

- [BS220](https://www.tandfonline.com/doi/abs/10.1080/00856400903049465?needAccess=true) Many Little Revolts or One Rebellion? Ceylon maritime provinces 1796–1800；机构：Taylor & Francis / South Asia；阅读级别：`journal_abstract_read`；原始手稿亲阅：否；档案编号：无。

## 尚待攻克

逐县请愿编号/军报、1797–98岁入税款及康提界线档图。

## 地图纪律

所有地点均为具名文本参考，尚未匹配正式权威参考坐标；该专题不可自动生成实控Polygon、军事行动缓冲圆面积、历史海运精确路线或现代行政区。
