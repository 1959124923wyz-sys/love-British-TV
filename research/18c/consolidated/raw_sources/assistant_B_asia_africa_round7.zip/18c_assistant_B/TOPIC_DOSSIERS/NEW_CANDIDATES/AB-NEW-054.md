# AB-NEW-054｜1796年英军占领安汶、班达香料堡垒、缴获库存与军官奖金

**独立研究候选 `research_only`，未发表，非17世纪历史版图继承。**
原母题：`E18-E11`；不会修改项目原ID。

## 政治与经济机制
海军占据荷兰据点为短时战争军事占领；香料缴获和银钱仓库须区别公司净利、军官个人分配；当地社会政治与香料采集劳动另核

## 具体事件、证据与空间含义
- **1796-01-06 英国海军从马六甲出发准备夺取荷属摩鹿加香料岛**（`AB-F5-SE-001`）：Rainier舰队从马六甲出航；舰队航路不得据此画精确海上轨迹。；历史权力类别：naval_departure_not_land_control。来源：BS196, BS198。
- **1796-02-16 英国舰队抵达安汶岛近海**（`AB-F5-SE-002`）：海军史研究确认舰队16日抵港，实际占堡另记17日。；历史权力类别：expedition_arrival_not_occupation。来源：BS196, BS198。
- **1796-02-17 John Kennedy率英军进驻安汶荷兰堡垒，荷军未战投降**（`AB-F5-SE-003`）：海军史研究称17日无战斗进入堡垒；1869历史回顾笼统称三月初占有，具体时日须向IOR/H/441核对。；历史权力类别：named_dutch_fort_temporary_military_capture。来源：BS196, BS198。
- **1796-03-08 英军登陆班达群岛并遭荷属炮台抵抗**（`AB-F5-SE-004`）：舰队依战术船只掩护登陆，遭荷兰两座炮台抵抗；荷军打坏炮机撤退，同晚荷兰总督谈判投降。；历史权力类别：fought_landing_and_capitulation_not_wider_archipelago_sovereignty。来源：BS196, BS198。
- **1796-03-09 英军进入班达堡垒并驻留，不涵盖全部班达岛民地权**（`AB-F5-SE-005`）：英国海军纪事称3月9日Kennedy进入Fort Nassau，驻留部队以英印雇佣兵混编；当地生产和土地权未逐地核验。；历史权力类别：named_fort_garrison_takeover。来源：BS196, BS198。
- **1796-06-18 英国图书馆馆藏摩鹿加远征日记止于6月18日**（`AB-F5-SE-006`）：IOR/H/441日记范围截止6月18日；这是原档覆盖末日而非英军撤离日。；历史权力类别：archive_end_date_not_control_end。来源：BS196。

## 金钱、物资、人口分别入账（不可加总为英国净掠夺）
- `FISC-F5-Amboyna-cash-rd`：**81112 rijksdaalders_reported_dutch_treasury**。Historical naval summary reports 81,112 Dutch rijksdaalders found in Amboyna treasury。限制：Stock of Dutch cash seized, not British net revenue or proof UK remittance
- `FISC-F5-Amboyna-cannons`：**85 cannons_inventory_reported**。Amboyna fort reportedly held 85 cannon。限制：Not cash income or territorial area; reported garrison inventory
- `FISC-F5-Amboyna-cloves-lower`：**500000 pounds_weight_cloves_lower_bound**。Historical account describes more than half a million pounds weight cloves at Amboyna。限制：Conservative lower threshold, NOT exact 500000 lbs and not a net cash receipt
- `FISC-F5-Banda-cash-rd`：**66675 rijksdaalders_reported_dutch_treasury**。Historical naval summary reports 66,675 rijksdaalders in Banda treasury。限制：Captured stock, not realised net treasure
- `FISC-F5-Banda-nutmeg-lbs`：**84477 pounds_weight_nutmegs_reported**。Banda inventory reported 84,477 lb nutmegs in naval summary。限制：Original 1796 company inventory not seen; alternate online 84,777 must be checked against IOR/H/441; do not claim exact independently verified
- `FISC-F5-Banda-mace-lbs`：**19587 pounds_weight_mace_reported**。Banda inventory reported 19,587 lb mace。限制：Spice inventory mass not sterling sales proceeds
- `FISC-F5-Banda-cannons`：**310 cannons_approximate_reported**。Banda defenses described as over 310 cannon。限制：This is a lower threshold not exact 310
- `FISC-F5-Moluccas-prize-captain`：**15000 GBP_per_naval_captain_historical_retrospective**。1869 Cust and later naval historian claim £15,000 prize money each for five captains。限制：Per recipient estimate, NOT company profit nor five times independently cleared; original prize distribution register not inspected

## 真实控制转换（边界仍留空）
- `T073` 1796-02-17 Amboyna / Ambon named Dutch fort：VOC Dutch fort garrison → British naval forces occupy fort and warehouses；**temporary_military_capture_of_named_fort**。1869 retrospective imprecisely dates takeover early March; archive diary needed for exact day
- `T074` 1796-03-08 Banda / Fort Nassau：Dutch VOC fort garrison and spice stores → Dutch garrison capitulates following British attack；**short_war_capture_of_colonial_fort**。Fort not entire Banda sovereign archipelago
- `T075` 1796-03-09 Banda / Fort Nassau：Dutch fort has just surrendered → British mixed troop garrison installed；**actual_named_british_fort_garrison**。No local island-wide land jurisdiction verified

## 来源／阅读状态
- `BS196`｜British Library India Office Records｜IOR/H/441 expedition to the Molucca Islands, Walter Caulfield Lennon journal, 1795–1796｜https://searcharchives.bl.uk/catalog/040-000004502｜阅读：archive_catalogue_only｜档号：IOR/H/441；原始手稿亲阅：**否**。
- `BS197`｜British Library India Office Records｜IOR/G/21/10 Factory Records: Java, 1796 accounts Amboyna Banda Tidore｜https://searcharchives.bl.uk/catalog/040-000177056｜阅读：archive_catalogue_only｜档号：IOR/G/21/10；原始手稿亲阅：**否**。
- `BS198`｜Richard Hiscocks, naval historian｜The Capture of Colombo and the Molucca Islands – February–March 1796｜https://morethannelson.com/the-capture-of-colombo-and-the-molucca-islands-february-march-1796/｜阅读：historical_naval_research_full_html_read｜档号：无；原始手稿亲阅：**否**。
- `BS199`｜Sir Edward Cust, third edition (1869), digitised historical monograph｜Annals of the Wars of the Eighteenth Century, Volume V 1796–1799｜https://upload.wikimedia.org/wikipedia/commons/a/a1/1796_-_1799_%28IA_in.ernet.dli.2015.463034%29.pdf｜阅读：nineteenth_century_retrospective_indexed_pdf_text_read_screenshot_failed_file_32MB｜档号：无；原始手稿亲阅：**否**。

## 下一步核实与制图
- 从英国图书馆卷 `IOR/H/441` 与 `IOR/G/21/10` 校验1796年实际占堡日期、缴获库存和军官奖金；不得用现代群岛Polygon涂色。
- 无实测历史领土多边形，`area_sqkm=null`；暂不制造新的经纬度。
- 原国家、殖民公司、地方统治者或居民及抵抗者的关系分层绘制。

## 第五轮第三批：1796荷兰原档与英国公报互校（本地候审）
- 英国1796年报称2月16日安汶、3月8日班达“交付”；荷兰国家档案馆`1.10.59/407`明确班达驻地长F. van Boeckholz于**3月9日**投降，`408`有货物清单抄本；8/9日分阶段记录，未凭一天夺堡扩张全群岛。
- 报表`BS203`称查获安汶银库**81,112 rix dollars**与丁香**515,940磅**，班达银库约**66,675 rix dollars**、肉豆蔻**84,777磅**、肉豆蔻衣**19,587磅**；其中肉豆蔻比BS198二手史中的84,477多300磅。账本新增的是**同一批次的竞争读数/印本依据，不可相加**。
- `BS204`二手学术研究表明Hitu地方独立行动遭镇压，有囚禁与处决，经济上英国延续VOC丁香专卖。单独专题`AB-NEW-056`。
- `IOR/L/MIL/5/151`个人名册、`/156`安汶后续未领奖项、`/157`班达基金及未领奖项均为真实档案**目录**，尚未打开原卷，不把1826年的追索日期当1796年个人实际分配日。
- 剔除此前候审记录`AB-F5-SE-006`：远征日记目录以6月18日结束是**文献记载范围**，而非发生在岛上的独立殖民事件。该信息保留于原报告及来源目录。
