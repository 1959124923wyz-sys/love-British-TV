# AB-NEW-055｜1799年开普Graaff-Reinet镇压及Khoikhoi—Xhosa土地抵抗

**独立研究候选 `research_only`，未发表，非17世纪历史版图继承。**
原母题：`E18-E06`；不会修改项目原ID。

## 政治与经济机制
英国军队首先镇压布尔人地方反抗，随后与Khoikhoi和Xhosa及Gqunukwebe发生多方边境冲突；Zuurveld史界不能据此假装英国全部管治

## 具体事件、证据与空间含义
- **1799-01-?? 开普Graaff-Reinet布尔居民再次反抗殖民政府**（`AB-F5-ZA-001`）：1799年1月驻地布尔殖民者反抗英国第一占领时期政府；此与稍后Khoikhoi/Xhosa抵抗是不同群体的行动。；历史权力类别：settler_rebellion_against_colonial_government。来源：BS200, BS201。
- **1799-03-?? Vandeleur率英军镇压Graaff-Reinet布尔居民反抗**（`AB-F5-ZA-002`）：英军于1799年3月行动镇压布尔叛乱；英国财政和军数尚无原始核。；历史权力类别：crown_military_repression_of_frontier_burghers。来源：BS200, BS201。
- **1799-04-?? 开普Khoikhoi人与Xhosa人结盟反抗农庄及土地侵占**（`AB-F5-ZA-003`）：4月起Khoikhoi及Xhosa与殖民占地者冲突，分清各社区目的与阵营流动。；历史权力类别：indigenous_anti_dispossession_resistance。来源：BS200, BS201。
- **1799-07-?? 1799年东开普冲突扩大至Oudtshoorn一带**（`AB-F5-ZA-004`）：殖民历史年表称至1799年7月冲突蔓延到Oudtshoorn；地点只是区域达到的描述，不能直接绘制战线、点缓冲面。；历史权力类别：frontier_conflict_geographic_extent_uncertain。来源：BS200, BS201。
- **1799-??-?? Gqunukwebe武装在英军返回Algoa Bay途中阻击**（`AB-F5-ZA-005`）：南非史资料记载Gqunukwebe部族担心遭驱逐而袭击返程英军，未确认精确战地与日期。；历史权力类别：indigenous_resistance_to_expulsion。来源：BS200, BS201。
- **1799-??-?? 殖民当局在1799年谈判中允许Xhosa继续留在Zuurveld**（`AB-F5-ZA-006`）：当局畏惧Khoikhoi普遍起义，选择议和并让Xhosa留在Zuurveld；实际各社区管辖与地图边界需核对，非英军全面征服。；历史权力类别：negotiated_nonexpulsion_not_annexation。来源：BS200, BS201。

## 金钱、物资、人口分别入账（不可加总为英国净掠夺）
- 本轮并无可核财务原卷数据，不填造。

## 真实控制转换（边界仍留空）
- `T076` 1799-01 Graaff-Reinet Cape：First British Cape colonial administration → Revolt by Boer frontier townspeople；**contested_settler_local_government**。Town protest cannot be turned into geography of all Cape
- `T077` 1799-03 Graaff-Reinet Cape：Boer rebellion ongoing → British military suppression campaign by Vandeleur；**counter_insurgency_not_new_land_annexation**。Date month only, no claim of expanded sovereignty
- `T078` 1799-04 Zuurveld eastern Cape：Multiple Xhosa communities and settler farms contested → Khoikhoi and Xhosa resistance and renewed border war；**indigenous_land_and_labor_resistance**。No historic operational border traced; map only contested named study region with archival boundary if obtained
- `T079` 1799 Zuurveld eastern Cape：British demand expulsion contested by Xhosa armed communities → Some negotiated Xhosa retention of Zuurveld；**negotiated_withdrawal_nonexpulsion**。Xhosa communities’ precise territories require independent sources; 1801–1803 excluded from this dataset

## 来源／阅读状态
- `BS200`｜South African History Online｜Eastern Cape Wars of Dispossession 1779–1878｜https://sahistory.org.za/article/eastern-cape-wars-dispossession-1779-1878｜阅读：institutional_regional_history_full_html_read｜档号：无；原始手稿亲阅：**否**。
- `BS201`｜Denver Webb, Scientia Militaria (2014)｜The Third War of Dispossession and Resistance in the Cape of Good Hope Colony, 1799–1803｜https://scientiamilitaria.journals.ac.za/pub/article/view/1094｜阅读：peer_reviewed_abstract_full_read_pdf_not_read｜档号：doi:10.5787/42-2-1094；原始手稿亲阅：**否**。

## 下一步核实与制图
- 调取英国开普殖民军日记及Xhosa/Khoikhoi地方材料，校勘Gqunukwebe战场和谈判责任。
- 无实测历史领土多边形，`area_sqkm=null`；暂不制造新的经纬度。
- 原国家、殖民公司、地方统治者或居民及抵抗者的关系分层绘制。
