# AB-NEW-019｜1772—1799年孟加拉食盐专卖、盐工劳动与1788拍卖改革

**范围与状态：1700—1799研究候审，未发表；保留原37母题ID不变。**

**对应母题：** `E18-B18`。**单立理由：**原B18仅强调采购/出口货物，未充分覆盖1772生产专卖、盐工molungoes、1788拍卖以及地方商人存续。

## 一、背景与权力性质

1772年公司对孟加拉和比哈尔食盐生产的制度性控制是本世纪重要财政机制，具有粮食以外的独立商品税负与劳动关系。Sayako Kanda的研究将盐工（molungoes）、燃料市场、生产成本与环境变化纳入分析；销售侧专卖制度和沿海制盐的劳动实践是不同环节。

## 二、具体过程与收益链

1788年出现公司控制的盐品公开拍卖制度，Sayako Miki的研究明确地方批发商和孟加拉商人仍在销售网络中发挥作用。因此“东印度公司垄断盐”要写清是生产、批发分销还是拍卖定价，不可写成所有私人食盐交易停止。英国图书馆IOR/L/PARL/2/9a现为馆藏目录，可定位盐工待遇的议会文书条目，但尚无具体名册、盐价与工人日薪数据。

## 三、当地政治主体与证据冲突

印度盐工、地方经销商、地方富商和各地生产地权主体不是同一社会群体。盐业利润不能并入粮食贸易利润证明1770饥荒成因，1772改革也不能倒写到1769年。

## 四、地图可执行限制

仅在取得具体盐场、拍卖所、公司盐署和历史地名的原档证据后提出点图。不得拿整个孟加拉、比哈尔的现代行政轮廓作公司的食盐实控面积。

## 五、已有逐项事件（需主编审核）

## 六、经济数据引用（不重复加总）

当前尚无可核实的原币值或实收金额，本专题经济证据为空值，后续查账。

## 七、实际使用的来源与阅读深度

- **BS105 · British Library：** [IOR/L/PARL/2/9a Bengal Narrative: Rohilla, salt labour, 1764-1775 revenues](https://searcharchives.bl.uk/catalog/040-001116470)；档案号 `IOR/L/PARL/2/9a`；已读层级 `archive_catalogue_only`；纸质原始手稿未亲读。
- **BS112 · Cambridge University Press：** [Sayako Kanda 2010 Bengal salt makers, Company monopoly from 1772](https://www.cambridge.org/core/journals/international-review-of-social-history/article/environmental-changes-the-emergence-of-a-fuel-market-and-the-working-conditions-of-salt-makers-in-bengal-c-17801845/EFF95B979EA1BC59C12DAFD1E623FB58)；档案号 `无`；已读层级 `peer_reviewed_html_read`；纸质原始手稿未亲读。
- **BS113 · J-STAGE：** [Sayako Miki 2002 Bengal salt auction monopoly 1788-1836](https://www.jstage.jst.go.jp/article/sehs/68/2/68_KJ00004582558/_article/-char/en)；档案号 `无`；已读层级 `peer_reviewed_abstract_read`；纸质原始手稿未亲读。

## 八、下一轮原档优先查验

1. 1772公司设立盐业生产专卖的董事决议条款
2. 1788盐拍卖数量、成交价、投标人及费税分解
3. 具体molungee契约和燃料供应档案

**制图审核声明：**任何已确认的现代坐标仅可作为历史事件的现代参考点，不可作为当年实控边界。条约、征税、战利品或人物获利不自动形成主权多边形。

## 第六轮补充：1780年生产垄断与salt malangis劳动

1780年公司进一步直接掌握生产并禁止私人生产及进口，此为盐业生产制度转换，独立于1772初设独占与1788拍卖。研究：[BS237](https://www.cambridge.org/core/journals/international-review-of-social-history/article/environmental-changes-the-emergence-of-a-fuel-market-and-the-working-conditions-of-salt-makers-in-bengal-c-17801845/EFF95B979EA1BC59C12DAFD1E623FB58)。不要把19世纪英国Cheshire盐在印度的优势倒写至1780年。
