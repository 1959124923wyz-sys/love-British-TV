# AB-NEW-012｜1794年法军袭击Freetown及1799黑人移民土地反抗

- **原母题关联**：`E18-E09`
- **独立新专题必要性**：反殖民地租权争议与公司治理不宜只写慈善移民

## 可核参考

- [BS42 CO 270 Sierra Leone sessional papers 1792-1801](https://loyalist.lib.unb.ca/record/sessional-papers-sierra-leone-co-270-1792-1801)；阅读等级：archive_collection_description_read。

## 待核原件与地图

进入新专题须主编决定新正式编号，补足原始公司日志、财政原卷、地方视角；现阶段既不自动上图，也不改变项目原专题ID。
