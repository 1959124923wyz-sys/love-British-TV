# AB-NEW-028 | 北部Circars四种合法性层次 1759—1768

**研究级，未发表。** 日期：2026-11-08。

## 史料核查结果

1759-05-14 Salabat Jang与Francis Forde签署的文书只列Masulipatam/Nizampatam等地区及排斥法国军官；1765-08-12莫卧儿Shah Alam II又授北部Circars；1766-11-12 Nizam Ali Khan与John Calliaud签约，按辖区实际接管、公司供军情况条件性要求每年5+2+2=9 lakh卢比；1768-02-23 Madras三方条约再调整为前6年每年2 lakh、若Condavir接管增加缴款，1774年起有5或7 lakh两种可选条件。

1768约规定公司在Khammam/Warangal行动后撤，然而没有实际撤军日。各条都是权力变更线索，不可把现代Andhra Pradesh全染成公司领土。

## 原始来源与阅读级别

- [BS133](https://dl.tufts.edu/downloads/7s75dr260?filename=2r36v8583.pdf)。来源性质见`../../SOURCE_REGISTRY.json`；未读取博物馆/馆藏手稿原件。

## 地图交接

目前只有已证明的具名地点、地方税权和条约年份；精确行政边界和现场坐标未审核，一律不得生成实控Polygon或面积。史料可以研究虚线范围，但必须先具名点及有据示意方法。
