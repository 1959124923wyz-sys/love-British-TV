"""Third preservation checkpoint: primary Dutch records and 1796 printed dispatch; local only."""
from pathlib import Path
import csv,json,datetime
P=Path('/mnt/data/18c_assistant_B');W=P/'WORKING'
def jread(f):return json.loads((P/f).read_text(encoding='utf-8'))
def jsave(f,o):(P/f).write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def csvread(f):
 with (P/f).open(encoding='utf-8-sig',newline='') as h:
  r=csv.DictReader(h);return r.fieldnames,list(r)
def csvwrite(f,fieldnames,rows):
 with (P/f).open('w',encoding='utf-8-sig',newline='') as h:
  w=csv.DictWriter(h,fieldnames=fieldnames);w.writeheader();w.writerows(rows)
S=jread('SOURCE_REGISTRY.json');E=jread('EVENT_CANDIDATES.json');N=jread('NEW_CANDIDATES.json');fc,F=csvread('ECONOMIC_EVIDENCE.csv');tc,T=csvread('CONTROL_TRANSITIONS_B_E.csv');ec,EC=csvread('EVENT_CANDIDATES.csv')
before={'events':len(E['events']),'sources':len(S['sources']),'economic':len(F),'transitions':len(T),'new_candidates':len(N['candidates'])}
# Only documents independently opened in this research session; capture reading depth with historical nuance.
SNEW=[
 ('BS202','Nationaal Archief, Den Haag','Nederburgh archive inventory 1.10.59: Banda capitulation, transferred goods, supply negotiations, reports','https://www.nationaalarchief.nl/onderzoeken/archief/1.10.59/download/pdf','national_archive_finding_aid_full_text_and_page_70_screenshot_inspected_original_archive_boxes_unread','1.10.59 inv. 407,408,410,411,412','Inventory 407 explicitly Van Boeckholz surrender to English 9 Mar 1796; 408 copied goods inventory transferred to commander Pieter Rainier; 410 correspondence, 411 rice supply discussion, 412 Schoebert governance report. Catalogue scan read, document folios not read.'),
 ('BS203','Freemasons Magazine (Dec. 1796) reproducing 29 Nov London Gazette dispatch','Gazette Intelligence quoting Madras Government 22 June 1796 summary of Rear-Admiral Rainier dispatches 27 March and 18 April','https://masonicperiodicals.org/static/media/periodicals/119-FMM-1796-12-01-001-SINGLE.pdf','contemporary_1796_printed_periodical_digitised_text_lines_3543_3557_read_pdf_screenshot_failed','Dec 1796 Gazette Intelligence pp. 425+ (PDF indexed excerpt)','Dutch Amboyna delivered 16 Feb, Banda 8 Mar; cash Ambon 81,112 rix dollars, cloves 515,940 lb, Banda nutmegs 84,777 lb, mace 19,587 lb; Banda cash OCR appears 65,d75; cite 66,675 also backed by independent naval history. Dates differ from English entered forts 17 Feb/9 Mar. EIC profit not documented.'),
 ('BS204','P.J.M. Noldus, University of Canterbury, MA thesis 1984','The Pattimura Revolt of 1817: Its Causes, Course and Consequences, Chapter II British Interregnums','https://ir.canterbury.ac.nz/bitstream/10092/7184/1/noldus_thesis.pdf','academic_thesis_text_and_scanned_pdf_pages_42_43_read_not_18c_archive_original','University of Canterbury historical thesis 1984 pp.34-36','For 1796 Ambon: Dutch and British looting, indigenous soldiers deserted with weapons, Dutch offices and local rajas/pattis/orang kayas continued, British retained VOC clove monopoly with increased prices; Hituese declared independence and marched on town, suppressed, some jailed and executed. Their Sultan of Ternate allegiance must be retained.'),
 ('BS205','British Library, India Office Records','Prize and Batta Rolls: Ceylon, Amboyna and Banda 1795–1796 — nominal rolls','https://searcharchives.bl.uk/catalog/040-000306957','archive_catalogue_only_original_rolls_not_read','IOR/L/MIL/5/151','Nominal rolls for Trincomalee Jaffnapatam Mannar 1795 and Colombo Amboyna Banda 1796; catalogue dated c.1829; do not date roll itself to 1796 composition.'),
 ('BS206','British Library, India Office Records','Prize and Batta Rolls: Ceylon, Amboyna and Banda — unpaid Amboyna shares','https://searcharchives.bl.uk/catalog/040-000306962','archive_catalogue_only_original_rolls_not_read','IOR/L/MIL/5/156','Abstracts of claims to unpaid shares for Amboyna SECOND distribution, referencing Madras GO no.81 of 1826. Not evidence exact sums were paid in 1796.'),
 ('BS207','British Library, India Office Records','Prize and Batta Rolls — Banda Neira Fund and unpaid shares','https://searcharchives.bl.uk/catalog/040-000306963','archive_catalogue_only_original_rolls_not_read','IOR/L/MIL/5/157','Abstracts of Banda unpaid share claims and general statement Banda Neira Fund, linked Madras GO no.81 of 1826; do not misdate 1826 payments as original 1796 profits.'),
 ('BS208','Richard Hiscocks, More than Nelson (historical synthesis)','The Capture of Colombo and the Molucca Islands – February–March 1796','https://morethannelson.com/the-capture-of-colombo-and-the-molucca-islands-february-march-1796/','secondary_nav_hist_full_article_read','','Corroborates 66,675 rix dollars and printed inventories but says Banda nutmegs 84,477 lb vs 1796 printed periodical 84,777 lb; source conflict held and no blending.'),
]
for sid,inst,title,url,level,archive,note in SNEW:
 assert sid not in {s['id'] for s in S['sources']}
 S['sources'].append({'id':sid,'institution':inst,'title':title,'url':url,'reading_level':level,'archive_identifier':archive or None,'notes':note,'original_manuscript_personally_inspected':False,'consulted_on':'2026-11-08'})
S['source_count']=len(S['sources']);S['schema']='18c-assistant-B-source-v5.3'
byurl={s['id']:s['url'] for s in S['sources']}
# Historical event log quality pass: the end date of an archived diary is not itself an event.
drop='AB-F5-SE-006'
old=next((e for e in E['events'] if e['id']==drop),None)
assert old and old['political_effect']=='archive_end_date_not_control_end'
E['events']=[e for e in E['events'] if e['id']!=drop]
# Existing distinct 9 March occupation now explicitly supported by the Dutch archival record.
for e in E['events']:
 if e['id']=='AB-F5-SE-005':
  e['source_ids'].append('BS202');e['source_urls'].append(byurl['BS202']);e['action']+=' 荷兰国家档案馆1.10.59/407明确记录原驻地长F. van Boeckholz于1796-03-09向英方投降，而英国1796年公报记同一占领过程于3月8日交出；8日与9日属不同阶段、仍须据原卷区分。'
 if e['id']=='AB-F5-SE-003':
  e['source_ids'].extend(['BS203','BS204']);e['source_urls'].extend([byurl['BS203'],byurl['BS204']]);e['action']+=' 1796年英国公报称16日已交出，二手海军史称17日英军进驻；暂将交付与实际进驻分开。'
# Additional research topics, independent local agency
new='AB-NEW-056'
assert new not in {i['candidate_id'] for i in N['candidates']}
N['candidates'].append({'candidate_id':new,'title':'1796年安汶Hitu地方独立运动、特尔纳特王权认同与英军镇压','related_original_topic_id':'E18-E11','rationale':'英国1796年取得荷属堡垒后，Hituese地方领袖与特尔纳特苏丹政治认同形成抵抗；英军镇压、囚禁及处决。须保留Hitu地方政治，避免将VOC控制自动视为全岛英国主权。','source_ids':['BS204','BS202'],'decision':'propose_to_editor'})
NEW=[]
def evt(id,top,y,m,d,title,actors,loc,action,effect,sids,precision='year',confidence='scholarly_secondary_plus_archive_catalogue_not_original'):
 assert id not in {e['id'] for e in E['events']}
 ss=sids.split(';')
 e={'id':id,'topic_ids':top.split(';'),'year':y,'month':m,'day':d,'date_precision':precision,'title':title,'actors':actors,'location':loc,'action':action,'political_effect':effect,'source_ids':ss,'source_urls':[byurl[s] for s in ss],'research_status':'candidate_not_published','map_state':'not_yet_geocoded','geometry_id':None,'confidence':confidence,'historical_control_boundary_verified':False,'actual_British_control_area_sqkm':None}
 NEW.append(e)
evt('AB-F5-MO-001','E18-E11;AB-NEW-054',1796,3,9,'班达荷兰驻地长F. van Boeckholz的投降与物品交接','VOC gezaghebber F. van Boeckholz; Royal Navy officer Peter Rainier; British Indian troops','Banda Neira','荷兰国家档案馆1.10.59/407将投降日明确标为1796年3月9日，408为交接给Pieter Rainier的货物目录。英军称8日群岛投降、9日入堡；两记录可能对应不同过程而非两次独立征服。','documented_local_transfer_with_dated_catalogue_not_extra_annexation','BS202;BS203','day','dated_royal_navy_and_dutch_archive_catalogue')
evt('AB-F5-MO-002','E18-E11;AB-NEW-056',1796,None,None,'安汶Hitu政治领袖借东印度公司统治崩溃尝试恢复特尔纳特相关王权','Hituese Muslim leaders; Sultan of Ternate; British garrison','Hitu, Ambon','Noldus史学研究：Hitu社群仍承认特尔纳特苏丹为其Rajah；VOC统治崩溃后选立新王并谋求不受英方统治的政治独立。具体村寨政治界线不可根据现代安汶区划推定。','asserted_local_indigenous_autonomy_not_british_entitlement','BS204')
evt('AB-F5-MO-003','E18-E11;AB-NEW-056',1796,None,None,'Hitu抵抗者向安汶城推进，英军将其镇压','Hituese leaders and armed local inhabitants; British garrison','Hitu → Ambon town (sequence only)','Noldus研究记Hitu起事者进军安汶市镇，驻军获得预警并镇压；人数、路线、具体战场及月份未有可靠定位，不能画战斗圈和精确行军线。','armed_local_resistance_suppressed','BS204')
evt('AB-F5-MO-004','E18-E11;AB-NEW-056',1796,None,None,'英军囚禁Hitu新王及抵抗者，并处决部分参与者','Hituese new king and adherents; British occupation authorities','Ambon / Hitu','Noldus 1984 p.36记载一批抵抗者包括新王遭拘禁、部分人被处决；身份人数及行刑地点尚未从De Graaf 1977原著和英方军档核实，人数null。','colonial_repression_and_imprisonment','BS204')
evt('AB-F5-MO-005','E18-E11;AB-NEW-054',1796,None,None,'英军接管安汶后维持荷属丁香专卖制度并提高收购价','British governor and Company traders; Dutch VOC staff; local spice producers','Ambon clove districts','Noldus 1984 pp.34–35：许多原荷兰官员继续任职，英国占领当局保留丁香专卖制度并提高收购价格；金额和生产区域须查1796–1802税表。','economic_monopoly_institutional_continuity','BS204')
evt('AB-F5-MO-006','E18-E11;AB-NEW-054',1796,None,None,'安汶交接期间荷英士兵抢掠、当地雇佣兵携枪逃离','British troops; Dutch troops; Ambon local soldiers','Ambon fort vicinity','Noldus 1984 p.35：荷兰及英国部队短期抢掠私人与公产，英方随后制止；本地士兵携武器逃离，欧洲雇佣军多数宣誓效忠英方。不同军队行为不能一概指向全部安汶居民。','occupation_looting_and_local_military_noncompliance','BS204')
evt('AB-F5-MO-007','E18-E11;AB-NEW-054',1796,6,22,'马德拉斯官员报告摩鹿加查获现金和香料库存','Madras Governor and Council; Rear Admiral Peter Rainier','Madras / Fort St George','1796年6月22日印度马德拉斯官署来函经11月29日伦敦Gazette、12月期刊转载：2月/3月占岛时查获银元和丁香、肉豆蔻、肉豆蔻衣；记录的是库存和银库余额，不是商品已经售出或利润汇英。','contemporary_inventory_report_not_fiscal_transfer','BS203','day','contemporary_gazette_reprint_digitised_text_read')
evt('AB-F5-MO-008','E18-E11;AB-NEW-054',1796,None,None,'原荷属地方首领与行政人员部分向英国驻军宣誓、继续在原职位办公','British military commanders; local rajas/pattis/orang kayas; Dutch colonial officials','Ambon','Noldus 1984 p.35：多数地方raja、patti、orang kaya及荷兰官员在英军占领下继续任职，抵抗的Hitu势力不能被此概括淹没。','local_offices_continued_under_garrison_occupation','BS204')
evt('AB-F5-MO-009','E18-E11;AB-NEW-054',1796,None,None,'荷方制作班达交接货物清单作为英国缴获资产账的校对入口','VOC resident F. van Boeckholz; British commander Peter Rainier','Banda / Fort Nassau','荷兰国家档案馆1.10.59/408收藏交接货物目录抄本；具体物品数量原卷尚未阅读，事件记“编制/交接账目”而不自造其内容。','documented_inventory_on_local_capitulation','BS202')
for e in NEW:E['events'].append(e)
# Financial: same physical inventory with rival figures, separate records for variance; no double count.
FM=[]
def econ(id,topics,year,val,unit,definition,payer,recipient,period,sids,role,status,limit):
 x={'id':id,'topic_ids':topics,'year_start':str(year),'year_end':str(year),'value':str(val),'currency_or_unit':unit,'metric_definition':definition,'payer_or_affected':payer,'recipient_or_observer':recipient,'accounting_period':period,'source_ids':sids,'source_urls':';'.join(byurl[k] for k in sids.split(';')),'source_reading_level':'contemporary_periodical_digitised_text_or_research_or_catalogue;original_archival_receipt_not_seen','source_role':role,'verification_status':status,'was_primary_manuscript_personally_read':'False','actual_received_or_transferred_verified':'False','numerator_denominator':'','interpretation_limit':limit}
 assert id not in {r['id'] for r in F};FM.append(x)
econ('FISC-F5-1796-gazette-amboyna-cloves','E18-E11;AB-NEW-054',1796,515940,'pounds_weight_cloves','1796 London Gazette Madras dispatch reports cloves in seized Amboyna store','Dutch VOC stock under British seizure','British armed occupation','1796-02-16 reported surrender','BS203','contemporary_1796_official_dispatch_reprint','contemporary_report_inventory_not_sales','Same batch as previously recorded >500,000 pounds, NOT additional cloves; no valuation or EIC net profit documented')
econ('FISC-F5-1796-gazette-banda-nutmeg','E18-E11;AB-NEW-054',1796,84777,'pounds_weight_nutmegs','1796 printed London Gazette reports Banda nutmegs in store; secondary narrative claims 84,477','Dutch VOC stock under British seizure','British armed occupation','1796-03-08 reported surrender','BS203;BS208','contemporary_report_vs_secondary_differing_figures','numerical_conflict_84777_vs_84477_not_reconciled','Same historic captured store already counted as 84477 in FISC-F5-Banda-nutmeg-lbs; record is competing reading, NOT 169,254 pounds total or income')
econ('FISC-F5-1796-gazette-banda-mace','E18-E11;AB-NEW-054',1796,19587,'pounds_weight_mace','Contemporary official periodical reports Banda mace warehouse volume','Dutch VOC stock under British seizure','British armed occupation','1796-03-08 reported surrender','BS203','contemporary_report_duplicate_inventory','reported_captured_inventory_not_sales','Same Banda spice stock previously recorded, duplicated only to supply contemporaneous source; DO NOT sum')
econ('FISC-F5-1796-gazette-amboyna-rix','E18-E11;AB-NEW-054',1796,81112,'rix_dollars_cash_inventory','Madras dispatch reported seized Dutch treasury cash at Amboyna','VOC treasury','British military authorities','1796-02-16 reported surrender','BS203','contemporary_report_duplicate_inventory','reported_captured_treasury_not_EIC_net_profit','Repeat of same 81,112 rix dollars already in existing economics, alternative stronger source; not extra acquisition')
econ('FISC-F5-1796-banda-rix-source-confirm','E18-E11;AB-NEW-054',1796,66675,'rix_dollars_cash_inventory','Contemporary report OCR uncertain for Banda treasury; corroborated by historical naval study','VOC treasury','British military authorities','1796-03-08 reported surrender','BS203;BS198','contemporary_report_with_ocr_problem_secondary_corrob','cross_source_reading_needs_original_printed_page','Repeat of previously recorded 66,675, not a separate asset; no company net profit')
F.extend(FM)
# Register actual transfer and resistance relation without fabricated borders.
TN=[]
def trans(id,date,place,frm,to,actors,sem,src,eid,unc):
 TN.append({'id':id,'date':date,'place':place,'from_status':frm,'to_status':to,'actors':actors,'control_semantics':sem,'historical_boundary_verified':'false','area_sqkm':'','geometry_policy':'named_site_point_or_unmapped_only','source_ids':src,'related_event_id':eid,'uncertainty':unc})
trans('T080','1796-03-09','Banda Neira Fort Nassau','VOC Dutch garrison under resident Van Boeckholz','British military garrison with goods handover','VOC F. van Boeckholz; Rainier Royal Navy; Kennedy British Army','specific_fort_capitulation_vs_island_suzerainty','BS202;BS203','AB-F5-MO-001','1796 official Madras dispatch surrender 8 March, Dutch archive handover 9 March; fort footprint unknown, island sovereignty not established')
trans('T081','1796','Hitu (Ambon)','VOC commercial coercion over autonomous Hitu communities','Hitu local rulers attempted self-government independent of British','Hituese leaders; Sultan of Ternate; British garrison','local_sovereignty_contested','BS204','AB-F5-MO-002','Year only from scholarship, locality and precise boundaries unspecified; British did not acquire whole indigenous polity')
trans('T082','1796','Ambon town / Hitu','Hitu resistance movement mobilized','British garrison suppressed uprising and imprisoned new Hitu king','Hitu resistance; British troops','armed_resistance_and_repression_not_territorial_accretion','BS204','AB-F5-MO-004','Death and imprisonment numbers not known; avoid drawing fabricated battle area')
trans('T083','1796','Ambon spice markets','VOC clove monopoly','British military trade administration continued monopoly with higher buy price','VOC local agents; British commanders; local clove growers','economic_regime_continuity_not_direct_crown_annexation','BS204','AB-F5-MO-005','No evidence for coercion level in individual villages or verified monopsony price accounts')
T.extend(TN)
# Persist immediately, including regenerated CSV from JSON to prevent drift.
for e in E['events']:
 if e['id']==drop:raise AssertionError('removed non-event persists')
EC=[]
for e in E['events']:
 row={k:'' for k in ec}
 for k in ec:
  if k=='year_window':row[k]=e.get('year_window','')
  elif k in ('topic_ids','source_ids','source_urls'):row[k]=';'.join(e.get(k,[]))
  else:
   v=e.get(k,'');row[k]='' if v is None else str(v)
 EC.append(row)
jsave('SOURCE_REGISTRY.json',S);jsave('EVENT_CANDIDATES.json',E);jsave('NEW_CANDIDATES.json',N)
csvwrite('EVENT_CANDIDATES.csv',ec,EC);csvwrite('ECONOMIC_EVIDENCE.csv',fc,F);csvwrite('CONTROL_TRANSITIONS_B_E.csv',tc,T)
# Expert analytical dossier and first-hand archive vs latter scholarship evidence matrix.
report='''# AB-NEW-056｜1796年安汶Hitu地方反英独立运动（研究候审，未发表）

## 一、核心发现：VOC统治瓦解与Hitu政治回应
1796年，Peter Rainier舰队夺取荷兰殖民公司在Ambon的主要堡垒。当地穆斯林Hitu社会对荷兰公司统治本有不满，并保留以**特尔纳特苏丹**为其政治君主的认同。P. J. M. Noldus (1984, pp.34–36)描述，随着VOC军事权威退去，一些Hitu领袖试图自行恢复王权、摆脱英国驻军的控制。

英国在安汶城堡驻兵，不等于全岛居民同意割让主权。英国军事报告中所谓“dependencies delivered”是当时英国官员对荷兰殖民资产的描述，不能作为Hitu或特尔纳特土地归英国的地界证据。

## 二、时间线：史实与档案所给日期
- **1796-02-16**：1796年12月期刊转录的同年11月29日London Gazette称安汶及属地在16日交付；海军史描述舰队16日到港。
- **1796-02-17**：现代海军史描述Major John Kennedy在17日进入VOC安汶堡。16/17日是否分别表示投降、入堡，需查IOR/H/441原卷。
- **1796年（月日未确立）**：Hituese领袖视VOC垮台为自决契机，提出独立于英军，占据特尔纳特政治传统。`AB-F5-MO-002`。
- **1796年（月日未确立）**：Hitu队伍向Ambon镇推进，英军反击镇压；战线、兵力、损失未知。`AB-F5-MO-003`。
- **1796年（月日未确立）**：Hitu新王与部分参与者遭拘禁，另有人被处决。Noldus援引De Graaf 1977 p.198，具体人员和人数、被处决者身份尚需查原著与原始档案。`AB-F5-MO-004`。

## 三、军事控制与经济治理不宜混写
Noldus p.35称一些荷英军人曾短暂抢掠私人及公产，部分本地士兵带武器离营；多数Raja/Patti/Orang Kaya及荷兰基层官员继续在英国驻军下办事。**保留本地行政官职并非英国掌握全岛各社群的地权。** 英方继续经营VOC时期丁香专卖制度，但提高收购价，未有实额与地点清单；暂不把全部丁香贸易写作殖民净收益。

## 四、交叉史料与阅读深度
| 编号 | 来源 | 已核层级 | 可支持的断言 | 不能证明 |
|---|---|---|---|---|
| BS204 | P. J. M. Noldus, *The Pattimura Revolt of 1817*, MA thesis, Canterbury 1984, scanned pp.34–36 | 已阅读PDF图页42、43及可检索文本；二手历史学论文 | Hitu抗英行动、地方领导、拘禁及处决、香料专卖、原行政人员继续任职 | 精确年月、姓名总数、被毁村镇及实控边界 |
| BS203 | *Freemasons Magazine*, Dec 1796, London Gazette 29 Nov summary of Madras 22 June dispatch | 已读取期刊数字文本，远程PDF截图失败；1796同期报告转载 | 英方称16日交接及战利品库存 | 英军驻堡后每天实际控制及各地居民承认英方主权 |
| BS202 | Nationaal Archief 1.10.59, inv. 407/408/410/411/412 | 已阅读荷兰官方PDF目录图页70；未打开历史文书原卷 | 班达荷方具体交接人、9 March文字、货物及行政资料存在 | 原账单具体数量、1780–1800年度收入和Hitu村落土地 |

## 五、地图审查建议
现阶段仅按**已知具名参考地点**索引Ambon镇与Hitu地区（Hitu尚无核验点坐标，因此新事件坐标留空）。可以按有证顺序叙述Hitu→Ambon镇，但不应画未知的确切行军轨迹。不能把现代Ambon岛或北安汶区画成英国政治实控polygon；应分别标注VOC驻军设施接收、地方政权反抗、香料商业权利。`actual_British_control_area_sqkm=null`。

## 六、仍需取证
1. 核查De Graaf (1977) p.198与英方驻军1796年行军日志，对齐Hitu反抗具体月份、新王姓名、监禁和处决人数。
2. 核英国图书馆`IOR/H/441`、`IOR/G/21/10`1796年占领与公司经营原文件；核荷兰1.10.59第407–412号。
3. 缴获货物原始库存与实际公司拍卖收益必须分别核算，查Bl Prize Rolls `IOR/L/MIL/5/151–158`不等于读过个人领取回执。

**状态：research_only；未刊发；未经审核不可制作领土Polygon。**
'''
(P/'TOPIC_DOSSIERS/NEW_CANDIDATES/AB-NEW-056.md').write_text(report,encoding='utf-8')
append='''\n## 第五轮第三批：1796荷兰原档与英国公报互校（本地候审）
- 英国1796年报称2月16日安汶、3月8日班达“交付”；荷兰国家档案馆`1.10.59/407`明确班达驻地长F. van Boeckholz于**3月9日**投降，`408`有货物清单抄本；8/9日分阶段记录，未凭一天夺堡扩张全群岛。
- 报表`BS203`称查获安汶银库**81,112 rix dollars**与丁香**515,940磅**，班达银库约**66,675 rix dollars**、肉豆蔻**84,777磅**、肉豆蔻衣**19,587磅**；其中肉豆蔻比BS198二手史中的84,477多300磅。账本新增的是**同一批次的竞争读数/印本依据，不可相加**。
- `BS204`二手学术研究表明Hitu地方独立行动遭镇压，有囚禁与处决，经济上英国延续VOC丁香专卖。单独专题`AB-NEW-056`。
- `IOR/L/MIL/5/151`个人名册、`/156`安汶后续未领奖项、`/157`班达基金及未领奖项均为真实档案**目录**，尚未打开原卷，不把1826年的追索日期当1796年个人实际分配日。
- 剔除此前候审记录`AB-F5-SE-006`：远征日记目录以6月18日结束是**文献记载范围**，而非发生在岛上的独立殖民事件。该信息保留于原报告及来源目录。
'''
for filepath in [P/'TOPIC_DOSSIERS/E18-E11.md',P/'TOPIC_DOSSIERS/NEW_CANDIDATES/AB-NEW-054.md']:
 filepath.write_text(filepath.read_text(encoding='utf-8')+append,encoding='utf-8')
checks={'round':'fifth_batch3','date':'2026-11-08','before':before,'after':{'events':len(E['events']),'sources':len(S['sources']),'economic':len(F),'transitions':len(T),'new_candidates':len(N['candidates'])},'new_event_ids':[x['id'] for x in NEW],'removed_non_event':drop,'new_source_ids':[x[0] for x in SNEW],'new_fiscal_ids':[x['id'] for x in FM],'new_transitions':[x['id'] for x in TN],'source_limit':'British and Dutch source text/catalogue not original archive manuscripts; 1796 newspaper scan image inaccessible but indexed text read; 1796 clove/nutmeg quantities duplicated as alternative source NOT addable.'}
(W/'FIFTH_ROUND_BATCH3_CHECKPOINT.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(checks,ensure_ascii=False,indent=2))
