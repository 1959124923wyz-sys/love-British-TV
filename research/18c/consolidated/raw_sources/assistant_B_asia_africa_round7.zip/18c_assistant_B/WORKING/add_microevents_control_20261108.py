import pathlib,json,csv
p=pathlib.Path('/mnt/data/18c_assistant_B')
e=json.loads((p/'EVENT_CANDIDATES.json').read_text());src={s['id']:s['url'] for s in json.loads((p/'SOURCE_REGISTRY.json').read_text())['sources']}
def add(id,topics,year,mon,day,title,who,loc,action,effect,srcids,confidence='academic_source_body_read'):
 if any(x['id']==id for x in e['events']):return
 for r in srcids:assert r in src,r
 e['events'].append({'id':id,'topic_ids':topics,'year':year,'month':mon,'day':day,'date_precision':'day' if day else 'month' if mon else 'year','title':title,'actors':who,'location':loc,'action':action,'political_effect':effect,'source_ids':srcids,'source_urls':[src[z] for z in srcids],'research_status':'candidate_not_published','map_state':'location_name_only_no_coordinates','geometry_id':None,'confidence':confidence,'historical_control_boundary_verified':False,'actual_British_control_area_sqkm':None})
add('AB-NEW-018-005',['E18-B17'],1781,11,None,'比吉加尔堡交降与军队分配查获财物','Chait Singh courtiers; Major Popham; Bengal Army sepoys','Bijigarh / Benares','比吉加尔于1781年11月交降；Fisher据军官记录称约400万卢比现款及珠宝被分配，后来公司要求缴回并提起军法与民事追索。','seized_treasure_prize_contested_company_claim',['BS108','BS104'])
add('AB-NEW-018-006',['E18-B17'],1782,7,None,'贝拿勒斯乡民指控公司军官胁迫村庄缴纳赎金','Benares regent and village residents; Capt. Godfrey Evan Baker; Hastings','Benares and surrounding villages','Fisher记原住民投诉Baker未经命令扣押村庄索要赎款，Hastings于1782年7月召回；指控真实性与最终调查结论需区分。','contested_extortion_allegation_and_disciplinary_recall',['BS108'])
add('AB-B11-007',['E18-B11'],1781,4,None,'东印度公司部队夺取卡尔皮并要求交出前马拉塔税赋','Colonel Morgan Bengal Army; Maratha garrison and local administrators','Kalpi, Yamuna','Fisher学术版叙述1781年4月公司驱逐卡尔皮马拉塔驻军，随后要求旧纳税机关把原交马拉塔税转付公司；住民的认可、实际征收数额均待核。','short_military_capture_followed_by_fiscal_claim',['BS108'])
add('AB-B22-003',['E18-B22'],1763,None,None,'1763巴黎和约规定法属印度沿岸商馆归还','France; British Crown; East India Company; Indian local rulers','Pondicherry, Karikal, Chandernagore and other named factories require case check','英法《巴黎和约》第十一条规定法国取回1749年初在印度的商馆（Coromandel、Orissa、Malabar、Bengal等）；具体各处实际驻军撤离和地方权力另核。','treaty_restore_french_factories_not_permanent_British_annexation',['BS129'])
for x in e['events']:
 if x['id']=='AB-NEW-018-003':x['action']+=' Fisher的Dean Mahomet版本补充地方军民反抗与军队征粮背景；具体伤亡和声称人数仍为历史文献估计。'
(p/'EVENT_CANDIDATES.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n')
p_csv=p/'EVENT_CANDIDATES.csv'
with p_csv.open(encoding='utf-8-sig',newline='') as f:fields=[x.lstrip('\ufeff') for x in csv.DictReader(f).fieldnames]
with p_csv.open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader()
 for x in e['events']:
  row={k:json.dumps(v,ensure_ascii=False) if isinstance(v,(dict,list)) else v for k,v in x.items()}
  w.writerow(row)
print('events',len(e['events']))
