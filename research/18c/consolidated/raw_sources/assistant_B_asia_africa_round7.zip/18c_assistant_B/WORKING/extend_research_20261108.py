#!/usr/bin/env python3
# Incremental extension; no GitHub mutation. Re-runnable without duplicates.
import json, csv, pathlib, datetime, copy
R=pathlib.Path('/mnt/data/18c_assistant_B')
S=R/'SOURCE_REGISTRY.json'; E=R/'EVENT_CANDIDATES.json'; N=R/'NEW_CANDIDATES.json'
s=json.loads(S.read_text()); e=json.loads(E.read_text()); n=json.loads(N.read_text())

def add_source(id, inst, title, url, level='archive_catalogue_only', note='', archive=None):
 if id in [x['id'] for x in s['sources']]:return
 if any(x['url']==url for x in s['sources']):
  raise ValueError('existing URL '+url)
 s['sources'].append({'id':id,'institution':inst,'title':title,'url':url,'reading_level':level,'archive_identifier':archive,'notes':note,'original_manuscript_personally_inspected':False,'consulted_on':'2026-11-08'})

def add_event(id, topics, date, title, actors, place, action, effect, src, confidence='verified_source_scope',year_window=None):
 if any(x['id']==id for x in e['events']):return
 assert all(any(a['id']==r for a in s['sources']) for r in src),src
 if date:
  y=int(date[:4]);m=int(date[5:7]) if len(date)>4 else None;d=int(date[8:10]) if len(date)>7 else None
  prec='day' if d else 'month' if m else 'year'
 else:
  y=m=d=None;prec='interval_pending'
 urls=[next(a['url'] for a in s['sources'] if a['id']==r) for r in src]
 item={'id':id,'topic_ids':topics,'year':y,'month':m,'day':d,'date_precision':prec,'title':title,
       'actors':actors,'location':place,'action':action,'political_effect':effect,
       'source_ids':src,'source_urls':urls,'research_status':'candidate_not_published',
       'map_state':'location_name_only_no_coordinates','geometry_id':None,'confidence':confidence,
       'historical_control_boundary_verified':False,'actual_British_control_area_sqkm':None}
 if year_window:item['year_window']=year_window
 e['events'].append(item)

def add_new(id,title,related,rationale,src):
 if any(x['candidate_id']==id for x in n['candidates']):return
 n['candidates'].append({'candidate_id':id,'title':title,'related_original_topic_id':related,
                       'rationale':rationale,'source_ids':src,'decision':'propose_to_editor'})

# New provenance: catalogue pages actually read, not physical records.
add_source('BS96','British Library','IOR/L/PARL/2/7/4 Fourth Report: Bengal/Behar revenues, salt, bills, allowances', 'https://searcharchives.bl.uk/catalog/041-001116386',archive='IOR/L/PARL/2/7/4', note='Directly inspected catalogue item scope only; first priority for R C Dutt fiscal total £2,000 discrepancy')
add_source('BS97','British Library','IOR/L/PARL/2/19/3 1784 Parliament and East India Company accounts, Bengal to China remittances','https://searcharchives.bl.uk/catalog/041-001116508',archive='IOR/L/PARL/2/19/3', note='Archive item inventory for accounts and investments; no sums extracted')
add_source('BS98','British Library','Mss Eur G37/9/6 Persian translations: Mir Jafar treaty, company sannads and rent grants','https://searcharchives.bl.uk/catalog/040-000800397',archive='Mss Eur G37/9/6',note='Contains translated 1757 agreement; grant of rights vs actual lands distinguish')
add_source('BS99','British Library','Clive jagir indenture copy, term extending by ten years','https://searcharchives.bl.uk/catalog/041-000800348',archive='Mss Eur G37/8/10 f.6',note='Catalogued c.1764 copy, original not seen')
add_source('BS100','National Library of Wales','Clive 1756-1759 general correspondence letterbooks CR1','https://archives.library.wales/index.php/letter-books-of-general-letters-to-europe-and-within-india?sf_culture=en',archive='CR1',note='11 volumes correspondence; archival description not manuscript examination')
add_source('BS101','British Library','IOR/H/633 Miscellaneous Treaties 1771-1784: Purandhar, Wadgaon, Salbai, Mangalore, Benares','https://searcharchives.bl.uk/catalog/040-000004727',archive='IOR/H/633',note='Page ranges and exact dates copied from archival metadata; documents not personally examined')
add_source('BS102','British Library','IOR/H/240 First Maratha War papers, 1775-82 Wadgaon report','https://searcharchives.bl.uk/catalog/040-000004282',archive='IOR/H/240',note='Archives catalogue only')
add_source('BS103','Government of Maharashtra','Bombay City District Gazetteer, British Period 1764-1819, Wadgaon and Salbai','https://gazetteers.maharashtra.gov.in/cultural.maharashtra.gov.in/english/gazetteer/Bombay%20City/volume_2/British%20Period_1764-1819.html',level='government_gazetteer_search_extract_read',note='Historical gazetteer, retrospective secondary. Some web loads timed out; claim checked via search text only')
add_source('BS104','British Library','IOR/H/83 Distribution of Prize-Money, bounty and booty 1756-1804','https://searcharchives.bl.uk/catalog/040-000004120',archive='IOR/H/83',note='Archival item-level scope, contains separate Buxar/Rohilla/Trincomalee/Malacca/Seringapatam claims, not actual proceeds totals')
add_source('BS105','British Library','IOR/L/PARL/2/9a Bengal Narrative: Rohilla, salt labour, 1764-1775 revenues','https://searcharchives.bl.uk/catalog/040-001116470',archive='IOR/L/PARL/2/9a',note='Includes complaints from salt workers (molungoes), bonded debts, Calcutta customs and river arrivals; catalogue only')
add_source('BS106','British Library','Rohilla prize money 1774, select parliamentary archives','https://searcharchives.bl.uk/catalog/041-001116424',archive='IOR/L/PARL/2/8/32',note='Title-level archival evidence only; no sum established')
add_source('BS107','British Library','IOR/H/246 1781 correspondence: Benares rebellion, Nawab of Arcot debt','https://searcharchives.bl.uk/catalog/040-000004288',archive='IOR/H/246',note='Archive catalogue and page synopsis, letters not personally read')
add_source('BS108','University of California Press','Michael H Fisher, The Travels of Dean Mahomet (1997), Benares 1781 context','https://publishing.cdlib.org/ucpressebooks/public/book/the-travels-of-dean-mahomet-an-eighteenth-century-journey-through-india.html',level='academic_edition_html_read',note='Edited 1794 autobiographical narrative and extensive scholarship; Rs 2,340,249 is promised annual tribute, not tax realized')
add_source('BS109','British Library','1792 Tipu-Mysore Treaty Persian and English copies and 1792 Jamabandi revenue statement','https://searcharchives.bl.uk/catalog/040-000564194',archive='IOR/L/PS/19/3',note='18 March 1792 definitive treaty; September 1792 attached ceded territory revenue register, not GIS-ready historical polygon')
add_source('BS110','National Army Museum','1792 Tipu hostages and 1794 return, NAM.1971-02-33-367-1','https://collection.nam.ac.uk/detail.php?acc=1971-02-33-367-1',level='museum_artifact_description_read',note='Princes returned in March 1794 on performance of promises; museum historical interpretation')
add_source('BS111','Cardiff University repository','Rachel Herrmann (2016) Sierra Leone Black Loyalist food laws and the 1800 riot','https://orca.cardiff.ac.uk/id/eprint/104088/',level='academic_paper_abstract_read',note='Event of 1800 outside user 1700–1799 scope; 1799 land/tax politics remain relevant; not auto-enter 1800 event')
add_source('BS112','Cambridge University Press','Sayako Kanda 2010 Bengal salt makers, Company monopoly from 1772','https://www.cambridge.org/core/journals/international-review-of-social-history/article/environmental-changes-the-emergence-of-a-fuel-market-and-the-working-conditions-of-salt-makers-in-bengal-c-17801845/EFF95B979EA1BC59C12DAFD1E623FB58',level='peer_reviewed_html_read',note='Dates salt production monopoly Bengal Bihar 1772; effects on malangis later, no blanket claim each village suffered equally')
add_source('BS113','J-STAGE','Sayako Miki 2002 Bengal salt auction monopoly 1788-1836','https://www.jstage.jst.go.jp/article/sehs/68/2/68_KJ00004582558/_article/-char/en',level='peer_reviewed_abstract_read',note='1788 auction and rise of local merchants; no inferred profit margin')
add_source('BS114','Snewpapers / Library of Congress linked digitization','National Gazette Philadelphia Sep 12 1792 reprints 22 Feb Tipu preliminary treaty','https://snewpapers.com/components/8105c512-3be2-4448-b5a3-0f6766c3cf52_evt_0',level='historic_newspaper_OCR_transcription_read',note='OCR of contemporary newspaper reprint (London Gazette based); says 3 crores 30 lakhs sicca rupees; needs comparison to original gazette and treaty; LoC image not manually inspected')
add_source('BS115','National Archives of India','EIC records descriptive list of secret correspondence 1778-1786','https://www.nationalarchives.nic.in/en/research-and-references/reference-tools',level='national_archive_research_guide_read',note='Finding aid only; supplies follow-up for Surat, Trincomalee, Nizam Guntur and Maratha, not a direct original transcript')
add_source('BS116','Elsevier / Asian Journal of Social Science','2026 study Colonial justice on trial: Maharaja Nandakumar, Warren Hastings and 1775 execution','https://www.sciencedirect.com/science/article/pii/S1568484926000298',level='peer_reviewed_abstract_read',note='Court jurisdiction and alleged retaliation disputed, source abstract only')
add_source('BS117','SAGE / Indian Economic and Social History Review','Rajat Datta 1986 Merchants and peasants: late 18th century Bengal grain trade','https://journals.sagepub.com/doi/10.1177/001946468602300403',level='peer_reviewed_article_preview_and_footnotes_read',note='Cites 1771-08-28 Court directors letter about some private agents seizing seed grain. Scholarly evidence rejects broad blanket claim company monopolised all grain.')
add_source('BS118','University of Nottingham Manuscripts','Portland PlC/4/26 Hastings report to directors on Benares 20 Mar 1783','https://mss-cat.nottingham.ac.uk/CALMVIEW/Record.aspx?id=PlC%2F4%2F26&src=CalmView.Catalog',archive='PlC/4/26',note='17 folios report self-justification. Catalogue synopsis only; not neutral outcome')
add_source('BS119','British Library','IOR/L/PARL/2/8 Warren Hastings Parliamentary files Burdwan, land farming and salt','https://searcharchives.bl.uk/catalog/040-001116392',archive='IOR/L/PARL/2/8',note='Group inventory; item subrefs should be read before quoting amounts')

# New candidates separate from original PR ids.
add_new('AB-NEW-018','1775—1781年贝拿勒斯Chait Singh与东印度公司财政索取及反抗','E18-B17','1775权力转接、1776 zamindari sanad、1778后新增征兵税索、1781王公反抗，超出泛称公司战争；查原约、贡赋与当地行动。',['BS101','BS107','BS108','BS118'])
add_new('AB-NEW-019','1772—1799年孟加拉食盐专卖、盐工劳动与1788拍卖改革','E18-B18','原B18仅强调采购/出口货物，未充分覆盖1772生产专卖、盐工molungoes、1788拍卖以及地方商人存续。',['BS105','BS112','BS113'])
add_new('AB-NEW-020','1756—1804年印度战争战利品和军官奖金分配账','E18-B18','不同战役与战争的赔款/战利品须从公司收入和个人受益账独立分开；IOR/H/83含多个地方案卷。',['BS104','BS106'])
add_new('AB-NEW-021','1773—1792年英印条约版本与莫卧儿/地方政治主权多层关系','E18-B17','相同事件的协定、未批准合同、条约转让、年款、实际治地有不同状态；建立原件目录逐条审。',['BS101','BS109'])
add_new('AB-NEW-022','1775年Nandakumar刑事审判与加尔各答英式法院法权冲突','E18-B09','1774设法院后1775发生争议性审判处决，应独立核档案中法律适用与政治影响，不预断谋杀阴谋。',['BS116','BS105'])
add_new('AB-NEW-023','1770年孟加拉粮价与种粮遭私人官员强取的区别研究','E18-B07','学界指出公司没有整体谷物贸易官方垄断，但个别官员/代理人被指私营囤粮并收购种子；验证具体县份和记录。',['BS117','BS24'])

# Tight dated treaty and legal transitions.
add_event('AB-B11-003',['E18-B11'],'1775-03-06','孟买东印度公司与Raghunath Rao订立《苏拉特条约》','Bombay Presidency; Raghunath Rao; Maratha rival court','Surat','公司以扶植Raghunath Rao争夺Peshwa地位获取贸易与土地利益的承诺；详细让地名单依据原约再核。','treaty_claim_not_executed_territory',['BS101','BS115'])
add_event('AB-B11-004',['E18-B11'],'1776-03-01','普兰达尔条约重新规定公司与马拉塔政治条件','Col. John Upton; Balaji Pandit; Pune Maratha government','Purandhar / Poona','公司特使与马拉塔方面签定新的政治协定；不能把上年各项索地立即视为实控。','treaty_revises_prior_claims',['BS101'])
add_event('AB-B11-005',['E18-B11'],'1779','瓦德冈被围后孟买公司军与马拉塔达成未获批准的协定','Bombay East India Company command; Mahadji Sindia and Maratha leaders','Wadgaon near Pune','公司军受挫后签《瓦德冈协定》，英国图书馆目录明确记孟买政府拒绝批准；区分战败与法定土地移转。','unratified_treaty_and_military_reverse',['BS101','BS102','BS103'])
add_event('AB-B11-006',['E18-B11'],'1782-06-06','David Anderson与Mahadji Sindia达成萨尔拜和约','David Anderson; Mahadji Sindia; East India Company; Maratha Confederacy','Salbai (historical treaty place unresolved)','英国图书馆IOR/H/633 pp.95-109注明1782年6月6日和平约文；1783年后续密函另见同卷，不能简单全境成为英属。','multi_polity_peace_terms',['BS101'])
add_event('AB-B13-004',['E18-B13'],'1784-03-11','英公司与Tipu Sultan签订芒格洛尔和约','Tipu Sultan; Anthony Sadleir; George Leonard Staunton; John Hudlestone','Mangalore (modern city reference unverified)','IOR/H/633 pp.139-146列1784年3月11日签署和约和三位公司签署者。','war_termination_not_company_annexation',['BS101'])
add_event('AB-B14-004',['E18-B14'],'1792-02-22','迈索尔与三方联军订立初步和平条款','Tipu Sultan; Cornwallis/EIC; Hyderabad Nizam; Maratha ally','Seringapatam','1792年报纸翻印的初步条款要求割让原控制地一半、支付3300万sicca卢比及交两名王子作履约人质，均是四方谈判承诺。','preliminary_treaty_multi_party_obligations',['BS114','BS109'],confidence='contemporary_newspaper_transcription_crossed_with_archival_final_treaty')
add_event('AB-B14-005',['E18-B14'],'1792-03-18','迈索尔和平正式约文与附地税登记','Tipu Sultan; EIC; Hyderabad Nizam; Maratha representatives','Seringapatam','BL IOR/L/PS/19/3存3月18日波斯文与英文条约，并有9月3日转发的割地税收登记jamabandi；未逐乡读取，不能编造分界。','treaty_final_vs_revenue_statement',['BS109'])
add_event('AB-B14-006',['E18-B14'],'1794-03','提普两名王子按已履行条款归还迈索尔','Tipu Sultan; princes Abdul Khaliq and Mohin-ud-din; Cornwallis administration','Seringapatam/Mysore','国家陆军博物馆记1794年3月两位人质返还；该年具体归还地址与日期仍需原档。','hostage_return_conditional_security_ended',['BS110'])
add_event('AB-B03-004',['E18-B03'],'1757','Mir Jafar赐予公司新贸易权敕令及军事同盟约文','Mir Jafar; Admiral Watson; Robert Clive; British East India Company','Murshidabad, Bengal','BL Mss Eur G37/9/6包含双方条约译本与贸易sannad；目录确认文件存在，不足以推定每个特权立即实施。','negotiated_trade_rights_not_all_Bengal_sovereignty',['BS98'])
add_event('AB-B03-005',['E18-B03'],'1764','Clive个人jagir收入续约证明与公司土地收益分离','Robert Clive; East India Company directors','24 Parganas, Bengal / London agreement','BL Mss Eur G37/8/10 f.6存约1764延长十年jagir条款副本；这是公司及个人独立收益权问题，实际付款凭据另核。','personal_jagir_distinct_from_company_tax',['BS99'])
add_event('AB-B07-006',['E18-B07'],'1771-08-28','公司董事谴责个别商人代理夺购农民留种谷物','East India Company Court of Directors; private servants and gomasthas; affected ryots','Bengal; districts still to identify','学者Datta引1771-08-28董事函称部分代理人收购或迫使农户出售来年留种粮；公司自身未建立覆盖全境的官方谷物贸易垄断。','reported_private_grain_abuse_not_official_general_grain_monopoly',['BS117'],confidence='scholarly_quotation_of_primary_letter_unchecked_original')
add_event('AB-B18-005',['E18-B18'],'1784','公司账册列出孟加拉向中国汇款、鸦片利润与伦敦财务','Company directors; British parliamentary committees; Bengal and China agents','Bengal, China, London (financial network only)','1784年议会调查汇编存在汇票、鸦片盈利、对华汇款、公司债券与军费分录；目录没有可直接引用的单项金额。','financial_records_not_verified_aggregate_transfer',['BS97'],confidence='archive_catalogue_subject_inventory_only')
add_event('AB-NEW-018-001',['E18-B17'],'1775','公司与阿瓦德协议后重订贝拿勒斯贡赋关系','Shuja-ud-daula family / Asaf-ud-daula; East India Company; Chait Singh','Benares (Varanasi)','IOR/H/633收1775年5月21日阿瓦德和约；贝拿勒斯权力义务需交叉解读1773和1776契据，而非全属地英国直接政府。','indirect_revenue_rights_and_zamindari',['BS101','BS108'])
add_event('AB-NEW-018-002',['E18-B17'],'1776-04-15','Chait Singh取得贝拿勒斯及Ghazipur zamindari敕令','Chait Singh; East India Company; local cultivators','Benares / Ghazipur','IOR/H/633 pp.47-56明记1776年4月15日签发的zamindari sanad；具体权利要原文核对。','local_zamindari_recognized',['BS101'])
add_event('AB-NEW-018-003',['E18-B17'],'1781-08','Hastings拘捕Chait Singh引发贝拿勒斯武装反抗','Warren Hastings; Raja Chait Singh and soldiers; Company sepoys','Benares / Chunar','公司在战时追加贡赋/兵役要求，Hastings命兵逮捕Chait Singh，引发冲突；Hastings撤退Chunar，后扶植新地方统治。双方损失需原卷。','coercive_revenue_demands_and_local_rebellion',['BS108','BS107','BS118'])
add_event('AB-NEW-018-004',['E18-B17'],'1781-09-14','贝拿勒斯继任者Mahip Narain在公司监督下承认欠赋','Raja Mahip Narain; EIC administration','Benares','英国图书馆IOR/H/633 pp.73-90编目继任者Pottah及1781年9月14日Cubbooleeat（接受文件），所涉未付款数额待查。','replacement_local_ruler_indirect_fiscal_rights',['BS101'])
add_event('AB-NEW-019-001',['E18-B18'],'1772','公司垄断孟加拉、比哈尔食盐生产','Bengal East India Company government; malangis salt workers; local merchants','Bengal and Bihar regional salt areas (not mapped)','专业史学研究认定1772年公司将孟加拉、比哈尔食盐生产纳入垄断安排；具体县区执行、劳动合同与销量需逐地核。','commodity_production_monopoly_not_full_land_sovereignty',['BS112'])
add_event('AB-NEW-019-002',['E18-B18'],'1788','东印度公司改革食盐销售实施公开拍卖','Company Bengal government; Calcutta bankers; local indigenous salt traders','Calcutta and Bengal salt trade network','经济史学论文指出1788年盐品销售拍卖，以提高售价和公司收益；本地批发及区域商人并未全退出。','salt_auction_reform_indigenous_merchant_agency',['BS113'])
add_event('AB-NEW-020-001',['E18-B10'],'1774','阿瓦德向东印度公司罗希拉远征军的赠款存在分配案卷','Shuja-ud-daula; Alexander Champion; Company officers and soldiers','Rohilkhand / Bengal','英国图书馆IOR/H/83 pp.133-233,311-348是军队赠款分配卷；此时金额空缺，不能将军官收到款等于公司净税收。','war_donation_individual_vs_company_accounting',['BS104','BS106'])
add_event('AB-NEW-020-002',['E18-E04'],'1795','马六甲攻取后的军官奖金争议存在海军事务档案','George Lord Keith; Colonel Archibald Brown; company troops','Malacca','英国图书馆IOR/H/83 pp.475-476存索赔马六甲奖金的申诉，战争缴获与实际受偿需分别核。','capture_prize_claim_not_actual_net_receipt',['BS104'])
add_event('AB-NEW-022-001',['E18-B09'],'1775','加尔各答最高法院判Nandakumar伪造罪并处决','Maharaja Nandakumar; Supreme Court at Fort William; Chief Justice Elijah Impey','Calcutta','1775年Nandakumar遭以英刑法伪造罪审判处死，法条适用及与此前指控Hastings腐败的关系长期有争议。','contested_colonial_criminal_jurisdiction',['BS116','BS105'],confidence='academic_abstract_not_trial_transcript')

# Enrich existing 1799 Sierra Leone record to avoid turning 1800 rioting into 1799.
for it in e['events']:
 if it['id']=='AB-E09-004':
  it['action']='1799年自由持地与quitrent、居民自治法权发生争议。2016年专业研究把通常所称的黑人效忠派骚乱/暴动定位在1800年；本条仅记1799紧张关系，不能提前算1799暴动。'
  it['source_ids']=list(dict.fromkeys(it['source_ids']+['BS111']))
  it['source_urls']=[next(z['url'] for z in s['sources'] if z['id']==q) for q in it['source_ids']]
  it['confidence']='1799_background_and_1800_distinction_verified'
 if it['id']=='AB-B14-003':
  it['month']=3;it['day']=18;it['date_precision']='day'
  it['action']='1792年3月18日Tipu Sultan与公司、海得拉巴尼扎姆、马拉塔盟友正式签署和约；9月3日随文传送割地税收登记。割地分配给多方，严禁全部视为英公司直接占领。'
  it['source_ids']=list(dict.fromkeys(it['source_ids']+['BS109']))
  it['source_urls']=[next(z['url'] for z in s['sources'] if z['id']==q) for q in it['source_ids']]
  it['confidence']='final_treaty_date_archive_catalogue'
 if it['id']=='AB-B11-002':
  it['month']=6;it['day']=6;it['date_precision']='day'
  it['source_ids']=list(dict.fromkeys(it['source_ids']+['BS101']))
  it['source_urls']=[next(z['url'] for z in s['sources'] if z['id']==q) for q in it['source_ids']]
  it['action']='IOR/H/633存1782年6月6日David Anderson和Mahadji Sindia的和平条约；涉及马拉塔与公司复杂的法权重组，详情需译读原条文。'
  it['confidence']='treaty_dated_from_archive_catalogue'

# Atomic checkpoints BEFORE any report prose or packaging.
for p,d in [(S,s),(E,e),(N,n)]:
 tmp=p.with_suffix(p.suffix+'.tmp'); tmp.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');tmp.replace(p)
print('saved checkpoint',len(s['sources']),len(e['events']),len(n['candidates']))
