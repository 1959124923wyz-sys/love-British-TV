"""Fifth-round independently sourced incremental dossier generation; NO GitHub calls."""
from pathlib import Path
import json,csv,datetime
P=Path('/mnt/data/18c_assistant_B'); W=P/'WORKING'; W.mkdir(exist_ok=True)
def rd(p): return json.loads((P/p).read_text(encoding='utf-8'))
def wr(p,x): (P/p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def csvrows(p):
 with (P/p).open(encoding='utf-8-sig',newline='') as f: r=csv.DictReader(f);return r.fieldnames,list(r)
def csvwrite(p,fields,rows):
 with (P/p).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
S=rd('SOURCE_REGISTRY.json'); E=rd('EVENT_CANDIDATES.json');N=rd('NEW_CANDIDATES.json')
f_fields,F=csvrows('ECONOMIC_EVIDENCE.csv');t_fields,T=csvrows('CONTROL_TRANSITIONS_B_E.csv')
old={'sources':len(S['sources']),'events':len(E['events']),'economic':len(F),'control':len(T),'new':len(N['candidates'])}
SNEW=[
 ('BS179','J. J. Crooks (1923; Routledge preview)','Records Relating to the Gold Coast Settlements from 1750 to 1874, pp.10–36; reproduces eighteenth-century committee minutes, statutes and engineer letters','https://api.pageplace.de/preview/DT0400.9781136960703_A23876854/preview-9781136960703_A23876854.pdf','historical_1923_compilation_extracts_read_pdf_screens_pages_10_23_24_36','23 Geo II c31;25 Geo II c40; 1753 John Apperley letter; 1770 Cape Coast court; 1782 preface; NOT archive manuscript; preview ends near 1762/1770'),
 ('BS180','Yale University MacMillan Center / Gilder Lehrman Center','Bunce Island History: RAC / Grant Oswald / Anderson succession and slave trade','https://macmillan.yale.edu/glc/bunce-island-history','academic_university_site_full_html_read','Bunce is a coastal slave-trading fort, not Sierra Leone colonial territorial sovereign control'),
 ('BS181','UK Parliament Historic Hansard','Petitions Against the Slave Trade Abolition Bill, 17 Feb 1807; Anderson owners recount Bance Island 1752 rights and claimed 1794 loss','https://api.parliament.uk/historic-hansard/commons/1807/feb/17/petitions-against-the-slave-trade','digitised_1807_primary_parliamentary_petition_transcription_read','£20,000-plus is 1807 petitioners assertion of 1794 damage, not independently audited realised loss'),
 ('BS182','Ty M. Reese / Journal of Imperial and Commonwealth History','Controlling the Company: Fante-British Relations on the Gold Coast 1750–1821','https://www.tandfonline.com/doi/full/10.1080/03086534.2013.762162','peer_reviewed_abstract_read_only','Abstract confirms Fante political agency and tenant-patron relation; paywalled body NOT read'),
 ('BS183','India Code / Government of India','Bengal Regulation I of 1793, Permanent Settlement (consolidated text with later adaptations)','https://www.indiacode.nic.in/bitstream/123456789/15514/1/the_bengal_permanent_settlement_regulation%2C_1793.pdf','government_law_pdf_indexed_text_read_screenshot_timeout','Original 22 March proclamation and 1 May enactment noted; consolidated footnotes are later amendments; scanned PDF page image unavailable'),
 ('BS184','India Code / Government of India','Bengal Regulation II of 1793, Land-Revenue: transfer Mal Adalat cases to Diwani Adalat','https://www.indiacode.nic.in/bitstream/123456789/15515/1/the_bengal_land_revenue_regulation%2C_1793.pdf','government_law_pdf_indexed_text_read_not_full_scan','Present consolidated version contains later edits; preamble dated 1 May 1793'),
 ('BS185','Indian Kanoon legislation archive','Bengal Land-Revenue Regulation II of 1793 text with later editorial amendments','https://indiankanoon.org/doc/117474657/','secondary_legislation_reproduction_full_html_read','Website states no original publication verified; corroborate law against India Code'),
 ('BS186','Cambridge University Press, Comparative Studies in Society and History (2025)','The Politics of Colonial Lists: Conspiracies, Deportations, and Knowledge in 1790s Pondicherry','https://www.cambridge.org/core/journals/comparative-studies-in-society-and-history/article/politics-of-colonial-lists-conspiracies-deportations-and-knowledge-in-1790s-pondicherry/B25DED3C8D5AC160E3CB88C8F262B1BA','peer_reviewed_academic_full_text_opened','1793 Aug23 capitulation; 1799 Feb8 roundup of 52 residents; 300 French POW already aboard'),
 ('BS187','Bombay High Court, 17 November 1980, Indian Kanoon','State of Maharashtra v Kusum C B Upadhye: historical 1726/1753 Mayors Courts charters','https://indiankanoon.org/doc/252279/','later_judicial_primary_judgment_recounting_18c_charters','24 Sep 1726 and 8 Jan 1753 for local courts, boundaries jurisdiction distinguished'),
 ('BS188','British Online Archives / National Library of Wales','Calcutta Mayor’s Court records and copies of 1753 charter; collection identifier 71859-6CSB-01','https://britishonlinearchives.com/collections/20/volumes/89/records-of-the-calcutta-mayors-court-c1765-1766','archive_catalogue_only','Court charter transcript NOT personally read; note 1766 minutes extant'),
 ('BS189','Brill academic book chapter','Life after the VOC: Cochin after the October 1795 takeover','https://brill.com/previewpdf/book/9789004190252/Bej.9789004168169.i-317_007.xml','publisher_book_chapter_pdf_extracted_text_read_screenshot_not_supported','British claimed Dutch privileges; physically inventoried warehouses, arms; Kochi Raja independent; research historic chapter, not original book originals'),
 ('BS190','British Library India Office Records','IOR/F/4/21/801: Questions concerning civil administration of Cochin and dependants, Nov 1795-Oct 1797','https://searcharchives.bl.uk/catalog/041-000736178','archive_catalogue_only','Named original case file; contents not inspected'),
 ('BS191','Francis Day (1863), digitised by Internet Archive','The Land of the Permauls, or Cochin: 19 October 1795 surrender terms reproduced','https://upload.wikimedia.org/wikipedia/commons/3/3f/The_Land_of_the_Permauls_or_Cochin%2C_Its_Past_and_Its_Present_%28IA_landofpermaulsor00fran%29.pdf','1863_compiled_historical_treaty_transcript_indexed_pdf_text','Colonial era historian; 19 Oct 1795 Van Spall/Petrie signed terms; original parchment not read'),
 ('BS192','UK National Army Museum','Levée du siège de Pondicherry August-October 1748 museum catalogue','https://collection.nam.ac.uk/detail.php?acc=1971-02-33-299-1','museum_catalogue_full_html_read','Unsuccessful British besiegement; museum says 30 ships and over 1000 dead—estimates contextual not confirmed casualty roll'),
 ('BS193','University of Florida doctoral thesis','Anomabo Fort William architecture and John Apperley fort building 1753','https://ufdcimages.uflib.ufl.edu/UF/E0/04/13/66/00001/micots_c.pdf','university_thesis_indexed_excerpt_read','University thesis corroborates contemporary Crooks letter; do not treat digitised thesis as original archival minutes'),
]
known={x['id'] for x in S['sources']};
for sid,inst,title,url,level,notes in SNEW:
 if sid in known: raise ValueError(f'duplicate source {sid}')
 S['sources'].append({'id':sid,'institution':inst,'title':title,'url':url,'reading_level':level,'archive_identifier': ('IOR/F/4/21/801' if sid=='BS190' else ('71859-6CSB-01' if sid=='BS188' else None)), 'notes':notes,'original_manuscript_personally_inspected':False,'consulted_on':'2026-11-08'})
S['source_count']=len(S['sources']);S['schema']='18c-assistant-B-source-v5'
SLOOKUP={s['id']:s['url'] for s in S['sources']}
NEW=[
 ('AB-NEW-047','1750—1755年阿诺马布堡扩建、被奴役劳动与Fante地方首领的土地谈判','E18-E10','1753工程师与Fante地方首领约束英方新堡尺寸；英国商堡受当地政治限制，并有被奴役者劳动和议会拨款','BS179;BS182;BS193'),
 ('AB-NEW-048','1728—1794年邦斯岛堡弃守、私人贩奴公司接手与战时袭击','E18-E09','1728 RAC弃守，1752议会在法中确认私人业主持有；1794损失数额见1807年业主利益请愿','BS179;BS180;BS181'),
 ('AB-NEW-049','1782年英国袭击荷属Elmina与五处西非堡垒','E18-E10','1782 Feb17–21 Elmina攻城失败、3月Shirley取五座荷属堡；据点短期军占不等于加纳领土吞并','BS179'),
 ('AB-NEW-050','1770年Komenda受奴役者审判与跨大西洋惩罚移送提议','E18-E10','英堡作为拘禁地点，Fante/当地权力举行审判，裁决包含移送英国种植园提议；实际移送执行未明','BS179'),
 ('AB-NEW-051','1793—1799年本地治里重占、政治清查及居民强制远航','E18-B22','23 Aug 1793落城、1799 Feb8 52名当地居民遭英印军拘捕与囚船遣送，是具体法权、监控及暴力事件','BS186'),
 ('AB-NEW-052','1726—1753年印度三大公司港市法院、司法特许与当地居民诉讼范围','E18-B01','公司港市内部法院司法权独立于莫卧儿/当地社会主权；一项有文书证的商业→司法权转型','BS187;BS188'),
 ('AB-NEW-053','1795—1797年科钦荷属堡垒移交、VOC资产清点与科钦王国权利争议','E18-E05','英军先取得荷商堡垒，逐项清查仓库、税权与地方政体，不能扩大为整个Cochin独立王国被吞并','BS189;BS190;BS191'),
]
existing={x['candidate_id'] for x in N['candidates']}
for cid,title,orig,rationale,sources in NEW:
 if cid in existing: raise ValueError(cid)
 N['candidates'].append({'candidate_id':cid,'title':title,'related_original_topic_id':orig,'rationale':rationale,'source_ids':sources.split(';'),'decision':'propose_to_editor'})
# distinct events, date precision and political actor; null site = no fabricated coordinates
EV=[]
def add(id,ts,year,month,day,title,actors,location,action,effect,sids,precision='day',confidence='source_explicit_historical_date',date_window=None):
 EV.append({'id':id,'topic_ids':ts.split(';'),'year':year,'month':month,'day':day,'date_precision':precision,'title':title,'actors':actors,'location':location,'action':action,'political_effect':effect,'source_ids':sids.split(';'),'source_urls':[SLOOKUP[s] for s in sids.split(';')],'research_status':'candidate_not_published','map_state':'not_yet_geocoded','geometry_id':None,'confidence':confidence,'historical_control_boundary_verified':False,'actual_British_control_area_sqkm':None,**({'year_window':date_window} if date_window else {})})
# Ghana coast and Sierra Leone
add('AB-F5-GH-001','E18-E10;AB-NEW-047',1750,None,None,'1750法案创立非洲商人公司并重组RAC堡垒资产','British Parliament; Royal African Company; Company of Merchants Trading to Africa; local Fante polities','London; Gold Coast forts','23 Geo II c31推进非洲公司替代；明载在非洲堡垒服务大西洋人口奴役买卖，而非新的沿岸全域主权。','commercial_corporation_and_forts_not_african_suzerainty','BS179','year')
add('AB-F5-GH-002','E18-E10;AB-NEW-047',1750,8,6,'公司在伦敦首次选举委员会主席、设置秘书薪酬','African Company of Merchants trading to Africa; Richard Boddicott; Charles Pole; William Hollier','London Royal Exchange','伦敦委员会首次会议：Charles Pole抽签任主席，William Hollier秘书兼会计年薪100英镑、须交500英镑保证金。','corporate_accounting_organization_not_local_sovereignty','BS179')
add('AB-F5-GH-003','E18-E10;AB-NEW-047',1751,2,5,'皇家非洲公司与新商人公司协商Cape Coast官员接替','RAC; Company of Merchants; Thomas Melvil; Ebenezer Young','London; Cape Coast Castle','1751年2月5日伦敦会议约定委任Thomas Melvil等；分清董事组织变迁和驻堡实际移交。','negotiated_company_management_transfer','BS179')
add('AB-F5-GH-004','E18-E10;AB-NEW-047',1751,4,17,'公司指示海岸角总管登记被奴役者与贩奴船航次','Company of Merchants; Thomas Melvil; enslaved African persons; coastal communities','Cape Coast Castle / London','给Melvil的命令要求记录堡中被奴役者名册、沿岸到港船舶所载人数、来去港；公司参与人口奴役贸易的管理体系。','trade_reporting_control_not_land_title','BS179')
add('AB-F5-GH-005','E18-E10;AB-NEW-047',1752,4,10,'1752法案撤销RAC原公司财产并移交城堡与被奴役者','British Parliament; Royal African Company; Company of Merchants; enslaved people','London; Gold Coast','25 Geo II c40据1762年出版汇编转引文本：规定旧公司自1752年4月10日失去所列财产／公司权利；各堡实际交割需另核。','legal_asset_divestiture_not_verified_castle_transfer_date','BS179')
add('AB-F5-GH-006','E18-E10;AB-NEW-047',1752,6,10,'阿诺马布新堡设计拟从冈比亚调被奴役者清理工程','Company of Merchants; Anomabo Fante chiefs; enslaved people at Gambia','Anomabo and Gambia','委员会提出扩大旧堡的炮台并从冈比亚运被奴役者协助施工，属于规划命令，未凭此声称全部人数确实抵达。','planned_coerced_labour_transfer_not_verified_arrivals','BS179')
add('AB-F5-GH-007','E18-E10;AB-NEW-047',1753,1,None,'阿诺马布委员申报1752年建筑材料成本','Company of Merchants; British Treasury; Anomabo local communities','London / Anomabo','委员会报告此前由1752年10,000英镑议会拨款中挪用6,116英镑3先令9便士采购材料，呼吁补充预算；子额不可和总拨款再加。','parliamentary_spending_materials_not_trade_profit','BS179','month')
add('AB-F5-GH-008','E18-E10;AB-NEW-047',1753,1,25,'Fante阿诺马布地方首领反对英国商堡扩大占地','John Apperley; Fante cabboceers; John Currantee under Fante king','Anomabo, Ghana','Apperley 1753年3月9日回顾称1月25日拟扩堡时地方首领因旧堡英官苛待而反对，John Currantee调解且英方拟缩小棱堡面宽；土地边界无据。','documented_local_land_negotiation_opposition','BS179')
add('AB-F5-GH-009','E18-E10;AB-NEW-047',1753,3,9,'阿诺马布工程师承认动用被奴役者与当地居民装卸材料','John Apperley; company enslaved labourers; Anomabo residents','Anomabo','Apperley工程师致军械委员会日记记公司被奴役者和镇上居民帮忙装卸；未从词句推断所有当地居民都被强迫。','documented_enslaved_labour_fort_construction','BS179')
add('AB-F5-GH-010','E18-E10;AB-NEW-047',1754,9,25,'非洲公司准付两名被带至英国非洲少年的寄养支出','Company of Merchants; George Cockburn; two African youths; Fante elites','London / Wombwell Hall','委员会批准报销Cockburn对两名非洲少年的£79 4s 1d费用；同期文件显示企图以教育建立与海岸首领外交关系；不推断二人遭奴役。','colonial_hostage_or_elite_diplomacy_disputed_legal_status','BS179')
add('AB-F5-GH-011','E18-E10;AB-NEW-047',1757,1,5,'伦敦非洲公司为西非征募士兵支付人头费','Company of Merchants; John Blackwood','London / Cape Coast Castle','批准按每征10名派往Cape Coast士兵支付每人£1 11s 6d佣金；合同价格不是军事净收益。','recruitment_fee_not_land_control','BS179')
add('AB-F5-GH-012','E18-E10;AB-NEW-047',1759,6,27,'英国非洲公司请海军介入Komenda英荷争夺登陆地','Nassau Senior; African Company; Dutch coastal forts; Komenda local communities','Komenda, Ghana','1759年6月27日呈海军部备忘录称荷堡试图排斥英国使用公共登陆地，英荷堡已发生敌对行动；材料是英方的权利主张，不代表本地首领认可。','military_trade_dispute_not_full_coastal_sovereignty','BS179')
add('AB-F5-GH-013','E18-E10;AB-NEW-047',1760,11,12,'公司要求各西非贸易堡宣读乔治三世继位公告','Company of Merchants; Cape Coast; James Fort; Whydah local communities','Cape Coast Castle; James Fort Gambia; Whydah','伦敦委员会指示各堡宣告君主继位；殖民公司要求在贸易影响范围公开宣读，并不证明非洲各本地政体接受英国直接主权。','symbolic_royal_proclamation_at_forts_only','BS179')
add('AB-F5-GH-014','E18-E10;AB-NEW-050',1770,11,21,'Komenda地方审判决定惩罚八名涉嫌杀死奴主者','Fante cabboceers; Cudjoe; Kings of Abramboe and Aquafoe; 8 accused enslaved people; British governor','Cape Coast Castle / Komenda','英文城堡会议记录称各当地首领按地方习俗审理8名在堡内暂拘者，最终决定4人被交付处死、4人拟送英属美洲种植园；实际跨洋运输执行未证实。','mixed_local_law_and_british_fort_detention;transport_proposed_only','BS179')
add('AB-F5-GH-015','E18-E10;AB-NEW-049',1782,2,17,'英军联合海陆兵力攻击荷属Elmina但被击退','British independent companies; Dutch fort Elmina; local Fante and Elmina polities','Elmina, Ghana','Crooks前言综述1782年2月17—21日英国进攻Elmina失败；原发报副本与军队名单未直接核对，攻城区域不要自行推算。','failed_british_attack_not_dutch_transfer','BS179')
add('AB-F5-GH-016','E18-E10;AB-NEW-049',1782,3,None,'Shirley上尉在西非海岸短期夺取五座荷属堡','Captain Shirley; Royal Navy HMS Leander; Dutch forts; local polities','Gold Coast; five Dutch forts unnamed in available extract','1923文献前言称1782年3月英舰Leander攻下五堡，但摘录未列堡名、坐标与归还时间；保持地区文字事件、不生成五个地理点。','short_military_occupation_unnamed_forts','BS179','month')
add('AB-F5-GH-017','E18-E10;AB-NEW-049',1782,2,None,'英国派两支独立连至海岸角堡准备进攻荷堡','British Independent Companies; African Company; Dutch garrisons','Cape Coast Castle','英军两连于1782年2月抵达Cape Coast，原总额200人；六月以后编制剧降的原因、统计期间需复核。','temporary_crown_force_station_not_coastline_control','BS179','month')
# Sierra Leone Bunce succession
add('AB-F5-SL-001','E18-E09;AB-NEW-048',1728,None,None,'皇家非洲公司放弃塞拉利昂河Bunce岛堡','Royal African Company; local Sierra Leone River polities','Bunce Island, Sierra Leone','1752年英国议会法案追述RAC及职员在1728年弃守Bance堡；没有把本地居民自治消失或岛周边海岸英国管治当作法律后果。','abandoned_royal_african_company_fort_not_enslaved_trading_end','BS179;BS181','year','later_law_recounts_1728')
add('AB-F5-SL-002','E18-E09;AB-NEW-048',1752,4,10,'1752议会法保留Grant、Sargent与Oswald对Bance岛堡占有','British Parliament; Alexander Grant; John Sargent; Richard Oswald; Sierra Leone River locals','Bunce Island','25 Geo II c40对私人商人的具体例外：其对岛屿堡垒及建筑占有继续，不随RAC整体移交新的Africa Merchants Company。','private_merchant_fort_title_claim_not_river_suzerainty','BS179;BS181')
add('AB-F5-SL-003','E18-E09;AB-NEW-048',1794,None,None,'Bunce岛私商声称因法英战争遭美法来袭受损','Anderson brothers; French and American raiders; enslaved coastal trade workers','Bunce Island','1807年请愿追述1794战时入侵导致岛上财产毁坏不少于20,000英镑；归类为**1807年业主索赔宣称**，不是经验证真损失、亦非保险到账。','private_slaving_station_wartime_damage_claim','BS181','year','later_1807_petition_claim')
# Bengal legal and Indian Ocean courts
add('AB-F5-IN-001','E18-B16',1793,3,22,'孟加拉永久地税公告确定地税评估长期固定原则','Cornwallis; EIC Board of Directors; Bengal zamindars, talukdars and ryots','Bengal, Bihar and Orissa (legal region, historic bounds not traced)','1793年3月22日公告确立固定地税原则，后在5月1日Regulation I中取得法定效力；税权并非所有村落即时财政交割。','permanent_fiscal_assessment_not_polygon','BS183')
add('AB-F5-IN-002','E18-B16',1793,5,1,'Regulation I把1793年3月公告编入孟加拉地税法','Governor-General in Council; zamindars; independent talukdars','Bengal Presidency','1793年5月1日Reg I规定对已议定地税的地主及继承人固定应纳jama，仍有不同土地及法律例外，不把农民土地权一概写成地主私人所有。','legislation_fixed_revenue_claim','BS183')
add('AB-F5-IN-003','E18-B16;AB-NEW-034',1793,5,1,'Regulation II将税务法院民事案件改由Diwani Adalat审理','Governor-General in Council; revenue collectors; landholders and raiyats','Bengal Presidency','1793年5月1日Regulation II的立法理由明示废除Mal Adalat税务法院，并将争议交Diwani Adalat处理，使收税官失去司法裁决职责。','court_jurisdiction_reallocation_not_annexation','BS184;BS185')
add('AB-F5-IN-004','E18-B01;AB-NEW-052',1726,9,24,'王室1726特许在孟买、马德拉斯和加尔各答设市长法院','George I; East India Company; local merchants and residents','Bombay; Madras; Calcutta','1726年9月24日Letters Patent设置市长法院并将特定诉讼/审理权授公司城镇机构；不能将之泛化为整个莫卧儿印度的英国司法主权。','presidency_town_civil_jurisdiction','BS187;BS188')
add('AB-F5-IN-005','E18-B01;AB-NEW-052',1753,1,8,'1753新特许重新设立三大公司港市法院','George II; East India Company; urban residents','Bombay; Madras; Calcutta','1753年1月8日新宪章重建Mayor’s Courts，另设受理5帕戈达及以下诉讼的简易法院；具体当地原始法庭簿册仍未读。','limited_company_town_courts','BS187;BS188')
# Pondicherry
add('AB-F5-IN-006','E18-B02;E18-B22;AB-NEW-051',1748,8,None,'Boscawen率英舰在本地治里围攻法军失败','Admiral Edward Boscawen; French India defenders; EIC troops','Pondicherry','英国国家陆军博物馆记1748年8月约30艘舰船和陆军围困法属本地治里约两个月终撤；死者“超过1000”系馆方历史概述，未查原军籍。','failed_siege_no_occupation','BS192','month')
add('AB-F5-IN-007','E18-B22;AB-NEW-051',1793,8,23,'英印军围攻后法属本地治里投降','EIC troops; French Pondicherry officers; local Tamil inhabitants','Pondicherry','剑桥2025文献明载7月被围与8月23日投降；1990年代前的法国定居点自由度和英方占领持续性分别记录。','military_capture_of_french_port_city_not_coromandel_region','BS186')
add('AB-F5-IN-008','E18-B22;AB-NEW-051',1799,2,8,'英印军在本地治里拘捕52名平民并以囚船遣往英国','East India Company detachments; 52 arrested civilians; French prisoners of war','Pondicherry / ship to Portsmouth','剑桥学术文据法印殖民档记52名本地治里男子遭拘捕、上船，另载船上此前已有300名法军战俘；两个群体不可混为352名本地平民；未证各人的最终下落。','coercive_detention_deportation_not_territory_expansion','BS186')
# Cochin
add('AB-F5-IN-009','E18-E05;AB-NEW-053',1791,None,None,'Cochin王与英国驻王廷官员签协议保留旧荷方合约关系','Raja Rama Varma; British resident George Powney; VOC officials','Cochin','Brill学者指出1791英公司保证不侵害Cochin王与VOC先有条约；1795英方主张继承荷方特权不得变成默认王国自愿割让。','diplomatic_law_not_cession_of_cochin_kingdom','BS189','year')
add('AB-F5-IN-010','E18-E05;AB-NEW-053',1795,10,19,'英国Petrie与荷方Van Spall签署Cochin城堡投降条款','Major G. Petrie; J. L. Van Spall; VOC; Cochin Raja','Fort Cochin','Francis Day 1863年出版的历史条约副本含1795年10月19日投降条款及签名；签署日与实际移交不混作同一事实。','signed_dutch_fort_surrender_terms','BS191')
add('AB-F5-IN-011','E18-E05;AB-NEW-053',1795,10,None,'公司接管Cochin荷商军械仓库、港务房屋与税权文书','EIC officials; Dutch VOC officials; Cochin Raja and town communities','Fort Cochin','Brill学者指出英方征用VOC仓库、炮械和行政建筑、审查荷方港口税权文书与荷方雇员，出现双套行政一段时间；Raja的独立统治须单独检验。','asset_and_jurisdiction_inventory_claim_not_kingdom_annexation','BS189;BS190','month')
# Validate no accidental duplicate ids
seen={x['id'] for x in E['events']}
for e in EV:
 if e['id'] in seen: raise ValueError('Duplicate '+e['id'])
 E['events'].append(e)
E['schema']='18c-assistant-B-events-v5';E['state']='research_only'
FNEW=[]
def econ(id,topics,year,value,unit,metric,payer,recipient,period,sources,role,limit,verification='reported_historical_document_not_cash_receipt',actual=False):
 FNEW.append({'id':id,'topic_ids':topics,'year_start':str(year),'year_end':str(year),'value':str(value),'currency_or_unit':unit,'metric_definition':metric,'payer_or_affected':payer,'recipient_or_observer':recipient,'accounting_period':period,'source_ids':sources,'source_urls':';'.join(SLOOKUP[s] for s in sources.split(';')),'source_reading_level':'archival_transcription_in_1923_book_read' if 'BS179' in sources else 'historical_law_or_petition_transcription_read','source_role':role,'verification_status':verification,'was_primary_manuscript_personally_read':'False','actual_received_or_transferred_verified':'True' if actual else 'False','numerator_denominator':'','interpretation_limit':limit})
econ('FISC-F5-1750-Africa-secretary','E18-E10;AB-NEW-047',1750,100,'GBP_nominal_per_year','appointed secretary and accountant annual salary, not total payroll','African Company of Merchants','William Hollier','annual proposed remuneration','BS179','London_Committee_Minutes','Committee salary grant not evidence of actual annual payment')
econ('FISC-F5-1750-Africa-secretary-bond','E18-E10;AB-NEW-047',1750,500,'GBP_nominal_security_bond','security bond required of accountant, not annual salary or paid revenue','William Hollier','African Company of Merchants','one-time security condition','BS179','London_Committee_Minutes','Bond promised, not annual net income, and not necessarily deposited cash')
econ('FISC-F5-1751-Africa-supplies','E18-E10;AB-NEW-047',1751,10000,'GBP_nominal_parliamentary_allocation','parliamentary grant toward African forts as explicitly noted in 1751 instructions','British Treasury','Company of Merchants','one-year grant','BS179','company_instructions_reproduced','Grant is British fiscal expense to maintain slave trade network, NOT profit')
econ('FISC-F5-1751-Cape-Coast-hire','E18-E10;AB-NEW-047',1751,650,'GBP_nominal_ship_hire_quote','Captain Bonell hired Flying Flambro (~370 ton) for 60 passengers and 30 crew','African Company Merchants','Captain Bonell','1751 charter proposal','BS179','committee_contract_reproduced','Charter cost quoted; no proof full cash clearing and not slave count')
econ('FISC-F5-1753-Anomabo-material-cost-pounds','E18-E10;AB-NEW-047',1753,6116,'GBP_pounds_component_3shillings_9pence','Anomabo new fort imported stores cost £6,116 3s 9d; GBP component for searchable numeric','British Treasury appropriation via Merchants Company','Anomabo fort construction','Jan 1753 memorandum for materials bought Oct 1752','BS179;BS193','contemporary_1753_memo_reproduced','FULL ORIGINAL £6116:3:9 (pounds/shillings/pence). Included in £10,000 1752 grant; never add as separate grant. GBP pounds component only.')
econ('FISC-F5-1754-African-youth-education-cost','E18-E10;AB-NEW-047',1754,79,'GBP_pounds_component_4s_1d','Committee repaid account £79 4s 1d for two young African persons (historical terminology biased)','Company of Merchants','Captain Cockburn','account to 22 July 1754; approved 25 Sept','BS179','company_minute_reproduced','£79:4:1 not proof children were enslaved; not slave-sale proceeds')
econ('FISC-F5-1757-recruitment-per-soldier','E18-E10;AB-NEW-047',1757,1,'GBP_pounds_component_11s_6d_per_recruit','Recruiter John Blackwood allowance £1 11s 6d per recruited soldier','African Merchants Company','John Blackwood','for ten recruits to Cape Coast, 5 Jan 1757','BS179','committee_minute_reproduced','Unit price has shillings/pence; not full GBP £1.00 and no evidence of paid total')
econ('FISC-F5-1757-recruitment-target','E18-E10;AB-NEW-047',1757,10,'persons_recruitment_target','ten soldiers specified in committee contract; actual embarkation not established','African Merchants Company','Cape Coast garrison','Jan 1757 order','BS179','committee_minute_reproduced','Recruitment agreement headcount not precise live garrison')
econ('FISC-F5-1794-Bunce-owner-loss-claim','E18-E09;AB-NEW-048',1794,20000,'GBP_nominal_claim_lower_bound','Anderson brothers in February 1807 petition claim loss upwards of £20,000 on Bunce Island in 1794 attack','Anderson slave trading firm','Parliament petition','asserted 1794 loss in petition 1807','BS181','retrospective_primary_lobbying_claim','Claim is self-interested and not an audited loss, actual compensation or received revenue')
econ('FISC-F5-1782-West-Africa-two-company-men','E18-E10;AB-NEW-049',1782,200,'persons_initial_force_claim','Crooks 1923 historical preface says two Independent Companies landing total strength 200','British military Crown forces','Cape Coast','1782 Feb arrival','BS179','1923_book_preface_historical_retelling','Not a count of enslaved persons nor complete military campaign casualty statistics')
econ('FISC-F5-1782-West-Africa-strength-six-months','E18-E10;AB-NEW-049',1782,60,'persons_remaining_force_claim','Historical preface claims force reduced to 60 within 6 months; desertion and detachments, do not infer deaths','British independent military companies','Cape Coast','1782 six months post-arrival','BS179','1923_book_preface_historical_retelling','200 minus 60 not attributable to deaths alone; no duplicate casualty calculation')
econ('FISC-F5-1799-Pondicherry-arrested','E18-B22;AB-NEW-051',1799,52,'persons_arrested','52 civilian men rounded up by East India Company troops 8 Feb 1799','Pondicherry civilian residents','EIC military and ship','1799-02-08','BS186','peer_reviewed_2025_article','Detained persons, not entire city population or 300 French prisoners already on vessel')
econ('FISC-F5-1799-Pondicherry-POW','E18-B22;AB-NEW-051',1799,300,'persons_french_POW_aboard','Article describes 300 French POW already aboard ship before 52 residents arrived','French military POW','EIC transport vessel','1799-02-08','BS186','peer_reviewed_2025_article','Distinct category, not additional 300 local civilian arrests')
ids={r['id'] for r in F}
for r in FNEW:
 if r['id'] in ids:raise ValueError('Dup econ '+r['id'])
 F.append(r)
TNEW=[]
def transition(id,date,place,before,after,actors,semantics,sources,event,limit):
 TNEW.append({'id':id,'date':date,'place':place,'from_status':before,'to_status':after,'actors':actors,'control_semantics':semantics,'historical_boundary_verified':'false','area_sqkm':'','geometry_policy':'named_site_point_or_unmapped_only','source_ids':sources,'related_event_id':event,'uncertainty':limit})
transition('T062','1726-09-24','Bombay/Madras/Calcutta','Local company trading settlements','New limited company mayor court jurisdictions','EIC; George I; urban residents','judicial_charter_not_india_territorial_sovereignty','BS187;BS188','AB-F5-IN-004','Only three company towns and listed dependencies, no wider Indian state boundary verified')
transition('T063','1750','Cape Coast and West African forts','Royal African Company previous charter','New Company of Merchants corporate regime; site handover separately','RAC; Merchants Company; Fante','corporate_reorganization_not_political_territory','BS179','AB-F5-GH-001','1750 corporation charter law ≠ physical occupation of each fort')
transition('T064','1752-04-10','Bunce Island Sierra Leone River','Previous RAC abandoned fort; later private operators','Specific private firm title/exception from generic Africa company transfer','Grant; Sargent; Oswald; RAC','private_trading_station_not_crown_land_annexation','BS179;BS181','AB-F5-SL-002','The 1752 act confirmed European private property claim; land/trading relations with locals distinct')
transition('T065','1753-01-25','Anomabo Ghana','Small previous merchant fort','Company seeks much bigger fort; Fante chiefs oppose and negotiate shrinkage','Fante cabboceers; John Currantee; engineer Apperley','contested_fort_footprint_and_local_land_agency','BS179','AB-F5-GH-008','No traced historic fort walls or agreed boundary; no fake expansion polygon')
transition('T066','1782-02-17','Elmina Ghana','Dutch fort','Dutch fort remains after failed British siege','British Crown; Dutch fort; local polities','failed_attack_no_territorial_transfer','BS179','AB-F5-GH-015','Siege continued to 21 Feb; exact battle geometry unknown')
transition('T067','1793-05-01','Bengal presidency','Decennial land tax and collector-court structure','Permanent revenue law and separate civil courts','Cornwallis; Zamindars; Raiyats; EIC','fiscal_and_judicial_law_change_not_land_area','BS183;BS184','AB-F5-IN-003','District-level territory and implemented cadastral boundaries require independent archival work')
transition('T068','1793-08-23','Pondicherry','French colonial military town before 1793 siege','EIC military occupation of town','British EIC; French; Tamil local residents','dated_french_port_capture_not_wider_carnatic','BS186','AB-F5-IN-007','Town capture not settlement of permanent sovereign title across India')
transition('T069','1795-10-19','Fort Cochin','Dutch VOC colonial fort; separate Cochin Raja','Capitulation signed; British takeover follows as different stage','EIC major Petrie; VOC Van Spall; Cochin Raja','fort_surrender_document_not_native_kingdom_cession','BS191','AB-F5-IN-010','Actual warehouse transfer and Raja treaty conditions not coincident with signature')
transition('T070','1795-10','Cochin warehouses/fort assets','VOC arms/harbour assets and records','British inventory and asserted Dutch tax rights; local kingdom status contested','EIC; VOC; Cochin Raja','asset_takeover_plus_claimed_jurisdiction_not_universal_land_right','BS189;BS190','AB-F5-IN-011','Treaty rights contested and separately administered; paper inventory != measured territory')
for r in TNEW:
 if any(x['id']==r['id'] for x in T):raise ValueError('Dup transition')
 T.append(r)
wr('SOURCE_REGISTRY.json',S);wr('EVENT_CANDIDATES.json',E);wr('NEW_CANDIDATES.json',N)
csvwrite('ECONOMIC_EVIDENCE.csv',f_fields,F);csvwrite('CONTROL_TRANSITIONS_B_E.csv',t_fields,T)
# Re-emit canonical CSV from json using original order
fields,rows=csvrows('EVENT_CANDIDATES.csv'); original_ids={r['id'] for r in rows}
for e in EV:
 rr={k:'' for k in fields};
 for k in fields:
  v=e.get(k)
  if isinstance(v,list):v=';'.join(str(x) for x in v)
  rr[k]='' if v is None else str(v)
 rows.append(rr)
csvwrite('EVENT_CANDIDATES.csv',fields,rows)
# Per-candidate independent historical dossiers
for cid,title,orig,rationale,sources in NEW:
 related=[v for v in EV if cid in v['topic_ids']]
 econrows=[r for r in FNEW if cid in r['topic_ids'].split(';')]
 transitionrows=[r for r in TNEW if r['related_event_id'] in {v['id'] for v in related}]
 p=P/'TOPIC_DOSSIERS'/'NEW_CANDIDATES'/f'{cid}.md'
 lines=[f'# {cid}｜{title}','',f'- 编辑关系：`{orig}`；候选独立议题，不改变原母题ID。',f'- 研究状态：`research_only`；原纸档、地理边界尚未审定。','', '## 可核时间序列']
 for v in related:lines.append(f"- **{v['year'] if v['year'] else v.get('year_window','?')}{('-'+str(v['month']).zfill(2)) if v['month'] else ''}{('-'+str(v['day']).zfill(2)) if v['day'] else ''}｜{v['title']}**：{v['action']} （来源：{', '.join(v['source_ids'])}；事件ID：`{v['id']}`）")
 lines+=['','## 权力与政治主体',rationale,'地图请保持Fante、当地王侯／法荷殖民地、印度各邦和其他非英国政治主体为独立对象；公司贸易许可证、官员礼金、税权、驻军、实际城堡占据及英国国王主权不得合并。','', '## 金额／数量／会计口径']
 if econrows:
  for r in econrows:lines.append(f"- `{r['id']}`：{r['value']} {r['currency_or_unit']}。{r['metric_definition']}。限制：{r['interpretation_limit']}")
 else:lines.append('- 本候选暂无经核可量化财务数字；不补造收益。')
 lines+=['','## 来源与阅读深度']
 for sid in sources.split(';'):
  s=next(s for s in S['sources'] if s['id']==sid);lines.append(f"- `{sid}` {s['title']}：{s['url']}；阅读级别：`{s['reading_level']}`；原始手稿本人亲阅：否。")
 lines+=['','## GIS与后续查核','- 无实测控制 Polygon；具名地点可待地名文献复核后画现代参考点，严禁凭堡垒地点涂整国或整省。','- 未核项：原卷连续性、当地政治主体史料、精确军占起止日、金额实际清算、历史边界。']
 p.write_text('\n'.join(lines)+'\n',encoding='utf-8')
# Append specific source-verified increments to original dossier files, never discard previous text
for code,selected in {'E18-E10':['AB-F5-GH','AB-F5-SL'],'E18-E09':['AB-F5-SL'],'E18-B16':['AB-F5-IN-001','AB-F5-IN-002','AB-F5-IN-003'],'E18-B01':['AB-F5-IN-004','AB-F5-IN-005'],'E18-B22':['AB-F5-IN-006','AB-F5-IN-007','AB-F5-IN-008'],'E18-E05':['AB-F5-IN-009','AB-F5-IN-010','AB-F5-IN-011']}.items():
 p=P/'TOPIC_DOSSIERS'/f'{code}.md'
 if not p.exists():raise FileNotFoundError(p)
 lines=['','## 第五轮（2026-11-08）原件转录／学术增量','以下全部为**待主编审核的研究候选**，不是正式Atlas事件。']
 for v in EV:
  if any(v['id'].startswith(prefix) for prefix in selected): lines.append(f"- `{v['id']}`：{v['year']}年 {v['title']}。{v['action']} 来源{','.join(v['source_ids'])}。")
 p.write_text(p.read_text(encoding='utf-8')+'\n'.join(lines)+'\n',encoding='utf-8')
checkpoint={'date':'2026-11-08','round':'fifth_round_batch1','initial':old,'new_source_ids':[s[0] for s in SNEW],'new_event_ids':[e['id'] for e in EV],'new_topic_ids':[n[0] for n in NEW],'economic_ids':[r['id'] for r in FNEW],'transition_ids':[r['id'] for r in TNEW],'after':{'sources':len(S['sources']),'events':len(E['events']),'economic':len(F),'control':len(T),'new':len(N['candidates'])},'github_writes':0,'publication':'research_only','notes':'PDF page screenshots inspected for Crooks pp10,23,24,36; full original archives not read; 1793 India Code page screenshot timeout; all non-geocoded points remain null.'}
(W/'FIFTH_ROUND_BATCH1_CHECKPOINT.json').write_text(json.dumps(checkpoint,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(checkpoint['after'],ensure_ascii=False))
