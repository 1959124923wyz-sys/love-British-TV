"""Append exact monetary/quantitative definitions, accountability evidence and long dossiers."""
import csv,json,hashlib
from pathlib import Path
P=Path('/mnt/data/18c_assistant_B'); W=P/'WORKING'
get=lambda fn:json.loads((P/fn).read_text(encoding='utf-8'))
S=get('SOURCE_REGISTRY.json')['sources']; E=get('EVENT_CANDIDATES.json')['events']; N=get('NEW_CANDIDATES.json')['candidates']
lookup={s['url'].rstrip('/'):s for s in S};b_id={s['id']:s for s in S}
def sid(u): return lookup[u.rstrip('/')]['id']
def url(k):return b_id[k]['url']
# Supplemental events: statutory incentives and independent petitions not folded into broad annual captions.
extra=[
('AB-R7-ACT-01',1788,'1788年《奴隶船规制法》要求船医登记死亡并呈报海关','英国议会、船医、海关、被奴役者','British slave-voyage ports','1788 Act s.IV mandates named surgeon journals recording deaths, causes, and numbers and certified returns on arrival. This enabled knowledge production and enforcement, not abolition.','administrative_death_surveillance',['AB-NEW-072','E18-E10'],'https://www.pdavis.nl/Legis_21.htm'),
('AB-R7-ACT-02',1788,'1788年英国为低奴役者死亡率航次发船长与船医奖金','英国财政部/海关、英国贩奴船长与船医','Westminster / British Caribbean ports','28 Geo III c54 s.XIV authorizes captain £100/surgeon £50 if mortality ≤2%; alternatively £50/£25 if ≤3%. Legal bonus levels are not confirmed actual disbursements.','legislated_financial_reward_for_slave_shipping',['AB-NEW-072','E18-E10'],'https://www.pdavis.nl/Legis_21.htm'),
('AB-R7-ACT-03',1788,'1788年法令要求评估奴役贸易商因新规遭受的财产损失','英国议会、商人Brook Watson等委员、船主','Westminster / British shipping ports','28 Geo III c54 s.XV establishes commissioners for merchant loss claims occasioned by limits; compensation amounts are undecided, not proven paid.','statutory_merchant_indemnification_process',['AB-NEW-072','E18-E10'],'https://www.pdavis.nl/Legis_21.htm'),
('AB-R7-ACT-04',1788,'1788年英国议会授权最多£2,000资助奴役贸易规制执行委员会','英国国库、奴役贸易规制委员会','London, Treasury','28 Geo III c54 s.XVI authorizes spending up to £2,000 on clerks/administrative costs; ceiling not actual spent or slave-merchant payout.','public_treasury_enforcement_administration',['AB-NEW-072','E18-E10'],'https://www.pdavis.nl/Legis_21.htm'),
('AB-R7-ACT-05',1788,'1788年法令保留奴役“货物”特定海险保险赔偿范围','英国议会、海上保险商人、被奴役非洲人','Westminster / London insurance market','28 Geo III c54 s.XII limits permitted insurance to sea peril, piracy, mutiny, wartime capture, crew misconduct and fire. Shows market legally framed people as insured property; amount unknown.','legal_insurability_of_enslaved_cargo',['AB-NEW-072','E18-E10'],'https://www.pdavis.nl/Legis_21.htm'),
('AB-R7-ACT-06',1773,'1773年公司贷款兼有要求对王室支付两年一度费用的安排','英国政府、议会、东印度公司','Westminster, London','UK Parliament institutional history says Company kept political control of its territories under state authority for £40,000 payment per two years; chronology of actual cash payment requires UK fiscal records.','company_governance_and_treasury_payment',['AB-NEW-074','E18-B09'],'https://www.parliament.uk/about/living-heritage/evolutionofparliament/legislativescrutiny/parliament-and-empire/parliament-and-the-american-colonies-before-1765/parliament-and-the-east-india-company/'),
]
existing={e['id'] for e in E}
for rid,year,title,actor,loc,action,eff,tids,src in extra:
 if rid in existing:continue
 E.append({'id':rid,'topic_ids':tids,'year':year,'month':None,'day':None,'date_precision':'year','title':title,'actors':actor,'location':loc,'action':action,'political_effect':eff,'source_ids':[sid(src)],'source_urls':[src],'research_status':'candidate_not_published','map_state':'law_or_accounting_no_territorial_geometry','geometry_id':None,'confidence':'primary_law_transcription_or_institutional_historical_account','historical_control_boundary_verified':False,'actual_British_control_area_sqkm':None})
(P/'EVENT_CANDIDATES.json').write_text(json.dumps({'schema':get('EVENT_CANDIDATES.json')['schema'],'state':get('EVENT_CANDIDATES.json')['state'],'events':E},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
p=P/'EVENT_CANDIDATES.csv'
with p.open(encoding='utf-8-sig',newline='') as f: hdr=csv.DictReader(f).fieldnames
with p.open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=hdr,extrasaction='ignore');w.writeheader()
 for e in E:
  row={x:e.get(x) for x in hdr}
  for k in ['topic_ids','source_ids','source_urls']:row[k]=';'.join(e.get(k,[]))
  for k,v in row.items():
   if v is None:row[k]=''
   if isinstance(v,dict):row[k]=json.dumps(v,ensure_ascii=False)
  w.writerow(row)

# Economy ledger records are heterogeneous: enforcement ceilings, loan receivable, local expense, mortality bounds, and alleged prices.
finance=[
('R7-FISC-001','E18-E10;AB-NEW-071',1700,1713,'10','percent_export_goods_duty','Trade to Africa 1698–1713: ten percent tax on British merchandise shipped to Africa, historically allocated to forts; no cash receipts measured','British exporters to Africa','British state/Royal African Company fort administration','1698 to 1713 per statutory duty','https://www.nationalarchives.gov.uk/help-with-your-research/research-guides/british-transatlantic-slave-trade-records/','statutory_duty_rate_not_actual_treasury_receipt','1698–1713 British company origin incl before UK 1707; duty on export goods not 10% of slave sale proceeds'),
('R7-FISC-002','E18-B08;AB-NEW-074',1773,1773,'1400000','GBP_18c_nominal','Government loan to East India Company announced in 1773 crisis and Regulating Act; loan principal not net colonial receipt','British public treasury','East India Company','Government financing 1773','https://searcharchives.bl.uk/catalog/036-000178727','public_loan_principal_not_company_profit','British Library catalogue institutional note; original treasury loan disbursement not read'),
('R7-FISC-003','E18-B09;AB-NEW-074',1773,1773,'40000','GBP_18c_nominal_per_two_years','Legal payment scheduled in return for continuing company territorial control under oversight; not confirmed cash actually paid','East India Company','British Crown/public authority','1773 onward statutory arrangement','https://www.parliament.uk/about/living-heritage/evolutionofparliament/legislativescrutiny/parliament-and-empire/parliament-and-the-american-colonies-before-1765/parliament-and-the-east-india-company/','scheduled_payment_not_confirmed_received','The UK Parliament text gives £40,000 every two years; verify actual dates and recipient treasury account'),
('R7-FISC-004','E18-E10;AB-NEW-072',1788,1788,'30','GBP_18c_nominal_per_enslaved_person_exceeding_limit','Statutory £30 charge for each enslaved person carried over permitted capacity; not realized fine revenue','British slave ship masters','British Crown and private prosecutor each half','28 Geo III c54 s.I / s.VI','https://www.pdavis.nl/Legis_21.htm','statutory_penalty_not_actual_payment','No count of punished voyages; cannot multiply by all enslaved voyages'),
('R7-FISC-005','E18-E10;AB-NEW-072',1788,1788,'500','GBP_18c_nominal_per_licensing_offence','Statutory penalty for unlawful disembarkation contrary to Act; legal limit not actual fine collection','British slave ship masters','British Crown and informant in halves','28 Geo III c54 s.III','https://www.pdavis.nl/Legis_21.htm','statutory_penalty_not_actual_payment','Distinct from £30 per additional enslaved person'),
('R7-FISC-006','E18-E10;AB-NEW-072',1788,1788,'5','persons_per_3_tons_up_to_201_tons','Maximum shipping ratio for overall enslaved people at ship tonnage up to 201 (with additional male-specific restriction)','enslaved Africans','ship registers / customs','28 Geo III c54 s.I','https://www.pdavis.nl/Legis_21.htm','statutory_capacity_ratio_not_actual_ship_count','Ratio five per three tons; individual men of stature >4ft 4in stricter conditions'),
('R7-FISC-007','E18-E10;AB-NEW-072',1788,1788,'201','vessel_tons_threshold','Slave-vessel tonnage threshold at which allowable-people-per-ton formula changes','shipowners','Royal customs officers','28 Geo III c54 s.I','https://www.pdavis.nl/Legis_21.htm','legal_ship_tonnage_threshold','Tonnage not an estimate of transported individuals'),
('R7-FISC-008','E18-E10;AB-NEW-072',1788,1788,'100','GBP_18c_nominal_per_qualifying_captain','Reward authorized to captain if documented captive deaths <=2 percent; statute not proof of payment','customs treasury','slave ship captain','28 Geo III c54 s.XIV','https://www.pdavis.nl/Legis_21.htm','conditional_legislated_bonus_not_actual_spent','Medical/mortality conditions apply; not slave-trade net profit'),
('R7-FISC-009','E18-E10;AB-NEW-072',1788,1788,'50','GBP_18c_nominal_per_qualifying_surgeon','Reward authorized to ship surgeon if documented captive deaths <=2 percent; statute not payment record','customs treasury','slave ship surgeon','28 Geo III c54 s.XIV','https://www.pdavis.nl/Legis_21.htm','conditional_legislated_bonus_not_actual_spent','Conditional on certified morbidity and mortality'),
('R7-FISC-010','E18-E10;AB-NEW-072',1788,1788,'50','GBP_18c_nominal_per_qualifying_captain','Lesser reward to captain if captive mortality >2 percent but <=3 percent (as act provision)','customs treasury','slave ship captain','28 Geo III c54 s.XIV','https://www.pdavis.nl/Legis_21.htm','conditional_legislated_bonus_not_actual_spent','Do not sum both bonuses for same ship; tiers alternative'),
('R7-FISC-011','E18-E10;AB-NEW-072',1788,1788,'25','GBP_18c_nominal_per_qualifying_surgeon','Lesser reward to surgeon if captive mortality in higher eligible band <=3 percent','customs treasury','slave ship surgeon','28 Geo III c54 s.XIV','https://www.pdavis.nl/Legis_21.htm','conditional_legislated_bonus_not_actual_spent','Alternate to £50 surgeon reward'),
('R7-FISC-012','E18-E10;AB-NEW-072',1788,1788,'2000','GBP_18c_nominal_ceiling','Upper authorization for clerks, messengers and administration of committee investigating losses from regulation','British Treasury','administration / commissioners','28 Geo III c54 s.XVI','https://www.pdavis.nl/Legis_21.htm','public_expenditure_authorization_not_actual_disbursement','£2,000 ceiling is NOT merchant compensation value'),
('R7-FISC-013','E18-B07',1770,1770,'11500','Company_reported_rupees','Bengal official Richard Becher letter: charity of rice expenses, one local jurisdiction','Company-affiliated charitable expenditures','famine relief recipients','20 Nov 1770 letter','https://academic.oup.com/book/61892/chapter/548190343','contemporary_official_report_quoted_by_historian','Local charitable relief, cannot aggregate to Bengal expenditure; actual vouchers not read'),
('R7-FISC-014','E18-B07',1770,1770,'500','Company_reported_rupees','Bengal official Richard Becher letter: corpse removal expenditure','local company administration','body removal contractors','20 Nov 1770 letter','https://academic.oup.com/book/61892/chapter/548190343','contemporary_official_report_quoted_by_historian','Same letter different expense class, not death count'),
('R7-FISC-015','E18-B07',1770,1770,'3000','Company_reported_rupees','Bengal official Richard Becher letter: feeding elephants expenditure','local company administration','Company elephant provisioning','20 Nov 1770 letter','https://academic.oup.com/book/61892/chapter/548190343','contemporary_official_report_quoted_by_historian','Local line item, not all animal maintenance; do not treat moral comparison as numerical proof of total state priorities'),
('R7-FISC-016','E18-B07',1770,1770,'36','percent_reported_abandoned_cultivated_land','Reported Birbhum cultivated land abandoned in aftermath of 1770 famine; observational administrative figure','Birbhum cultivators','Company district officials','1770 famine period','https://academic.oup.com/book/61892/chapter/548190343','reported_land_use_share_not_population','Birbhum only; historical denominator and survey mapping unverified'),
('R7-FISC-017','E18-B07',1770,1770,'16.7','percent_pop_estimate_lower_bound','Scholarly Bengal famine fatality estimate approx one sixth of regional population at lower end','Bengal inhabitants','McLane historical demographic synthesis','1770 famine period','https://www.cambridge.org/core/books/abs/land-and-local-kingship-in-eighteenthcentury-bengal/famine-of-1770/932B785B5186FD79ADB4EC5FF5127F85','secondary_historical_mortality_estimate_bound','Approx fraction; different population denominators and wide uncertainty; not measured register'),
('R7-FISC-018','E18-B07',1770,1770,'33.3','percent_pop_estimate_upper_bound','Scholarly Bengal famine fatality estimate approx one third regional population at upper end','Bengal inhabitants','McLane historical demographic synthesis','1770 famine period','https://www.cambridge.org/core/books/abs/land-and-local-kingship-in-eighteenthcentury-bengal/famine-of-1770/932B785B5186FD79ADB4EC5FF5127F85','secondary_historical_mortality_estimate_bound','Bound pairs with R7-FISC-017, cannot sum; no total headcount without proper denominator'),
('R7-FISC-019','E18-B19;AB-NEW-076',1788,1788,'3000000','maund_annual_salt_supply_quota_approx','Annual permitted salt quantity under Company auction system; rough order from academic analysis','Bengal salt producers and buyers','East India Company salt agencies','c.1788–early company auction regime','https://www.cambridge.org/core/journals/international-review-of-social-history/article/environmental-changes-the-emergence-of-a-fuel-market-and-the-working-conditions-of-salt-makers-in-bengal-c-17801845/EFF95B979EA1BC59C12DAFD1E623FB58','approx_regime_quota_not_actual_sold','Maund varies; do not convert into tons without historically correct regional weight standard'),
('R7-FISC-020','E18-B07;AB-NEW-074',1772,1772,'2–2.5','rice_maunds_per_rupee_alleged','Peasants alleged official purchased paddy cheaply at about 2–2.5 maunds per rupee during famine','Purnea/Tajpur peasants','Raja Debi Singh / official agents as accused','1772 petitions about 1770 famine','https://famineanddearth.exeter.ac.uk/displayhtml.html?id=fp_00358_en_committeeofcircuit_7thjuly-20thaugust1772','contested_petition_allegation','Source is petition / local grievance, official Ducarel denied charges; no verified market series'),
('R7-FISC-021','E18-B07;AB-NEW-074',1772,1772,'3–4','rice_seer_per_rupee_resale_alleged','Peasants alleged later resale around 3–4 seer of rice per rupee after monopoly seizure','Purnea/Tajpur inhabitants','Raja Debi Singh / official granary as accused','1772 petitions about 1770 famine','https://famineanddearth.exeter.ac.uk/displayhtml.html?id=fp_00358_en_committeeofcircuit_7thjuly-20thaugust1772','contested_petition_allegation','Historical maund/ser unit conversions not assumed, seller and purchase quality not confirmed'),
]
fpath=P/'ECONOMIC_EVIDENCE.csv'
with fpath.open(encoding='utf-8-sig',newline='') as f:reader=csv.DictReader(f); hdr=reader.fieldnames; rows=list(reader)
existing={r['id'] for r in rows}
for fid,tids,ys,ye,value,unit,metric,payer,rece,period,src,role,limit in finance:
 if fid in existing:continue
 s=sid(src)
 rows.append({'id':fid,'topic_ids':tids,'year_start':ys,'year_end':ye,'value':value,'currency_or_unit':unit,'metric_definition':metric,'payer_or_affected':payer,'recipient_or_observer':rece,'accounting_period':period,'source_ids':s,'source_urls':src,'source_reading_level':b_id[s]['reading_level'],'source_role':role,'verification_status':'documented_with_stated_limit_not_original_accounts_verified','was_primary_manuscript_personally_read':'False','actual_received_or_transferred_verified':'False','numerator_denominator':'see_metric_definition','interpretation_limit':limit})
with fpath.open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=hdr);w.writeheader();w.writerows(rows)
# Governance transitions across specific administrative domains; no false control geometry.
tpath=P/'CONTROL_TRANSITIONS_B_E.csv'
with tpath.open(encoding='utf-8-sig',newline='') as f:dr=csv.DictReader(f);thdr=dr.fieldnames; tr=list(dr)
transitions=[
('1701','English home textile market','Unrestricted Asian finished cloth in England','Royal protection ban with stated exemptions','English Parliament / EIC','market_access_regulation_not_Indian_land_control','AB-R7-POL-001'),
('1721','British Asian textile import and colonial routing','Early legal restrictions','Additional limits on printed cloth domestic use and American-colony routing','British Parliament / EIC','imperial_trade_routing_not_sovereignty','AB-R7-POL-003'),
('1750','West African British trading fort governance','Royal African Company charter and fort administration','Parliament-created Company of Merchants Trading to Africa structure','British Parliament / local Fante political authorities','trading_fort_company_successor_not_African_territory','AB-R7-POL-005'),
('1769','East India Company surplus transfer channels','Bengal diwani with company administrative control','British state-endorsed revenue surplus remittance policy','British Government / Company','fiscal_policy_not_new_land_conquest','AB-R7-POL-011'),
('1772-05-14','Bengal district land-revenue collection','Variable local intermediary tax receipts','Five-year tax farming competitive bidding by Company committee','Company Revenue Committee / zamindars','territorial_tax_farming_not_new_historical_boundary','AB-R7-POL-015'),
('1773','East India Company corporate finance','Liquidity crisis','Parliament-approved rescue loan and limited Crown governance rules','British Parliament / East India Company','state_financial_exposure_not_new_sovereignty_polygon','AB-R7-POL-017'),
('1773','Bihar and Patna opium procurement','Private Company officials and subcontractor privileges','Centralized Company monopolistic contractual procurement','Company Governor-General / ryots','commodity_monopoly_not_area_colonization','AB-R7-POL-019'),
('1784','Bengal/India political oversight','Company governors under 1773 act','London Board of Control empowered to direct policies','British Parliament / East India Company','political_control_supervision_not_royal_direct_rule','AB-R7-POL-021'),
('1788','Bengal salt sale','Fixed-price Company salt sale','Auction monopoly for fiscal revenue','Company Bengal revenue administration / malangi workers','market_monopoly_not_land_boundary','AB-R7-POL-024'),
('1788','British shipping on West African slave trade routes','Private slave trade operating with previous general statutes','Full tonnage and death-reporting regulation by Parliament','UK Parliament / customs','state_regulation_of_people_trafficking_not_west_african_colonial_area','AB-R7-POL-025'),
('1793','Bengal permanent revenue settlement','Decennial conditionally fixed zamindari assessments','Company estate revenue fixed permanently with landholder rights rules','Company Directors / Cornwallis / zamindars','land_tenure_law_not_geographical_boundary_proof','AB-R7-POL-030'),
('1793','Bengal land revenue judiciary','Revenue collectors judge many tax matters','Mal Adalat cases sent to Diwani courts','Company Bengal administration','judicial_reform_not_a_new_land_acquisition','AB-R7-POL-031'),
('1797','Patna/Benaras opium agencies','Private contractor opium purchasing','Company official agent-administered fixed procurement','East India Company / ryots','economic_coercion_not_territory','AB-R7-POL-033'),
('1799','Bengal agency opium agriculture','Contract and agent monopoly','Regulation VI 1799 prohibits private cultivation and diversion','Company Bengal regulation / poppy farmers','legal_production_controls_not_sovereignty_polygon','AB-R7-POL-034'),
]
eidmap={e['id']:e for e in E}
for date,place,frm,to,actors,sem,eid in transitions:
 assert eid in eidmap,(date,eid)
 if any(r['related_event_id']==eid for r in tr): continue
 srcid=eidmap[eid]['source_ids'][0]
 tid='T-R7-'+str(len(tr)+1)
 tr.append({'id':tid,'date':date,'place':place,'from_status':frm,'to_status':to,'actors':actors,'control_semantics':sem,'historical_boundary_verified':'false','area_sqkm':'','geometry_policy':'no_new_polygon; textual control timeline only','source_ids':srcid,'related_event_id':eid,'uncertainty':'Authoritative source supports legal/institutional change, NOT historical land extent'})
with tpath.open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=thdr);w.writeheader();w.writerows(tr)
print('CHECKPOINT B events',len(E),'fiscal',len(rows),'transitions',len(tr))
(W/'SEVENTH_ROUND_ACCOUNTING_CHECKPOINT.json').write_text(json.dumps({'events':len(E),'fiscal':len(rows),'transitions':len(tr),'new_fiscal_ids':[f[0] for f in finance]},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

# Governance chain matrix. Claim of authorization is graded according to instrument and contemporaneous knowledge, not preconceived conclusion.
policies=[
('P01',1701,'India to English market','English Parliament','1701 Asian finished textiles import/use restriction','Statute-based market access restrictions','Indian manufacturers, English consumers, English wool producers','LEGAL_SYSTEMATIC','institutional/museum timeline; no India factory damage figure','AB-R7-POL-001','AB-NEW-079'),
('P02',1721,'India-English-Americas','British Parliament','1721 calico / colonial reexport legislation','Domestic sale restrictions; British gateway to colonies','Indian exporters, transshipment merchants, colonial buyers','LEGAL_SYSTEMATIC','1721 act and Cambridge historical analysis','AB-R7-POL-002;AB-R7-POL-003','AB-NEW-079'),
('P03',1750,'Gold Coast & West Africa','British Parliament, Crown','23 Geo II c31 African Trade Act','Organized merchant company for supplying plantation slave labor, fort governance','Enslaved Africans, African coastal communities, Fante rulers','EXPLICIT_LEGAL_AUTHORIZATION','Smithsonian facsimile curatorial text preamble','AB-R7-POL-005','AB-NEW-071'),
('P04',1750,'Cape Coast & Anomabo forts','Company of Merchants Trading to Africa','Fort records: T 70 Detached Papers','Company governance included enslaved fort workers and relationship with Fante elites','Enslaved fort laborers, Fante societies','CORPORATE_ORGANIZATIONAL','2026 Cambridge abstract, T70 historical paper not actually opened','AB-R7-POL-006','AB-NEW-071'),
('P05',1757,'Bengal','EIC General Court / Mir Jafar','Treaty financial accounts and 1757–1760 meeting minutes','Company and private recipients tracked separately in corporate books','Bengal treasury, East India Company shareholders, officials','DOCUMENTED_CORPORATE_KNOWLEDGE','British Library catalogue only; monetary figures unverified','AB-R7-POL-007;AB-R7-POL-008','AB-NEW-077'),
('P06',1769,'Bengal-UK finance','British Government / EIC','State policy for surplus transfers described in economic study','Revenue-funded investment and export plus remittances','Bengal revenue payers and EIC trading networks','GOVERNMENT_POLICY_SCHOLARLY_ATTESTED','Peer-reviewed abstract/introduction; original 1769 dispatch not yet read','AB-R7-POL-011','AB-NEW-073'),
('P07',1770,'Bengal','Bengal Council / EIC revenue officers','Tax maintenance alongside famine monitoring','Direct evidence of officials aware of hunger and continued collecting','Bengali cultivators and urban poor','DOCUMENTED_AWARENESS_WITH_POLICY_CONTINUATION','Recent historical analysis of correspondence; causation multifactorial','AB-R7-POL-012;AB-R7-POL-013','E18-B07'),
('P08',1771,'Bengal','EIC London Court of Directors','Letters ordering directly managed collection and investigating famine profiteering','Central directors intervene but evidence of consistent punishment missing','Bengali grain producers and landholders','KNOWLEDGE_AND_CONTESTED_ENFORCEMENT','Exeter West Bengal State Archive transcription incl petition and denial','AB-R7-POL-014;AB-R7-POL-035;AB-R7-POL-036','AB-NEW-074'),
('P09',1772,'Bengal land revenue','Bengal Committee of Revenue','14 May 1772 Committee and tax-farming scheme','Farmers bid for tax farming, coercive local remissions still disputed','Ryots, zamindars, indigenous revenue managers','CORPORATE_ORGANIZATIONAL','Exeter original transcription and BL parliamentary archive catalogue','AB-R7-POL-015','AB-NEW-074'),
('P10',1772,'Purnea and Tajpur','Company district government and local tax intermediaries','5 Aug ryot & landlord petitions / 24 Aug Collector denial','Petitions allege seizures, rent increases, torture; British official disputes','Purnea ryots, Raja Debi Singh, Ducarel','REPORTED_ABUSE_DISPUTED','Eyewitness petitions and official denial preserved; verdict not verified','AB-R7-POL-037;AB-R7-POL-038','E18-B07'),
('P11',1773,'Bengal-UK','British Parliament / EIC','East India Company Loan Act and Regulating Act','Government financial support and legal control while Company ruled','Company creditors, shareholders, Indian revenue payers','EXPLICIT_LEGAL_AUTHORIZATION','UK Parliament explanatory text; BL catalogue loan sum','AB-R7-POL-017;AB-R7-POL-018;AB-R7-ACT-06','AB-NEW-074'),
('P12',1783,'Bengal and India','British Parliament Select Committee','Ninth Report IOR/L/PARL/2/15/4','Formal scrutiny of fiscal remittance, cloth, opium, salt and judiciary','Indian laborers, salt makers, British trading interests','DOCUMENTED_PARLIAMENTARY_KNOWLEDGE','BL archive catalogue only, report body not independently examined','AB-R7-POL-020','AB-NEW-074'),
('P13',1784,'Company territories in India','British Government Board of Control','Pitt India Act','Crown-appointed oversight body directs Company policy','Company subjects, governors, directors','EXPLICIT_LEGAL_AUTHORIZATION','UK Parliament institutional history','AB-R7-POL-021','AB-NEW-074'),
('P14',1788,'Bihar and Benaras','Cornwallis and opium contractor governance','Contract terms weakened; 1788 official inquiry','Compulsion to grow poppy generally understood although contract text not explicit','Ryots, contractors, local opium traders','KNOWING_PERMISSIVE_PRACTICE','Cambridge peer-reviewed study extract; legal contract editions pending','AB-R7-POL-023','AB-NEW-075'),
('P15',1788,'Bengal salt market','EIC Bengal fiscal administration','Company salt auctions and fixed quotas','Monopoly sale sets price/revenue, with indigenous distributors still participating','Malangi makers, salt buyers and merchants','CORPORATE_ORGANIZATIONAL','Cambridge/Japanese journal peer-reviewed analyses','AB-R7-POL-024','AB-NEW-076'),
('P16',1788,'West Africa-Caribbean British ships','British Parliament / Customs / Admiralty','28 Geo III c54 Slave Trade Regulation','Authorized voyage density, customs logs, low-death bonuses and merchant claims for restriction loss','Enslaved Africans, crew, shipowners, British Treasury','EXPLICIT_LEGAL_AUTHORIZATION','Full text transcribed historical act; original parchment not personally checked','AB-R7-POL-025;AB-R7-ACT-01;AB-R7-ACT-02;AB-R7-ACT-03','AB-NEW-072'),
('P17',1789,'British slave shipping','British Parliament','29 Geo III c66 continued ship regulations','Continued regulated slave transports after public debate','Enslaved Africans','EXPLICIT_LEGAL_AUTHORIZATION','Full act transcription','AB-R7-POL-027','AB-NEW-072'),
('P18',1792,'British slave shipping','British Parliament','32 Geo III c52 continued Slave Trade Regulations','Law extended amid ongoing abolition debate','Enslaved Africans','EXPLICIT_LEGAL_AUTHORIZATION','Full act transcription','AB-R7-POL-029','AB-NEW-072'),
('P19',1793,'Bengal Bihar Orissa','EIC Governor-General Cornwallis / Directors','Regulations I and II of 1793','Permanently fixed assessments and separation of tax judiciary','Bengal landholders, ryots, district judges','EXPLICIT_LEGAL_AUTHORIZATION','Historical statute transcription with post-1793 editorial amendments','AB-R7-POL-030;AB-R7-POL-031','AB-NEW-078'),
('P20',1793,'India to Britain','Board of Control / British Parliament','1793 EIC Charter Act renewal','Renewed Asian trading monopoly with export-remittance goals','Indian revenue payers, British mercantile capital','GOVERNMENT_POLICY_SCHOLARLY_ATTESTED','Peer-reviewed economic study plus Parliament institutional chronology','AB-R7-POL-032','AB-NEW-073'),
('P21',1797,'Patna and Benaras','EIC Bengal government','Opium Agency System','Centralized opium production and procurement','Ryots, agency officers, private merchants','CORPORATE_ORGANIZATIONAL','Cambridge historical analysis','AB-R7-POL-033','AB-NEW-075'),
('P22',1799,'Patna/Benaras','EIC Bengal government','Regulation VI 1799','Prohibited private poppy growing and illegal sale; punitive rules','Ryots and local traders','EXPLICIT_COMPANY_REGULATION','Academic reading, historical regulation edition to cross-check','AB-R7-POL-034','AB-NEW-075'),
('P23',1799,'Freetown Sierra Leone','Sierra Leone Company London investors','Company settlers land policy','Company refused freehold land titles and settlers contested governance','Nova Scotia Black Settlers and local African residents','CORPORATE_ORGANIZATIONAL','UNB TNA CO270 collection overview; 1800 revolt different century','AB-R7-POL-041','AB-NEW-080'),
]
pol_hdr=['policy_id','anchor_year','area','decision_maker','document_or_instrument','coercive_or_extractive_mechanism','affected_people','evidence_strength_class','reading_and_conflict_notes','event_ids','new_candidate_id','source_ids','primary_manuscript_read','historical_control_polygon_verified']
out=[]
for id,yr,area,dm,doc,mech,peop,cls,notes,eids,cid in policies:
 found=[next(e for e in E if e['id']==i) for i in eids.split(';')]
 srcids=sorted(set(s for e in found for s in e['source_ids']))
 out.append(dict(zip(pol_hdr,[id,yr,area,dm,doc,mech,peop,cls,notes,eids,cid,';'.join(srcids),'false','false'])))
with (P/'SYSTEMIC_POLICY_ACCOUNTABILITY_MATRIX.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=pol_hdr);w.writeheader();w.writerows(out)
(W/'SEVENTH_ROUND_POLICY_MATRIX_CHECKPOINT.json').write_text(json.dumps({'policies':len(out),'last':out[-1]['policy_id']},ensure_ascii=False,indent=2)+'\n')

# Each major case gets a separately reviewable detailed narrative, not repeated factless summaries.
case_data={
'071':('国家立法组织西非奴役贸易','英国议会1750年法令不是私人贸易的边缘性口头许可，而是明确将种植园劳动力供应列为制度目的。Smithsonian藏1750历史印本说明法令重组西非商人公司、开放英国对非洲贸易；英国国家档案馆T70则保存贸易堡垒文书、堡内遭奴役者劳动及地方Fante社会的交涉。','国家法令和公司商贸体系构成持续制度链。Fante首领和非洲其他独立政体并不因公司在海岸拥有堡垒就丧失主权。','需要取得23 Geo II c31整册逐条影像及T70堡垒资产移交、获准贡金与用工名册，确定哪些堡垒实际换管、何时换管。'),
'072':('议会对奴役运输持续管理','1788年枢密院及议会已经调查奴役贸易，英国随后制定载人密度、关税登记、医生死亡记录、保险范围、超载罚金和死亡率分级奖励。法令并设商人损失审查委员会。1789、1792年法令继续允许但规制奴役运输；1807才正式禁止英国奴役贸易。','这是国家层级授权的最完整证据链：立法许可、监管、死亡报告、财政奖励、对损失作赔偿调查；各项法定预算/罚金/奖金不同于实际支付。','逐年核查船医航海死亡日志、海关罚款台账、法定奖金真实给付、申请补偿名单及起诉结果。未核实际补偿不能宣称已赔。'),
'073':('政府指示印度财政盈余转移','1765年公司取得Diwani财政权以后，税入、国库借贷和公司的出口采购混合影响其贸易能力。经济史学者Cuenca-Esteban明确指出英国政府1769年传达促进印度财政余额输英政策、1793年Dundas继续维护公司在亚洲垄断；海贸商品也常经中国商品形式结算。','这种系统政策与公司股东私人礼物是不同的利润渠道：税收毛入、净余额、资本利得、汇票和英国净国际收支不能全部相加。','需查1769政府—董事指令原本、年度Company investment表、亚洲贸易账及伦敦汇票登记，核每期净余额与贸易利润/海军军费。'),
'074':('公司财政危机后的国家介入与持续管治','1772公司金融危机推动英国议会调查，1773政府贷款并通过Regulating Act让公司继续治理印度领土，1784建立Board of Control。1783年议会第九报告档案列明丝、棉布、盐、鸦片、硝石和财政投资。Exeter档案另记1771董事接收税务直接管理命令。','国家对公司行为存在多层监督、贷款和政策设计，不能将1772调查说成议会已经批准每个贪污行为。当地纳瓦卜、zamindar和农民并非同一政府层级。','英国议会1773《规制法》、1783第九报告原卷、Bengal Committee of Circuit各pargana投标及惩戒决定均待全文逐页读。'),
'075':('鸦片农民被卷入国家采购制度','1773年Hastings掌握Patna鸦片采购并在合同限制强迫；后续禁强迫条款被取消，1788年Cornwallis发现部分农民被认为必须继续种植。1785年公司重新招标，1797年设Patna与Benaras鸦片代理，1799年第VI号规章禁止不合规定的私人种植。','有正式垄断，也有执法强迫知情线索，但应单列明确法权、默许的合同操作、承包商个人暴力及农民反抗的证据，不能全称法律明文授予鞭打权。','每个地区需要种植面积、合同最低供应价、交货与扣款、实际利润和惩处登记，以及1799原令译本。'),
'076':('食盐消费品成为公司财政垄断','孟加拉食盐已在公司生产与销售控制下，1788年公司改行拍卖定价，以提高财政收入。学者Miki及IRSH研究显示当地商业网络依然发挥定价与分销作用，故不能将本地商户从历史叙事中抹去。','盐工的低报酬、地方商人议价、民众购买负担需要按市场细分。约300万maund是制度定额概数，不是已运往英国的盐或实际出售量。','按年度检查Patna/Calcutta盐税销售表、盐工工资、拍卖价、黑市及质量登记，确认历史maund/sey计量。'),
'077':('普拉西后公共赔款与私人财产分流','Mir Jafar转款的历史账本存在1757–1759公司收付记录、1757–60股东会议、1764 Clive jagir对账、1765–1770 Calcutta土地毛净入账表；英国图书馆都给出具体分册编号，但这轮未看到原卷表格数字。','不能把Clive个人jagir、海军战利品、军官礼物与公司利润简单相加。Mir Jafar既有政治盟约及政权压迫，也是独立作出决定的地方君主。','优先领取Mss Eur G37/4/1 ff63–67；G37/11/2 ff30–32；G37/82/6 f48；G37/8/10 ff1–2，核原始单位、实际支付、年份及是否重复。'),
'078':('永久地税与民事司法分权的两面性','1793年Regulation I将1789–90各省十年期税额经董事批准转为长期固定，并确认若干地主产权。Regulation II将原由征税官兼任法官的Mal Adalat收入诉讼转至Diwani民事法院；这是为建立更可预测的产权和征税秩序。','法律文本自身强调地产经营与农作投资，但实际佃农租额、欠税没产及争讼费用对不同阶层作用分化。没有每个庄园地籍不可把现代省界当永久税制适用地实测图斑。','检查1793年原印法令修改版本、逐地主地契、1711/1793地税差异、法庭案件和农户份地。'),
'079':('英国纺织保护主义与印度商品进入英国市场的制度门槛','1701英国限制特定亚洲花布销售，1721通过国内棉布法令及殖民市场转运限制，1736又调整部分产业禁令。议会官网说明1721法令受本地纺织业请愿推动，剑桥研究证实东印度公司对英属美洲的进口路径获更有利地位。','欧洲贸易法和孟加拉织工的采购强迫是互补但不同的机制。Om Prakash指出第二个过程存在强迫中间商和工匠，但同时质疑“一夕之间纺织工业全灭”的简单叙述。','须补英国当年进口/转口布匹海关账、各产品豁免、孟加拉布价与织工工钱；不得仅靠禁令推算死亡与工业衰退率。'),
'080':('塞拉利昂自由居民被殖民公司限制土地权','新斯科舍黑人效忠派及其他居民迁抵塞拉利昂，曾选出tithingmen、hundreders参与自治；伦敦投资者掌握的Sierra Leone Company不让他们拥有完全土地自由保有权，1799年紧张加剧。UNB收藏TNA CO270 1792–1801记录，明载1800年爆发反抗。','公司号称自由定居和法权庇护，土地保障和居民政治权利却与投资者利益冲突。1799年的对抗与1800年的起义应分开。当地Temne等政治实体不能被当作无主地。','查TNA CO270/4–5自由保有权原文、Temne土地协议、settler选举和1800年法律请愿原稿；勿把19世纪土地规则提前。'),
}
for n in N:
 if n.get('coverage_expansion_round')!=7: continue
 suffix=n['candidate_id'][-3:]
 cases=[e for e in E if n['candidate_id'] in e.get('topic_ids',[]) and e['id'].startswith('AB-R7-')]
 head,desc,conclusion,gaps=case_data[suffix]
 md=[f'# {n["candidate_id"]}｜{n["title"]}','','> **research_only / 第七轮**；法定许可、组织实施、已知问题与个别越权必须分证据等级。','',f'## 历史过程与机制：{head}','',desc,'','## 归责与当地行动','',conclusion,'','## 本轮新增时间线与证据','']
 for e in cases:
  dt=str(e['year']) if e['year'] else str(e.get('year_window',{}))
  src='；'.join('['+k+']('+url(k)+')' for k in e['source_ids'])
  md.extend([f'### {e["id"]}｜{dt}｜{e["title"]}','',f'{e["action"]}','',f'**涉事主体**：{e["actors"]}。**地点/行政层级**：{e["location"]}。**来源**：{src}。','','**GIS限制**：不引入历史实控面，法规的通过地点与受影响的地区互不等同。',''])
 md.extend(['## 经济/人口证据与原卷缺口','',gaps,'','### 来源阅读深度','','| ID | 网址或档案 | 本轮实际阅读级别 |','|---|---|---|'])
 ids=set(n['source_ids'])|{i for e in cases for i in e['source_ids']}
 for x in sorted(ids):
  ss=b_id[x];md.append(f'| {x} | [{ss["title"]}]({ss["url"]}) | {ss["reading_level"]}；原史料纸卷未亲读 |')
 md.extend(['','**候审地图**：全部无可靠历史边界，本篇事件仅作为时间轴、财政/政策关联和将来核实堡垒或城市参考点的研究素材。',''])
 fn=P/'TOPIC_DOSSIERS'/'NEW_CANDIDATES'/f'{n["candidate_id"]}.md'; fn.write_text('\n'.join(md),encoding='utf-8')
# Critical main 37 dossier links: add focused additions without tampering published story IDs.
orig={
'E18-B01':['AB-NEW-079'], 'E18-B03':['AB-NEW-077'], 'E18-B07':['AB-NEW-073','AB-NEW-074'], 'E18-B08':['AB-NEW-074'], 'E18-B09':['AB-NEW-074'], 'E18-B16':['AB-NEW-078'], 'E18-B17':['AB-NEW-073','AB-NEW-074'], 'E18-B18':['AB-NEW-073','AB-NEW-077'], 'E18-B19':['AB-NEW-076','AB-NEW-079'], 'E18-B20':['AB-NEW-075'], 'E18-E09':['AB-NEW-080'], 'E18-E10':['AB-NEW-071','AB-NEW-072']}
for k,refs in orig.items():
 fn=P/'TOPIC_DOSSIERS'/f'{k}.md'
 if not fn.exists():continue
 old=fn.read_text();anchor='## 第七轮制度化政策与责任链补充'
 if anchor in old:continue
 block='\n'+anchor+'\n\n'+('、'.join(f'`{x}`' for x in refs))+' 对原母题提供新的议会、公司董事会、法律、政策/人口与监管知情证据。原母题ID不变；请依新专题独立正文、事件和 `SYSTEMIC_POLICY_ACCOUNTABILITY_MATRIX.csv` 核对，不要推断所有具体暴力均由法令逐项批准。\n'
 fn.write_text(old+block,encoding='utf-8')
print('CHECKPOINT C 10 DOSSIERS+MAIN APPENDICES+POLICY MATRIX',len(out),'rows')
