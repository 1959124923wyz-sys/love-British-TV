"""Fifth round second checkpoint: 1753 Fante treaty and labor; 1796 Moluccas; 1799 Cape resistance. Local only."""
from pathlib import Path
import csv,json
P=Path('/mnt/data/18c_assistant_B');W=P/'WORKING'
def load(f):return json.loads((P/f).read_text(encoding='utf-8'))
def save(f,x):(P/f).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def cr(f):
 with (P/f).open(encoding='utf-8-sig',newline='') as fi:
  rdr=csv.DictReader(fi);return rdr.fieldnames,list(rdr)
def cw(f,fields,rows):
 with (P/f).open('w',encoding='utf-8-sig',newline='') as fo:
  w=csv.DictWriter(fo,fieldnames=fields);w.writeheader();w.writerows(rows)
S=load('SOURCE_REGISTRY.json');E=load('EVENT_CANDIDATES.json');N=load('NEW_CANDIDATES.json');ff,F=cr('ECONOMIC_EVIDENCE.csv');tf,T=cr('CONTROL_TRANSITIONS_B_E.csv');ef,ER=cr('EVENT_CANDIDATES.csv')
before={'sources':len(S['sources']),'events':len(E['events']),'economic':len(F),'control':len(T),'new':len(N['candidates'])}
SNEW=[
('BS194','The National Archives, UK','Enslaved and Indigenous people: Reading against the grain in the colonial archive','https://www.nationalarchives.gov.uk/explore-the-collection/stories/reading-against-the-grain-in-the-colonial-archive/','institutional_digitised_document_transcription_indexed_search_full_excerpt;site_403_on_direct_open','T 70/1526/22; T 70/1695/1','1753 Fante agreement dated 6 Feb in copied transcribed text; site describes 7 Feb; includes pledged four persons; original sheets not personally examined.'),
('BS195','Philippa Hellawell and Briony Widdis, Cambridge Africa Bibliography (2026)','The enslaved, the Fante, and the governors: rediscovering the Detached Papers','https://www.cambridge.org/core/journals/africa-bibliography-research-and-documentation/article/abs/enslaved-the-fante-and-the-governors-rediscovering-the-detached-papers-of-the-company-of-merchants-trading-to-africa/D8E11D351868A2F9B34ABCEB3C46D26D','peer_reviewed_abstract_read','T 70 Detached Papers','Describes Fante political diplomacy, enslaved labor and lost archival silences; article body requires access.'),
('BS196','British Library India Office Records','IOR/H/441 expedition to the Molucca Islands, Walter Caulfield Lennon journal, 1795–1796','https://searcharchives.bl.uk/catalog/040-000004502','archive_catalogue_only','IOR/H/441','pp. 1–204 expedition 12 Oct 1795–18 June 1796; pp.205–310 management recommendations; actual manuscript not read.'),
('BS197','British Library India Office Records','IOR/G/21/10 Factory Records: Java, 1796 accounts Amboyna Banda Tidore','https://searcharchives.bl.uk/catalog/040-000177056','archive_catalogue_only','IOR/G/21/10','File mixes 1796 account and unrelated 1811–12 Java journal; 1796 account original not read, accessible via institutional subscription.'),
('BS198','Richard Hiscocks, naval historian','The Capture of Colombo and the Molucca Islands – February–March 1796','https://morethannelson.com/the-capture-of-colombo-and-the-molucca-islands-february-march-1796/','historical_naval_research_full_html_read','','Events Amboyna 16–17 Feb; Banda 8–9 Mar; cash and spices; later secondary synthesis, not proven prize ledger.'),
('BS199','Sir Edward Cust, third edition (1869), digitised historical monograph','Annals of the Wars of the Eighteenth Century, Volume V 1796–1799','https://upload.wikimedia.org/wikipedia/commons/a/a1/1796_-_1799_%28IA_in.ernet.dli.2015.463034%29.pdf','nineteenth_century_retrospective_indexed_pdf_text_read_screenshot_failed_file_32MB','','Moluccas 16 Feb arrival and vaguely first March takeover (disagrees 17 Feb historian); claims each of 5 captains £15000; original 1796 correspondence not read.'),
('BS200','South African History Online','Eastern Cape Wars of Dispossession 1779–1878','https://sahistory.org.za/article/eastern-cape-wars-dispossession-1779-1878','institutional_regional_history_full_html_read','','1799 Graaff-Reinet Boer uprising, Vandeleur repression, Xhosa/Khoikhoi fighting, Gqunukwebe and partial peace, local agency.'),
('BS201','Denver Webb, Scientia Militaria (2014)','The Third War of Dispossession and Resistance in the Cape of Good Hope Colony, 1799–1803','https://scientiamilitaria.journals.ac.za/pub/article/view/1094','peer_reviewed_abstract_full_read_pdf_not_read','doi:10.5787/42-2-1094','First British Army/Xhosa and Khoikhoi encounter; 1799–1803 multi-actor conflict, 1800+ out of 18th century.'),
]
exists={x['id'] for x in S['sources']}
for id,ins,title,url,rl,archive,notes in SNEW:
 assert id not in exists
 S['sources'].append({'id':id,'institution':ins,'title':title,'url':url,'reading_level':rl,'archive_identifier':archive or None,'notes':notes,'original_manuscript_personally_inspected':False,'consulted_on':'2026-11-08'})
S['source_count']=len(S['sources']);S['schema']='18c-assistant-B-source-v5';url_by_id={s['id']:s['url'] for s in S['sources']}
NEWS=[('AB-NEW-054','1796年英军占领安汶、班达香料堡垒、缴获库存与军官奖金','E18-E11','海军占据荷兰据点为短时战争军事占领；香料缴获和银钱仓库须区别公司净利、军官个人分配；当地社会政治与香料采集劳动另核','BS196;BS197;BS198;BS199'),('AB-NEW-055','1799年开普Graaff-Reinet镇压及Khoikhoi—Xhosa土地抵抗','E18-E06','英国军队首先镇压布尔人地方反抗，随后与Khoikhoi和Xhosa及Gqunukwebe发生多方边境冲突；Zuurveld史界不能据此假装英国全部管治','BS200;BS201')]
for cid,title,orig,reason,sources in NEWS:
 assert cid not in {n['candidate_id'] for n in N['candidates']}
 N['candidates'].append({'candidate_id':cid,'title':title,'related_original_topic_id':orig,'rationale':reason,'source_ids':sources.split(';'),'decision':'propose_to_editor'})
EV=[]
def event(id,topics,y,m,d,title,actors,loc,action,effect,sources,precision='day',confidence='published_document_or_secondary_history;original_manuscript_unread'):
 e={'id':id,'topic_ids':topics.split(';'),'year':y,'month':m,'day':d,'date_precision':precision,'title':title,'actors':actors,'location':loc,'action':action,'political_effect':effect,'source_ids':sources.split(';'),'source_urls':[url_by_id[s] for s in sources.split(';')],'research_status':'candidate_not_published','map_state':'not_yet_geocoded','geometry_id':None,'confidence':confidence,'historical_control_boundary_verified':False,'actual_British_control_area_sqkm':None}
 assert id not in {x['id'] for x in E['events']};EV.append(e)
# West Africa, with source contradictions held explicitly
event('AB-F5-GH-025','E18-E10;AB-NEW-047',1753,2,None,'Fante首领与英国西非商人公司签署限制法国驻地协议：原文6日／机构目录7日','Fante chiefs; Company of Merchants Trading to Africa','Cape Coast Castle','英方抄录文件称2月6日签署，英国国家档案馆索引标为2月7日；Fante领袖名单及印记T 70/1695/1，另抄本文本T70/1526/22；双方的意图及文字起草权不等同。','negotiated_diplomacy_not_british_sovereignty','BS194;BS195','month','dated_6_or_7_feb_conflict')
event('AB-F5-GH-026','E18-E10;AB-NEW-047',1753,2,None,'Fante领袖在协议中提交四名人质／抵押人，以保证禁法条款','Fante headmen; four pawned individuals; Cape Coast Company officials','Cape Coast Castle','殖民档案将四名pledges称作hostages；属于当地债务与承诺担保制度，个人身份和后续处境不明，不可当作被出售的奴隶人数。','coercive_diplomatic_security_persons_not_sale','BS194','month')
event('AB-F5-GH-027','E18-E10;AB-NEW-047',1753,4,22,'阿诺马布工程师报告已束缚12名新奴役砖匠、另申请40名冈比亚劳工','John Apperley; enslaved African workers; Company of Merchants','Anomabo / Fort William','工程师1753年4月22日函称已将12名新奴役者安排受训砖匠，申请再送40人；后者仅申请未证明实际运抵。','compulsory_building_labor_and_unfulfilled_proposal','BS179')
event('AB-F5-GH-028','E18-E10;AB-NEW-047',1753,8,18,'英方在三次当地阻止施工后才为阿诺马布新堡奠基','John Apperley; Anomabo town magistrates and inhabitants','Anomabo / Fort William','Apperley同年10月11日来函回顾8月18日部分堡垒奠基；称居民曾三次中止工作，最终由当地官员及居民在场同意，证据是英方单方记录。','negotiated_fort_construction_not_territorial_conquest','BS179','day','first_hand_letter_reproduced_in_1923_compilation')
event('AB-F5-GH-029','E18-E10;AB-NEW-047',1753,10,11,'英方阿诺马布工程师书面报告堡垒仅有8名泥瓦匠及18名劳工','John Apperley; company building work force; local community','Anomabo','施工规模为该日工程师自报，无法据此推算被奴役者总数或城堡扩张面积；法国造堡报价£40,000也是英国工程师转述传闻。','workforce_snapshot_not_enslaved_worker_population','BS179')
event('AB-F5-GH-030','E18-E10;AB-NEW-047',1754,9,25,'西非商人公司批准支付照护两名Fante少年费用£79 4s 1d','George Cockburn; Company of Merchants; Fante boys Aqua and Sackee','London / Wombwell Hall','1754年9月25日会议记确认截至7月22日照管两名少年账单£79 4s 1d并命令偿付；汇款实际到账凭证未见。','corporate_expenditure_authorization_pawnship_context','BS179')
event('AB-F5-GH-031','E18-E10;AB-NEW-047',1754,10,23,'公司向海军部申请将两名Fante少年乘Gosport舰送回西非','Company of Merchants; Fante boys Aqua and Sackee; Admiralty','London / Rochester / Africa proposed','会议命令写信安排上船归返；此处仅为命令，实际归返需与后续1755年说明分开。','return_journey_order_not_proof_of_arrival','BS179')
# Moluccas Royal Navy, only localized forts
for a in [
('AB-F5-SE-001',1796,1,6,'英国海军从马六甲出发准备夺取荷属摩鹿加香料岛','Commodore Peter Rainier; Royal Navy; EIC auxiliary ships','Malacca','Rainier舰队从马六甲出航；舰队航路不得据此画精确海上轨迹。','naval_departure_not_land_control'),
('AB-F5-SE-002',1796,2,16,'英国舰队抵达安汶岛近海','Rear Admiral Peter Rainier; VOC defenders','Ambon / Amboyna','海军史研究确认舰队16日抵港，实际占堡另记17日。','expedition_arrival_not_occupation'),
('AB-F5-SE-003',1796,2,17,'John Kennedy率英军进驻安汶荷兰堡垒，荷军未战投降','Major John Kennedy; Royal Navy; Dutch VOC','Ambon / Amboyna fort','海军史研究称17日无战斗进入堡垒；1869历史回顾笼统称三月初占有，具体时日须向IOR/H/441核对。','named_dutch_fort_temporary_military_capture'),
('AB-F5-SE-004',1796,3,8,'英军登陆班达群岛并遭荷属炮台抵抗','John Kennedy; Rainier Royal Navy; Dutch batteries','Banda Islands / Fort Nassau','舰队依战术船只掩护登陆，遭荷兰两座炮台抵抗；荷军打坏炮机撤退，同晚荷兰总督谈判投降。','fought_landing_and_capitulation_not_wider_archipelago_sovereignty'),
('AB-F5-SE-005',1796,3,9,'英军进入班达堡垒并驻留，不涵盖全部班达岛民地权','Major John Kennedy; Dutch VOC garrison','Banda / Fort Nassau','英国海军纪事称3月9日Kennedy进入Fort Nassau，驻留部队以英印雇佣兵混编；当地生产和土地权未逐地核验。','named_fort_garrison_takeover'),
('AB-F5-SE-006',1796,6,18,'英国图书馆馆藏摩鹿加远征日记止于6月18日','Captain Walter C Lennon; Company of Merchants / Royal Navy','Amboina and Banda','IOR/H/441日记范围截止6月18日；这是原档覆盖末日而非英军撤离日。','archive_end_date_not_control_end'),
]:
 id,y,m,d,t,actors,loc,act,effect=a
 event(id,'E18-E11;AB-NEW-054',y,m,d,t,actors,loc,act,effect,'BS196;BS198' if id!='AB-F5-SE-006' else 'BS196')
# Cape Third Frontier War
for a in [
('AB-F5-ZA-001',1799,1,None,'开普Graaff-Reinet布尔居民再次反抗殖民政府','Graaff-Reinet Boer frontiersmen; British Cape governor','Graaff-Reinet','1799年1月驻地布尔殖民者反抗英国第一占领时期政府；此与稍后Khoikhoi/Xhosa抵抗是不同群体的行动。','settler_rebellion_against_colonial_government'),
('AB-F5-ZA-002',1799,3,None,'Vandeleur率英军镇压Graaff-Reinet布尔居民反抗','General T P Vandeleur; British regular soldiers; rebel Boers','Graaff-Reinet','英军于1799年3月行动镇压布尔叛乱；英国财政和军数尚无原始核。','crown_military_repression_of_frontier_burghers'),
('AB-F5-ZA-003',1799,4,None,'开普Khoikhoi人与Xhosa人结盟反抗农庄及土地侵占','Khoikhoi rebels; Xhosa allies; Boer settler farmers','Zuurveld / Eastern Cape','4月起Khoikhoi及Xhosa与殖民占地者冲突，分清各社区目的与阵营流动。','indigenous_anti_dispossession_resistance'),
('AB-F5-ZA-004',1799,7,None,'1799年东开普冲突扩大至Oudtshoorn一带','Khoikhoi; Xhosa; British and Boer frontier troops','Oudtshoorn','殖民历史年表称至1799年7月冲突蔓延到Oudtshoorn；地点只是区域达到的描述，不能直接绘制战线、点缓冲面。','frontier_conflict_geographic_extent_uncertain'),
('AB-F5-ZA-005',1799,None,None,'Gqunukwebe武装在英军返回Algoa Bay途中阻击','Gqunukwebe Xhosa clan; British Vandeleur troops','Algoa Bay route / Zuurveld','南非史资料记载Gqunukwebe部族担心遭驱逐而袭击返程英军，未确认精确战地与日期。','indigenous_resistance_to_expulsion'),
('AB-F5-ZA-006',1799,None,None,'殖民当局在1799年谈判中允许Xhosa继续留在Zuurveld','British Cape government; Xhosa chiefdoms; Khoikhoi','Zuurveld','当局畏惧Khoikhoi普遍起义，选择议和并让Xhosa留在Zuurveld；实际各社区管辖与地图边界需核对，非英军全面征服。','negotiated_nonexpulsion_not_annexation'),
]:
 id,y,m,d,t,actors,loc,act,effect=a
 event(id,'E18-E06;AB-NEW-055',y,m,d,t,actors,loc,act,effect,'BS200;BS201','month' if m else 'year')
# Source-preserving numeric facts. No currency conversions. 
FNEW=[]
def econ(id,topics,y,val,currency,definition,payer,recipient,period,sources,role,limit):
 FNEW.append({'id':id,'topic_ids':topics,'year_start':str(y),'year_end':str(y),'value':str(val),'currency_or_unit':currency,'metric_definition':definition,'payer_or_affected':payer,'recipient_or_observer':recipient,'accounting_period':period,'source_ids':sources,'source_urls':';'.join(url_by_id[s] for s in sources.split(';')),'source_reading_level':'published_transcription_or_secondary_report_original_archive_unread','source_role':role,'verification_status':'reported_historical_document_not_cash_receipt','was_primary_manuscript_personally_read':'False','actual_received_or_transferred_verified':'False','numerator_denominator':'','interpretation_limit':limit})
econ('FISC-F5-Fante-pawns1753','E18-E10;AB-NEW-047',1753,4,'persons_pledged','Fante treaty presented four persons as pledges for compliance, not a sales ledger','Fante political leadership','Company of Merchants at Cape Coast','1753-02','BS194','colonial_treaty_transcription','No whereabouts/outcome attested; personal coercion and kinship/legal category distinct from enslaved people traded')
econ('FISC-F5-Anomabo-bound-bricklayers','E18-E10;AB-NEW-047',1753,12,'persons_enslaved_training_report','Apperley April 22 report: bound twelve new slaves as bricklayers','Enslaved African workers','Company of Merchants fortress construction','1753-04-22','BS179','engineer_letter_1923_reprinted','A self-reported worker count in training, not entire fort enslaved labor force')
econ('FISC-F5-Anomabo-request-only','E18-E10;AB-NEW-047',1753,40,'persons_request_only','Apperley asked London committee to import forty male slaves from Gambia for training','Gambian people targeted by trafficking','British African company letter','1753-04-22','BS179','letter_request','Explicit request only; cannot count as actually transported or paid')
econ('FISC-F5-Anomabo-octwork-masons','E18-E10;AB-NEW-047',1753,8,'persons_mason_workers_report','October 11 letter says eight masons currently at building site','Fort builders','John Apperley','1753-10-11','BS179','engineer_letter','Not definitely eight enslaved masons; cannot merge with April workers')
econ('FISC-F5-Anomabo-octwork-laborers','E18-E10;AB-NEW-047',1753,18,'persons_laborers_report','October 11 letter says eighteen labourers currently at site','Fort workers','John Apperley','1753-10-11','BS179','engineer_letter','Laborer employment/enslavement statuses not specified in this line')
econ('FISC-F5-Fante-boys-care-invoice','E18-E10;AB-NEW-047',1754,79.2041667,'GBP_nominal_from_79_pounds_4_shillings_1_penny','1754 Sept25 merchant committee ordered payment of £79 4s 1d for two Fante boys to July22','Company of Merchants','Capt George Cockburn','1754-09-25','BS179','committee_order_reproduced','Original historical value £79 4s 1d; decimal for searchable calculation only; payment ordered not bank-cleared')
econ('FISC-F5-Amboyna-cash-rd','E18-E11;AB-NEW-054',1796,81112,'rijksdaalders_reported_dutch_treasury','Historical naval summary reports 81,112 Dutch rijksdaalders found in Amboyna treasury','Dutch VOC treasury','British captors','1796-02-17','BS198','secondary_naval_history','Stock of Dutch cash seized, not British net revenue or proof UK remittance')
econ('FISC-F5-Amboyna-cannons','E18-E11;AB-NEW-054',1796,85,'cannons_inventory_reported','Amboyna fort reportedly held 85 cannon','Dutch VOC garrison','Royal Navy invaders','1796-02-17','BS198','secondary_naval_history','Not cash income or territorial area; reported garrison inventory')
econ('FISC-F5-Amboyna-cloves-lower','E18-E11;AB-NEW-054',1796,500000,'pounds_weight_cloves_lower_bound','Historical account describes more than half a million pounds weight cloves at Amboyna','Dutch colonial spice warehouses; producer labor','Royal Navy captors','1796-02','BS198','secondary_naval_history','Conservative lower threshold, NOT exact 500000 lbs and not a net cash receipt')
econ('FISC-F5-Banda-cash-rd','E18-E11;AB-NEW-054',1796,66675,'rijksdaalders_reported_dutch_treasury','Historical naval summary reports 66,675 rijksdaalders in Banda treasury','Dutch VOC treasury','British captors','1796-03-09','BS198','secondary_naval_history','Captured stock, not realised net treasure')
econ('FISC-F5-Banda-nutmeg-lbs','E18-E11;AB-NEW-054',1796,84477,'pounds_weight_nutmegs_reported','Banda inventory reported 84,477 lb nutmegs in naval summary','Dutch VOC stores','Royal Navy captors','1796-03-09','BS198','secondary_naval_history','Original 1796 company inventory not seen; alternate online 84,777 must be checked against IOR/H/441; do not claim exact independently verified')
econ('FISC-F5-Banda-mace-lbs','E18-E11;AB-NEW-054',1796,19587,'pounds_weight_mace_reported','Banda inventory reported 19,587 lb mace','Dutch VOC stores','Royal Navy captors','1796-03-09','BS198','secondary_naval_history','Spice inventory mass not sterling sales proceeds')
econ('FISC-F5-Banda-cannons','E18-E11;AB-NEW-054',1796,310,'cannons_approximate_reported','Banda defenses described as over 310 cannon','Dutch colonial garrison','Royal Navy','1796-03-09','BS198','secondary_naval_history','This is a lower threshold not exact 310')
econ('FISC-F5-Moluccas-prize-captain','E18-E11;AB-NEW-054',1796,15000,'GBP_per_naval_captain_historical_retrospective','1869 Cust and later naval historian claim £15,000 prize money each for five captains','Captured Dutch naval and spice prizes','Individual British naval captains','1796 campaign','BS198;BS199','1869_historical_retrospective','Per recipient estimate, NOT company profit nor five times independently cleared; original prize distribution register not inspected')
for r in FNEW:assert r['id'] not in {z['id'] for z in F};F.append(r)
TNEW=[]
def tran(id,date,place,before,after,actors,meaning,sources,event,limit):
 TNEW.append({'id':id,'date':date,'place':place,'from_status':before,'to_status':after,'actors':actors,'control_semantics':meaning,'historical_boundary_verified':'false','area_sqkm':'','geometry_policy':'named_site_point_or_unmapped_only','source_ids':sources,'related_event_id':event,'uncertainty':limit})
tran('T071','1753-02','Fante polities / Cape Coast','Fante autonomous local jurisdiction and English trading forts','Negotiated restriction on French settlement with four pawns pledged','Fante leaders; Merchants Company','treaty_diplomacy_not_territorial_cession','BS194;BS195','AB-F5-GH-025','Source says signed 6 Feb but TNA webpage dates 7 Feb; local Fante autonomy survives')
tran('T072','1753-08-18','Anomabo Fort William','Smaller coastal English trading fort; Fante local neighborhoods around','Work begins on enlarged fort after negotiated local assent','Fante town chiefs and inhabitants; John Apperley','fort_building_authorization_not_automatic_territorial_control','BS179','AB-F5-GH-028','No reconstructed physical footprint; revised plan local legal agreement, not carte blanche')
tran('T073','1796-02-17','Amboyna / Ambon named Dutch fort','VOC Dutch fort garrison','British naval forces occupy fort and warehouses','Peter Rainier; John Kennedy; Dutch VOC','temporary_military_capture_of_named_fort','BS196;BS198;BS199','AB-F5-SE-003','1869 retrospective imprecisely dates takeover early March; archive diary needed for exact day')
tran('T074','1796-03-08','Banda / Fort Nassau','Dutch VOC fort garrison and spice stores','Dutch garrison capitulates following British attack','Dutch colonial governor; John Kennedy','short_war_capture_of_colonial_fort','BS196;BS198','AB-F5-SE-004','Fort not entire Banda sovereign archipelago')
tran('T075','1796-03-09','Banda / Fort Nassau','Dutch fort has just surrendered','British mixed troop garrison installed','Royal Navy; John Kennedy; Dutch VOC','actual_named_british_fort_garrison','BS196;BS198','AB-F5-SE-005','No local island-wide land jurisdiction verified')
tran('T076','1799-01','Graaff-Reinet Cape','First British Cape colonial administration','Revolt by Boer frontier townspeople','Graaff-Reinet Boer burghers; British military administration','contested_settler_local_government','BS200;BS201','AB-F5-ZA-001','Town protest cannot be turned into geography of all Cape')
tran('T077','1799-03','Graaff-Reinet Cape','Boer rebellion ongoing','British military suppression campaign by Vandeleur','British soldiers; Boer rebels','counter_insurgency_not_new_land_annexation','BS200;BS201','AB-F5-ZA-002','Date month only, no claim of expanded sovereignty')
tran('T078','1799-04','Zuurveld eastern Cape','Multiple Xhosa communities and settler farms contested','Khoikhoi and Xhosa resistance and renewed border war','Khoikhoi; Xhosa; local Boer farmers','indigenous_land_and_labor_resistance','BS200;BS201','AB-F5-ZA-003','No historic operational border traced; map only contested named study region with archival boundary if obtained')
tran('T079','1799','Zuurveld eastern Cape','British demand expulsion contested by Xhosa armed communities','Some negotiated Xhosa retention of Zuurveld','Cape colonial authorities; Xhosa chiefly groups','negotiated_withdrawal_nonexpulsion','BS200','AB-F5-ZA-006',"Xhosa communities’ precise territories require independent sources; 1801–1803 excluded from this dataset")
for t in TNEW:assert t['id'] not in {x['id'] for x in T};T.append(t)
E['events'].extend(EV);save('SOURCE_REGISTRY.json',S);save('EVENT_CANDIDATES.json',E);save('NEW_CANDIDATES.json',N);cw('ECONOMIC_EVIDENCE.csv',ff,F);cw('CONTROL_TRANSITIONS_B_E.csv',tf,T)
for e in EV:
 row={k:'' for k in ef}
 for k in ef:
  v=e.get(k);v=';'.join(map(str,v)) if isinstance(v,list) else v
  row[k]='' if v is None else str(v)
 ER.append(row)
cw('EVENT_CANDIDATES.csv',ef,ER)
# report two new dossiers
for cid,title,orig,reason,sids in NEWS:
 related=[e for e in EV if cid in e['topic_ids']];amount=[x for x in FNEW if cid in x['topic_ids'].split(';')];states=[t for t in TNEW if t['related_event_id'] in {e['id'] for e in related}]
 lines=[f'# {cid}｜{title}','','**独立研究候选 `research_only`，未发表，非17世纪历史版图继承。**',f'原母题：`{orig}`；不会修改项目原ID。','','## 政治与经济机制',reason,'','## 具体事件、证据与空间含义']
 for e in related:
  date=f"{e['year']}-{str(e['month']).zfill(2) if e['month'] else '??'}-{str(e['day']).zfill(2) if e['day'] else '??'}"
  lines.append(f"- **{date} {e['title']}**（`{e['id']}`）：{e['action']}；历史权力类别：{e['political_effect']}。来源：{', '.join(e['source_ids'])}。")
 lines+=['','## 金钱、物资、人口分别入账（不可加总为英国净掠夺）']
 for x in amount:lines.append(f"- `{x['id']}`：**{x['value']} {x['currency_or_unit']}**。{x['metric_definition']}。限制：{x['interpretation_limit']}")
 if not amount:lines.append('- 本轮并无可核财务原卷数据，不填造。')
 lines+=['','## 真实控制转换（边界仍留空）']
 for t in states:lines.append(f"- `{t['id']}` {t['date']} {t['place']}：{t['from_status']} → {t['to_status']}；**{t['control_semantics']}**。{t['uncertainty']}")
 lines+=['','## 来源／阅读状态']
 for sid in sids.split(';'):
  s=next(x for x in S['sources'] if x['id']==sid)
  lines.append(f"- `{sid}`｜{s['institution']}｜{s['title']}｜{s['url']}｜阅读：{s['reading_level']}｜档号：{s['archive_identifier'] or '无'}；原始手稿亲阅：**否**。")
 lines+=['','## 下一步核实与制图', '- 从英国图书馆卷 `IOR/H/441` 与 `IOR/G/21/10` 校验1796年实际占堡日期、缴获库存和军官奖金；不得用现代群岛Polygon涂色。' if cid=='AB-NEW-054' else '- 调取英国开普殖民军日记及Xhosa/Khoikhoi地方材料，校勘Gqunukwebe战场和谈判责任。','- 无实测历史领土多边形，`area_sqkm=null`；暂不制造新的经纬度。','- 原国家、殖民公司、地方统治者或居民及抵抗者的关系分层绘制。']
 (P/'TOPIC_DOSSIERS'/'NEW_CANDIDATES'/f'{cid}.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
# enhance prior key sources without overwriting
for code,related in {'E18-E10':[e for e in EV if e['id'].startswith('AB-F5-GH')], 'E18-E11':[e for e in EV if e['id'].startswith('AB-F5-SE')],'E18-E06':[e for e in EV if e['id'].startswith('AB-F5-ZA')]}.items():
 path=P/'TOPIC_DOSSIERS'/f'{code}.md'; assert path.exists()
 add='\n## 第五轮第二批：地方主体、远征堡垒与新发现遗漏案（2026-11-08）\n'
 for e in related:add+=f"- `{e['id']}` {e['year']} {e['title']}。{e['action']}。来源{','.join(e['source_ids'])}；`research_only`。\n"
 path.write_text(path.read_text(encoding='utf-8')+add,encoding='utf-8')
newcount={'sources':len(S['sources']),'events':len(E['events']),'economic':len(F),'control':len(T),'new':len(N['candidates'])}
print('BATCH2:',before,'=>',newcount)
(W/'FIFTH_ROUND_BATCH2_CHECKPOINT.json').write_text(json.dumps({'date':'2026-11-08','round':'fifth_round_batch2','initial':before,'after':newcount,'new_source_ids':[x[0] for x in SNEW],'new_event_ids':[x['id'] for x in EV],'new_economic_ids':[x['id'] for x in FNEW],'new_control_ids':[x['id'] for x in TNEW],'new_topic_ids':[x[0] for x in NEWS],'notes':'TNA 1753 treaty webpage says 7 Feb but signed-text says 6 Feb, set month precision; Cust 1869 ambiguous ambon capture March vs naval history Feb 17; Company manuscript originals only catalogued, no fake territorial polygons; annual totals not realized net.'},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
