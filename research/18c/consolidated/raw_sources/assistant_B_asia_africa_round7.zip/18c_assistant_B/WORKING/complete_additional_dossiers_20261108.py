"""2026-11-08 addendum: independently documented dossiers, site transitions and evidence notes. Local only."""
import json,csv,pathlib,collections,datetime,textwrap
P=pathlib.Path('/mnt/data/18c_assistant_B')
S={s['id']:s for s in json.loads((P/'SOURCE_REGISTRY.json').read_text(encoding='utf-8'))['sources']}
N={n['candidate_id']:n for n in json.loads((P/'NEW_CANDIDATES.json').read_text(encoding='utf-8'))['candidates']}
E=json.loads((P/'EVENT_CANDIDATES.json').read_text(encoding='utf-8'))['events']
with (P/'ECONOMIC_EVIDENCE.csv').open(encoding='utf-8-sig',newline='') as f: F=list(csv.DictReader(f))

d={
'AB-NEW-018': {
 'background':'''贝拿勒斯的案例不能用“英国征服城市”概括。1775年阿瓦德与公司间权利调整后，公司就Chait Singh所掌Benares与Ghazipur的zamindari地租／年款取得直接协商地位。1776年4月15日的sanad明确作为一份独立文书存在，具体地权、司法、军事征调义务须逐条读全文，不可由签约这一个动作推断所有村社已经进入英属直辖。''',
 'detail':'''Fisher编辑的十八世纪士兵旅行叙事提供了Hastings追加战时征索、1781年拘捕Chait Singh失败、军队撤往Chunar及其后地方继任政治重组的完整链条。记载的原定约2,340,249卢比年款、其后4,000,000卢比要求应分别登记为不同年度与法律口径，不能算作既已征收的现金；“额外要求”中征兵与现金亦不可以双算。1781年11月Bijigarh堡垒交降后约400万卢比的现银、首饰等属于缴获财物估计，与军官的294,000卢比、22,478卢比、士兵50卢比分发口径存在包含关系，不能累加成公司总净收益。公司事后索回军奖显示战利品占有与归公司财产并非同一回事。''',
 'agency':'''Chait Singh的抵抗、地方军队的行动及继任Mahip Narain的zamindari关系须独立叙述。1782年村民对军官Baker私自索财的指控，学术编辑亦提到军官受到调查并获澄清；应在地图写成“地方投诉—召回调查”，而非刑责已经确认。''',
 'map':'''贝拿勒斯、Chunar、Bijigarh、Ghazipur、Kalpi是互不相同的事件和税收地点；无原地籍时只画具名点，不能把今日北方邦边界当英国1781年治地。''',
 'critical':['IOR/H/633 pp.47–56 的1776 zamindari sanad全文与1781 pp.73–90继任约文','1781军队缴获原始估价册、军奖领取名单及Company追回账','Hastings—公司董事来信与Chait Singh、Mahip Narain的印度语契据'],'fiscal':['FISC-BENARES','FISC-BIJIGARH','FISC-BENA']},
'AB-NEW-019': {
 'background':'''1772年公司对孟加拉和比哈尔食盐生产的制度性控制是本世纪重要财政机制，具有粮食以外的独立商品税负与劳动关系。Sayako Kanda的研究将盐工（molungoes）、燃料市场、生产成本与环境变化纳入分析；销售侧专卖制度和沿海制盐的劳动实践是不同环节。''',
 'detail':'''1788年出现公司控制的盐品公开拍卖制度，Sayako Miki的研究明确地方批发商和孟加拉商人仍在销售网络中发挥作用。因此“东印度公司垄断盐”要写清是生产、批发分销还是拍卖定价，不可写成所有私人食盐交易停止。英国图书馆IOR/L/PARL/2/9a现为馆藏目录，可定位盐工待遇的议会文书条目，但尚无具体名册、盐价与工人日薪数据。''',
 'agency':'''印度盐工、地方经销商、地方富商和各地生产地权主体不是同一社会群体。盐业利润不能并入粮食贸易利润证明1770饥荒成因，1772改革也不能倒写到1769年。''',
 'map':'''仅在取得具体盐场、拍卖所、公司盐署和历史地名的原档证据后提出点图。不得拿整个孟加拉、比哈尔的现代行政轮廓作公司的食盐实控面积。''',
 'critical':['1772公司设立盐业生产专卖的董事决议条款','1788盐拍卖数量、成交价、投标人及费税分解','具体molungee契约和燃料供应档案'],'fiscal':[]},
'AB-NEW-020':{
 'background':'''“战利品”“赎金”“战争赔款”“公司征税”“英国军官私产”是五种不同收入法律属性。英国图书馆IOR/H/83列出1756—1804年多场军事行动的奖金、军饷和战利品争讼文件。研究范围只把1700—1799年具体事项转成事件，超过1799年只保留档案覆盖说明。''',
 'detail':'''卷内包括1774罗希拉军队获得的Awadh赠款（p.133–233、311–348），以及1795马六甲相关军奖申诉（p.475–476）。目录存在是档案真实性证据，不是数额或领取成功证据。另应和1757年Clive个人jagir契据、1779公司军队融资、1799年提普宫廷战利品委员会并行分账。Bijigarh举例：约400万卢比战场财物、Popham个人分成与军官奖金已归入同一个“财产被取得”事件的不同子集；若重复求和会系统性夸大殖民收益。''',
 'agency':'''被夺物原产权所有者、名义赐金者、实际分发军队、公司董事会和英国王室收入均须分栏。与军队签约的印度统治者不一律具有自愿转让的议价条件。''',
 'map':'''战利品分配发生于堡垒、驻营或伦敦法庭，不意味着所在地每一条道路和村落被英国直接治理；无收缴处准确位置不得画金钱流向线。''',
 'critical':['IOR/H/83每一分配表的货币与账面销账号','军队奖金与Company treasure承认条件','现代论文转述的缴获价值和同期原帐互校'],'fiscal':[]},
'AB-NEW-021':{
 'background':'''本专题比较1773—1792若干条约的“签约”“董事会批准”“实际交割”“地方拒绝”四道流程。国际条约的法律文本不是英国地面驻军覆盖图。英方当事人另有《东印度公司法》与伦敦监督机关的行政层级，不能把公司承诺与王室主权混写。''',
 'detail':'''IOR/H/633载1775年《苏拉特条约》、1776年《普兰达尔条约》、1779年《瓦德冈协定》（英国图书馆明确称孟买政府没有批准）、1782年6月6日《萨尔拜和约》和1784年3月11日《芒格洛尔条约》。1782和约中Mahadji Sindia应保留为马拉塔谈判参与方。1792年2月22日迈索尔初步条款及3月18日最终条约是两种文书；征收3,300万sicca rupees与约半数领土给多方盟军不等于公司单独获收全部款项、全部面积。''',
 'agency':'''马拉塔邦联内部的Peshwa、Scindia等势力、迈索尔Tipu、Hyderabad的尼扎姆、莫卧儿名义授职与公司官员互不等同。''',
 'map':'''条约前后行政转换需单独有具体交接地名、纳税实体、驻军证据；目前不给虚假全面归属Polygon。''',
 'critical':['IOR/H/633 pp.27–45、95–109、139–146原约全文','IOR/L/PS/19/3 1792 jamabandi割地财政表逐区辨识','各签字版本及未获批准协议在公法上的相对效力'],'fiscal':['FISC-MYSORE-1792']},
'AB-NEW-022':{
 'background':'''1773 Regulating Act后加尔各答新设最高法院与公司行政权之间的关系成为政治冲突场域。1775年Nandakumar（亦作Nuncomar）因伪造罪定罪并执行死刑，学界长期争论该案英式刑法适用、对Hastings指控的关联与法院政治地位。''',
 'detail':'''现有2026同行评审研究摘要提供法权争议与政治解释的线索，但刑事卷宗、法官意见、控诉与辩护陈词并未逐页亲查。研究档案只能准确陈述“判决、执行、争议”，既不直接把有罪判决转换为现代史学真相，也不在缺审判档时认定已证实的政治谋杀。''',
 'agency':'''Nandakumar本人、法院法官、公司总督委员会及孟加拉本地诉讼惯例均属不同主体。''',
 'map':'''只可落加尔各答法院城市代表点；司法权变化不对应可绘的“全部孟加拉新吞并领土”。''',
 'critical':['1775 Supreme Court原案卷与庭审陈述','1773法令有关最高法院管辖与当地居民适用条款','总督委员会内关于Nandakumar指控的 contemporaneous correspondence'],'fiscal':[]},
'AB-NEW-023':{
 'background':'''1769—1770孟加拉饥荒的粮价危机需要区分“公司建立官方谷物市场垄断”与“部分公司代理人和商人占用职权操纵粮食市场”。Rajat Datta研究所引1771年8月28日公司董事通讯谈及代理人为利益收购乃至胁迫农民出售下一年度留种。''',
 'detail':'''目前有证据可把董事会来信和针对具体代理人行为的指责作为研究对象，而不能据此给整片孟加拉贴“官方谷物垄断”标签。应补足粮价月表、仓储位置、农民留种量、运输船过境关税和地区市场整合状况，才能估量各机制的相对贡献。饥荒死亡人口及流民则应另立人口估计分母。''',
 'agency':'''农民、地方zamindars、印裔和欧裔经纪人、公司官员都有不同程度的行动能力和受损程度，不能把任何一群写成单一抽象主体。''',
 'map':'''对于董事会来信可落伦敦董事会行政参考点，灾情须按已核具名县份列表；不制造饥荒受害面积。''',
 'critical':['1771-08-28董事会往来原文并辨识人员','Purnea、Burdwan、Birbhum的米价统计与旱情史料','粮价政策与1772盐业改革的时间先后'],'fiscal':[]},
'AB-NEW-024':{
 'background':'''英国1758年夺取法国在塞内加尔河的Saint-Louis，此前后还有Gorée、Podor及Galam的不同国际条约处理。Newton的研究明确英国1765—1779年在西非设“Province of Senegambia”（塞内冈比亚省），试图将当地军事防御、阿拉伯胶贸易和奴役贸易组织成可统筹的殖民管理网络。''',
 'detail':'''1763《巴黎和约》第10条承认法国恢复Gorée而英方取得塞内加尔若干贸易位置；1765设省并不等于英军控制整个塞内加尔—冈比亚河流域。John Carter Brown馆藏1779年法国地图说明当年法军重夺Saint-Louis，剑桥研究另显示英军1779重占Gorée。1783《凡尔赛和约》第9条重新将Gorée、Saint-Louis、Podor、Galam和部分岸点交法国。不同年份的Gorée驻军与法理必须有拆分记录。''',
 'agency':'''周边沃洛夫、Moorish和其他塞内冈比亚统治者与商人持续拥有自己的政治、关税与土地权益；英法条约未能替他们签署土地让渡。2024学术研究特别关注欧洲人同当地君主谈判的合作与纠纷。''',
 'map':'''可以核地名为Saint-Louis、Gorée、Fort James等港堡点；“Province”行政声索范围暂只有名称和时间，需查省内教区/海岸管辖表后方可提出局部虚线研究包络。''',
 'critical':['1765省行政成立原决议和任官档案','1779圣路易夺堡具体月份与Gorée重占交接军报','1783条约后实际撤军月日、甘比亚河内陆政治主体的协议'],'fiscal':[]},
'AB-NEW-025':{
 'background':'''加纳文物管理局记阿诺马布存在1700年代早期英国Fort Charles、1731拆堡、1753议会拨款及1757建成Fort William的多次改变。英国不能把新堡完工之前的所有年份都连续描绘为同一永久英式堡垒。''',
 'detail':'''该机构还转述一名英籍船长1717年报告，称1702年1月至1708年8月自Anomabu输往巴巴多斯和牙买加超过或至少30,141名被奴役者。数字应标明为“1717年船长陈述，涵盖1702—1708”，不是现代清点的航次档、也不是本期可再加入跨洋运输数据库的净新增人数。1753的议会拨款需查批准数、年款和是否按时发放；1757建堡和堡内拘押空间可按实地官方建筑研究，但不能捏造关押人数。''',
 'agency':'''Ty M Reese强调Fante领导者与英国商馆有利益谈判和实际制衡；Fort William驻堡贸易不是英王对整个Fante族地直接主权。1794法军袭堡结果待确认，不提前断言占领易手。''',
 'map':'''阿诺马布Fort Charles与Fort William重建地理关系须通过遗产测绘定点；暂无独立核定位时不伪造精确坐标。''',
 'critical':['1717船长原始汇报的笔录与船只、港口统计','1731拆堡、法国修建、1753拨款、1757完工的原公司/议会记录','1794袭击守军与当地民众遭受结果'],'fiscal':[]},
'AB-NEW-026':{
 'background':'''James Island（今Kunta Kinteh Island）位于冈比亚河，18世纪英国公司堡垒与奴役人口装船网络须分离于英国声索的整条冈比亚河岸。联合国教科文组织明确称1779年法国军队造成该堡最后重大毁坏，此后遗址维持废墟状态。''',
 'detail':'''1783英法《凡尔赛和约》第10条保障英国在冈比亚河及Fort James的地位；法理声索在1779堡垒破坏之后发生，不能直接从和约文本推定已重建、长期驻军已恢复。地点官方UNESCO现代经纬度为13°19′3.51″N、16°21′40.87″W，只用作现代文化遗产坐标，不当历史城垣或控制面积。''',
 'agency':'''附近非洲贸易势力、河口社区与被掳被奴役者的遭遇必须保留；和约只由法国、英国政府缔结。''',
 'map':'''地图可用UNESCO参考Point，并按1779终止“有建筑存在”状态、1783另记法律权利候审点；不能从海岛现代面积统计英国实控。''',
 'critical':['1779法军炮击/毁堡清单和是否留下守军','1783之后英国是否再建堡、何年重新驻军的独立证据','贸易公司、英政府和冈比亚地方政治的关系'],'fiscal':[]},
'AB-NEW-027':{
 'background':'''18世纪各欧洲国王的和约条款与海外实控相脱节。在西非，英法1763、1783两次改订戈雷和塞内加尔河据点归属；在印度，1763条约又要求归还法国1749年已拥有的商馆。区域法律地位、堡垒本体与商馆许可需做独立状态。''',
 'detail':'''1763《巴黎和约》第10条归还Gorée法国并涉及英方获得的塞内加尔据点；第11条规定法国恢复印度沿岸Coromandel、Orissa、Malabar、Bengal各贸易商馆。1783《凡尔赛和约》第9条让法国恢复Saint-Louis、Podor、Galam及Gorée；第10条确认英方甘比亚Fort James权利但其1779已遭破坏。以上仅为已读取的法律转录文本主张，具体驻军接防须另查军事日记。''',
 'agency':'''马拉塔、孟加拉、科罗曼德海岸印度政权与塞内加尔当地统治者既非“英法国民”，亦非条约自动消灭的自治政治。''',
 'map':'''同一座堡垒可有“条约确认主体”“实际驻军主体”“被毁而无驻军”三套时间字段，不能采用单一按年全域国旗。''',
 'critical':['1763 Pondicherry等每一商馆实际交还的独立时间','1783圣路易、Gorée、詹姆斯堡条款实际执行','法国和英国外交文本与当地政权契据核对'],'fiscal':[]}}

out=P/'TOPIC_DOSSIERS'/'NEW_CANDIDATES';out.mkdir(exist_ok=True)
for ident,sp in d.items():
 n=N[ident];ev=[e for e in E if ident in e['topic_ids']]
 src_ids=sorted(set(n['source_ids'])|{sid for e in ev for sid in e['source_ids']})
 lines=[f"# {ident}｜{n['title']}",'', '**范围与状态：1700—1799研究候审，未发表；保留原37母题ID不变。**','', f"**对应母题：** `{n['related_original_topic_id']}`。**单立理由：**{n['rationale']}",'','## 一、背景与权力性质','',sp['background'],'','## 二、具体过程与收益链','',sp['detail'],'','## 三、当地政治主体与证据冲突','',sp['agency'],'','## 四、地图可执行限制','',sp['map'],'','## 五、已有逐项事件（需主编审核）','']
 for e in sorted(ev,key=lambda e:(e.get('year') or 0,e.get('month') or 0,e.get('day') or 0,e['id'])):
  date=str(e.get('year') or e.get('year_window') or '?')
  if e.get('month'):date+=f"-{e['month']:02d}" 
  if e.get('day'):date+=f"-{e['day']:02d}"
  lines+=[f"### {date}｜{e['title']} (`{e['id']}`)",'',f"**行动主体：**{e['actors']}。**地点：**{e['location']}。",'',f"{e['action']}", '', f"证据：{', '.join('['+sid+']('+S[sid]['url']+')' for sid in e['source_ids'])}。**地图状态：**{e.get('map_state','待核')}，边界未验证。",'']
 assoc=[f for f in F if ident in f['topic_ids'].split(';')]
 lines+=['## 六、经济数据引用（不重复加总）','']
 if assoc:
  for x in assoc:
   lines += [f"- **{x['id']}**：{x['value']} {x['currency_or_unit']}，{x['metric_definition']}。时期 {x['accounting_period'] or (x['year_start']+'—'+x['year_end'])}；核查等级 `{x['verification_status']}`；{x['interpretation_limit']}"]
 else: lines+=['当前尚无可核实的原币值或实收金额，本专题经济证据为空值，后续查账。']
 lines+=['','## 七、实际使用的来源与阅读深度','']
 for sid in src_ids:
  s=S[sid]
  lines += [f"- **{sid} · {s['institution']}：** [{s['title']}]({s['url']})；档案号 `{s.get('archive_identifier') or '无'}`；已读层级 `{s.get('reading_level')}`；纸质原始手稿未亲读。"]
 lines+=['','## 八、下一轮原档优先查验','']
 for i,a in enumerate(sp['critical'],1):lines.append(f'{i}. {a}')
 lines+=['','**制图审核声明：**任何已确认的现代坐标仅可作为历史事件的现代参考点，不可作为当年实控边界。条约、征税、战利品或人物获利不自动形成主权多边形。','']
 (out/(ident+'.md')).write_text('\n'.join(lines),encoding='utf-8')

appendices={
'E18-B07':('粮价私商、留种抢购与1773税务原卷的增量核查', '''Rajat Datta的论文[BS117](https://journals.sagepub.com/doi/10.1177/001946468602300403)引1771年8月28日董事会来信，讨论某些公司关联代理人收购、甚至被指强迫农民出售下一年留种粮的行为。研究中必须把私人代理买卖与公司官方谷物贸易制度分开：现阶段未掌握证据证明存在覆盖全孟加拉的“公司谷物官营专卖”。此外，英国图书馆**IOR/L/PARL/2/7/4**馆藏[BS96](https://searcharchives.bl.uk/catalog/041-001116386)收1773第四报告，涉及1770账及盐税、民政开支、汇票等。这是用以校验R.C.Dutt £2,000支出总数差异的原档入口，而非已阅读该原卷。新增关联候审事件`AB-B07-006`。同一时期盐业专卖自1772年起，不能倒推作为1769饥荒单因。'''),
'E18-B11':('马拉塔战争和约及驻军转换：不能以战争窗作连续英国领土', '''已从英国图书馆[BS101｜IOR/H/633](https://searcharchives.bl.uk/catalog/040-000004727)编目确认：**1775-03-06苏拉特条约、1776-03-01普兰达尔条约、1779瓦德冈协定、1782-06-06萨尔拜和约**均有独立文书。瓦德冈协议记有孟买政府**拒绝批准**，故签约≠合法全面领土移交；普兰达尔和萨尔拜亦不等于马拉塔邦联全部被征服。1781年4月公司军夺取Kalpi，Fisher所编士兵旅行记录[BS108](https://publishing.cdlib.org/ucpressebooks/public/book/the-travels-of-dean-mahomet-an-eighteenth-century-journey-through-india.html)记公司试图索取过去付给马拉塔的税赋，实际税收到款待核。相关事件`AB-B11-003`至`AB-B11-007`，地图应分别标协议、失败、驻堡与税收转向，不制作一条1775—1782连续实控战线。'''),
'E18-B14':('迈索尔1792条约初案、最终文书与多方获地的分离', '''[BS114｜1792-09-12《National Gazette》历史报纸转录](https://snewpapers.com/components/8105c512-3be2-4448-b5a3-0f6766c3cf52_evt_0)刊载**1792-02-22初步条款**：Tipu应支付**3 crore 30 lakh sicca rupees（33,000,000 sicca卢比）**，其中约半数先交、其余分期；并割让约半数统治区予交战**盟国**，王子作担保。[BS109｜IOR/L/PS/19/3](https://searcharchives.bl.uk/catalog/040-000564194)明确存**1792-03-18正式条约**波斯/英文副本及**1792-09-03**所附割让领土的jamabandi税基账。新闻转录不是原报纸实物已读，目录不是已查原条款。3,300万的分期是同一总额内构成，不得相加；多方盟军获地也不能全部涂成公司直辖。1794年归还人质可见[BS110](https://collection.nam.ac.uk/detail.php?acc=1971-02-33-367-1)。'''),
'E18-B17':('1781年贝拿勒斯财政政变与地方统治权分层', '''英国图书馆IOR/H/633[BS101](https://searcharchives.bl.uk/catalog/040-000004727)编目收**1776-04-15 Chait Singh在Benares/Ghazipur的zamindari敕令**和**1781-09-14 Mahip Narain继位的接受条款**。[BS108](https://publishing.cdlib.org/ucpressebooks/public/book/the-travels-of-dean-mahomet-an-eighteenth-century-journey-through-india.html)历史叙事显示Hastings追加贡赋和兵员要求，引发1781武装抵抗；公司夺取Bijigarh财宝后，军官与士兵奖金并不必然转为公司收入。年度2,340,249卢比原约付款、4,000,000卢比后继要求、Bijigarh约4,000,000卢比缴获、军官获294,000卢比需保留不同性质。另立新增候选`AB-NEW-018`完整记录。'''),
'E18-B18':('盐业生产垄断、拍卖、鸦片与对华汇票的不同收益科目', '''现增英国图书馆[BS97｜IOR/L/PARL/2/19/3](https://searcharchives.bl.uk/catalog/041-001116508)及[BS105｜IOR/L/PARL/2/9a](https://searcharchives.bl.uk/catalog/040-001116470)：相关议会财务卷含对华汇票、鸦片利润、盐工征缴、军费、债务等不同账。1772年孟加拉/比哈尔食盐生产专卖见Kanda学术研究[BS112](https://www.cambridge.org/core/journals/international-review-of-social-history/article/environmental-changes-the-emergence-of-a-fuel-market-and-the-working-conditions-of-salt-makers-in-bengal-c-17801845/EFF95B979EA1BC59C12DAFD1E623FB58)；1788年盐品拍卖、地方经销商仍发挥作用见[BS113](https://www.jstage.jst.go.jp/article/sehs/68/2/68_KJ00004582558/_article/-char/en)。生产、国内销售、对华收支与输英采购不得加成一个“对英净转移”数字。'''),
'E18-E07':('塞内冈比亚省1765—1779的行政时间段与三次英法易手', '''[BS122](https://www.tandfonline.com/doi/full/10.1080/21533369.2013.851840)以专门研究明确**1765—1779 Province of Senegambia**作为英国在西非的行政安排。1763英法《巴黎和约》第10条[BS129](https://www.uottawa.ca/about-us/official-languages-bilingualism-institute/clmc/linguistic-history/historic-documents/treaty-paris-1763)归还Gorée于法国，而英国在Saint-Louis/Podor/Galam另有条约权利；1779英军失去Saint-Louis，但另一英国部队占Gorée[BS125](https://jcblibrary.org/news/carte-du-cours-des-fleuves-du-senegal-et-de-gambie-dediee-et-presentee-monsieur-le-duc-de/)[BS126](https://www.cambridge.org/core/books/mobility-and-coercion-in-an-age-of-wars-and-revolutions/legion-of-the-damned/15C327CD2E119A6ACC6D889CF8B10CAF)；1783《凡尔赛和约》第9条[BS128](https://mjp.univ-perp.fr/traites/1783versailles.htm)再将Gorée及Saint-Louis河岸据点交法。每处需独立呈现港堡点与驻军年限。西非政治主体的自主地权另参[BS127](https://www.cambridge.org/core/journals/history-in-africa/article/vivre-en-paix-et-en-bonne-intelligence-avec-les-princes-locaux-in-senegambia-in-the-age-of-slave-economy-diplomatic-treaties-trade-conflicts-and-peace-in-interaction-16791815/3D78436EE79DD7C86CF0CBDC3AD00DD5)。'''),
'E18-E10':('阿诺马布堡垒断代、Fante经济谈判及詹姆斯堡毁堡', '''加纳国家博物馆[BS120](https://gmmb.gov.gh/fort-william-anomabu-1753/)将Anomabu英方堡垒拆分为**Fort Charles于1731拆除、1753议会拨款、1757 Fort William建成**。其1717年船长称1702—1708至少30,141名被奴役者输出，是一条需回到原船长函和航次数据库核对的自报量。Fante地方领导人与英国公司的谈判见[BS121](https://www.tandfonline.com/doi/abs/10.1080/03086534.2013.762162)。冈比亚James Fort在**1779遭法军毁坏**[BS123](https://whc.unesco.org/en/list/761)，1783第10条[BS128](https://mjp.univ-perp.fr/traites/1783versailles.htm)保障英国相应法定权利，不能当作重修或驻军证明。UNESCO坐标[BS124](https://whc.unesco.org/en/list/761/maps/)仅现代遗址参考点。'''),
'E18-E09':('塞拉利昂1799地产争端与1800抗议事件的世纪界线', '''专业研究[BS111](https://orca.cardiff.ac.uk/id/eprint/104088/)讨论塞拉利昂公司和黑人效忠派移民围绕土地分配、quitrent、粮食控制和自治法权的冲突。**1799年可以记累积争端，主要殖民骚乱为1800年事件**，必须留给19世纪专题；已经更正`AB-E09-004`，避免把研究的叙事尾声提前当成1799武装起义。'''),
'E18-B03':('Mir Jafar条约档与Clive jagir个人资产分账', '''[BS98｜Mss Eur G37/9/6](https://searcharchives.bl.uk/catalog/040-000800397)存Siraj ud-Daulah被推翻后Mir Jafar相关条约、贸易特许与公司授权文书的波斯文翻译件；[BS99｜Mss Eur G37/8/10](https://searcharchives.bl.uk/catalog/041-000800348)有约1764年Clive个人jagir十年展期契据。两者是公司政治收益与私人收入来源的不同档案入口，实际土地税金分摊、收款时间、Clive个人分红需按年查对。'''),
'E18-B22':('1763年本地治里等法属印度商馆归还条款', '''1763年《巴黎和约》第11条[BS129](https://www.uottawa.ca/about-us/official-languages-bilingualism-institute/clmc/linguistic-history/historic-documents/treaty-paris-1763)要求法国恢复其1749年初于Coromandel、Orissa、Malabar、Bengal等的商馆/贸易站。1761英国占领Pondicherry不应自动延续为1799年前持续英国驻城，也不能误画整个泰米尔地区英领；实际执行时间和法方防御权限制另需原条约及移交军报。关联事件`AB-B22-003`。''')
}
for tp,(title,body) in appendices.items():
 file=P/'TOPIC_DOSSIERS'/(tp+'.md')
 marker=f'## 追加研究｜{title}（2026-11-08）'
 text=file.read_text(encoding='utf-8')
 if marker not in text:file.write_text(text.rstrip()+f'\n\n{marker}\n\n{body}\n',encoding='utf-8')

# Map continuity is a status argument audit, not a polygon creation tool.
rows=[
('T001','1700','Cape Coast Castle','17C English RAC fort trading presence','18C presumed institutional continuation pending fort log','Royal African Company; Fetu polities','fort_trade_not_territorial_sovereignty','BS40;BS63','AB-E10-001','Current island/region shoreline MUST NOT become historical polygon'),
('T002','1700','Indian coastal factories','17C EIC factories / changing Indian sovereigns','18C company factories not all-mapped territorial control','Mughal/Indian polities; EIC','factory_permission_no_sovereignty','BS01;BS13','AB-B01-001','1700 garrisons/leases and host sovereigns need precise check'),
('T003','1719','Bencoolen/Marlborough','English Company local fort residency','Local revolt; interruption of British factory/fort residency','Local Sumatra political communities; EIC','fort_control_disrupted','BS34','AB-E15-003','End date and resumption around 1723 require original logs'),
('T004','1723','Bencoolen','Local insurgency and vacated fort','EIC returns to operational station','EIC; Sumatran local polities','fort_reoccupation_not_island_sovereignty','BS34','AB-E15-004','No polygon around Bengkulu'),
('T005','1731','Anomabu Fort Charles','Earlier English coastal fort structure','British demolition; French later repairs','British traders; Fante; French','fort_demolition','BS120','AB-E10-004','1753 funding and 1757 new fort separately dated'),
('T006','1757','Anomabu Fort William','1753 financed but unbuilt','New British coastal trade and detention fort completed','British traders; Fante','fort_completion_not_fante_control','BS120;BS121','AB-E10-006','Local Fante land authority independent'),
('T007','1758','Saint-Louis Senegal','French coastal station','British forces seize port','British crown forces; French; local African rulers','short_to_multi_year_garrison_occupation','BS122','AB-E07-001','No Senegambia-wide conquest'),
('T008','1763','Gorée','British garrison after 1758/59 attack','1763 Treaty of Paris restores French legal rights','British and French governments','legal_transfer_actual_garrison_to_check','BS129','AB-E07-003','Actual evacuation month unknown'),
('T009','1763','French India factories (Pondicherry etc)','British occupation in Seven Years War','1763 Treaty of Paris provides French restitution','French; British EIC; local Indian polities','legal_factory_restitution','BS129','AB-B22-003','Exact factory execution dates independent'),
('T010','1765','Bengal Bihar Orissa revenue domains','Mughal appointed provincial revenue authorities','EIC granted Diwani fiscal rights; nawab judicial roles remain','Mughal emperor; Nawab; EIC','revenue_right_not_direct_royal_sovereignty','BS02;BS06','AB-B06-001','No mapped 1765 diwani district polygon'),
('T011','1765','Saint-Louis / Province of Senegambia','British control of select posts since 1758','British provincial governance structure created 1765','British officials; Senegambian sovereigns','claimed_province_not_uniform_control','BS122','AB-E07-004','Local sovereigns remain independent; area blank'),
('T012','1774','Rohilkhand','Rohilla political centres','Awadh advances using EIC troops; company gains payment claims','Awadh Nawab; Rohilla chiefs; EIC troops','military_support_for_ally_not_eic_sovereignty','BS52;BS58;BS101','AB-B10-001','No Rohilkhand British colony polygon'),
('T013','1779','Saint-Louis','English military port held','French military recapture','French armed forces; English garrison; African local polities','garrison_transfer_to_french','BS125;BS122','AB-E07-005','Exact surrender day unverified'),
('T014','1779','Gorée','French occupation post 1763 treaty','British forces reoccupy island fort','British and French forces','garrison_change_not_continental_control','BS126','AB-E07-006','1799 must not inherit British occupation'),
('T015','1779','James Fort / Kunta Kinteh Island','British trading fort near Gambia River','French force destroys fort; physically ruined thereafter','French navy; British fort traders; local river polities','fort_destroyed_legal_claim_may_survive','BS123;BS124','AB-E10-007','No fort area extrapolation from UNESCO monument'),
('T016','1781','Benares','Chait Singh local zamindari with Company demands','Hastings crackdown and removal of Chait Singh; successor remains local ruler','Chait Singh; Hastings; Mahip Narain','fiscal_suzerainty_not_total_royal_control','BS101;BS108','AB-NEW-018-003','Requires district revenue register'),
('T017','1783','Saint-Louis / Gorée','Multiple wartime changes 1779','1783 treaty returns French rights including Gorée and Senegal posts','French and British governments; independent African rulers','treaty_transfer_verify_actual_withdrawal','BS128','AB-E07-007','French rights not African land grants'),
('T018','1783','James Fort, Gambia','Fort physically destroyed in 1779','1783 France recognizes English legal rights but fort remains ruins','France; Britain; river communities','legal_claim_not_rebuilt_garrison','BS123;BS128','AB-E10-008','Verify if/when military rebuild occurred'),
('T019','1786','Penang','Kedah-linked maritime domain with local residents','Francis Light EIC landing / Company possession assertion','Kedah ruler; British EIC; Penang residents','contested_cession_vs_actual_port_occupation','BS31;BS32;BS33','AB-E02-001','1786 treaty cession contested'),
('T020','1792','Mysore territories','Tipu political domain','March18 treaty requires territorial cession to tripartite alliance','Tipu; EIC; Hyderabad; Maratha allies','treaty_multiple_recipients','BS109;BS114','AB-B14-005','Use jamabandi fiscal districts not modern whole-state polygons'),
('T021','1795','Cape settlement','Dutch colonial administration and local Khoikhoi polity','British military takeover of Cape Dutch coastal centres','British Crown forces; VOC/Dutch; Khoikhoi communities','temporary_british_military_occupation','BS55','AB-E06-001','Occupation terms do not resolve indigenous land rights'),
('T022','1795','Malacca','Dutch VOC fort/port','British invasion and occupation (wartime)','British EIC/Crown units; Dutch; Malay rulers','wartime_port_occupation_not_malaya_conquest','BS104','AB-E04-001','Original garrison capitulation needed'),
('T023','1796-02-16','Colombo fort','Dutch fort garrison','British/Company Indian sepoys take over following Feb15 terms','Dutch garrison; British forces; EIC sepoys','garrison_transfer_not_kandy','BS84','AB-E05-003','Modern city point not historic perimeter'),
('T024','1796-02-23','Galle fort','Dutch fort garrison','British forces replace Dutch after keys handed','Dutch and British forces; local Ceylon communities','fort_occupation_not_sri_lanka_conquest','BS84','AB-E05-004','Kandyan Kingdom remains independent'),
('T025','1799-05-04','Seringapatam','Tipu controls Mysore capital','Company-allied assault captures fort; Tipu killed; successor polities and allocations follow','Mysore; EIC; Hyderabad; Wodeyar','battle_capture_and_multilateral_division','BS11;BS109','AB-B15-001','No modern Karnataka polygon allowed')]
# source id tests: bs02 etc exists but some event ids? check dynamically and warn instead of output broken
sd=set(S);ed={e['id'] for e in E}
with (P/'CONTROL_TRANSITIONS_B_E.csv').open('w',encoding='utf-8-sig',newline='') as f:
 names=['id','date','place','from_status','to_status','actors','control_semantics','historical_boundary_verified','area_sqkm','geometry_policy','source_ids','related_event_id','uncertainty']
 w=csv.DictWriter(f,fieldnames=names);w.writeheader()
 for a,b,c,fd,td,actors,sem,src,ev,uncertain in rows:
  missing=set(src.split(';'))-sd
  assert not missing,(a,missing)
  assert ev in ed,(a,ev)
  w.writerow(dict(id=a,date=b,place=c,from_status=fd,to_status=td,actors=actors,control_semantics=sem,historical_boundary_verified='false',area_sqkm='',geometry_policy='named_site_point_or_unmapped_only',source_ids=src,related_event_id=ev,uncertainty=uncertain))

check_notes='''# 经济史料口径与重复计算审计（2026-11-08，研究级）

本笔记不发布历史地图中的收益统计；只为主编审查提供已经有来源的数字类别和不得合并的层次。

## 一、孟加拉收入（1765—1771）：年度gross / net / expenses / balance

- `ECONOMIC_EVIDENCE.csv`中每年度分别列总征收、扣税务和政治补助后的收入、军政及建筑支出、余款。年度的`net`已经扣除若干项目；年度`balance`由`net−expenses`形成。**严禁把四栏直接加总**。
- 后世R.C.Dutt网上转录的1773年下院第四报告六年分项：**军政支出逐年和9,029,609英镑；总栏印9,027,609英镑，差2,000英镑**；净收入13,066,761英镑；年结余4,037,152英镑。由此检验原始1773报告 `[BS96](https://searcharchives.bl.uk/catalog/041-001116386)` IOR/L/PARL/2/7/4与`[BS10](https://akshara.ink/books/economic-history-of-india/03-lord-clive-and-his-successors/)`，并与1765—1771地方账户逐年比对。**结余≠装船输英黄金、股息、个人扣款或净殖民转移**。
- `[BS97](https://searcharchives.bl.uk/catalog/041-001116508)` IOR/L/PARL/2/19/3可能区分对华汇票、鸦片利润、公司采购、国库债务；仅确认目录存在，未读取册内金额。

## 二、迈索尔1792：条件值、履约款和割地分别核实

- 1792年2月22日初步条款报纸转录 `[BS114](https://snewpapers.com/components/8105c512-3be2-4448-b5a3-0f6766c3cf52_evt_0)`以**sicca rupees 33,000,000**提出赔款总额；其中16,500,000先交、16,500,000分期偿付。**16.5m+16.5m=33m，而不是总值33m以外再加33m。**
- 1792年3月18日多边正式约文及同年jamabandi登记见英国图书馆 `[BS109](https://searcharchives.bl.uk/catalog/040-000564194)` IOR/L/PS/19/3；目录不含逐区金额，无法给出公司单方获款或确切割地面积。人质1794归还 `[BS110](https://collection.nam.ac.uk/detail.php?acc=1971-02-33-367-1)`是履约结果的定性旁证，而非现金支付凭证。

## 三、Benares / Bijigarh 1781：公司税款、缴获、军官私得

- `[BS108](https://publishing.cdlib.org/ucpressebooks/public/book/the-travels-of-dean-mahomet-an-eighteenth-century-journey-through-india.html)`：1775对Chait Singh约定**2,340,249 rupees每年**；继任制度称要求**4,000,000 rupees每年**，不把两档相加或视作实际到账。
- Bijigarh约**4,000,000 rupees战利品**属汇总估计；军官Popham **294,000 rupees个人获配**、各captain **22,478 rupees**、普通印度兵 **50 rupees**被陈述为同一批军奖的分配，不具有不同收入“叠加”属性。公司追索意味着公司账面收入和士兵持有不同。
- 同一文本提**50,000 rupees借款**供应公司部队；这是外部融资／负债，不是征税或净收入。
- 与`[BS118](https://mss-cat.nottingham.ac.uk/CALMVIEW/Record.aspx?id=PlC%2F4%2F26&src=CalmView.Catalog)`Hastings报告、[BS101](https://searcharchives.bl.uk/catalog/040-000004727) IOR/H/633及[BS104](https://searcharchives.bl.uk/catalog/040-000004120) IOR/H/83档案交叉再验。

## 四、马尼拉、罗希拉及西非量值

- 马尼拉**4,000,000西班牙银元**为1762投降约定赎金而不是英国实际收款；汇票、Santísima Trinidad船货、海军私分不得二次叠加。Bank of England档 M5/110记录后续索款，实际交割未完成核实。
- IOR/H/83 1774罗希拉战争对应英军分配奖赏的案卷目录，**没有可直接凭目录编写的到账货币金额**。
- 阿诺马布所谓**30,141被奴役者**是加纳博物馆所转一名英国船长**1717年关于1702—1708年的报告**，单位是“声称人数”而非货币，不代表全港生死净统计，也不能加入跨大西洋统计库成为另一笔运输。

## 五、所有经济统计的禁用操作

1. 不把分期总额与分期子项再次相加。
2. 不把地税征收、商品采购、库存面值、拍卖额和战争财物都当“英国净收益”。
3. 不把军官奖金、士兵薪金、公司账面结余和国库收入合并到一个不可审计数字。
4. 不凭1765税收特权、1753堡垒拨款、1783国际条约或现代遗址范围计算历史土地面积。
5. 所有金额保留原历史币制、名义年份、统计口径、债权人及精确来源 URL/档号；需要兑换汇率必须找到当年票据记载，不用现代汇率。
'''
(P/'WORKING/ECONOMIC_RECONCILIATION_20261108.md').write_text(check_notes,encoding='utf-8')

# Extend gaps with independently actionable targets
f=P/'GAPS_AND_CONFLICTS.md';g=f.read_text(encoding='utf-8');head='\n## 追加P0/P1｜本轮新发现的10项原始核查问题（2026-11-08）\n'
if head not in g:
 g+=head+'''

30. **1775—1782贝拿勒斯钱款与法权**：查IOR/H/633的1776 zamindari sanad、1781 Mahip Narain承诺及1783 Hastings报告；约2,340,249、4,000,000卢比的年款与Bijigarh约4,000,000卢比缴获是不同财产权，军官分配为后者子项。[BS101/BS108/BS118]
31. **1792 Tipu正式/初步两约**：2月22日初步条款之“3 crore 30 lakh sicca rupees”与3月18日正式条款及9月3日jamabandi须逐项核验。约半数土地割让给多边盟军，不可全算公司；现暂无经核历史多边形。[BS109/BS114]
32. **1779 Wadgaon没有批准**：IOR/H/633目录明确孟买当局未批准协议；须查看马拉塔方及公司方的签字/批准生效日期。不可仅靠英军战败与原协议推断每一区域实际退兵。[BS101/BS102]
33. **1783日后James Fort的堡址与法律身份分离**：UNESCO认定1779被法军毁坏成为废墟；1783英法和约第十条保障英国取得法律地位仍需核实际守军是否重返。[BS123/BS128]
34. **1765—1779塞内冈比亚省**：是否包括哪些城镇和贡税区、军政联系如何形成、1765创建法令日期、1779法国夺Saint-Louis具体日和Gorée英方重占起止日，均需原档。[BS122/BS125/BS126]
35. **1702—1708阿诺马布人数30141**：当前是1717船长陈述，尚未与船舶账、跨大西洋运输数据库去重；1731拆Fort Charles、1753拨款、1757 Fort William完工和1794法军袭堡结局亦待核。[BS120/BS121]
36. **1772—1788孟加拉盐业**：学术文献支持生产专卖和公开拍卖，尚无公司盐厂生产日报、出厂收购价、molungee工资及供应量，不得声称整个私人交易消失。[BS105/BS112/BS113]
37. **1770年粮食机构争议**：部分代理人私购农民留种是对具体行为的历史指控，不能改写为官方公司统一谷物垄断；查1771-08-28董事通讯全文和县级米价序列。[BS117/BS96]
38. **1775 Nandakumar案**：法律判决与政治动机需分别取证，读加尔各答最高法院原案与有关指控Hastings腐败的来往信件；仅学术摘要不足判定全部案件政治实情。[BS116]
39. **1763和1783欧洲条约与实际驻军**：1763法属印度商馆归还、Gorée归法国；1783Saint-Louis/Gorée归法国、James Fort英方权利。各条的法律生效日和军队实际接防日不同；任何一条都不转让当地独立政体未经同意的土地。[BS128/BS129]

增量控制审查表：`CONTROL_TRANSITIONS_B_E.csv`（25项时间转换，历史边界均留空），增量经济审计：`WORKING/ECONOMIC_RECONCILIATION_20261108.md`。未读档案目录保持原标记，不将一次馆藏搜索当作一手原件全文核查。
'''
 f.write_text(g,encoding='utf-8')

# Update handoff count in actual state
stats=dict(original=37, B=22,E=15, new=len(N), events=len(E),sources=len(S),economic=len(F),geo=len(json.loads((P/'MAP_CANDIDATES.geojson').read_text(encoding='utf-8'))['features']),transitions=len(rows),new_reports=len(list(out.glob('AB-NEW-*.md'))))
assert stats['new']==27 and stats['events']==131 and stats['sources']==132 and stats['economic']==63
progress=f'''# 爱英TV｜助手2第二轮补充成果／交接｜2026-11-08

**完整工作目录** `/mnt/data/18c_assistant_B/`；**GitHub修改数：0；出版状态：research_only**。

## 总量与增量

| 研究文件 | 此轮合并后的数量 |
|---|---:|
| 原定B/E专题报告（B01—B22 / E01—E15） | 37（22 + 15） |
| 另立遗漏研究候选及独立报告 | {stats['new']} |
| 候审事件（JSON+CSV逐条对应） | {stats['events']} |
| 带真实URL/档案号来源 | {stats['sources']} |
| 财政、人口、奖金、赔款及承诺证据行 | {stats['economic']} |
| 具核证现代参考地点 | {stats['geo']} |
| 控制关系转换待核登记 | {stats['transitions']} |
| 经验证殖民历史控制Polygon / 可计算历史面积 | 0 / 0 |

相对首版：新增**37件候审事件（94→131）**、**37项来源（95→132）**、**11条经济证据（52→63）**、**10项遗漏专题（17→27）**、**1处UNESCO现代参考点（13→14）**。已为新10个候选生成独立详查报告，并在10篇原B/E报告补充具体审查段落。

## 已实际保存的三批增量与关键突破

1. **第一批**：追踪英国图书馆`IOR/H/633`所列苏拉特、普兰达尔、瓦德冈、萨尔拜、芒格洛尔条约，区分签约日、未批准条款与实驻；另找到`IOR/L/PS/19/3`迈索尔1792多语条约及jamabandi财税附件。新增专题18—23。
2. **第二批**：核对历史军官叙事、Benares地税与Bijigarh缴获，保持约2340249卢比年约、400万卢比继任年款、约400万卢比战利品及军官个人分成的包含关系；整理1772盐业生产专卖、1788拍卖与饥荒粮食市场区分。发现1799塞拉利昂地产争议与1800骚乱世纪界限并已修正事件。
3. **第三批**：由1779法军西非行动、1765—1779英国塞内冈比亚省、1783英法条约、UNESCO 1779詹姆斯堡毁坏、阿诺马布1717船长报告和建堡时间表，增加B/E的西非政治控制转换。地图第14点采用UNESCO公布的现代Kunta Kinteh Island地点坐标，未生成任何历史疆界。

## 整合结构

- `TOPIC_DOSSIERS/` 原37篇，新增专题`TOPIC_DOSSIERS/NEW_CANDIDATES/`27篇；每篇附历史过程、史料深度与地理限制。
- `EVENT_CANDIDATES.json`及`.csv` 真实可追溯事件；`SOURCE_REGISTRY.json` 逐份来源阅读层级；`ECONOMIC_EVIDENCE.csv` 单位口径、分期合计、实收证据状态。
- `CONTROL_TRANSITIONS_B_E.csv` 25个历史地点跨年的驻军/条约/毁堡/税权变化，不附假界线。
- `MAP_CANDIDATES.geojson` 14个现代参考点，明确历史边界未证及面积禁统。
- `WORKING/ECONOMIC_RECONCILIATION_20261108.md` 重要数字防双算审计；`GAPS_AND_CONFLICTS.md` 优先级缺口。

## 原始材料读取声明与交接

本轮确实阅读了可访问的网页条约文本/历史文字转录和机构学术材料，检索了多个英国图书馆实体馆藏**目录**，但**没有逐页查验馆藏纸质原件或扫描件**。目录不能证明档案每一条细节已经核实。所有本期资料仅为研究候审，禁止直接并入正式地图或用现代省界统计1757、1765、1792、1799疆土。

下一位主编应优先读：`IOR/H/633`和`IOR/L/PS/19/3`，1765—1771原议会第四报告`IOR/L/PARL/2/7/4`，Bijigarh赏金`IOR/H/83`，马尼拉赎金`M5/110`，槟城`IOR/G/34/2`，1779 Senegal和1783城防交接原卷；地图须逐年独立确认当地政体、堡垒实驻和条约主张。
'''
(P/'PROGRESS.md').write_text(progress,encoding='utf-8')
read=P/'README.md';q=read.read_text(encoding='utf-8');q+=f'''\n\n## 2026-11-08 第二轮续查更新（覆盖首次交付说明）\n\n本ZIP最终以`MANIFEST.json`、`PROGRESS.md`数量为准：{stats['events']}候审事件、{stats['sources']}来源、{stats['economic']}经济证据、{stats['new']}遗漏专题报告、14现代参考点、25项控制关系转换；原B/E37母题仍为候审。新增`CONTROL_TRANSITIONS_B_E.csv`、`WORKING/ECONOMIC_RECONCILIATION_20261108.md`以及`TOPIC_DOSSIERS/NEW_CANDIDATES/AB-NEW-018.md`至`AB-NEW-027.md`。所有资料尚未发表，未写入GitHub。\n''';read.write_text(q,encoding='utf-8')
print('REPORTS',stats)
