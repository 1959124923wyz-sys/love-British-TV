import json,csv,pathlib,collections
P=pathlib.Path('/mnt/data/18c_assistant_B')
S=json.loads((P/'SOURCE_REGISTRY.json').read_text());N=json.loads((P/'NEW_CANDIDATES.json').read_text());E=json.loads((P/'EVENT_CANDIDATES.json').read_text())
next_s=max(int(x['id'][2:]) for x in S['sources'])+1
next_n=max(int(x['candidate_id'].split('-')[-1]) for x in N['candidates'])+1
smap={}
def s(key,institution,title,url,level,ident=None,notes=''):
 global next_s
 id='BS'+str(next_s);next_s+=1;smap[key]=id
 S['sources'].append({'id':id,'institution':institution,'title':title,'url':url,'reading_level':level,'archive_identifier':ident,'notes':notes,'original_manuscript_personally_inspected':False,'consulted_on':'2026-11-08'})
s('poligar','Cambridge / Journal of Asian Studies / Anand A. Yang','Bandits and Kings: Moral Authority and Resistance in Early Colonial India','https://www.cambridge.org/core/journals/journal-of-asian-studies/article/abs/bandits-and-kings-moral-authority-and-resistance-in-early-colonial-india/F5C6466E58EA233E8678A2917D81159D','journal_abstract_read',notes='1801 exile of 73 poligars is OUTSIDE 18th century and is cross-century note only')
s('site','Tamil Nadu Department of Archaeology','Panchalankurichi archaeology fort palace','https://www.tnarch.gov.in/panchalankurichi','official_archaeology_site_read',notes='35 acres is modern protected archaeological mound, NOT 1799 historic company-controlled area')
s('famine1781','UCL doctoral thesis / Leela Sami','Famine, Disease, Medicine and State in Madras Presidency (1876-78), Historical Table 0.1','https://discovery.ucl.ac.uk/1444928/1/U592238.pdf','pdf_text_extracted_screenshot_failed_large_file',notes='Table 0.1 historical past famines pp.74–77; web screenshot attempted but refused for oversized PDF; original 18c documents not reviewed')
s('saltworkers','Cambridge University Press / International Review of Social History','Environmental Changes, Fuel Market, Working Conditions of Bengal Salt Makers c.1780–1845','https://www.cambridge.org/core/journals/international-review-of-social-history/article/environmental-changes-the-emergence-of-a-fuel-market-and-the-working-conditions-of-salt-makers-in-bengal-c-17801845/EFF95B979EA1BC59C12DAFD1E623FB58','journal_full_html_read')
s('carnatic','Royal Collection Trust','Map of the Carnatic marches 1781–1784','https://militarymaps.rct.uk/other-18th/19th-century-conflicts/map-of-the-carnatic-1781-4-tamil-nadu-india','museum_map_catalogue_read','RCIN 734062','Historical march map, not area of sovereignty')
s('poligarHist','Tamil Nadu History Congress','Proceedings: Poligar Rebellion, primary archive series list','https://www.tnhc.org.in/docs/proceedings/Chidambaram-2012.pdf','conference_pdf_search_excerpt_not_page_visual_verified',notes='Listed original Revenue Consultations 1798, Board of Revenue 1799, Secret Sundries 1799; no paper volumes personally inspected')

def make_case(title,topic,rationale,keys,entries,notes,gaps):
 global next_n
 id='AB-NEW-'+str(next_n).zfill(3);next_n+=1
 sr=[smap.get(k,k) for k in keys]
 N['candidates'].append({'candidate_id':id,'title':title,'related_original_topic_id':topic,'rationale':rationale,'source_ids':sr,'decision':'propose_to_editor','publication_status':'research_only','coverage_expansion_round':6})
 dos=[f'# {id}｜{title}','','> research_only｜第六轮扩大地区调查，主编审批前不得视为已发布地图。','','## 历史机制与受害、抵抗者','',notes,'','## 候审事件','']
 for i,(year,month,day,prec,tt,actors,place,action,effect,sourcekeys) in enumerate(entries,1):
  ev_id=f'AB-R6-{id[-3:]}-{i:02d}'
  ss=[smap.get(k,k) for k in sourcekeys]
  urls=[next(x['url'] for x in S['sources'] if x['id']==xx) for xx in ss]
  obj={'id':ev_id,'topic_ids':[id,topic],'year':year,'month':month,'day':day,'date_precision':prec,'title':tt,'actors':actors,'location':place,'action':action,'political_effect':effect,'source_ids':ss,'source_urls':urls,'research_status':'candidate_not_published','map_state':'named_place_without_verified_event_coordinates','geometry_id':None,'confidence':'sourced_historical_study_with_primary_review_pending','historical_control_boundary_verified':False,'actual_British_control_area_sqkm':None}
  E['events'].append(obj)
  dos+= [f'### {ev_id}｜{year}｜{tt}','','- '+action,'- 地点：'+place+'；主体：'+actors,'- 史料：'+', '.join('['+x+']('+u+')' for x,u in zip(ss,urls)),'- 地图：地点名可做文字，历史边界不可直接绘制；公司关税、地方割据与王室主权不能混同。','']
 dos+=['## 文献阅读级别','']
 for k in keys:
  x=smap.get(k,k);src=next(a for a in S['sources'] if a['id']==x)
  dos.append('- '+x+' '+src['title']+' — '+src['url']+'；阅读：'+src['reading_level']+'；18世纪原始手稿：未亲自查验。')
 dos+=['','## 具体缺口','',gaps,'']
 (P/'TOPIC_DOSSIERS'/'NEW_CANDIDATES'/(id+'.md')).write_text('\n'.join(dos))
 return id
poligar=make_case('1798—1799南印度Kattabomman/Palayakkarar税收与反殖民战争','E18-B21','大规模地方武装反抗，涉及公司直接税收、地方堡垒毁坏、审判处刑与1801跨世纪流放',['poligar','site','poligarHist'],[
 (1798,None,None,'year','Kattabomman与公司税务官发生征收权争执','Kattabomman; EIC Tirunelveli collector','Panchalankurichi / Tirunelveli','公司试图扩大对Palayakkarar的地税控制，本地统治者反对；具体接见日期及冲突细节需一手Revenue Consultations复核。','contested_revenue_authority',['poligar']),
 (1799,None,None,'year','英公司军围攻Panchalankurichi堡','EIC Major Bannerman; Kattabomman; local allied chiefs','Panchalankurichi','1799年英公司军攻打Kattabomman的堡垒，当地地方首领反抗并有部分首领支持公司；堡垒被攻战经过须核军报。','fort_siege_not_modern_taluka_sovereignty',['poligar','site']),
 (1799,None,None,'year','Kattabomman被地方统治者拘捕并移交公司','Kattabomman; Pudukkottai authorities; EIC officers','Pudukkottai / Kayathar','公司及结盟地方统治者抓捕Kattabomman，体现当地政治身份复杂；不得将所有Tamil政治主体描为一个反英集团。','local_alliance_and_detention',['poligar','poligarHist']),
 (1799,None,None,'year','公司处决Kattabomman','Kattabomman; EIC officers','Kayathar / Tirunelveli','1799年Kattabomman因反抗公司政权遭处刑；文献对10月16或17日的确切日期有分歧，目前保留年份。','colonial_execution_following_war',['poligar'])],
 '帕拉亚卡拉尔拥有地方武装与财政职责；公司征税与解除武装成为冲突焦点。独立性不等于现代民族主义组织；各地方首领对公司的立场并不一致。泰米尔纳德邦考古机构证实古堡残址，**35英亩是现代考古遗址规模，不是1799英国实控面积**。',
 '需要1799 Revenue Consultations、军事报告核攻城与处决日期；1801年73位poligars被运槟城属19世纪后续，应列跨世纪，不进入1799年事件/金额。')
madras=make_case('1781—1782马德拉斯粮食危机、战争破坏与赈济','E18-B13','除1770孟加拉与1790年代饥荒外，第二次英—迈索尔战争导致马德拉斯居民遭遇独立的灾荒和政府救济压力',['famine1781','carnatic'],[
 (1781,None,None,'year','迈索尔战争期间马德拉斯周边出现严重食物短缺','Hyder Ali army; EIC Madras; local civilians','Madras / Carnatic','1780–81战争摧毁粮食供给地区及乡村，殖民城市粮价恶化；居民损害须与战争各方行为分别归责。','war_related_food_crisis',['famine1781']),
 (1782,1,None,'month','马德拉斯救济机构Monegar Choultry开始设立','Madras government; local poor and famine victims','Madras city','UCL历史表记1782年1月设救济设施、放宽粮食进口限制等；为后世学术表重引，原政府拨款凭证尚未读。','famine_relief_institution',['famine1781']),
 (1782,None,None,'year','马德拉斯官方采购孟加拉米并收到捐助报告','Madras government; Bengal European residents; famine-affected households','Madras / Bengal','UCL表记孟加拉欧洲居民筹送30,000卢比，购买孟加拉米；是否实际到库及账户分摊须查同时期来信与收据。','relief_reported_not_verified_net_transfer',['famine1781'])],
 '战争中迈索尔军破坏乡村粮食来源，公司在战事中防卫Madras并采取粮米交易干预；不能把全部平民死亡归因单个参与方。统计为UCL学位论文引用18世纪地方材料的摘要表，网页PDF截图因大小限制失败，已明确降低阅读级别。',
 '必须取得1782年Madras原始食品价格和Monegar Choultry账单及各月受灾死亡报告。')
# Existing salt topic with substantially different monopoly labour mode, not duplicate new candidate
E['events'].append({'id':'AB-R6-SALT-1780','topic_ids':['E18-B20','AB-NEW-019'],'year':1780,'month':None,'day':None,'date_precision':'year','title':'孟加拉公司禁止私人制盐并加强直接生产控制','actors':'EIC Bengal revenue administration; malangi salt producers; Bengal local merchants','location':'Bengal / Bihar','action':'Cambridge历史论文指出公司1772年设盐专卖，1780年开始直接控制生产并禁止私人制盐及其附属盐类和私人盐进口。该事件不同于1788年盐拍卖改革。','political_effect':'production_and_import_monopoly_not_land_annexation','source_ids':[smap['saltworkers']],'source_urls':[next(x['url'] for x in S['sources'] if x['id']==smap['saltworkers'])],'research_status':'candidate_not_published','map_state':'not_geolocatable_specific_town','geometry_id':None,'confidence':'peer_reviewed_full_html','historical_control_boundary_verified':False,'actual_British_control_area_sqkm':None})
# add sources to matching existing case too
for a in N['candidates']:
 if a['candidate_id']=='AB-NEW-019' and smap['saltworkers'] not in a['source_ids']:a['source_ids'].append(smap['saltworkers'])
with (P/'TOPIC_DOSSIERS'/'NEW_CANDIDATES'/'AB-NEW-019.md').open('a') as f:
 f.write('\n## 第六轮补充：1780年生产垄断与salt malangis劳动\n\n1780年公司进一步直接掌握生产并禁止私人生产及进口，此为盐业生产制度转换，独立于1772初设独占与1788拍卖。研究：[BS237](https://www.cambridge.org/core/journals/international-review-of-social-history/article/environmental-changes-the-emergence-of-a-fuel-market-and-the-working-conditions-of-salt-makers-in-bengal-c-17801845/EFF95B979EA1BC59C12DAFD1E623FB58)。不要把19世纪英国Cheshire盐在印度的优势倒写至1780年。\n')
# update S and N and E; outputs csv economic/control below
S['source_count']=len(S['sources'])
for k,obj in [('SOURCE_REGISTRY.json',S),('NEW_CANDIDATES.json',N),('EVENT_CANDIDATES.json',E)]:
 (P/k).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
# add economic entries using actual CSV fields
path=P/'ECONOMIC_EVIDENCE.csv'
with path.open(encoding='utf-8-sig',newline='') as f:r=csv.DictReader(f);fld=r.fieldnames;F=list(r)
Fids={x['id'] for x in F}
def econ(id,topic,yr,val,unit,defn,payer,to,source,period='',denom='',limit='',role='scholarly_secondary',end=None,received=False):
 if id in Fids:raise ValueError(id)
 o={k:'' for k in fld};o.update({'id':id,'topic_ids':topic,'year_start':str(yr),'year_end':str(end if end is not None else yr),'value':str(val),'currency_or_unit':unit,'metric_definition':defn,'payer_or_affected':payer,'recipient_or_observer':to,'accounting_period':period,'source_ids':source,'source_urls':';'.join(next(s['url'] for s in S['sources'] if s['id']==z) for z in source.split(';')),'source_reading_level':'modern_scholarly_abstract_or_html','source_role':role,'verification_status':'reported_in_scholarly_secondary_source_not_original_ledger','was_primary_manuscript_personally_read':'False','actual_received_or_transferred_verified':str(bool(received)),'numerator_denominator':denom,'interpretation_limit':limit});F.append(o);Fids.add(id)
# Rajshahi district assessed and actual separate; figures not company net profit
for yr,assessed,received in [(1769,2601000,2438342),(1770,2676000,2146247),(1771,2751000,2612391)]:
 econ('R6-RAJ-'+str(yr)+'-ASSESSED','AB-NEW-062;E18-B07',yr,assessed,'INR_current_period_rupees_nominal','Rajshahi zamin tax assessment fiscal year','Rajshahi cultivators and zamindari','EIC revenue assessment', 'BS230',f'{yr}–{yr+1}',limit='District-only secondary table, not Bengal gross collections; rupees current period, no GBP conversion',end=yr+1)
 econ('R6-RAJ-'+str(yr)+'-COLLECTED','AB-NEW-062;E18-B07',yr,received,'INR_current_period_rupees_nominal','Rajshahi district revenue reportedly collected fiscal year','Rajshahi cultivators and zamindari','EIC revenue treasury','BS230',f'{yr}–{yr+1}',limit='Reported regional receipts, not exports to Britain; verify Firminger original table',end=yr+1)
for seg,qty,region,period in [('WINDWARD',21,'Windward Coast','Mar 1720'),('GOLD',22,'Gold Coast','5 Apr–2 May 1720'),('CALABAR',75,'Old Calabar','late May–early July 1720')]:
 econ('R6-HANNOVER-'+seg,'AB-NEW-065;E18-E10',1720,qty,'persons_purchased_captive','People recorded purchased enslaved aboard Hannover at '+region,'Enslaved Africans','Robert Bogle Jr and cargo agent Alexander Horsburgh','BS222',period,limit='Port-stage purchases, not arrivals, ship deaths or African population; 21+22+75=118 purchases can be derived without re-counting')
econ('R6-CALABAR-1767-KILLED','AB-NEW-064;E18-E10',1767,300,'persons_lower_bound','Estimated minimum number killed in Old Calabar massacre (more than 300)','Old Town traders, residents and families','British captains and Duke Town allied attackers','BS221',limit='Oxford study describes MORE THAN 300; 300 is conservative floor, not exact count, separate kidnapped and shipped')
for code,num,name in [('DEAD',36,'British officers killed or died wounds'),('CAPTURED_WOUNDED',34,'wounded and taken prisoner'),('CAPTURED_UNWOUNDED',16,'unwounded and taken prisoner')]:
 econ('R6-POLLILUR-1780-'+code,'AB-NEW-067;E18-B13',1780,num,'British_officers_persons','1780 Pollilur '+name,'EIC officers in Baillies force','Mysore army under Hyder Ali and Tipu','BS225',limit='Scholarly breakdown specifically British officers; does not cover sepoy rank-and-file or other dead')
econ('R6-MADRAS-1782-RELIEF','AB-NEW-070;E18-B13',1782,30000,'rupees_18c_nominal','Donation sent by Bengal European residents as reported in later famine overview','European residents Bengal','Madras famine relief','BS236',limit='Later UCL thesis historical table, screenshot failed; original receipt not read, do not treat as Company operating profit',role='later_historical_tabulation',received=False)
with path.open('w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fieldnames=fld);w.writeheader();w.writerows(F)
# transitions chronology
path=P/'CONTROL_TRANSITIONS_B_E.csv'
with path.open(encoding='utf-8-sig',newline='') as f:r=csv.DictReader(f);fld=r.fieldnames;T=list(r)
maxid=max(int(t['id'][1:]) for t in T if t['id'].startswith('T'))
def trans(date,place,froms,tos,actors,sem,ss,eid,uncertainty):
 global maxid
 maxid+=1;T.append({'id':f'T{maxid:03d}','date':date,'place':place,'from_status':froms,'to_status':tos,'actors':actors,'control_semantics':sem,'historical_boundary_verified':'false','area_sqkm':'','geometry_policy':'named_site_point_or_unmapped_only','source_ids':ss,'related_event_id':eid,'uncertainty':uncertainty})
trans('1759','Surat Castle','Surat castle governor and city Nawab distinct','EIC took castle governors office; city Nawab persisted','EIC; Surat city Nawab','fort_office_not_full_city_annexation','BS213;BS214','AB-R6-060-01','Mughal subjects in Surat still not all EIC Crown direct control')
trans('1772','Broach / Bharuch','local Broach Nawab and regional states','EIC district government exercised 1772–1783','EIC Bombay; Broach Nawab','district_company_control_not_modern_gujarat','BS216','AB-R6-061-01','historical district boundary not surveyed')
trans('1783','Broach / Bharuch','EIC district government','transferred to Maratha Scindia','EIC; Scindia','transfer_out_of_company_control','BS216','AB-R6-061-03','1783 exact day and cadastral limits unknown; do not retain 1784–1799 British fill')
trans('1789','Chatham Island / Phoenix Bay','Andamanese local land occupation','limited EIC convict outpost and clearing','EIC; Andamanese communities','fortified_settlement_not_whole_islands','BS211','AB-R6-058-01','Chatham settlement and Phoenix Bay clearing not exact boundary polygon')
trans('1792–1793','Port Cornwallis','initial south Andaman colonial outpost','settlement relocated north with uncertain year','Archibald Blair; EIC','temporary_outpost_relocation','BS211','AB-R6-058-03','date range only, year is null in event')
trans('1796','Port Cornwallis','EIC temporary settlement active','first penal outpost abandoned','East India Company','withdrawal_not_continuous_colonization','BS211','AB-R6-058-04','1796 abandonment is 18c, 1858 later colonization separate')
trans('1792','Assam / Guwahati','Ahom king and Moamoria conflict','EIC troops temporarily intervened at invitation of Ahom monarch','Ahom king; Captain Welsh; Moamoria','military_intervention_without_annexation','BS212','AB-R6-059-02','Assam monarchy not EIC province; exact withdrawal unverified')
trans('1727','Ouidah / Hueda','Hueda political rule with European trade forts','Dahomey under Agaja conquered Ouidah, European forts submitted to Dahomey trade governance','Agaja; Hueda; EIC merchants','african_sovereignty_not_British_territory','BS223;BS224','AB-R6-066-01','Dahomey act must not appear as UK territorial expansion')
trans('1799','Panchalankurichi','local Palayakkarar fortified polity','EIC assault and local chiefly resistance; continued frontier struggle','Kattabomman; Bannerman; local allies','temporary_military_assault_not_all_tirunelveli_annexation',smap['poligar']+';'+smap['site'],'AB-R6-069-02','1799 area boundaries not measured; govt archaeological mound 35 acres modern not control area')
with path.open('w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fieldnames=fld);w.writeheader();w.writerows(T)
# 1781 Pollilur representative point from official subject coords DMS 12°50 79°43, not exact site
geo=json.loads((P/'MAP_CANDIDATES.geojson').read_text());gid='AB-GEO-R6-POLLILUR-1781'
if gid not in {g['id'] for g in geo['features']}:
 geo['features'].append({'type':'Feature','id':gid,'geometry':{'type':'Point','coordinates':[79+43/60,12+50/60]},'properties':{'name':'Pollilur near Kanchipuram (modern location reference, 1781 battle)','representative_map_point':True,'geo_precision':'modern_named_place_reference_not_exact_1781_battlefield','geo_reference_method':'Royal Collection Trust RCIN 734067 subject location 12°50N 79°43E; not battle exact footprint or historical boundary','source_ids':['BS226'],'source_urls':['https://militarymaps.rct.uk/other-18th/19th-century-conflicts/map-of-the-battle-of-pollilur-1781-pollilur-near-kanchipuram-tamil-nadu-india-12deg5000n-79deg4300e'],'related_event_ids':['AB-R6-067-02'],'political_control_class':'research_site_reference','historical_control_boundary_verified':False,'actual_British_control_area_sqkm':None,'exclude_from_area_aggregation':True,'publication_status':'research_only','mapping_status':'named_place_reference_only_1781_not_1780'}})
(P/'MAP_CANDIDATES.geojson').write_text(json.dumps(geo,ensure_ascii=False,indent=2)+'\n')
checkpoint={'batch':2,'round':6,'new_candidates':[poligar,madras],'salt_event':'AB-R6-SALT-1780','sources':len(S['sources']),'events':len(E['events']),'new_candidate_count':len(N['candidates']),'economic':len(F),'transitions':len(T),'map_points':len(geo['features'])}
(P/'WORKING'/'SIXTH_ROUND_BATCH2_CHECKPOINT.json').write_text(json.dumps(checkpoint,ensure_ascii=False,indent=2)+'\n')
print(checkpoint)
