from pathlib import Path
from datetime import datetime
import json,csv, collections
P=Path('/mnt/data/18c_assistant_B'); W=P/'WORKING'
S={x['id']:x for x in json.loads((P/'SOURCE_REGISTRY.json').read_text())['sources']}
E=json.loads((P/'EVENT_CANDIDATES.json').read_text())['events']; eid={x['id'] for x in E}
N=json.loads((P/'NEW_CANDIDATES.json').read_text())['candidates']
with (P/'SYSTEMIC_POLICY_ACCOUNTABILITY_MATRIX.csv').open(encoding='utf-8-sig',newline='') as f:M=list(csv.DictReader(f))
F=list(csv.DictReader((P/'ECONOMIC_EVIDENCE.csv').open(encoding='utf-8-sig',newline='')))
T=list(csv.DictReader((P/'CONTROL_TRANSITIONS_B_E.csv').open(encoding='utf-8-sig',newline='')))
valid_source=lambda ids: all(t in S for t in ids)
errors=[]
for r in M:
 for i in r['event_ids'].split(';'):
  if i not in eid:errors.append('policy unknown event '+r['\ufeffpolicy_id']+' '+i)
 for i in r['source_ids'].split(';'):
  if i not in S:errors.append('policy unknown source '+r['\ufeffpolicy_id']+' '+i)
 if r['primary_manuscript_read']!='false':errors.append('asserted manuscript inspected')
 if r['historical_control_polygon_verified']!='false':errors.append('asserted polygon verified')
assert not errors,errors

policy_research='''# 第七轮：制度化殖民剥削与知情监管的证据矩阵（1700—1799）

> 爱英TV助手2，2026-11-08；研究级（research_only），禁止作为已刊地图。这里的“体系化”特指可核实的法律、董事命令、会计程序、监督结构在多时点连续运作；“默许”只在存在**知情时间、具体决策者、可采取的措施以及其后的继续行为**四要素时作为候审判断，不以结果倒推所有官员同谋。

## 一、证据等级与常见误读

| 等级 | 认定要求 | 本轮用途 |
|---|---|---|
| 明文授权 | 议会通过且生效的法案，或公司正式条例/条约条款已查到文本 | 奴役运输上限与奖励、1793年孟加拉地税条例、鸦片采购规则 |
| 有组织的执行 | 同期指令、预算、财政行、官员派遣与执行记录有可追溯原始出处 | 1772土地税承包、1784控制委员会、东印度公司汇款机制 |
| 有记录的知情／监督不力 | 反复请愿、调查及官员答复可以指明“知道什么、何时知道”，最终结果仍按独立证据校验 | 1772普尔尼亚请愿与税务官否认；饥荒中向伦敦致函 |
| 当事人的争议主张 | 起诉、请愿、军官索赔或殖民官方自辩，结果与数额未旁证 | 饥荒粮价、酷刑指控、土地损失与贸易商声称被规制损失 |

**重要区别：**英王、英国议会、伦敦东印度公司董事会、孟加拉总督和地方征税承包商各有不同权限；有法律层面的奴役贸易经营，足以认定国家政策支持该经济部门，但不能证明每一位奴役商人所做的私刑都得到议会逐项批准。公司取得特定税权，不自动赋予整个现代印度区域的直接主权。

## 二、国家与公司实施机制：可核时序

| 年份 | 制定／执行机构 | 政策或文书 | 经济／人口机制 | 证据 | 审核结论 |
|---|---|---|---|---|---|
| 1701、1721、1736 | 英国议会 | 亚洲棉布销售限制及其调整 | 贸易和本国制造业保护；与公司印度采购及英国转口经济并行 | BS256, BS258 | 有议会法制证据；印度行业就业变化的因果量化仍缺 |
| 1750 | 英国议会 | *An Act for extending and improving the Trade to Africa* | 国家在种植园奴役劳动需求背景下重组非洲贸易管理及堡垒责任 | BS240, BS249 | 明文制度参与；城堡雇用被奴役者需要逐堡证明 |
| 1757—1764 | 孟加拉纳瓦卜／公司及军官 | Mir Jafar付款、Clive jagir及公司收入的独立账目 | 私人赏赐、公司资产与征收权利分开，资料保存于具体卷宗 | BS259–BS264 | 目前确证目录存在，金额与个人实际到账仍待阅原卷 |
| 1765—1771 | 莫卧儿皇帝授权公司Diwani、公司征管 | 孟加拉／比哈尔／奥里萨财政机制 | 土地税入公司财政，支付军队、地方管理和出口采购等 | BS01、原研究包财政表 | 经核税权法权；净汇英额须按年度跨账核查 |
| 1769—1793 | 伦敦政府、公司董事及议会 | 印度收入盈余转往英国的政策动因、1784监督和1793续约 | 印度税收用于公司采购，英国市场销售及债权调整 | BS231, BS255 | 同行评议经济史解释，政策原信与银行转账需进一步核原件 |
| 1770—1772 | 孟加拉公司官员、董事会 | 饥荒期间继续征税、赈灾通信、董事批评 | 农户与地方商人遭灾，财政收入与市场冲击共同影响 | BS232, BS233, BS265 | 同代通信与后世研究；不把任一单因当全部死亡原因 |
| 1772 | 公司董事会、巡回税务委员会 | 五年期税收承包和农民请愿 | 征税竞标、租额负担、被控粮食截留与酷刑 | BS265 | 请愿内容遭征税官反驳；个案事实需证词和财务凭证交叉核 |
| 1773、1784、1793 | 议会／伦敦Board of Control | 《规制法》《印度法》及特许续期 | 国家监管私营公司领地财政及贸易垄断 | BS01, BS251, BS255 | 具国家立法参与，法律和实际治理效果分开 |
| 1773—1799 | 公司孟加拉政务机构 | 鸦片强制性采购与种植条规 | 代理、承包、地方农民交货限制；1799禁止私人交易 | BS252, BS253 | 管制制度明确；个体强迫指控与规模分别评估 |
| 1788—1799 | 英国议会、海关、船长及船医 | 《奴隶船规制法》及续行 | 在未废止贩奴的情况下规定装载人数、病亡上报和奖惩 | BS243–BS247 | 已直接阅读现代历史法令转录；议会并非每次执行的保证者 |
| 1788—1793 | 孟加拉公司当局 | 食盐专卖与拍卖、地税永久定额、税务争讼分权 | 购买渠道、价格与税额管理改变，地主和农户法律地位变化 | BS113, BS254 | 有制度文本；不推导全省人口损失百分比 |
| 1792—1799 | Sierra Leone Company、黑人定居者 | 塞拉利昂土地自由保有权、公司章程和自治争论 | 承诺与土地权利分配不一致、迁徙及自治诉求 | BS165 | 1799政策争议在世纪内；1800抵抗须另世纪登记 |

### 1750年立法与西非地方政治的边界

英国议会确实以殖民种植园对被奴役非洲人的需求论证非洲贸易制度（**BS240**：史密森尼法令实物馆藏目录）。公司堡垒的修建、付款、被奴役劳工及Fante政治主体干预在先前专题档案 **BS179** 及后续研究 **BS249** 中单独出现。两类材料可组合解释**国家财政支持与当地堡垒实践共存**；不能由一部1750年法令推断英国实控整片黄金海岸、每一处殖民暴行由议会明令执行，或将未读原始人员账伪称已核。

### 1788年英国奴役运输规制细节

现代转录全文 **BS244**（https://www.pdavis.nl/Legis_21.htm）记录：船舶载运人数与登记吨位挂钩；超额每名被运输者可处罚£30；船医登记人口与死亡；当死亡率低于特定阈值时允许给船长、医生规定奖金；允许调查贸易商因新法可能声称的财产损失。金额与比率在 `ECONOMIC_EVIDENCE.csv` 的 `R7-FISC-004`—`016` 字段逐项入账，全部标记**法定额度/奖金资格，而非国库实际支付**。议会对贸易同时规定限制，且在本世纪末尚未取消；因此它最直接证明国家**制度性规制并延续这一产业**。不能把装载率当死亡率，不能把禁止某类海险的例外条款解释成所有杀人的合法授权。

### 1772年孟加拉普尔尼亚被控强制征粮：当事人双方文书

埃克塞特大学 `Famine and Dearth` 同期材料转录 **BS265** 包括多个地方农民（rayat）、地主/税官关系人于1772年8月提出的控告：指称Debi Singh及代理人为高租额和控制粮食而夺取谷物、施行刑罚及转卖。孟加拉公司税务官 Ducarel 于8月24日就这些指控提出否认。两种互相冲突的叙述都是**当时公司税政处理程序中的真实文件**，但不能仅凭申诉就宣布每个暴行已经法庭认定。粮食价格的“maund”和“seer”尤其不宜用任意换算推广到全孟加拉市场。1773年委员会派兵对付 Sannyasi 也须区分“公司军队的行政强制”与具体每一次村落遭袭；目前资料可证令和相关报告，而无精确袭击点。

### 孟加拉饥荒：人口后果、税政与因果层级

先前研究已登记从约**100万到1000万**的跨研究估计，以及约 **1/6—1/3** 人口死亡的后世估算。两组估计**不是可加总的独立死亡记录，也不是同一人口分母的两个可靠统计端点**。现据 BS232–BS233 及 BS265 增加议会与公司各方通信、赈米与粮价请愿。分析应同时检查1769/70年天气和收成、人口对土地的依赖、价格和囤积、贸易路径、税收征集、赈济及疫病；结论中的“公司治理加重苦难”应指明书证和影响环节，而非用现代单一模型推算实际死者。

### 1757—1773年公司与个人财富三层账户

英国图书馆Clive系列 **BS259–BS264** 存在董事会议、纳瓦卜付款、加尔各答地租收入及Clive个人jagir等明确档案目录。供研究员按照**公司公款、地方统治者转款、个人礼品/赏赐、土地租金、军事开支、董事会授予权利**逐栏核账。同一笔 Mir Jafar 转款若同时出现在政府收支、Clive个人账户和军事奖金不得相加为三倍财富转移。所列卷宗**只核查过目录，并未亲阅页内支出表**。

### 1701—1736年英国纺织品保护制度与印度经济

BS256（英国议会行业史）及 BS258（同行评议研究）说明议会限制本土出售的印度印花棉布、保护境内制造业并多次修改。英国、印度及大西洋殖民地对纺织品有不同关税和转口规则；17世纪EIC采购网络、18世纪英国贸易法、1793特许垄断应在地图正文通过制度时间轴链接。有关“印度制造业衰落多少百分比”“某项法律导致多少失业”尚无统一年度史料，数值必须留空。

### 1793年税制：地主—佃农与司法权分别立案

BS254为印度法律网站所展示的历史法规转录，BS185为此前收录的行政材料。1793年永久定额的对象包括获得税收管理权的zamindars和其他纳税主体，其私权、地租征集权与农民租佃负担随规则调整；同时公司处理土地税争讼的法庭机制另有变化。此为结构性制度而非单次“征服全孟加拉”。每个争议税区的历史边界还应根据同代district、pargana、mauza等地名资料复核。

## 三、财政及人口口径门禁

- **公款与个人获利**：公司土地税收入、私人礼品、战争赔款、查获库存、财政拨款、奖金额度等不能相加成“英国净掠夺额”。
- **人口损失**：饥荒死亡人数、被迫登船、实际抵岸、船上死亡、1772请愿农民人数、被流放人口、公司驻堡被奴役劳工人数各有不同分母。缺少同代人口清册就不填估计精确人数。
- **制度化≠全员共同参与**：给予某部门法律权力和作出某个掠夺性行政决定是不同层面；出现官员否认、议会质询、地方抵抗时保持证据链完整。
- **空间**：法律适用范围不等于有边界图的实际控制区；本轮没有新增Polygon，也没有从历史王朝名称或现代省界虚构面积。

## 四、供审稿人和制图人员直接复核的文件

- `SYSTEMIC_POLICY_ACCOUNTABILITY_MATRIX.csv`：每条政策具决策人、执行机制、被影响人群、证据层级、来源、对应事件ID。
- `ECONOMIC_EVIDENCE.csv`：数值原口径、币种/分母、统计性质、是否已核到账。
- `DEMOGRAPHIC_AND_LABOR_MECHANISMS.csv`：人口迁徙、死亡与强迫劳动性质、可靠数量与缺口。
- `EVENT_CANDIDATES.json`、`.csv`：所有研究级历史事件，法令用全国政策地点文本，不凭空放伦敦/加尔各答坐标。
- `TOPIC_DOSSIERS/NEW_CANDIDATES/AB-NEW-071.md`—`080.md`：十个独立新专题和前六轮研究关联。
- `WORKING/SEVENTH_ROUND_SOURCE_READING_MATRIX.md`：本轮28项新增史料阅读层级、网上摘录与原始档案区别。

**严禁**：把本轮数字标为已发表事件、将现代行政边界涂为1750年商馆控制范围，或把税收承包争议定位在某一农民住宅的臆测GPS。
'''
(W/'SEVENTH_ROUND_SYSTEMIC_POLICY_EVIDENCE.md').write_text(policy_research,encoding='utf-8')

source_review=[ '# 第七轮来源阅读级别与待核原件', '', '本表严格区分：可直接阅读的法令网络转录/学术网页、档案目录、PDF摘要。**原始纸质手稿本轮均未实地查阅。**','', '|ID|来源与机构|当前阅读级别|网页|', '|---|---|---|---|' ]
for i in range(240,268):
 s=S[f'BS{i}']; source_review.append(f"|{s['id']}|{s['title'].replace('|','/')}|{s['reading_level']}|{s['url']}|")
source_review.extend(['','## 档案核对优先顺序','','1. **BS265** Exeter 1772巡回税务委员会材料：下载原始扫描、核八月农民请愿和Ducarel回应全部段落，逐人登记。','2. **BS259—264** Clive/Mir Jafar 原账：逐页记录收款日期、赠礼、兑换、年收入与个人签收证明。','3. **BS242** T70/349—356：对照1698—1713西非城堡税收与支出，查核是否有特定堡垒收款凭证。','4. **BS244/245/246** 1788、1789、1792海运法：以英国法令集原印页复核段落、吨位计算、医师奖金与时间有效期。','5. **BS251** 1783公司调查报告：由目录找到议会全文和对应年度综合账，避免把转运额直接叫作净掠夺。','6. **BS252** 1799鸦片规章：获取同时期Company规章法原印，与学者具体史实对照。','7. **BS254** 1793地税条例：确定网页转录是否经过后世改写、合并或撤销，复核原法条编号。'])
(W/'SEVENTH_ROUND_SOURCE_READING_MATRIX.md').write_text('\n'.join(source_review)+'\n',encoding='utf-8')

# Independent demographic and labor mechanism table. No manufactured counts.
demo=[
('D001','1769–1773','孟加拉','famine_mortality_estimates','Population in Bengal','1000000–10000000','people estimated in different scholarly studies','FAMINE-1770-MORTALITY-LOW;FAMINE-1770-MORTALITY-HIGH','BS24','Very wide competing estimates, not an observed population register, endpoints noncomparable','AB-R7-POL-012'),
('D002','1769–1773','孟加拉','famine_population_fraction','Population in Bengal','about 1/6–1/3','fraction estimated in secondary historical studies','FAMINE-1770-POP-FRAC-LOW;FAMINE-1770-POP-FRAC-HIGH','BS07','Do not multiply by invented population baseline or combine with D001','AB-R7-POL-012'),
('D003','1772','Purnea/Tajpur Bengal','alleged_forced_grain_acquisition','Peasant petitioners','', 'people affected','R7-FISC-020;R7-FISC-021','BS265','Petition allegations explicitly denied by company revenue officer; no reliable person count','AB-R7-POL-037;AB-R7-POL-038'),
('D004','1788–1799','British Atlantic slaving vessels','state_regulated_captive_transport','Enslaved Africans shipped by British vessels','', 'people transported/arrived/died, by voyage','','BS244;BS243','Law sets capacity formulas but supplies no per-voyage passenger/death series','AB-R7-POL-025'),
('D005','1750–1799','British West African castles','castle_enslaved_labour_and_export','Enslaved Africans and Fante communities','', 'workers by place/date','FISC-F5-Anomabo-bound-bricklayers','BS179;BS249','1753 Anomabo twelve bound bricklayers in earlier record; not all West African forts','AB-R7-POL-005'),
('D006','1791–1792','Nova Scotia to Sierra Leone','black_loyalist_settler_migration','Black Loyalists and subsequent settlers','112', 'reported deaths, including voyage or shortly afterwards','E1792-SIERRA-DEATHS;FISC-1792-Sierra-Leone-deaths','BS44;BS166','Two economic rows repeat same estimate; count once and verify passenger denominator from archive','AB-R7-POL-041'),
('D007','1792–1800','Sierra Leone','land_tenure_and_colonial_governance','Black settlers and indigenous African communities','', 'people dispossessed','','BS165','Settler complaints known; specific land parcels/people not established','AB-R7-POL-041'),
('D008','1720','Windward/Gold/Old Calabar','slave_purchase_manifest','Enslaved Africans captured and sold','118','people recorded bought on historical ship purchase fragments','R6-HANNOVER-WINDWARD;R6-HANNOVER-GOLD;R6-HANNOVER-CALABAR','BS223','21+22+75 three purchase points; no verified people delivered to Americas or mortality figure',''),
('D009','1773–1799','Bihar Patna and Benaras','agricultural_contractual_coercion','Poppy cultivators and procurement intermediaries','', 'farmers coerced','','BS252;BS253','Company regulations and scholarly case evidence; no century-wide reliable farmer count','AB-R7-POL-023;AB-R7-POL-034'),
('D010','1757–1799','Bengal weaving regions','commercial_procurement_pressure','South Asian textile producers','', 'affected weavers','','BS231;BS256','Policy and procurement mechanism; no validated regional person count or exact employment effect','AB-R7-POL-011'),
('D011','1788–1799','Atlantic passage','shipboard_recordkeeping_and_incentives','Enslaved Africans and ship surgeons','', 'actual deaths, documented per voyage','','BS244;BS245;BS246','Captain/surgeon mortality percentage thresholds are legal incentives, not observed mortality','AB-R7-ACT-01;AB-R7-ACT-02'),
('D012','1793','Bengal revenue districts','land_tenure_and_rent_liability','Zamindars and tenant farmers','', 'farmers/tenants affected','','BS254','Do not extrapolate modern Bengal region or tenants from statute alone','AB-R7-POL-030;AB-R7-POL-031'),
]
headers=['id','date_or_period','historical_geography','mechanism','affected_people','count_or_estimate','count_unit_and_denominator','linked_economic_row_ids','source_ids','interpretation_and_uncertainty','related_event_ids']
with (P/'DEMOGRAPHIC_AND_LABOR_MECHANISMS.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=headers);w.writeheader();w.writerows([dict(zip(headers,r)) for r in demo])

# R7 cross-century dependencies for explicit 1800 followup only
cross={'status':'research_only','last_year':1799,'rules':['Do not predate 1800 or later violence into 18th century','Do not draw modern boundaries as eighteenth-century company sovereignty','Link source documentary reading levels'],'next_century_follow_ups':[
 {'period':'1800 onward','subject':'Sierra Leone Company and Black Settlers resistance','18c_trigger_event_ids':['AB-R7-POL-041'],'18c_source_ids':['BS165'],'next_action':'Separate 1799 demands and 1800 confrontation; find CO 270 primary transcripts.'},
 {'period':'1801 onward','subject':'Poligar resistance, deportation and repression in southern India','18c_trigger_event_ids':[],'18c_source_ids':['BS239'],'next_action':'Do not count 1801 deportees as 1799 18c population data.'},
 {'period':'1807 onward','subject':'End of British Atlantic slave trade and subsequent enforcement','18c_trigger_event_ids':['AB-R7-POL-025','AB-R7-ACT-02'],'18c_source_ids':['BS243','BS244'],'next_action':'Slave Trade Act 1807 belongs to next century, not 1799 map.'}
 ]}
(W/'SEVENTH_ROUND_CROSS_CENTURY_QUEUE.json').write_text(json.dumps(cross,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

S_last = '\n\n## 第七轮制度责任研究增量（2026-11-08）\n\n'
S_last += f'- 本轮新增 **10个**候审专题（AB-NEW-071—080）；累计 **{len(N)}** 项新增母题、37篇原定B/E专题。新增 **47件**制度史事，累计 **{len(E)}** 事件；史料增加 **28项**，累计 **{len(S)}** 项；财经人口证据累计 **{len(F)}** 行；政治转换累计 **{len(T)}** 项。\n'
S_last += '- 新增 `SYSTEMIC_POLICY_ACCOUNTABILITY_MATRIX.csv` **23项**国家／公司决策证据矩阵，`DEMOGRAPHIC_AND_LABOR_MECHANISMS.csv` **12条**分母与强制劳动核查表。\n'
S_last += '- 明确划分议会法令/公司条例、公司指令/治理执行、报告及投诉后是否行动、尚有争议的请愿指控。1788年奴役船法的奖金和吨位数字全部为**法规规定**，不等于实际支出或人口死亡数。\n'
S_last += '- 1772年普尔尼亚请愿与1772年8月24日Ducarel否认同列，两种档案陈述不可只引用控诉方。原档目录未亲阅纸本，Exeter网站属于历史材料现代转录；不得把未核手稿写为已读。\n'
S_last += '- 孟加拉1765—1771年印本收支表£2,000的合计差额仍不消除。所有地图历史实控区域面积为null，暂时沿用22个具名Point，不添加推测Polygon。\n'
S_last += '- 第七轮主文见 `WORKING/SEVENTH_ROUND_SYSTEMIC_POLICY_EVIDENCE.md`；全部引用层级见 `WORKING/SEVENTH_ROUND_SOURCE_READING_MATRIX.md`。\n'
for name in ['README.md','PROGRESS.md']:
 with (P/name).open('a',encoding='utf-8') as f:f.write(S_last)
with (P/'GAPS_AND_CONFLICTS.md').open('a',encoding='utf-8') as f:
 f.write('''\n\n## 第七轮新增核心核查问题\n\n89. **1750非洲贸易立法与实务对应**：法令的贸易需求论证可核，但各堡垒被奴役者劳动、人员册及金流需按T70年度档逐堡检验。明文法令不能作为所有私人屠杀的逐件授权证据（BS240, BS242, BS249）。\n90. **1788贩奴运输规制法**：网络历史转录记吨位比例、死亡登记、船长与船医奖励，须同英国法令原刊逐条核对。尤其各类船舶上限阈值及“赔偿商人”条款不能简写为国家已经付款（BS244–BS246）。\n91. **Bengal 1769净对英转移**：研究指出政策导向，但公司税收、军费、印度商品采购、贸易销售、伦敦公债和私人礼物分属不同现金流，仍缺同年度对账（BS231, BS251, BS259–BS264）。\n92. **1770孟加拉人口损失**：传统一千万人估计与较低经济史估算不兼容，约一六分之一到三分之一人口的比率缺统一分母。贸易与气候、征税和赈济之间的因果需地方系列统计（BS07, BS24, BS232–233）。\n93. **1772普尔尼亚请愿真假**：Exeter当时档案转录记农民遭劫粮/酷刑投诉，Ducarel在同月答辩否认，须核原扫描、被控人证词、其他商人价格账、后续实际处分或平反（BS265）。\n94. **鸦片受强制农民人数**：1799条例与1788调查可见制度，强迫种植的村级普遍性和逐年净利不可从规章推算（BS252, BS253）。\n95. **1788船医死亡报告与国家实付奖金**：法律要求报告、设置奖励，与现存逐航次死亡表及海关支付凭证是两个研究层次；不得将名义奖励累计为国库付款（BS244）。\n96. **1793永久地税法与司法权**：网络法规转录需与1793原版条款比对，zamindar法律权限与村级农民土地占有须另立层，不使用现代省界为实控边界（BS254）。\n97. **英国棉布禁令对印度人口经济影响**：法令有据但印度纺织就业、工资、产出变化仍缺同代地区统计，不以贸易限制单独证明全国性去工业化数字（BS256, BS258）。\n98. **Sierra Leone居住权和自由土地契据**：1799黑人定居者对公司土地安排反对可核，1800骚乱不纳入本世纪；需逐地对照定居契据、原有非洲政治权利（BS165）。\n''')
# confirm no false referential ties
for d in demo:
 assert all(s in S for s in d[8].split(';')), d[0]
 assert all(e in eid for e in d[-1].split(';') if e), d[0]
print('INTEGRATED',{'events':len(E),'sources':len(S),'new_topics':len(N),'fiscal':len(F),'political_transitions':len(T),'policy_matrix':len(M),'population_mechanisms':len(demo),'new_source_review_entries':28})
