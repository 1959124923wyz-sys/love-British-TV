# coding: utf-8
"""Fourth-round archive date corrections, case notes, project README and handoff."""
from pathlib import Path
import json,csv
P=Path('/mnt/data/18c_assistant_B');rd=lambda n:json.loads((P/n).read_text(encoding='utf8'))
def wr(n,d):(P/n).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
E=rd('EVENT_CANDIDATES.json');S=rd('SOURCE_REGISTRY.json');G=rd('MAP_CANDIDATES.geojson');N=rd('NEW_CANDIDATES.json')
def putsrc(i,ins,t,url,lev):
 if any(x['id']==i for x in S['sources']):return
 S['sources'].append({'id':i,'institution':ins,'title':t,'url':url,'reading_level':lev,'original_manuscript_personally_inspected':False,'consulted_on':'2026-11-08'})
putsrc('BS175','Ghana Museums and Monuments Board','Fort Victoria Cape Coast 1821 structure on ruined 1712 Fort Phipps Tower site','https://gmmb.gov.gh/fort-victoria-cape-coast/','official_heritage_page_read')
putsrc('BS176','UNESCO World Heritage Centre','English Komenda Fort 1672 original site - UNESCO technical report','https://whc.unesco.org/document/198275','unesco_world_heritage_document_indexed_text_read')
putsrc('BS177','University of Ghana','Historical fort establishment dates (1708 Komenda, 1745 Vernon etc) differ from GMMB','https://ugspace.ug.edu.gh/server/api/core/bitstreams/46b8486b-1c23-481a-85b1-647d48288984/content','university_repository_thesis_table_indexed_text')
putsrc('BS178','Indiana University Press','Making an African City: 1730s Ga retained strong control of Accra coast trade','https://publish.iupress.indiana.edu/read/making-an-african-city/section/a8f55624-5134-4b9e-aad0-1926fbc13a44','university_press_full_online_excerpt_read')
ids={x['id'] for x in E['events']};m={x['id']:x['url'] for x in S['sources']}
if 'AB-NEW-044-006' not in ids:
 E['events'].append({'id':'AB-NEW-044-006','topic_ids':['E18-E10','AB-NEW-044'],'year':1712,'month':None,'day':None,'date_precision':'year_official_heritage_retrospective','title':'Phipps Tower 1712年英方望楼旧址（现Fort Victoria为1821年重建）','actors':'English Governor Phipps; Fante and Cape Coast local communities','location':'modern Fort Victoria site, Cape Coast','action':'加纳国家博物馆机构称181?原建筑修建于1712年，1821新Fort Victoria建在1712前堡遗迹上，现代Fort Victoria名称与建筑不能倒用于1712。','political_effect':'1721_site_predecessor_not_modern_fort_built_1821','source_ids':['BS175'],'source_urls':[m['BS175']],'research_status':'candidate_not_published','map_state':'modern_named_reference','geometry_id':'AB-GEO-CAPECOAST-VICTORIA','confidence':'official_heritage_retrospective_year','historical_control_boundary_verified':False,'actual_British_control_area_sqkm':None})
# fix our own typo on the case description year, semantic
for e in E['events']:
 if e['id']=='AB-NEW-044-006':
  e['action']='加纳博物馆机构确认Fort Victoria于1821年在1712年旧堡（Phipps Tower）遗址上修建；1712事件仅指旧堡，不将维多利亚时代建筑倒置到18世纪。';e['political_effect']='english_1712_predecessor_fort_site_not_1821_structure'
 if e['id']=='AB-NEW-041-009':e['topic_ids']=['E18-B14','AB-NEW-041']
 if e['id']=='AB-NEW-041-010':e['topic_ids']=['E18-B21','AB-NEW-041']
for g in G['features']:
 if g['id']=='AB-GEO-CAPECOAST-VICTORIA':
  g['properties']['name']='Phipps Tower 1712 predecessor site (modern Fort Victoria built 1821)'
  g['properties']['mapping_status']='modern_1821_heritage_site_reference_to_1712_predecessor_not_1712_building'
  g['properties']['source_ids']=list(dict.fromkeys(g['properties']['source_ids']+['BS175']))
  g['properties']['source_urls']=list(dict.fromkeys(g['properties'].get('source_urls',[])+[m['BS175']]))
  g['properties']['related_event_ids']=list(dict.fromkeys(g['properties']['related_event_ids']+['AB-NEW-044-006']))
 if g['id']=='AB-GEO-BRITISH-KOMENDA':
  g['properties']['source_ids']=list(dict.fromkeys(g['properties']['source_ids']+['BS176','BS177']))
  g['properties']['source_urls']=list(dict.fromkeys(g['properties'].get('source_urls',[])+[m['BS176'],m['BS177']]))
  g['properties']['historical_site_date_conflict']='UNESCO original establishment 1672; Ghana government page typo 1673–1974; University of Ghana lists fort 1708; compare scopes rather than invent 1708 change.'
 if g['id']=='AB-GEO-ACCRA-JAMES':
  g['properties']['source_ids']=list(dict.fromkeys(g['properties']['source_ids']+['BS178']))
  g['properties']['source_urls']=list(dict.fromkeys(g['properties'].get('source_urls',[])+[m['BS178']]))
  g['properties']['political_local_agency']='Ga coastal trade sovereignty and indigenous quarters independent of English fort and its walls'
# update new dossier with source conflict
f=P/'TOPIC_DOSSIERS/NEW_CANDIDATES/AB-NEW-044.md';txt=f.read_text(encoding='utf8')
marker='## 第四轮最终地理考据（禁用时代错置）'
if marker not in txt:
 txt+='\n'+marker+'\n\n- 现代 **Fort Victoria** 按[加纳博物馆机构](https://gmmb.gov.gh/fort-victoria-cape-coast/)建于**1821年**，所在地前建筑是**1712年Phipps Tower**。因此现代坐标只定位1712旧堡所在之地，不把1821建筑倒画成1712堡垒。新增事件`AB-NEW-044-006`。\n- English Komenda早期筑堡年：联合国教科文组织报告提1672，加纳政府页面含明显1974排版错误，加纳大学堡垒表列1708；保留不同建筑阶段/年代待核，不能挑其中一年宣称有确证新征服。\n- 《Making an African City》研究指出1730年代Ga人仍控制沿海交易，Fort James英商驻点并非英国占有整个Accra和Ga政治社会。\n'
 f.write_text(txt,encoding='utf8')
# save updated data
S['source_count']=len(S['sources']);wr('SOURCE_REGISTRY.json',S);wr('EVENT_CANDIDATES.json',E);wr('MAP_CANDIDATES.geojson',G)
with (P/'EVENT_CANDIDATES.csv').open(encoding='utf-8-sig',newline='') as f:columns=csv.DictReader(f).fieldnames
with (P/'EVENT_CANDIDATES.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,columns);w.writeheader()
 for e in E['events']:
  d=dict(e)
  for k in ['source_ids','source_urls','topic_ids']:d[k]=';'.join(e.get(k,[]))
  d['year_window']=json.dumps(e.get('year_window',''),ensure_ascii=False) if isinstance(e.get('year_window'),dict) else e.get('year_window','')
  w.writerow({k:d.get(k,'') for k in columns})
# progress / readme / gaps append, do not destroy previous 3 rounds
from datetime import date
with (P/'ECONOMIC_EVIDENCE.csv').open(encoding='utf-8-sig') as f:F=list(csv.DictReader(f))
with (P/'CONTROL_TRANSITIONS_B_E.csv').open(encoding='utf-8-sig') as f:T=list(csv.DictReader(f))
counts=dict(originals=37,new=len(N['candidates']),events=len(E['events']),sources=len(S['sources']),economic=len(F),geo=len(G['features']),controls=len(T))
progress=f'''\n## 第四轮完整交接｜2026-11-08｜独立研究增量，全部本地已保存\n\n上一轮174事件、149来源、87经济条目、41政治转换、14点、38遗漏专题，本轮累计 **{counts['events']}事件、{counts['sources']}来源、{counts['economic']}经济／人口条目、{counts['controls']}政治转换、{counts['geo']}个现代参考点、{counts['new']}遗漏专题候选**；原B22/E15合计37专题仍全部保留，新增候选独立报告及原母题报告补充完成。\n\n- **核心印本证据**：印度考古调查局1909年Aitchison第X卷`BS164`，内容包含1708—1799年多份十八世纪条约的编译文本。这是经读出版原文的历史条约来源，非亲自查阅当时签署手稿；网络截图因27MB限制失败。\n- **财政新账**：1770年孟加拉赈济米预支10万卢比与农耕支持40万卢比分开；1781年Carnatic收税1/6现付、5/6记纳瓦卜在公司信用账（非自动公司利润）；1785年120万帕戈达债务款+40万军政费；1787年90万军费含30万与60万分期；1762年Tanjore→Carnatic王侯间220万卢比；1793年坦贾武尔公司保证与收款机构不同的多种子账。所有数额按来源保留原币种，合同应付不视已收。\n- **西非新点**：Ghana University Cape Coast现代坐标7点（六处黄金海岸堡／一处南非Muizenberg纪念地）；旧文资料的现代堡址与历史建筑分开，特别是Fort Victoria建于1821年，而1712年为同址Phipps Tower。\n- **其他进展**：马拉巴尔1708 Tellicherry筑防、1719/1722/1725/1748胡椒专卖、1760关税许可、1765局部让地、1792/1793王侯地方治理；锡兰1795/1796康提独立外交；加纳Nzema酋长1768允许筑Apollonia堡和Ahanta对Dixcove英商抵抗；开普1795 Muizenberg当地武装及VOC分期失城；1792塞拉利昂黑人移民自治与司法。\n- **不确定性修正**：Dixcove的1700年精确持续状态未核，将调查节点`year=null`；Prampram Vernon造堡1742/1745冲突也置空。1787年Tanjore印本目录4月10日、签署正文4月20日冲突，事件只保留年。1793年条约的“1792财政生效”与“1793实际签字”分开。\n- **QA**：`WORKING/validate_and_package.py`独立验证跨表来源/ID、研究状态、点坐标、历史面积空值、无多边形；完整ZIP另做`testzip`和SHA256SUMS。研究档案没有任何GitHub写入。\n\n**下一批高收益文献**：英国图书馆`Mss Eur G37/88/4 ff.30-31`与`Mss Eur G37/84/5 f.3`实地校读1765—1771年孟加拉税款；1799年Srirangapatnam奖赏名单`IOR/L/MIL/5/159-160`；坦贾武尔条约1787年10/20日校勘；公司Carnatic/Travancore应收账；加纳Fort Vernon 1742/1745建造日及1700年Dixcove堡存在状态。新地图仍一律无认证真实疆界Polygon，不得求殖民实控面积。\n'''
for filename in ['PROGRESS.md','README.md']:
 p=P/filename;txt=p.read_text(encoding='utf8');txt += '\n'+progress;p.write_text(txt,encoding='utf8')
newgaps='''\n## 第四轮新增未核与证据冲突｜2026-11-08\n\n50. **1765—1771年Bengal年度收入账核页**：`Mss Eur G37/88/4 ff.30–31`与`G37/84/5 f.3`只核British Library馆藏目录；前轮账面£2,000合计不符继续保留。必须面对账页与议会出版表逐行比对。\n51. **1770死亡人数和救济支出**：Om Prakash转述Rajat Datta质疑传统1000万死亡估计，且记录向穆尔希达巴德贫民购米预支Rs100,000、支持农耕Rs400,000；相反另有2024研究继续引1000万。二者未能确立双方统计分母和原人口登记，死亡人数不录实证固定值；两种救济/支持资助不能混成死亡赔偿或已到账。\n52. **1781年Carnatic公司收款“五分之六”会计语义**：条约明确其为计入Nawab账户的贷记而不是五分之六已被公司吸为净利润。财务转移须与纳瓦卜借款、公司对外借贷和净存款簿重核。\n53. **1787年Tanjore签署日**：1909 Aitchison第X卷目录1787-04-10而条文末部分英签署句为1787-04-20；先保留年度与来源内部矛盾。\n54. **1793年Tanjore法律财务**：350,000 Star Pagodas为军费、114,285为推迟三年的贡赋转让、60,000为私人债务、50,000为临时积欠分期，前3年合计460,000已含其构件，不能再加三年暂缓额342,855；第7条欠款15日触发税收行政是条件不是已发生吞并。账本实缴未知。\n55. **1762年Tanjore—Carnatic赔款收款主体**：220万卢比及年20万+20万当地王侯间贡赋/礼金，由EIC担保，不能标为EIC营业额或英国海外净收益。\n56. **1787年Vernon堡和早期Dixcove节点**：GMMB对Vernon建年1742，另一大学史表1745；Dixcove1692启动筑堡，1750有成熟堡参考但1700年驻军没有独立年度记录；相关事件year已留null。\n57. **Fort Victoria年代倒置**：现代Fort Victoria建于**1821年**，但位于1712年Phipps Tower废墟原址，现代地标坐标不是1712年工事具体轮廓。\n58. **Komenda堡建成时间分歧**：UNESCO报告说原址1672年建堡、GMMB页面出现“1673—1974”明显笔误、加纳大学堡垒年代列表是1708；区分早期商站/扩建/后来重建，不按1708年一次“新征服”记录。\n59. **纸质原件和影印本**：1909编修版条约已读取可检索全文与明确条款，但并非18世纪有签章原件；馆藏目录、现代堡址GPS与殖民实控地图是三种不同证据；27MB扫描图无法在线截图，不能自称原件图页已逐页核对。\n'''
p=P/'GAPS_AND_CONFLICTS.md';p.write_text(p.read_text(encoding='utf8')+'\n'+newgaps,encoding='utf8')
wr('WORKING/FOURTH_ROUND_COMPLETION_CHECKPOINT.json',{'date':'2026-11-08','stage':'all_four_rounds_preserved','counts':counts,'qa_policy':'research_only; no historical boundaries claimed; no GitHub push','unverified_physical_originals':True})
print('FINALIZED',counts)
