"""Reproducible, read-only QA + local ZIP packaging for research-only Assistant B."""
from pathlib import Path
import json, csv, hashlib, zipfile, collections, datetime, re
P=Path('/mnt/data/18c_assistant_B')
OUT=Path('/mnt/data/18c_assistant_B_asia_africa.zip')
issues=[]; warnings=[]
def require(condition, message):
 if not condition: issues.append(message)
def get_json(name): return json.loads((P/name).read_text(encoding='utf-8'))
def get_csv(name):
 with (P/name).open('r',encoding='utf-8-sig',newline='') as f: return list(csv.DictReader(f))
E=get_json('EVENT_CANDIDATES.json')['events']
S=get_json('SOURCE_REGISTRY.json')['sources']
N=get_json('NEW_CANDIDATES.json')['candidates']
G=get_json('MAP_CANDIDATES.geojson')['features']
T=get_csv('CONTROL_TRANSITIONS_B_E.csv')
O=get_json('WORKING/ORIGINAL_TOPIC_CHECKLIST.json')
F=get_csv('ECONOMIC_EVIDENCE.csv');EC=get_csv('EVENT_CANDIDATES.csv')
sids={s['id'] for s in S}; tids={t['id'] for t in O}; newids={n['candidate_id'] for n in N}; all_tids=tids|newids; eids={e['id'] for e in E}; gids={f['id'] for f in G}; fids={f['id'] for f in F}
require(len(S)==len(sids),'Duplicated source IDs')
require(len(E)==len(eids),'Duplicated event IDs')
require(len(G)==len(gids),'Duplicated GeoJSON point IDs')
require(len(F)==len(fids),'Duplicated economic evidence IDs')
require(len(T)>=41,'Third round transition audit missing changes')
require(len({t['id'] for t in T})==len(T),'Duplicate transitions')
for t in T:
 require(t['related_event_id'] in eids,'Transition with unknown event '+t['id'])
 require(all(s in sids for s in t['source_ids'].split(';')),'Transition with unknown source '+t['id'])
 require(t['historical_boundary_verified']=='false' and not t['area_sqkm'],'Transition asserts fabricated historic extent '+t['id'])
require(len(E)==len(EC),'Event CSV row count differs from JSON')
require(len(tids)==37,'Topic count not 37')
require(len([t for t in tids if t.startswith('E18-B')])==22,'B series not 22')
require(len([t for t in tids if t.startswith('E18-E')])==15,'E series not 15')
require(len(N)>=38,'Third round new candidate dossiers missing')
require(len(list((P/'TOPIC_DOSSIERS').glob('E18-B??.md')))==22,'Missing B dossier')
require(len(list((P/'TOPIC_DOSSIERS').glob('E18-E??.md')))==15,'Missing E dossier')
require(len(list((P/'TOPIC_DOSSIERS/NEW_CANDIDATES').glob('AB-NEW-*.md')))==len(N),'Missing new candidate dossier')
require({t for e in E for t in e['topic_ids']} >= tids,'Some original topic IDs have no events')
for s in S:
 require(s.get('url','').startswith('https://'),'No HTTPS source URL: '+s['id'])
 require(s.get('reading_level') not in (None,''),'Missing source reading depth '+s['id'])
 require(s.get('original_manuscript_personally_inspected') is False,'Unverified original manuscript inspection claim '+s['id'])
for e in E:
 require(set(e['topic_ids']).issubset(all_tids),'Unknown topic or candidate ID for event '+e['id'])
 require(all(x in sids for x in e['source_ids']),'Broken source ID event '+e['id'])
 require(len(e['source_ids'])>0,'No source event '+e['id'])
 require(e.get('research_status')=='candidate_not_published','Published status on event '+e['id'])
 require(e.get('historical_control_boundary_verified') is False,'False boundary certainty event '+e['id'])
 require(e.get('actual_British_control_area_sqkm') is None,'Invented actual area event '+e['id'])
 require(e.get('geometry_id') in gids or not e.get('geometry_id'),'Bad geometry ID '+e['id'])
 if e['year'] is not None:
  require(1700<=e['year']<=1799,'Year outside 18th century: '+e['id'])
  if e.get('month') is not None: require(1<=e['month']<=12,'Invalid month '+e['id'])
  if e.get('day') is not None: require(1<=e['day']<=31,'Invalid day '+e['id'])
 else: require(bool(e.get('year_window')),'Null year without window '+e['id'])
 if e.get('source_urls'):
  require(len(e['source_urls'])==len(e['source_ids']),'Source ids and urls mismatched event '+e['id'])
for e,c in zip(E,EC): require(e['id']==c['id'],'CSV and JSON event order/id mismatch: '+e['id'])
for g in G:
 require(g['type']=='Feature','Invalid geo type '+g['id'])
 require(g['geometry']['type']=='Point','Non-point historic geometry (not verified) '+g['id'])
 coords=g['geometry']['coordinates'];require(len(coords)==2 and -180<=coords[0]<=180 and -90<=coords[1]<=90,'Invalid geo coordinates '+g['id'])
 p=g['properties'];require(p.get('historical_control_boundary_verified') is False,'Unverified historical boundary '+g['id'])
 require(p.get('actual_British_control_area_sqkm') is None,'Invented historic area '+g['id'])
 require(p.get('exclude_from_area_aggregation') is True,'Point wrongly included in area stats '+g['id'])
 require(p.get('publication_status')=='research_only','Geo was marked as published '+g['id'])
 require(all(s in sids for s in p['source_ids']),'Unknown source on geography '+g['id'])
 require(all(e in eids for e in p['related_event_ids']),'Unknown event on geography '+g['id'])
for n in N:
 require(n['related_original_topic_id'] in tids,'Invalid original topic crosswalk '+n['candidate_id'])
 require(n['decision']=='propose_to_editor','Candidate was published '+n['candidate_id'])
 require(all(s in sids for s in n['source_ids']),'Unknown source candidate '+n['candidate_id'])
for f in F:
 require(all(s in sids for s in f['source_ids'].split(';')),'Unknown fiscal source ID '+f['id'])
 require(all(t in all_tids for t in f['topic_ids'].split(';')),'Unknown fiscal topic ID '+f['id'])
 require(f.get('was_primary_manuscript_personally_read') in ['False','false',''],'Unsupported claim of personally reading original for fiscal '+f['id'])
 require(f.get('value','').strip().lower() not in ('nan','none','null'),'Unclear numeric null '+f['id'])
 if f['year_start'].strip(): require(1700<=int(f['year_start'])<=1799,'Economic date out of scope '+f['id'])
 if f['year_end'].strip(): require(1700<=int(f['year_end'])<=1800,'Economic end date out of scope '+f['id'])
fiscal=get_json('WORKING/FISCAL_ROW_CHECK.json')
require(fiscal['published_totals']['expenses']==9027609,'Published expenditures total changed')
require(fiscal['computed_totals']['expenses']==9029609,'Line item expenditures incorrectly calculated')
require(fiscal['computed_totals']['balances']==4037152,'Balance sum inaccurate')
if fiscal['published_totals']['expenses'] != fiscal['computed_totals']['expenses']:
 warnings.append('Bengal 1765–1771 printed expenses total differs from six-year item sum by GBP 2,000; both recorded; original Parliamentary Fourth Report still required.')
require(all(not g['geometry']['type']=='Polygon' for g in G),'Unverified polygons')
# All URL strings in source list require independent live/source examination; this package is not a link-check engine.
warnings.extend(['Source URLs and catalogue descriptions are recorded, not all original manuscripts inspected.','No historically verified control polygon is provided; each modern place point is an index only.'])
manifest={'title':'爱英TV助手2：1700–1799 亚洲非洲及其他海外殖民扩张研究包','date':'2026-11-08','publication_status':'research_only','github_writes':0,'original_topics':len(O),'B_topic_dossiers':22,'E_topic_dossiers':15,'new_candidate_topics':len(N),'new_candidate_dossiers':len(N),'event_candidates':len(E),'economic_evidence_rows':len(F),'source_registry_entries':len(S),'modern_site_reference_points':len(G),'control_transitions_research_only':len(T),'historical_control_polygons':0,'validation_errors':issues,'warnings':warnings}
(P/'WORKING/VALIDATION_REPORT.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
if issues:
 print(json.dumps(manifest,ensure_ascii=False,indent=2));raise SystemExit('VALIDATION FAILED: '+str(len(issues)))
# All user-facing artifacts are inside this folder. Work scripts included to support investigator handoff.
(P/'MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
checksum=[]
for p in sorted(P.rglob('*')):
 if p.is_file() and p.name!='SHA256SUMS.txt':
  checksum.append(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(P).as_posix()}')
(P/'SHA256SUMS.txt').write_text('\n'.join(checksum)+'\n',encoding='utf-8')
with zipfile.ZipFile(OUT,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for p in sorted(P.rglob('*')):
  if p.is_file():z.write(p,arcname='18c_assistant_B/'+p.relative_to(P).as_posix())
with zipfile.ZipFile(OUT) as z:
 bad=z.testzip();require(bad is None,'ZIP testzip failed '+str(bad))
 contents=z.namelist();require(len(contents)==len([p for p in P.rglob('*') if p.is_file()]),'ZIP entry count potentially incomplete')
 require('18c_assistant_B/MANIFEST.json' in contents,'ZIP missing MANIFEST')
print('SUCCESS',json.dumps({'zip':str(OUT),'size_bytes':OUT.stat().st_size,'zip_entries':len(contents),'original_topics':len(O),'events':len(E),'sources':len(S),'fiscal':len(F),'geo':len(G),'new':len(N),'transitions':len(T),'warnings':warnings},ensure_ascii=False,indent=2))
