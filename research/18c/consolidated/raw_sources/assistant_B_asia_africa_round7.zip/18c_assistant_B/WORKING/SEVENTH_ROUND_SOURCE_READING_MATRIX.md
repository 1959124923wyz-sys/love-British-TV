# 第七轮来源阅读级别与待核原件

本表严格区分：可直接阅读的法令网络转录/学术网页、档案目录、PDF摘要。**原始纸质手稿本轮均未实地查阅。**

|ID|来源与机构|当前阅读级别|网页|
|---|---|---|---|
|BS240|1750 Act for Extending and Improving the Trade to Africa, object 2019.28.2|institutional_object_catalogue_read|https://nmaahc.si.edu/object/nmaahc_2019.28.2?form=FUNKKCZRWSJ&s_src=H0000PWBUTTON|
|BS241|Parliament regulates the Africa trade: 1698 monopoly|institutional_html_read|https://www.parliament.uk/about/living-heritage/transformingsociety/tradeindustry/slavetrade/overview/parliament-regulates-the-africa-trade/|
|BS242|British transatlantic slave trade records research guide, T 70/349–356|archive_guide_html_read|https://www.nationalarchives.gov.uk/help-with-your-research/research-guides/british-transatlantic-slave-trade-records/|
|BS243|The first parliamentary debates on slave trade, 1788 Dolben Act|institutional_html_read|https://www.parliament.uk/about/living-heritage/transformingsociety/tradeindustry/slavetrade/overview/the-first-parliamentary-debates/|
|BS244|1788 Slave Trade Regulation / Dolben Act|contemporary_act_transcription_html_read|https://www.pdavis.nl/Legis_21.htm|
|BS245|1789 Slave Trade Regulation extension|contemporary_act_transcription_html_read|https://www.pdavis.nl/Legis_20.htm|
|BS246|1792 Slave Trade Regulation continuation|contemporary_act_transcription_html_read|https://www.pdavis.nl/Legis_64.htm|
|BS247|Slave trade key dates 1788–1807|institutional_chronology_html_read|https://www.parliament.uk/about/living-heritage/transformingsociety/tradeindustry/slavetrade/key-dates/|
|BS248|Britain and the Transatlantic Slave Trade briefing 2019|pdf_search_excerpt_only_not_page_verified|https://researchbriefings.files.parliament.uk/documents/LLN-2019-0104/LLN-2019-0104.pdf|
|BS249|The enslaved, the Fante, and the governors: Detached Papers of the Company of Merchants|peer_reviewed_abstract_html_read|https://doi.org/10.1017/abd.2025.10025|
|BS250|IOR/A/2: Secret and Select Committees of East India Company|archive_catalogue_read|https://searcharchives.bl.uk/catalog/036-000178727|
|BS251|IOR/L/PARL/2/15/4 Ninth Report on Company law and Asian trade|archive_catalogue_read|https://searcharchives.bl.uk/catalog/041-001116495|
|BS252|Poor Man’s Crop: Evading Opium Monopoly|peer_reviewed_html_read|https://www.cambridge.org/core/journals/modern-asian-studies/article/poor-mans-crop-evading-opium-monopoly/199D0743201BF76C8ADA72F625B85FAD|
|BS253|Boatmen contract work and resistance, Company opium governance|peer_reviewed_html_search_excerpt_read|https://www.cambridge.org/core/journals/international-review-of-social-history/article/contract-work-and-resistance-boatmen-in-early-colonial-eastern-india-1760s1850s/F839EA9C4FFBB04A9DC2F6A9145CD0E8|
|BS254|Bengal Permanent Settlement Regulation 1793|historical_law_transcription_read|https://indiankanoon.org/doc/183597006/|
|BS255|East India Company and Raj 1785–1858: 1793 charter|institutional_html_read|https://www.parliament.uk/about/living-heritage/evolutionofparliament/legislativescrutiny/parliament-and-empire/parliament-and-the-american-colonies-before-1765/east-india-company-and-raj-1785-1858/|
|BS256|Textile industries: 1721 Act, 1736 Manchester Act|institutional_html_read|https://www.parliament.uk/about/living-heritage/transformingsociety/tradeindustry/industrycommunity/overview/textileindustries/|
|BS257|Interwoven Globe: textiles timeline 1708–1736|museum_history_timeline_excerpt_read|https://www.metmuseum.org/exhibitions/listings/2013/interwoven-globe|
|BS258|Calico Madams and South Sea Cheats: 1721 trade controls|peer_reviewed_html_search_excerpt_read|https://www.cambridge.org/core/journals/journal-of-british-studies/article/calico-madams-and-south-sea-cheats-global-trade-finance-and-popular-protest-in-early-hanoverian-england/A42541469AC2D07D56DB379D6B34EFAA|
|BS259|Clive Collection general court minutes 1757–1760, Mir Jafar grants|archive_catalogue_read|https://searcharchives.bl.uk/catalog/041-000800570|
|BS260|1772 Clive testimony, jewels pledged by Mir Jafar|archive_catalogue_read|https://searcharchives.bl.uk/catalog/041-000800545|
|BS261|Clive Collection: Calcutta land gross/net revenues 1765–1770|archive_catalogue_read|https://searcharchives.bl.uk/catalog/041-000808909|
|BS262|Mir Jafar treaty Company receipts and accounts 1757–1759|archive_catalogue_read|https://searcharchives.bl.uk/catalog/041-000799999|
|BS263|Clive jagir receipts 1763–1764|archive_catalogue_read|https://searcharchives.bl.uk/catalog/041-000800345|
|BS264|IOR/H/192 Bengal affairs Mir Jafar donations, Navy share|archive_catalogue_read|https://searcharchives.bl.uk/catalog/040-000004232|
|BS265|Proceedings of Committee of Circuit 1772 July–August: Purnea peasants and directors letters|digitized_primary_excerpt_transcription_read|https://famineanddearth.exeter.ac.uk/displayhtml.html?id=fp_00358_en_committeeofcircuit_7thjuly-20thaugust1772|
|BS266|Proceedings of Committee of Circuit 1773 February 2–9|digitized_primary_excerpt_transcription_read|https://famineanddearth.exeter.ac.uk/displayhtml.html?id=fp_00355_en_committeeofcircuit_2ndfebruary-9thfebruary1773|
|BS267|Proceedings of Committee of Circuit 1773 February 15–18|archival_press_list_excerpt_read|https://famineanddearth.exeter.ac.uk/displayhtml.html?id=fp_00359_en_committeeofcircuit_15thfebruary-18thfebruary1773|

## 档案核对优先顺序

1. **BS265** Exeter 1772巡回税务委员会材料：下载原始扫描、核八月农民请愿和Ducarel回应全部段落，逐人登记。
2. **BS259—264** Clive/Mir Jafar 原账：逐页记录收款日期、赠礼、兑换、年收入与个人签收证明。
3. **BS242** T70/349—356：对照1698—1713西非城堡税收与支出，查核是否有特定堡垒收款凭证。
4. **BS244/245/246** 1788、1789、1792海运法：以英国法令集原印页复核段落、吨位计算、医师奖金与时间有效期。
5. **BS251** 1783公司调查报告：由目录找到议会全文和对应年度综合账，避免把转运额直接叫作净掠夺。
6. **BS252** 1799鸦片规章：获取同时期Company规章法原印，与学者具体史实对照。
7. **BS254** 1793地税条例：确定网页转录是否经过后世改写、合并或撤销，复核原法条编号。

## 后续追加三项网页来源（28项之外）

|ID|来源与机构|阅读级别|链接|
|---|---|---|---|
|BS268|Letter Copy Books of the Murshidabad Durbar: John Grose, William Harwood and others, 1770|digitized_historical_1919_editorial_transcription_read|https://famineanddearth.exeter.ac.uk/displayhtml.html?id=fp_00462_en_lettercopybooksofthemurshidabaddurbar|
|BS269|Black Loyalist Hunger Prevention in Sierra Leone|academic_chapter_search_excerpt_read|https://academic.oup.com/cornell-scholarship-online/book/30815/chapter/262429667|
|BS270|Observing Famine (2026): 1769-1772 EIC correspondence about the Bengal famine|academic_chapter_abstract_read|https://academic.oup.com/book/61892/chapter/548190343|
