# coding: utf-8
"""第四轮权威可追溯研究增量；仅在本地改写，幂等。原件阅读级别严格区分。"""
import json,csv,datetime,pathlib,collections
P=pathlib.Path('/mnt/data/18c_assistant_B')
def J(n):return json.loads((P/n).read_text(encoding='utf8'))
def dump(n,d): (P/n).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def csvload(n):
 with (P/n).open(encoding='utf-8-sig',newline='') as f:r=csv.DictReader(f);return list(r),r.fieldnames
def csvwrite(n,a,fields):
 with (P/n).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fields);w.writeheader();w.writerows(a)
S=J('SOURCE_REGISTRY.json'); E=J('EVENT_CANDIDATES.json'); N=J('NEW_CANDIDATES.json'); G=J('MAP_CANDIDATES.geojson'); F,ff=csvload('ECONOMIC_EVIDENCE.csv');T,tf=csvload('CONTROL_TRANSITIONS_B_E.csv')
sids={s['id'] for s in S['sources']}; eids={e['id'] for e in E['events']}; nids={n['candidate_id'] for n in N['candidates']}; gids={x['id'] for x in G['features']};fids={x['id'] for x in F};tids={x['id'] for x in T}
def s(i,inst,title,url,level='institutional_site_read',archive=None,note=''):
 if i in sids:return
 S['sources'].append(dict(id=i,institution=inst,title=title,url=url,reading_level=level,archive_identifier=archive,notes=note,original_manuscript_personally_inspected=False,consulted_on='2026-11-08'));sids.add(i)
def topic(i,title,rel,rationale,ss):
 if i in nids:return
 N['candidates'].append(dict(candidate_id=i,title=title,related_original_topic_id=rel,rationale=rationale,source_ids=ss,decision='propose_to_editor'));nids.add(i)
def ev(i,topics,year,title,actors,loc,action,pol,ss,month=None,day=None,prec='year',confidence='confirmed_in_cited_secondary_or_printed_edition',geo='not_yet_geocoded',gid=None,window=None):
 if i in eids:return
 o=dict(id=i,topic_ids=topics,year=year,month=month,day=day,date_precision=prec,title=title,actors=actors,location=loc,action=action,political_effect=pol,source_ids=ss,source_urls=[next(x['url'] for x in S['sources'] if x['id']==k) for k in ss],research_status='candidate_not_published',map_state=geo,geometry_id=gid,confidence=confidence,historical_control_boundary_verified=False,actual_British_control_area_sqkm=None)
 if window:o['year_window']=window
 E['events'].append(o);eids.add(i)
def econ(i,topics,y0,y1,value,unit,metric,payer,recipient,period,ss,role,interpret,verified='verified_in_cited_edition_or_secondary',received='False'):
 if i in fids:return
 v=dict(id=i,topic_ids=';'.join(topics),year_start=y0,year_end=y1,value=str(value) if value is not None else '',currency_or_unit=unit,metric_definition=metric,payer_or_affected=payer,recipient_or_observer=recipient,accounting_period=period,source_ids=';'.join(ss),source_urls=';'.join(next(x['url'] for x in S['sources'] if x['id']==k) for k in ss),source_reading_level='published_historical_treaty_transcription_or_scholarly_analysis_read',source_role=role,verification_status=verified,was_primary_manuscript_personally_read='False',actual_received_or_transferred_verified=received,numerator_denominator='',interpretation_limit=interpret)
 F.append({k:v.get(k,'') for k in ff});fids.add(i)
def trans(i,date,place,fr,to,actors,semantic,ss,eid,unc='边界未核，仅事件与条约级别，不代表现代行政区统一实际占领'):
 if i in tids:return
 d=dict(id=i,date=date,place=place,from_status=fr,to_status=to,actors=actors,control_semantics=semantic,historical_boundary_verified='false',area_sqkm='',geometry_policy='named_site_point_or_unmapped_only',source_ids=';'.join(ss),related_event_id=eid,uncertainty=unc)
 T.append({k:d.get(k,'') for k in tf});tids.add(i)
def geo(i,name,lon,lat,sources,events,precision='modern_named_heritage_site_reference_not_18c_footprint',method='2024 University of Cape Coast thesis Appendix D modern coordinate'):
 if i in gids:return
 G['features'].append(dict(type='Feature',id=i,geometry={'type':'Point','coordinates':[lon,lat]},properties={'name':name,'representative_map_point':True,'geo_precision':precision,'geo_reference_method':method,'source_ids':sources,'source_urls':[next(x['url'] for x in S['sources'] if x['id']==k) for k in sources],'related_event_ids':events,'political_control_class':'reference_only','historical_control_boundary_verified':False,'actual_British_control_area_sqkm':None,'exclude_from_area_aggregation':True,'publication_status':'research_only','mapping_status':'modern_named_reference_not_verified_18c_boundary'}));gids.add(i)
# 本轮新增证据，编号与前三轮隔离
s('BS150','British Library','Mss Eur G37/84/5 f.1-4: 1771 trade and 1765–71 revenue and charge notes','https://searcharchives.bl.uk/catalog/040-000809104','archive_catalogue_only','Mss Eur G37/84/5','f.3为1765-71六年收支表；目录可读，手稿未看。')
s('BS151','British Library','Mss Eur G37/88/4 ff.30-31 statement of diwani revenues and charges May-April 1765–1771','https://searcharchives.bl.uk/catalog/041-000809593','archive_catalogue_only','Mss Eur G37/88/4 ff.30-31')
s('BS152','British Library','IOR/L/MIL/5/159-160 Seringapatam Prize and Batta Rolls','https://searcharchives.bl.uk/catalog/038-000306965','archive_catalogue_only','IOR/L/MIL/5/159-160','1792–1825目录含1800年索赔与1822–25追溯，不能混称1799实时分配。')
s('BS153','British Library','Mss Eur E196 Tipu Sultan correspondence and captured library records','https://searcharchives.bl.uk/catalog/032-002278328','archive_catalogue_only','Mss Eur E196')
s('BS154','Royal Historical Society / Cambridge','1922 study English establishments on the Gold Coast; original 1750 law schedules in footnotes','https://www.cambridge.org/core/journals/transactions-of-the-royal-historical-society/article/abs/english-establishments-on-the-gold-coast-in-the-second-half-of-the-eighteenth-century/6952B0DF3DC5BB547173E0278227EF11','scholarly_article_abstract_and_footnotes_read','Transactions Royal Historical Society 1922 5:167–208','Footnote fort list based on contemporary statute, later historian citation only.')
s('BS155','Ghana Museums and Monuments Board','Fort Apollonia Beyin (1768) and Nzema chief Amenihyia permission','https://gmmb.gov.gh/fort-apollonia-beyin-1768/','official_heritage_history_read')
s('BS156','Ghana Museums and Monuments Board','Fort Metal Cross Dixcove 1692–1750 Ahanta/Infuma opposition','https://gmmb.gov.gh/fort-metal-cross-dixcove-1692/','official_heritage_history_read')
s('BS157','Ghana Museums and Monuments Board','Fort at Tantumquery English fort built 1720s','https://gmmb.gov.gh/the-fort-at-tantumquery/','official_heritage_history_read')
s('BS158','Ghana Museums and Monuments Board','Fort Vernon Prampram built 1742 (cf other table 1745)','https://gmmb.gov.gh/fort-vernon-prampram/','official_heritage_history_read')
s('BS159','Ghana Museums and Monuments Board','British Fort, English Komenda (chronology internal typo)','https://gmmb.gov.gh/british-fort-english-komenda/','official_heritage_history_read','', 'Page says between 1673 and 1974 (likely typo); other sources say 1708, so no publication-grade exact year.')
s('BS160','Banglapedia Asiatic Society of Bangladesh','Farrukh Siyar Farman 1717 Bengal customs grant and annual peshkash Rs3000','https://en.banglapedia.org/index.php/Farrukh_Siyar%E2%80%99s_Farman','scholarly_encyclopedia_full_html_read')
s('BS161','London School of Economics / Om Prakash','The Transformation from a Pre-Colonial to a Colonial Order, page 29 famine demography and relief','https://www.lse.ac.uk/Economic-History/Assets/Documents/Research/GEHN/GEHNConferences/conf2/Conf2-OPrakash.pdf','scholarly_conference_pdf_text_and_screenshot_page29','GEHN Conf 2 O Prakash p29','Cites Rajat Datta; questions 10m conventional death tally; numbers are aid pledges/advances not complete spending audit.')
s('BS162','Geographical Review / Senjuti Mallik 2024','Corporate colonial biopolitics Bengal famine (uses 10m conventional estimate)','https://www.tandfonline.com/doi/full/10.1080/00167428.2024.2325977','academic_article_abstract_read','doi:10.1080/00167428.2024.2325977','10m mortality claim differs from Om Prakash appraisal.')
s('BS163','University of Cape Coast / Blessing Charuka 2024','Appendix D of Ghana coast thesis modern coordinates for forts and castles','https://ir.ucc.edu.gh/xmlui/bitstream/handle/123456789/12199/CHARUKA%2C%202024.pdf?isAllowed=y&sequence=1','university_repository_pdf_extracted_text_appendix_D','PhD dissertation 2024 p213','Source modern heritage geocoding only; PDF screenshot endpoint returned 404; original colonial boundaries not available.')
s('BS164','Archaeological Survey of India / Government of India','1909 Aitchison Treaties Vol X: Madras and Ceylon, 18th-century treaty copies','https://ignca.gov.in/Asi_data/14009.pdf','digitized_1909_primary_document_compilation_text_read_screenshot_failed_large_pdf','ASI accession 14009; 341.254/Ait Vol X','Transcriptions of 18th century treaties in 1909 compendium, original executed instruments not seen; screenshot unavailable (file too large).')
s('BS165','University of New Brunswick, Loyalist Collection','TNA CO 270/2-6 Freetown council minutes 1792–1801','https://loyalist.lib.unb.ca/record/sessional-papers-sierra-leone-co-270-1792-1801','archival_inventory_with_detailed_description','TNA CO 270/2–6')
s('BS166','University of New Brunswick, Loyalist Collection','John Clarkson Papers 1791–1792 Black Loyalist emigration','https://loyalist.lib.unb.ca/record/papers-1785-1853','archival_inventory_with_counts','Add MS 41262A','1190 migrated; 112 died en route or shortly thereafter; timing not broken down.')
s('BS167','University of Cape Town / City of Cape Town','Muizenberg Battle 1795 heritage site remains and indigenous Corps Pandoeren','https://www.capetown.gov.za/media-and-news/city-secures-battle-of-muizenberg-site-as-a-provincial-heritage-site/','municipal_official_heritage_statement_read','Heritage Western Cape gazette 27 Mar 2026')
s('BS168','South African History Online','Battle of Muizenberg 7 Aug 1795 and British Cape surrender 16 Sep 1795','https://sahistory.org.za/place/battle-muizenburg-monument-muizenburg','public_history_full_html_read','SAHO P-0124791','Modern memorial coordinates -34.1130,18.4650 not actual artillery position.')
s('BS169','Cambridge / Journal of Royal Asiatic Society','English EIC and society Maritime Ceylon 1796–1802','https://www.cambridge.org/core/journals/journal-of-the-royal-asiatic-society/article/abs/english-east-india-company-and-society-in-the-maritime-provinces-of-ceylon-17961802/5B3A7559C0E5DB8043C170CE995F3271','academic_article_extract_read','doi:10.1017/S0035869X00129181','Caste obligations upheld under early Company governance; primary factory records cited but not inspected.')
s('BS170','South African History Online','Fortifications at the Cape Dutch British 1795–1803 transitional occupation','https://sahistory.org.za/place/dutch-and-british-coastal-fortifications-cape-good-hope-1665-1829','public_history_full_html_read')
s('BS171','University of New Brunswick Library','John Clarkson Papers and 1792 elected Freetown settlers; Sierra Leone CO 270 collection guide','https://lib.unb.ca/guides/loyalist-collection-black-history','academic_archive_guide_read')
s('BS172','Oxford University Press / Rachel B Herrmann','Black Loyalist Hunger Prevention in Sierra Leone elected Hundredors/Tythingmen','https://academic.oup.com/cornell-scholarship-online/book/30815/chapter/262429667','academic_book_excerpt_read','Oxford online monograph','1792–1793 elected offices; 1800 revolt after 18C cut-off; original council minutes cited by historian not inspected here.')
s('BS173','City of Cape Town','Stories of the South Peninsula Ch8 Muizenberg 7 Aug 1795 fighting','https://resource.capetown.gov.za/documentcentre/Documents/City%20research%20reports%20and%20review/Stories_of_the_South_Peninsula_chapter_08_2014-06.pdf','municipal_pdf_indexed_extract_read','City of Cape Town report ch8','Pdf web screenshot not yet verified.')
# 本轮新增专题候选
for z in [
 ('AB-NEW-039','1763—1792卡纳提克纳瓦卜债务、年贡、公司条件税收和战时接管','E18-B18','公司军费条约与地方国库间的政治及财政控制；分清纳瓦卜继续在位和公司战时接管。',['BS164']),
 ('AB-NEW-040','1762—1799坦贾武尔王室、纳戈尔授地和公司军事财政','E18-B21','277村庄和Nagore的176?授地与1799后合同不等于全部王国直接领土。',['BS164']),
 ('AB-NEW-041','1708—1765马拉巴尔沿岸Tellicherry堡、胡椒专卖与地方政体','E18-B01','多个地方Nayar国君的胡椒贸易特许和特定岛屿/堡垒让与须区别。',['BS164']),
 ('AB-NEW-042','1787—1795特拉凡哥尔军费附属、1793胡椒合同及1791科钦政治关系','E18-B21','军费、贸易排他权与政治联盟独立建模，不得以胡椒合同涂色独立王国。',['BS164']),
 ('AB-NEW-043','1795—1796康提国王对英盟约、荷属锡兰海岸易手与公司官员治理','E18-E05','1795与康提的两次谈判和1796荷城降约，均非康提被吞并。',['BS164','BS169']),
 ('AB-NEW-044','1700—1799黄金海岸英商堡垒多节点：Nzema、Ahanta、Ga/Fante自主','E18-E10','并列具体堡垒开建、当地准许和包围抵抗，修复只在海岸角和阿诺马布落点的缺口。',['BS154','BS155','BS156','BS157','BS158']),
 ('AB-NEW-045','1799斯里兰加帕特纳文献与宫廷图书馆遭英印军事接管','E18-B15','军队战利品与掌握文献档案是不同财产转移；档案仅列入文书去向，货币净收入未知。',['BS153']),
 ('AB-NEW-046','1795开普征服逐次驻点、Khoikhoi士兵与布尔民兵抵抗','E18-E06','不能把王室与荷属东印度公司的协议直接等同驻军征服过程，保留本地群体政治。',['BS167','BS168'])
]:topic(*z)
# 事件：比原有174件更细，谨慎处理日期/法权类别
for z in [
 ('AB-B01-003',['E18-B01','AB-NEW-002'],1717,'法鲁赫西亚尔关税敕令规定公司年付3000卢比','Mughal emperor Farrukh Siyar; EIC factors','Bengal subah','Mughal法令允许公司货物按年付peshkash Rs3000免关税，还涉及商馆、债务和村庄租售；非全境授土。','commercial_farman_customs_exemption',['BS160']),
 ('AB-B07-007',['E18-B07'],1770,'公司向穆尔希达巴德附近粮食慈善分配预支10万卢比','EIC Council; Murshidabad poor','Murshidabad','Om Prakash转引Rajat Datta称至1770年4月此项用于购米援助的已预支100000卢比；需追源核付现清单。','recorded_famine_relief_advance_not_total',['BS161']),
 ('AB-B07-008',['E18-B07'],1770,'穆尔希达巴德库房1769—70支援农事款四十万卢比','Murshidabad treasury; cultivators','Murshidabad hinterland','后世学术汇总称1769年4月至1770年5月400000卢比用于资助农民下季生产；与购米预支不得简单合并成总赈济。','cultivator_aid_account_not_mortality',['BS161'],dict(prec='interval',window={'start_year':1769,'end_year':1770,'interpretation':'financial aid April 1769-May 1770; recorded in end year 1770'})),
 ('AB-B18-007',['E18-B18'],1771,'Clive Collection保存1765—1771逐年Diwani税款与开支手稿表','EIC revenue departments','Bengal and Bihar','英国图书馆登记两份具体手稿账页Mss Eur G37/84/5 f3与G37/88/4 ff30–31，必须先做逐项校勘再刊货币总额。','fiscal_original_manuscripts_identified_not_read',['BS150','BS151'],dict(prec='period_end',confidence='archival_catalogue_not_manuscript_read')),
 ('AB-B15-003',['E18-B15','AB-NEW-045'],1799,'提普苏丹宫廷档案与图书被征服者接管并编列去向','British EIC prize agents; Tipu Sultan court','Seringapatam, Mysore','英图书馆Mss Eur E196目录记录战后Tipu藏书被分配给孟加拉亚洲学会和东印度公司图书馆的清册与来往函；无法据目录计算财产总价。','military_capture_cultural_property_inventory',['BS153'],dict(prec='year_and_postwar',confidence='catalogue_only_followup_1799_1808')),
 ('AB-NEW-044-001',['E18-E10','AB-NEW-044'],1700,'Dixcove英商堡垒在Infuma/Ahanta抗争下延宕施工','English traders; local Infuma/Ahanta chiefs; Dutch interests','Dixcove, Ghana','GMMB记英方1692开建后遭当地多次围困；1700有否在建需查堡守日记，本行仅作为17C→18C待核连续性。','coastal_fort_local_agency_not_colonial_territory',['BS156'],dict(confidence='year1700_continuity_pending_contemporary_log')),
 ('AB-NEW-044-002',['E18-E10','AB-NEW-044'],1720,'英商在Tantumquery修小堡（具体年份未核）','English traders; coastal local authorities','Otuam / Tantumquery, Ghana','GMMB确定为1720年代，年份栏留空，先按1720—1729年研究窗，不编造1721年为确年。','small_trading_fort_not_hinterland_colony',['BS157'],dict(prec='decade',confidence='1720s_only',window={'start_year':1720,'end_year':1729,'interpretation':'decade-only; year null'})),
 ('AB-NEW-044-003',['E18-E10','AB-NEW-044'],1742,'Prampram新建Fort Vernon英商堡（建筑年份来源相互矛盾）','British coastal traders; Ga coastal communities','Prampram, Ghana','GMMB单堡网页记1742，大学加纳堡垒表列1745，暂按双方冲突记录并在地图终稿年核实前不自动启用。','fort_site_history_date_dispute',['BS158'],dict(confidence='year_conflict_1742_vs_1745')),
 ('AB-NEW-044-004',['E18-E10','AB-NEW-044'],1750,'Dixcove堡至1750装炮据馆方称可容25门','British Gold Coast fort personnel; Ahanta people','Fort Metal Cross, Dixcove','GMMB称堡至1750年具备容纳至多25门炮的设施，该数为设计/装载能力，不是逐门现存清单。','military_fort_capacity_not_area',['BS156']),
 ('AB-NEW-044-005',['E18-E10','AB-NEW-044'],1768,'Nzema酋长许可下英国商人修建Apollonia堡','Nzema chief Amenihyia; Committee of Merchants Trading to Africa','Beyin / Cape Apollonia, Ghana','1766起筹料、1768开建；酋长允许建堡以平衡荷方势力并促贸易，不能视为Nzema国家主权移转。','local_permission_for_fort_not_nzema_sovereignty',['BS155'],dict(prec='year')),
 ('AB-NEW-039-001',['E18-B18','AB-NEW-039'],1763,'阿尔科特纳瓦卜授公司卡纳提克七个Magsans','Nawab Muhammad Ali of Arcot; EIC','Carnatic Payanghat','1909官方条约汇编存1763-10-16纳瓦卜给七个Magsans的Sanad与后续Chengalpet授地，实际核地不可套现代District。','jagir_grant_specific_districts_not_whole_carnatic',['BS164'],dict(month=10,day=16,prec='day')),
 ('AB-NEW-039-002',['E18-B18','AB-NEW-039'],1765,'1765年卡纳提克授地有收入表、累计2201个村庄','Nawab of Arcot; Mughal emperor; EIC','Carnatic / Chengalpet','汇编有关授地税册总计24区、2201 villages、4,42,881 pagodas 3½ annas plus 32,283 chucrams 0；为历史税额表，不可加作同一币种或实际拨款。','jagir_grant_revenue_schedule_not_cash',['BS164'],dict(month=8,day=28,prec='day')),
 ('AB-NEW-039-003',['E18-B18','AB-NEW-039'],1781,'公司与阿尔科特纳瓦卜签五年卡纳提克税收移交安排','Nawab Muhammad Ali; Fort St George EIC Council','Carnatic','1781-12-02条约约定公司管理Carnatic收益五年，纳瓦卜留1/6供私用；条约订立与逐区实际接管需分别核。','temporary_revenue_assignment_not_annexation',['BS164'],dict(month=12,day=2,prec='day')),
 ('AB-NEW-039-004',['E18-B18','AB-NEW-039'],1785,'纳瓦卜债款偿付与每年多种Pagoda义务重新协商','Nawab Muhammad Ali; EIC Madras; private creditors','Arcot/Carnatic','1785初步条款约定每年1200000 pagodas债务偿付与400000 current charges；两者不得与1787新条约各条叠算。','promised_debt_service_and_current_charges',['BS164'],dict(prec='year')),
 ('AB-NEW-039-005',['E18-B18','AB-NEW-039'],1787,'纳瓦卜支付90万Pagodas军费及逾期接税权','Nawab Muhammad Ali; East India Company','Arcot / Fort St George','1787-02-24条约订立，按Fasli周期1787-07-12起计90万Star Pagodas/年，逾期公司可在指定地区委收税；纳瓦卜仍保民事治理名义。','conditional_revenue_enforcement_and_military_subsidy',['BS164'],dict(month=2,day=24,prec='day')),
 ('AB-NEW-039-006',['E18-B18','AB-NEW-039'],1792,'1792年卡纳提克纳瓦卜重新签军费附属条约','Nawab Muhammad Ali; East India Company','Carnatic','1792-07-12条约年贡90万帕戈达，战时条件下公司取得财政管理权，纳瓦卜仍以其名义收贡；注意与1787文本相近但不可视为一份。','1792_revised_subsidiary_treaty',['BS164'],dict(month=7,day=12,prec='day')),
 ('AB-NEW-040-001',['E18-B21','AB-NEW-040'],1778,'坦贾武尔王授Nagore及277个村镇给东印度公司','Raja of Tanjore; EIC','Nagore and Muarugoddy district, Tamil Nadu','1778-06-17王室Sanad列含Nagore港在内277村镇，另有土地灌溉与当地宗教权益条款；必须逐村证据定位，不能整坦贾武尔涂色。','specific_village_jagir_grant_not_tanjore_annexation',['BS164'],dict(month=6,day=17,prec='day')),
 ('AB-NEW-040-002',['E18-B21','AB-NEW-040'],1799,'坦贾武尔王室1799年与公司签新治理条约','Raja of Tanjore; East India Company','Thanjavur/Tanjore','政府条约汇编列1799-10-25关于Tanjore政体新治理安排；须查实际税收交割和王室继续存在范围。','governance_treaty_not_verified_territory_boundary',['BS164'],dict(month=10,day=25,prec='day')),
 ('AB-NEW-041-001',['E18-B01','AB-NEW-041'],1708,'Tellicherry要塞筑防条款在公司与地方政权间成立','EIC; local Malabar political authorities','Thalassery/Tellicherry','1909官方汇编列1708-08-20筑防协定，属于一具名堡的权力许可与潜在军事驻点，不是全Malabar主权。','fortification_permission_specific_site',['BS164'],dict(month=8,day=20,prec='day')),
 ('AB-NEW-041-002',['E18-B01','AB-NEW-041'],1719,'Kurangot Nayar向英商特许胡椒贸易专卖','Kurangot Nayar; EIC','Kurangot, Malabar','1719胡椒专卖Grant记录为公司商业权，贸易垄断不赋领地司法管辖。','pepper_trade_monopoly_license_not_sovereignty',['BS164'],dict(prec='year')),
 ('AB-NEW-041-003',['E18-B01','AB-NEW-041'],1722,'Kolattiri地区胡椒专卖让给英商','Kolattiri ruler; EIC','Kolattiri, Malabar','1722商业Grant，地方统治者仍保政治身份。','regional_commodity_trade_monopoly',['BS164']),
 ('AB-NEW-041-004',['E18-B01','AB-NEW-041'],1734,'Dharmapattanam岛让与东印度公司','Malabar local rulers; EIC','Dharmapattanam island','1734有特定岛屿Cession文本，应核原契和小岛历史海岸线，不得拿现代Taluk多边形表示。','island_grant_requires_historic_boundary',['BS164'],dict(prec='year')),
 ('AB-NEW-041-005',['E18-B01','AB-NEW-041'],1765,'Chirakkal Regent与英商签Randatara省让与安排','Regent of Chirakkal; EIC','Randatara, Malabar','1765-03-23地方协议，候审地图仅用历史地名空几何；政治权利与征税交付仍待核。','district_cession_contract_not_verified_possession',['BS164'],dict(month=3,day=23,prec='day')),
 ('AB-NEW-042-001',['E18-B21','AB-NEW-042'],1791,'科钦王向公司签订关系条约','Raja of Cochin; EIC','Kochi / Cochin','官方汇编列1791-01-06科钦成为英国tributary的条约；按相关义务单列，科钦王权仍在。','tributary_treaty_not_direct_annexation',['BS164'],dict(month=1,day=6,prec='day')),
 ('AB-NEW-042-002',['E18-B21','AB-NEW-042'],1793,'特拉凡哥尔王室与孟买公司签十年胡椒供货合同','Raja of Travancore; Dewan Guswa Pillai; Governor Robert Abercromby','Travancore/Malabar','1793-01-28合同供胡椒换军火及欧洲商品，期限十年；合同贸易收益与军事费用非一项。','pepper_supply_contract_not_sovereignty',['BS164'],dict(month=1,day=28,prec='day')),
 ('AB-NEW-042-003',['E18-B21','AB-NEW-042'],1795,'特拉凡哥尔同意英印公司军队支持与临时补贴','Raja of Travancore; Jonathan Duncan; EIC','near Anjengo / Anchuthengu','1795-11-17三条临时协定以一营印度士兵费用为基本补贴，额外军事援助另定，系附属关系非土地吞并。','subsidiary_military_treaty_not_annexation',['BS164'],dict(month=11,day=17,prec='day')),
 ('AB-NEW-043-001',['E18-E05','AB-NEW-043'],1795,'康提国王与英国订友好同盟条约','King of Kandy; EIC envoys','Kandy, Sri Lanka','1909官方条约汇编目录记1795-10-12友好同盟；此为康提外交主体行权，未证明英国吞并康提。','independent_kandy_treaty_not_cession',['BS164'],dict(month=10,day=12,prec='day')),
 ('AB-NEW-043-002',['E18-E05','AB-NEW-043'],1796,'康提国王与英国订进一步和平约文','King of Kandy; Company representatives','Kandy, Sri Lanka','1909官方汇编目录载1796-02-12对康提和平约文，与1796-02-15科伦坡荷军投降区分。','kandyan_diplomatic_agreement_independent',['BS164'],dict(month=2,day=12,prec='day')),
 ('AB-NEW-046-001',['E18-E06','AB-NEW-046'],1795,'英海军在开普False Bay和Simon’s Town部署','Vice-Admiral Elphinstone; VOC command; local militias','Simon’s Town, Cape','1795年6月英舰抵False Bay、英军同VOC谈判而后进驻Simon’s Town；到8月仍未占领Cape Town城。','military_staging_not_entire_cape_colony',['BS168','BS170'],dict(month=6,prec='month')),
 ('AB-NEW-046-002',['E18-E06','AB-NEW-046'],1795,'英军8月7日炮击Muizenberg荷军防线','British navy and soldiers; VOC defenders; Corps Pandoeren and burghers','Muizenberg near Rust en Vrede','VOC守军及由有色士兵构成的Korps Pandoeren、布尔民兵参与反抗；现今历史遗迹并非全1795战线。','battlefield_temporary_military_action',['BS167','BS168','BS173'],dict(month=8,day=7,prec='day',geo='modern_named_reference',gid='AB-GEO-MUIZENBERG')),
 ('AB-NEW-046-003',['E18-E06','AB-NEW-046'],1795,'开普VOC当局9月16日向英军投降','VOC Commissioner Sluysken; British command','Cape Town','Britain在战事后取得开普殖民行政据点；保留Khoikhoi、San及内陆非欧政治体自主，城堡投降不是现代西开普省全域法权。','voc_to_british_occupation_not_modern_country_control',['BS168'],dict(month=9,day=16,prec='day')),
 ('AB-E09-005',['E18-E09'],1792,'弗里敦新移民选百人代表和十人代表参与自治','Black Nova Scotian settlers; Hundredors and Tythingmen; Sierra Leone Company','Freetown, Sierra Leone','1792年12月殖民地会务有黑人移民自己选的百人代表与十人代表，需从CO270原会议记录再核；其制度与伦敦投资人公司管治有张力。','black_settler_elected_representatives_not_company_unilateral_rule',['BS165','BS172'],dict(month=12,prec='month')),
 ('AB-E09-006',['E18-E09'],1793,'黑人居民以自选陪审团处理白人水手偷猎财产案','Black Nova Scotian settlers; local jurors; Sierra Leone Council','Freetown','历史研究引用1793年12人黑人陪审团审理偷鸭案，显示移民司法能动性与殖民公司之间的权力冲突。','black_jury_autonomy',['BS172']),
 ('AB-E09-007',['E18-E09'],1799,'塞拉利昂CO270第四卷连续记录土地和治理纠纷','Sierra Leone Council; Nova Scotian settlers','Freetown','UNB馆藏CO270/4保存1796-03至1799-12会议记录，是1799土地与税争议的核查入口；并非已经逐页读完所有投诉原卷。','administrative_record_series_not_proof_of_single_revolt',['BS165'],dict(confidence='archival_inventory_not_direct_event')),
 ('AB-E09-008',['E18-E09'],1792,'克拉克森组织1190名黑人效忠派自北美移往塞拉利昂','John Clarkson; Thomas Peters; Black Loyalist households','Halifax to Sierra Leone','UNB Clarkson Papers目录约1190人航行，112人途中或抵达不久死亡；迁徙人数不是奴役航次人数，死亡时点未分拆。','resettlement_and_mortality_distinct_denominators',['BS166','BS171'])
]: ev(*z[:-1],**z[-1]) if isinstance(z[-1],dict) else ev(*z)
# 1720年代事件必须year=null，勿沿用临时例子里的1720
for e in E['events']:
 if e['id']=='AB-NEW-044-002': e['year']=None
# 财政/人口分项，尽量区分承诺金额与实际入账
for z in [
 ('FISC-1770-famine-Murshidabad-rice',['E18-B07'],1769,1770,100000,'rupee_nominal_18c','至1770年4月公司预支购米慈善款','EIC revenue / famine relief','poor around Murshidabad','up to April 1770',['BS161'],'scholarly_recount_of_Rajat_Datta','财政预支，未核验实收购买凭据或受益人数；不可当作总救助。'),
 ('FISC-1770-famine-Murshidabad-cultivators',['E18-B07'],1769,1770,400000,'rupee_nominal_18c','1769年4月—1770年5月穆尔希达巴德财政对下季种植的支持','Murshidabad treasury','cultivators','April 1769 – May 1770',['BS161'],'scholarly_recount_of_Rajat_Datta','与买米赈济款不同科目；不凭此推算援助覆盖人数。'),
 ('FISC-1717-bengal-farman-customs-payment',['E18-B01','AB-NEW-002'],1717,1717,3000,'rupee_nominal_18c','Farrukh Siyar farman stipulated annual company peshkash for customs exemption','EIC factory agents','Mughal Bengal officials','annual according to 1717 farman',['BS160'],'scholarly_farman_summary','法定年贡不是已到账总数；原法波斯手稿未亲阅。'),
 ('FISC-1781-carnatic-private-retained-fraction',['E18-B18','AB-NEW-039'],1781,1781,'1/6','revenue_fraction','1781 revenue assignment reserved one-sixth for Nawab private use','Carnatic Nawab revenue system','Nawab Muhammad Ali','1781 pact for five years',['BS164'],'1909_official_compilation_retrospective_summary','分配比例不是税收或净汇出金额；转化现款需当年已收税册。'),
 ('FISC-1785-arcot-debt-service',['E18-B18','AB-NEW-039'],1785,1785,1200000,'pagoda_18c_nominal','preliminary 1785 annual proposed debt repayment to Company and private creditors','Nawab Muhammad Ali','EIC and private creditors','annually under preliminary 1785 arrangement',['BS164'],'1909_compiled_1785_treaty_explanation','承诺偿债不等于实际偿付；1787新约重复规定不得叠加。'),
 ('FISC-1785-arcot-current-charges',['E18-B18','AB-NEW-039'],1785,1785,400000,'pagoda_18c_nominal','preliminary annual current charges distinct from debt service','Nawab Muhammad Ali','EIC','annually under preliminary 1785 arrangement',['BS164'],'1909_compiled_1785_treaty_explanation','独立于债务偿付120万Pagodas；收入科目与后续1792修约不同。'),
 ('FISC-1787-carnatic-peace-establishment',['E18-B18','AB-NEW-039'],1787,1787,900000,'star_pagoda_18c_nominal','annual military peace establishment contribution commencing Fasli 1197 July 12','Nawab of Carnatic','East India Company military treasury','annual: 300000 Nov + 600000 Mar',['BS164'],'published_treaty_No_VI_article_2','条约义务非实际收款，不推断主权转让。'),
 ('FISC-1787-carnatic-kist-nov',['E18-B18','AB-NEW-039'],1787,1787,300000,'star_pagoda_18c_nominal','November instalment subset of annual 900000 military contribution','Nawab of Carnatic','EIC','November yearly',['BS164'],'published_treaty_No_VI','年贡的子项，绝不可与900000加总。'),
 ('FISC-1787-carnatic-kist-mar',['E18-B18','AB-NEW-039'],1787,1787,600000,'star_pagoda_18c_nominal','March instalment subset of annual 900000 military contribution','Nawab of Carnatic','EIC','March yearly',['BS164'],'published_treaty_No_VI','年贡的子项，绝不可与900000加总。'),
 ('FISC-1765-carnatic-jagir-pagodas',['E18-B18','AB-NEW-039'],1765,1765,'442881.21875','pagoda_18c_schedule_partial','Carnatic company jagir historic table grand total 442881 pagodas 3½ annas; original mixed subunits recorded separately','Arcot territorial revenue','EIC jagir','1763 and 1765 grants consolidated',['BS164'],'published_revenue_schedule_historical_estimate','NOT cash collected; decimal conversion of fractional annas NOT verified; use raw mixed amount in prose only.'),
 ('FISC-1792-carnatic-military',['E18-B18','AB-NEW-039'],1792,1792,900000,'pagoda_18c_nominal','annual Carnatic defence subsidy under revised treaty','Nawab Muhammad Ali','EIC Madras','annual, 1792 revised treaty',['BS164'],'1909_compiled_treaty','Same style as 1787 but treaty revision; alternative obligations not additive.'),
 ('FISC-1792-carnatic-debt-charge',['E18-B18','AB-NEW-039'],1792,1792,621105,'pagoda_18c_nominal','annual debt assignment following 1792 revised treaty according to govt narrative','Nawab Muhammad Ali','EIC and private creditors','annual after 1792 agreement',['BS164'],'government_compilation_summarized','Not actual cash transfers; need period and payer split.'),
 ('FISC-1793-travancore-pepper-tenure',['E18-B21','AB-NEW-042'],1793,1793,10,'years_contract_duration','pepper supply duration as stipulated in trade contract','Travancore Raja','EIC Bombay','1793-01-28 contractual term',['BS164'],'treaty_transcription','Duration only, not quantity, profit, or forced labor total.'),
 ('FISC-1792-Sierra-Leone-migrants',['E18-E09'],1791,1792,1190,'persons_reported','Black Loyalists estimated participants in 1791/92 Sierra Leone emigration','Black Nova Scotian settlers','Sierra Leone','1791–1792 migration',['BS166','BS171'],'archive_collection_guide_count','Approximate persons in migration, NOT enslaved persons, plantation output or 1792 resident census.'),
 ('FISC-1792-Sierra-Leone-deaths',['E18-E09'],1791,1792,112,'persons_reported','Deaths en route or shortly after arrival, UNB Clarkson Papers catalogue','Black Nova Scotian emigrants','recorded by Clarkson papers','1791–1792 arrival phase',['BS166'],'archive_collection_guide_count','Deaths period includes post arrival; NOT voyage-only mortality; denominator of 1190 needs archive verification.')
]:econ(*z)
# Replace one awkward raw-decimal accounting entry with faithful recorded historical coin unit string (never present an invented conversion)
for r in F:
 if r['id']=='FISC-1765-carnatic-jagir-pagodas':r['value']='';r['metric_definition']='1763+1765 grant total schedule stated as 4,42,881 pagodas 3½ annas plus 32,283 chucrams 0; 24 historical mehers and 2,201 villages';r['interpretation_limit']='Mixed historical subunits; no conversion/aggregation; grant assessed revenue NOT confirmed collected cash.'
# map: University of Cape Coast modern heritage place coordinates (not political boundaries). Site bibliography assessed but not old footprints.
for z in [
 ('AB-GEO-DIXCOVE','Fort Metal Cross, Dixcove',-1.944939,4.793394,['BS163','BS156'],['AB-NEW-044-001','AB-NEW-044-004']),
 ('AB-GEO-ANOMABU','Fort William, Anomabu',-1.119103,5.174119,['BS163','BS120'],['AB-E10-006']),
 ('AB-GEO-APOLLONIA','Fort Apollonia, Beyin',-2.590025,4.987167,['BS163','BS155'],['AB-NEW-044-005']),
 ('AB-GEO-BRITISH-KOMENDA','British Fort, English Komenda',-1.489604,5.050000,['BS163','BS159'],['AB-E10-002']),
 ('AB-GEO-ACCRA-JAMES','Fort James, Jamestown Accra',-0.211426,5.533578,['BS163','BS154'],['AB-E10-002']),
 ('AB-GEO-CAPECOAST-VICTORIA','Fort Victoria, Cape Coast',-1.249233,5.106757,['BS163','BS154'],['AB-E10-002']),
 ('AB-GEO-MUIZENBERG','Muizenberg battle memorial (site reference)',18.4650,-34.1130,['BS168','BS167'],['AB-NEW-046-002'])
]:
 if z[0]=='AB-GEO-MUIZENBERG':geo(*z,precision='modern_saho_heritage_marker_not_1795_gun_position',method='SAHO designated modern battle monument coordinate -34.1130,18.4650')
 else:geo(*z)
for z in [
 ('T042','1768','Beyin/Fort Apollonia','Nzema coast independent Nzema polity and local trade','Nzema Chief Amenihyia permission for English fort construction','Nzema chief; British merchants','fort_permission_not_sovereignty',['BS155'],'AB-NEW-044-005'),
 ('T043','1781-12-02','Carnatic','Nawab revenue administration','five-year treaty assignment of revenues to EIC, private share reserved for Nawab','Nawab Muhammad Ali; EIC','temporary_fiscal_assignment_not_instant_territorial_annexation',['BS164'],'AB-NEW-039-003'),
 ('T044','1787-02-24','Carnatic treaty','Nawab military and civil institutions','EIC receives conditional fiscal receivership and troops authority on unpaid kists','Nawab Muhammad Ali; EIC','conditional_tax_rights_not_historically_mapped_area',['BS164'],'AB-NEW-039-005'),
 ('T045','1778-06-17','Nagore and Tanjore villages','Tanjore Raja historic jurisdiction','specific grant of 277 villages/small towns incl Nagore to Company jagir','Tanjore Raja; EIC','village_jagir_not_whole_kingdom',['BS164'],'AB-NEW-040-001'),
 ('T046','1708-08-20','Tellicherry','Malabar local sovereignty','company granted named fortification permission','EIC; Malabar local rulers','named_fort_license_not_regionwide_control',['BS164'],'AB-NEW-041-001'),
 ('T047','1719','Kurangot','local Nayar ruler controls pepper commerce','pepper trade monopoly granted to English Company','Kurangot Nayar; EIC','trade_monopoly_not_territory',['BS164'],'AB-NEW-041-002'),
 ('T048','1722','Kolattiri','Kolattiri polity controls trade','pepper sale privilege to Company','Kolattiri ruler; EIC','trade_exclusivity_not_sovereignty',['BS164'],'AB-NEW-041-003'),
 ('T049','1734','Dharmapattanam','Malabar local rulers hold island','documentary cession of island to EIC, handover geography unverified','Malabar rulers; EIC','island_cession_without_verified_shoreline',['BS164'],'AB-NEW-041-004'),
 ('T050','1765-03-23','Randatara','Chirakkal regency','documentary local cession arrangement','Chirakkal Regent; EIC','district_transfer_no_verified_boundary',['BS164'],'AB-NEW-041-005'),
 ('T051','1791-01-06','Cochin','Raja of Cochin independent political actor','tributary status specified in company treaty','Raja of Cochin; EIC','tributary_relation_not_company_sovereignty',['BS164'],'AB-NEW-042-001'),
 ('T052','1793-01-28','Travancore','Raja of Travancore retained sovereignty','pepper supply contract with EIC Bombay','Raja of Travancore; EIC','pepper_contract_not_territorial_change',['BS164'],'AB-NEW-042-002'),
 ('T053','1795-11-17','Travancore','Raja sovereign with prior ties','limited subsidiary military agreement, annual battalion cost','Raja; EIC','subsidiary_military_relation_not_direct_annexation',['BS164'],'AB-NEW-042-003'),
 ('T054','1795-10-12','Kandy','Kandyan independent kingdom','friendship alliance treaty with Company envoys','Kandyan king; EIC','diplomacy_no_company_occupation',['BS164'],'AB-NEW-043-001'),
 ('T055','1795-08-07','Muizenberg','VOC battle-line position with local Corps Pandoeren','British seizure of local military pass','British forces; VOC defenders; Pandoeren','battlefield_capture_not_whole_cape',['BS167','BS168'],'AB-NEW-046-002'),
 ('T056','1795-09-16','Cape Town','VOC colonial administration','British military occupation after capitulation','VOC commissioner; British commanders','colonial_core_occupation_indigenous_autonomy_preserved',['BS168'],'AB-NEW-046-003')
]:trans(*z)
# 修旧专题：强制将所有新证据附入对应报告，索引可追踪
for t in ['E18-E10','E18-B07','E18-B18','E18-E09','E18-E06','E18-B15','E18-E05','E18-B01','E18-B21']:
 f=P/'TOPIC_DOSSIERS'/f'{t}.md';txt=f.read_text(encoding='utf8');marker='## 第四轮补充：档案和政治关系逐件复核'
 if marker not in txt:
  subset=[e for e in E['events'] if t in e['topic_ids'] and (e['id'].startswith('AB-NEW-04') or e['id'] in {'AB-B07-007','AB-B07-008','AB-B18-007','AB-B01-003','AB-B15-003','AB-E09-005','AB-E09-006','AB-E09-007','AB-E09-008'})]
  lines=['\n'+marker,'','从各原始条约汇编/现代档案目录及机构研究中独立提取；时间精度及主权语义以结构化事件为准。','']
  for e in subset:lines += [f"- **{e['id']}｜{e['year'] or '未确定年'}｜{e['title']}**：{e['action']} 来源："+'、'.join(f"[{si}]({u})" for si,u in zip(e['source_ids'],e['source_urls']))+'。']
  lines += ['','**阅读层级**：1909年条约编纂的影印文本为历史原件转录，非18世纪签署手稿；大英图书馆档案号仅核目录；现代遗址经纬度只作索引点。']
  f.write_text(txt+'\n'.join(lines)+'\n',encoding='utf8')
# 新候选独立专题报告
for n in N['candidates']:
 if int(n['candidate_id'].split('-')[-1])<39:continue
 f=P/'TOPIC_DOSSIERS/NEW_CANDIDATES'/f"{n['candidate_id']}.md"
 if f.exists():continue
 es=[e for e in E['events'] if n['candidate_id'] in e['topic_ids']]; fs=[x for x in F if n['candidate_id'] in x['topic_ids'].split(';')]
 out=[f"# {n['candidate_id']}｜{n['title']}",'','状态：`research_only` / `propose_to_editor`。原有E18-B/E系列ID保持不动。','',f"**推荐与原项目交叉索引：** `{n['related_original_topic_id']}`。",'','## 问题与发现',n['rationale'],'','## 逐件证据事件']
 for e in es:out += [f"### {e['id']}｜{e['year'] or e.get('year_window','区间未定')}｜{e['title']}",f"- 行动者：{e['actors']}；地点：{e['location']}；日期精度：{e['date_precision']}。",f"- 事实与权利：{e['action']}",f"- 法权分类：`{e['political_effect']}`；可验证程度：`{e['confidence']}`。",'- 证据：'+'；'.join(f"[{si}]({u})" for si,u in zip(e['source_ids'],e['source_urls'])),'']
 out += ['## 经济或人口分项（若有）','']
 if fs:
  for x in fs:out.append(f"- `{x['id']}`：{x['value']} {x['currency_or_unit']}（{x['accounting_period']}）；{x['metric_definition']}。**口径：** {x['interpretation_limit']}")
 else:out.append('现有足额/实收货币账无法确认，保持null；不得推断成本、利润或净汇出。')
 out += ['','## 地图与下一步','所有本专题地理对象先作具名点或未定位参考；不得将地方胡椒贸易许可、宗主关系、陆军战场或现代省界填成公司实占多边形；有确切让地条文也必须先核逐村或历史岛岸边界。','','**核查缺口**：需核条约的当地语言版本、年度实际税收和付款凭据、当事人答辩、原档页影及能够校准的历史地籍。','**档案声明**：18世纪物理原件未亲阅；1909编辑出版条约文字与馆藏目录保留不同阅读等级。','']
 f.write_text('\n'.join(out),encoding='utf8')
# first increment checkpoint, real writing to disk
S['source_count']=len(S['sources']);dump('SOURCE_REGISTRY.json',S);dump('EVENT_CANDIDATES.json',E);dump('NEW_CANDIDATES.json',N);dump('MAP_CANDIDATES.geojson',G);csvwrite('ECONOMIC_EVIDENCE.csv',F,ff);csvwrite('CONTROL_TRANSITIONS_B_E.csv',T,tf)
cols=['id','topic_ids','year','month','day','year_window','date_precision','title','actors','location','action','political_effect','source_ids','source_urls','research_status','map_state','geometry_id','confidence','historical_control_boundary_verified','actual_British_control_area_sqkm']
rows=[]
for e in E['events']:
 d=dict(e);d['topic_ids']=';'.join(e['topic_ids']);d['source_ids']=';'.join(e['source_ids']);d['source_urls']=';'.join(e.get('source_urls',[]));d['year_window']=json.dumps(e.get('year_window',''),ensure_ascii=False) if isinstance(e.get('year_window'),dict) else e.get('year_window','')
 rows.append({k:d.get(k,'') for k in cols})
csvwrite('EVENT_CANDIDATES.csv',rows,cols)
dump('WORKING/FOURTH_ROUND_BATCH1_CHECKPOINT.json',dict(date='2026-11-08',stage='actual_written',events=len(E['events']),sources=len(S['sources']),economic=len(F),new_topics=len(N['candidates']),geo=len(G['features']),transitions=len(T)))
print('SAVED',len(E['events']),len(S['sources']),len(F),len(N['candidates']),len(G['features']),len(T))
