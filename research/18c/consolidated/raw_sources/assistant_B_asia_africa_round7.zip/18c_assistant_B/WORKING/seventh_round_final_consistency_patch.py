from pathlib import Path
import csv,json
P=Path('/mnt/data/18c_assistant_B');W=P/'WORKING'
p=W/'SEVENTH_ROUND_SYSTEMIC_POLICY_EVIDENCE.md';s=p.read_text(encoding='utf-8').replace('BS232, BS233, BS265','BS07, BS24, BS265, BS268, BS270').replace('BS232–BS233 及 BS265','BS07、BS24、BS265、BS268、BS270')
p.write_text(s,encoding='utf-8')
p=P/'GAPS_AND_CONFLICTS.md';s=p.read_text(encoding='utf-8').replace('（BS07, BS24, BS232–233）','（BS07, BS24, BS265, BS268, BS270）')
s+='''\n99. **1770年Rangpur第一手书信**：Grose 6月19日所报917,250、632,797、284,453卢比为一个地区应征、汇城、费用与欠款的不同口径，不可称孟加拉全省的英国净收入或将本地军费当个人侵占。检查1919年印本与原稿，确认币种、日期和年次（BS268）。\n100. **1770年粮价报告**：8月7日每卢比稻米20降至12 seer属一个时点两次交易的地方官员观察；另处8–10 seer为粗paddy，质量和地点不同不能用作同一地区通胀率，亦不能证明全省米价（BS268）。\n101. **1770年地方税胥额外勒索**：Grose所引50,000–80,000卢比/年的Pykes非法收费只是官员所称“获悉”的估算，尚无逐项收款/农户证言核实，不能写为确定实际财富转移（BS268）。\n102. **Sierra Leone本地政治主体**：1796、1799年有关Temne精英King Tom的文献提醒黑人效忠派定居者也可能与本地Temne/Susu发生土地、食品与司法权争议；不得将地方社会简写成单一殖民地政体或英国王室直接管辖（BS269）。\n'''
p.write_text(s,encoding='utf-8')
source=W/'SEVENTH_ROUND_SOURCE_READING_MATRIX.md';s=source.read_text(encoding='utf-8');S={x['id']:x for x in json.loads((P/'SOURCE_REGISTRY.json').read_text())['sources']}
s+='\n## 后续追加三项网页来源（28项之外）\n\n|ID|来源与机构|阅读级别|链接|\n|---|---|---|---|\n'
for i in range(268,271):
 x=S[f'BS{i}'];s+=f"|{x['id']}|{x['title'].replace('|','/')}|{x['reading_level']}|{x['url']}|\n"
source.write_text(s,encoding='utf-8')
path=P/'SYSTEMIC_POLICY_ACCOUNTABILITY_MATRIX.csv'
with path.open(encoding='utf-8-sig',newline='') as f:reader=csv.DictReader(f);headers=list(reader.fieldnames);M=list(reader)
def p_row(pid,date,who,doc,mechanism,people,level,notes,events,sids):
 d=dict.fromkeys(headers,'');d.update({headers[0]:pid,'anchor_year':str(date),'area':'Rangpur / Bhagalpur, Bengal','decision_maker':who,'document_or_instrument':doc,'coercive_or_extractive_mechanism':mechanism,'affected_people':people,'evidence_strength_class':level,'reading_and_conflict_notes':notes,'event_ids':events,'new_candidate_id':'AB-NEW-081','source_ids':sids,'primary_manuscript_read':'false','historical_control_polygon_verified':'false'});return d
more=[
 p_row('P24',1770,'Company supervisor John Grose','24 April 1770 report to Richard Becher','Unpaid Pykes allegedly extracted extra levies of Rs50,000–80,000 a year and official demanded action','Rangpur ryots','OFFICIAL_COMPLAINT_NOT_CORROBORATED','Contemporary report of hearsay rather than paid customs ledger','AB-R7-LET-01','BS268'),
 p_row('P25',1770,'Company supervisor John Grose','19 June 1770 revenue account communication','Land tax assessment, remittances to Murshidabad and local cost/deduction accounting','Rangpur taxpayers','OFFICIAL_REVENUE_ACCOUNT','Rs917250 assessed / Rs632797 remitted / Rs284453 remaining; local fiscal flow not net UK extraction','AB-R7-LET-03','BS268'),
 p_row('P26',1770,'Company supervisor and tax staff','7 July 1770 troop-escorted payment letter','Company tax collections accompanied by armed guard and partial settlement of sepoy arrears','Rangpur taxpayers / Company sepoys','OFFICIAL_REPORT_NOT_AUDITED','Rs10000 collection reported, Rs1932 separate pay office allocation; avoid duplicated totals','AB-R7-LET-04','BS268'),
 p_row('P27',1770,'Company Bengal officers and local rulers','23 May and 7 August 1770 famine correspondence','Harvest shocks, rice price increases, troop and tax needs; correspondence to Cooch Behar ruler for food supplies','Farmers, merchants, famine-stricken households','OFFICIAL_OBSERVATION_WITH_POLICY_REQUEST','Separate recorded market shocks from specific claims of hoarding; no total famine attribution','AB-R7-LET-02;AB-R7-LET-06','BS268')
]
seen={d[headers[0]] for d in M}
for r in more:
 if r[headers[0]] not in seen:M.append(r)
with path.open('w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fieldnames=headers);w.writeheader();w.writerows(M)
for name in ['README.md','PROGRESS.md']:
 with (P/name).open('a',encoding='utf-8') as f:
  f.write('''\n\n### 第七轮末次补充：1770年穆尔希达巴德书信\n新增 `AB-NEW-081`（饥荒时的税收与军费管理），7件具日通信史事、10条不混口径的Rangpur/Bhagalpur经济证据，3项可追溯来源。修正对饥荒研究的误配来源编号，使用 BS07、BS24、BS265、BS268、BS270；本轮新增31项来源。制度责任矩阵增加4项1770年官员通信与收入管理，且明确官员自己提出反胥吏额外勒索和对民间饥荒的担忧。历史原稿未亲阅，现代历史印本转录已读。\n''')
print('POLICY MATRIX',len(M),'SOURCE REVIEWED',3)
