from pathlib import Path
import json, csv, collections,hashlib
P=Path('/mnt/data/18c_assistant_B')
S=json.loads((P/'SOURCE_REGISTRY.json').read_text())['sources'];E=json.loads((P/'EVENT_CANDIDATES.json').read_text())['events'];N=json.loads((P/'NEW_CANDIDATES.json').read_text())['candidates'];G=json.loads((P/'MAP_CANDIDATES.geojson').read_text())['features']
with (P/'ECONOMIC_EVIDENCE.csv').open(encoding='utf-8-sig',newline='') as f: F=list(csv.DictReader(f))
with (P/'CONTROL_TRANSITIONS_B_E.csv').open(encoding='utf-8-sig',newline='') as f: T=list(csv.DictReader(f))
assert (len(E),len(S),len(N),len(F),len(G),len(T))==(327,239,70,158,22,92)
R6=[n for n in N if n.get('coverage_expansion_round')==6];R6E=[e for e in E if e['id'].startswith('AB-R6-')];R6S=[s for s in S if int(s['id'][2:])>=209]
source_by_id={s['id']:s for s in S};topic_names={n['candidate_id']:n['title'] for n in R6}
# Main dossier source-aware amendments (no duplicate original historical events)
updates={
'E18-B01.md':('苏拉特1759城堡与船舶贸易', 'AB-NEW-060', '1759年苏拉特城堡长官职权由公司掌控，但城市纳瓦卜、莫卧儿臣民法权与马拉塔的税收分成仍并立。1759年11月5日城堡收入报告只见英国图书馆目录IOR/G/36/119，不曾读税册。'),
'E18-B11.md':('布罗奇1772—1783更替','AB-NEW-061','IOR/G/5明确：1772年Broach/Bharuch地区落入公司行政、1783年转交Scindia，不能持续显示为1799英国领土。'),
'E18-B13.md':('1780与1781 Pollilur不同的战役','AB-NEW-067','1780年9月10日迈索尔军击败Baillie；1781年8月27日Eyre Coote获胜。皇家收藏RCIN734067是1781图，不能错置到1780战役。1781–82马德拉斯粮食危机另见AB-NEW-070。'),
'E18-B16.md':('当地土地反抗与1799 Jungle Mahals','AB-NEW-062','Sannyasi/Fakir并非一个统一军政主体；1799年Midnapore Jungle Mahals的Adivasi、paik及农民反抗，与公司征税及jagir被收回相关。'),
'E18-B18.md':('阿瓦德王室女性财库没收','AB-NEW-057','公司通过地方盟友的军费债务、司法和驻军施压，引起1782年法扎巴德宫廷财产和jagir权利被夺争议；参见剑桥学术原文和馆藏IOR/L/PARL/2/347。'),
'E18-B21.md':('Ahom王国1792年援军与测绘','AB-NEW-059','1792年公司受Gaurinath Singha请求派Captain Welsh出兵，局部有军事行动，Ahom王国并未变成公司行政省，Moamoria有独立政治诉求。'),
'E18-E05.md':('1796—1800锡兰沿海反抗','AB-NEW-063','东印度公司占领荷兰旧海岸后改变村级头人及税务经办关系，造成多个地方抗争；不可简单概括为一种税或“全锡兰叛乱”。康提仍是独立王国。'),
'E18-E10.md':('Old Calabar屠杀、Hannover及Ouidah地方政治','AB-NEW-064','1767年英国贩奴船长与一派Efik商人合谋造成Old Town大量遇害与强制跨洋奴役，非领土占领。1720年Hannover分别购买21/22/75被奴役者，均属购买记录非抵岸数。1727年Ouidah属Dahomey征服而非英国领土。'),
'E18-E11.md':('1789–1796安达曼港口、流放监禁','AB-NEW-058','东印度公司曾短暂建监禁港口和清林定居点，1796弃守，Anadaman群岛原住民土地及岛屿不能用整体英国实控面积填色。'),
'E18-B07.md':('1789–1794南印度饥荒不是1770孟加拉饥荒','AB-NEW-068','Oxford研究记Northern Circars与南印度1789–94气候及农业危机；不可将1770孟加拉死亡估计机械移入。Rajshahi1769–72仅地区财税数据，不能合并为孟加拉年总收入。')}
for fn,(title,new_id,paragraph) in updates.items():
 p=P/'TOPIC_DOSSIERS'/fn; old=p.read_text()
 if '## 第六轮重大遗漏延伸' not in old:
  old+='\n## 第六轮重大遗漏延伸｜'+title+'\n\n'+paragraph+'\n\n**独立候选专题**：`'+new_id+'`；来源和不确定性详见 `NEW_CANDIDATES/'+new_id+'.md`。该增量仍为研究级，未进入正式地图。\n'
  p.write_text(old)
# reference and research audit
cases=[('AB-NEW-057','阿瓦德王室女性财库与jagir遭军事威逼','法扎巴德宫廷、阿瓦德贵族女性与公司财政督导','1781—1783','法扎巴德城市级候审点、jagir无经证Polygon','IOR/L/PARL/2/347'),('AB-NEW-058','安达曼流放殖民与森林土地剥夺','安达曼原住民、被流放者','1789—1796','Chatham / Phoenix Bay具名点，搬迁年有争议','需Blair原军政日记'),('AB-NEW-059','阿萨姆军事介入与调查','Ahom王廷、Moamoria地方反抗与贸易','1792—1794','Guwahati地名，王国保持独立','Welsh原始测绘'),('AB-NEW-060','苏拉特堡与保护勒索','印度商船主、莫卧儿法权与马拉塔分成','1759—1800','只许可标Su rat Castle据点，绝不画满城区','IOR/G/36/119'),('AB-NEW-061','Broach公司税权取得和交还','Broach居民、Nawab、Scindia','1772—1783','公司地区控制1783后必须结束，边界null','IOR/G/5'),('AB-NEW-062','孟加拉地税及农民/地方武装反抗','Rajshahi地主与农户、Jungle Mahals Adivasi','1760s—1799','具名地区、无统一叛乱边界','地方档及Rajshahi原簿'),('AB-NEW-063','锡兰海岸税制抗争','锡兰村民、地方头人、征税承包人','1796—1800','海岸各地分别待核；康提未被吞并','1797各地请愿'),('AB-NEW-064','Old Calabar伏击与跨海强制奴役','被谋杀和被掳的Old Town居民','1767','Old Calabar河口，非欧洲领土','英国船日志与Efik地方文书'),('AB-NEW-065','苏格兰Hannover跨非洲贩奴采购','非洲被奴役者、苏格兰船主','1719—1720','多港口是贸易关系而非航路实测坐标','苏格兰Horsburgh手稿'),('AB-NEW-066','Ouidah地方王权约束英商堡','Hueda/Dahomey王廷、商人、被掳者','1727—1762','Dahomey实际政治权力与英商经营分开','英商堡条例与达荷美王函'),('AB-NEW-067','Pollilur两战相反战果','迈索尔王国、公司兵与英军战俘','1780、1781','1781 RCT历史战图仅现代代表点','RCIN734067、1780双方战报'),('AB-NEW-068','Doji bara粮食危机','Madras/Northern Circars受灾农户儿童','1789—1794','不按现代省界涂饥荒死亡范围','具体账和死亡统计'),('AB-NEW-069','Kattabomman/Poligar战争','本地Palayakkarar、EIC官军、地方盟友','1798—1799','古堡遗址与Kayathar地名，处决日冲突','1799 Revenue Consultations'),('AB-NEW-070','1781—82 Madras饥荒救济','Madras受灾居民、战时后勤与粮商','1781—1782','城市/周边研究地点非测量受灾区','Madras粮价和30,000卢比收据')]
lines=['# 第六轮重大影响案件：区域扩大与出版前分级审计','', '**时间与区域**：1700—1799年印度、东南亚、印度洋、西非、南非（含本地独立政体）；所有下列为研究候选，绝不表示已发表。','', '## 新增14条重大过程：权力机制、社会后果和GIS门槛', '', '| 候选ID | 新增过程 | 核心受影响主体 | 已核研究时间 | 地图约束 | 下一份关键原档 |','|---|---|---|---|---|---|']
for case in cases:lines.append('| '+' | '.join(case)+' |')
lines+=['','## 本轮反复交叉核对得到的关键纠错','', '- 苏拉特1759取得城堡职权；该城纳瓦卜和多数居民仍属莫卧儿法权，不是英国当年占有现代Surat城市全部土地。','- Broach1772—1783曾由公司管理，1783实际交还辛迪亚。不能用贸易许可点充当省级主权图斑。','- Pollilur 1780公司兵惨败、1781公司获胜；皇家收藏RCIN734067明确为**1781**，具参考坐标但不表示战场精确轮廓。','- 1767 Old Calabar英国船长参与非洲地方派系杀戮和奴役，属短期贸易军事干预，英国没有凭此获得尼日利亚领土。','- 1727 Ouidah被达荷美征服；英国商馆仍在非洲政权规制下活动，绝不能把Agaja的战争画成英国征服。','- 安达曼1789殖民实验到1796退去，中期迁址约1792—93，未知年份留空；1858年后重新占领另属19世纪。','- 锡兰1796–1800抗议动因和空间分布复杂，不能用单一椰园税解释或把康提涂作英殖民地。','- Kattabomman 1799被处决，具体10月16日与17日记载冲突；1799先记年，1801波利加尔到槟城流放属于下世纪。','- 1781—82 Madras与1789—94 Northern Circars粮食危机相互独立，且与1770 Bengal地税饥荒不是一个事件。','- Hannover 1720三个港口采购21/22/75名被奴役者，可计算118人采购，不能写118名到港或被杀。','', '## 史料分级和会计线', '', '原档目录 `IOR/L/PARL/2/347` / `IOR/G/36/119` / `IOR/G/5` / `Add MS39857–58` 仅实际读到目录；Cambridge、Oxford、UC Press同代材料的史学分析已在网页正文或摘要读取；UCL论文历史数据表的可提取文字已读取，但网络PDF图片过大导致截图失败，需独立核页。','', '新增经济账按地方税款应征、实际征收、战役中军官损失、人口购买、受害死亡下限、救济金额严格分列。Rajshahi仅地区统计，且下辖村户分母未核；任何数字都不得汇成“英国净掠夺价值”。','', '## 连续性外溢但不得进入18世纪正式事件的案例','', '- 1801年南印度Poligar首领被流放槟城73人，见Cambridge Anand A. Yang研究；**不是1799年实际发生的流放事件**。','- 1803年公司再取Broach，前次英国行政在1783结束。','- 1803年开普殖民地由英国退回，1806年再次攻占；不能一条1795线延至1806。','- 1824年英缅战争以后Assam政治控制才另阶段，1792援军不能提前变成英国行政省。','- 1858年英国在安达曼重新建立殖民据点，不能连贯继承1789–1796年间短暂殖民点。','', '## 逐专题有效内容','', '新候选全文见 `TOPIC_DOSSIERS/NEW_CANDIDATES/AB-NEW-057.md` 至 `AB-NEW-070.md`，其他37篇原母题报告已将重要连接与反驳旧版图语义附录。', '']
(P/'WORKING'/'SIXTH_ROUND_MAJOR_IMPACT_AUDIT.md').write_text('\n'.join(lines))
# provenance mini matrix for next editor
ll=['# 第六轮来源阅读矩阵与一手文献领取顺序','', '标注为archive_catalogue_read者未看到历史纸本原件，学术HTML抽象只用于其明说的证据；未做24小时自动网址可访问性扫描。','', '| 本轮来源编号 | 来源名称及用途 | 阅读层级 | 不能宣称 |','|---|---|---|---|']
for s in R6S:
 ll.append('| '+s['id']+' | ['+s['title'].replace('|','/')+']('+s['url']+') | `'+s['reading_level']+'` | '+('原始卷宗全文已审' if 'archive' in s['reading_level'] else '18世纪原始手稿已亲自阅读')+' |')
ll+=['','## 现场原档复核优先序（仅建议主编，用户不必现在操作）','', '1. 大英图书馆 **IOR/L/PARL/2/347**：阿瓦德王妃财库与强制收款，逐笔分栏。','2. 大英图书馆 **IOR/G/36/119**：1759年苏拉特城堡和Tanka收入、是否仅堡垒相关税。','3. 大英图书馆 **IOR/G/5**：Broach 1772–1783征收和1783向Scindia交割日期。','4. 苏格兰历史档案Horsburgh/Hannover 1720航海日记准确登记号、购买和抵岸名单。','5. 英国在Old Calabar五位船长与Efik地方方派的1767同期书信、SlaveVoyages船名索引。','6. 1799南印度 **Revenue Consultations、Secret Sundries、Military Consultations**：Kattabomman攻击/处刑、各地方首领产权。','7. 当年Archibald Blair Port Cornwallis选址/撤离日记及Andamanese原住民遭迫迁具体地名。','8. 1796–1800 Sri Lanka coastal petitions/military reports逐县核实，勿将康提同西海岸。','9. **RCIN734067** 现已读官方历史地图目录；后续只研究1781战场图，而1780需独立军事地图。','10. UCL历史饥荒表需要PDF页面截图人工复核，以及1782 Monegar Choultry慈善会计。','']
(P/'WORKING'/'SIXTH_ROUND_SOURCE_READING_MATRIX.md').write_text('\n'.join(ll))
# Crosscentury concise machine action queue
future=[{'year':1801,'topic':'1799 Poligar War follow-up: 73 Poligars sent to Penang','source_id':'BS234','not_in_18c_events':True},{'year':1803,'topic':'Broach recaptured by EIC, separate from 1783 transfer','source_id':'BS216','not_in_18c_events':True},{'year':1858,'topic':'Second Andaman colonial settlement following abandonment 1796','source_id':'BS211','not_in_18c_events':True}]
(P/'WORKING'/'SIXTH_ROUND_CROSS_CENTURY_QUEUE.json').write_text(json.dumps(future,ensure_ascii=False,indent=2)+'\n')
summary=f'''# 第六轮最新调查结果（研究级，不得出版）

**本轮基线**：此前280候审事件、208来源、144经济证据、83政治转换、21地图点、56新增专题。
**现累计**：{len(E)}候审事件、{len(S)}可追溯来源、{len(F)}经济／人口证据、{len(T)}政治转换、{len(G)}地图现代参考点、{len(N)}新增专题（含独立报告），外加原定37篇。
**本轮净增**：{len(E)-280}事件、{len(S)-208}来源、{len(F)-144}账目、{len(T)-83}控制转换、{len(G)-21}具官方史图参考点、{len(N)-56}专题。无任何实控历史Polygon，GitHub写入0。

新增14个事件过程及其源证矩阵见 `WORKING/SIXTH_ROUND_MAJOR_IMPACT_AUDIT.md`。

**突出发现**：1767 Old Calabar英商与地方同盟杀害并掳走受害人；1781–83 Awadh女性财库遭军事逼迫；1789–96 Andaman港口/流放占地；1792 Ahom求援与英公司军事测绘；1759 Surat城堡但非全城英国直接主权；1772–83 Broach公司管理并转交Maratha；1760s–1799 Bengal地方反抗；1796–1800 Ceylon海岸税制抗争；1799 Poligar公司征税与处刑；1781–82 Madras粮食危机及救济。

**绝对禁止错误**：1780/1781 Pollilur是胜败相反的两场战役；英国公司1759没有吞并全Surat；1727 Ouidah为Dahomey征服；1789–96 Andaman短期港口不是整个安达曼群岛英国主权；1772 Broach公司控制不能跨过1783；没有来源坐标的Old Calabar、Andaman、Ahom细节继续留空。

**现实限制**：纸质原史料并未亲阅，英国图书馆档案编号仅核目录；UCL PDF文本可提取但网页截图因13.4MB失败，该表的£/卢比救助数字需再证。来源见每条source阅读等级。
'''
for fname in ['README.md','PROGRESS.md']:
 p=P/fname; old=p.read_text()
 if not old.startswith('# 第六轮最新调查结果'):
  p.write_text(summary+'\n---\n\n'+old)
with (P/'GAPS_AND_CONFLICTS.md').open('a') as f:
 f.write('\n\n## 第六轮重大遗漏审查与新矛盾（2026-11-08）\n\n')
 f.write('75. **1767 Old Calabar屠杀**：Oxford与Cambridge证英国贩奴船长参与地方派系伏击，受害死亡数为逾300的学术概数；确切涉案船、死亡名单、被掳至美洲者及当地Eyik叙事仍待原档。不得以事件等同尼日利亚领土占领。\n')
 f.write('76. **1765–1783 Awadh女性财库及军费挤压**：Bahu Begam的jagir土地收入、女性私人财产、纳瓦卜“公共国库”和公司债务争议，不能合并记“公司已汇英利润”。需读BL IOR/L/PARL/2/347原卷，特别1782强制收款。\n')
 f.write('77. **Andaman流放殖民**：1789–1796两段港口/监禁据点中1792–93迁址具体年未一致，历史路权/清林地界无同代地籍，1858重新占据属下世纪。\n')
 f.write('78. **Ahom 1792干预**：东印度公司是Gaurinath Singha请求的军事盟军，Moamoria叛乱者亦为独立行动者。没有1792整个Assam英国领土；真实撤兵日与军费账及具体地图仍缺。\n')
 f.write('79. **Surat/ Broach领土错误**：1759仅苏拉特城堡长官权归公司，城市Nawab保留；Broach据英国图书馆为1772公司管理及1783交Scindia，1803才又回公司（超本世纪）。地图必须按年启停，旧现代Gujarat面禁用。\n')
 f.write('80. **Pollilur两战辨析**：1780-09-10公司败于Hyder Ali/Tipu；1781-08-27公司军Coote反败为胜，Royal Collection RCIN734067仅1781，不能套在1780。经济表中36/34/16仅公司欧洲军官伤亡/俘获拆类，印度sepoy未被统计。\n')
 f.write('81. **1799 Poligar处刑日期冲突**：近现代公开叙事多报10月16日，1909旧殖民官撰史与印度政府刊物报10月17日。研究档暂定1799年，确日须追当年军法审判、军事公告。Panchalankurichi现代考古保护35 acres不代表1799公司实控面积。\n')
 f.write('82. **1796–1800 Ceylon税制反抗**：学术论文反对把地方抗议归为单一“椰子园税”并声称可能涉及更复杂税权/村级申诉体系；目前地方军报和请愿未逐件读，不能把全部岛屿写成统一反抗或英国主权。\n')
 f.write('83. **孟加拉Rajshahi税收行**：1769–72三财政年应征与实收来自后世地方论文表，未核Firminger原档，不能加进全Bengal的英镑收入或用纸币汇率推算净财富转移。\n')
 f.write('84. **Hannover 1720贸易人数**：Windward 21、Gold Coast 22、Old Calabar 75合118个采购记录；航海日志原件与到美洲实到人数未核，不可把合计当受害死亡数。\n')
 f.write('85. **1781–82 Madras及1790–92 Northern Circars灾害**：UCL学术论文的历史表出现30,000 rupees与各救济措施，网端PDF截图因大文件失败，仅已读索引文字，未核18世纪原账；不同地区/年份/灾因不得加总。\n')
 f.write('86. **Ouidah1727被Dahomey王征服**：英国商馆/贩奴商受达荷美港务条件约束；英方贸易堡垒不等于英国国家控制。1755、1762本地王抗议是非英国政治行为，须保持自主权。\n')
 f.write('87. **空间未确认**：新增22个参考点仅Pollilur 1781一处因RCT官方地图题名给出可证现代代表位置；其余14个新专题的地名未从权威地点坐标落点，未加现代省界Polygon，任何面积统计仍保持null。\n')
 f.write('88. **本轮数字总量不等于已发表事实**：原纸未亲阅，多数新文为同行评审文章段落或档案目录。请查 `WORKING/SIXTH_ROUND_SOURCE_READING_MATRIX.md` 获取逐条层级。\n')
(P/'WORKING'/'SIXTH_ROUND_FINAL_CHECKPOINT.json').write_text(json.dumps({'round':6,'sources':len(S),'events':len(E),'economic':len(F),'transitions':len(T),'map_reference_points':len(G),'new_topics':len(N),'original_topics':37,'historic_polygons':0,'published':False,'github_writes':0},ensure_ascii=False,indent=2)+'\n')
print('WRITE_REPORTS',len(R6),'new topics',len(R6E),'new events; QA-ready')
