#!/usr/bin/env python3
import pathlib,json,csv,runpy
p=pathlib.Path('/mnt/data/18c_assistant_B')
ns=runpy.run_path(str(p/'WORKING/extend_research_20261108.py'))
s,e,n=ns['s'],ns['e'],ns['n']; source=ns['add_source']; event=ns['add_event']; new=ns['add_new']
source('BS120','Ghana Museums and Monuments Board','Official Fort William Anomabu 1753–57 and 1717 ship captain estimate','https://gmmb.gov.gh/fort-william-anomabu-1753/',level='national_museum_history_search_extract_read',note='Official Ghanaian heritage account; 1717 captain claim 30141 people transported 1702-08 not independently corroborated')
source('BS121','Taylor and Francis / Journal of Imperial and Commonwealth History','Ty M Reese Controlling the Company: Fante-British Relations 1750–1821','https://www.tandfonline.com/doi/abs/10.1080/03086534.2013.762162',level='peer_reviewed_abstract_read',note='Fante trade practices and bargaining, company tenant-patron rather than UK sovereignty')
source('BS122','Taylor and Francis / Journal for Maritime Research','Joshua D Newton Naval power and the Province of Senegambia, 1758–1779','https://www.tandfonline.com/doi/full/10.1080/21533369.2013.851840',level='peer_reviewed_abstract_read',note='British formal province 1765-79 for gum and slave trade; profitability qualitative without ledger amount')
source('BS123','UNESCO World Heritage Centre','Kunta Kinteh Island and related sites UNESCO summary, James Fort destroyed by French in 1779','https://whc.unesco.org/en/list/761',level='UNESCO_heritage_history_read',note='1779 last destruction and ruin; does not prove fort sovereignty or its 18th-century footprint')
source('BS124','UNESCO World Heritage Centre','Kunta Kinteh Island UNESCO geolocation for James Island 761-001','https://whc.unesco.org/en/list/761/maps/',level='UNESCO_official_modern_reference_coordinates_read',note='N13 19 3.51 W16 21 40.87 modern listed location; protected area 0.35 ha is NOT historical 1779 fort controlled area')
source('BS125','John Carter Brown Library Brown University','1779 rare manuscript map Senegal and Gambia dedicated to Duc de Lauzun','https://jcblibrary.org/news/carte-du-cours-des-fleuves-du-senegal-et-de-gambie-dediee-et-presentee-monsieur-le-duc-de/',level='university_library_map_context_read',note='Describes early 1779 French recapture of Senegal from British 1758 footholds; map NOT georeferenced or border reconstruction')
source('BS126','Cambridge University Press','Mobility and Coercion in Age of Wars: O Hara regiment Goree 1758 and recapture 1779','https://www.cambridge.org/core/books/mobility-and-coercion-in-an-age-of-wars-and-revolutions/legion-of-the-damned/15C327CD2E119A6ACC6D889CF8B10CAF',level='academic_book_extract_read',note='Gorée British recapture 1779 and unit manned multiple forts; no automatic sovereignty over the coast')
source('BS127','Cambridge University Press / History in Africa','2024 study Senegambian treaties and local political rulers 1679–1815','https://www.cambridge.org/core/journals/history-in-africa/article/vivre-en-paix-et-en-bonne-intelligence-avec-les-princes-locaux-in-senegambia-in-the-age-of-slave-economy-diplomatic-treaties-trade-conflicts-and-peace-in-interaction-16791815/3D78436EE79DD7C86CF0CBDC3AD00DD5',level='peer_reviewed_html_read',note='Discusses 1783 Versailles treaty Article 9 and African rulers of Saloum, etc; treaty is European claim, not local land consent')
source('BS128','University of Perpignan digital legal history','French 1783 Treaty of Versailles full text articles 9-11','https://mjp.univ-perp.fr/traites/1783versailles.htm',level='digitised_primary_treaty_transcription_read',note='Article 9 Senegal to France and Gorée restitution, Article 10 British title to Fort James and Gambia; legal guarantee does not prove 1779 ruin rebuilt')
source('BS129','University of Ottawa','1763 Treaty of Paris archival legal transcription articles 10–11','https://www.uottawa.ca/about-us/official-languages-bilingualism-institute/clmc/linguistic-history/historic-documents/treaty-paris-1763',level='primary_treaty_transcription_read',note='France receives Goree, Britain Senegal St Louis Podor Galam; also Pondicherry and India factories restoration, read treaty scope')
source('BS130','Cambridge University Press / Journal of African History','1961 The Ashanti Question and the British, eighteenth-century origins','https://www.cambridge.org/core/journals/journal-of-african-history/article/abs/ashanti-question-and-the-british-eighteenthcentury-origins/31ECA3E746C70147090FCA23AF454AC4',level='peer_reviewed_abstract_and_notes_read',note='1750 Company of Merchants trading to Africa managed forts with parliament grant; unlike RAC not monopoly trader; T70 official archive')
source('BS131','Bibliothèque nationale de France / Patrimoines partagés','British-French 1783 Versailles peace Senegal River and Goree restoration','https://heritage.bnf.fr/france-ameriques/en/1783-peace-treaties',level='national_library_treaty_context_read',note='Confirms terms of French-British Versailles peace distinct American Treaty of Paris 1783')
source('BS132','Cambridge University Press / Itinerario','2026 Senegambia city-formations French British settlement and chronology','https://www.cambridge.org/core/journals/itinerario/article/building-and-developing-westernstyle-cities-the-influence-of-european-architecture-and-urban-planning-in-senegambia-16591854/A7A6B2A47EA32EA9255ED50F1C6DA54A',level='peer_reviewed_html_extract_read',note='British Goree second stay 1779-83; no claim that European forts controlled all surrounding settlements')
new('AB-NEW-024','1758—1783年英属塞内冈比亚省、阿拉伯胶专利与圣路易易手','E18-E07','1765正式殖民省在1758军事占领和1779法国反攻之间形成，1783和约又明确恢复，远超过单次夺堡。',['BS122','BS125','BS127','BS128'])
new('AB-NEW-025','1702—1806年阿诺马布Fort Charles与Fort William及Fante政治自主','E18-E10','1731英国拆堡、1753—1757新堡建造、非洲Fante商人谈判及被奴役者转运可独立展开；1806超世纪只作结局上下文。',['BS120','BS121'])
new('AB-NEW-026','1709—1779年冈比亚詹姆斯堡毁弃与1783主权承诺脱节','E18-E10','国际法和约确认英国对已毁堡的声索，不等于堡垒实驻；UNESCO确认1779破坏后保持废墟。',['BS123','BS124','BS128'])
new('AB-NEW-027','1763与1783英法和约对印度商馆、Gorée和塞内加尔不同归属','E18-E07','1763与1783分别恢复法方港岛/商馆及英方部分商贸地，必须记录条约名和年份；不将贸易站误作广域土地。',['BS129','BS128'])

# Concrete local political and military events.
event('AB-E10-003',['E18-E10'],'1717','阿诺马布英船长称1702—1708年被迫运送非洲人口数量','Unidentified English captain cited by Ghana Museums; African merchants and captives','Anomabu; Barbados and Jamaica','1717年英船长回顾1702年1月至1708年8月从阿诺马布输往巴巴多斯和牙买加至少30141名被奴役者；这是同期人员陈述，不是验证航次账。','contemporary_report_not_ship_manifest',['BS120'],confidence='modern_museum_cites_1717_english_captain_no_primary_scan')
event('AB-E10-004',['E18-E10'],'1731','英方拆毁阿诺马布Fort Charles防止竞争欧洲公司利用','English merchants / fort administration; French traders; Fante communities','Anomabu, Ghana','加纳文物管理局记英国1731年拆Fort Charles，之后法国重修，表明英国沿岸堡垒实控并非逐年不变。','fort_ended_or_control_gap',['BS120'],confidence='ghana_official_site_secondary_chronology')
event('AB-E10-005',['E18-E10'],'1753','英国议会为阿诺马布新贸易堡垒拨建设款','British Parliament; Company of Merchants Trading to Africa; Fante political communities','Anomabu, Ghana','国家博物馆记1753年议会批准新堡财政支出；金额未公开核对；拨款≠已完工或主权。','fort_funding_not_land_control',['BS120','BS130'])
event('AB-E10-006',['E18-E10'],'1757','阿诺马布Fort William贸易与囚禁堡垒建成','Company of Merchants Trading to Africa; indigenous Fante communities; captives','Anomabu, Ghana','加纳官方史记堡垒1757年完工并具专门拘押被奴役者空间，需依据历史结构平面图研究具体建筑；不得虚构监狱人数。','fort_building_and_enslavement_node',['BS120','BS121'])
event('AB-E07-003',['E18-E07'],'1763','1763英法和约法方收回Gorée英方保有塞内加尔据点','George III; Louis XV; local Senegal/Goree communities','Gorée and Saint-Louis (two geographically separate sites)','《巴黎和约》第十条恢复法国对Gorée岛的法律权利，确认英国Saint-Louis、Podor、Galam的欧洲条约主张；当地政治主体并非缔约国。','multi_site_treaty_status_not_comprehensive_african_sov',['BS129'])
event('AB-E07-004',['E18-E07'],'1765','英国设置塞内冈比亚省以统筹圣路易及西非贸易','British Crown and administrators; Senegal/Gambia African rulers; merchants','Saint-Louis and Gambia, geographic scope not surveyed','学术研究将1765—1779界定为英国首个西非正式殖民省，企图控制阿拉伯胶和跨大西洋奴役贸易；公司堡垒与原住民政权不能同画一省实占Polygon。','Crown_colonial_administration_claim_and_port_posts',['BS122','BS127'])
event('AB-E07-005',['E18-E07'],'1779-01','法军夺回塞内加尔圣路易，英国失去在该处驻军','Duc de Lauzun and French fleet; British colonial governor and garrison; Senegal communities','Saint-Louis, Senegal','John Carter Brown 1779历史地图馆藏说明Lauzun率法军1779年初收复圣路易；具体投降当日待军报核，不能沿用英国驻城到1799。','British_Crown_post_lost_to_France',['BS125','BS122'])
event('AB-E10-007',['E18-E10'],'1779','法国军队毁坏冈比亚河英属James Fort','French armed force; British fort garrison; Gambia river communities','James Island / present Kunta Kinteh Island, The Gambia','UNESCO认定1779年法方破坏是詹姆斯堡最后一次重大毁坏，遗址至今仍为废墟；不能因1783年英国声索便重画驻军堡垒。','fort_destroyed_no_auto_reoccupation',['BS123','BS124'])
event('AB-E07-006',['E18-E07'],'1779','英国军队再次进驻Gorée岛据点','British forces; local Goree community; French colonial garrison','Gorée Island, Senegal','Cambridge学术资料将1779英国重占Gorée与1763年交还法国分开；实际接防日期未见原军报。','British_short_reoccupation_of_island_post',['BS126','BS132'])
event('AB-E07-007',['E18-E07'],'1783-09-03','英法凡尔赛和约将Gorée及塞内加尔河据点交还法国','Great Britain and France; Senegal and Gambia African rulers not signatories','Versailles signatory location; Gorée/Senegal affected','1783年英法和约第九条明确英国把塞内加尔河及Saint-Louis/Podor/Galam/Arguin/Portendick交法国，并交还Gorée；欧洲条约没有取得各地非洲统治者土地许可。','formal_European_treaty_concessions_not_local_sovereignty',['BS128','BS131','BS127'])
event('AB-E10-008',['E18-E10'],'1783-09-03','1783和约确认英国在甘比亚Fort James的欧洲条约权利','George III; French Crown; local Gambia rulers','Gambia River, former James Fort','英法和约第十条承诺保障英国占有詹姆斯堡和冈比亚河，但UNESCO证实堡垒1779毁坏，不能把法定声索当作1783重建完成或持续驻守。','treaty_claim_to_ruined_fort_not_active_military_control',['BS128','BS123'])
event('AB-E10-009',['E18-E10'],'1794','法国军队袭击加纳阿诺马布Fort William','French armed force; British fort garrison; Fante communities','Anomabu, Ghana','加纳官方遗产资料证实1794年法国军队袭击，结果、驻军和民众损失未见同文证据，暂只记袭击。','short_attack_outcome_unknown',['BS120'])

# Link one named heritage point, explicitly reference-only; UNESCO modern site coordinates, no historical footprint.
mapfile=p/'MAP_CANDIDATES.geojson'; geo=json.loads(mapfile.read_text())
if not any(z.get('id')=='AB-GEO-JAMES-ISLAND' for z in geo['features']):
 def dms(d,m,sec,sign=1):return round(sign*(d+m/60+sec/3600),7)
 feature={'type':'Feature','id':'AB-GEO-JAMES-ISLAND','geometry':{'type':'Point','coordinates':[dms(16,21,40.87,-1),dms(13,19,3.51)]},
 'properties':{'name':'James Island / Kunta Kinteh Island (modern UNESCO site)','representative_map_point':True,
 'geo_precision':'official_modern_UNESCO_site_reference_not_18c_fort_footprint',
 'geo_reference_method':'UNESCO World Heritage 761-001 N13 19 3.51 W16 21 40.87; modern heritage listing',
 'source_ids':['BS124','BS123'],'source_urls':[next(x['url'] for x in s['sources'] if x['id']==i) for i in ['BS124','BS123']],
 'related_event_ids':['AB-E10-007','AB-E10-008'],'political_control_class':'reference_only',
 'historical_control_boundary_verified':False,'actual_British_control_area_sqkm':None,
 'exclude_from_area_aggregation':True,'publication_status':'research_only','mapping_status':'modern_site_location_verified_historical_ruin_extent_unverified'}}
 geo['features'].append(feature)
 for it in e['events']:
  if it['id'] in feature['properties']['related_event_ids']:
   it['map_state']='modern_named_reference';it['geometry_id']=feature['id']
mapfile.write_text(json.dumps(geo,ensure_ascii=False,indent=2)+'\n')

# Appendix economics: original CSV schema maintained, all figures explicit obligations/claims, no dollar conversion.
f=p/'ECONOMIC_EVIDENCE.csv'
with f.open(encoding='utf-8-sig',newline='') as h:
 reader=csv.DictReader(h); headers=reader.fieldnames; data=list(reader)
known={x['id'] for x in data}

def money(id,topics,ystart,yend,value,unit,definition,payer,recipient,period,ids,role,status,received,limit,denom=''):
 if id in known:return
 assert all(any(x['id']==si for x in s['sources']) for si in ids)
 d={'id':id,'topic_ids':';'.join(topics),'year_start':ystart,'year_end':yend,'value':value,
 'currency_or_unit':unit,'metric_definition':definition,'payer_or_affected':payer,
 'recipient_or_observer':recipient,'accounting_period':period,'source_ids':';'.join(ids),
 'source_urls':';'.join(next(z['url'] for z in s['sources'] if z['id']==si) for si in ids),
 'source_reading_level':'cross_referenced_secondary_or_transcribed_contemporary','source_role':role,
 'verification_status':status,'was_primary_manuscript_personally_read':False,
 'actual_received_or_transferred_verified':received,'numerator_denominator':denom,'interpretation_limit':limit}
 data.append(d); known.add(id)

money('EXTRA-1792-MYSORE-INDEMNITY',['E18-B14'],1792,1792,33000000,'sicca_rupees_nominal','Preliminary treaty total indemnity to coalition, not solely EIC','Tipu Sultan / Mysore','Company, Hyderabad, Maratha allied powers','1792-02-22 articles, formal treaty 1792-03-18',['BS114','BS109'],'contemporary_OCR_preliminary_terms','preliminary_contractual_obligation_not_receipts',False,'3 crore 30 lakh sicca rupees; overlap with two half-payment rows, do not sum; recipient allocation not verified')
money('EXTRA-1792-MYSORE-FIRST-HALF',['E18-B14'],1792,1792,16500000,'sicca_rupees_nominal','First half promised immediately, part of 33m total','Tipu Sultan / Mysore','Allied powers','1792-02-22 preliminary agreement',['BS114'],'contemporary_newspaper_copy','contractual_due_not_proof_of_payment',False,'One crore 65 lakh; subtotal of 33m, DO NOT ADD to total')
money('EXTRA-1792-MYSORE-REMAINING-HALF',['E18-B14'],1792,1793,16500000,'sicca_rupees_nominal','Remaining half under three installments, no more than four months each','Tipu Sultan / Mysore','Allied powers','1792-02-22 terms, future installments',['BS114'],'contemporary_newspaper_copy','scheduled_not_verified_cash',False,'Subtotal of same 33m, no proved receipts or per-ally split')
money('EXTRA-1775-BENARES-TRIBUTE',['E18-B17'],1775,1781,2340249,'sicca_rupees_not_specified','Annual tribute promised by Chait Singh; source says rupees without specie type','Chait Singh Benares polity','East India Company','Annual promise, cited for 1775 alliance, 1778–81 disputes',['BS108'],'UC_Press_academic_edition','secondary_stated_annual_contract_not_actual_collections',False,'Rs 2,340,249 promised each year, actual payments not independently checked; do not multiply by years')
money('EXTRA-1781-BENARES-REVISED-DEMAND',['E18-B17'],1781,1782,4000000,'rupees_specie_unspecified','Revised annual Company revenue demand after Chait Singh removal','Benares residents and zamindari','East India Company','After September 1781 installation',['BS108'],'UC_Press_academic_edition','administrative_demand_not_verified_actual_revenue',False,'Cannot sum with previous 2,340,249 promise; revised rate may replace older promise; not net profit')
money('EXTRA-1781-BIJIGARH-TREASURE',['E18-B17'],1781,1781,4000000,'rupees_specie_unspecified','Bijigarh fort treasure cash circa 4m rupees plus jewellery, historian estimate','Chait Singh court treasury','Soldiers / contested Company claim','Nov 1781 surrender and immediate division',['BS108'],'UC_Press_academic_edition','approximate_captured_cash_not_net_company_receipt',False,'Some four million rupees from Fisher; same stock contains officers distributions; £400,000 a secondary contextual conversion, not separate UK transfer')
money('EXTRA-1781-POPHAM-PRIZE',['E18-B17'],1781,1781,294000,'rupees_specie_unspecified','Military commander Popham reported share of Bijigarh prize treasure','Captured Benares treasury','Major Popham','1781 loot distribution, later Company attempted recovery',['BS108'],'UC_Press_academic_edition','reported_officer_personal_share_disputed_recovery',False,'Component of approximate 4m Bijigarh cash, not independent additional treasure')
money('EXTRA-1781-CAPTAIN-PRIZE',['E18-B17'],1781,1781,22478,'rupees_specie_unspecified','Per British Captain reported prize-money allotment, not sum all captains','Captured Benares treasury','Individual British captain','1781 Bijigarh reported division',['BS108'],'UC_Press_academic_edition','reported_per_capita_allotment_not_total',False,'No verified number of qualifying captains, no multiplying to grand total')
money('EXTRA-1781-SEPOY-PRIZE',['E18-B17'],1781,1781,50,'rupees_specie_unspecified','Per sepoy reportedly paid at Bijigarh','Captured Benares treasury','Individual Indian sepoy','1781 Bijigarh reported division',['BS108'],'UC_Press_academic_edition','reported_per_person_allotment_not_total',False,'No proof all sepoys received or denominator for total; some participating troops excluded')
money('EXTRA-1781-AWADH-ARMY-LOAN',['E18-B17'],1781,1781,50000,'rupees_specie_unspecified','Loan from Awadh ruler to pay overdue Company soldiers','Awadh ruler','East India Company military treasury','1781 Benares relief march',['BS108'],'UC_Press_academic_edition','historian_recounted_loan_not_company_revenue',False,'Borrowed military liquidity, neither indemnity nor taxable revenue; does not add to Bijigarh cash')
money('EXTRA-1702-1708-ANOMABU-CAPTAIN',['E18-E10'],1702,1708,30141,'people_reported_minimum','English captain 1717 retrospective minimum persons exported Anomabu to Barbados and Jamaica','People forcibly enslaved and exported','English maritime transport commercial participants','Jan 1702–Aug 1708 reported 1717',['BS120'],'Ghana_national_museum_reports_historic_captain','contemporary_reported_count_not_reconstructed_ship_manifest',False,'Claim at least 30,141; no independent individual ship verification; probable overlap with Atlantic specialist dataset; no summation to other estimates')

# Keep both files consistently updated, do not let old CSV mislead about event count.
def export_events():
 ef=p/'EVENT_CANDIDATES.csv'
 with ef.open(encoding='utf-8-sig',newline='') as h:
  r=csv.DictReader(h); outheaders=r.fieldnames
 fieldmap=[x.lstrip('\ufeff') for x in outheaders]
 with ef.open('w',encoding='utf-8-sig',newline='') as h:
  w=csv.DictWriter(h,fieldnames=fieldmap,extrasaction='ignore');w.writeheader()
  for x in e['events']:
   flat={k:json.dumps(v,ensure_ascii=False) if isinstance(v,(list,dict)) else v for k,v in x.items()}
   w.writerow(flat)
export_events()
with f.open('w',encoding='utf-8-sig',newline='') as h:
 fieldnames=[x.lstrip('\ufeff') for x in headers]
 w=csv.DictWriter(h,fieldnames=fieldnames,extrasaction='ignore');w.writeheader();w.writerows(data)
s['source_count']=len(s['sources'])
for filepath,obj in [(p/'SOURCE_REGISTRY.json',s),(p/'EVENT_CANDIDATES.json',e),(p/'NEW_CANDIDATES.json',n)]:
 filepath.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print('checkpoint updated:',len(s['sources']),'sources',len(e['events']),'events',len(n['candidates']),'new topics',len(data),'economic rows',len(geo['features']),'geopoints')
