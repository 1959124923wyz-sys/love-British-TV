# 第六轮来源阅读矩阵与一手文献领取顺序

标注为archive_catalogue_read者未看到历史纸本原件，学术HTML抽象只用于其明说的证据；未做24小时自动网址可访问性扫描。

| 本轮来源编号 | 来源名称及用途 | 阅读层级 | 不能宣称 |
|---|---|---|---|
| BS209 | [It all comes from me: Bahu Begam and making of the Awadh nawabi](https://www.cambridge.org/core/journals/modern-asian-studies/article/it-all-comes-from-me-bahu-begam-and-the-making-of-the-awadh-nawabi-circa-17651815/D7AEE97EA7821335A01B32B82AAB3FB0) | `journal_full_html_read` | 18世纪原始手稿已亲自阅读 |
| BS210 | [Warren Hastings papers, Part I regarding Oudh Begams](https://searcharchives.bl.uk/?f%5Bcollection_area_ssi%5D%5B%5D=India+Office+Records+and+Private+Papers&f%5Blanguage_ssim%5D%5B%5D=English&f%5Broot_ancestor_reference_ssi%5D%5B%5D=IOR%2FL%2FPARL&page=2&per_page=50&sort=date) | `archive_catalogue_read` | 原始卷宗全文已审 |
| BS211 | [Developing Terra Nullius: Colonialism, Nationalism, Indigeneity in Andaman Islands](https://www.cambridge.org/core/journals/comparative-studies-in-society-and-history/article/developing-terra-nullius-colonialism-nationalism-and-indigeneity-in-the-andaman-islands/8F0B5F996A88F1DB8E8B5D7B54AD8E8F) | `journal_full_html_read` | 18世纪原始手稿已亲自阅读 |
| BS212 | [Geographical Exploration and Historical Investigation: John Peter Wade in Assam](https://www.cambridge.org/core/books/abs/landscape-culture-and-belonging/geographical-exploration-and-historical-investigation-john-peter-wade-in-assam/FD71BBD7370CA6C116FBCE04A20ACACF) | `scholarly_chapter_summary_read` | 18世纪原始手稿已亲自阅读 |
| BS213 | [The British Monopoly on Surat Trade to the Middle East and Indian shipowners struggle 1759–1800](https://www.cambridge.org/core/journals/journal-of-the-royal-asiatic-society/article/abs/british-monopoly-on-the-surat-trade-to-the-middle-east-and-the-indian-shipowning-merchants-struggle-against-it-17591800/ED95E21E566D5BD586BC830431D79449) | `journal_html_abstract_and_notes_read` | 18世纪原始手稿已亲自阅读 |
| BS214 | [Mughal Nobles, Indian Merchants and Beginning of British Conquest: Surat 1756–59](https://www.cambridge.org/core/journals/modern-asian-studies/article/abs/mughal-nobles-indian-merchants-and-the-beginning-of-british-conquest-in-western-india-the-case-of-surat-17561759/AAA9C1720689652875326A6380922029) | `journal_abstract_read` | 18世纪原始手稿已亲自阅读 |
| BS215 | [Factory records Surat: revenue report of 5 November 1759](https://searcharchives.bl.uk/?f%5Bcollection_area_ssi%5D%5B%5D=India+Office+Records+and+Private+Papers&f%5Bmaterial_type_si%5D%5B%5D=Archives+and+Manuscripts&f%5Bproject_collections_ssim%5D%5B%5D=India+Office+Records&f%5Burl_non_blank_si%5D%5B%5D=Yes+%28available%29&page=10&per_page=100&sort=date) | `archive_catalogue_read` | 原始卷宗全文已审 |
| BS216 | [Factory records Broach: EIC district 1772–1783 and handover to Scindia](https://searcharchives.bl.uk/catalog/036-000173372) | `archive_catalogue_read` | 原始卷宗全文已审 |
| BS217 | [Town Revenues and Taxes in Eighteenth-Century Gujarat](https://journals.sagepub.com/doi/10.1177/0262728003232004) | `journal_abstract_read` | 18世纪原始手稿已亲自阅读 |
| BS218 | [Revisiting the Early Anti-colonial Rebellions in Bengal and Odisha, 1760–1856](https://journals.sagepub.com/doi/10.1177/03769836221105972) | `journal_abstract_read` | 18世纪原始手稿已亲自阅读 |
| BS219 | [Tribal-led Peoples Resistance in Transition 1765–1800](https://online.ucpress.edu/esr/article-abstract/36/1/127/34172/Tribal-led-People-s-Resistance-in-Transition-1765) | `journal_abstract_read` | 18世纪原始手稿已亲自阅读 |
| BS220 | [Many Little Revolts or One Rebellion? Ceylon maritime provinces 1796–1800](https://www.tandfonline.com/doi/abs/10.1080/00856400903049465?needAccess=true) | `journal_abstract_read` | 18世纪原始手稿已亲自阅读 |
| BS221 | [Mutiny on the Black Prince Chapter 4: Old Calabar](https://academic.oup.com/book/58166/chapter-abstract/485239549) | `book_chapter_abstract_read` | 18世纪原始手稿已亲自阅读 |
| BS222 | [Cultures of Exchange: Atlantic Africa in Era of Slave Trade](https://www.cambridge.org/core/journals/transactions-of-the-royal-historical-society/article/abs/cultures-of-exchange-atlantic-africa-in-the-era-of-the-slave-trade/CCB6F191757555706151856EC26C4287) | `journal_html_notes_read` | 18世纪原始手稿已亲自阅读 |
| BS223 | [African Merchants, Notables, Slave Trade at Old Calabar, 1720: Scottish Archives](https://www.cambridge.org/core/journals/history-in-africa/article/abs/african-merchants-notables-and-the-slave-trade-at-old-calabar-1720-evidence-from-the-national-archives-of-scotland/4260269CC4899A46AC1E0DA57BA6F7A0) | `journal_extract_read` | 18世纪原始手稿已亲自阅读 |
| BS224 | [Ouidah, chapter The Dahomian Conquest of Ouidah](https://www.cambridge.org/core/books/abs/ouidah/dahomian-conquest-of-ouidah/56386651A8A853276C32FFDE9920427B) | `book_chapter_summary_read` | 18世纪原始手稿已亲自阅读 |
| BS225 | [Ouidah, chapter The Operation of Atlantic Slave Trade](https://www.cambridge.org/core/books/abs/ouidah/operation-of-the-atlantic-slave-trade/8C586FD8A07B0E31C6AFF7BBFE8BE677) | `book_chapter_summary_read` | 18世纪原始手稿已亲自阅读 |
| BS226 | [Dialogue and History: The Battle of Pullalur and the Naturalization of the British](https://publishing.cdlib.org/ucpressebooks/public/book/dialogue-and-history-constructing-south-india-1795-1895.html) | `scholarly_full_html_read` | 18世纪原始手稿已亲自阅读 |
| BS227 | [Original military map of Second Battle of Pollilur (1781) RCIN 734067](https://militarymaps.rct.uk/other-18th/19th-century-conflicts/map-of-the-battle-of-pollilur-1781-pollilur-near-kanchipuram-tamil-nadu-india-12deg5000n-79deg4300e) | `museum_map_catalogue_and_transcription_read` | 18世纪原始手稿已亲自阅读 |
| BS228 | [Journal of Commissioners negotiating Mangalore Peace Treaty, Add MS 39857–39858](https://searcharchives.bl.uk/catalog/032-002059709) | `archive_catalogue_read` | 原始卷宗全文已审 |
| BS229 | [Naturalizing Famine: Doji bara Famine and Madras 1789–94](https://academic.oup.com/book/61892/chapter/548192041) | `scholarly_chapter_excerpt_read` | 18世纪原始手稿已亲自阅读 |
| BS230 | [Fakir-Sannyasi Movement in Rajshahi; revenue assessed and collected 1769–72](https://rc.gov.bd/jss/fakir-sannyasi-movement-in-rajshahi-regional-study-of-a-pioneer-peasant-resistance-in-colonial-bengal/) | `secondary_research_full_html_read` | 18世纪原始手稿已亲自阅读 |
| BS231 | [India Contribution to British Balance of Payments 1757–1812](https://www.sciencedirect.com/science/article/pii/S0014498305000859) | `journal_article_excerpt_read` | 18世纪原始手稿已亲自阅读 |
| BS232 | [From Negotiation to Coercion: Textile Manufacturing in India in Eighteenth Century](https://www.cambridge.org/core/journals/modern-asian-studies/article/abs/from-negotiation-to-coercion-textile-manufacturing-in-india-in-the-eighteenth-century/9ECA84ADA531FC112E225221E773267D) | `journal_abstract_read` | 18世纪原始手稿已亲自阅读 |
| BS233 | [The Third War of Dispossession 1799–1803](https://scientiamilitaria.journals.ac.za/pub/article/view/1094) | `journal_abstract_read` | 18世纪原始手稿已亲自阅读 |
| BS234 | [Bandits and Kings: Moral Authority and Resistance in Early Colonial India](https://www.cambridge.org/core/journals/journal-of-asian-studies/article/abs/bandits-and-kings-moral-authority-and-resistance-in-early-colonial-india/F5C6466E58EA233E8678A2917D81159D) | `journal_abstract_read` | 18世纪原始手稿已亲自阅读 |
| BS235 | [Panchalankurichi archaeology fort palace](https://www.tnarch.gov.in/panchalankurichi) | `official_archaeology_site_read` | 18世纪原始手稿已亲自阅读 |
| BS236 | [Famine, Disease, Medicine and State in Madras Presidency (1876-78), Historical Table 0.1](https://discovery.ucl.ac.uk/1444928/1/U592238.pdf) | `pdf_text_extracted_screenshot_failed_large_file` | 18世纪原始手稿已亲自阅读 |
| BS237 | [Environmental Changes, Fuel Market, Working Conditions of Bengal Salt Makers c.1780–1845](https://www.cambridge.org/core/journals/international-review-of-social-history/article/environmental-changes-the-emergence-of-a-fuel-market-and-the-working-conditions-of-salt-makers-in-bengal-c-17801845/EFF95B979EA1BC59C12DAFD1E623FB58) | `journal_full_html_read` | 18世纪原始手稿已亲自阅读 |
| BS238 | [Map of the Carnatic marches 1781–1784](https://militarymaps.rct.uk/other-18th/19th-century-conflicts/map-of-the-carnatic-1781-4-tamil-nadu-india) | `museum_map_catalogue_read` | 18世纪原始手稿已亲自阅读 |
| BS239 | [Proceedings: Poligar Rebellion, primary archive series list](https://www.tnhc.org.in/docs/proceedings/Chidambaram-2012.pdf) | `conference_pdf_search_excerpt_not_page_visual_verified` | 18世纪原始手稿已亲自阅读 |

## 现场原档复核优先序（仅建议主编，用户不必现在操作）

1. 大英图书馆 **IOR/L/PARL/2/347**：阿瓦德王妃财库与强制收款，逐笔分栏。
2. 大英图书馆 **IOR/G/36/119**：1759年苏拉特城堡和Tanka收入、是否仅堡垒相关税。
3. 大英图书馆 **IOR/G/5**：Broach 1772–1783征收和1783向Scindia交割日期。
4. 苏格兰历史档案Horsburgh/Hannover 1720航海日记准确登记号、购买和抵岸名单。
5. 英国在Old Calabar五位船长与Efik地方方派的1767同期书信、SlaveVoyages船名索引。
6. 1799南印度 **Revenue Consultations、Secret Sundries、Military Consultations**：Kattabomman攻击/处刑、各地方首领产权。
7. 当年Archibald Blair Port Cornwallis选址/撤离日记及Andamanese原住民遭迫迁具体地名。
8. 1796–1800 Sri Lanka coastal petitions/military reports逐县核实，勿将康提同西海岸。
9. **RCIN734067** 现已读官方历史地图目录；后续只研究1781战场图，而1780需独立军事地图。
10. UCL历史饥荒表需要PDF页面截图人工复核，以及1782 Monegar Choultry慈善会计。
