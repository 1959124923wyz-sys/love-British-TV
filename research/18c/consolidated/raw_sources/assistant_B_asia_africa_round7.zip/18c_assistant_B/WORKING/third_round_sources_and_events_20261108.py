#!/usr/bin/env python3
"""Research-only third increment: source-verified Asia primary printed documents and Bengal archival transcriptions.
Never commits to GitHub. Idempotent by IDs; preserve previous work.
"""
import json,csv,datetime
from pathlib import Path
P=Path('/mnt/data/18c_assistant_B'); T=P/'TOPIC_DOSSIERS'; W=P/'WORKING'
U={
'BS133':'https://dl.tufts.edu/downloads/7s75dr260?filename=2r36v8583.pdf',
'BS134':'https://famineanddearth.exeter.ac.uk/displayhtml.html?id=fp_00175_en_narrativeoftransactionsinbengal_vol01',
'BS135':'https://famineanddearth.exeter.ac.uk/displayhtml.html?id=fp_00229_en_fortwilliam-indiahouse_vol07',
'BS136':'https://famineanddearth.exeter.ac.uk/displayhtml.html?id=fp_00374_en_committeeofrevenue25thseptember-30thoctober1783',
'BS137':'https://searcharchives.bl.uk/catalog/040-000004236',
'BS138':'https://hansard.parliament.uk/Commons/1813-02-22/debates/aa93e22f-1e33-4937-b97e-0ddf7c67e88c/PetitionOfTheEastIndiaCompanyForTheRenewalOfTheirCharter',
'BS139':'https://famineanddearth.exeter.ac.uk/displayhtml.html?id=fp_00082_en_bdgazetteershooghly',
'BS140':'https://gsl.lbsnaa.gov.in/opac-tmpl/bootstrap/Books/106122.pdf',
'BS141':'https://www.tandfonline.com/doi/full/10.1080/0308653042000329997',
}
entries=[
('BS133','Tufts Digital Library / Government of India (1929)','Aitchison, A Collection of Treaties, Engagements and Sanads, Vol. IX, Hyderabad, Mysore and Coorg','published_official_treaty_compilation_web_extracted_text_read','1759 Nizam grant, 1765 Mughal farman, 1766/1768 treaty, 1779 Guntur rent, 1788 surrender, 1798 subsidiary, 1799 partition; 1929 editorial transcriptions, NOT 18c originals'),
('BS134','University of Exeter Famine and Dearth','Henry Vansittart: A Narrative of Transactions in Bengal, Vol I (1766) selected transcription','published_1766_primary_account_selection_read','Governor self-defence and partisan contemporaneous account; 1757 Mir Jafar treaty, 1760 50-lakh anticipated revenue, land; online transcription selection'),
('BS135','University of Exeter / National Archives of India publication (1949)','Fort William–India House Correspondence, Vol. VII, 1773–1776, selected letters','transcribed_primary_correspondence_selection_read','1775-03-03 letter procurement investment, Bengal bond debt, costs; excludes original archival facsimile'),
('BS136','University of Exeter / West Bengal State Archives','Proceedings of Committee of Revenue, 25 Sept–30 Oct 1783','transcribed_primary_manuscript_selection_read','1783 Purnea and Tirhut food scarcity, export restrictions reversed, grain duty orders; edited selection has illegible gaps'),
('BS137','British Library India Office Records','IOR/H/196, Bengal affairs 1760–1766','archive_catalogue_only','pp.125-218 restitutions/grants, pp.259-261 inland trade by force, pp.263-265 Midnapore frauds; historical manuscript NOT read'),
('BS138','UK Parliament / Hansard','1813-02-22 East India Company charter renewal petition','1813_company_petition_as_published_primary_claim_read','Retrospective claims of 1759/1763/1765 territorial grants; self-serving petition not independent proof of territory'),
('BS139','University of Exeter / Bengal District Gazetteers (1912)','Hooghly District Gazetteer by O\'Malley & Chakravarti','later_government_gazetteer_selected_transcription_read','1760 Burdwan zemindari and failure of first-year collections; regional history not original fiscal ledger'),
('BS140','Lal Bahadur Shastri National Academy of Administration / University of Calcutta (1940)','M. N. Gupta, Land System of Bengal','1940_scholarly_book_pdf_extracted_text_read','1760-65 transfers and restricted Midnapore control, later analysis rather than contemporary land survey'),
('BS141','Journal of Imperial and Commonwealth History (academic research)','Ideology and British expansion in Bengal 1757–72','search_snippet_only_full_text_blocked','Academic contextual analysis of dastaks vs private trade; do not present as full read'),
]
sp=P/'SOURCE_REGISTRY.json'; sd=json.loads(sp.read_text()); seen={x['id'] for x in sd['sources']}
for id,org,title,reading,notes in entries:
 if id not in seen:
  sd['sources'].append({'id':id,'institution':org,'title':title,'url':U[id],'reading_level':reading,'archive_identifier':'IOR/H/196' if id=='BS137' else None,'notes':notes,'original_manuscript_personally_inspected':False,'consulted_on':'2026-11-08'})
sd['source_count']=len(sd['sources']);sp.write_text(json.dumps(sd,ensure_ascii=False,indent=2)+'\n')
# Batches are disk persisted before proceeding to other source searches
EV=P/'EVENT_CANDIDATES.json'; ed=json.loads(EV.read_text()); ev_seen={x['id'] for x in ed['events']}
def event(eid,topics,date,title,actors,place,action,effect,sources,confidence='published_primary_text_and_editor_review',precision=None):
 if eid in ev_seen:return
 ss=date.split('-') if date else []
 e={'id':eid,'topic_ids':topics,'year':int(ss[0]) if ss else None,'month':int(ss[1]) if len(ss)>1 else None,'day':int(ss[2]) if len(ss)>2 else None,
    'date_precision':'day' if len(ss)==3 else 'month' if len(ss)==2 else 'year' if len(ss)==1 else 'year_window',
    'title':title,'actors':actors,'location':place,'action':action,'political_effect':effect,'source_ids':sources,
    'source_urls':[U[x] for x in sources],'research_status':'candidate_not_published',
    'map_state':'named_place_no_verified_coordinates','geometry_id':None,'confidence':confidence,
    'historical_control_boundary_verified':False,'actual_British_control_area_sqkm':None}
 ed['events'].append(e)

event('AB-NEW-007-001',['E18-B01','E18-B02'],'1759-05-14','Salabat Jang授予Masulipatam及沿海辖区敕令','Salabat Jang; Francis Forde; EIC','Masulipatam/Machilipatnam; Hyderabad', '条款要求将Masulipatam、Nizampatam和Condavir等指定区域颁给公司并排斥法军，地方地税与实际驻军须逐处核','negotiated_specific_district_grant_not_whole_andhra',['BS133'])
event('AB-B03-006',['E18-B03','E18-B06'],'1757','Mir Jafar条约准许公司取得加尔各答以南的zamindari','Mir Jafar; EIC','Calcutta to Culpee/Kulpi','1757条款把Calcutta界沟以南至Culpee部分土地授予公司zamindari，需继续缴纳与其他地主相同的地租；绝非孟加拉全境权利','conditional_zamindari_not_full_sovereignty',['BS134'])
event('AB-NEW-032-001',['E18-B03','E18-B06'],'1760-09-27','Mir Qasim上台协定授公司Burdwan/Midnapore/Chittagong收益','Mir Qasim; EIC Select Committee; Mir Jafar','Burdwan, Midnapore, Chittagong','公司以军事支持Mir Qasim继任为交换，按条约取得三地约50 lakh卢比预计年收益的土地权利；实际收税与占据应分县核','military_financed_revenue_assignment_three_districts',['BS134','BS140'])
event('AB-NEW-032-002',['E18-B03','E18-B06'],'1760-11-17','Burdwan财政收入专供公司军费的追加凭据','Mir Qasim; EIC','Burdwan','较晚税制研究著述将1760年11月17日列为伯德万军费收入划拨日；须复查原grant, 与9月27日总条约不混为同一文书','revenue_assignment_after_general_treaty',['BS140'],'secondary_book_quoted_not_original_assignment')
event('AB-NEW-032-003',['E18-B03','E18-B06'],'1760-12','Mir Qasim将Chittagong收入权限移交公司','Mir Qasim; EIC; Chittagong local officials','Chittagong','1940年税制研究指出Chittagong于1760年12月授公司；Midnapore部分区域延至1765才有效占有','revenue_concession_not_all_simultaneous_ground_control',['BS140'],'secondary_book_quoted_not_original_assignment')
event('AB-NEW-033-001',['E18-B01','E18-B19'],'1763-03-01','公司加尔各答议会否定Vansittart与Mir Qasim私商关税协商','EIC Calcutta Council; Henry Vansittart; Warren Hastings; Mir Qasim','Calcutta / Fort William','公司议会多数反对对公司雇员私营内陆贸易征税的9%安排；英公司官员与纳瓦卜税官管辖权发生公开冲突','company_private_trade_privilege_dispute_not_legal_sovereignty',['BS137','BS141'],'source_only_secondary_snippet_plus_archive_catalogue')
event('AB-NEW-033-002',['E18-B01','E18-B19'],'1763-03-22','公司委员会反对Mir Qasim对本地商人全面取消关税','Mir Qasim; EIC Calcutta Council','Calcutta / Bengal','公司一方因免税特许遭削弱而反对纳瓦卜对所有交易取消关税；日期出自当年报告的后世援引，原1763会议全文待读','private_trader_privilege_vs_local_tax_equality',['BS137'],'archive_catalogue_and_later_transcription_requires_primary_crosscheck')
event('AB-NEW-007-002',['E18-B01','E18-B21'],'1765-08-12','Shah Alam II敕令列明北部Circars授予东印度公司','Shah Alam II; EIC; Hyderabad Nizam','Northern Circars','莫卧儿皇帝1765年敕令将具名辖区授予公司，后仍需与海得拉巴尼扎姆谈判；法定授予不保证各地驻军接收','imperial_farman_claim_not_instant_territory_control',['BS133'])
event('AB-NEW-007-003',['E18-B01','E18-B21'],'1766-11-12','Nizam Ali Khan与Calliaud签北部五Circars协定','Nizam Ali Khan; John Calliaud; EIC','Hyderabad','公司取得五具名circar敕令及条件性军援条款，承诺不需要出兵年份按各区实际交付约最多每年9 lakh卢比','conditional_nizam_grant_with_annual_tribute',['BS133'])
event('AB-NEW-007-004',['E18-B01','E18-B12'],'1768-02-23','三方条约重新划分Circars贡赋与驻军','Nizam Ali Khan; Nawab of Carnatic; EIC','Fort St George / Madras','1768条约修改1766安排，先六年按实际控制条件缴付2 lakh卢比、1774后条件性5或7 lakh，并约定军事撤回','revised_conditional_fiscal_and_military_rights',['BS133'])
event('AB-NEW-007-005',['E18-B01','E18-B12'],'1768','公司承诺撤出Khammam与Warangal短期驻军','Nizam Ali Khan; EIC; local commanders','Khammam/Warangal','1768第5条记公司曾短暂控制二地、约定在Nizam军越过Kistna后撤出；具体实际撤军日待核，不得把临时驻点延到1799','temporary_occupied_forts_with_conditional_withdrawal',['BS133'])
event('AB-NEW-031-001',['E18-B01','E18-B21'],'1779-04-27','公司向Basalat Jang租入Guntur税收经营权','Basalat Jang; EIC Madras Council; local zamindars','Guntur / Kondavid','租佃约以地方既有税额为租金，约定公司供兵、军费先从租额扣除，并保留Kondavid堡由地方人员管理及英驻军','revenue_farm_not_overall_sovereignty',['BS133'])
event('AB-NEW-031-002',['E18-B01','E18-B21'],'1788-09-18','Nizam命令交出Guntur给公司','Nizam Ali Khan; Captain John Kennaway; EIC','Guntur','尼扎姆18日下令地方官员交付Guntur及收入收欠账；命令签署与实际交接时间分开核','directive_to_transfer_specific_circar',['BS133'])
event('AB-NEW-031-003',['E18-B01','E18-B21'],'1789-07-07','Cornwallis书信重申Guntur交付与Circar贡赋须对账','Lord Cornwallis; Nizam Ali Khan; EIC','Hyderabad / Madras','信明确此前1768条约有关Guntur交付及公司向尼扎姆付款双方均未履行，说明1788命令与实际账款不应被自动视为已完全执行','mutual_unfulfilled_fiscal_and_control_obligations',['BS133'])
event('AB-NEW-029-001',['E18-B17','E18-B21'],'1798-09-01','海得拉巴附属条约规定公司驻军与尼扎姆军费','Nizam Ali Khan; James Achilles Kirkpatrick; Richard Wellesley; EIC','Hyderabad','条约约定6000 sepoys及炮兵、每月201425卢比/年度2417100卢比、季度604275卢比，禁止尼扎姆继续使用法国官兵；尼扎姆保留本邦政体','subsidiary_force_and_foreign_policy_constraint_not_direct_eic_sovereignty',['BS133'])
event('AB-NEW-030-001',['E18-B15','E18-B21'],'1799-06-22','公司与尼扎姆订立迈索尔战后分治条约','EIC; Nizam Ali Khan; Wodeyar heirs; Peshwa named nonparticipating','Seringapatam / Mysore','22日条约分明规定公司Schedule A、尼扎姆Schedule B、Wodeyar Schedule C及Seringapatam岛堡归公司；Peshwa条款是后续邀请','partition_between_three_political_bodies_not_all_company_land',['BS133'])
event('AB-NEW-030-002',['E18-B15','E18-B21'],'1799-07-08','迈索尔王室与公司订附属军队条约','Mysore Maharaja Krishna Raja Wodeyar; EIC','Mysore','1929官方条约汇编目录列出1799-07-08另订附属军队条约；须详查条款及王室实际行政自主范围','princely_state_with_company_subsidiary_treaty',['BS133'],'catalogue_index_within_published_treaty_collection')
event('AB-NEW-030-003',['E18-B15'],'1799-07-13','尼扎姆确认1799迈索尔瓜分约','Nizam Ali Khan; EIC','Hyderabad','条约汇编列尼扎姆1799-07-13批准，区别1799-06-22签署与1800实地交割','ratification_stage_only',['BS133'])
event('AB-B18-006',['E18-B18','E18-B19'],'1775-03-03','董事信披露孟加拉公司货物采购、债券成本与财务压力','EIC London Court of Directors; Calcutta Council','London / Calcutta','董事信报告1769年采购以一年期8%息债券支付、到1773年债务剧增，并反驳孟加拉投资可简单视为无成本净汇款','director_account_of_trade_credit_costs',['BS135'])
event('AB-NEW-034-001',['E18-B07','E18-B16'],'1781-02-09','孟加拉地方税务议会被废改以加尔各答集中管税','EIC Court of Directors; Committee of Revenue; local diwan','Calcutta / Bengal','埃克塞特项目引西孟加拉档案的机构说明载1781年2月9日地方Revenue Councils被废、税务改由加尔各答协调','company_revenue_administrative_centralisation',['BS136'],'historian_archival_introduction_date_not_original_circular')
event('AB-NEW-034-002',['E18-B16'],'1786','孟加拉成立Board of Revenue代替委员会','EIC Calcutta; Board of Revenue','Calcutta','来源概要记委员会1786年被Board of Revenue取代；尚需成立法令及确切日期','administrative_tax_institution_reorganization',['BS136'],'editorial_introduction_requires_formal_order')
event('AB-NEW-035-001',['E18-B07','E18-B16'],'1783-09-23','Purnea税官报告旱灾粮价上涨并暂停稻米外运','W. Douglas; Purnea rice cultivators and traders','Purnea','西孟加拉档案转录载W. Douglas报告缺雨、稻米歉收、价格上涨与对1769–70恐慌，宣布禁止新稻米外运','local_emergency_grain_export_restriction',['BS136'])
event('AB-NEW-035-002',['E18-B07','E18-B16'],'1783-10-21','Purnea负责人建议保留公共用粮运输例外','J. Heatly; Purnea officials; rice traders','Purnea','21日呈文允许公共采购用谷例外，征询私人商船货物扣留与释放；分开地方命令和公司上级回应','partial_grain_embargo_with_exemption',['BS136'])
event('AB-NEW-035-003',['E18-B07','E18-B16'],'1783-10-27','加尔各答收入委员会撤销地方禁运要求稻米跨区流通','Warren Hastings and revenue committee; Purnea & Tirhut officials','Purnea / Tirhut / Calcutta','27日往来命令反对当地封锁粮食出区，要求允许商人跨县运粮并通过税务机关发布低税政策','reversal_of_local_grain_embargo_not_famine_death_estimate',['BS136'])
event('AB-B19-004',['E18-B19'],'1773-03-01','加尔各答讨论饥荒后Kasimbazar丝绸生产衰退','EIC Bengal Council; silk growers of Cossimbazar','Kasimbazar / Calcutta','1773年3月1日公司信述1770年饥荒引发丝绸供应下降与桑地种植鼓励，属于公司估计需与实际丝工劳动条件核对','post_famine_industry_policy',['BS135'])
EV.write_text(json.dumps(ed,ensure_ascii=False,indent=2)+'\n')
# human CSV synchronize
fields=['id','topic_ids','year','month','day','year_window','date_precision','title','actors','location','action','political_effect','source_ids','source_urls','research_status','map_state','geometry_id','confidence','historical_control_boundary_verified','actual_British_control_area_sqkm']
with open(P/'EVENT_CANDIDATES.csv','w',newline='',encoding='utf-8-sig') as f:
 w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader()
 for e in ed['events']:
  a={k:e.get(k,'') for k in fields};
  for k in ['topic_ids','source_ids','source_urls']:a[k]=';'.join(e.get(k,[]))
  w.writerow(a)
# new areas of inquiry
cp=P/'NEW_CANDIDATES.json'; cd=json.loads(cp.read_text());ids={x['candidate_id'] for x in cd['candidates']}
C=[('AB-NEW-028','1759—1768北部Circars：尼扎姆、莫卧儿敕令与公司权力条件','E18-B01','可核1759/1765/1766/1768四套文件区别具体授予、军事服务、征税及实际驻点。',['BS133']),
('AB-NEW-029','1798海得拉巴常驻附属军条约：军费与外交干预','E18-B21','独立司法财权的邦与公司驻军不是同一层；6000 sepoy及2417100卢比年费可作为明确经济账。',['BS133']),
('AB-NEW-030','1799迈索尔战后分治、尼扎姆分得与Wodeyar复辟','E18-B15','1799正式瓜分约具schedule A/B/C，塞林加帕特纳城堡、公司税收、尼扎姆权利和Wodeyar都可单独追踪。',['BS133']),
('AB-NEW-031','1779—1789Guntur租税经营与尼扎姆交付纠纷','E18-B01','1779租税权、1788交割指令及1789双方尚未履行是三种不同状态。',['BS133']),
('AB-NEW-032','1760 Mir Qasim三地税收授予与公司实际接管错时','E18-B03','1760年名义受让、各地征收时点和地方地主权不可省略。',['BS134','BS140']),
('AB-NEW-033','1763 Mir Qasim贸易税平权争议与公司私商特许','E18-B01','1763公司官员税务豁免诉求与地方纳瓦卜关税权发生冲突，需区别公贸与官员私贸。',['BS137','BS141']),
('AB-NEW-034','1781—1786孟加拉税务局机构改组与当地Diwan职责','E18-B16','1781收入委员会集权和1786 Board of Revenue提供县级司法/税权转移研究线索。',['BS136']),
('AB-NEW-035','1783 Purnea-Tirhut大旱与粮食流通禁令的政策冲突','E18-B07','1783原信日级时间线可对照1770灾后粮食自由贸易与应急禁运的制度变迁。',['BS136'])]
for iid,t,link,reason,sources in C:
 if iid not in ids:cd['candidates'].append({'candidate_id':iid,'title':t,'related_original_topic_id':link,'rationale':reason,'source_ids':sources,'decision':'propose_to_editor'})
cp.write_text(json.dumps(cd,ensure_ascii=False,indent=2)+'\n')
# economic records
Econ=P/'ECONOMIC_EVIDENCE.csv'
with open(Econ,encoding='utf-8-sig',newline='') as f:
 rr=csv.DictReader(f); fn=rr.fieldnames; rows=list(rr)
ids={r['id'] for r in rows}
def econ(eid,topic,start,end,value,unit,desc,payer,recipient,period,sids,verification,interpretation,level='published_official_treaty_compilation_text_read',transferred=False):
 if eid in ids:return
 d={k:'' for k in fn}
 d.update(id=eid,topic_ids=';'.join(topic),year_start=start,year_end=end,value=str(value),currency_or_unit=unit,metric_definition=desc,payer_or_affected=payer,recipient_or_observer=recipient,accounting_period=period,source_ids=';'.join(sids),source_urls=';'.join(U[x] for x in sids),source_reading_level=level,source_role='contemporary_document_in_later_published_collection',verification_status=verification,was_primary_manuscript_personally_read='False',actual_received_or_transferred_verified=str(transferred),interpretation_limit=interpretation)
 rows.append(d)
econ('EXTRA-1760-COSSIM-EST-50LAKH',['E18-B03','E18-B06'],1760,1760,5000000,'sicca_rupees_approx_type_unverified','Mir Qasim three districts projected annual revenue (50 lakh)', 'Burdwan/Midnapore/Chittagong tax payers','EIC','1760 negotiation fiscal estimate',['BS134'],'contemporary_official_estimate_not_revenue_collected','50 lakh is forecast of annual income, not actual land tax cash or annual net profit','published_primary_account_selection_read')
econ('EXTRA-1766-CIRCARS-ANNUAL-MAX',['E18-B01'],1766,1767,900000,'rupees_local_variety_unverified','Five Circars maximum conditional annual payment to Nizam under 1766 article 3','EIC','Nizam Ali Khan','Annual only if military assistance unrequired and named districts taken',['BS133'],'treaty_stipulated_not_actual_payment','5 lakh for 3 core districts plus up to 2 lakh for each of two others, not 9 lakh automatic from 1766')
econ('EXTRA-1768-CIRCARS-FIRST6',['E18-B01'],1768,1773,200000,'arcot_rupees_per_year','Payment pledged in 1768 treaty for first six years subject to territorial conditions','EIC','Hyderabad Nizam','1 Jan 1768 through six-year term',['BS133'],'treaty_stipulated_not_actual_payment','2 lakh annual, increases by 1 lakh at each of two kists only if Condavir handed over; not same as 1766 9 lakh')
econ('EXTRA-1768-CIRCARS-AFTER1774',['E18-B01'],1774,1799,500000,'arcot_rupees_per_year_conditional','1768 treaty projected annual payment from 1774 to Nizam (base)','EIC','Hyderabad Nizam','1 Jan 1774 onwards, if peaceful possession and conditions met',['BS133'],'treaty_stipulated_not_actual_payment','5 lakh base or 7 lakh if Condavir held, suspension under war/loss; do not extrapolate to 1799 or claim paid')
econ('EXTRA-1768-CIRCARS-CONDAVIR',['E18-B01'],1774,1799,700000,'arcot_rupees_per_year_conditional','1768 treaty projected annual payment from 1774 when Condavir also possessed','EIC','Hyderabad Nizam','Alternative to base five-lakh obligation',['BS133'],'alternative_scenario_not_additive','Mutually exclusive 5 lakh base and 7 lakh when Condavir possessed, do not sum')
econ('EXTRA-1779-GUNTUR-ZAMINDAR-PAGODAS',['E18-B01'],1779,1779,5000,'pagodas_unspecified_type_per_year','Existing annual local zamindar allowances maintained in Guntur treaty','Guntur revenue administration','Guntur zamindars','1779 treaty article 5',['BS133'],'treaty_stipulation_not_collected','Allowance to local holders; not EIC tax income, nor rent total')
econ('EXTRA-1798-HYDERABAD-SUBSIDY-YEAR',['E18-B21','E18-B17'],1798,1799,2417100,'rupees_local_currency_unspecified_per_year','Annual subsidy Hyderabad is obliged to pay for Company force of 6000 sepoys and artillery','Hyderabad state treasury','EIC military subsidiary force','1798 treaty art 3 per year',['BS133'],'contracted_annual_subsidy_actual_payment_unverified','Annual obligation, not profit; Hyderabad retains own government; monthly and quarterly values are same sum not additive')
econ('EXTRA-1798-HYDERABAD-SUBSIDY-QUARTER',['E18-B21'],1798,1799,604275,'rupees_local_currency_unspecified_per_quarter','Quarterly instalment of annual subsidiary force funding','Hyderabad state treasury','EIC military subsidiary force','Every 3 English months',['BS133'],'contracted_quarterly_component_not_additive','4 quarters=2417100 annual, subset of annual record above')
econ('EXTRA-1798-HYDERABAD-SUBSIDY-MONTH',['E18-B21'],1798,1799,201425,'rupees_local_currency_unspecified_per_month','Monthly contracted army maintenance rate','Hyderabad state treasury','EIC military subsidiary force','1798 treaty art 3 per month',['BS133'],'contracted_monthly_component_not_additive','12 months=2417100 annual; same obligation as other frequency rows')
econ('EXTRA-1799-MYSORE-COMPANY-SCHEDULE-GROSS',['E18-B15'],1799,1799,777170,'canterai_pagodas_whole_component','Schedule A nominal assessed annual revenue of assigned districts prior to family maintenance deduction','Tipu Mysore territories','EIC Company share listed at partition','22 Jun 1799 schedule A',['BS133'],'treaty_schedule_assessment_not_real_cash','Fractions of pagoda omitted (source lists subdivisions); not sterling nor guaranteed tax realized')
econ('EXTRA-1799-MYSORE-COMPANY-SCHEDULE-NET',['E18-B15'],1799,1799,537170,'canterai_pagodas_whole_component','Schedule A projected remainder to EIC after family maintenance provision','Tipu Mysore territories','EIC','22 Jun 1799 schedule A',['BS133'],'treaty_schedule_projected_after_earmark','777170 minus 240000 = 537170 in source; not actual net British extraction and must not add to gross record')
econ('EXTRA-1799-MYSORE-NIZAM-SCHEDULE-GROSS',['E18-B15'],1799,1799,607332,'canterai_pagodas_whole_component','Schedule B nominal annual revenue of Nizam share','Tipu Mysore territories','Hyderabad Nizam','22 Jun 1799 schedule B',['BS133'],'treaty_schedule_assessment_not_real_cash','Nizam is separate polity, not British EIC receipts; fractions omitted')
econ('EXTRA-1799-MYSORE-NIZAM-SCHEDULE-NET',['E18-B15'],1799,1799,537332,'canterai_pagodas_whole_component','Nizam Schedule B share after personal jagir earmark','Tipu Mysore territories','Hyderabad Nizam','22 Jun 1799 schedule B',['BS133'],'treaty_schedule_projected_after_earmark','607332-70000; subset, separate from company income and actual cash')
econ('EXTRA-1775-LETTER-1769-INVESTMENT',['E18-B18','E18-B19'],1769,1769,289819,'GBP_18c_nominal','Calcutta purchases for Company investment reportedly acquired with 8% 12-month company bonds','Bengal manufacturers and trading middlemen','EIC Fort William warehouse','First season of 1769 purchasing, 1775-03-03 retrospective letter',['BS135'],'contemporary_company_directors_letter_not_invoice','Gross purchased goods invoice value; credit debt not free extraction, and do not add to total 1769–73 Bengal cargo','transcribed_primary_correspondence_selection_read')
econ('EXTRA-1775-LETTER-BOND-DEBT-EARLY',['E18-B18'],1769,1769,351817,'GBP_18c_nominal_stock','Bengal bond debt at time Company opened warehouse for interest-note purchases','EIC Bengal creditors','EIC Calcutta balance sheet','Opening indebtedness before later purchasing policies, year approximate',['BS135'],'contemporary_directors_recalled_balance_date_approx','Debt stock, not cash remitted; exact as-of date not given in excerpt','transcribed_primary_correspondence_selection_read')
econ('EXTRA-1775-LETTER-BOND-DEBT-1773',['E18-B18'],1773,1773,1547458,'GBP_18c_nominal_stock','Bengal bond debt of EIC in 1773 as reported by 1775 directors','EIC Bengal creditors','EIC Calcutta balance sheet','1773 stock',['BS135'],'contemporary_directors_letter_debt_stock','Do not subtract gross revenue to infer colony net profit; possible debt categories need original ledgers','transcribed_primary_correspondence_selection_read')
econ('EXTRA-1775-LETTER-ADDITIONAL-INTEREST',['E18-B18'],1773,1773,95636,'GBP_18c_nominal_per_year','Directors reported annual interest on extra Bengal bond debt','EIC','Company bond creditors','1773 reported annual cost',['BS135'],'contemporary_directors_letter_estimate','Annual interest on incremental debt, not added to principal nor proven paid exact amount','transcribed_primary_correspondence_selection_read')
econ('EXTRA-1775-LETTER-BENGAL-CARGO',['E18-B18','E18-B19'],1769,1773,2901194,'GBP_18c_nominal_total_period','Company Bengal cargoes amount as reported in 1775 letter, 1769-1773','Bengal producers/merchants','EIC export inventory','five-year reported total 1769–1773',['BS135'],'contemporary_directors_letter_cargo_value','Gross exports / investment goods, not audited profit, not physical cash transfer, and includes 1769 procurement','transcribed_primary_correspondence_selection_read')
econ('EXTRA-1775-LETTER-PRICE-INCREASE',['E18-B18','E18-B19'],1769,1773,725298,'GBP_18c_nominal_hypothetical','Directors conditional estimate of 25% increased purchase prices on 1769-1773 cargo','EIC Calcutta','EIC trade cost forecast','1769-1773 inferred hypothetical',['BS135'],'contemporary_directors_hypothetical_not_actual_payment','Counterfactual price uplift = 25% * 2901194 rounded; no independent spot market validation','transcribed_primary_correspondence_selection_read')
econ('EXTRA-1775-LETTER-BILLS-DRAWN',['E18-B18'],1769,1773,1063000,'GBP_18c_nominal','Bills drawn upon EIC Board, recalled as Bengal available resources during 1770 famine','EIC correspondents','Company treasury obligations and resources','approximate 1769–73 discussion in 1775 letter',['BS135'],'company_letter_accounting_claim','Bills drawn are financial instrument; direction, obligor and net cash need original entries, not remitted colonial net profit','transcribed_primary_correspondence_selection_read')
with open(Econ,'w',newline='',encoding='utf-8-sig') as f:
 w=csv.DictWriter(f,fieldnames=fn);w.writeheader();w.writerows(rows)
# control changes
tr=P/'CONTROL_TRANSITIONS_B_E.csv'
with open(tr,encoding='utf-8-sig',newline='') as f:
 rdr=csv.DictReader(f); cols=rdr.fieldnames; trs=list(rdr)
seen={x['id'] for x in trs}
transitions=[
('T026','1759-05-14','Masulipatam / Nizampatam','French/Mughal/Hyderabad contested trade jurisdiction','Salabat Jang grants specified rights to EIC','grant_claim_not_proven_whole_district_occupation',['BS133'],'AB-NEW-007-001','Royal grants do not establish which village forts occupied on each date'),
('T027','1760-09-27','Burdwan Midnapore Chittagong','Mir Jafar administration and zamindar rights','Mir Qasim assigns specific revenue rights to Company','conditional_revenue_transfer',['BS134','BS140'],'AB-NEW-032-001','Existing zamindar rights and parts of Midnapore remain; do not paint 3 modern districts'),
('T028','1765-08-12','Northern Circars','Hyderabad and imperial fiscal jurisdictions; mixed EIC forts','Mughal emperor issues Company grant','imperial_grant_not_full_occupation',['BS133'],'AB-NEW-007-002','Needs 1766 and 1768 negotiation plus fort-by-fort records'),
('T029','1766-11-12','Northern Circars','Imperial grant not accepted fully by Nizam','Nizam Ali grants conditionally with EIC tribute/forces','hyderabad_eic_treaty_fiscal_rights',['BS133'],'AB-NEW-007-003','Guntur/Condavir not immediately EIC physical property'),
('T030','1768-02-23','Northern Circars','1766 annual 9 lakh commitment with disputed occupation','New three-party treaty recalibrates territory and fiscal payment','negotiated_partial_eic_revenue_occupation',['BS133'],'AB-NEW-007-004','2 lakh through 1773; 5/7 lakh after 1774 conditional only'),
('T031','1768','Khammam / Warangal','EIC forces momentarily positioned','Company undertakes withdrawal under treaty','short_term_occupation_withdrawal_pending',['BS133'],'AB-NEW-007-005','Cannot assume when actual evacuation occurred'),
('T032','1779-04-27','Guntur','Basalat Jang jagir and revenue management','EIC rents specific Circar revenue and garrison access','leased_revenue_right_not_proven_sovereignty',['BS133'],'AB-NEW-031-001','Fort of Condavir still entrusted to local kiladar'),
('T033','1788-09-18','Guntur','Hyderabad administration with unresolved 1779 rent','Nizam orders transfer to Company; follow-through needs log','ordered_handover_not_verified_actual_transfer',['BS133'],'AB-NEW-031-002','1789 Cornwallis still references unfulfilled fiscal conditions'),
('T034','1798-09-01','Hyderabad','Independent Nizam employing French and other European officers','Nizam bound to fund 6000 EIC sepoys and exclude French officers','subsidiary_alliance_hedged_autonomy_not_british_polygon',['BS133'],'AB-NEW-029-001','No conversion of Nizam full territory to EIC land'),
('T035','1799-06-22','Mysore / Seringapatam','Tipu administration defeated 4 May','Scheduled division among EIC Nizam Wodeyar state and fortress island','multilateral_partition_schedules_without_georeference',['BS133'],'AB-NEW-030-001','Schedules A/B/C should be mapped only against authenticated contemporaneous boundaries'),
('T036','1799-07-08','Restored Mysore','Wodeyar restored with separate allocation','Separate subsidiary arrangement with EIC','princely_state_subsidiary_not_eic_direct_rule',['BS133'],'AB-NEW-030-002','Separate treaty full clauses require close reading'),
]
for iid,date,place,fr,to,sem,sids,eid,uncertainty in transitions:
 if iid not in seen:
  trs.append(dict(id=iid,date=date,place=place,from_status=fr,to_status=to,actors='EIC and Indian sovereign/political authorities',control_semantics=sem,historical_boundary_verified='false',area_sqkm='',geometry_policy='named_site_point_or_unmapped_only',source_ids=';'.join(sids),related_event_id=eid,uncertainty=uncertainty))
with open(tr,'w',newline='',encoding='utf-8-sig') as f:w=csv.DictWriter(f,fieldnames=cols);w.writeheader();w.writerows(trs)

# Detailed human-readable reports; separate from existing dossier pages, preserving old sources and content
sections={
'AB-NEW-028':('北部Circars四种合法性层次 1759—1768','''1759-05-14 Salabat Jang与Francis Forde签署的文书只列Masulipatam/Nizampatam等地区及排斥法国军官；1765-08-12莫卧儿Shah Alam II又授北部Circars；1766-11-12 Nizam Ali Khan与John Calliaud签约，按辖区实际接管、公司供军情况条件性要求每年5+2+2=9 lakh卢比；1768-02-23 Madras三方条约再调整为前6年每年2 lakh、若Condavir接管增加缴款，1774年起有5或7 lakh两种可选条件。\n\n1768约规定公司在Khammam/Warangal行动后撤，然而没有实际撤军日。各条都是权力变更线索，不可把现代Andhra Pradesh全染成公司领土。\n'''),
'AB-NEW-029':('1798海得拉巴军费与政治干预','''1798-09-01公司与尼扎姆条约第3条：6000名sepoys及欧洲炮兵、月供201,425卢比、年供2,417,100卢比，按季度604,275卢比结算；三者属同一义务，不可累计。若欠款，公司可从自己应付北部Circars贡赋中扣除，必要时转而指定地方地税收入；第6条要求尼扎姆解散法国官兵，并限制雇用欧洲官员。\n\n这是一种军事驻留、金融依赖和外交从属机制；尼扎姆并未因此成为英国王室的直接殖民地。须另核实际季度缴费凭证和兵籍。\n'''),
'AB-NEW-030':('1799迈索尔瓜分和地方王朝恢复','''1799-06-22战后条约第1/2/4/5条按Schedule A/B/C分给公司、尼扎姆、恢复的Wodeyar；第3条另指定Seringapatam城堡与岛屿给公司。公司Schedule A的列明年评估收入为777,170 Canterai pagodas（略去细小分数），扣给Tipu/Haider家族的240,000后剩约537,170；尼扎姆Schedule B为607,332，扣相关jagir 70,000后为537,332。四项是条约财政评估和内部扣除，绝非同年实收四笔独立净利。\n\n第7条认为Peshwa未参与攻城，邀请其加入但与实际接收并不相同。尼扎姆1799-07-13批准条约；1799-07-08有恢复Wodeyar与公司订立的另一附属约。地图应分别展示公司直接税辖、尼扎姆政体、Wodeyar附属政体，不可把现今Karnataka涂成整块英属。\n'''),
'AB-NEW-031':('Guntur商税权与军事驻留不等同主权','''1779-04-27 Basalat Jang协议公司“租”Guntur，佣兵维护费从租金中按月支出；原Zamindars每年5,000 pagodas津贴继续，Kondavid城堡保留地方管理者、允许英军驻防。1788-09-18 Nizam 下令地方长官交付Guntur；1789-07-07 Cornwallis承认此前应交地与贡款仍存在未履行。\n\n这三个截面必须分开：租税—行政交割指令—未决财权，不能直接断言1779起Guntur已彻底被公司统治。\n'''),
'AB-NEW-032':('1760孟加拉三个税区的错时转移','''Henry Vansittart 1766年出版自辩书转述：EIC Select Committee为取得年约50 lakh卢比预期财政收入，支持Mir Qasim取代Mir Jafar并交换Burdwan、Midnapore、Chittagong税权。1940 Calcutta University学术书另记1760-11-17 Burdwan年税划拨、1760-12 Chittagong转移，并称Midnapore至1765仍有部分地区未被实际接管。\n\n年50 lakh为谈判预计财政规模，不是已经收到的收入。zaminadri/assignment、原有地主权益与名义主权并存。\n'''),
'AB-NEW-033':('贸易免税特许如何冲突于本土商人的税制','''1763 Mir Qasim争议不是简单的EIC“被允许自由贸易”：公司官方贸易的dastak与公司官员借用免税证从事私人内陆贸易需要区分。Vansittart与Mir Qasim试图约9%关税安排，Calcutta多数议员1763-03-01予以否定；Mir Qasim遂主张普遍废除内陆关税，让本地商人获得较公平竞争条件，引来公司反对。\n\n本案现有1763决议日期取自后世研究和英国图书馆 IOR/H/196 目录；原Council会议全文尚未直接读取。经核档案亦有'Barja/Guchaout'武力私商方式案卷，保留查原卷任务。\n'''),
'AB-NEW-034':('财政征收结构逐阶段更替','''西孟加拉档案由埃克塞特大学转录并编写引言：1781-02-09地方Provincial Councils of Revenue结束，Calcutta Revenue Committee集中管理、依赖Diwan和县级征收官；1786再由Board of Revenue接替。须从原条例确认各district Collector准确职权，不能把1772年全国统一直接管理写成唯一制度。\n'''),
'AB-NEW-035':('1783 Purnea-Tirhut旱灾与禁运反转','''1783-09-23 Purnea官员W Douglas称季节干旱、稻米歉收、价格骤涨，并因当地贫民惧怕1769—70重演而限制稻米外运。10-21地方负责人在运输与公共用粮之间作例外安排；10-27上级来函反对封县、要求放行各地粮食、降低关卡征收并多次上报米价。\n\n这是1783年另一次危机的本地治理证据，不能把1783气候或禁运争议直接倒推为1770同样发生；原扫描转录部分价格与名称字迹缺损，无法精确重建价格指数。\n''')}
for iid,(headline,description) in sections.items():
 src='BS133' if iid in ['AB-NEW-028','AB-NEW-029','AB-NEW-030','AB-NEW-031'] else 'BS134; BS140' if iid=='AB-NEW-032' else 'BS137; BS141' if iid=='AB-NEW-033' else 'BS136'
 report=f'# {iid} | {headline}\n\n**研究级，未发表。** 日期：2026-11-08。\n\n## 史料核查结果\n\n{description}\n## 原始来源与阅读级别\n\n'
 for sid in src.split('; '):report+=f'- [{sid}]({U[sid]})。来源性质见`../../SOURCE_REGISTRY.json`；未读取博物馆/馆藏手稿原件。\n'
 report+='\n## 地图交接\n\n目前只有已证明的具名地点、地方税权和条约年份；精确行政边界和现场坐标未审核，一律不得生成实控Polygon或面积。史料可以研究虚线范围，但必须先具名点及有据示意方法。\n'
 (T/'NEW_CANDIDATES'/f'{iid}.md').write_text(report)
# append to existing B dossiers in dedicated headings if not present
for tid,head,body in [
 ('E18-B01','第三轮：北部Circars、Guntur与1700后公司贸易法权','1759授地／1765莫卧儿敕令／1766尼扎姆协定／1768三方修改；1779 Guntur租税，1788交地指令和1789未了贡款。详见 AB-NEW-028 /031。'),
 ('E18-B03','第三轮：1757 zamindari及1760三地军费财政交换','1757条约准许Calcutta以南公司为zaminadar并付地方地租；1760 Mir Qasim协定预计三地税收50 lakh，后续公司实际接管时间不同。详见 AB-NEW-032。'),
 ('E18-B15','第三轮：1799年分治和Wodeyar恢复','1799-06-22公司、尼扎姆、Wodeyar各有独立Schedule，1799-07-08再有Mysore附属驻军约；分地税估计不是实际移转现金。详见AB-NEW-030。'),
 ('E18-B18','第三轮：1775信中的孟加拉投资债券与借款','1775-03-03董事信描述1769以8%一年期债券购入£289,819商品、1773孟加拉债务£1,547,458和货价上涨；信源承认并不能把投资品总价当纯净汇款。来源BS135。'),
 ('E18-B21','第三轮：1798海得拉巴驻军财政与外交条款','每年2,417,100卢比为6000 sepoys及炮兵的军费约定；尼扎姆不得任用法国官兵，欠款可抵扣北部Circar贡金。来源BS133。'),
 ('E18-B07','第三轮：1783灾情对1770政策对照','1783 Purnea、Tirhut原税务记录有地方禁运及中央否决，不可凭此倒推1770同一制度；同专卷还收1775董事信讨论1770饥荒使孟加拉税收下降的公司自述。来源BS135、BS136。'),
 ('E18-B16','第三轮：1781—1786实际收入委员会改组','1781年地区税务议会废止、1786年 Board of Revenue 成立的机构转轨须区别于1772财政承包、1793永久税。来源BS136。'),
]:
 file=T/f'{tid}.md';s=file.read_text();mark='## '+head
 if mark not in s:file.write_text(s+'\n'+mark+'\n\n'+body+'\n')
# checkpoint - truly saved now
(W/'THIRD_ROUND_BATCH1_CHECKPOINT.json').write_text(json.dumps({'date':'2026-11-08','sources':len(sd['sources']),'events':len(ed['events']),'new_topics':len(cd['candidates']),'economics':len(rows),'control_transitions':len(trs),'notes':'Increment batch 1 saved to disk, not published and no git action.'},ensure_ascii=False,indent=2)+'\n')
print('BATCH1 SAVED',len(sd['sources']),len(ed['events']),len(cd['candidates']),len(rows),len(trs))
