import json,csv,os,datetime,collections,pathlib
ROOT=pathlib.Path('/mnt/data/18c_assistant_B')
S=json.loads((ROOT/'SOURCE_REGISTRY.json').read_text())
E=json.loads((ROOT/'EVENT_CANDIDATES.json').read_text())
N=json.loads((ROOT/'NEW_CANDIDATES.json').read_text())
Sids={x['id'] for x in S['sources']};Eids={x['id'] for x in E['events']};Nids={x['candidate_id'] for x in N['candidates']}
next_s=max(int(x.replace('BS','')) for x in Sids if x.startswith('BS'))+1
next_n=max(int(x.replace('AB-NEW-','')) for x in Nids if x.startswith('AB-NEW-'))+1
cases=[]
def src(key, institution,title,url,level='journal_full_html_read',archive=None,notes=''):
 global next_s
 id=f'BS{next_s}';next_s+=1
 S['sources'].append(dict(id=id,institution=institution,title=title,url=url,reading_level=level,archive_identifier=archive,notes=notes,original_manuscript_personally_inspected=False,consulted_on='2026-11-08'))
 return id
srcs={}
srcs['awadh']=src('','Cambridge University Press / Modern Asian Studies','It all comes from me: Bahu Begam and making of the Awadh nawabi','https://www.cambridge.org/core/journals/modern-asian-studies/article/it-all-comes-from-me-bahu-begam-and-the-making-of-the-awadh-nawabi-circa-17651815/D7AEE97EA7821335A01B32B82AAB3FB0')
srcs['awadhBL']=src('','British Library / India Office','Warren Hastings papers, Part I regarding Oudh Begams','https://searcharchives.bl.uk/?f%5Bcollection_area_ssi%5D%5B%5D=India+Office+Records+and+Private+Papers&f%5Blanguage_ssim%5D%5B%5D=English&f%5Broot_ancestor_reference_ssi%5D%5B%5D=IOR%2FL%2FPARL&page=2&per_page=50&sort=date','archive_catalogue_read','IOR/L/PARL/2/347','1786–1787 exhibit compilation, actual folios not read')
srcs['andaman']=src('','Cambridge University Press / Comparative Studies in Society and History','Developing Terra Nullius: Colonialism, Nationalism, Indigeneity in Andaman Islands','https://www.cambridge.org/core/journals/comparative-studies-in-society-and-history/article/developing-terra-nullius-colonialism-nationalism-and-indigeneity-in-the-andaman-islands/8F0B5F996A88F1DB8E8B5D7B54AD8E8F')
srcs['assam']=src('','Cambridge University Press','Geographical Exploration and Historical Investigation: John Peter Wade in Assam','https://www.cambridge.org/core/books/abs/landscape-culture-and-belonging/geographical-exploration-and-historical-investigation-john-peter-wade-in-assam/FD71BBD7370CA6C116FBCE04A20ACACF','scholarly_chapter_summary_read')
srcs['surat']=src('','Cambridge / Journal of Royal Asiatic Society','The British Monopoly on Surat Trade to the Middle East and Indian shipowners struggle 1759–1800','https://www.cambridge.org/core/journals/journal-of-the-royal-asiatic-society/article/abs/british-monopoly-on-the-surat-trade-to-the-middle-east-and-the-indian-shipowning-merchants-struggle-against-it-17591800/ED95E21E566D5BD586BC830431D79449','journal_html_abstract_and_notes_read')
srcs['surat2']=src('','Cambridge / Modern Asian Studies','Mughal Nobles, Indian Merchants and Beginning of British Conquest: Surat 1756–59','https://www.cambridge.org/core/journals/modern-asian-studies/article/abs/mughal-nobles-indian-merchants-and-the-beginning-of-british-conquest-in-western-india-the-case-of-surat-17561759/AAA9C1720689652875326A6380922029','journal_abstract_read')
srcs['suratBL']=src('','British Library / India Office','Factory records Surat: revenue report of 5 November 1759','https://searcharchives.bl.uk/?f%5Bcollection_area_ssi%5D%5B%5D=India+Office+Records+and+Private+Papers&f%5Bmaterial_type_si%5D%5B%5D=Archives+and+Manuscripts&f%5Bproject_collections_ssim%5D%5B%5D=India+Office+Records&f%5Burl_non_blank_si%5D%5B%5D=Yes+%28available%29&page=10&per_page=100&sort=date','archive_catalogue_read','IOR/G/36/119','1759 castle/tanka revenues report, not primary folio read')
srcs['broach']=src('','British Library / India Office','Factory records Broach: EIC district 1772–1783 and handover to Scindia','https://searcharchives.bl.uk/catalog/036-000173372','archive_catalogue_read','IOR/G/5','A district, not modern all-Gujarat jurisdiction')
srcs['broach2']=src('','SAGE / South Asia Research','Town Revenues and Taxes in Eighteenth-Century Gujarat','https://journals.sagepub.com/doi/10.1177/0262728003232004','journal_abstract_read')
srcs['rebellions']=src('','SAGE / Indian Historical Review','Revisiting the Early Anti-colonial Rebellions in Bengal and Odisha, 1760–1856','https://journals.sagepub.com/doi/10.1177/03769836221105972','journal_abstract_read')
srcs['chuar']=src('','University of California Press / Ethnic Studies Review','Tribal-led Peoples Resistance in Transition 1765–1800','https://online.ucpress.edu/esr/article-abstract/36/1/127/34172/Tribal-led-People-s-Resistance-in-Transition-1765','journal_abstract_read')
srcs['ceylon']=src('','Taylor & Francis / South Asia','Many Little Revolts or One Rebellion? Ceylon maritime provinces 1796–1800','https://www.tandfonline.com/doi/abs/10.1080/00856400903049465?needAccess=true','journal_abstract_read')
srcs['calabar']=src('','Oxford University Press / James H. Sweet','Mutiny on the Black Prince Chapter 4: Old Calabar','https://academic.oup.com/book/58166/chapter-abstract/485239549','book_chapter_abstract_read')
srcs['calabar2']=src('','Cambridge / Royal Historical Society','Cultures of Exchange: Atlantic Africa in Era of Slave Trade','https://www.cambridge.org/core/journals/transactions-of-the-royal-historical-society/article/abs/cultures-of-exchange-atlantic-africa-in-the-era-of-the-slave-trade/CCB6F191757555706151856EC26C4287','journal_html_notes_read')
srcs['hanno']=src('','Cambridge / History in Africa','African Merchants, Notables, Slave Trade at Old Calabar, 1720: Scottish Archives','https://www.cambridge.org/core/journals/history-in-africa/article/abs/african-merchants-notables-and-the-slave-trade-at-old-calabar-1720-evidence-from-the-national-archives-of-scotland/4260269CC4899A46AC1E0DA57BA6F7A0','journal_extract_read','National Archives Scotland (secondary cited, shelfmark unresolved)','ship Hannover, purchase stages 21,22,75 distinct')
srcs['dahomey']=src('','Cambridge / Robin Law','Ouidah, chapter The Dahomian Conquest of Ouidah','https://www.cambridge.org/core/books/abs/ouidah/dahomian-conquest-of-ouidah/56386651A8A853276C32FFDE9920427B','book_chapter_summary_read')
srcs['dahomey2']=src('','Cambridge / Robin Law','Ouidah, chapter The Operation of Atlantic Slave Trade','https://www.cambridge.org/core/books/abs/ouidah/operation-of-the-atlantic-slave-trade/8C586FD8A07B0E31C6AFF7BBFE8BE677','book_chapter_summary_read')
srcs['mysore']=src('','University of California Press','Dialogue and History: The Battle of Pullalur and the Naturalization of the British','https://publishing.cdlib.org/ucpressebooks/public/book/dialogue-and-history-constructing-south-india-1795-1895.html','scholarly_full_html_read')
srcs['pollilurRCT']=src('','Royal Collection Trust','Original military map of Second Battle of Pollilur (1781) RCIN 734067','https://militarymaps.rct.uk/other-18th/19th-century-conflicts/map-of-the-battle-of-pollilur-1781-pollilur-near-kanchipuram-tamil-nadu-india-12deg5000n-79deg4300e','museum_map_catalogue_and_transcription_read','RCIN 734067','1781 second battle not 1780 first defeat')
srcs['treaty']=src('','British Library','Journal of Commissioners negotiating Mangalore Peace Treaty, Add MS 39857–39858','https://searcharchives.bl.uk/catalog/032-002059709','archive_catalogue_read','Add MS 39857–39858, f.315b','11 Mar 1784 treaty date supported, original ms unexamined')
srcs['famine']=src('','Oxford University Press','Naturalizing Famine: Doji bara Famine and Madras 1789–94','https://academic.oup.com/book/61892/chapter/548192041','scholarly_chapter_excerpt_read')
srcs['rajshahi']=src('','Rajshahi College / Journal of Social Science','Fakir-Sannyasi Movement in Rajshahi; revenue assessed and collected 1769–72','https://rc.gov.bd/jss/fakir-sannyasi-movement-in-rajshahi-regional-study-of-a-pioneer-peasant-resistance-in-colonial-bengal/','secondary_research_full_html_read','Firminger and Mahmood cited indirectly','Different district tax series vs wider Bengal; local data not primary ledgers')
srcs['balance']=src('','Elsevier / Explorations in Economic History','India Contribution to British Balance of Payments 1757–1812','https://www.sciencedirect.com/science/article/pii/S0014498305000859','journal_article_excerpt_read')
srcs['weavers']=src('','Cambridge University Press / Om Prakash','From Negotiation to Coercion: Textile Manufacturing in India in Eighteenth Century','https://www.cambridge.org/core/journals/modern-asian-studies/article/abs/from-negotiation-to-coercion-textile-manufacturing-in-india-in-the-eighteenth-century/9ECA84ADA531FC112E225221E773267D','journal_abstract_read')
srcs['cape']=src('','Stellenbosch University / Scientia Militaria','The Third War of Dispossession 1799–1803','https://scientiamilitaria.journals.ac.za/pub/article/view/1094','journal_abstract_read')

def case(title,anchor,rationale,source_keys,events,notes,affects,need_more=''):
 global next_n
 id=f'AB-NEW-{next_n:03d}';next_n+=1
 rec=dict(candidate_id=id,title=title,related_original_topic_id=anchor,rationale=rationale,source_ids=[srcs[k] for k in source_keys],decision='propose_to_editor',publication_status='research_only',coverage_expansion_round=6)
 N['candidates'].append(rec)
 for i,info in enumerate(events,1):
  year,precision,subj,actors,place,action,sem=info[:7]
  extra=info[7] if len(info)>7 else {}
  ev=dict(id=f'AB-R6-{id[-3:]}-{i:02d}',topic_ids=[id,anchor],year=year,month=extra.get('month'),day=extra.get('day'),date_precision=precision,title=subj,actors=actors,location=place,action=action,political_effect=sem,source_ids=rec['source_ids'],source_urls=[next(s['url'] for s in S['sources'] if s['id']==srcs[k]) for k in source_keys],research_status='candidate_not_published',map_state='named_place_with_coordinates_pending_official_reference',geometry_id=None,confidence=extra.get('confidence','sourced_scholarly_or_archive_context'),historical_control_boundary_verified=False,actual_British_control_area_sqkm=None)
  if 'year_window' in extra: ev['year_window']=extra['year_window']
  assert ev['id'] not in Eids
  E['events'].append(ev)
 cases.append(dict(id=id,title=title,anchor=anchor,source_keys=source_keys,events=events,notes=notes,affects=affects,need_more=need_more))
 return id

case('1781—1783阿瓦德王室女性土地与宫廷金库剥夺','E18-B18','阿瓦德王室女性自身的土地权、宫廷财产权及公司的军政施压机制，在既有贝拿勒斯专题之外需要独立叙述',['awadh','awadhBL'],[
 (1775,'year','阿瓦德Bahu Begam财产保证与公司承诺关系','Bahu Begam; Asaf-ud-Daula; EIC','Faizabad / Awadh','1775年保证关系是后来公司强制干预时被争辩的权利基础；保证条款与王室内部继承需另读原件。','treaty_guarantee_disputed_not_territorial_rule'),
 (1781,'year','贝拿勒斯反抗后Hastings要求剥夺Begams世袭收入','Warren Hastings; Asaf-ud-Daula; Bahu Begam; Sadr-un-Nissa Begam','Awadh / Faizabad','公司官员认为Begams支持反抗，要求阿瓦德纳瓦卜收回其jagir并取得争议财库，所称支持程度与涉事者说法有争议。','extraction_order_over_local_jagir_revenue'),
 (1782,'year','公司驻扎与纳瓦卜部队包围法扎巴德宫殿','EIC Resident; Asaf-ud-Daula; Bahu Begam','Faizabad','1782年1月纳瓦卜征收人员进入Begam的jagir，公司驻扎部队协同包围宫殿，驻城一年以上。','military_pressure_not_royal_annexation',{'month':1}),
 (1782,'year','法扎巴德宫廷高级宦官被拘押并被迫交出资金','Awadh palace eunuch officials; EIC forces; Nawab','Faizabad','有高级宦官遭拘押直至交出可观现金；需要逐笔查收款与最终入公司账，尚不把财物一概记为英国净受益。','detention_and_exaction_not_accounted_profit')],
 'Cambridge 2022/2023 Modern Asian Studies全文基于波斯文当地材料及公司文书重新解释财库究竟属王室私人财产、纳瓦卜国库还是公司债务抵押。不能因为Hastings的指控便宣布Begams确证支持起义。',
 '阿瓦德王室女性及宫廷官员；征税债务与东印度公司对附属盟友的预算控制',
 'IOR/L/PARL/2/347全文及当时收到款项单、所谓55 lakh数值须回账本；绝不可将强制支出自动等同汇英国。')
case('1789—1796安达曼流放殖民地与原住民领土压迫','E18-E11','印度洋岛屿的东印度公司小型据点、清林和土地边界暴力，不能被现代安达曼岛全境英属区域替代',['andaman'],[
 (1789,'year','公司在南安达曼Chatham岛开设流放殖民据点','Archibald Blair; EIC convicts; Andamanese peoples','Chatham Island / Phoenix Bay, South Andaman','1789年公司建立港口与监禁殖民据点并清理Chatham岛及Phoenix Bay相邻林地。','convict_settlement_and_local_land_displacement'),
 (1791,'year','安达曼殖民当局筑路形成武装压迫的边界','EIC garrison; indigenous Andaman peoples','Phoenix Bay / South Andaman','研究记道路及火枪、舰炮约束形成单方强加的定居区界线，路址与确切年份需要历史工程图，不可绘历史边界。','militarised_frontier_not_precise_line',{'confidence':'phase_circa_1789_1792','year_window':'1789–1792'}),
 (None,'range_only','东印度公司将安达曼殖民据点迁往Port Cornwallis','Archibald Blair; EIC','Port Cornwallis, North Andaman','研究描述1792–1793间移至Port Cornwallis，具体月份与名称沿革须核对原日记。','outpost_relocation',{'year_window':'1792–1793','confidence':'date_dispute_1792_1793'}),
 (1796,'year','东印度公司放弃早期安达曼殖民驻点','East India Company; settlers and prisoners','Port Cornwallis / Andaman Islands','由于健康条件和港口战略效用变化，殖民据点1796年撤弃；不能从1789据点延长整个19世纪的驻军控制。','settlement_withdrawal')],
 'Cambridge同行评审全文记载道路被单方用作权利边界，证据来源为Blair殖民材料；必须区别长期原住民岛屿主权与公司短暂占据的局部清林。',
 '安达曼原住民土地、被流放囚犯和英印海军后勤','Chatham岛与Phoenix Bay局部地籍、1789–1796囚犯名单、具体道路测绘图和死亡资料。')
case('1792—1794阿萨姆Ahom王国求援、公司军事干预与军事测绘','E18-B21','弥补地图把阿萨姆到1824年才出现的英国军事接触从18世纪全部漏掉的问题',['assam'],[
 (1792,'year','Ahom王Gaurinath Singha请求公司镇压境内叛乱','Ahom king Gaurinath Singha; Moamoria rebels; EIC','Ahom Kingdom / Assam','地方统治者面临Moamoria等反抗与武装集团冲突而请求英印军队援助，不能称英王征服阿萨姆。','indigenous_kingdom_alliance_not_annexation'),
 (1792,'year','Captain Welsh出兵阿萨姆、行动集中在Guwahati','Captain Thomas Welsh; EIC sepoys; Ahom court','Guwahati, Assam','公司军队进入Ahom王国并参与恢复王权军事行动，局部部署不等于整个阿萨姆英公司行政领地。','temporary_military_intervention'),
 (1794,'year','公司以军政调查形式记录阿萨姆政权与地理','Captain Welsh; Ensign Wood; EIC Calcutta','Assam / Guwahati','1794年的询问书与测绘记录要求解释国王、诸首领权力结构；文件用于未来商贸与军事情报。','colonial_intelligence_survey_not_sovereignty')],
 '剑桥书章摘录可读，原1792–1794书信/测绘未亲阅。Moamoria为本地政治主体；有王室请求不意味着所有地方团体同意英军干预。',
 'Ahom王廷、Moamoria反抗者、Guwahati居民、Bengal–Assam沿线贸易',
 'Captain Welsh原始日记及公司指令、临时营地地点和实际撤军日期；不把1794作为经证撤兵年。')
case('1759—1800苏拉特城堡夺取与英国商船保护勒索','E18-B01','西印度沿岸1759年另一条大型财权与军政扩张线，现有B系列专题易将之漏为贸易点',['surat','surat2','suratBL'],[
 (1759,'year','东印度公司武装取得苏拉特城堡长官职权','EIC Surat factory; Surat castle governor; city Nawab','Surat Castle / Surat','1759年军事行动针对城堡控制者，公司工厂首席继承城堡长官权力；城市Nawab和穆斯林/印度商人权利分属其他法权。','castle_office_not_whole_city_annexation'),
 (1759,'year','苏拉特堡垒税收报表编成','EIC Surat officials; local merchants','Surat Castle and Tanka','1759年11月5日Erskine关于城堡和Tanka收入报告现可在IOR/G/36/119目录定位；档案目录未提供实际数额。','revenue_document_archive_lead',{'month':11,'day':5}),
 (None,'multi_decade','公司官员对苏拉特—波斯湾海上贸易设保护与垄断条件','EIC officials; Indian ship-owning merchants','Surat to Arabian/Persian Gulf ports','1759—1800间对印度商船主实施保护费及贸易限制，印度船东持续抗争；海运关系非公司控制海面领土。','maritime_exaction_not_sovereignty',{'year_window':'1759–1800'} )],
 '专题论文注释明确：至1800年苏拉特多数居民仍被视为莫卧儿臣民。1759城堡职权不可改写为全部城市的“英国直接统治”，城堡控制也不同于马拉塔分成权利。',
 '苏拉特印度航运商、城堡办公人员、莫卧儿名义臣民及马拉塔税权争议',
 'Surat Castle和Tanka的同期财税实数及商人向公司的诉状。')
case('1772—1783布罗奇/Broach城区征税及马拉塔交割','E18-B11','补足西印度公司真实行政区由1772取得至1783交割的明确终止区间',['broach','broach2'],[
 (1772,'year','东印度公司取得Broach地区行政与税权','EIC Bombay; Nawab of Broach; local residents','Broach / Bharuch, Gujarat','1772年布罗奇由公司军政控制，公司档案IOR/G/5收1772–1783的地区管理；边界尚待实测档图。','district_administration_not_gujarat_annexation'),
 (1773,'year','Broach税官编录城市细目税及收入','EIC revenue officials; Bharuch town residents','Bharuch','1773年当时公司文书记录多种市镇税及实际征收，研究已分析其潜在加重的负担；未直接读取文书细目。','company_micro_taxation'),
 (1783,'year','公司将Broach地区移交马拉塔Scindia','EIC; Mahadji Scindia / Maratha polity','Broach / Bharuch','英国图书馆官档说明1783年交予Scindia，不能把1772控制延续为1784–1799持续公司实占。','territory_transferred_to_maratha')],
 'IOR/G/5同时记录1803重新取得，但本研究严格截至1799。马拉塔辛迪亚不是英国王室下属行政机构。',
 'Broach居民、纳瓦卜、Scindia马拉塔的财政权与贸易',
 '1772战事签字文件与1783实际行政交割日、历史布罗奇边界地图和税率原件。')
case('1760—1799孟加拉Sannyasi、Fakir与Jungle Mahals地方反抗','E18-B16','长期收税变革伴随不同宗教与族群行动者反抗，必须记地方主体与地权诉求而非泛称土匪',['rebellions','chuar','rajshahi'],[
 (None,'range_only','Sannyasi与Fakir团体反抗税权、土地剥夺和公司统治','Sannyasi; Fakir; peasants; EIC revenue officials','North Bengal / Rajshahi / Bengal','1760年代至18世纪后期多处发生异质的宗教、农民及地方领导者反抗，不能虚构统一起义军和单一战线。','regional_resistance_multiple_groups',{'year_window':'1760s–1790s'}),
 (1769,'financial_year','Rajshahi地主地税核定与实际收款不一致','Rajshahi zamindari; tenants; EIC revenue officials','Rajshahi / Bengal','1769–1770财政年核定2,601,000卢比、实际征得2,438,342卢比，来源为后世地方史研究，需向Firminger原表核查。','district_revenue_assessment_vs_receipts'),
 (1770,'financial_year','Rajshahi饥荒期地税核定高于实际收款','Rajshahi zamindari; EIC tax collectors; Bengal residents','Rajshahi','1770–1771核定2,676,000卢比、实际征得2,146,247卢比；该数据仅属Rajshahi地区，勿与全孟加拉合计。','district_tax_after_crop_shock'),
 (1799,'year','Midnapore Jungle Mahals地方武装发动大规模地权反抗','Adivasi communities; sirdars; paiks; ryots; EIC officials','Jungle Mahals / Midnapore','史学论文叙述被收回jagir用地的Adivasi、paik与农民1799年反抗，殖民档习惯称Chuar rebellion；名称含殖民歧视性，不可当客观族称。','land_rights_resistance_not_unified_enemy')],
 '区分教团性行动、贫农抗租、地方酋长保地和殖民官称“Chuar”的群体；不存在可描满贝尔地区的统一英军占领面。',
 'Bengal/Bihar/Odisha土地与农户财政权、反抗者本地自主行动',
 'Sannyasi/Fakir每次袭击的同期日记、Rajshahi各年度税款原簿及Jungle Mahals地契。')
case('1796—1800锡兰海岸税制和地方权威改变后的反抗','E18-E05','前期仅有荷属堡垒移交，缺少英国征税制度变化所触发的持续民众反抗与军镇压链',['ceylon'],[
 (1796,'year','公司统治锡兰荷属旧海岸地区后撤换地方官员','EIC Madras administration; mudaliyars; amildars; coastal villagers','Ceylon maritime provinces','当地头人原有申诉中介地位被征税承包人或新官员削弱，村庄申诉途径受损，抗议不能全归一项椰园税。','local_governance_replacement'),
 (1797,'year','锡兰海岸多个地区发生反对新财政与行政的抗议','Ceylonese coastal residents; EIC revenue contractors and troops','Sri Lankan maritime districts','1796–1800发生多次和平与暴力抗议，1797年为重要节点；地点须逐份请愿或军报核，不假定全岛联合起义。','revolts_against_company_revenue_system',{'year_window':'1796–1800'}),
 (None,'range_only','锡兰英国军事反抗镇压与持续请愿','EIC soldiers; coastal villagers; local officials','Maritime Ceylon','研究指出镇压手段有时严酷，但各地有不同动机和抗议形式；在1799年前不能虚构所有村落的具体战役。','repression_and_petitions_localized',{'year_window':'1796–1800'})],
 '论文挑战将不同抗议解释为一场单因椰园税起义的史叙。Kandyan Kingdom持续独立，海岸公司税政不是康提国王被吞并。',
 '海岸村落、头人阶层、征税承包人和抗争居民',
 '逐县请愿编号/军报、1797–98岁入税款及康提界线档图。')
case('1767英国贩奴船长参与Old Calabar大屠杀与强制流放','E18-E10','英国贩奴航次直接介入非洲地方政治暴力、奴役当地商人，这是单一可证重大暴行',['calabar','calabar2'],[
 (1767,'year','英国贩奴船长与Duke Town一方合谋伏击Old Town','British slave-ship captains; Duke Town and Creek Town allies; Old Town traders','Old Calabar / Calabar River, present-day Nigeria','参与者以调解贸易冲突为名把Old Town商人诱至船上，并与对方地方派系配合发动攻击。','shipboard_coordinated_local_massacre'),
 (1767,'year','Old Calabar伏击造成300人以上遇害与被奴役','Old Town victims; British sailors; local allies','Old Calabar River','牛津2024年学术章节记被杀逾300人，另有人被英船运往美洲沦为奴役者；不能把死亡估计与奴役人数混算。','lethal_violence_and_forced_atlantic_deportation'),
 (None,'range_only','Old Calabar屠杀后地方政治冲突继续','Old Town residents; Duke Town; British slavers','Old Calabar','剑桥研究记1767年伏击严重破坏当地商贸信任，双方冲突之后数年仍未立即终结。','long_term_conflict_no_British_land_annexation',{'year_window':'1767–1770s'})],
 'Old Town、Duke Town、Creek Town为不同地方势力；英国船长与一派结盟并未取得尼日利亚领土主权。历史估算300+是参与者/历史研究人数而非可定位现场的GPS，须保留确切死亡名单缺失。',
 'Old Town受害商人及家属，后被运往美洲的非洲自由人；Calabar政治结构',
 '1767涉案具体船名和船长、运输人口在Slave Voyages的个案交叉、1767同期原证词。')
case('1719—1720苏格兰贩奴船Hannover航次的非洲采购链','E18-E10','补全英苏统一后苏格兰私营商人从Windward、黄金海岸到Old Calabar多点采购的可量化航次',['hanno'],[
 (1719,'year','Port Glasgow船Hannover起航贩奴航次','Shipowner Robert Bogle Jr; Alexander Horsburgh; crew','Port Glasgow to West Africa','1719年末Hannover出航，后由外科医生Horsburgh主持购买被奴役者和补给品，不能把航次数当实际到岸奴役人数。','ship_voyage_not_maritime_territorial_rule'),
 (1720,'year','Hannover于Windward Coast购买21名被奴役者','Horsburgh; local traders; enslaved Africans','Windward Coast (specific shore not fixed)','1720年3月购买21名被奴役者与粮食，确切购买点未核。','documented_captive_purchase'),
 (1720,'year','Hannover于黄金海岸购买22名被奴役者','Horsburgh; local traders; enslaved Africans','Gold Coast','1720年4月5日至5月2日购买22名被奴役者，另采粮食；原航迹不能由海岸点连直线代替。','documented_captive_purchase',{'month':4}),
 (1720,'year','Hannover于Old Calabar购买75名被奴役者','Horsburgh; Old Calabar merchants; enslaved Africans','Old Calabar','1720年5月下旬至7月上旬购买75名被奴役者；该数仅为本港购买人数，不是死亡或抵岸人数。','documented_captive_purchase',{'month':5})],
 '三个地点已分别收21/22/75人；同一航次共可重算118名采购人口，未经船舱存活和美洲抵港名单不能称118名实际到岸。注意1719英苏已经联合王国。',
 '被奴役非洲人、Scottish私人商人和船员、多处非洲自主港市',
 'Horsburgh原航次日志的苏格兰档案shelfmark、具体抵岸人数与船上死亡、原海上日志行程。')
case('1727达荷美国王Agaja夺取Ouidah后英商堡贸易与当地权力','E18-E10','非洲奴役贸易最重要港市之一由非洲王国重新配置政治权力，不应把英商堡垒等同英国主权',['dahomey','dahomey2'],[
 (1727,'year','达荷美王Agaja军队征服Hueda/Ouidah','King Agaja; Dahomean army; Hueda authorities; English traders','Ouidah / Hueda (present-day Benin)','1727年3月达荷美攻占原Hueda区域，英法葡商堡随后在达荷美王权和港务规则下经营。','african_polity_conquest_not_British_occupation',{'month':3}),
 (1755,'year','达荷美国王Tegbesu要求英法商堡确保港口和平','King Tegbesu; English, French and Portuguese fort directors','Ouidah','1755年达荷美国王要求不同欧洲商堡尊重港内和平通行，反映本地对港口贸易的管治权。','african_sovereignty_over_european_forts'),
 (1762,'year','英国船射击法国堡补给船后达荷美王公开抗议','British vessel; French fort suppliers; King Tegbesu','Ouidah coastal anchorage','达荷美王抗议英国船向法国据点供给独木舟开火，明确要求欧洲商船遵守其港口秩序。','local_royal_regulation_of_armed_trade')],
 '1727是Dahomey对Hueda的征服，不是英国进攻；英国在此的殖民经济活动主要是强迫人口贩运和港市堡垒贸易。1690s英国实际堡址及1790退出时间仍未核。',
 'Hueda和达荷美国王、商人与被奴役人口，英法葡欧洲贸易据点',
 '具体英国堡名称及1755/1762原通信，1767之后英船人口奴役航次个案。')
case('1780年第一场Pollilur战役与1781年不同结局之对照','E18-B13','1780迈索尔一役造成公司军重大损失，但Royal Collection 1781第二战史图容易误绑到同年',['mysore','pollilurRCT'],[
 (1780,'day','Hyder Ali与Tipu军在Pollilur击败Baillie公司军','Hyder Ali; Tipu Sultan; Colonel John Baillie; EIC sepoys','Pollilur / Pullalur near Kanchipuram','1780年9月10日迈索尔军击败公司Baillie纵队，大量军官伤亡或被俘；这场胜利不是1781第二场同名战役。','company_military_defeat_not_British_acquisition',{'month':9,'day':10}),
 (1781,'day','Pollilur第二战由公司将领Coote击败迈索尔军','Eyre Coote; Hyder Ali forces','Pollilur near Kanchipuram','Royal Collection原军图标注1781年8月27日英军战胜Hyder Ali军；两战时间、胜败不同，地图需双事件。','company_military_victory_no_auto_annexation',{'month':8,'day':27})],
 'Royal Collection RCIN 734067展示的是1781胜利，绝不能用于证明1780英军败退的实际战线；当代军人绘图不等于整个Kanchipuram区域被英国实占。',
 '迈索尔独立政权与公司印度兵、英军战俘、Kanchipuram附近居民',
 '1780双方战报、战俘名单及战场遗址对应；军图坐标为现代城镇参照。')
case('1789—1794印度南部Doji bara与北Circar饥荒、战争及征税','E18-B07','补充1770 Bengal外第二场影响广泛的大饥荒，避免把印度气候与军事政策影响混为单因',['famine'],[
 (None,'range_only','1789—1794印度多区域干旱与粮食危机','Indian cultivators; zamindars; EIC Madras officers','Northern Circars and south India','1789—1794间不同地区遭遇多轮旱灾/饥荒，战争前置破坏与粮食征集、市场运输相互作用，不能制造全印度死亡总数。','multi_region_famine_no_surveyed_boundary',{'year_window':'1789–1794'}),
 (1792,'year','北部Circars地方报告农民因饥饿食用未成熟庄稼','local zamindars; labourers; EIC Madras Presidency','Northern Circars','当时的地方地主报告田间劳动力在成熟前食用作物，牲畜也被杀来充饥；资料是地方官和地主自述而非全区精确户数。','crop_failure_and_household_distress'),
 (1792,'year','Madras行政人员提出公共开支供养受灾儿童','Acting governor Oakeley; district officials; children','Madras Presidency','担心父母售卖子女，Oakeley指示地方官员以公共资金供养儿童；资金拨付与执行仍待账目确认。','famine_child_relief_instruction_not_verified_payment')],
 '1770 Bengal与1790年代Doji bara不同，不能直接比较规模或叠加死亡。需要区分气候干旱、粮价机制、运输成本及公司决策。',
 'Madras和Northern Circars农户、儿童、地方行政与种粮经济',
 '1790–94各地人口/粮价/地税/救助经费的同口径原档与战争损失。')

# Save source, candidate, event files now (batch 1 checkpoint) before more research
S['source_count']=len(S['sources']);
for name,obj in [('SOURCE_REGISTRY.json',S),('NEW_CANDIDATES.json',N),('EVENT_CANDIDATES.json',E)]:
 (ROOT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
# Per-case dossier initial batch; later data append
outdir=ROOT/'TOPIC_DOSSIERS'/'NEW_CANDIDATES';outdir.mkdir(parents=True,exist_ok=True)
for c in cases:
 a=[f'# {c["id"]}｜{c["title"]}','', '> 研究阶段 research_only。此次新增候选，未经主编出版审核；不构造未经证实的控制面。','',f'**原项目关联母题**：`{c["anchor"]}`','', '## 新增原因及主要发现', '',c['notes'],'',f'**受影响群体/利益**：{c["affects"]}','','## 有据史事 / 地图语义','']
 for i,e in enumerate(c['events'],1):
  yr,prec,tit,actors,loc,action,sem=e[:7];extra=e[7] if len(e)>7 else {}
  a+= [f'### AB-R6-{c["id"][-3:]}-{i:02d}｜{yr if yr else extra.get("year_window", "年份待核")}｜{tit}', '',f'- 地方与主体：{loc}；{actors}',f'- 史实：{action}',f'- 控制语义：`{sem}`；不据此生成英国领土面积。',f'- 日期精度：`{prec}`；日期补充：{extra or "无"}','']
 a+=['## 资料来源与实际阅读层级','']
 for k in c['source_keys']:
  s=next(y for y in S['sources'] if y['id']==srcs[k]);a += [f'- [{s["id"]}]({s["url"]}) {s["title"]}；机构：{s["institution"]}；阅读级别：`{s["reading_level"]}`；原始手稿亲阅：否；档案编号：{s.get("archive_identifier") or "无"}。']
 a+=['','## 尚待攻克','',c['need_more'],'','## 地图纪律','', '所有地点均为具名文本参考，尚未匹配正式权威参考坐标；该专题不可自动生成实控Polygon、军事行动缓冲圆面积、历史海运精确路线或现代行政区。','']
 (outdir/(c['id']+'.md')).write_text('\n'.join(a))
# save first batch checkpoint
checkpoint=dict(round=6,batch=1,created='2026-11-08',source_count=len(S['sources']),event_count=len(E['events']),new_candidate_count=len(N['candidates']),dossiers_added=[c['id'] for c in cases],new_source_ids=list(srcs.values()))
(ROOT/'WORKING'/'SIXTH_ROUND_BATCH1_CHECKPOINT.json').write_text(json.dumps(checkpoint,ensure_ascii=False,indent=2)+'\n')
print('CHECKPOINT',checkpoint)
