#!/usr/bin/env python3
"""Research-only follow-up: Sabah Balambangan, Kedah/Penang treaty law, and local-led Maltese siege.
Read levels recorded accurately. Incremental/idempotent, preserves old evidence; never touches GitHub.
"""
from pathlib import Path
import csv,json
P=Path('/mnt/data/18c_assistant_B'); W=P/'WORKING';T=P/'TOPIC_DOSSIERS'
URL={
 'BS142':'https://www.cambridge.org/core/journals/urban-history/article/before-the-port-city-coastal-settlements-and-colonialism-in-borneo/25B301620F838F25444FA7C2C315BF88',
 'BS143':'https://searcharchives.bl.uk/catalog/041-000173313',
 'BS144':'https://ris.cdu.edu.au/ws/portalfiles/portal/44135311/Thesis_CDU_Herivel_J.pdf',
 'BS145':'https://www.um.edu.mt/library/oar/bitstream/123456789/24090/1/Maltese%20Political%20Development.pdf',
 'BS146':'https://www.um.edu.mt/library/oar/handle/123456789/121918',
 'BS147':'https://law.nus.edu.sg/sjls/wp-content/uploads/sites/14/2024/07/568-1969-11-mal-jul-1.pdf',
 'BS148':'https://www.sabrizain.org/malaya/library/jmbras/jmbrasvol03-2.pdf',
 'BS149':'https://penangport.gov.my/en/contact-us/public/port-history',
}
sourceentries=[
 ('BS142','Cambridge University Press / Urban History','Before the port city: coastal settlements and colonialism in Borneo','peer_reviewed_article_full_text_read','1773 Balambangan station; local Tausug/Maguindanao commerce, opium+arms, Datu Teteng razing in Feb1775, historian-estimated EIC loss GBP170,000; 1803 reoccupation is OUTSIDE scope',None),
 ('BS143','British Library / India Office Records','IOR/G/4/1 ff.7–61: Examiner’s Office Collection 274','archive_catalogue_only','Specific folios: 1771 Jun 12 Britannia instructions ff.14–16, 1773 Nov 19 f.16–17; draft opium-for-tea proposal ff.29–33 and Nov 1773 rough cash f.34; archival originals NOT read','IOR/G/4/1 ff.7-61'),
 ('BS144','Charles Darwin University','Jan-maree Herivel (2020), A Perfect Malay: James Scott, East Indies Country Trader, PhD dissertation','academic_thesis_pdf_extracted_text_read','p117 gives 26 Feb 1775 local Datu Teteng attack and credit/house construction/slave collateral dispute; relied on Warren Sulu Zone; original correspondence NOT inspected',None),
 ('BS145','University of Malta / Henry Frendo (ed., 1993)','Maltese Political Development 1798–1964, part I documents 1–10','published_contemporary_document_transcriptions_web_pdf_text_read','June 1798 French capitulation and Sept 1798 uprising, 7 Feb 1799 Maltese congress petition, 19 Feb Sicilian minister approval, 23 Feb 1799 letters to Hamilton and Nelson. Original 1798–99 papers NOT inspected; web PDF screenshot failed file-size gate.',None),
 ('BS146','University of Malta / Yosanne Vella (2022)','Once Upon a Time in 1798, 1799, 1800: Forgotten Stories from the French Period in Malta','academic_book_repository_abstract_only','University repository public abstract directly read; PDF access restricted; Maltese provisional government 2 Sept 1798, French confined to fortified cities, British blockade plus Neapolitan support; 1800 capitulation out of scope',None),
 ('BS147','National University of Singapore Faculty of Law / Malaya Law Review 1969','The East India Company and the Crown 1773–1858','academic_law_journal_pdf_extracted_text_read','1969 law study directly quotes/paraphrases 1 May 1791 Kedah-Penang treaty art.1 payment 6000 Spanish dollars/year, arts.2–8 treatment of fugitives including enslaved and insurgents, art.9 wording; questions legal cession not physical 1786 EIC occupancy; 18c treaty original NOT inspected',None),
 ('BS148','Royal Asiatic Society Malayan Branch (1925) / L. A. Mills','British Malaya 1824–1867, opening background chapters, JMBRAS 1925','1925_scholarly_printed_book_pdf_text_read','footnote reproduces 1786 Kedah request $30000/year; 1791 formal $6000/year, later reports actual $10000/year unapproved until 1800; 1925 retrospective text only, original receipts not examined',None),
 ('BS149','Penang Port Commission (Malaysia government)','Port History: Francis Light arrival and 1790–91 conflict','government_website_text_read','11 Aug 1786 occupation, 1790 Kedah defence mobilisation and 1791 peace/6000 dollar annual promise; government site simplification "cession" disputed by BS147; source is not original treaty',None),
]
sp=P/'SOURCE_REGISTRY.json';src=json.loads(sp.read_text()); known={s['id'] for s in src['sources']}
for sid,org,title,level,notes,archive in sourceentries:
 if sid not in known:
  src['sources'].append({'id':sid,'institution':org,'title':title,'url':URL[sid],'reading_level':level,'archive_identifier':archive,'notes':notes,'original_manuscript_personally_inspected':False,'consulted_on':'2026-11-08'})
src['source_count']=len(src['sources']);sp.write_text(json.dumps(src,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

newf=P/'NEW_CANDIDATES.json';new=json.loads(newf.read_text());nids={x['candidate_id'] for x in new['candidates']}
nmore=[
 ('AB-NEW-036','1760s—1775婆罗洲巴兰邦岸商业据点、对苏禄军火鸦片贸易与Datu Teteng反抗','E18-E11','据点建立、贸易、草拟账目和本地抵抗使1775年迅速撤离；不能把1760年代Sulu条约或短占外推为18世纪全沙巴英国领土。',['BS142','BS143','BS144']),
 ('AB-NEW-037','1786—1791槟城与吉打条约的年款、逃亡奴役者交还和法律管辖争议','E18-E03','1791文本约定货币补偿、贸易与跨境交还逃亡被奴役者、叛乱者，法律学术认为该条约没有明文正式主权割让，必须另列附约司法权。',['BS147','BS148','BS149']),
 ('AB-NEW-038','1798—1799马耳他反法地方起义与英国海军干预：Maltese Congress、两西西里和Nelson','E18-E12','新增非亚非海外对照案；相关原母题E12仅作其他海外军事政治史编目交叉索引，并非马尔维纳斯同一战争；反法起义由当地人发动，英国/西西里军协助封锁，1800年法国投降是19世纪。',['BS145','BS146']),
]
for nid,title,oid,rationale,sids in nmore:
 if nid not in nids:new['candidates'].append({'candidate_id':nid,'title':title,'related_original_topic_id':oid,'rationale':rationale,'source_ids':sids,'decision':'propose_to_editor'})
newf.write_text(json.dumps(new,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

p=P/'EVENT_CANDIDATES.json';ed=json.loads(p.read_text()); eids={x['id'] for x in ed['events']}
def event(eid,topics,date,title,actors,place,action,effect,sources,confidence='source_read_text_reviewed'):
 if eid in eids:return
 d=date.split('-'); ed['events'].append({'id':eid,'topic_ids':topics,'year':int(d[0]),'month':int(d[1]) if len(d)>1 else None,'day':int(d[2]) if len(d)>2 else None,'date_precision':'day' if len(d)==3 else 'month' if len(d)==2 else 'year', 'title':title,'actors':actors,'location':place,'action':action,'political_effect':effect,'source_ids':sources,'source_urls':[URL[x] for x in sources],'research_status':'candidate_not_published','map_state':'named_place_no_verified_coordinates','geometry_id':None,'confidence':confidence,'historical_control_boundary_verified':False,'actual_British_control_area_sqkm':None})
# Sabah/Sulu local agency and records
T36=['E18-E11','AB-NEW-036']
event('AB-NEW-036-001',T36,'1762','Dalrymple取得与苏禄苏丹国的巴兰邦岸岛使用／割让协议','Alexander Dalrymple; Sultanate of Sulu','Sulu; Balambangan Island','剑桥研究把一组苏禄条约概称1760年代初，1762仅为候审代表年，准确签署时间需核对原条约; 必须将条约签署与1773实际设站分开','negotiated_island_concession_date_unverified_not_effective_settlement',['BS142'],'early_1760s_window_reference_year_not_fixed_day')
event('AB-NEW-036-002',T36,'1771-06-12','东印度公司向巴兰邦岸下达设站命令','East India Company; ship Britannia; Company Council','Balambangan / Company offices','大英图书馆IOR/G/4/1 ff14–16编目列“12 June 1771 orders establishing a settlement”；仅查目录未读原指令；不证明当时已驻岛','company_instruction_not_territorial_possession',['BS143'],'archive_catalogue_only')
event('AB-NEW-036-003',T36,'1773','John Herbert在巴兰邦岸实际建立公司商站','John Herbert; East India Company; Sulu and Brunei rulers','Balambangan Island','英国公司人员进驻岛上经营贸易，以鸟巢、海参、贝壳交换鸦片和军火；当地苏禄／文莱政体保有地域政治自主','limited_factory_outpost_not_northern_borneo_sovereignty',['BS142'])
event('AB-NEW-036-004',T36,'1773-11','巴兰邦岸记录存在公司草账但金额需查原卷','EIC Balambangan Council','Balambangan Island','馆藏IOR/G/4/1 f.34 编目为1773年11月rough cash account；原账未读，不能自行生成财政数额','archive_cash_ledger_exists_value_unread',['BS143'],'archive_catalogue_only')
event('AB-NEW-036-005',T36,'1773-11-19','公司向巴兰邦岸发出贸易与组织指令','East India Company; Balambangan Council','Balambangan / London','IOR/G/4/1 ff16–17编目标注“Summary instructions ... 19 November 1773”；指令发出与收到或实施日期待核','company_directive_not_actual_executed_territorial_control',['BS143'],'archive_catalogue_only')
event('AB-NEW-036-006',['E18-E11','E18-B20','AB-NEW-036'],'1773','公司会议草案否决用鸦片等交换中国丝茶的提议','EIC committee; Balambangan agents; Sulu merchants; Chinese traders','Balambangan / Company correspondence','馆藏ff29–33显示否决向中国帆船提供鸦片、呢绒与棉织品以换茶与生丝的计划；该份未批准拟议交易不应登记为已经发生的商品运输','disapproved_opium_exchange_scheme_not_actual_trade',['BS143'],'archive_catalogue_only')
event('AB-NEW-036-007',T36,'1774-10-04','Dalrymple向公司反映巴兰邦岸译员与行政争端','Alexander Dalrymple; John Roberts; East India Company','Balambangan / EIC','IOR/G/4/1 ff23–25保存Dalrymple 1774年10月4日投诉John Roberts的函件目录，争议细节未读原件','company_internal_personnel_dispute',['BS143'],'archive_catalogue_only')
event('AB-NEW-036-008',T36,'1775-02-26','苏禄Datu Teteng率众摧毁巴兰邦岸公司据点','Datu Teteng; Tausug/Sulu attackers; John Herbert; EIC','Balambangan Island','公司官员Herbert在债务/奴役人口作抵押争端中曾公开羞辱当地贵族Datu Teteng；2月26日苏禄武装袭击并毁坏公司据点，幸存商人逃向Labuan等处；公司在岛上持续驻点至此终止','eic_factory_ended_after_local_resistance_not_british_land_sovereignty',['BS142','BS144'])
# Kedah-Penang; exact dated treaty printed secondary legal article, treaty not firsthand
event('AB-NEW-037-001',['E18-E02','AB-NEW-037'],'1786','吉打苏丹要求以每年三万西班牙元补偿槟城贸易垄断损失','Sultan Abdullah of Kedah; Francis Light; East India Company','Kedah; Penang','吉打苏丹1786书信提出每年30,000西班牙元并寻求防卫保护；此为原谈判要求，非公司已付金额或可合并赔款','local_ruler_requested_compensation_not_paid_cash',['BS148'])
event('AB-NEW-037-002',['E18-E02','E18-E03','AB-NEW-037'],'1791-05-01','吉打—槟城和约第1条确认公司占有条件与六千银元年款','Sultan Abdullah of Kedah; Francis Light; EIC','Kedah / Penang','公司同意在占有槟城期间每年支付6000西班牙银元；法学研究指出条文没有明文“主权割让”，需保留吉打与暹罗复杂关系','penang_physical_possession_and_annuity_not_undisputed_sovereignty_cession',['BS147','BS148','BS149'])
event('AB-NEW-037-003',['E18-E03','AB-NEW-037'],'1791-05-01','槟城和约含逃亡奴役者、造假者及叛乱者的跨辖区交还条款','Sultan Abdullah of Kedah; East India Company; fugitives','Penang; Kedah','1791年和约第2—8条涉及奴役者、叛乱者和伪造者逃到公司管辖区后的拘捕与交还；须回查原文逐款与具体执行案，不能把条款自动等同每一名逃亡者实际遣返','treaty_cross_border_fugitive_return_duties_not_verified_executions',['BS147'],'1969_law_scholar_summary_no_original_treaty_read')
# Malta source book published contemporary documents, preserve local states and British military role
T38=['AB-NEW-038']
event('AB-NEW-038-001',T38,'1798-06-12','圣约翰骑士团向法国交出马耳他与堡垒','Order of Saint John; French Republic; Napoleon Bonaparte','Malta, Gozo, Valletta','1798年6月12日已公布投降协定第I条骑士团把具名城堡和岛屿交法方，此为反法抗争背景；英国尚未获得据点','non_british_control_change_france_vs_order',['BS145'])
event('AB-NEW-038-002',T38,'1798-09-02','马耳他当地居民起义并组地方临时治理机构','Maltese local insurgents; French garrison; Maltese provisional leaders','Malta outside Valletta fortifications','当地居民先发起反法抗争，法军退守瓦莱塔等堡区；此时非英方占领马耳他，马耳他起义政治主体须单独呈现','maltese_local_political_autonomy_and_french_garrison_separate',['BS146','BS145'])
event('AB-NEW-038-003',T38,'1798-09-05','马耳他起义代表向两西西里王室求援','Maltese insurgent leaders; King of Two Sicilies','Malta; Naples/Sicily','Frendo文献集Doc3为1798年9月5日起义领导人致国王公告；为地方外交行动非英国军事征服','maltese_appeal_to_sicilian_king',['BS145'],'published_contemporary_document_selection')
event('AB-NEW-038-004',T38,'1799-02-07','马耳他议会请两西西里同意向英国寻求军事保护','Maltese Congress; representatives of clergy and people; Sicilian monarchy','Malta; Palermo','1799年2月7日请愿写明法国仍占据堡区、当地断粮与军费困难，请求允许向英国求援、在战时悬挂英国旗；请愿而非无条件主权移交','petition_for_british_assistance_not_cession',['BS145'])
event('AB-NEW-038-005',T38,'1799-02-19','两西西里政府批准马耳他代表向英国求保护','John Acton; King of Two Sicilies; Maltese Congress; Horatio Nelson','Palermo; Malta','约翰·阿克顿1799年2月19日在巴勒莫回信同意代表向纳尔逊和英方求保护；西西里王室仍保留相关主权立场','sicilian_royal_permission_for_british_naval_protection',['BS145'])
event('AB-NEW-038-006',T38,'1799-02-23','马耳他使团致英国外交代表与纳尔逊求派陆上指挥官','Maltese envoys Savoye, Fournier, Agius; Sir William Hamilton; Horatio Nelson; Alexander Ball','Palermo; Malta','1799年2月23日两封信请求继续保护、战时英旗及以Ball为当地军政协调人；是当地代表政治行动，并未使法军控制的瓦莱塔即刻改旗','diplomatic_request_for_british_commander_not_final_colonial_cession',['BS145'])
event('AB-NEW-038-007',T38,'1799','英国海军协助封锁瓦莱塔法军据点、并非统治马耳他全岛','British Royal Navy; Alexander Ball; Maltese insurgents; Neapolitan/Sicilian allies; French garrison','Valletta / Grand Harbour','英国舰队与当地义军、那不勒斯方面共同封锁法军所据堡区；法军直到1800年才投降，英国全岛接收时间不得提前至1799','naval_blockade_and_local_insurgency_not_island_wide_british_rule',['BS145','BS146'])
p.write_text(json.dumps(ed,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
# regenerate CSV exactly to previous header, in the exact JSON event order
with (P/'EVENT_CANDIDATES.csv').open('r',encoding='utf-8-sig',newline='') as f: fns=csv.DictReader(f).fieldnames
with (P/'EVENT_CANDIDATES.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=fns);w.writeheader()
 for e in ed['events']:
  x=e.copy();x['topic_ids']=';'.join(e['topic_ids']);x['source_ids']=';'.join(e['source_ids']);x['source_urls']=';'.join(e['source_urls']);w.writerow({a:x.get(a,'') if x.get(a) is not None else '' for a in fns})
# Finance: annual obligation vs request vs estimate, and cross-referenced values never summable
fn=P/'ECONOMIC_EVIDENCE.csv'
with fn.open(encoding='utf-8-sig',newline='') as f: rr=csv.DictReader(f);columns=rr.fieldnames; econ=list(rr)
old={r['id'] for r in econ}
def money(mid,topics,yr,value,unit,metric,payer,recipient,period,source,role,limit,real='False'):
 if mid in old:return
 row={'id':mid,'topic_ids':';'.join(topics),'year_start':str(yr),'year_end':str(yr),'value':str(value),'currency_or_unit':unit,'metric_definition':metric,'payer_or_affected':payer,'recipient_or_observer':recipient,'accounting_period':period,'source_ids':source,'source_urls':URL[source],'source_reading_level':'scholarly_published_derived_data','source_role':role,'verification_status':'secondary_source_no_original_payment_voucher' if real=='False' else 'published_legal_treaty_commitment','was_primary_manuscript_personally_read':'False','actual_received_or_transferred_verified':'False','numerator_denominator':'','interpretation_limit':limit}
 econ.append(row)
money('EXTRA-BALAMBANGAN-1775-COSTLOSS',['E18-E11','AB-NEW-036'],1775,170000,'GBP_18c_nominal','Scholarly estimated company loss from failed Balambangan station, variously described as cost/loss','East India Company','retrospective company losses','1773–1775 project ending Feb 1775','BS142','retrospective_peer_reviewed_estimate','Estimated total cost/loss of project, not separately audited seized loot, cash profit or person-specific transfer; another thesis calls 14-month station cost, which may involve differing definitions')
money('EXTRA-KEDAH-1786-ASK',['E18-E02','AB-NEW-037'],1786,30000,'Spanish_dollars_annual','Kedah sultan request for annual compensation for lost monopoly and defence relationship','EIC proposed payer','Sultan Abdullah of Kedah','requested annual subsidy in 1786 letter','BS148','local_ruler_initial_demand_reported','Demand amount only, no proof EIC paid this yearly; nominal Spanish dollars, not UK pounds')
money('EXTRA-KEDAH-1791-ANNUITY',['E18-E03','AB-NEW-037'],1791,6000,'Spanish_dollars_per_year','1791 treaty year-annuity conditional on EIC occupation of Penang','EIC obligated payer','Kedah court','contract signed 1 May 1791','BS147','published_secondary_law_review_treaty_article','Annual legally negotiated amount not a one-off land purchase price, receipt voucher not inspected; law review challenges textual sovereignty cession','True')
money('EXTRA-KEDAH-1791-REPORT10K',['E18-E03','AB-NEW-037'],1791,10000,'Spanish_dollars_per_year','1925 historian claim Light recommended 10,000 and later payments reportedly reached 10,000/year; officially regularised 1800','EIC reported payer','Kedah court','unverified period after 1791','BS148','later_historical_reconstruction_not_contemporary_receipt','Treat separately from treaty 6,000 obligation, some claim paid vs promised; no cashier ledger inspected, DO NOT SUM with 6,000 or apply 1800 cession in 18c')
with fn.open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,columns);w.writeheader();w.writerows(econ)
# Control / political state changes, no fake geometries
cf=P/'CONTROL_TRANSITIONS_B_E.csv';
with cf.open(encoding='utf-8-sig',newline='') as f: cr=csv.DictReader(f); cols=cr.fieldnames; trans=list(cr)
existing={r['id'] for r in trans}
changes=[
 ('T037','1773','Balambangan Island','Sulu/Brunei maritime polities; EIC treaty negotiation only','EIC trading station established as small site','Sulu Sultanate; local Tausug and Maguindanao; John Herbert; EIC','physical_commercial_factory_not_island_or_coast_sovereignty','BS142','AB-NEW-036-003','No surveyed factory/fort boundary; political rights vary; Sulu-Brunei geography separate'),
 ('T038','1775-02-26','Balambangan Island','EIC small trading station on island','EIC station destroyed, personnel flee; no proven EIC site after 1775','Datu Teteng; Sulu fighters; John Herbert; EIC','local_resistance_ends_eic_factory_no_english_sovereignty','BS142;BS144','AB-NEW-036-008','Island reference point only; Datu Teteng actions not whole Sulu Sultanate decree'),
 ('T039','1791-05-01','Penang/Kedah','EIC physical island presence after 1786 with Kedah treaty dispute','1791 treaty sets annual subsidy, trade and fugitive rendition rules, unsettled legal sovereignty','Sultan Abdullah; EIC; local merchants and enslaved persons','company_occupation_payment_conditions_contested_cession','BS147;BS148','AB-NEW-037-002','May 1791 6000 Spanish dollars/year in text, not verified receipts; modern Penang not historic sovereignty polygon'),
 ('T040','1798-09-02','Malta outside French-held fortresses','French invasion after Saint John surrender','Maltese locally organised insurgency and provisional governing bodies in countryside','Maltese rebels; French garrison; Maltese provisional authorities','maltese_provisional_polity_french_forts_not_british','BS145;BS146','AB-NEW-038-002','No verified perimeter of rebel control; Maltese independence/monarchy relationship contested'),
 ('T041','1799-02-19','Malta / Valletta','Maltese-led siege with outside naval assistance','Sicilian king agrees temporary British naval/military protection requests; French still hold Valletta','Maltese Congress; Sicilian crown; Royal Navy; French garrison','naval_blockade_local_political_actor_not_british_sovereignty','BS145','AB-NEW-038-005','Petition and approval do not create British land title or 1799 island-wide garrison'),
]
for tid,date,place,a,b,actors,ctype,srcid,eid,un in changes:
 if tid in existing:continue
 trans.append({'id':tid,'date':date,'place':place,'from_status':a,'to_status':b,'actors':actors,'control_semantics':ctype,'historical_boundary_verified':'false','area_sqkm':'','geometry_policy':'named_site_point_or_unmapped_only','source_ids':srcid,'related_event_id':eid,'uncertainty':un})
with cf.open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,cols);w.writeheader();w.writerows(trans)
# New dossiers: source table and dossier narratives, actionable tasks
papers={
 'AB-NEW-036':('巴兰邦岸商站：公司预算、苏禄交往与1775年反抗', '''## 一、政治主体与初次权利\n苏禄苏丹国与文莱的沿海政治体系先于公司介入。Alexander Dalrymple于1760年代初从苏禄取得岛屿让渡相关协议，签约年及实际管理界须回看原件。英国公司于1773年由John Herbert实际设岛上商站，不能据此将今日Sabah海岸描为英地。来源BS142。\n\n## 二、鸦片、军火与采购制度\n剑桥《Urban History》全文指出，公司与Tausug/Maguindanao当地商人以鸦片、火药、步枪及大炮换鸟巢、珍珠母贝、海参等供中国市场商品。军火流通与当地武装竞争相联，但每件货量/单价尚未查原账。英图书馆 IOR/G/4/1 ff.7–61 提供实际追账入口：1771年6月12日设站令 ff.14–16；1773年11月19日公司指令 ff.16–17；工资餐费与债款 ff.13, ff.34-39。ff.29–33是拟向中国船交换鸦片与茶丝的被否决草案，不得当作已执行交易。目录已阅读，原卷未读取。来源BS143。\n\n## 三、当地反抗与终结\nJohn Herbert因债务和奴役者抵押问题辱及Datu Teteng，1775年2月26日后者组织苏禄战士攻袭据点，EIC仓库/军械受损，公司人员撤退，英国商站结束。此为具体历史行为的复原而不是把当地人仅称“海盗”。博士论文第117页在Warren研究基础上定位准确日，剑桥论文只写1775年2月。1799年末尚无可证该岛驻站，1803年再占需另归19世纪。来源BS142、BS144。\n\n## 四、经济核算与地图\n剑桥研究称东印度公司损失约£170,000；博士论文则描述14个月商站花费同数。两者可能是同一个估计且“花费”和“摧毁财物”口径不同，不可相加，更不可以直接算作苏禄获战利品的金额。项目不画现代岛疆界为EIC实控，只存岛级待核地名。无需凭现今Balambangan海岸线制造Polygon。\n\n## 五、未决原卷\n追 IOR/G/4/1 ff.8–13/34/36、1750–1775 Sulu条约原文、1775年当事人逃亡报告与Sulu历史研究。以此确定损失总额、贸易货量、岛屿实际驻地精度与后世修史偏见。'''),
 'AB-NEW-037':('槟城—吉打1791和约：权利与年款', '''## 一、1786占岛与当地条件\n马来西亚槟城港务局记录1786-08-11 Francis Light占有Penang，随后吉打苏丹提出长期防务与收益条件；公司此前准许商贸与岛上实际行政不得自动等于吉打国主权已无条件转让。1925年英马研究记1786年苏丹要求每年30,000 Spanish dollars作为失去贸易垄断的补偿（要求，非收据）。来源BS149、BS148。\n\n## 二、1791条约结构\n新加坡国立大学法学期刊1969年研究逐款摘要1 May 1791协定：Art.1规定公司继续占有槟城并每年付6,000 Spanish dollars；Arts 2–8涉及交易及逃亡奴役者、伪造者、叛乱者跨辖拘捕交还；Art.9有“Quedah and Pulo Penang shall be as one country”的文字，具有解释分歧。作者认为文本未正式明言主权割让；需与政府官方历史叙述（称ceded）并陈。来源BS147、BS149。\n\n## 三、金额不可合并\n6,000属1791法律合同年额；10,000源于Light另向董事提议增额及1925后世作者称“1791后曾付”而当年收据未查，1800才有正式1万年额的第二次条约；三万个要求亦不可计为现金实付。不同年款源出同一谈判链，不得当累加殖民净收益。来源BS148。\n\n## 四、下一步\n调1791年条约英文与爪夷文/马来文对照、Light书信和1791–1799年逐笔现金收据，研究各条“逃亡者交还”实施记录与吉打的防卫期待。槟城岛地形可以用于现代地名索引，但不能仅据这段争论重建18世纪公认的法律主权边界。'''),
 'AB-NEW-038':('1798—1799马耳他反法斗争、当地政治主体与英国海上介入', '''## 一、起义在前，英国协助在后\n1798-06-12骑士团向法军签岛屿与堡垒投降条约（编纂的历史原件转录Doc1，来源BS145）。1798-09-02马耳他居民因侵占、宗教/物资争端起义并推举当地临时治理；法军退守瓦莱塔等堡垒（University of Malta学者2022书摘要，原书全文受限，来源BS146）。马耳他是当地政治体，不能记为1798年由英国攻取全岛。\n\n## 二、1799年文书日级政治交涉链\nFrendo主编《Maltese Political Development》Part I编入当时马耳他语境下的意大利文文书。Doc7：1799-02-07 Maltese Congress向两西西里国王请愿，明确英国舰队已有海上封锁，但法军仍守堡区、起义者军费、粮食供应濒于危机，请准求英国救援和战时悬英旗；请求而非让渡主权。Doc8：1799-02-19 John Acton在Palermo答复允许向英方寻求保护。Doc9：1799-02-23当地三使（Ludovico Savoye、Baron Fournier、Luigi Agius）分别致Hamilton、Nelson，请求英国指挥官且提议Alexander Ball，文件保持同时向那不勒斯臣属/结盟的措辞。来源BS145。\n\n## 三、空间分层\n1798-99年马耳他乡间义军、法军占据Valletta/Grand Harbour堡垒、英海军及两西西里舰队封锁援助构成相互叠置但法律性质不同的控制。不绘整个马耳他英国统治实色；不将舰队战区画成英国主权；屏幕点坐标需后续官方场址核验。法国投降发生于1800年不入18世纪事件ID。\n\n## 四、史料核查状态\nHenry Frendo 1993年编刊的1798–1799政治原文转录网页已直接读到Doc7/8/9日期、签名及主要条款，原纸卷未翻看；PDF过大导致在线截图程序无法运行，须记录这一限制。University of Malta 2022学术书仅查了大学资料库的摘要，全文未获授权。\n\n## 五、未决\n核Nelson在1798年10月后封锁命令、那不勒斯粮饷与英国舰费、各岛民代表实际自治边界、1799 Ball具体权力来源和原寄信件。1850年代以后的英国政权叙述不宜倒写1799年。''')
}
D=T/'NEW_CANDIDATES';D.mkdir(exist_ok=True)
for nid,(title,body) in papers.items():
 (D/f'{nid}.md').write_text(f'# {title}\n\n资料级别：research_only／候审，原始手稿未亲阅；不得用于直接发布历史领土。\n\n{body}\n',encoding='utf-8')
for tid,title,body in [
 ('E18-E11','第三轮：巴兰邦岸1773–1775新增据点和苏禄抵抗','公司在1773年建站、1775-02-26被Datu Teteng攻袭。贸易包括军火和鸦片，英国图书馆IOR/G/4/1 pp.7–61有1771指令与1773经费草账目录但未亲阅原账；详见AB-NEW-036。'),
 ('E18-E02','第三轮：槟城1786年款谈判和1791法定权力','苏丹1786要求每年30,000 Spanish dollars为谈判价；1791正式约定6,000/year并存在未明确让渡主权法律争议，不能把1786和1791文书描绘成同日同样地权。详见AB-NEW-037。'),
 ('E18-E03','第三轮：1791和约的贸易及奴役逃亡者交还','BS147逐条介绍5月1日和约的Art.1 6,000 Spanish dollars年款，Art.2–8交还逃亡奴役者/伪造者/叛乱者，Art.9 Quedah and Penang shall be as one country。执行个案和吉打文书未核，详见AB-NEW-037。'),
 ('E18-E12','第三轮跨域比较：马耳他1798–1799不是全岛英国占领','作为本组“其他海外港堡军政关系”的比较母题，新增马耳他独立案AB-NEW-038：反法战由岛民发起，1799有当地议会请求、两西西里王国准许、英国海军围港；1800法国投降，不得回填1799年整岛英国实控。'),
]:
 path=T/f'{tid}.md';s=path.read_text();mark='## '+title
 if mark not in s:path.write_text(s+'\n'+mark+'\n\n'+body+'\n',encoding='utf-8')
(W/'THIRD_ROUND_BATCH2_CHECKPOINT.json').write_text(json.dumps({'date':'2026-11-08','sources':len(src['sources']),'events':len(ed['events']),'new_topics':len(new['candidates']),'economics':len(econ),'control_transitions':len(trans),'notes':'Second increment Sabah/Kedah/Malta saved physically, no Github write, not published.'},ensure_ascii=False,indent=2)+'\n')
print('BATCH2 SAVED',len(src['sources']),len(ed['events']),len(new['candidates']),len(econ),len(trans))
