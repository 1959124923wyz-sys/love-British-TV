# coding: utf-8
"""Fourth round second pass: original treaty clauses, fiscal categories, uncertainties."""
from pathlib import Path
import json,csv
P=Path('/mnt/data/18c_assistant_B'); j=lambda n:json.loads((P/n).read_text(encoding='utf8'))
def put(n,d):(P/n).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def loadcsv(n):
 with (P/n).open('r',encoding='utf-8-sig',newline='') as f:
  r=csv.DictReader(f);return list(r),r.fieldnames
def savecsv(n,rows,fieldnames):
 with (P/n).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames);w.writeheader();w.writerows(rows)
E=j('EVENT_CANDIDATES.json');F,fc=loadcsv('ECONOMIC_EVIDENCE.csv');T,tc=loadcsv('CONTROL_TRANSITIONS_B_E.csv');S=j('SOURCE_REGISTRY.json')
eid={e['id'] for e in E['events']};fid={x['id'] for x in F};tid={x['id'] for x in T};smap={s['id']:s['url'] for s in S['sources']}
def event(i,topics,y,mo,d,title,actors,location,detail,meaning,ss=('BS164',),precision='day',confidence='historical_treaty_text_in_1909_compilation_verified'):
 if i in eid:return
 E['events'].append({'id':i,'topic_ids':topics,'year':y,'month':mo,'day':d,'date_precision':precision,'title':title,'actors':actors,'location':location,'action':detail,'political_effect':meaning,'source_ids':ss,'source_urls':[smap[s] for s in ss],'research_status':'candidate_not_published','map_state':'not_yet_geocoded','geometry_id':None,'confidence':confidence,'historical_control_boundary_verified':False,'actual_British_control_area_sqkm':None});eid.add(i)
def money(i,topics,y,val,curr,definition,payer,recipient,account,explanation):
 if i in fid:return
 row={'id':i,'topic_ids':';'.join(topics),'year_start':str(y),'year_end':str(y),'value':str(val),'currency_or_unit':curr,'metric_definition':definition,'payer_or_affected':payer,'recipient_or_observer':recipient,'accounting_period':account,'source_ids':'BS164','source_urls':smap['BS164'],'source_reading_level':'1909_historical_treaty_compilation_full_indexed_text_read','source_role':'transcribed_18c_treaty_clause','verification_status':'verified_in_1909_government_transcription_only','was_primary_manuscript_personally_read':'False','actual_received_or_transferred_verified':'False','numerator_denominator':'','interpretation_limit':explanation}
 F.append({k:row.get(k,'') for k in fc});fid.add(i)
def transition(i,date,place,prev,post,actors,semantic,related):
 if i in tid:return
 a={'id':i,'date':date,'place':place,'from_status':prev,'to_status':post,'actors':actors,'control_semantics':semantic,'historical_boundary_verified':'false','area_sqkm':'','geometry_policy':'named_site_point_or_unmapped_only','source_ids':'BS164','related_event_id':related,'uncertainty':'基于1909政府条约转录；具体行权/局部边界及实际收款须查当年原档'}
 T.append({k:a.get(k,'') for k in tc});tid.add(i)
# British political control, Indian agency, revenue and commercial grants distinctly identified
for z in [
('AB-NEW-040-003',['E18-B18','AB-NEW-040'],1762,10,12,'坦贾武尔王与卡纳提克纳瓦卜定期赔付220万卢比','Raja Pratap Singh of Tanjore; Nawab of Carnatic; EIC Madras guarantor','Tanjore and Arcot','1762年两王签约一次性220万卢比，分1762至1764五期。英国公司为履约担保人而非全部款项的最终债权人。','local_to_local_indemnity_with_EIC_guarantee'),
('AB-NEW-040-004',['E18-B18','AB-NEW-040'],1762,10,12,'坦贾武尔王另承诺每年向纳瓦卜缴纳40万卢比','Raja Pratap Singh; Nawab of Carnatic','Tanjore and Arcot','1762条约约定每年20万卢比莫卧儿peshkash及20万卢比礼品与durbar费，不能把两者均归东印度公司收入。','annual_tribute_and_court_gifts_to_indian_ruler'),
('AB-NEW-040-005',['E18-B18','AB-NEW-040'],1787,None,None,'坦贾武尔王1787年订英印军费条约日期待核','Raja Ameer Singh of Tanjore; Governor Archibald Campbell; EIC','Thanjavur','1909政府条约卷目录记10 Apr 1787，但签署页行文为20 Apr 1787；档内冲突，先只用年精度。','military_subsidy_treaty_date_dispute'),
('AB-NEW-040-006',['E18-B18','AB-NEW-040'],1793,6,11,'坦贾武尔条约按三种科目设定军费贡赋与私债','Raja Ameer Singh; Charles Oakley; EIC','Thanjavur','1793年6月11日签约；每年350000 Star Pagodas军费、114285 Star Pagodas贡赋转付、60000 Star Pagodas私人债务；贡赋先延期三年，头三年需按合同每年缴460000（包括50000积欠摊付）。','three_category_annual_fiscal_liability_conditional_deferral'),
('AB-NEW-040-007',['E18-B18','AB-NEW-040'],1793,6,11,'坦贾武尔欠款15天后可被公司接管指定地区收税','Raja Ameer Singh; EIC Madras treasury','Tanjore scheduled districts','条约第7条：分期款到期逾15天，公司可在清单所列整区收税，设8%借贷往来科目；某些还款情形下归还，另一些条件可持续管理。原条约条款与实际执行须分开。','conditional_receivership_specific_districts_no_boundary'),
('AB-NEW-041-006',['E18-B01','AB-NEW-041'],1725,None,None,'Kadattanad地方酋长向公司给予胡椒贸易专卖','Chief of Kadattanad; EIC factors','Kadattanad, Malabar','1909汇编目录列1725年胡椒商业特许，此为排他采购关系，未展示司法主权转移。','pepper_trade_monopoly_license'),
('AB-NEW-041-007',['E18-B01','AB-NEW-041'],1748,None,None,'Kotayam的胡椒专卖权让给公司','Kottayam ruler; EIC factors','Kottayam, Malabar','1909条约集记录1748年商业专卖；不得以现代Kottayam行政县全域代表公司控制。','pepper_trade_monopoly_license'),
('AB-NEW-041-008',['E18-B01','AB-NEW-041'],1760,11,22,'Kolattiri摄政者准公司征收指定关税','Regent of Kolattiri; EIC traders','North Malabar','1760年11月22日条款授公司关税征收特权；税权地域与实收款额须依档案核，而非贸易港一整个区都为英国版图。','specific_customs_collection_right'),
('AB-NEW-041-009',['E18-B11','AB-NEW-041'],1792,10,12,'Chirakkal王与公司签订马拉巴尔划定辖区的管理安排','Raja of Chirakkal; EIC','Chirakkal district, Malabar','1792-10-12对公司得到的地区订立settlement；表明割地之后仍有王室/地方行政安排，边界需当年签约清单及地籍。','local_territorial_settlement_with_raja'),
('AB-NEW-041-010',['E18-B11','AB-NEW-041'],1793,6,29,'Calicut王与公司重新约定地区行政管理','Raja of Calicut; EIC','Kozhikode/Calicut Malabar','1793-06-29行政条约及1792早期基础须分开记录；地方政体的司法和行政存续程度需参原文条款。','revised_local_government_agreement'),
('AB-NEW-041-011',['E18-B21','AB-NEW-041'],1793,4,11,'Cannanore的Bibi同意就Laccadive群岛支付贡金','Bibi of Cannanore; EIC','Cannanore / Lakshadweep','1793年4月11日有关拉克沙群岛贡赋与积欠的两项协议；公司获得贡金权不等于实际占据群岛各岛。','tributary_payment_right_not_control_of_islands'),
('AB-NEW-042-004',['E18-B21','AB-NEW-042'],1788,6,19,'特拉凡哥尔与公司确定英军驻其边境的协议','Raja of Travancore; EIC Madras','Travancore frontier','1788-06-19双方关于英军边境布置的协议，区别军事驻地与地方王权。','troop_deployment_agreement_not_entire_frontier_annexation')
]:event(*z,precision='year' if z[3] is None else 'day',confidence='indexed_1909_gov_compilation_date_uncertain' if z[0]=='AB-NEW-040-005' else 'historical_treaty_text_in_1909_compilation_verified')
for z in [
('FISC-1762-Tanjore-Carnatic-lump-sum',['E18-B18','AB-NEW-040'],1762,2200000,'rupee_nominal_1762','1762 total indemnity/arrears under Raja vs Nawab treaty','Raja Pratap Singh, Tanjore','Nawab of Carnatic, not EIC as primary creditor','five scheduled payments 1762–64','Legal obligation with instalments, not actual paid amount; EIC guaranteed, do NOT classify as Company revenue.'),
('FISC-1762-Tanjore-Carnatic-tribute',['E18-B18','AB-NEW-040'],1762,200000,'rupee_nominal_1762','annual Mughal peshkash due by Raja to Nawab','Raja Pratap Singh','Nawab of Carnatic','each July','Legal annual dues to indigenous Nawab; not company income.'),
('FISC-1762-Tanjore-Carnatic-durbar',['E18-B18','AB-NEW-040'],1762,200000,'rupee_nominal_1762','annual durbar present separate from peshkash','Raja Pratap Singh','Nawab of Carnatic and officers','each July','Annual present distinct from tribute; do not aggregate with company transfers.'),
('FISC-1793-Tanjore-military',['E18-B18','AB-NEW-040'],1793,350000,'star_pagoda_nominal','military subsidy owed each year to Company treasury','Raja Ameer Singh','EIC Madras','annual treaty 1793; first 3 years 350000','Promised, not actual cash collected; same first-3-year aggregate component, do not double count.'),
('FISC-1793-Tanjore-tribute',['E18-B18','AB-NEW-040'],1793,114285,'star_pagoda_nominal','Tanjore peshkash originally payable Nawab of Carnatic, transferred entitlement to Company','Raja Ameer Singh','EIC acquired claim from Nawab of Carnatic','annual, deferred first 3 years from July 1792','Reassigned legal claim; first three years suspended, not paid cash every 1793 year.'),
('FISC-1793-Tanjore-private-debt',['E18-B18','AB-NEW-040'],1793,60000,'star_pagoda_nominal','private debts repayment (Company acts collector)','Raja Ameer Singh','private creditors routed through EIC treasury','annual','Private creditors are final recipients, not company net profits.'),
('FISC-1793-Tanjore-arrears',['E18-B18','AB-NEW-040'],1793,50000,'star_pagoda_nominal','first 3 years periodic past peshkash arrears repayment','Raja Ameer Singh','EIC ledger','annual first three years','Same aggregate 460000 includes this; not separately additional income.'),
('FISC-1793-Tanjore-first-3y-total',['E18-B18','AB-NEW-040'],1793,460000,'star_pagoda_nominal','first 3 years annual sum of military+arrears+private debts, 350k+50k+60k','Raja Ameer Singh','EIC treasury acting for mixed recipients','annually for first three years under 1793 agreement','Composite total: subsets are already separate table entries. NOT additional amount. Actual cash receipts unknown.'),
('FISC-1793-Tanjore-postponed-peshkash',['E18-B18','AB-NEW-040'],1793,342855,'star_pagoda_nominal','three years deferred peshkash 114285 * 3','Raja Ameer Singh','EIC treasury','three years deferral','Stock of arrears after three years, not independent annual recurring levy; excerpt states later amortization.'),
('FISC-1793-Tanjore-balance-interest',['E18-B18','AB-NEW-040'],1793,8,'percent_per_annum','contractual interest rate on balance account after district receivership','Raja Ameer Singh','EIC account','annual interest rate','Contract rate, no principal or actual realised interest confirmed.')
]:money(*z)
for z in [
('T057','1793-06-11','Tanjore military subsidy accounts','Raja retains revenue administration','conditional EIC tax receivership if instalment unpaid >15 days','Raja Ameer Singh; EIC','conditional_specific_district_receivership','AB-NEW-040-007'),
('T058','1762-10-12','Tanjore–Arcot alliance','Raja and Nawab independent interlinked polities','2200000 rupees settlement guaranteed by EIC without Company becoming creditor','Raja Pratap Singh; Nawab; EIC','indigenous_indemnity_not_company_revenue','AB-NEW-040-003'),
('T059','1760-11-22','Kolattiri customs','Regent of Kolattiri local legal regime','specified customs collection right to EIC commercial agency','Regent of Kolattiri; EIC','specific_customs_farm_not_sovereignty','AB-NEW-041-008'),
('T060','1792-10-12','Chirakkal settlement','political territory dispute after Mysore war','local Raja retains specified delegated administration under EIC agreement','Chirakkal Raja; EIC','mixed_delegated_admin_and_company_claim','AB-NEW-041-009'),
('T061','1793-04-11','Cannanore and Laccadives','Cannanore Bibi governs island relations','tribute commitment to Company, not island occupation','Bibi of Cannanore; EIC','tributary_contract_not_island_occupation','AB-NEW-041-011')
]:transition(*z)
# Retrospective and chronological uncertainty corrections
for e in E['events']:
 if e['id']=='AB-NEW-044-001':
  e['year']=None;e['month']=None;e['day']=None;e['date_precision']='continuity_investigation_no_attested_year';e['year_window']={'start_year':1700,'end_year':1750,'interpretation':'1692 fort attempt and 1750 fort capacity attested, but precise 1700 state unresolved'};e['confidence']='year1700_not_attested_do_not_render_on_1700_map'
 if e['id']=='AB-NEW-044-003':
  e['year']=None;e['month']=None;e['day']=None;e['date_precision']='conflicting_site_histories';e['year_window']={'start_year':1742,'end_year':1745,'interpretation':'GMMB 1742 vs academic fort table 1745; do not assign definite year'};e['confidence']='chronology_conflict_hold_from_yearly_map'
# 1793 Tanjore source dates, 1787 internal difference, geography
readme=P/'WORKING/FOURTH_ROUND_ORIGINAL_TREATY_CLAUSE_AUDIT.md'
readme.write_text('''# 第四轮：1909年官方条约汇编逐条核验及地理语义审计

来源：[印度考古调查局第14009号藏品：Aitchison《条约、协定与Sanads》第X卷，1909](https://ignca.gov.in/Asi_data/14009.pdf)。已查阅网页抽取的卷首目录和有关条文；1909年编辑转录并非十八世纪签署原件；27MB在线截图工具失败，未逐幅验证扫描纸面。

## 核实的具体条款

- **1781年12月2日卡纳提克Sanad（第IV号）**：由东印度公司总督选任负责征收的amildars，纳瓦卜确认；公司按实际收取税款的六分之一付纳瓦卜，余下六分之五**计入纳瓦卜在公司的账面贷记（credit）**。不得把五分之五直接记公司净利润。期限五年。
- **1785年初约（第V号）**：每年400,000 pagodas临时军政开支 + 1,200,000 pagodas债务偿付 = 承诺1,600,000 pagodas每年；有附属逾期接管安排，非实际到库凭证。
- **1787年2月24日卡纳提克正式约（第VI号）**：每年900,000 star pagodas军费，300,000于11月30日、600,000于3月31日；若某期欠款达100,000且逾1个月，公司可对附表指定辖区任命税务收款官，直至债务偿清；第七条仍保纳瓦卜民事政府及家族地位。并无全卡纳提克主权移转条款。
- **1762年10月12日坦贾武尔—纳瓦卜（第XI号）**：王室赔款220万卢比分期；年付20万卢比peshkash与20万卢比durbar礼金，受款人为当地纳瓦卜、公司为保证人。不能作为英印公司征税总收入。
- **1778年6月17日坦贾武尔王授地（第XIII号下的Sanad）**：Nagore港及周边277个村/小镇的特定jagir；须从历史村庄名单验证每个地点，不得绘整个坦贾武尔。
- **1793年6月11日坦贾武尔条约（第XV号）**：每年军费350,000、贡赋114,285、私人债务60,000星形帕戈达；前3年贡赋延期但每年还积欠50,000，合同当期合计460,000；三年累计暂缓的贡赋342,855。公司有逾期15日对指定完整地区接管收税权（第7条），设8%差额往来账户。按条约不同条件，接管权可终止或持续。部分收款归私人债权人，不应当作公司盈利。
- **175?—1793年马拉巴尔条约**：1708年Tellicherry筑防、1719/1722/1725/1748年不同地方政权的胡椒专卖、1760年Kolattiri关税征收许可、1765年Randatara让与、1792年Chirakkal管理、1793年Calicut和Cannanore地区／贡赋管理，法权语义逐件区分。
- **1795年11月17日特拉凡哥尔临时军事约**：约定一营印度兵支援及相应费用，如需两营则支付两营费用，不是英国直接吞并该王国。
- **1795年10月12日和1796年2月12日康提王国外交约**，与1796年2月15日科伦坡荷兰守军投降不同；康提作为谈判和条约签署者持续独立。

## 发现的内部问题

1. 1787年坦贾武尔军费条约：**卷首目录为4月10日，正文末签署句出现4月20日**，原拉丁文字、印本校勘或进一步审查前，日期在结构化事件中暂留到“年”。
2. 第XV号标题为“1792年条约”，但签署文本日期为**1793年6月11日**，而财政起效期追溯至1792年7月12日；事件年以签署为准，义务起始按另字段区分。
3. 1909编者的“British Government”“Annexed”“Treaty”措辞不等于18世纪同日已经逐村建立公司行政，必须对照地方史料、年度驻军或收税簿。
4. 1781年公司账面收税五分之五属于代纳瓦卜入账的安排；未经董事会偿债账与现款核算，不可简单定为掠夺净收益。
5. 对有年份冲突的Fort Vernon及仅有1692/1750锚点的Dixcove建堡过程，事件年置空，附研究窗口并不允许按1700或1742作确年上图。

## 期末制图门禁

新的研究点来自加纳海岸2024年现代遗产坐标表或南非现代纪念遗址。**历史实际控制面积全部保持null；historical_control_boundary_verified=false；不提供任何未经校正的殖民区多边形**。向下追溯应先查每个jagir村落、1792交割的实际档、军费账以及当地统治者执行文件。
''',encoding='utf8')
# Add case-specific supplement to existing new candidate dossier
for n in ['AB-NEW-040','AB-NEW-041','AB-NEW-042']:
 f=P/'TOPIC_DOSSIERS/NEW_CANDIDATES'/f'{n}.md';txt=f.read_text(encoding='utf8');marker='## 第四轮第二批：独立证据链'
 if marker not in txt:
  es=[x for x in E['events'] if x['id'].startswith(n+'-') and int(x['id'].split('-')[-1])>=3];ff=[x for x in F if n in x['topic_ids'].split(';') and x['id'].startswith(('FISC-1762','FISC-1793'))]
  lines=['\n'+marker,'','原始财政科目与法权转换按条文分开，以下均处候审阶段：','']
  for x in es:lines.append(f"- **{x['id']}**（{x['year'] or '未确年'}）：{x['title']}。{x['action']} 证据：[1909年政府条约汇编]({smap['BS164']})。")
  for x in ff:lines.append(f"- **{x['id']}**：{x['value']} {x['currency_or_unit']}；{x['metric_definition']}；限制：{x['interpretation_limit']}")
  f.write_text(txt+'\n'.join(lines)+'\n',encoding='utf8')
# source registry official cross confirmation
if 'BS174' not in smap:
 S['sources'].append({'id':'BS174','institution':'National Archives of India','title':'Collection at a Glance, Aitchison treaties 14-volume 1909 series archive context','url':'https://nationalarchives.nic.in/index.php/en/collection-glance','reading_level':'official_national_archive_webpage_read','archive_identifier':'1909 government treaties 14-volume collection','notes':'Authoritative institutional bibliography verifies Aitchison 1909 compilation, not individual 18th century original signatories.','original_manuscript_personally_inspected':False,'consulted_on':'2026-11-08'});smap['BS174']=S['sources'][-1]['url']
S['source_count']=len(S['sources']);put('SOURCE_REGISTRY.json',S);put('EVENT_CANDIDATES.json',E);savecsv('ECONOMIC_EVIDENCE.csv',F,fc);savecsv('CONTROL_TRANSITIONS_B_E.csv',T,tc)
old,cols=loadcsv('EVENT_CANDIDATES.csv');extra=[]
for e in E['events']:
 d=dict(e);d['topic_ids']=';'.join(e['topic_ids']);d['source_ids']=';'.join(e['source_ids']);d['source_urls']=';'.join(e.get('source_urls',[]));d['year_window']=json.dumps(e.get('year_window',''),ensure_ascii=False) if isinstance(e.get('year_window'),dict) else e.get('year_window','')
 extra.append({k:d.get(k,'') for k in cols})
savecsv('EVENT_CANDIDATES.csv',extra,cols)
put('WORKING/FOURTH_ROUND_BATCH2_CHECKPOINT.json',{'date':'2026-11-08','phase':'saved','event_count':len(E['events']),'source_count':len(S['sources']),'economic_count':len(F),'transition_count':len(T)})
print('batch2_saved',len(E['events']),len(S['sources']),len(F),len(T))
