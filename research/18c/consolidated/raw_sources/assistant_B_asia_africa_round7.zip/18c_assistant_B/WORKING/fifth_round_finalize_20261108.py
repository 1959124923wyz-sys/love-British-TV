"""Final fifth-round documentation, reproducible stat reconciliation and research handoff; no GitHub calls."""
from pathlib import Path
import json,csv
P=Path('/mnt/data/18c_assistant_B');W=P/'WORKING'
E=json.loads((P/'EVENT_CANDIDATES.json').read_text())['events'];S=json.loads((P/'SOURCE_REGISTRY.json').read_text())['sources'];N=json.loads((P/'NEW_CANDIDATES.json').read_text())['candidates'];G=json.loads((P/'MAP_CANDIDATES.geojson').read_text())['features']
def cr(f):
 with (P/f).open(encoding='utf-8-sig',newline='') as h:return list(csv.DictReader(h))
F=cr('ECONOMIC_EVIDENCE.csv');T=cr('CONTROL_TRANSITIONS_B_E.csv')
assert (len(E),len(S),len(F),len(T),len(N),len(G))==(280,208,144,83,56,21)
summary={'original_major_topics':37,'events':len(E),'sources':len(S),'fiscal_rows':len(F),'controls':len(T),'new_topics':len(N),'map_points':len(G),'original_18c_B_topics':22,'original_18c_E_topics':15,'hist_control_polygons':0,'research_only':True,'date':'2026-11-08','delta_from_round4':{'events':len(E)-222,'sources':len(S)-178,'fiscal_rows':len(F)-112,'controls':len(T)-61,'new_topics':len(N)-46,'map_points':len(G)-21}}
(W/'FIFTH_ROUND_FINAL_CHECKPOINT.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
summary_md=f'''\n\n## 第五轮深度研究｜2026-11-08（完成并本地保存；未提交GitHub）

**当前累计：37原定B/E专题＋{len(N)}个新候选专题（均有独立报告）；{len(E)}件候审事件、{len(S)}项有网址或档号来源、{len(F)}条财政/人口/经济证据、{len(T)}项控制转换、{len(G)}个现代地理参考点；历史实控Polygon 0。**

相对第四轮增加：**{len(E)-222}件净事件、{len(S)-178}项来源、{len(F)-112}条经济证据、{len(T)-61}条控制记录、{len(N)-46}个新专题**。每一原定母题都仍保留`research_only`；未将PR#289候审专题发布到主站，也未修改主站Atlas或GitHub。

### 本轮实质性调查
1. **1750—1753年黄金海岸经济与殖民法律身份**：皇家非洲公司交易及堡垒资产重组，1750年公司法及1752年商人公司接手；Fante各首领参与阿诺马布筑堡协商、抗议、间歇阻工，而殖民施工书信记录了12名已受训的被奴役砖匠、另外40名仅为申请人数；四名协议抵押人/人质有独立身份及后续未知（`BS179`,`BS194`,`BS195`，新`AB-NEW-047`）。
2. **塞拉利昂Bunce/Bance Island**：1728年RAC设施被弃守、之后在不同私商控制下成为人口奴役贸易据点；1794年战争袭击及1807年商人报称损失超£20,000属于**追述／请愿自报**，非1794英国公司已付款凭证（`BS180`,`BS181`）。
3. **1793年孟加拉地税与司法**：永久地税法律和赋税案件审理机制转移以独立法律材料拆分，研究案卷保存州级/司法权限，不能画现代孟加拉省界为1793实际收税地块（`BS183`,`BS184`,`BS185`）。
4. **印度被占领地区的法权**：18世纪公司与卡尔卡塔市长法庭及1753年新特许交互、1795年Cochin交接、Pondicherry 1799年居民被海运拘押等独立立案；少数个案日期、人数须读原法院记录（`BS186`–`BS192`）。
5. **1796年英占安汶与班达**：英军驻堡和当地Raja/Patti/Orang Kaya衔接、Hitu政治自主与特尔纳特王权、Hitu抵抗及英军镇压分别记录。英方公报与荷兰官方档案对**8/9日、16/17日的投降与入堡阶段**存在差异；已保留两个层次的档案来源，而不推断整群岛主权（`BS196`–`BS208`；`AB-NEW-054`、`056`）。
6. **1799年开普殖民边境**：Graaff-Reinet、Khoikhoi、Xhosa和Gqunukwebe各有政治行动，1800—1803后续战争严格不提前纳入1799年英国实控（`BS200`,`BS201`；`AB-NEW-055`）。

### 财政数据质量
- **战争账、赔款、查获库存、原住民土地权、追索请愿、个人奖金不能相加**。1796年安汶银库81,112 rix dollars、丁香515,940磅；班达银库约66,675 rix dollars、肉豆蔻84,777磅（另有84,477磅二手读数）、肉豆蔻衣19,587磅，均属**被查获库存**，其销售、转英国及净收益金额尚需原始凭证。
- `ECONOMIC_EVIDENCE.csv`为**证据行数**，同一1796战利品有互核数据行，**不是144个可以独立加总的财产收益**。原有1765—1771孟加拉印本总支出与逐年加总**相差£2,000**，两组数字均保留待原账核查。
- 1795—96锡兰、安汶、班达个人战利品与补领追索应查`IOR/L/MIL/5/151`、`/152`、`/156`、`/157`，馆藏元数据与实际手稿分开登记。

### GIS交接
`MAP_CANDIDATES.geojson`仍为{len(G)}个现代遗址/地名参考**Point**；远征航线、现代地区面、村级未知地界不擅自画线/面，年末占领仅按具名堡垒。`CONTROL_TRANSITIONS_B_E.csv`是**持续状态候审**，不等于主站已认证的实控。没有基于点缓冲区计算英属殖民面积。

### 立即可接手
优先阅读`WORKING/FIFTH_ROUND_FINAL_CHECKPOINT.json`、`WORKING/FIFTH_ROUND_SOURCE_READING_MATRIX.md`、`TOPIC_DOSSIERS/NEW_CANDIDATES/AB-NEW-056.md`、`GAPS_AND_CONFLICTS.md`；新ID均与原E18母题分开。运行`python WORKING/validate_and_package.py`可再生同名ZIP，并检查`MANIFEST.json`及`SHA256SUMS.txt`。**无GitHub提交，未发表**。
'''
for f in ['README.md','PROGRESS.md']:
 q=P/f
 text=q.read_text(encoding='utf-8')
 if '## 第五轮深度研究｜2026-11-08' not in text:q.write_text(text+summary_md,encoding='utf-8')
GAPS='''\n\n## 第五轮新增核心争议与未核对账目（2026-11-08）

60. **1750/1752西非贸易公司法权转换**：1680年代RAC私人财产、英王堡垒援款、1750年法案、1752年新公司实际接手分开，不将法条生效日自动代表所有堡垒交接完毕。相关来源`BS179`/第一批`BS...`；原始移交清册待读。
61. **1753阿诺马布条约日期**：英国国家档案馆目录叙述作2月7日，但同机构公布的历史签署文本作**1753年2月6日**；保存月级事件，不编造无争议精确日。`T70/1526/22`与`T70/1695/1`均属索引/转录，原纸未亲阅。
62. **1753阿诺马布建筑人力**：已受训的12名奴役砖匠为工程师当期自报；新要求40名劳工仅是申请，不能累加成52名已被强制运抵。工程监测8/18奠基、10/11劳动力快照不能外推建堡完工日或全城控制半径。
63. **Fante协议四名抵押人/人质**：法律称pledges，不能未经生平记录把人质等同实际贩卖上船者；Aqua/Sackee两名Fante少年在欧洲就学监护与1754年返乡命令的身份和航次要单独核原始船簿。
64. **Bunce岛1794年私商声称损失**：1807年反废奴请愿自报大于£20,000，归属商人利益主张；不是1740年代年收入、1794年实际理赔支付或英国殖民财政净收益。须查`TNA`商馆货簿与1794战争记录。
65. **1796安汶/班达“投降日”冲突**：1796年Madras政府在11月29日Gazette公报所载为**Ambon 2月16日、Banda 3月8日交出**；现代海军史记英国士兵2月17日与3月9日进入堡垒；荷兰国家档案馆`1.10.59/407`把Van Boeckholz投降明确记为3月9日。可能是谈判/下旗/入堡相异时间，不能把单方日期全部当作独立占领。
66. **1796 Banda肉豆蔻数量互异**：同时期官方转载数字**84,777 pounds**，后世海军史写**84,477 pounds**，相差**300 pounds**。此前经济表已录84,477，本轮增84,777仅为同一库存竞品，不可相加成169,254；应核`IOR/H/441`及荷兰`1.10.59/408`实物清单。
67. **Banda银库现金印刷OCR限制**：英国1796年期刊可检索数字为“65,d75”，海军历史文章报66,675；源图片未正常获取，只按“约66,675，印本照片未独立核认”登记。`rix dollar`币种来源为记账单位，不能未经汇率证据直接换算英镑。
68. **库存与净收入分离**：1796年Ambon银库81,112 rix dollars、丁香515,940 pounds，Banda肉豆蔻衣19,587 pounds及银库现金是**占领时盘点**，不是已售出利润或已汇往伦敦的净所得；真实货物流动、售价、扣费、个人奖金和英国议会分润需各自凭证。
69. **Hitu 1796自主与镇压**：Noldus 1984研究认为Hitu领袖欲恢复以Ternate Sultan为中心的政治权力，进军Ambon遭英军镇压、有人被监禁及处决。人数、月份、村落范围、领袖姓名需追`De Graaf 1977 p.198`及英/荷军事原档，不能绘制Hitu全岛已受英国长期实控Polygon。
70. **荷兰堡垒文书仅目录**：荷兰国家档案馆1.10.59第407、408、410、411、412项仅已见官方目录PDF图页，不曾阅读原卷和原货物交接单；Brit Library`IOR/H/441`,`IOR/G/21/10`同为馆藏编目，不能冒充已核库存账。
71. **1795–96个人奖金与后续索赔的年代**：BL`IOR/L/MIL/5/151–158`包含后来1820年代名册和索赔、`/156`和`/157`未领取分配及Banda Neira Fund；必须核每名受益者、分配轮次和真正到账年，而不能把每名军官自报£15,000写成1796年付清。
72. **1799开普边境战争起止**：研究窗口1799–1803，1799各阶段Graaff-Reinet殖民武装、英军、Khoikhoi、Xhosa和Gqunukwebe行动不完全统一；1800–1803后续不得塞入18C。Zuurveld无可靠真实主权边界，不据今日区划填色。
73. **历史新闻印刷品与原件阅读**：1796年12月期刊转录同年11月公报全文（PDF可检索文本可阅、截图工具不可取）是**同期印刷二次转载**；Dutch National Archives官方目录PDF已看扫描图页但未看当年信纸/原卷；University Canterbury 1984学位论文扫描图页已看，但属后人研究。
74. **单纯原档截止日不是殖民事件**：曾暂录的`AB-F5-SE-006`是英国图书馆远征日记可用范围截止日期，现已从候审历史事件删去，转为源目录信息以免污染逐年地图。
'''
q=P/'GAPS_AND_CONFLICTS.md';s=q.read_text(encoding='utf-8');q.write_text(s+(GAPS if '## 第五轮新增核心争议' not in s else ''),encoding='utf-8')
# Independent review note, so other assistants can navigate without any programming.
readmap='''# 第五轮史料阅读深度与主编可执行交接（2026-11-08）

## 1. 审核结论
最终数据计数：**280事件、208来源、144经济证据、83控制转换、56新专题**。原定37专题均有报告；21 Point / 0 Polygon。`research_only`；没有任何GitHub写入。201以后的来源均在SOURCE_REGISTRY登记阅读级别。

## 2. 一手资料/原件 vs 档案目录
| 来源/档号 | 研究实际接触 | 重要内容 | 主编下一步 |
|---|---|---|---|
| BS203，1796英国12月期刊中转载11月29日Gazette，Madras 6月22日书函 | 读取PDF可搜索页面所载同期文字；截图工具失败，未查原Madras来信 | Amboyna 16 Feb/Banda 8 Mar，以及现金和香料仓库数量 | 从1796 Gazette原页和船长回报逐项核，校正OCR数字 |
| BS202，荷兰Nationaal Archief `1.10.59/407–412` | 已阅读**官方目录**PDF图页70；未阅读库房案卷 | Van Boeckholz 9 March 1796交堡、公司货物交接、米粮、英国驻岛行政报告 | 调阅第407、408箱清单及第410–412号原档 |
| BS204，坎特伯雷大学Noldus 1984 | 已阅读学位论文扫描PDF图页42/43(印刷35/36) | Hitu抵抗、逮捕和处决、英军延续丁香专卖、地方首领继续办公 | 查论文脚注De Graaf (1977) p198的来源及英国驻军原信 |
| BS205 / BL `IOR/L/MIL/5/151` | 仅核英国图书馆数字目录 | 1795–96锡兰、摩鹿加战利品具名分配记录，后期编成 | 申请原卷/数字扫描，逐人录领取与追索日期 |
| BS208 / BL `IOR/L/MIL/5/152` | 仅核英国图书馆数字目录 | Colombo、Ambon、Banda奖金名册 | 同上 |
| BS206 / BL `IOR/L/MIL/5/156` | 仅核英国图书馆数字目录 | 1826 Madras命令下Ambon未领取第二次奖金追索 | 区分已付款、未领款、追索与原占岛年份 |
| BS207 / BL `IOR/L/MIL/5/157` | 仅核英国图书馆数字目录 | Banda Neira Fund总表与未领取奖金 | 同上 |
| BL `IOR/H/441`、`IOR/G/21/10` | 仅核馆藏目录 | 同期远征日志、工厂往来账 | 重点核安汶/班达占领及实际香料出售票据 |
| `TNA T70/1526/22, T70/1695/1` | 官方机构整理与签字史料索引；未见原纸 | 1753 Fante议约、当事首领和四名担保人 | 纠正2月6日/7日日期冲突，读取地方主体条款与身份 |
| `IOR/L/MIL/5/159–160` | 英国图书馆档案目录，未看原件 | 1799 Seringapatam奖赏与战利品份额 | 分公司收入、军官领取与兵士奖金，莫汇成英国政府纯利 |

**已看到现代机构扫描图页，不等于已看18世纪签字原件。** 历史原始汇票、领取收据和存货盘点未查到逐行全文时，本研究都明确作目录或研究转述。

## 3. 主编地图操作建议
- **数据只用于研究层**：审查`EVENT_CANDIDATES.json`与`CONTROL_TRANSITIONS_B_E.csv`后逐项分配正式Atlas事件ID；不可原样全量投产。
- **殖民身份要分层**：英格兰EIC商馆许可、英军短时驻堡、公司收税、附属军事协定、地方王权自治分别用不同标签。长时间战争与短暂抢掠不要因持续阅读而变成长期英国实占。
- **地理**：21个现代参考GPS仅可表示现代已知的地名/遗址；新Ambon/Hitu诸事件没有经确认微观遗址坐标，保持null。所有Polygon和area为null。需要具名参考点时优先馆方/官方遗址经纬度而不是临时手填。
- **金钱**：可按`metric_definition`,`recipient_or_observer`,`verification_status`过滤；`ECONOMIC_EVIDENCE.csv`有同一库存的数字冲突/复核行，禁止对value整列求和。

## 4. 复核通行路线
不懂编程可直接解压阅读：`README.md`→`PROGRESS.md`→`TOPIC_DOSSIERS/`→`GAPS_AND_CONFLICTS.md`。需要恢复完整校验，则执行`python WORKING/validate_and_package.py`；`WORKING/FIFTH_ROUND_FINAL_CHECKPOINT.json`载最终计数；`MANIFEST.json`载封存统计。
'''
(W/'FIFTH_ROUND_SOURCE_READING_MATRIX.md').write_text(readmap,encoding='utf-8')
# end-of-round checklist; no false content assertions
manifest={'round':'fifth','date':'2026-11-08','statistics':summary,'completion':'local-only research package, not released','requires_user_action_now':False,'pending_original_archives':['BL Mss Eur G37/88/4 ff.30–31','BL IOR/H/441','BL IOR/L/MIL/5/151–158 and 159–160','NA 1.10.59 inv.407–412','TNA T70/1526/22 and T70/1695/1'],'topic_ids_original_unmodified':True,'history_geometries_added':0}
(W/'FIFTH_ROUND_FINAL_HANDOFF.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('FIFTH ROUND DOCS FINALIZED',json.dumps(summary,ensure_ascii=False))
