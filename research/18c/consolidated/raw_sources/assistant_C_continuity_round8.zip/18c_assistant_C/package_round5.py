#!/usr/bin/env python3
"""Create one comprehensive, verifiable local research ZIP, no external writes."""
import json,hashlib,zipfile,pathlib,datetime
P=pathlib.Path(__file__).resolve().parent
OUT=P.parent/'18c_assistant_C_continuity_australia.zip'
checks=json.loads((P/'ROUND5_QA_REPORT.json').read_text())
assert checks['fail']==0
snap=[]
for f in sorted(P.rglob('*')):
 if f.is_file() and f.name!='ARCHIVE_MANIFEST.json':
  raw=f.read_bytes();snap.append({'path':str(f.relative_to(P)),'size_bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
manifest={'schema':'assistant-C-round5-full-local-archive-manifest','archive':'18c_assistant_C_continuity_australia.zip','research_status':'research_only','created_utc':'2026-11-08','package_path_prefix':'18c_assistant_C/','included_files_other_than_manifest':len(snap),'files':snap,'strict_source_witness_discipline':'Unverified original manuscripts and historical boundary geometries are not claimed reviewed/accurate','version':'round5'}
(P/'ARCHIVE_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
# re-run repo-script style checks (file presence, JSON/GeoJSON already run)
with zipfile.ZipFile(OUT,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in sorted(P.rglob('*')):
  if f.is_file():z.write(f,arcname='18c_assistant_C/'+f.relative_to(P).as_posix())
with zipfile.ZipFile(OUT) as z:
 assert z.testzip() is None
 assert len(z.namelist())==len(snap)+1
 for file in snap:
  b=z.read('18c_assistant_C/'+file['path'])
  assert len(b)==file['size_bytes'] and hashlib.sha256(b).hexdigest()==file['sha256']
 assert json.loads(z.read('18c_assistant_C/ARCHIVE_MANIFEST.json'))['version']=='round5'
print(json.dumps({'archive':str(OUT),'bytes':OUT.stat().st_size,'zip_items':len(snap)+1,'sha256':hashlib.sha256(OUT.read_bytes()).hexdigest(),'round5_qa_pass':checks['pass'],'round5_qa_fail':checks['fail']},ensure_ascii=False))
