#!/usr/bin/env python3
"""Assistant 3 round-6 non-publication QA: structure, traceability, dates, history-specific map gating."""
from pathlib import Path
import json,csv,re,collections,hashlib
P=Path(__file__).resolve().parent
R=lambda name:json.loads((P/name).read_text(encoding='utf-8'))
checks=[]
def test(name,func):
 try:
  detail=func()
  if detail is False:raise AssertionError('condition was false')
  checks.append({'name':name,'passed':True,'detail':str(detail)[:300] if detail is not True else ''})
 except Exception as err:checks.append({'name':name,'passed':False,'detail':str(err)[:800]});print('FAIL',name,err)
def require(condition,message='condition failed'):
 if not condition:raise AssertionError(message)
 return True
A=R('CROSS_CENTURY_AUDIT.json');B=R('CONTROL_TRANSITIONS_1699_1709.json');E=R('EVENT_CANDIDATES.json');S=R('SOURCE_REGISTRY.json');G=R('MAP_CANDIDATES.geojson');C=R('CLAIM_EVIDENCE_MATRIX.json');X=R('ROUND3_EVIDENCE_CONFLICTS.json');Q=R('ROUND5_SITE_YEAR_DECISION_MATRIX_1699_1710.json');Y=R('ROUND6_1699_1710_SITE_IDENTITY_GRID.json');L=R('ROUND6_LEGAL_PRECISION.json');J=R('ROUND6_LOCAL_CONTROL_EPISODES.json');IR=R('ROUND6_1798_LOCAL_REGIME_DECISIONS.json');H=R('ROUND6_HAWKESBURY_1794_CASE.json');V=R('ROUND5_EVENT_DEDUP_REVIEW.json');anchor=R('ROUND5_PRE_POST_18C_ANCHORS.json')
source_ids={x['id'] for x in S['sources']};event_ids={x['id'] for x in E['events']};geoid={x['id'] for x in G['features']}
eventmap={x['id']:x for x in E['events']}
test('36 prior registered stories',lambda:require(len(A['entries'])==36))
test('stable 17C old IDs unique',lambda:require(len({x['previous_story_id'] for x in A['entries']})==36))
test('source continuity classifications cover full 36',lambda:require(sum(A['counts_by_kind'].values())==36))
test('old 17C date windows never auto promoted into 1700 borders',lambda:require(all(x['historical_boundary_confirmed']==False for x in B['candidates'])))
test('27 seed graphics distinct',lambda:require(len(B['candidates'])==27 and len({x['stable_id'] for x in B['candidates']})==27))
test('each seed annual year-end 1700-1709',lambda:require(all([y['year'] for y in x['year_end_reviews']]==list(range(1700,1710)) for x in B['candidates'])))
test('270 audit seed annual slots',lambda:require(sum(len(x['year_end_reviews']) for x in B['candidates'])==270))
test('8 additional regime histories',lambda:require(len(Q['relations'])==8))
test('96 additional 1699-1710 site snapshots',lambda:require(sum(len(x['annual_1699_1710']) for x in Q['relations'])==96))
test('24 new historical site-identity decisions',lambda:require(Y['decision_count']==len(Y['year_end_site_checks'])==24))
test('identity checks cover exactly 1699-1710',lambda:require(all([x['year'] for x in Y['year_end_site_checks'] if x['site']==site]==list(range(1699,1711)) for site in {z['site'] for z in Y['year_end_site_checks']})))
test('no invented geo of eroded York and destroyed Churchill posts',lambda:require(all(x['coordinates'] is None and x['historical_boundary_verified'] is False for x in Y['year_end_site_checks'])))
test('all named site episodes require boundary null',lambda:require(all(x.get('geometry') is None for x in J['episodes'])))
test('all 1798 town control decisions have no real historical boundary',lambda:require(all(x.get('boundary') is None for x in IR['towns'])))
test('1798 local return to Crown must not mark New Ross successful rebel occupation',lambda:require(all(x['phase']!='held_by_insurgents' for x in IR['towns'] if x['site']=='New Ross')))
test('source rows unique and header count',lambda:require(len(S['sources'])==len(source_ids)==S['source_count'] and len(source_ids)>=189))
test('source URLs use HTTPS',lambda:require(all(x['url'].startswith('https://') for x in S['sources'])))
test('each source has audit scope',lambda:require(all(x.get('access_level') and x.get('original_manuscript_personally_inspected') is not None for x in S['sources'])))
test('event rows unique and header count',lambda:require(len(E['events'])==len(event_ids)==E['event_count'] and len(event_ids)>=179))
test('claim rows unique and header count',lambda:require(len(C['claims'])==len({x['id'] for x in C['claims']})==C['evidence_count'] and C['evidence_count']>=67))
test('date/source conflicts unique',lambda:require(len(X['conflicts'])==len({x['id'] for x in X['conflicts']})>=21))
def sourcewalk(obj,path='root'):
 if isinstance(obj,dict):
  for k,v in obj.items():
   if k=='source_ids':
    vv=v if isinstance(v,list) else [v]
    unknown=set(vv)-source_ids
    require(not unknown, f'{path} missing source IDs {unknown}')
   else:sourcewalk(v,path+'/'+str(k))
 elif isinstance(obj,list):
  for i,x in enumerate(obj):sourcewalk(x,f'{path}/{i}')
 return True
for f in ['CROSS_CENTURY_AUDIT.json','CONTROL_TRANSITIONS_1699_1709.json','EVENT_CANDIDATES.json','CLAIM_EVIDENCE_MATRIX.json','MAP_CANDIDATES.geojson','ROUND3_EVIDENCE_CONFLICTS.json','ROUND5_SITE_YEAR_DECISION_MATRIX_1699_1710.json','ROUND6_1699_1710_SITE_IDENTITY_GRID.json','ROUND6_LOCAL_CONTROL_EPISODES.json','ROUND6_LEGAL_PRECISION.json','ROUND6_1798_LOCAL_REGIME_DECISIONS.json']:
 test('referenced sources exist: '+f,lambda f=f:sourcewalk(R(f)))
test('new Hawkesbury source registry traceable',lambda:require(set(H['sources'])<=source_ids))
test('new Hawkesbury events traceable',lambda:require(set(H['new_events'])<=event_ids))
test('new Hawkesbury claims traceable',lambda:require(set(H['research_claims'])<={x['id'] for x in C['claims']}))
def validgeo():
 require(G['type']=='FeatureCollection')
 require(len(G['features'])>=60)
 require(sum(x['geometry'] is not None for x in G['features'])>=3)  # Updated after R7 HES-sourced Glenshiel point added; never assume fixed point count
 for x in G['features']:
  require(x['geometry'] is None or x['geometry']['type']=='Point','only Point and null allowed')
  v=x['properties']
  for k in ['historical_boundary_confirmed','territorial_claim','fill_authorized','exclude_from_area_aggregation']:
   require(v.get(k) is (True if k=='exclude_from_area_aggregation' else False),(x['id'],k))
  require(v.get('area_sqkm') is None,x['id'])
  for ref in v.get('linked_event_ids',[]):require(ref in event_ids,(x['id'],ref))
 return True
test('all geography candidate features strictly non-territorial',validgeo)
test('geometry IDs unique',lambda:require(len(geoid)==len(G['features'])))
test('all event geometry references exist or null',lambda:require(all(x.get('geometry_ref') is None or x['geometry_ref'] in geoid for x in E['events'])))
def event_dates():
 for x in E['events']:
  require(re.fullmatch(r'\d{4}(-\d{2}){0,2}',x['date']) is not None,(x['id'],x['date']))
  year=int(x['date'][:4]);require((1699<=year<=1799) or (year<1700 and x.get('is_prior_century_continuity_anchor') is True),(x['id'],year))
  require(x['historical_control_polygon_approved'] is False,x['id'])
  require(x['research_state']=='research_only',x['id'])
  require(len(x['source_ids'])>0,x['id'])
 return True
test('all 18C event windows properly bounded and never publication-ready',event_dates)
test('exactly 19 D/F main dossiers',lambda:require(all((P/'TOPIC_DOSSIERS'/f'E18-{pre}{n:02}.md').exists() for pre,num in [('D',10),('F',9)] for n in range(1,num+1))))
def csvjson():
 with (P/'EVENT_CANDIDATES.csv').open(encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f))
 require(len(rows)==len(E['events']))
 for r,x in zip(rows,E['events']):require((r['id'],r['date'],r['source_ids'])==(x['id'],x['date'],';'.join(x['source_ids'])),x['id'])
 with (P/'CLAIM_EVIDENCE_MATRIX.csv').open(encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f))
 require(len(rows)==len(C['claims']))
 for r,x in zip(rows,C['claims']):require(r['id']==x['id'])
 return True
test('CSV and JSON exact event and evidence count/alignment',csvjson)
test('1794 Hawkesbury event is distinct from 1795 troops',lambda:require(eventmap['C6A-D10-1794-MASSACRE']['date']=='1794-09' and eventmap['C6A-D06-1795-POST']['date']=='1795-01'))
test('1794 source disagreement preserved without fake coordinate',lambda:require(H['geo_decision']['geometry'] is None and H['casualty_accounts'][0]['count']==7 and H['casualty_accounts'][1]['count_interval']==[7,8]))
test('Cook east coast declaration cannot substitute settlement',lambda:require(all(x['historical_control_polygon_approved'] is False for x in E['events'] if x['topic_id']=='E18-D01')))
test('1707 Union and pre-1707 Darien distinct episodes',lambda:require(eventmap['C-F03-001']['date']=='1707-01-16' and eventmap['C-F03-002']['date']=='1707-03-06'))
test('Irish England 1702 vs Irish 1704 legislature separated',lambda:require({'Parliament of England','Parliament of Ireland'}<={x['legislature'] for x in L['clauses']}))
test('Scotland final Union effect 1707 not instant enlarged colonial Polygon',lambda:require(all(x['geometry'] is None for x in J['episodes'] if 'YORK' in x['id'])))
test('Carnew no proven rebel town control',lambda:require(eventmap['C6-F06-004']['geometry_ref'] is None and eventmap['C6-F06-004']['date']=='1798-06'))
test('Ballyellis ambush and Carnew failed storm separate',lambda:require(eventmap['C6-F06-012']['date']=='1798-06-30'))
test('Scullabogue victims not attributed to Crown soldiers',lambda:require('起义' in eventmap['C6-F06-009']['actor']))
test('Wexford Bridge massacre day under review',lambda:require(eventmap['C6-F06-005']['date']=='1798-06'))
test('York I/II/III source phase retained',lambda:require(all(any(x['id']==id for x in J['episodes']) for id in ['C6-YORK-I-FRENCH','C6-YORK-II-BRITISH','C6-YORK-III-BRITISH'])))
test('Churchill 1689 burn distinct 1717 rebuild',lambda:require(all(any(x['id']==id for x in J['episodes']) for id in ['C6-CHURCHILL-NOPOST','C6-CHURCHILL-1717'])))
test('prior fifth-round deduplicated records remain absent',lambda:require(all(x['discard_redundant_candidate'] not in event_ids and x['retained_id'] in event_ids for x in V['merged_redundant_events'])))
test('pre/post 18C anchors correctly excluded',lambda:require(all(x['id'] not in event_ids for x in anchor['anchors'])))
report={'schema':'assistant-C-round6-independent-local-QA-v1','audit_date':'2026-11-08','state':'research_only_not_published','checks':checks,'checks_passed':sum(x['passed'] for x in checks),'checks_failed':sum(not x['passed'] for x in checks),'totals':{'events':len(E['events']),'sources':len(S['sources']),'source_evidence_claims':len(C['claims']),'conflicting_claims':len(X['conflicts']),'geolocations':len(G['features']),'geolocations_with_reference_coordinates':sum(x['geometry'] is not None for x in G['features']),'historical_colonial_polygons':0,'old_stories_audited':len(A['entries']),'1699_reference_shapes':len(B['candidates']),'1700_1709_reference_slots':sum(len(z['year_end_reviews']) for z in B['candidates']),'site_identity_annual_slots':len(Y['year_end_site_checks'])},'limitations':['Several digitized primary law/archival descriptions rely on catalogue and printed public extracts, not inspected manuscript folios','A period-supported garrison or trading-post interval is not itself independently verified by yearly muster','Modern massacre database reference coordinates are only modelled locality and were not plotted as eyewitness GPS','1798 historic battle map is not geo-rectified and original facsimile pdf page visual inspect unavailable','No approved historical colonial polygon or formal Atlas/browser QA; repository not modified']}
(P/'ROUND6_QA_REPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print('ROUND6 PASS',report['checks_passed'],'FAIL',report['checks_failed'],report['totals'])
if report['checks_failed']:raise SystemExit(1)
