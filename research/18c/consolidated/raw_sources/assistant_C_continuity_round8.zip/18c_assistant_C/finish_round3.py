"""第三轮最终证据、专题、交接补充，运行于 extend_round3.py 之后，不写GitHub。"""
from pathlib import Path
import json, csv
P=Path('/mnt/data/18c_assistant_C')
def load(f):return json.loads((P/f).read_text(encoding='utf-8'))
def save(f,j):(P/f).write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def append(f,text):
 p=P/f; t=p.read_text(encoding='utf-8');marker='## 第三轮专题复查'
 if marker not in t:p.write_text(t.rstrip()+"\n\n"+marker+"\n\n"+text.strip()+"\n",encoding='utf-8')
S=load('SOURCE_REGISTRY.json');E=load('EVENT_CANDIDATES.json');M=load('CLAIM_EVIDENCE_MATRIX.json')
new=[
('C3-AU-SLNSW-COLLINS','State Library of New South Wales','David Collins: formal government on 7 February 1788','https://www2.sl.nsw.gov.au/archive/discover_collections/history_nation/justice/lawmaker/collins/collins.html','state_library_historical_research','Judge Advocate Collins read Act, commissions and letters patent on 7 Feb 1788. Legal commission geographical claim NOT military occupation of the 135E limit.'),
('C3-AU-GOV-1788','Governor of New South Wales','Historical speech on 7 February 1788 commission ceremony','https://www.governor.nsw.gov.au/governor/selected-speeches-and-messages/show/4138','office_of_governor_modern_primary_quotation_history','Governor NSW official speech locates 7 Feb reading at/near Dawes Point, cites original proclamation; retrospective event not surveyed precise location.'),
('C3-AU-USYD-1788','University of Sydney','Australharmony chronology 7 Feb 1788 primary diary excerpts','https://www.sydney.edu.au/paradisec/australharmony/chronicle1542-1800.php','academic_digitized_primary_text_transcripts_and_links','Quotes first-person journals by Arthur Bowes Smyth and George Worgan: Commission, court commission read 7 Feb; links manuscripts, but this agent did not examine physical originals.'),
('C3-CAN-MAROON-MIGRATION','Parks Canada','Black Migrations to Sierra Leone 1792 and 1800','https://parks.canada.ca/culture/designation/evenement-event/migrations-sierra-leone','official_national_historic_event_description','More than 500 Jamaican Maroons migrated in 1800 after 1796 Nova Scotia exile; do not redate 1800 to 1799.'),
('C3-CAN-MAROON-PLAQ','Parks Canada','The Jamaican Maroons in Nova Scotia National Historic Event','https://parks.canada.ca/culture/designation/evenement-event/marrons-maroons','official_national_historic_event_plaque_transcription','1796 exile April, reach Nova Scotia July. On 30 Sep 1800 HMS Asia anchored off Freetown with 177 women+151 men+222 children, note aboard ship count not all permanently resettled.'),
('C3-AU-NMA-PEMULWUY-1802','National Museum of Australia','Pemulwuy 1801 orders and 1802 killing','https://www.nma.gov.au/defining-moments/resources/pemulwuy','national_museum_historical_analysis_with_historic_records','May 1 1801 government shoot-on-sight order; Nov1801 reward; shot dead on or before 2 June 1802; assailant unverified; explicit non-1799 end.'),
]
ids={x['id'] for x in S['sources']}
for sid,inst,title,url,access,limitations in new:
 if sid not in ids:S['sources'].append({'id':sid,'institution':inst,'title':title,'url':url,'access_level':access,'original_manuscript_personally_inspected':False,'reviewed_online_on':'2026-11-08','specific_use_and_limits':limitations})
for x in S['sources']:
 if x['id']=='C3-AU-CAMP-RUSE':x['url']='https://www.campbelltown.nsw.gov.au/About-Campbelltown/History/Prominent-People-From-Our-Past/Ruse-James'
S['source_count']=len(S['sources']);save('SOURCE_REGISTRY.json',S)
for x in E['events']:
 if x['id']=='C3-D03-001':
  x['source_ids']=sorted(set(x['source_ids']+['C3-AU-SLNSW-COLLINS','C3-AU-GOV-1788','C3-AU-USYD-1788']))
  x['cartographic_status']='contemporaneous_commission_reading_day_attested; ceremonial_location_not_surveyed'
  x['evidence_notes']='两份1788一手航海日记同时代描述，由悉尼大学公开引录；州立图书馆与州总督办公室独立说明日期。委员会所列纸面省界不是1788年军队实控范围。'
 for key in ['C-D07-002','C-D07-001']:
  if x['id']==key:
   x['evidence_notes']=(x.get('evidence_notes') or '')+' | R3跨世纪提醒：Pemulwuy本人反抗持续至1802，1801政府命令不可隐藏；事件时段应由专门长期人物线跨世纪衔接。'
E['event_count']=len(E['events']);save('EVENT_CANDIDATES.json',E)
for x in M['claims']:
 if x['id']=='NORFOLK-HISTORY':x['source_ids']=sorted(set(x['source_ids']+['C3-AU-NORFOLK-DCCEEW']))
for id,dt,summary,srcs,limits,carto in [
('FIRST-NSW-GOVT-1788','1788-02-07','Governor Phillip commissions and justice court documents read in ceremony in Sydney','C3-AU-SLNSW-COLLINS;C3-AU-USYD-1788;C3-AU-GOV-1788','The commission extensive geographic bounds are legal jurisdictional CLAIM; 1788 soldiers / settlement actually concentrated in Sydney Harbour. Old diary original pages linked but not personally collated.','city scene named historical location only, never claimed entire territorial polygon'),
('MAROON-1796-1800-BOUNDARY','1796–1800','Trelawny Town Maroons sent to Nova Scotia 1796, later granted migration to Freetown in 1800 after petitions','C3-CAN-MAROON-MIGRATION;C3-CAN-MAROON-PLAQ','Sep 1800 ship manifest report 177 women, 151 men, 222 children; not exact 1796 deportation count and not 18C event.','cross-century 1800 handoff to editor, cannot add 1800 Freetown in 1799 slider'),
('PEMULWUY-1792-1802-BOUNDARY','1792–1802','Pemulwuy resistance continued across 1799, Governor order 1801, killed by early June1802','C3-AU-NMA-PEMULWUY-1802','1797 battle not endpoint; 1802 identity of killer disputed; no cause-to-area automatic polygons.','separate 1800-1802 19C next-series event nodes; keep stable resistance arc'),
]:
 if any(x['id']==id for x in M['claims']):continue
 M['claims'].append({'id':id,'date_or_range':dt,'claim_summary':summary,'source_ids':srcs.split(';'),'access_type':'government_or_academic_instutitional_analysis_and_quoted_18c_records','audit_limit':limits,'map_eligibility':carto,'original_folio_personally_inspected':False,'round_added':3})
M['evidence_count']=len(M['claims']);save('CLAIM_EVIDENCE_MATRIX.json',M)
# Detailed dossier technical notes: old materials retained.
articles={
 'E18-D01.md':'''**1770声索与1788法令连贯但不等同实控**：1770-08-22所述仪式是库克航海记载的英国领土声索，Kaurareg传统土地证人质疑登岸升旗细节（详上一轮）。1788-02-07 Phillip殖民地王室委任状被宣读，所述东岸及西界135°E为**英国官方法理声索地理范围**，而当期实际种植/驻军集中于少数据点。应分三个独立对象：航海宣示、殖民政府委任、实地具名聚落。来源C3-AU-USYD-1788、C3-AU-SLNSW-COLLINS，空间语义禁止1790年将135E声索包络涂为占领面。''',
 'E18-D02.md':'''**制度与年度断点**：1787年出航、1788年1月抵Botany Bay与1月26日在Warrane/Sydney Cove营建不同；1788年2月7日还有殖民法律委任宣读（C3-AU-SLNSW-COLLINS）。英格兰、爱尔兰、苏格兰被流放者身份应按船籍单独核验，不能对整次第一舰队用多个来源统计相加。1788 Norfolk Island分站早期参与者15名犯人（9男6女）+7名政府员工的官方遗产口径仅适用于**该分遣队**，绝不加进第一舰队总押送人数而称独立船队。C3-AU-NORFOLK-DCCEEW。''',
 'E18-D03.md':'''**四个空间制度层**：①1788-01-26悉尼湾实际定居，②1788-02-07在港区进行殖民总督、法庭王室委任公示，③1788-03-06 Norfolk Island Kingston定点建站，④1788-04-24选定Parramatta、11-02建Rose Hill。2月7日王室委员会给出极广行政声索，是纸面法域，不能拿1788委任状经度数字绘成实际占领地图。殖民聚落与当地Eora、Burramattagal、Darug及Norfolk Island古波利尼西亚文化历史相互独立；分别标图层，不准把悉尼湾宣示的行政权跨到整个东澳。1788-02-07一手日记摘录来自澳大利亚悉尼大学C3-AU-USYD-1788，以及州立图书馆C3-AU-SLNSW-COLLINS。''',
 'E18-D04.md':'''**精确侵害与原住民行动（1788—1790）**：1788-12-31殖民海军人员在Manly Cove抓走Arabanoo，1789-05-18其因天花死于殖民地羁留期间（C3-AU-RYDE-ARAB）。1789-11-25 William Bradley带队以鱼饵诱捕Colebee(Cadigal)和Bennelong(Wangal)，可从Bradley当场描绘、州立图书馆历史介绍交叉核实（C3-AU-SLNSW-ABDUCT、C3-AU-RYDE-BEN）。Colebee逃脱，Bennelong于1790-05逃脱后，1790-09-07在Manly Cove总督Phillip被Willemering刺伤，报复解释存在争议；1790-10-08 Bennelong与双方再次自主接触，并非接受英国主权的条约（C3-AU-RYDE-SETTLE）。这些是**不同日期的独立事件**，其位置为现代海湾名称而非历史抓捕GPS。''',
 'E18-D05.md':'''**天花机制限制**：Arabanoo在1789年4月疫情中帮助照顾病人，1789-05-18本人因病死亡（C3-AU-RYDE-ARAB）。有关病原传播的蓄意与否、航海船只源流、其他族群曾有天花经历均未获原始流行病学档案统一证实；不应把疫情几何范围描画成有据军事攻击面。''',
 'E18-D06.md':'''**原住民自主与侵占点**：1790年殖民者对McIntyre案的两次报复性外出、1795年Hawkesbury军方行动必须分主体、驻军类别与各自来源。1790-09-07发生在Kayeemy/Manly的Willemering刺伤总督Phillip也与Pemulwuy于12月10日攻击McIntyre各自独立。两者不能因为殖民当局当时归为“土著攻击”而视作同一战役，更不能画出悉尼湾全部受军队占领的半岛。''',
 'E18-D07.md':'''**跨1799年重要续接**：Pemulwuy于1792年开始的持续抵抗未在1799自动结束。澳大利亚国家博物馆载1801-05-01政府发出可以射杀靠近Parramatta、Georges River与Prospect原住民的指令，1801-11对Pemulwuy发布奖励令，1802-06-02或此前被射杀、斩首寄往英国自然学家Joseph Banks。其杀害者身份未确证。1801/1802属于19世纪新事件，必须在同一抵抗系列保留父题关联，不可提前显示在1790年代。（C3-AU-NMA-PEMULWUY-1802）''',
 'E18-D08.md':'''**1794相互独立的暴力记录**：国家博物馆确认殖民人于Toongabbie报复战中砍下死去原住民战士的头并带回悉尼作为证明；未确认这具身体/具体遭袭田块位置、被斩首者名字时不要捏造。新的1791-07-18 Prospect Hill殖民者定居（C3-AU-NSW-PROSPECT）进一步提供农场侵入的先行时序，但不能将它们简单连为同一直接因果链。''',
 'E18-D09.md':'''**时间位置**：1797年Parramatta战斗与1794年Toongabbie战斗分开；1797年Pemulwuy中枪后逃脱，而非死亡。其人身及当地原住民抵抗在1800后仍延续（C3-AU-NMA-PEMULWUY-1802），不允许将1770王室声索变成每一年的澳洲无争议英国实控范围。''',
 'E18-D10.md':'''**原始契据冲突与逐步开垦**：1788-11-02 Rose Hill建农耕据点，1789-11 Ruse开始耕种，1791-07-18 Prospect Hill东南坡多个获得农田用地者（C3-AU-NSW-PROSPECT），1792-02-22原始资料在NSW档案NRS 898登记Ruse首份授地；同日St. Library原件还见Schaffer 140英亩与Varndell 30英亩土地契据（C3-AU-SLNSW-SCHAFFER、C3-AU-SLNSW-VARNDELL）。**强制争议框**：Parramatta市府年表写1791-03-30授Ruse；ANU传记称1791-04取得地权；原手写Ruse契据表头“1790”，州档与州立图书馆编目为1792并提示抄写错误争议。把“开始耕种/获得试用/签署契据/档案登记”分字段，不挑一个日子冒充所有动作，更不能用30/140英亩文本自行生成精确GIS多边形。源：C3-AU-MHNSW-RUSE、C3-AU-SLNSW-RUSE、C3-AU-ANU-RUSE、C3-AU-CITYPARRA-TIMELINE。''',
 'E18-F01.md':'''**法令逐年不能静态填色**：1727/1728年度的爱尔兰天主教自由保有地产选民资格受到剥夺，1793年恢复满足**40先令freehold**资格的天主教男性选民投票权；此权并非成年人普选，不等于可以担任议员（C3-IRL-PRONI-FREE）。地产法律从1772 61年农业改良租约、1778 999年租约，1782进一步允许部分土地取得与学校教学，到1792专业资格、1793选民资格渐改（C3-IRL-UHF-RELIGION）。**必须严格分开爱尔兰议会与大不列颠议会的1778/1791宗教宽免法**；源国别、法条及应用对象一致时才与地权数据连接。''',
 'E18-F02.md':'''**单向“英国统治”描述不够精确**：1720英国议会宣示对爱尔兰终审及立法权；爱尔兰下院1753年又争得政府财政余款一定控制，1779–80商业限制解除，1782大不列颠撤销1720法并改革Poynings法，爱尔兰议会取得内部立法独占权，行政仍由大不列颠政府委派的总督和首席秘书掌握（C3-IRL-UKPARL-KEY、C3-IRL-UKPARL-TERMS）。1783进一步主权争议解决详第二轮；1801议会联合才是新政治主体断点。行政控制、法律权与独立主权不能压成一个布尔值。''',
 'E18-F03.md':'''**跨世纪地理保护**：1707-05-01之前苏格兰独立王国不能归为大不列颠殖民地，Darien的Company of Scotland为苏格兰公司。1720英国议会统辖爱尔兰问题也不等于1707联合自动涵盖爱尔兰。英国与爱尔兰直到1801-01-01才合并。1707 equivalent款包括英苏财政等价与Darien投资偿付义务，不是1700年新达连“领土补偿区”。''',
 'E18-F04.md':'''**1746法、1748生效与1748—1769驻军网络**：Culloden战败1746-04-16；世袭司法权法编于20 Geo II c43（1746），第1条规定**1748-03-25**原司法特许多数终止（C3-SCO-LEG-1746、C3-SCO-NRS-COURTS）；保留某些男爵庭收租法权例外。新Ardersier Fort George于1748-06-11开建、1769完工，按HES官方建筑登记，自**1750年代就已有军人驻防**（C3-SCO-HES-GEORGE）。因此1748开工、1750年代驻军、1769完工是不同时间标签，不得称堡垒1769才首次驻军，亦不等于整个高地皆英国占领Polygon。''',
 'E18-F05.md':'''**避免以军政改革等同地产清场**：1748消除大部分世袭司法权并非1748某一高地村庄实际被驱逐，1748—1769 Fort George建设也不直接证明任何具体租地失去者名单。1792 Year of the Sheep抗议与1809后Sutherland大规模改造需按庄园/迁居账本分级，历史范围继续null。''',
 'E18-F06.md':'''**1798前公民权变化**：1793恢复天主教男性40先令自由保有地产选民资格（C3-IRL-PRONI-FREE）；因此不可以在1798年仍陈述“所有爱尔兰天主教徒绝对没有任何选举权”。1798运动主体包括不同信仰联合爱尔兰人，政府与起义者各自暴力需要分事件与档案。1801联合在下一世纪生效，不能在1798战争年绘爱尔兰作为统一英国的现代行政省。''',
 'E18-F07.md':'''**终点前1/2年断点**：1799-01-24爱尔兰下院拒绝联合动议；1800-03-28两院接受条款、1800-08-01王室批准、1801-01-01正式生效（C3-IRL-UKPARL-UNION）。同一法案分议案、立法批准与生效三步；1799地图持续显示爱尔兰王国单独议会。不得将议会贿赂/爵位承诺无条件称可经证金钱交易的总金额。''',
 'E18-F08.md':'''**数字证据陷阱**：英格兰银行、皇家非洲公司、达连公司、加勒比种植园或苏格兰土地融资多个机构同期存在，不足以编造具体股东—船只—庄园收益资金链。要把资本联系画为地图连线，须完整可追溯的董事/认股、航次货运、产权支付与年份证据四项链条；未核暂列研究问题。''',
 'E18-F09.md':'''**达连古纳原住民政治连续性**：1699-11苏格兰第二远征抵达→1700-01主动攻击西班牙Toubacanti→1700围困与投降撤离；1700年末未有继续占据Fort St Andrew苏格兰军队，需另保留古纳族群土地权并区别西班牙军事回应。1707仅产生联盟、公司赔付及制度后果，不能作为驻军继续的终止日。1700具体降约4/12、撤离起始4/13仍依第二轮论文摘要，原法西文/旧历待审。''',
 'HBC_1699_1713.md':'''**重大发现：1697—1713约克堡在法方**。Parks Canada国家历史遗址官方说明：York Fort于1697被法方重夺、改名Fort Bourbon，至1713《乌得勒支条约》法国撤出/归还。这意味着1700—1709的每一年，即使英国HBC自1670有Rupert特许，也不得将**此堡**标为英王/哈德孙湾公司实际驻军。另据同机构2007管理计划，1684—1715早期York Fort I与1788以后第三次York Factory III地理位置**不同**，不可以用今天国家遗址官方地图点定位1700年的堡址。记录到SITE_SPECIFIC_CONTROL_1697_1715.json；其他Albany、Moose、Rupert、Severn堡继续逐堡待核，并未因此一律判归法国。当地Cree/Dene贸易政治自由不因英法换旗而自动归法王。''',
 'AFRICAN_COMPANY_SLAVERY.md':'''**1796→1800马龙迁徙跨世纪链接**：加拿大公园局国家历史事件公告（C3-CAN-MAROON-PLAQ）证明1796年Trelawny Maroons遭从牙买加放逐并在7月抵新斯科舍，1800-09-30 HMS Asia到达Freetown时载177名妇女、151名男子、222名儿童。三数字合550，代表**这艘船具体到达口径**，不可倒填为1796当初全岛放逐总人数；1800跨入19世纪，不能用1799事件提前显示。此内容交助手1；负责跨世纪断点，不重复其牙买加主线。''',
 'JAMAICA_MAROONS.md':'''**跨到1800而非1799结束**：Parks Canada新斯科舍马龙国家历史事件资料C3-CAN-MAROON-PLAQ记：1796年4月Trelawny Town社区遭放逐，7月到Nova Scotia，持续请愿后于1800迁居Sierra Leone，9月30日HMS Asia于Freetown下锚，船上分妇女177、男子151、儿童222。另有少数Maroon留在新斯科舍，不可将1796强制迁移画成每名成员都于1800离开。人数为不同统计日期和分母，切勿重复累计。该事实属于与助手1的协作锚点。''',
 'IRELAND_LAND_1691_1704_1798.md':'''**三阶段判定**：1702/1704严厉法令→1772租期及1778大幅产权放宽→1782/1792专业法制与1793有限选举权恢复。对1798起义需展示不同政治诉求。官方北爱尔兰档案C3-IRL-PRONI-FREE有1727–1793及1793–1829选民资格分期；公民权限制不等于同一地理多边形的所有权状态，不能因一个单年法令重新涂整岛。''',
 'SCOTLAND_1700_1746_1780.md':'''**内战、司法、军事地点、清场不可合并**：1692格伦科惨案明确已结束；1700达连殖民停止；1707王国联合；1746 Culloden战役结束；1748-03-25大量世袭司法权停止；1748—1769 Ardersier新Fort George逐步建设及驻军；1780年代后高地地主租佃改造；1792牧羊驱逐抗议。每项分别一套行政主体、时间、地点与来源。法权退出也不等于某一个庄园当日迁徙开始。'''
}
for f,t in articles.items():append('TOPIC_DOSSIERS/'+f,t)
# User requested exact extended handoff across 1799 boundary; don't invent 1800 continent polygons.
save('BOUNDARY_1799_1800_HANDOFF.json',{'schema':'assistant-C-next-century-continuity-gates-v1','research_state':'research_only','is_1800s_production_atlas':False,'entries':[
 {'id':'B1800-IRISH-UNION','parent_topic_id':'E18-F07','old_last_18c_anchor':'1799-01-24 Commons failed union motion','after_1799':[{'date':'1800-03-28','action':'Irish parliament terms accepted'}, {'date':'1800-08-01','action':'Royal Assent to Union legislation'},{'date':'1801-01-01','action':'United Kingdom of Great Britain and Ireland begins; Irish Parliament abolished'}],'source_ids':['C3-IRL-UKPARL-UNION'],'map_status_1799':'Kingdom of Ireland with separate Parliament, no UK 1801','map_status_1800':'Kingdom of Ireland continues until 1801-01-01; do not foreshadow legislature dissolution','geometry_supported':False},
 {'id':'B1800-PEMULWUY','parent_topic_id':'E18-D07','old_last_18c_anchor':'1797 Pemulwuy survived wounds; resistance persists beyond 1799','after_1799':[{'date':'1801-05-01','action':'King colonial shoot-on-sight order'}, {'date':'1801-11','action':'individual manhunt reward proclamation'}, {'date':'1802-06-02_or_prior','action':'Pemulwuy killed and beheaded, sender to Banks; shooter unsettled'}],'source_ids':['C3-AU-NMA-PEMULWUY-1802'],'map_status_1799':'active indigenous resistance, no 1799 death marker','geometry_supported':False},
 {'id':'B1800-JAMAICA-MAROONS','parent_topic_id':'E18-A12','old_last_18c_anchor':'1796 deportation from Jamaica to Nova Scotia','after_1799':[{'date':'1800-09-30','action':'HMS Asia at Freetown; Parks Canada reports 177 women, 151 men, 222 children aboard'}],'source_ids':['C3-CAN-MAROON-PLAQ','C3-CAN-MAROON-MIGRATION'],'map_status_1799':'community in Nova Scotia after involuntary exile, not fully resettled Sierra Leone','geometry_supported':False,'handoff_owner':'assistant_1'},
 {'id':'B1800-HIGHLAND-CLEARANCES','parent_topic_id':'E18-F05','old_last_18c_anchor':'1780s first wave and 1792 Year of the Sheep','after_1799':[{'date':'1800–1820s','action':'later estate-level clearances require separate tenants/lands evidence'}],'source_ids':['S40'],'map_status_1799':'no generalized Highland clearance polygon or assumption all estates simultaneously cleared','geometry_supported':False},
 {'id':'B1800-HBC','parent_topic_id':'E18-C27','old_last_18c_anchor':'1713 York Fort transferred by Treaty; post remains single point network trade','after_1799':[{'date':'1800s','action':'Company continues; specific forts and Indigenous sovereignty must be separately traced'}],'source_ids':['C3-HBC-PARKS-YORK'],'geometry_supported':False,'handoff_owner':'assistant_1'}]})
# Dedicated in-depth narrative to travel with machine JSONs.
report='''# 第三轮深入调查｜现场实控、法律生效与原始档案矛盾

**研究状态：research_only；时间：2026-11-08；GitHub只读。**

## 一、1700—1709年约克堡新发现：法方Fort Bourbon，不是英方驻军

加拿大Parks Canada的York Factory国家历史遗址年表明确记录：1697年法军重新夺占原York Fort并重命名Fort Bourbon，法方占据直至1713年乌得勒支和约；商业公司声索和堡垒实控完全不同。其管理规划另识别York Factory I（1684—1715）、II（1715—1788）和III（1788—1957），今天遗址地理点一般是III，并非1699时期军事堡址。1700—1709年英方控制图层若将York Fort标作英国实际驻军，必须更正为法方堡垒独立标记（当前源只到具名地点；精确原址仍待历史堡址坐标核验）。

本地`SITE_SPECIFIC_CONTROL_1697_1715.json`保存10年逐年“官方遗址历史区间证实”的法方控制状态：不是十份独立驻防名册；1999参考虚线大Rupert流域仍不具实控证明。其他海湾堡垒Albany、Moose、Rupert、Severn、Churchill待逐堡审查，绝不因约克堡归法国而整个流域涂法国。来源C3-HBC-PARKS-YORK、C3-HBC-PARKS-PLAN。

## 二、1788殖民行为由法理宣示拆成至少四个独立时点

- 1788-01-26：Sydney Cove/Warrane实际立营。
- **1788-02-07**：Royal Commission及殖民法院执法文书公示。State Library NSW的David Collins专题、悉尼大学公开逐日引录的1788日记及NSW总督办公室官方讲话均支持当日，不能合并入1月26日。文书提及广大的纸面管理声索范围，实际据点另核。
- **1788-03-06**：Norfolk Island Kingston殖民副站，由澳大利亚政府遗产机关DCCEEW精确确认。
- 1788-04-24今Parramatta地择址，11-02 Rose Hill农耕据点建立；和Burramattagal/Darug土地关系另列。

由此建立`royal_claim`、`institutional_proclamation`、`physical_settlement`、`Indigenous_political_land`四种独立字段。只画文书地点与已证聚落点，绝不把135°E等委任书坐标生成为英国实际占领面。

## 三、三位被抓走的原住民：重新核日并记录能动性

州立图书馆和City of Ryde：Arabanoo于1788-12-31在Manly Cove遭强制抓捕，1789-05-18因天花去世；Bennelong与Colebee于**1789-11-25**同地遭殖民人员抓捕，William Bradley原始写生提供独立视觉证据。Bennelong于1790-05逃脱；1790-09-07 Willemering以矛刺伤Phillip，是否报复仪式属解释层；1790-10-08 Bennelong与双方重开自主交往。不得将这些史实压成“1789俘虏—1799被殖民者同化”的单线故事。C3-AU-RYDE-ARAB / BEN / SETTLE，C3-AU-SLNSW-ABDUCT。

## 四、殖民土地账簿难题：1791/1792同时保留

James Ruse早于1789-11就在Rose Hill耕种，Parramatta当地年表称1791-03-30“首次授地”，ANU传记称1791-04；但NSW官方State Archives以`NRS 898 [9/2731 p.2]`为据称首项授地登记于**1792-02-22**，州立图书馆收藏的SAFE/DLMSF37原手写契据日期写成1790而编目为`[1792]`、也承认是否抄写错误有争议。

本轮没选一个取代其他：C2-D10-002改为“1791地方报道、日期冲突、待审”，另立C3-D10-002记1792年档案登记；1789耕作单列。1792-02-22另有州图书馆Schaffer140英亩和Varndell30英亩原契据目录。面积为契据载明数字，不代表已知地籍GIS Polygon。1791-07-18 Prospect Hill殖民农户安置已从Heritage NSW找到具体开端，另独立地名候审点。

## 五、爱尔兰不应按1704全年禁令描述1798

PRONI官方选举资料显示1727–1793只有符合40先令freehold要求的新教徒有选举权，**1793起符合要求的天主教徒恢复投票权**，但无普选、议员任职权等推断。Ulster Historical Foundation逐项列1772年61年农业改良租约、1778年999年租约及地产限制宽免、1782进一步土地与教学变化、1792专业限制松动；英国议会官方资料印证1720→1782立法权转折及1753财政治理变化。必须分大不列颠1778宗教宽免和爱尔兰议会1778法案，不得混年份、混政体。

## 六、苏格兰1748转折由原始法案直接证实

英国官方立法数据库列`20 Geo II c43`，其第1条规定世袭司法权于**1748-03-25**消失（保留部分男爵收租等例外），而不是1746立法标题年份。Historic Environment Scotland新Fort George Ardersier官方记录证实1748-06-11开工、1769完成、1750年代起已有军人使用。三个不同时间口径不能涂成一个英军1769年才全面占有高地的地图。原国家史册详细存于C3-SCO-LEG-1746、C3-SCO-NRS-COURTS、C3-SCO-HES-GEORGE。

## 七、1799→1800跨世纪不断线

- 1799爱尔兰下院拒联合，1800接受并通过，**1801-01-01**《联合法》生效。不得把1798起义地图预先标为现代英国行政区（C3-IRL-UKPARL-UNION）。
- 1792—1799 Pemulwuy抵抗系列于1801-05-01出现殖民政府射杀令，1801-11悬赏令，1802-06-02或此前被杀并斩首，杀人者尚有争论。1797被击中不是结束（C3-AU-NMA-PEMULWUY-1802）。
- 1796牙买加Trelawny Town Maroons被放逐至新斯科舍；**1800-09-30**加拿大国家公园局记HMS Asia到Freetown时船上177名妇女、151名男子、222名儿童——这是1800船上口径，不能挪作1796流放全员口径；有人留在新斯科舍（C3-CAN-MAROON-PLAQ）。只作助手1接棒锚点。

## 证据等级与地图限制

截至本轮：原卷多数为官方档案目录/原文网页转录，未亲自翻阅全部纸本；Parks Canada区间控制具有可靠官方史迹陈述，但并非逐年10份驻军登记；部分1700达连精确降约日历和1791土地文书仍待原卷交叉查验。新增地点均`geometry:null`，旧3个现代参考点未改变。完整证据清单详`ROUND3_EVIDENCE_CONFLICTS.json`、`SITE_SPECIFIC_CONTROL_1697_1715.json`、`CLAIM_EVIDENCE_MATRIX.json/.csv`。
'''
(P/'ROUND3_DEEP_RESEARCH.md').write_text(report,encoding='utf-8')
# Extend period gap and status statements with no duplicate sections.
append('MISSING_TOPICS.md','''### 第三轮特别缺口（新增）

1. **约克堡/法方Fort Bourbon**：需要Hudson Bay Company Archives、法国1697–1713堡垒军政日记、1750之前原堡址考古图；不能把现代York Factory III遗产点拿来标1700 Fort Bourbon。Albany/Moose/Rupert/New Severn/Churchill逐堡核1700–09，助手1负责所在北美地图。
2. **NSW地权正式登记日期重大分歧**：Ruse 1790手写契据、1791地方年表/ANU、1792州档NRS898必须并列核原始Phillip来往文书及NRS1215 register。1791 Prospect Hill地契逐宗位置未核；Schaffer/Varndell 1792契据面积目前无法反演地界。
3. **1770与1788行政声索边界**：Royal Commission文本的经纬数与1770库克宣示都只代表王室纸面地权主张，必须核实际据点/警备和原住民Country体系；绝不能直接画整个东澳殖民面。
4. **苏格兰司法权归并1748**：25 March是法案第1条生效；法庭文件RH11和各郡发放薪俸/实际换官年逐查。新Ardersier Fort George的1750年代真实驻军首次年待原始军饷册，不能让1769完工误作首次驻军。
5. **爱尔兰1772/1778/1782/1792/1793法规**：逐项核原法条、适用地区、宗派、实际选举登记，不能将书面允许购地自动变成某个郡县宗教人口或地权占比。
6. **1800年不得从18C截止丢失的人与机构**：Pemulwuy 1801–1802、爱尔兰1801议会合并、牙买加Maroon迁1800、苏格兰19C清场延续：见`BOUNDARY_1799_1800_HANDOFF.json`。
''')
# update multiple documentation once, idempotent marker same as dossiers.
summary=f'''### 第三轮（2026-11-08）

- 新增逐堡独立研究`SITE_SPECIFIC_CONTROL_1697_1715.json`：加拿大公园局证实York Fort(1697–1713)法方Fort Bourbon，原27块参考层的Rupert虚线**不能转为英国实控**；1700–1709十年有法方局点存在的机构史料区间、无逐年驻军名册/真实古堡GPS。
- 事件累计**{len(E['events'])}**（原89，新增21，另修订4个旧事件的日期与来源）；来源总计**{len(S['sources'])}**（原87），地理参考地点共31（Point仍仅3，其余null）。`CLAIM_EVIDENCE_MATRIX`共{len(M['claims'])}条。旧36专题、27×10=270条年份审核槽位均保留。
- NSW州档/州立图书馆揭露Ruse农田使用、1791地方授地叙述与1792-02-22正式记录的冲突；`ROUND3_EVIDENCE_CONFLICTS.json`已明确解决框架。Arabanoo 1788-12-31、1789-05-18，Bennelong/Colebee 1789-11-25经来源交叉核日。
- 爱尔兰1793有限天主教选民资格恢复、苏格兰世袭司法权1748-03-25生效、1748–1769Fort George逐步驻军建设均新增具年候审节点与19篇D/F专题升级。
- `BOUNDARY_1799_1800_HANDOFF.json`防止把Pemulwuy 1802被杀、英国爱尔兰1801合并、马龙1800西非迁徙提前至1799。所有仍仅`research_only`；本地未修改GitHub。
'''
for path in ['PROGRESS.md','README.md','CONTROL_RELATION_DECISION_GUIDE.md']:
 append(path,summary)
# update csvs after final source links and claim row updates.
for fn,values,fields in [('EVENT_CANDIDATES.csv',E['events'],['id','topic_id','date','date_precision','title','actor','action','historical_place','source_ids','research_state','cartographic_status','geometry_ref','historical_control_polygon_approved','evidence_notes']),('CLAIM_EVIDENCE_MATRIX.csv',M['claims'],['id','date_or_range','claim_summary','source_ids','access_type','audit_limit','map_eligibility','original_folio_personally_inspected'])]:
 with (P/fn).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
  for x in values:w.writerow({k:';'.join(x.get(k,[])) if k=='source_ids' else x.get(k,'') for k in fields})
print('R3 narrative finalized:',len(S['sources']),'sources',len(E['events']),'events',len(M['claims']),'evidence assertions')
