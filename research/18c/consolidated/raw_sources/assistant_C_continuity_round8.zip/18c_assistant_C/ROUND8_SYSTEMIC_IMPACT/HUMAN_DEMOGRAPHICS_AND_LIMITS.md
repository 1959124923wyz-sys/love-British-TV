# 人口变动的可证与不可证：爱尔兰饥荒、悉尼天花和Hawkesbury拓殖

**阶段：research_only，供史学和制图审核。**

1795年Hawkesbury至少约500名殖民定居者，1799年末报告1008名，证明欧洲移居者数量增长。但同期原住民人口计数与土地精确范围未能核实，不应从1008反推原住民死亡/被驱人数。

1789年悉尼附近原住民群体经历小痘疫情；国家博物馆将部分受影响社群死亡上限称为70%，不是整座澳洲全部原住民70%。2026年新的流行病统计模型支持东南澳来源假说，模拟某些条件下损失220000人，但此数是模型结果而非1789年户口或具名死亡登记。两组数不能合并。爱尔兰1740—41年310000—480000死亡也是学者估算，和澳洲小痘完全不同分母。

## 对应材料

- `C6A-AU-TOWARDSTRUTH-HAWKES` — Hawkesbury River 1795–1800: violence and land occupation; https://www.towardstruth.org.au/themes/country/dispossession/120-frontier-wars/sub0533-hawkesbury-river
- `S22` — Smallpox epidemic of April 1789; origin contested; https://www.nma.gov.au/defining-moments/resources/smallpox-epidemic
- `C8-S16` — Stochastic smallpox spread models Indigenous Australians; https://pubmed.ncbi.nlm.nih.gov/42426264/
- `C8-S04` — Engler et al. Irish famine 1740–1741, climate migration; https://cp.copernicus.org/articles/9/1161/2013/index.html
- `C7-S12` — Review of Famine in European History, Irish 1740–41 mortality estimates; https://www.cambridge.org/core/journals/international-review-of-social-history/article/famine-in-european-history-ed-by-guido-alfani-grada-corman-o-cambridge-university-press-cambridge-etc-2017-xi-325-pp-maps-6999-paper-2399/102EC302166801BD24D6AB0650EDF798

**制图规则：** 没有古代地籍/军事实控边界时只记事件或具核地点；财税份额、人口比率、王室特许均不得转换成历史实控Polygon。
