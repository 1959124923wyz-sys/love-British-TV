# 澳大利亚：王室授地授权与原住民土地未获承认

**阶段：research_only，供史学和制图审核。**

1768年Cook的航海指令提及经当地原住民同意占取合适地点的条件，1787年Phillip的总督指示保护原住民生命并期望友好相处，却没有把他们的土地权作为英方殖民产权的有效基线。英国法律和殖民勘测直接赋予总督土地特许权，给获释罪犯、军人和自由移民。授权虽可称制度性土地掠夺通道，实际地籍与已定居范围必须另证。

Ruse农场尤其能够展示法律对象差异：历史占用始于1789，获得土地记录在1791前后，1792-02-22进入正式登记；旧契据上的1790年文字被有馆藏记录的学者质疑。不得将单份地契当作已经同意的Burramattagal地权让渡，更不可将NSW王室书面权力全涂成实占面。

## 对应材料

- `C8-S12` — Indigenous recognition chronology Cook instructions and retrospective terra nullius; https://www.aph.gov.au/About_Parliament/Parliamentary_departments/Parliamentary_Library/Research/Chronologies/2021-22/IndigenousChronology
- `C7-S05` — 1787 instructions and purported NSW colony legal bounds; https://www.migrationheritage.nsw.gov.au/exhibition/objectsthroughtime/draughtinstructions/index.html
- `C3-AU-MHNSW-LAND` — Land grants guide 1788–1856; https://mhnsw.au/guides/land-grants-guide-1788-1856/
- `C8-S13` — Brief History of Registrar General records first Ruse grants; https://www.nswlrs.com.au/assets/f/1129775276948026/56e6e828d4/brief_history_of_rg_records.pdf

**制图规则：** 没有古代地籍/军事实控边界时只记事件或具核地点；财税份额、人口比率、王室特许均不得转换成历史实控Polygon。
