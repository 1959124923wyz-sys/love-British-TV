# 澳大利亚：1790—1799官方报复、军事护地与定罪后赦免

**阶段：research_only，供史学和制图审核。**

1790年Phillip因McIntyre遭刺伤向军队下令抓12杀10并取首级；军官Tench促成修订抓6或杀6。两次出击最终未抓到或杀死原住民——「官方命令」强证，「按命令执行了六名死者」为错误。1795年Paterson正式派出62士兵前往Hawkesbury确保殖民农田所有，官方报告致死7–8人、俘5人。政府直接命令和报告的衔接比单纯私人冲突更能判断国家参与。

1796年Hunter禁止定居者随意杀害原住民，又在1797特定条件下允许开枪；政府命令在不同年份和条件下存在矛盾。1799年两名原住民男孩被定居者杀害，法院判罪但先放人，1802年获王室赦免。这是可追溯的特定处罚落空样本，比笼统「英国全体默许所有屠杀」更能精确表达制度和执行问题。

## 对应材料

- `S21` — Initial confrontation; Arabanoo, Colbee, Bennelong; https://towardstruth.org.au/themes/country/dispossession/120-frontier-wars/sub0194-initial-confrontation-and-resistance
- `C6A-AU-TOWARDSTRUTH-HAWKES` — Hawkesbury River 1795–1800: violence and land occupation; https://www.towardstruth.org.au/themes/country/dispossession/120-frontier-wars/sub0533-hawkesbury-river

**制图规则：** 没有古代地籍/军事实控边界时只记事件或具核地点；财税份额、人口比率、王室特许均不得转换成历史实控Polygon。
