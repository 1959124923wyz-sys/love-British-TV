# 澳大利亚：强迫运输、劳役体系与人口健康后果

**阶段：research_only，供史学和制图审核。**

1787—88第一舰队及随后1790第二舰队的运输是英国国家设立的流放劳动力机制。新南威尔士州立图书馆指出，第二舰队约1250名男性囚犯中超过四分之一死于旅途中，Neptune、Scarborough和Surprize三艘的航行死亡率另记26%。这些是不同分母/时间窗的资料，不能加到一起。登陆后大量生病人员接受紧急救治；后续死亡的统计起算必须确立存活分母。

人口运输与土地配给共同扩张，1791年爱尔兰囚犯Queen抵港，为爱尔兰司法体系向新南威尔士转移人口开端。统计必须保留罪犯船旗、性别、刑期以及实际抵港人数，禁止把1853年底累计被运输人数全部算进18世纪。

## 对应材料

- `C8-S14` — Convict survival Second Fleet 1790; https://www.sl.nsw.gov.au/learning/challenges-convict-survival/disease-and-medicine
- `C7-S01` — Second Fleet convict deaths, 1790; https://guides.sl.nsw.gov.au/convicts-bound-for-australia/second_fleet
- `C7-S03` — Transportation of Irish convicts 1791–1853 research guide; https://nationalarchives.ie/wp-content/uploads/2025/01/Ireland_Australia_transportation.pdf
- `C8-S15` — Sentenced beyond the Seas Queen transport 1791 first Irish; https://mhnsw.au/guides/sentenced-beyond-the-seas-australias-early/

**制图规则：** 没有古代地籍/军事实控边界时只记事件或具核地点；财税份额、人口比率、王室特许均不得转换成历史实控Polygon。
