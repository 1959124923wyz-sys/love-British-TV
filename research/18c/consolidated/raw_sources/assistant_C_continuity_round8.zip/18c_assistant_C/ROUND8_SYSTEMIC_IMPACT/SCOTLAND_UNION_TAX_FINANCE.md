# 苏格兰：1707财政联合、殖民市场准入与1725抗税镇压

**阶段：research_only，供史学和制图审核。**

1707年联合条约Article 4直接将英格兰海外殖民地贸易向新大不列颠的苏格兰臣民开放，是制度性经济收益的明确法律基础。Article 15的£398085 10s Equivalent同时解决英格兰国债义务、旧政府薪资及达连投资人损失，不能全算赔偿达连的纯殖民利润。苏格兰国家记录保存1707年首笔到账与工资支付账目。

1725年苏格兰麦芽税引发城镇示威和酿酒商停工，格拉斯哥Shawfield事件中学术研究称士兵杀死八位平民。须继续收集士兵开枪的具体日、命令和受害者名单。该案证明财政法令存在可记录的社会冲突，但不能因此把苏格兰整国史写成「同一种殖民地被征服」。

## 对应材料

- `C2-UNION-ART` — Articles of Union 1707, Article 15; https://www.scottisharchivesforschools.org/union1707/chapter3-3.asp
- `C2-DAR-CHRONO` — The Darien Scheme: Second expedition; https://www.nms.ac.uk/discover-catalogue/the-darien-scheme
- `C8-S06` — Equivalent Societies and early Scottish financial revolution; https://www.cambridge.org/core/journals/journal-of-british-studies/article/equivalent-societies-of-edinburgh-and-london-the-formation-of-the-royal-bank-of-scotland-and-the-nature-of-the-scottish-financial-revolution/5A2961F1484B06F674F1FBA7B0BD01C1
- `C8-S08` — Scotland in American Colonies trade Navigation Acts 1690 records; https://www.nrscotland.gov.uk/learning-and-events/all-features-and-articles/the-experiences-of-scots-in-the-american-colonies/

**制图规则：** 没有古代地籍/军事实控边界时只记事件或具核地点；财税份额、人口比率、王室特许均不得转换成历史实控Polygon。
