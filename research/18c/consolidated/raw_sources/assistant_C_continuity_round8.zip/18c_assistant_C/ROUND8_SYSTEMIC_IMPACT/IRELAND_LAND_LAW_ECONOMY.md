# 爱尔兰：地权、宗教及贸易限制如何相互强化

**阶段：research_only，供史学和制图审核。**

1699年毛纺织品对外出口禁令清楚表明英国议会以保护英格兰毛纺织业为由，限制爱尔兰王国的合法出口市场。此法律名为Wool Act 1698，禁令日期从1699年6月24日起算。英国议会官方说明同时指出其即时经济效应不宜被无限夸大。本次将其视为明确的经济保护主义政策，而不是虚构的全国制造业失业总数。

1703—1704年的爱尔兰王国议会刑法体系把天主教地产取得、继承、教育、监护与公职权利连接起来。1727年进一步明确剥夺县郡天主教选举权，直到1793年才逐步恢复。这里的立法主体首先是爱尔兰王国的议会，英王及英国政府影响另设字段；不要倒装为当时已存在联合王国内的现代北爱行政区。

经济和政权效应必须区分：法定排斥存在，但旧地主拥有的土地比例变化还受到先前战乱没产、继承法、宗教改宗、家族信托、租赁规避及市场交易影响。文献流行的1704约14%和1776约5%是学术估算，不是本轮GIS测量。1778年法案大幅缓和地权限制，1782年又有宗教教育放宽，不能把限制延长到1800而没有变化。

## 对应材料

- `C8-S01` — Wool Act 1698 (10 Will III c.16), 1699-06-24 commencement; https://www.legislation.gov.uk/aep/Will3/10/16/enacted/data.xht?view=snippet&wrap=true
- `C5-UK-PARL-IRISH-1720` — Constitutional differences: March 1720 Declaratory Act; https://www.parliament.uk/about/living-heritage/evolutionofparliament/legislativescrutiny/parliamentandireland/overview/constitutional-differences/
- `S53` — Making of penal law 2 Anne c6, 1703–4; https://www.cambridge.org/core/journals/irish-historical-studies/article/abs/making-of-a-penal-law-2-anne-c6-17034/BFF887B070C7357A2D7A26C2AA2E9E45
- `C8-S02` — Research Paper 13/14 Catholic Irish county electorate 1727–1793; https://researchbriefings.files.parliament.uk/documents/RP13-14/RP13-14.pdf
- `C3-IRL-CAM-RELIEF` — Robert E Burns, Catholic Relief Act in Ireland 1778; https://www.cambridge.org/core/journals/church-history/article/abs/catholic-relief-act-in-ireland-1778/00046185A6727830F62990B4BB170D6E
- `C8-S03` — Eamon O’Flaherty Dismantling Irish penal laws, 1774–82; https://www.cambridge.org/core/journals/irish-historical-studies/article/abs/ecclesiastical-politics-and-the-dismantling-of-the-penal-laws-in-ireland-177482/F2661777B964E395DF52D42680441C9A

**制图规则：** 没有古代地籍/军事实控边界时只记事件或具核地点；财税份额、人口比率、王室特许均不得转换成历史实控Polygon。
