# 爱尔兰：1798国家镇压、军事强取与海外流放

**阶段：research_only，供史学和制图审核。**

英国国家陆军博物馆记录1798年国家反叛乱力量采用大规模抓捕、鞭打、焚屋和军事占据。爱尔兰国家档案馆1798年5月16日军事书信的说明载有「free quarters」强制住宿及征用供给等集体惩罚方式。国家陆军博物馆又馆藏1798年6月2日Lake将军命令：维持严厉军事惩罚的同时限制士兵未经军官许可焚毁财产、擅自入屋。必须把「有据的官方军事策略」与「命令明令禁止的越权暴行」分别记账。

爱尔兰王国1786海外流放法、1790修订、1791首船Queen自Cork启航，在制度上把爱尔兰的司法刑罚连接到澳大利亚殖民劳动力需求。1798年起义后至少300人获得海外运输判决的国家博物馆数据属于跨年司法结果，不能当成1798年立刻抵澳人数。1804年的澳大利亚Castle Hill起义是19世纪后续专题，不得塞回1799地图。

## 对应材料

- `C6-IRL-NAM-1798` — Irish Rebellion 1798 revised narrative and Crown/loyalist reprisals; https://www.nam.ac.uk/explore/irish-rebellion-1798
- `C8-S05` — Hewitt General Orders 1798–1801 accession NAM.1985-12-15-8; https://collection.nam.ac.uk/detail.php?acc=1985-12-15-8
- `C7-S03` — Transportation of Irish convicts 1791–1853 research guide; https://nationalarchives.ie/wp-content/uploads/2025/01/Ireland_Australia_transportation.pdf
- `C8-S15` — Sentenced beyond the Seas Queen transport 1791 first Irish; https://mhnsw.au/guides/sentenced-beyond-the-seas-australias-early/
- `C7-S04` — Castle Hill rebellion and 1798 Irish exiles; https://www.nma.gov.au/defining-moments/resources/castle-hill-rebellion

**制图规则：** 没有古代地籍/军事实控边界时只记事件或具核地点；财税份额、人口比率、王室特许均不得转换成历史实控Polygon。
