# 苏格兰奴役经济：港口、信用、商人及司法档案

**阶段：research_only，供史学和制图审核。**

1707年后殖民市场准入与苏格兰商贸机构的扩张构成历史结构性联系。1769年克莱德河三港占当年英国烟草进口52%，与美国切萨皮克由被奴役者劳动生产的烟草具有经济关系；这里不能把52%错算奴隶航次、全部收益或强迫人口。牛津学术论文给出该贸易份额和信贷机制。格拉斯哥大学证明苏格兰商人、医生、种植园所有人和出口制造商都参与经济网络，不只是本地出港奴隶船。

苏格兰国家档案馆提供1721/1727年海事法院与运奴船东之间的诉讼案卷号，及1731年格拉斯哥商号往来信件，证明这类活动通过私商合同、司法债权网络形成常规商业业务。仅凭有官司不能推断法院判决支持哪一方或政府参与单次捕奴；这些案卷下一步应查原手稿。苏格兰参与东印度公司的人才网络也是海外经济扩张，但地区主责由助手2进行。

## 对应材料

- `C7-S26` — Glasgow tobacco trade and enslavement, import 1769 52%; https://academic.oup.com/ajlh/article/63/2/150/7231728
- `C8-S09` — Sugar in our Tea Scotland and Slavery; https://www.gla.ac.uk/schools/humanities/research/historyresearch/sugarinourtea/introduction/
- `C8-S10` — Slavery and the slave trade case files AC9/718 AC9/1022 AC9/1042; https://www.nrscotland.gov.uk/learning-and-events/research-guides/slavery-and-the-slave-trade/?section=enslavement-in-africa-and-slave-trade-voyages
- `C8-S11` — Scots and empire in Asia c1695–1813; https://academic.oup.com/book/12634/chapter-abstract/162554777

**制图规则：** 没有古代地籍/军事实控边界时只记事件或具核地点；财税份额、人口比率、王室特许均不得转换成历史实控Polygon。
