# 爱尔兰：1740—1741饥荒、税赋与农村反抗

**阶段：research_only，供史学和制图审核。**

1740—1741年爱尔兰出现大规模饥荒，由极端寒冬、农业减产、粮价与社会脆弱性共同造成。学术评论援引的310000—480000人死亡是估算值；人口资料不足使误差很大，应与1845—1852年大饥荒严格分开。不能把严寒当作英国施行的特定蓄意政策。研究重点是土地权不平等、佃户资源和救灾应对怎样增加脆弱性，而这些因果环节尚需财政赈济原账核实。

1761年末Whiteboys在Knockmealdown山麓出现，对公地圈占、地租和什一税承包人的收费举动反抗。主体是当地农民结社、地主、宗教什一税承包人和政府；运动并非单场英国王室军战役，也不能不审地方身份就把全部反抗解释为单一民族起义。

## 对应材料

- `C8-S04` — Engler et al. Irish famine 1740–1741, climate migration; https://cp.copernicus.org/articles/9/1161/2013/index.html
- `C7-S12` — Review of Famine in European History, Irish 1740–41 mortality estimates; https://www.cambridge.org/core/journals/international-review-of-social-history/article/famine-in-european-history-ed-by-guido-alfani-grada-corman-o-cambridge-university-press-cambridge-etc-2017-xi-325-pp-maps-6999-paper-2399/102EC302166801BD24D6AB0650EDF798
- `C7-S10` — Whiteboy movement, 1761–65; https://www.cambridge.org/core/journals/irish-historical-studies/article/abs/whiteboy-movement-17615/51FA8CC01E50A1784078B5A38581D400

**制图规则：** 没有古代地籍/军事实控边界时只记事件或具核地点；财税份额、人口比率、王室特许均不得转换成历史实控Polygon。
