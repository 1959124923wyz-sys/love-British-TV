# 苏格兰高地：治安立法、财产没收与农业资本化

**阶段：research_only，供史学和制图审核。**

1746年禁止法规定高地部分郡县居民缴械：可以罚款、监禁；法定某些欠缴罚金、适于服役者可被转送美洲军事服务。服饰禁令虽属1746年法案第17条，但到1747年8月1日才开始；二次定罪有海外强制流放七年的法定选项。需要对应法院案卷才能判断实际裁定数量。

1747没产调查及1752附属庄园管理使政府依法征租并安排收入，档案记载53处曾被调查，其中12处判为非没产，最后只有部分指定庄园可作王室治理收入范围。史学研究将1780年代起的高地清场与收益率更高的牧羊、农田重组相联系；地主、经纪人与中央政府不同项目的行为不应被混写成一条遍及全高地的英国官方「清场令」。1809—1821年Sutherland大清场属于19世纪。

## 对应材料

- `C8-S07` — Act of Proscription 1746 / 19 Geo II c39 transcription; https://www.scottishhistory.org/resources/act-of-proscription-1746/
- `C4-SCO-NRS-ESTATE` — E738 Forfeited Estates 1745: particular estate series Arnprior, 1747 Vesting, 1752 annexing; https://catalogue.nrscotland.gov.uk/nrsonlinecatalogue/details.aspx?reference=E738
- `C2-SCO-CLEAR` — Highland Clearances first wave and limitations; https://scottishhistorysociety.com/the-highland-clearances/

**制图规则：** 没有古代地籍/军事实控边界时只记事件或具核地点；财税份额、人口比率、王室特许均不得转换成历史实控Polygon。
