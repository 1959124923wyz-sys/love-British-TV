# 第五轮深入调查｜三世纪历史连续性、澳大利亚、爱尔兰、苏格兰

研究状态：`research_only`；2026-11-08；GitHub只读；原始档案馆目录与经过编辑的影印并不等同已翻检原件。

## 一、1699/1700关键控制位点

| 位点 | 1699—1709可靠阶段判断 | 禁止自动延续/问题 | 主要来源 |
|---|---|---|---|
| York Fort / Fort Bourbon (Hayes River) | 法方1697夺取，直至1713年和约变化 | HBC 1670特许不等于此堡持续英国驻军，旧址与现代York Factory III区别 | C5-HBC-PARKS-YORK, C3-HBC-PARKS-YORK |
| Churchill River | 1689短命HBC商站起火消失，1717才较稳定重建 | 1700—1709不能自行推定英方现役驻守 | C5-HBC-PARKS-CHURCHILL, C5-HBC-PARKS-CAPEMERRY |
| Albany Fort | 英商站仍存，1709曾受法方袭击 | 仅堡核心点；非哈德孙湾流域实占 | 见四轮SITE_SPECIFIC_CONTROL_1697_1715.json |
| Newfoundland St John’s Fort William | 1705年法方攻击未夺，1708旧历/1709新历攻陷并毁坏 | 一次攻陷、双历日期；1709年末复驻军必须另外证明 | C5-CAN-DCB-LLOYD, C5-NFL-HERITAGE-WAR |
| French Plaisance/Placentia | 1713年转移前为法方据点 | 官方资料一句概述有时间压缩，不能在1713前判英国实控 | C5-NFL-HERITAGE-WAR |
| New Edinburgh, Darien | 1699第二批抵达、1700投降结束 | 苏格兰公司；古纳自主，17C旧文章截止1699并非真实结尾 | C5-SCOT-NLS-DARIENPAPERS, C2-DAR-2025 |

YEAR-END的逐年格子仅把已证历史区间应用于各年；绝不是每一年有独立点验驻军的原档。见ROUND5_SITE_YEAR_DECISION_MATRIX_1699_1710.json。

## 二、苏格兰Darien与1707年联盟

1849年印行的Darien Papers选录提及1700-03-18/21议事与委任，后续投降4月阶段独立。1707-01-16苏格兰议会以110票对67票批准条款；1707-03-06英格兰立法获御准；1707-05-01大不列颠王国成立。期间爱尔兰保留自己的王国议会。以合同、贸易与债权追述达连经济后果，不画作1700后当地苏格兰实控面积。来源 C5-UK-PARL-UNION-RATIFY, C5-UK-PARL-UNION-HOUSE, C5-SCOT-NLS-DARIENPAPERS。

## 三、1770—1799澳大利亚当地政治与殖民扩张

1770-08-22 库克航海日志宣示有直接文字源；NMA某时间线写1770-09-13，标注为冲突源；澳大利亚博物馆与Kaurareg传统土地持有人对实际登岛升旗有所异议。1770年东岸不得涂英国实际占领。1788-01-18 Botany Bay到达与1788-01-26在Warrane/Sydney Cove设站分开。1789 Rose Hill小麦耕作、1791年末政府农场>200英亩仅能证明局部农耕，不能由英亩绘制地契Polygon。1794/1795 Hawkesbury殖民侵入与本地反抗、惩罚行动按各地方角色呈现，不将所有河流反抗归于Pemulwuy。原住民政治主体与殖民机构在同年并存。来源 C5-AU-NLA-COOK, C5-AU-MUSEUM-CONTEST, C5-AU-SLNSW-FIRSTFLEET, C5-AU-SLNSW-FIRSTFARMS, C5-AU-HAWKESBURY-COUNCIL。

## 四、爱尔兰1720—1801法律与军事断点

1720年3月 Declaratory Act 强化伦敦议会对爱尔兰立法和上诉权；1782年英国废除限制并改造Poynings Law制度，爱尔兰议会仍与英国任命行政机构并存。1798年军事行动要区分都柏林组织遭拘捕、Wexford New Ross、Arklow、Foulkesmills、Vinegar Hill、法军Killala登陆与9月残余抵抗。国家档案馆1798史料配套及NLI两幅当时战场图均建立目录；地图尚未取得可校正的原图像素和元数据，不画精确军阵。Killala登陆日有22/23日冲突，事件日期退为月份。1799英爱联合提案初遭否决；1800通过、1801生效属于19C，不提前投射。来源 C5-UK-PARL-IRISH-1720, C5-UK-PARL-IRISH-1782, C5-IRL-NAI-1798, C5-IRL-NLI-TAYLOR-MAP, C5-IRL-NLI-HARDY-MAP, C5-UK-PARL-IRISH-1799。

## 五、苏格兰1746法制与1748起效

1746年Tenures Abolition与Heritable Jurisdictions两法不能因为有共同的1748-03-25重要生效日而合并一个法令。氏族辖区的实际军事镇压、没收各处产业和后续高地牧场资本主义经营，须分别按庄园核对。不将19世纪Sutherland大清场投射1790年代。来源 C5-UK-LEGIS-TENURES, C3-SCO-LEG-1746。

## 六、仍阻碍实控Polygon发布的档案问题

1. 1699各堡点位/年末驻军的原始名册与换旗真实日期；Parks Canada公布的是区间历史，不是每年逐堡兵员原卷。
2. 达连 Fort St Andrew 本体、西班牙围城及Guna主权区域没有可核准1720以前历史界线。
3. 1798 NLI L368/L391军事地图尚未根据原图实测控制点做空间配准；历史图可研究不等于现代精准战线。
4. Parramatta/Hawkesbury小田地、征用地契和古纳/Gadigal/Darug实际领地界线未独立核证。
5. 岛屿、海湾、航线和18世纪英方省级特许研究几何保持研究层，不能计殖民实际土地面积。

伴随审计：ROUND5_EVENT_DEDUP_REVIEW.json、ROUND5_PRE_POST_18C_ANCHORS.json、ROUND3_EVIDENCE_CONFLICTS.json、HISTORICAL_MAP_SOURCE_CATALOG.json。
