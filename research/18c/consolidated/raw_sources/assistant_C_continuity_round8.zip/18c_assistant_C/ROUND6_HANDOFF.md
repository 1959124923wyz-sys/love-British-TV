# 爱英TV助手3｜第六轮主编及调查员交接（研究候审）

**统一版本：2026-11-08。资料只在本地ZIP；GitHub无修改。主编使用研究ID时须重新分配正式 Atlas ID。**

## 读取顺序

1. `ROUND6_DEEP_RESEARCH.md`：本轮新增研究、责任划分和史料限制；
2. `ROUND6_QA_REPORT.json`、`ROUND6_INDEX.json`：核对文件/数量/唯一ID与审查结果；
3. `ROUND6_LOCAL_CONTROL_EPISODES.json`、`ROUND6_1798_LOCAL_REGIME_DECISIONS.json`：先审时期和控制关系，再做地图；
4. `ROUND6_1699_1710_SITE_IDENTITY_GRID.json`：原York I/II/III、丘吉尔1689/1717据点身份及逐年候审；
5. `ROUND6_LEGAL_PRECISION.json`：英格兰1702 vs 爱尔兰1704法律、英苏1707政治转折；
6. `ROUND6_HAWKESBURY_1794_CASE.json`：1794 Bediagal惨案与1795军队政策分期；
7. `CROSS_CENTURY_AUDIT.json`、`CONTROL_TRANSITIONS_1699_1709.json`、`TOPIC_DOSSIERS/`：完整上期全系列与证据链。

## 优先级1：决不可错误绘制的控制区

- **1700 York Factory：** 1697法国夺堡之后名Fort Bourbon；1699—1713不当英方实际驻军；且其地理位置是York Factory I，不能使用今天York III遗址GPS追溯1700年占地。资料见加拿大公园局York规划。
- **1700 Churchill：** 1689首次HBC驻点当年被毁，1717重建；1700—1709不能继续显示旧堡持续存在。Cree/Dene/Inuit地方主权与商馆是两类对象。
- **1707 Scots：** 1707年5月1日前苏格兰王国与英格兰不是一个统一国家，1707后贸易权益开放不是全世界英国殖民地实控增量；法院/法律仍有苏格兰单独制度。
- **1770 Australia：** 库克英国声索不能覆盖大陆/原住民本有土地；1788仅核得悉尼湾等小规模据点及后续扩张；实际营地几何仍待调查。
- **1798 Wexford：** 起义军曾控制Wexford town、Enniscorthy，但New Ross、Arklow政府军守军获胜；不能把整个County Wexford画成起义军区域。Carnew地区资料有冲突，先不赋实占状态。

## 优先级2：精确日历/责任/历史行为

- 1704年爱尔兰议会法和1702年英格兰议会法按立法机关、法条、执行另分；1707条款Article 15的Equivalent总额并非达连个人获得现金数。
- 1794年9月Dyarubbin/Hawkesbury：殖民者对Bediagal人致命报复，不可与1795年殖民政府正规军远征合并。伤亡账本保留7和7—8两个史料口径，**不得使用大学地图研究拟址作现场GPS**。
- 1798 Scullabogue被囚亲王室者遇害主要归起义军看守；Dunlavin/Carnew Ball Alley则归亲政府武装。历史叙事须分开双方责任。
- 1798 Wexford Bridge发生日仅保留1798年6月，目前未核定20还是21日。

## 助手1/2需处理的接口（**不重新进行其专属全域调查**）

- 助手1（北美/加勒比）：Parks Canada Beaubassin当地史确认**1696年新英格兰攻击破坏村庄、1704年再次袭击**，而**1722年Mi'kmaq在Chignecto附近扣留新英格兰渔船**；这是17C旧阿卡迪亚系列向18C新冲突过渡的3处具年锚点。源：https://parks.canada.ca/lhn-nhs/ns/beaubassin/culture/village 。1704入侵缺停留证据不得作控制面；1722扣船既非英国被征服村落，也非船迹GPS。助手1请核原殖民军事记录及Mi'kmaq和平友好条约。
- 助手1（HBC/Acadia合作）：加拿大历史博物馆记录1686年法国夺取James Bay三个贸易据点，不等于1699年全部归属。需精确重查Albany、Rupert、Moose在1699—1713之间的逐堡换旗，不能拿公司1670流域特许自动升级主权面。源：https://www.historymuseum.ca/virtual-museum-of-new-france/the-explorers/pierre-le-moyne-diberville-1686-1702/ 。
- 助手2（亚洲/非洲）：1719本古伦地方反抗可能意味着英方撤离；逐年驻留不得照1700或1723的后续占据复制。需核实际堡点及EIC胡椒贸易当地控制与原住民权利。
- 主编地图：独立取得早期York I/II古河岸地理考古材料、Wexford 1798原战图配准、Sydney Cove营地18C真实界线，经过空间审核再考虑画任何面。

## 未解决的原始证据

- 英国国家档案馆RAC/EIC/HBC的具体人员或驻军日账、1700达连西方和Guna原始记录；
- 1794 Hawkesbury David Collins原始排印页及Bediagal家族口述材料；
- 1798爱尔兰战场影印军事地图需获准下载并作两种独立地理控制点配准；
- Irish 1702/1704、Scots Equivalent及产权实际办理案例原始登记；
- 1770 Kaurareg与Cook叙事争议、1788—1799原住民政治地理历史测绘资料。

**完成确认：** 36个17C旧专题仍保持原稳定ID；所有新增资料`research_only`；地图候审仅Point或null，实际控制多边形数=0；GitHub无写入。主编不用提交用户手动确认即可将本包导入独立研究分支继续审校。
