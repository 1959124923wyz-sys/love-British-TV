#!/usr/bin/env python3
"""Deterministic full research-only ZIP, per-file SHA256 verify, no remote/GitHub I/O."""
from pathlib import Path
import json,zipfile,hashlib
P=Path(__file__).resolve().parent
OUT=P.parent/'18c_assistant_C_continuity_australia.zip'
Q=json.loads((P/'ROUND6_QA_REPORT.json').read_text())
assert Q['checks_failed']==0,'round 6 QA must pass'
for name in ['ROUND4_QA_REPORT.json','ROUND5_QA_REPORT.json']:
 r=json.loads((P/name).read_text())
 assert (r.get('overall_pass') is True if name.startswith('ROUND4') else r['fail']==0),f'legacy validation failed: {name}'
files=sorted((p for p in P.rglob('*') if p.is_file() and p.name!='ARCHIVE_MANIFEST.json' and '__pycache__' not in p.parts and not p.name.endswith('.pyc')),key=lambda p:p.relative_to(P).as_posix())
rows=[]
for f in files:
 raw=f.read_bytes()
 rows.append({'path':f.relative_to(P).as_posix(),'size_bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
manifest={'schema':'assistant-C-round6-sha256-file-manifest','version':'round6','generated':'2026-11-08','archive':'18c_assistant_C_continuity_australia.zip','archive_prefix':'18c_assistant_C/','research_state':'research_only_not_published','git_modified':False,'file_count_excluding_manifest':len(rows),'previous_round_files_retained':True,'qa':{'round6':Q['checks_passed'],'round6_fail':Q['checks_failed'],'round5':json.loads((P/'ROUND5_QA_REPORT.json').read_text())['pass'],'round4':sum(x['passed'] for x in json.loads((P/'ROUND4_QA_REPORT.json').read_text())['checks'])},'files':rows}
(P/'ARCHIVE_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
files=[P/'ARCHIVE_MANIFEST.json']+files
with zipfile.ZipFile(OUT,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for file in files:z.write(file,arcname='18c_assistant_C/'+file.relative_to(P).as_posix())
with zipfile.ZipFile(OUT,'r') as z:
 assert z.testzip() is None
 assert len(z.namelist())==len(files)
 stored=json.loads(z.read('18c_assistant_C/ARCHIVE_MANIFEST.json'))
 assert stored['version']=='round6' and stored['file_count_excluding_manifest']==len(rows)
 for record in rows:
  b=z.read('18c_assistant_C/'+record['path'])
  assert len(b)==record['size_bytes'] and hashlib.sha256(b).hexdigest()==record['sha256'],record['path']
print(json.dumps({'archive':str(OUT),'size_bytes':OUT.stat().st_size,'file_count':len(files),'sha256':hashlib.sha256(OUT.read_bytes()).hexdigest(),'qa_round6':Q['checks_passed'],'qa_round4':manifest['qa']['round4'],'qa_round5':manifest['qa']['round5']},ensure_ascii=False))
