from pathlib import Path
import json,hashlib,csv,zipfile,datetime,collections,subprocess
P=Path('/mnt/data/18c_assistant_C'); R=P/'ROUND8_SYSTEMIC_IMPACT'; Z=Path('/mnt/data/18c_assistant_C_continuity_australia.zip')
def load(path):return json.loads((P/path).read_text(encoding='utf-8-sig'))
def store(path,obj): (P/path).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
source=load('SOURCE_REGISTRY.json');event=load('EVENT_CANDIDATES.json');claims=load('CLAIM_EVIDENCE_MATRIX.json');geo=load('MAP_CANDIDATES.geojson');cross=load('CROSS_CENTURY_AUDIT.json');ct=load('CONTROL_TRANSITIONS_1699_1709.json')
policy=load('ROUND8_SYSTEMIC_IMPACT/POLICY_MECHANISM_MATRIX.json');cases=load('ROUND8_SYSTEMIC_IMPACT/STATE_RESPONSIBILITY_ADJUDICATION.json');numbers=load('ROUND8_SYSTEMIC_IMPACT/QUANTIFIED_IMPACTS.json');newsrc=load('ROUND8_SYSTEMIC_IMPACT/ROUND8_SOURCE_REGISTRY.json')
checks=[]
def ck(name,condition,detail=None):checks.append({'check':name,'pass':bool(condition), 'detail':detail})
S=source['sources']; E=event['events']; C=claims['claims'];P29=policy['rows'];A=cases['cases'];Q=numbers['records'];G=geo['features']
sids={s['id'] for s in S}; eids={e['id'] for e in E}; policyids={e['id'] for e in P29}
for label,seq,expected in [('sources',S,source['source_count']),('events',E,event['event_count']),('claims',C,claims['evidence_count']),('places',G,len(G)),('policy',P29,29),('adjudication',A,18),('metrics',Q,22),('newsources',newsrc['new_sources'],newsrc['new_source_count'])]:
 ck(label+' cardinality',len(seq)==expected,(len(seq),expected)); ck(label+' IDs unique',len([v['id'] for v in seq])==len({v['id'] for v in seq}))
for label,seq in [('event',E),('claims',C),('policy',P29),('adjudication',A),('metric',Q)]:
 for v in seq:
  ck(label+' sources resolve '+v['id'],bool(v.get('source_ids')) and set(v['source_ids']).issubset(sids))
for v in A:ck('adjudication policy link '+v['id'],v['policy_id'] in policyids)
for x in newsrc['new_sources']:ck('round8 source in master '+x['id'],x['id'] in sids)
for x in S:
 ck('source provenance '+x['id'],x.get('url','').startswith(('https://','http://')) and x.get('original_manuscript_personally_inspected') in [False,None])
for v in P29:
 ck('policy research status '+v['id'],v.get('status')=='research_only')
 ck('policy legal mechanism '+v['id'],bool(v.get('political_actor') and v.get('policy_or_instruction') and v.get('evidence_limit') and v.get('documented_burdens')))
 ck('policy no fake polygons '+v['id'],'polygon' not in str(v.get('map_representation','')).lower())
for x in Q:
 ck('metric denominator '+x['id'],bool(x.get('denominator_or_population') and x.get('non_additivity_or_limitation')))
 ck('metric not official area '+x['id'],x.get('official_map_area_sqkm') is None)
for v in E:
 if v['id'].startswith('C8-'):
  ck('round8 event no polygon '+v['id'],v.get('historical_control_polygon_approved') is False and v.get('statistical_area_sqkm') is None)
  ck('round8 event not published '+v['id'],v.get('research_state')=='research_only')
for f in G:
 gg=f.get('geometry');ck('geo only reference Point '+f['id'],gg is None or gg.get('type')=='Point')
 if gg:
  lon,lat=gg['coordinates'];ck('geo point bounds '+f['id'],(-180<=lon<=180 and -90<=lat<=90))
 ck('geo never material actual area '+f['id'],f.get('properties',{}).get('area_sqkm') is None and f.get('properties',{}).get('fill_authorized') is False)
ck('source IDs suffix unique',len(S)==len(sids));ck('D/F 19 dossier files',all((P/'TOPIC_DOSSIERS'/f'E18-{a}{i:02d}.md').is_file() for a,n in [('D',10),('F',9)] for i in range(1,n+1)))
ck('cross century full 36',len(cross.get('entries',[]))==36)
ck('previous 27 land proxies not political proof',len(ct.get('candidates',[]))==27)
ck('270 annual review 1700-1709',sum(len(a.get('year_end_reviews',[])) for a in ct.get('candidates',[]))==270)
ck('no new colonial polygon',not any(f['geometry'] and f['geometry']['type'] in ('Polygon','MultiPolygon') for f in G))
ck('1747 dress ban corrected',any(e['id']=='C7-SCT-1746-PROSC' and '1747' in (str(e.get('date'))+str(e.get('evidence_notes'))) for e in E))
ck('Knight and Dundas contrast dossier',(R/'SCOTLAND_ABOLITION_JUDICIARY_INSTITUTIONAL_CONTRAST.md').exists() and all(pid in policyids for pid in ('C8-P28','C8-P29')))
ck('dossiers 10 narrative',all((R/f).is_file() for f in ['IRELAND_LAND_LAW_ECONOMY.md','IRELAND_FAMINE_TITHE_RURAL.md','IRELAND_STATE_REPRESSION_TRANSPORT.md','SCOTLAND_UNION_TAX_FINANCE.md','SCOTLAND_HIGHLANDS_PROPERTY.md','SCOTLAND_SLAVERY_CREDIT.md','AUSTRALIA_TERRITORIAL_LAW.md','AUSTRALIA_LABOUR_MORTALITY.md','AUSTRALIA_ORDERS_IMPUNITY.md','HUMAN_DEMOGRAPHICS_AND_LIMITS.md']))
for name,data,key in [('EVENT_CANDIDATES.csv',E,'events'),('CLAIM_EVIDENCE_MATRIX.csv',C,'claims'),('ROUND8_SYSTEMIC_IMPACT/POLICY_MECHANISM_MATRIX.csv',P29,'policy'),('ROUND8_SYSTEMIC_IMPACT/STATE_RESPONSIBILITY_ADJUDICATION.csv',A,'adjudication'),('ROUND8_SYSTEMIC_IMPACT/QUANTIFIED_IMPACTS.csv',Q,'quant')]:
 with (P/name).open(encoding='utf-8-sig',newline='') as file:r=list(csv.DictReader(file))
 ck(key+' CSV/JSON row equal',len(r)==len(data))
 ck(key+' CSV IDs equal',{x['id'] for x in r}=={x['id'] for x in data})
ck('only 10 new events this round',sum(v['id'].startswith('C8-') for v in E)==10)
ck('all new mechanism IDs present',len([x for x in P29 if x['id'].startswith('C8-P')])==29)
ck('original 17C event share preserved',len([e for e in E if e['id'].startswith('C7-')])==37)
ck('round8 source IDs start at 01',all('C8-S' in v['id'] for v in newsrc['new_sources']))
chkfail=[v for v in checks if not v['pass']]
qa={'schema':'round8-systemic-state-involvement-quantitative-evidence-audit-v1','date':'2026-11-08','editorial_state':'research_only','counts':{'events':len(E),'sources':len(S),'claims':len(C),'geographical_candidates':len(G),'georeferenced_points':sum(bool(f['geometry']) for f in G),'historical_polygons':0,'policies':len(P29),'economic_population_metrics':len(Q),'government_responsibility_cases':len(A),'previous_17c_topic_audits':len(cross['entries']),'annual_seed_reviews':270},'checks_total':len(checks),'passed':len(checks)-len(chkfail),'failed':len(chkfail),'failed_checks':chkfail,'checks':checks,'github_modified':False,'publication_approved':False,'manual_user_actions':[]}
store('ROUND8_QA_REPORT.json',qa)
if chkfail:
 print('R8 FAIL',json.dumps(chkfail[:15],ensure_ascii=False,indent=2));raise SystemExit(1)
ret=subprocess.run(['python',str(P/'validate_round6.py')],capture_output=True,text=True)
if ret.returncode:raise RuntimeError('round6 legacy regression failed: '+ret.stdout+' '+ret.stderr)
(P/'ROUND8_HANDOFF.md').write_text(f'''# 助手3第八轮制度性殖民经济/人口/政策研究交接（research_only）\n\n**完整研究**：`ROUND8_SYSTEMIC_IMPACT/ROUND8_INDEX.json` 与`ROUND8_SYSTEMIC_IMPACT/CLAIMS_OF_SYSTEMICITY.md`。\n\n**累计**：事件{len(E)}件（新增10）、来源{len(S)}条（本轮新增{len(newsrc['new_sources'])}）、证据条{len(C)}、地点{len(G)}处（有参考坐标{sum(bool(f['geometry']) for f in G)}）、27图形x10年=270条旧图层年末核对、17世纪专题36条。\n\n**本轮**：29项政策/决策链；22项人口经济量化分母；18项国家授权/默许/限制的责任审查。全部源ID可追溯。仍没有经核定历史实控面。\n\n**重要反证**：1798年爱尔兰军令限制烧毁房屋、1796年澳大利亚殖民总督令禁止恣意杀人、1778苏格兰Knight司法判决与1792英国下院渐进废奴决定都要并列；不可把“未处罚”推断为事先命令。\n\n**下一阶段最有价值的原卷**：原始议会法案及财政支出帐、爱尔兰宗教地权诉讼与海关贸易记录、苏格兰17/18C公司投资与奴隶贸易结算账、NSW Colonial Secretary来往公文与土地授予地籍、1799 Hawkesbury案件卷宗。旧资料/新增数据均保留`research_only`。\n\n**地图禁则**：1770库克宣示不等于土地实占；爱尔兰气候饥荒及1789天花不能无档案归类为蓄意英国制造；不得将议会决议画为控制区，不能生成无出处利润及死亡数字。\n\n**交付**：ZIP为`18c_assistant_C_continuity_australia.zip`，本地目录`/mnt/data/18c_assistant_C/`；GitHub从未修改。本批结构校验{qa['passed']}项通过，旧版55项回归通过；原始档案逐页审核与正式桌面浏览器检查需主编执行。\n''',encoding='utf-8')
# Publish manifest listing included bytes (including scripts) except archive manifest itself
pathlist=sorted(q for q in P.rglob('*') if q.is_file() and '__pycache__' not in q.parts and q.name!='ARCHIVE_MANIFEST.json')
manifest={'schema':'18c-assistant-C-integrity-sha256-v8','generated_date':'2026-11-08','zip_filename':Z.name,'source_root':str(P),'file_count_excluding_manifest':len(pathlist),'files':[{'path':str(q.relative_to(P)),'bytes':q.stat().st_size,'sha256':hashlib.sha256(q.read_bytes()).hexdigest()} for q in pathlist]}
store('ARCHIVE_MANIFEST.json',manifest)
files=sorted(q for q in P.rglob('*') if q.is_file() and '__pycache__' not in q.parts)
with zipfile.ZipFile(Z,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for q in files:z.write(q,arcname=str(Path(P.name)/q.relative_to(P)))
with zipfile.ZipFile(Z) as z:
 assert z.testzip() is None
 assert len(z.namelist())==len(files)
 for v in manifest['files']:assert hashlib.sha256(z.read(P.name+'/'+v['path'])).hexdigest()==v['sha256'],v['path']
print(json.dumps({'archive':str(Z),'bytes':Z.stat().st_size,'file_count':len(files),'checked_sha256':len(manifest['files']),'round8_checks_passed':qa['passed'],'round8_checks_failed':qa['failed'],'round6_regression_passed':True,'events':len(E),'sources':len(S),'evidence_claims':len(C),'policy_rows':len(P29),'demographic_records':len(Q),'responsibility_cases':len(A),'geographic_candidates':len(G),'polygon_count':0},ensure_ascii=False))
