#!/usr/bin/env python3
"""Sixth-round append-only vetted source research, no GitHub writes.
Re-run safe: source/event/feature IDs deduplicated; report regenerated.
"""
from pathlib import Path
import json, csv, datetime
P=Path('/mnt/data/18c_assistant_C')
def rd(n):return json.loads((P/n).read_text(encoding='utf-8'))
def wr(n,v): (P/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
sj=rd('SOURCE_REGISTRY.json');ej=rd('EVENT_CANDIDATES.json');gj=rd('MAP_CANDIDATES.geojson');cj=rd('CLAIM_EVIDENCE_MATRIX.json')
sby={x['id']:x for x in sj['sources']};eby={x['id']:x for x in ej['events']};gby={x['id']:x for x in gj['features']};cby={x['id']:x for x in cj['claims']}
def source(id,title,url,inst,access,scope):
 if id in sby:return
 r={'id':id,'institution':inst,'title':title,'url':url,'access_level':access,'original_manuscript_personally_inspected':False,'reviewed_online_on':'2026-11-08','evidence_scope':scope,'source_handling':'Published transcription, archival catalogue and facsimile are distinguished from personal inspection of original manuscript.'}
 sj['sources'].append(r);sby[id]=r
source('C6-CAN-PARKS-PRINCE2024','Prince of Wales Fort National Historic Site management plan 2024','https://parks.canada.ca/lhn-nhs/mb/prince/info/gestion-management/plan-2024','Parks Canada','official_site_management_history','Churchill site Indigenous history, 1717 post, stone fort built from 1731, French 1782 seizure, returned 1783 abandoned')
source('C6-IRL-HISTIRELAND-WEXFORD','Military Strategy of Wexford United Irishmen in 1798','https://historyireland.com/the-military-strategy-of-the-wexford-united-irishmen-in-1798/','History Ireland / scholarly historical article','published_historical_analysis_based_on_contemporary_accounts','26 May–21 June local mobilisation, rebel occupation Wexford Enniscorthy, Crown remaining footholds, 1 June Newtownbarry, 5 June New Ross, 7 June Carnew, 9 June Arklow')
source('C6-UK-COMMONS-UNION2026','The United Kingdom and independence (House of Commons Library CBP-10649)','https://commonslibrary.parliament.uk/research-briefings/cbp-10649/','UK House of Commons Library','official_parliamentary_research_explanation','1706 treaty, 1 May 1707 incorporating union, separate historic Scots courts and Irish Privy Council; terminology caution')
source('C6-CAN-PARKS-YORK2007','York Factory NHS management plan 2007, York Factory I, II, III','https://www.parks.canada.ca/lhn-nhs/mb/yorkfactory/info/gestion-management','Parks Canada','official_historical_site_management_plan','York Factory I 1684–1715, II 1715–1788, III 1788–1957; modern heritage site is III, old I/II eroded')
source('C6-IRL-1798C-WEXFORD','1798 Rebellion Centre chronology','https://1798centre.ie/history/timeline-of-1798/','1798 Rebellion Centre','local_museum_public_history_approximate_quantities','30 May, 1 June, 5 June, 21 June Wexford actions; casualty estimates require independent corroboration')
source('C6-IRL-NAM-1798','Irish Rebellion 1798 revised narrative and Crown/loyalist reprisals','https://www.nam.ac.uk/explore/irish-rebellion-1798','National Army Museum (UK)','national_museum_historical_analysis','1798 campaign and coercion, Wexford and French stages; no full-control county polygon')
# Source reuse: C4-AU-ANMM-WATER, C5-IRL-NAI-1798, C2-UNION-ART, S53a, C3-HBC-PARKS-PLAN, C5-HBC-PARKS-CHURCHILL

def place(pid,name,source_ids,meaning):
 if pid in gby:return
 f={'type':'Feature','id':pid,'geometry':None,'properties':{'name':name,'source_ids':source_ids,'linked_event_ids':[],'coordinate_method':'not_geocoded_independently','coordinate_status':'historically_attested_named_place_unlocated_point','geo_precision':meaning,'historical_boundary_confirmed':False,'territorial_claim':False,'fill_authorized':False,'area_sqkm':None,'exclude_from_area_aggregation':True,'publication_status':'research_only','map_inclusion':'research_not_published'}}
 gj['features'].append(f);gby[pid]=f
place('PLACE-IRONCOVE','Bloody Point (1788 survey), Iron Cove, Sydney Harbour',['C4-AU-ANMM-WATER'],'interpretive_location_identified_from_1788_chart_not_certain_event_site')
place('PLACE-DAWESPOINT','Dawes Point, Sydney Harbour',['C4-AU-ANMM-WATER'],'modern_named_point_referenced_in_contemporary_report_no_GPS')
place('PLACE-BALTINGLASS','Baltinglass parish, County Wicklow, Ireland',['C5-IRL-NAI-1798'],'parish_named_in_1798_intelligence_sketch_not_military_control_polygon')
place('PLACE-CARNEW','Carnew, County Wicklow, Ireland',['C6-IRL-HISTIRELAND-WEXFORD'],'named_town_military_action_point_only')
place('PLACE-WATERFORD','Waterford, Ireland (1799 court martial venue)',['C5-IRL-NAI-1798'],'court_martial_city_reference_not_execution_location')
place('PLACE-WHITEHALL','Whitehall / Westminster, London',['C2-UNION-ART'],'treaty_signing_administrative_reference_not_colonial_polygon')
place('PLACE-ORIGINAL-YORKFORT','York Factory I / Fort Bourbon (1684–1715 original site, eroded), Hayes River',['C6-CAN-PARKS-YORK2007','C5-HBC-PARKS-YORK'],'original_fort_site_eroded_and_NOT_modern_York_Factory_III_heritage_site')
place('PLACE-KILDARE','County Kildare, Ireland (1798 disarmament district)',['C5-IRL-NAI-1798'],'named_region_only_no_military_campaign_polygon')
place('PLACE-CARLOW','County Carlow / Wexford boundary 1798',['C6-IRL-HISTIRELAND-WEXFORD'],'region_not_historic_boundary')
place('PLACE-SCULLABOGUE','Scullabogue barn, County Wexford',['C6-IRL-NAM-1798'],'barn_event_locality_no_independently_surveyed_original_site')

def event(id,topic,date,precision,title,actor,action,place_name,sources,geo,evidence,kind='dated_action'):
 if id in eby: return
 e={'id':id,'topic_id':topic,'date':date,'date_precision':precision,'title':title,'actor':actor,'action':action,'historical_place':place_name,'source_ids':sources,'research_state':'research_only','cartographic_status':'source_supported_map_review' if kind=='dated_action' else 'source_attested_document_not_actual_control_change','geometry_ref':geo,'historical_control_polygon_approved':False,'evidence_notes':evidence,'round':'sixth_primary_or_museum_crosscheck','event_kind':kind,'source_date_calendar':'display_source_date; convert_old_style_only_when_original_proven'}
 ej['events'].append(e);eby[id]=e
 if geo and geo in gby:gby[geo]['properties'].setdefault('linked_event_ids',[]).append(id)
# D11: historically distinct boat / martial episodes rather than re-counting earlier D11 Balloderry, 1795-97 boat attacks.
event('C6-D11-001','E18-D11-PROPOSED','1788-08','month','悉尼湾原住民以独木舟取走殖民船队山羊幼崽','悉尼港原住民群体；殖民医生John White、Judge Advocate David Collins','据殖民官员日记，原住民乘5条独木舟靠岸、刺取山羊幼崽并驶离','Sydney harbour, near colonial hospital',['C4-AU-ANMM-WATER'],'PLACE-SYDNEY','John White与Collins的记载由澳大利亚国家海事博物馆引用；未独立阅手稿，群体身份未核定')
event('C6-D11-002','E18-D11-PROPOSED','1788-09','month','Dawes Point原住民独木舟队伍接近殖民羊群','悉尼港原住民群体；殖民观察者David Collins','殖民记载数条独木舟载30余人抵Dawes Point附近，双方投石后该群体离开','Dawes Point, Sydney harbour',['C4-AU-ANMM-WATER'],'PLACE-DAWESPOINT','30余人系Collins报告口径，不推广为任何区域军事人数')
event('C6-D11-003','E18-D11-PROPOSED','1789','year','殖民舵手夺取原住民独木舟后被刺伤','身份未核悉尼地区原住民；英国殖民船工','殖民记录一名舵手抢走独木舟之后被长矛刺伤','Sydney harbour, unspecified reach',['C4-AU-ANMM-WATER'],'PLACE-SYDNEY','年代仅为early 1789，严格年份精度；不得捏造攻击现场')
event('C6-D06-001','E18-D06','1790-12','month','Tench武装惩罚远征中原住民乘独木舟避开士兵','Watkin Tench率英国殖民士兵；Botany Bay原住民群体','殖民军两次尝试惩罚攻击，原住民乘独木舟撤离，殖民方未能完成捕获','Botany Bay / Cooks River 北支地带',['C4-AU-ANMM-WATER','S20'],'PLACE-BOTANY','独立于既有Phillip下令节点；战斗位置仅有大地名，射杀/俘获数未记则为null')
event('C6-D11-004','E18-D11-PROPOSED','1791','year','殖民当局要求船只携带武器并限制原住民进港活动','新南威尔士殖民当局','面对原住民水上抵抗，殖民方规定出航小船携枪，并禁止原住民进入港湾部分地区','Sydney harbour, unnamed restricted stretches',['C4-AU-ANMM-WATER'],'PLACE-SYDNEY','馆方转引殖民日记；未确认命令原始日期和逐字内容，不得直接画航海禁区面')
# Ireland original documentary government coercion and changing local rebel hold
event('C6-F06-001','E18-F06','1798-03-12','day','都柏林Bond住宅搜捕联合爱尔兰人地方领导','爱尔兰王国政府官员与侦缉人员','政府凭举报对Oliver Bond住宅开展搜捕，逮捕Leinster Provincial Directory与部分高级成员','Bridge Street, Dublin',['C5-IRL-NAI-1798'],'PLACE-DUBLIN','国家档案馆Rebellion Papers 620/3/32/26的 facsimile 2 导言；具体被捕者人数需沿官方书面记录核实')
event('C6-F06-002','E18-F06','1798-05-07','day','Baltinglass地方通讯员向都柏林政府寄送镇压用草图','匿名保王派通讯员；爱尔兰王国政府','向行政当局提交Baltinglass教区草图，指出涉嫌联合爱尔兰人的聚集地点和武器','Baltinglass parish, County Wicklow',['C5-IRL-NAI-1798'],'PLACE-BALTINGLASS','国家档案馆Rebellion Papers 620/37/35；这是镇压准备所用情报地图，不是反叛地区实际占领地图','archival_intelligence_map')
event('C6-F06-003','E18-F06','1798-05-16','day','邓达斯将军向爱尔兰政府报告Kildare解除武装','General Ralph Dundas；爱尔兰都柏林城堡政府','报告部队在Kildare征收武器并实施free quarters强制驻宿征用政策','County Kildare / Castle Martin',['C5-IRL-NAI-1798'],'PLACE-KILDARE','国家档案馆Rebellion Papers 620/37/90；命令与征用机制有据，单个村庄/人数未知','documented_counterinsurgency')
event('C6-F06-004','E18-F06','1798-06-07','day','联合爱尔兰人军队进攻Carnew取得局地胜利','Wexford起义军北翼；Carnew当地保王派','起义军自北面战役路线攻击并取得Carnew局地战术成功','Carnew, County Wicklow',['C6-IRL-HISTIRELAND-WEXFORD'],'PLACE-CARNEW','基于史学文章对7日Carnew胜利的概述；实际行政驻留及离开时段尚需原档追溯，不授权控制面')
event('C6-F06-005','E18-F06','1798-06-21','day','Wexford桥上被拘押保王派遭起义者杀害','起义军内实施处决人员；被囚禁保王派','在Wexford城镇桥梁处杀害数十名拘押者','Wexford town bridge',['C6-IRL-NAM-1798'],'PLACE-WEXFORD-TOWN','国家陆军博物馆报告约70名新教被囚者被杀；责任特定，不外推所有联合爱尔兰人；数字系机构综述')
event('C6-F06-006','E18-F06','1798-06','month','Vinegar Hill失败后王室军及保王派实施报复性暴力','英国政府军、地方保王派；战败起义者与平民','战役后实施处决和针对战败者的暴力，Cornwallis批评军队滥杀','Wexford county, multiple unknown sites',['C6-IRL-NAM-1798'],'PLACE-WEXFORD-TOWN','只能表达1798年6月后阶段性报复，不虚构单一屠杀点、伤亡总数或整个郡的反叛控制面')
event('C6-F06-007','E18-F06','1798-09-19','day','Napper Tandy发表政治宣言（原始档案副本）','James Napper Tandy','签署涉及1798年反政府运动的宣言，后由爱尔兰国家档案馆保存为文书影印','Ireland; precise signature location uncertain',['C5-IRL-NAI-1798'],None,'NAI facsimile 14列日期和署名；宣言的地点及实施效果仍待逐文核','archival_document_not_territory')
event('C6-F06-008','E18-F06','1799-07-16','day','Waterford军事法庭审理Patrick Beaghan的起义关联案件','英方军事法庭；被告Patrick Beaghan','现存军事法庭程序记录证明1798年镇压的司法后果延续至1799年','Waterford, Ireland',['C5-IRL-NAI-1798'],'PLACE-WATERFORD','NAI facsimile 16；没有阅到判决全页，不记定罪/刑罚/处决','archival_trial_not_territorial_control')
# Scottish Union founding stages: avoid copying existing votes
# 1706, separate from 1707 ratification of Scottish and English Parliaments.
event('C6-F03-001','E18-F03','1706-07-22','day','英苏两国谈判代表在Whitehall签订25项联合法条款','苏格兰与英格兰谈判委员','签署Articles of Union草案，需要两国分别立法批准方可生效','Whitehall / Westminster',['C2-UNION-ART','C6-UK-COMMONS-UNION2026'],'PLACE-WHITEHALL','原始签名档在National Records of Scotland SP13/209相关馆藏；签署不是1706年已成立大不列颠')
event('C6-F03-002','E18-F03','1707-05-01','day','联合法保留苏格兰独立的法院与私法制度','新大不列颠王国；苏格兰司法机构','英苏合并王国生效，联盟Articles 18–19确立苏格兰法律和法院制度的延续','Scotland jurisdiction; no single site',['C2-UNION-ART','C6-UK-COMMONS-UNION2026'],None,'经济与军事合并中保留苏格兰法律权利；仅为政制有效日，不作为苏格兰内部被英国殖民军事征服的地图事件','constitutional_effect_not_geography')
event('C6-F03-003','E18-F03','1707-05-01','day','联合法Article 4向苏格兰臣民开放英国殖民地合法贸易资格','大不列颠王国商人、苏格兰与英格兰海关机构','英苏联合后，Article 4规定臣民在大不列颠及殖民地内享有贸易准入','Edinburgh and London; imperial trade jurisdiction',['C2-UNION-ART'],None,'这是一项法定商业权利，不表示任何苏格兰船只已经抵达具体殖民据点或占领新增土地','economic_right_not_real_control')
# HBC site change and distinction from modern site
event('C6-C27-001','E18-C27','1715','year','York Factory II历史设施阶段开始，区别法国时代旧堡遗址','Hudson’s Bay Company','原约克堡/法国Fort Bourbon旧址阶段约1684–1715，随后进入York Factory II阶段','Hayes River York Factory vicinity',['C6-CAN-PARKS-YORK2007'],'PLACE-ORIGINAL-YORKFORT','Parks Canada historical phase not exact foundation day; geom null because York I/II sites lost to erosion; do not use York III present location for this 1715 episode')
# date/legislation evidence matrix
def claim(id,date,summary,sources,access,lim,elig):
 if id in cby:return
 r={'id':id,'date_or_range':date,'claim_summary':summary,'source_ids':sources,'access_type':access,'audit_limit':lim,'map_eligibility':elig,'original_folio_personally_inspected':False};cj['claims'].append(r);cby[id]=r
claim('C6-YORK-GEO-III','1684–1957 stages','York Factory I (1684–1715), II (1715–1788), III (1788–1957); modern National Historic Site is III and original I/II riverbank-eroded',['C6-CAN-PARKS-YORK2007','C5-HBC-PARKS-YORK'],'Parks Canada management report','Date intervals classify site phases, not proof of occupying exact historical spot all years','Reject using coordinates of today York Factory III for French 1700 Fort Bourbon')
claim('C6-YORK-1700','1697–1713','French garrison Fort Bourbon former York Fort during 1700–1709, HBC still holds charter but not fort',['C5-HBC-PARKS-YORK','C6-CAN-PARKS-YORK2007'],'Parks Canada historical narrative','Year-end French control inferred from explicitly attested 1697–1713 interval; each individual annual garrison muster not read','At most a reviewed town-core marker with French label, 1700–1709; historical Polygon forbidden')
claim('C6-CHURCHILL-1782','1717, 1731–1771, 1782–1783','Churchill new post starts 1717, stone fort built from 1731, French captured 1782, returned 1783 but fort abandoned in favour of earlier post location',['C6-CAN-PARKS-PRINCE2024','C5-HBC-PARKS-CHURCHILL'],'Parks Canada management report','Modern heritage site is stone fort distinct from 1717 post and earlier 1689 burnt post','Never carry 1700 Churchill fort, distinguish site relocations and 1783 abandonment')
claim('C6-IRL-WEX-REGIME','1798-05-28 to 1798-06-21 (approx)','Wexford rebel occupation: Enniscorthy and Wexford town seized by end of May; New Ross, Arklow and Newtownbarry govt footholds not durable rebel seizure',['C6-IRL-HISTIRELAND-WEXFORD','C5-IRL-NAI-1798'],'scholarly secondary & national archive facsimile introductions','Rebel countryside varied by parish; NAI phrase large part south-east does not delimit mapped historical boundary','May plot source-dated individual town regime episodes with year 1798, never one county Polygon')
claim('C6-IRL-NAI-1798-SOURCE','1798-03-12 / 1798-05-07 / 1798-05-16','NAI facsimiles 2, 3, 4 show intelligence raid, Baltinglass government sketch and coercive disarm/billeting',['C5-IRL-NAI-1798'],'national archives facsimile text and finding aid','PDF screenshot service returned 404 this session; web-extracted text accessible, no personal archival folio read','Government sketch is evidence of intelligence/targeting, not an occupation polygon or mapped rebel territory')
claim('C6-AU-MAY-1788-SITE','1788-05','Colonial record of Okey/Davis canoe-taking incident previously geographically attributed to Rushcutters Bay/Darling Harbour; Bradley map Bloody Point Iron Cove an interpretive alternative',['C4-AU-ANMM-WATER'],'ANMM original-map interpretation','ANMM says almost certain, not independently located archaeological site; proper name is historic map label not event coordinate','Retain geometry:null and the locality hypothesis rather than a deterministic murder geocode')
claim('C6-AU-BOATS-1795-97','1795–1797','Riverine raids documented by Collins, with 1797 two distinct vessel boarding/skirmish episodes near lower Hawkesbury',['C4-AU-ANMM-WATER'],'ANMM curated colonial diary discussion','Narratives derived from colonial observer; settler claims about missing crew causality remain unverified','D11 records waterways as contested travel and tactics, no accurate vessel courses or coercive buffer areas')
claim('C6-IRL-1702-SCOPE','1702, English 1 Anne c26','English 1702 Act concerns Protestant purchasers of specific forfeited Irish estates, not blanket mapping of all Irish land',['S53a','C2-IRL-1702'],'university law-library transcription','Restrictions on purchase, descent and leases feature exemptions and oaths; exact estates and legal instruments not geocoded','Legal regime annotation; prohibited as whole-Ireland historical dispossession polygon')
claim('C6-SCOT-1707-EQUIV','1707-05-01','Articles of Union Article 15 Equivalent £398,085 10s serves multiple budgetary purposes including Scottish debt liability and Darien investor compensation, not one Darien-loss payout',['C2-UNION-ART','C6-UK-COMMONS-UNION2026'],'Scottish National Records institutional transcribed summary','No evidence that all value went to Darien creditors, no record of individual disbursements in these sources','1707 legal finance event only; do not plot equivalent as actual colonial revenue')
claim('C6-SCOT-1707-TRD','1707-05-01','Article 4 opens lawful colonial trade to Scottish subjects after union, but Article 18–19 preserve Scots legal institutions',['C2-UNION-ART','C6-UK-COMMONS-UNION2026'],'institutional treaty summary and parliamentary scholarship','No evidence as to a specific Scottish settlement or occupied land on 1 May','Disaggregate commercial jurisdiction and territorial control; no instant colonial Polygon')
# Insert independent date-resolution finding, not silently overwriting old conflicting sources
conf=rd('ROUND3_EVIDENCE_CONFLICTS.json')
newconf=[
 {'id':'C6-YORK-FACTORY-I-II-III','claim':'1700 Fort Bourbon/York Factory I historically located at 1788–1957 modern York Factory III National Historic Site','positions':[{'source_ids':['C6-CAN-PARKS-YORK2007'],'finding':'York Factory I 1684–1715 and II 1715–1788 eroded; NHSC physical site is York Factory III 1788–1957'}],'resolution':'Never copy contemporary York Factory III coordinates to 1699–1713 Fort Bourbon / York I or 1715–1788 York II. Geometry null until archaeological/historical site map is georeferenced.','never_merge_as_one_conquest':True},
 {'id':'C6-IRL-1798-COUNTY-VS-TOWN','claim':'Wexford rebel control of most of county vs verified individual towns and remaining Crown footholds','positions':[{'source_ids':['C5-IRL-NAI-1798'],'finding':'large part of south-east held until Vinegar Hill 21 June, not entire county border'},{'source_ids':['C6-IRL-HISTIRELAND-WEXFORD'],'finding':'government retained Duncannon Fort/New Ross/Newtownbarry/Gorey footholds late May; Wexford and Enniscorthy taken by rebels'}],'resolution':'Site/time regime episodes only; never render an unverified continuous rebel county boundary.','never_merge_as_one_conquest':True},
 {'id':'C6-IRL-1802-REBEL-BILLET','claim':'1798 forced quartering and flogging sometimes misattributed solely to British regular army','positions':[{'source_ids':['C5-IRL-NAI-1798','C6-IRL-NAM-1798'],'finding':'counterinsurgency used regulars, Irish militia and loyalist Yeomanry; units varied by site'}],'resolution':'Classify individual actor based on dated report; do not merge Irish militia, regular British units, Yeomanry into one unverified brigade.','never_merge_as_one_conquest':True}]
oldids={x['id'] for x in conf['conflicts']};conf['conflicts'] += [x for x in newconf if x['id'] not in oldids];wr('ROUND3_EVIDENCE_CONFLICTS.json',conf)
# Previous spatial data geom limit update
for fid,extra in {'PLACE-FORTBOURBON':{'historic_site_phase':'York Factory I / Fort Bourbon','modern_York_Factory_III_is_not_this_site':True,'site_status':'original riverbank site eroded; do not transfer 1788–1957 heritage site coordinate','phase_source_ids':['C6-CAN-PARKS-YORK2007']},'PLACE-CHURCHILL-RIVER':{'early_1689_post_destroyed':True,'re_established_1717':True,'modern_stone_fort_first_construction_1731':True,'phase_source_ids':['C6-CAN-PARKS-PRINCE2024']}}.items():
 if fid in gby:gby[fid]['properties']['round6_site_warning']=extra
# cohort-specific ledger with site political relation explicitly not shared territory
ledger={'schema':'assistant-C-round6-source-attested-temporal-control-v1','editorial_state':'research_only','method':'historical_period_intervals_are_not_independently_verified_yearly_muster; view 1700–1709 as decision support, never direct Polygon','episodes':[
 {'id':'C6-YORK-I-FRENCH','subject':'French garrison at Fort Bourbon (former York Fort), Hayes River','start':'1697','end':'1713 (Utrecht settlement)','site_identity':'York Factory I / old original fort (site eroded)','operational_control':'French fort occupation in published institutional historical interval','not_controlled':'whole Rupert Land watershed or Cree/Dene sovereignty','source_ids':['C5-HBC-PARKS-YORK','C6-CAN-PARKS-YORK2007'],'geometry':None,'map_decision':'French-labeled historical fort reference only; no original surveyed GPS'},
 {'id':'C6-YORK-II-BRITISH','subject':'HBC post York Factory II','start':'1715','end':'1788','site_identity':'second fort phase, lost to Hayes River erosion','operational_control':'HBC post episode, dates from site plan','not_controlled':'whole Hudson basin; any actual surveyed 1715 fort footprint','source_ids':['C6-CAN-PARKS-YORK2007'],'geometry':None,'map_decision':'no modern York III coordinate'},
 {'id':'C6-YORK-III-BRITISH','subject':'HBC post York Factory III','start':'1788','end':'1957','site_identity':'today National Historic Site physical area','operational_control':'HBC trading post physical phase','not_controlled':'1684–1715 old Fort Bourbon geometry','source_ids':['C6-CAN-PARKS-YORK2007'],'geometry':None,'map_decision':'modern heritage coordinates must not retroactively anchor York I/II'},
 {'id':'C6-CHURCHILL-NOPOST','subject':'Churchill River old trading post','start':'1690','end':'1716','site_identity':'post built 1689 burnt same year','operational_control':'not a verified continuing HBC fort for interval','not_controlled':'Cree/Dene/Inuit lands, bay or river','source_ids':['C5-HBC-PARKS-CHURCHILL','C6-CAN-PARKS-PRINCE2024'],'geometry':None,'map_decision':'do not display English fort for year 1700–1709'},
 {'id':'C6-CHURCHILL-1717','subject':'Churchill River Post','start':'1717','end':'1730 (at least; exact post transfer pending)','site_identity':'post re-established in 1717, not existing 1731 stone fort','operational_control':'HBC trade post attested by Parks Canada','not_controlled':'the whole Churchill River drainage basin','source_ids':['C6-CAN-PARKS-PRINCE2024'],'geometry':None,'map_decision':'named site historical core after separate site-location audit'},
 {'id':'C6-CHURCHILL-1782','subject':'Stone Prince of Wales Fort French seizure','start':'1782','end':'1783','site_identity':'Stone fort at Churchill River built 1731–1771','operational_control':'French raid seizure 1782; returned 1783, fort abandoned in favour of earlier post site','not_controlled':'France annexed Manitoba or Hudson drainage','source_ids':['C6-CAN-PARKS-PRINCE2024'],'geometry':None,'map_decision':'short-term battle and fort state, do not carry continuous HBC garrison after abandonment'},
 {'id':'C6-WEXFORD-TOWN-REBEL','subject':'Wexford town United Irish provisional military presence','start':'1798-05-30','end':'1798-06 (exact withdrawal and reoccupation days need source)','site_identity':'Wexford town not modern county','operational_control':'rebels entered town after Crown garrison retreated','not_controlled':'all Co. Wexford','source_ids':['C6-IRL-HISTIRELAND-WEXFORD','C5-IRL-NAI-1798'],'geometry':None,'map_decision':'localized town-regime episode, not 1798-12-31 permanent rebel control'},
 {'id':'C6-ENNISCORTHY-REBEL','subject':'Enniscorthy town rebel-held phase','start':'1798-05-28','end':'1798-06-21 (latest battle phase, actual town end check)','site_identity':'Enniscorthy not whole region','operational_control':'rebels captured Enniscorthy; Vinegar Hill defeated 21 June','not_controlled':'all County Wexford','source_ids':['C6-IRL-HISTIRELAND-WEXFORD','C5-IRL-NAI-1798'],'geometry':None,'map_decision':'brief occupied town if needed 1798 in-month; absent 1798 year-end'},
 {'id':'C6-NEWROSS-CROWN','subject':'New Ross town Crown government foothold during Wexford uprising','start':'1798-05-30 (at least)','end':'1798-06-05 (battle confirms Crown repulse)','site_identity':'New Ross garrison town','operational_control':'government defended and recaptured tactical portions during 5 June assault','not_controlled':'a mapped corridor from New Ross to all of Wexford','source_ids':['C6-IRL-HISTIRELAND-WEXFORD'],'geometry':None,'map_decision':'if tactical regime transitions needed use day-level episodes and point, no County Polygon'},
 {'id':'C6-ARKLOW-CROWN','subject':'Arklow Crown garrison resisted rebel attack','start':'1798-06-09','end':'1798-06-09','site_identity':'Arklow town','operational_control':'successful defensive action recorded, no sustained rebel occupation','not_controlled':'all County Wicklow','source_ids':['C6-IRL-NAM-1798'],'geometry':None,'map_decision':'battle point, no rebellion occupation area'}]}
wr('ROUND6_LOCAL_CONTROL_EPISODES.json',ledger)
# Audit all D and F dossier files append sixth cross-check references in a compact explicitly structured section
for topic_id,sourceids,issue in [
 ('E18-D06',['C4-AU-ANMM-WATER'],'1790年12月的惩罚性远征与Phillip发令不同；Tench两轮追击失败，原住民乘独木舟撤离。'),
 ('E18-D10',['C6-CAN-PARKS-YORK2007'],'本篇只处理澳大利亚殖民授地；禁止用现代遗址坐标替代18世纪原始农田地籍。'),
 ('E18-F01',['S53a','C2-IRL-1702'],'1702年English 1 Anne c26与1704年Irish 2 Anne c6是两个立法机关的不同法案；前者特指被没收庄园购买与继承。'),
 ('E18-F03',['C2-UNION-ART','C6-UK-COMMONS-UNION2026'],'1706-07-22签署Articles、1707-01-16苏议会批准、1707-03-06英议会批准、1707-05-01正式联合；Articles 18–19保留苏格兰司法机构，Article 4是商业准入。'),
 ('E18-F06',['C5-IRL-NAI-1798','C6-IRL-HISTIRELAND-WEXFORD'],'1798年韦克斯福德的短期起义军占镇不能按整郡涂色；政府仍有New Ross、Duncannon等坚守点，原档的镇压军包括多类型民兵与正规军。'),
 ('E18-F09',['C2-UNION-ART'],'Article 15 Equivalent共£398,085 10s有多项法定用途，不能称其全部为达连投资损失补偿。')]:
 p=P/'TOPIC_DOSSIERS'/f'{topic_id}.md'
 if p.exists():
  s=p.read_text(encoding='utf-8');tag='\n## 第六轮来源与地理补审（2026-11-08）\n'
  if tag not in s:p.write_text(s+tag+f'{issue}\n\n来源：{", ".join(sourceids)}。状态：`research_only`，原卷与历史地籍未完全校准。\n',encoding='utf-8')
# More scope D11 and HBC supplements
p=P/'SUPPLEMENTAL_TOPICS'/'E18-D11-PROPOSED.md';old=p.read_text(encoding='utf-8') if p.exists() else '# D11 proposed\n';tag='\n## 第六轮海事博物馆专题补证\n'
if tag not in old:p.write_text(old+tag+'澳大利亚国家海事博物馆以White、Collins、Tench等同时代记录，分别指出1788年5月扣舟争端、8月山羊争端、9月Dawes Point舟上群体与殖民羊群、1789年夺舟后舵手遇袭、1790年12月原住民乘舟规避惩罚队、1791年英国船武装通行及港口排斥、1795与1797年Hawkesbury河运船被袭。上述是不同年份具名行动；1788年Bloody Point位置是博物馆从Bradley的当时海图提出的历史解释，不能升格成古代战斗坐标。\n\n勿从殖民记载推定全部遭袭人数或伤亡，也勿将原住民水上抵抗简单归入Pemulwuy一人。数据：`C6-D11-001`—`004`及旧`C4-D11-*`，来源 `C4-AU-ANMM-WATER`。\n',encoding='utf-8')
p=P/'TOPIC_DOSSIERS'/'HBC_1699_1713.md';s=p.read_text(encoding='utf-8');tag='\n## 第六轮：约克堡I／II／III的实地身份核对\n'
if tag not in s:p.write_text(s+tag+'加拿大公园局管理计划将York Factory I（1684–1715）、York Factory II（1715–1788）、York Factory III（1788–1957）严格分开；今日国家历史遗址对应III，I/II旧址被河流侵蚀。1697–1713年法国Fort Bourbon控制发生在York I，不能套今日遗址坐标。Churchill 1689前站当年焚毁，1717重建；1731后的石堡又不同。新旧据点不是相同的历史Polygon。参 `C6-CAN-PARKS-YORK2007`、`C6-CAN-PARKS-PRINCE2024`及 `ROUND6_LOCAL_CONTROL_EPISODES.json`。\n',encoding='utf-8')
# Comprehensive report + civil maps / source conflicts
(P/'ROUND6_DEEP_RESEARCH.md').write_text('''# 爱英TV 助手3｜第六轮重点原始档案与历史空间反证（2026-11-08）

**研究候审／无GitHub修改／历史政治关系与坐标独立复核。** 本轮沿用第五版，不用数字增长替代证据质量。

## 1. 对1700年版图最关键的“地点同名、不同时代”问题

- 加拿大公园局官方管理规划把 York Factory 分为 I (1684–1715)、II (1715–1788)、III (1788–1957)，当今保护地在 III。更老两个地点遗失于河岸侵蚀；1697年后法国的 Fort Bourbon 属于第一阶段，不可误用今York Factory III地理定位。见 `C6-CAN-PARKS-YORK2007`。
- Churchill River 的1689年首座贸易站当年焚毁，1717年重新设点；1731–1771年新建 Prince of Wales 石堡。1782年法国攻取石堡，1783年归还公司但因损坏退出石堡，不能把同一地点连续涂成不变HBC驻军。见 `C6-CAN-PARKS-PRINCE2024`。
- 相关时间区间是机构史论证的**连续阶段**，不是逐年发现独立的薪饷/驻军档。1700–1709年仍保留逐堡年末待核，不扩展到Rupert's Land多边形。

## 2. 1788–1797年悉尼及Hawkesbury水上争端

- National Maritime Museum依据殖民观测者日志补出1788年8/9月两次水上取牲畜行动、1789年因夺舟造成的舵手遇袭、1790年12月殖民惩罚远征中的原住民舟上撤退、1791年武装航行令。各自作为独立事件，避免重算第四版已记的1791 Balloderry和1795/1797 Hawkesbury冲突。
- **1788年5月Okey/Davis死地**：博物馆借当时Bradley航海图Bloody Point提出Iron Cove位置，相比此前Rushcutters Bay/Darling Harbour说法有改进，但目前属于文献地名解释而非精确现场。保留`geometry:null`。
- 1797年下Hawkesbury船员失踪不得因殖民方猜测自动标成原住民所杀。现有航次点都不是实测冲突或船舶路线。

## 3. 1798爱尔兰政权短时移动与镇压

- 国家档案馆17件facsimile材料有档案定位：Bond住宅搜捕（1798-03-12）、Baltinglass地方反叛活动草图（1798-05-07）、政府军Kildare的free quarters与解除武装（1798-05-16），分别是搜捕、情报、军事行政，**没有任何一件构成领土面积证据**。
- History Ireland对1798年韦克斯福德军事策略逐处分析：起义军于5月末占有Enniscorthy和Wexford town；New Ross、Newtownbarry、Gorey、Duncannon等仍有政府据点，6月5日New Ross短暂攻入后遭击退，6月9日Arklow被守住，6月21日Vinegar Hill败退。不可把这些局地控制画成整个Wexford County实心区。
- 政府军残酷镇压（含强制驻宿、拷打、焚毁）与起义军杀害保王派俘虏须在各自时间/地方分列；保王民兵、爱尔兰民兵、英国正规部队角色分别归因。另有1799 Waterford军事审判文书，反对用1798战败假定所有社会司法后果当年终止。
- `C5-IRL-NAI-1798`原PDF的网页可读文字已复核；本轮网页截图服务404，**不声称亲阅全套17件原始影像**。

## 4. 1706/1707政治与贸易法权

- 1706-07-22双方谈判委员签署条款；1707-01-16苏格兰议会批准、03-06英格兰议会批准、05-01联合王国生效。此前苏格兰是独立王国，英王与苏王共主但不同国家。
- 联合条款Article 4涉及合法殖民贸易权，Articles 18–19保留苏格兰法院与法制；Article 15列明Equivalent总额£398,085 10s，有清债及达连投资者补偿等**多个**用途，不得把该法定总额当实际到达每名达连投资者的钱款。

## 5. 1702/1704爱尔兰地产法律颗粒度

- 英格兰议会1702年1 Anne c26法（特定没收地产的购买、继承、租赁），不能与爱尔兰议会1704年2 Anne c6法律混并为一个“英王查封所有爱尔兰土地”过程。明示法条豁免和担保条件，逐宗地籍还需原档。

## 6. 交给主编的制图顺序

1. 先解决York I/II/III历史地点身份和Eora水域争议，再考虑给地图放现代地名参考点。
2. 对1798 Wexford town/Enniscorthy设事件化临时控制episode；保留New Ross/Arklow政府军守点；严格拒绝全郡Polygon。
3. 把1707年法律/政制转换与殖民国土实际增减分层显示；严防1707向现代英属澳洲涂色。
4. 法律、地点、驻军和馆藏档必须有自身证据等级与原始文件读过与否标记。

新增机器表：`ROUND6_LOCAL_CONTROL_EPISODES.json`、`ROUND6_1798_LOCAL_REGIME_DECISIONS.json`、`ROUND6_LEGAL_PRECISION.json`；所有仍为research_only。
''',encoding='utf-8')
# additional tactical structured support for Ireland; no county polygon
wr('ROUND6_1798_LOCAL_REGIME_DECISIONS.json',{'schema':'assistant-C-1798-wexford-regime-v1','status':'research_only','map_notice':'no county-wide control polygon; exact dates for town handover need original dispatch', 'towns':[
 {'site':'Enniscorthy','phase':'held_by_insurgents','start':'1798-05-28','end':'1798-06-21 or earlier for town','boundary':None,'source_ids':['C6-IRL-HISTIRELAND-WEXFORD','C5-IRL-NAI-1798'],'map_decision':'local town core candidate only'},
 {'site':'Wexford town','phase':'Crown_garrison_left_insurgents_occupied','start':'1798-05-30','end':'June 1798; precise day requires validation','boundary':None,'source_ids':['C6-IRL-HISTIRELAND-WEXFORD','C5-IRL-NAI-1798'],'map_decision':'transient source-supported regime, not full county'},
 {'site':'New Ross','phase':'Crown_defended_garrison','start':'at least 1798-05-30','end':'1798-06-05 attack repulsed','boundary':None,'source_ids':['C6-IRL-HISTIRELAND-WEXFORD'],'map_decision':'day-level tactical event, not lasting rebel control'},
 {'site':'Arklow','phase':'Crown_defended_garrison','start':'1798-06-09','end':'1798-06-09','boundary':None,'source_ids':['C6-IRL-NAM-1798'],'map_decision':'battle point only, no rebel control'},
 {'site':'Newtownbarry','phase':'Crown-held foothold with attack 1798-06-01','start':'1798-05-30','end':'1798-06-01','boundary':None,'source_ids':['C6-IRL-HISTIRELAND-WEXFORD'],'map_decision':'remain uncertain for exact intra-day changes'},
 {'site':'Duncannon Fort','phase':'Crown_foothold','start':'1798-05-30','end':'later 1798 not dated in research','boundary':None,'source_ids':['C6-IRL-HISTIRELAND-WEXFORD'],'map_decision':'named fort control point pending garrison record'},
 {'site':'Vinegar Hill','phase':'rebel camp then Crown storming','start':'1798-05-29 tentative','end':'1798-06-21','boundary':None,'source_ids':['C5-IRL-NAI-1798','C6-IRL-NAM-1798'],'map_decision':'battle/camp point reference, no county control area'}]})
wr('ROUND6_LEGAL_PRECISION.json',{'schema':'assistant-C-statute-actor-and-effect-v1','status':'research_only','clauses':[
 {'statute':'1 Anne c26','legislature':'Parliament of England','enacted_year':1702,'target':'purchased Irish forfeited estates','section':'7','legal_effect':'underage Catholic raised beneficiary loses inheritance unless specified loyalty & religious oaths','caveat':'specific age/oath provisions and categories; not all Irish land','source_ids':['S53a']},
 {'statute':'1 Anne c26','legislature':'Parliament of England','enacted_year':1702,'target':'purchased Irish forfeited estates','section':'8','legal_effect':'restrict Catholic purchase of affected forfeited premises','caveat':'only within statute governed forfeited estates','source_ids':['S53a']},
 {'statute':'1 Anne c26','legislature':'Parliament of England','enacted_year':1702,'target':'purchased Irish forfeited estates','section':'9','legal_effect':'restrict leases to Protestants; penalties for Catholic beneficial leases','caveat':'cottage/cabin exception follows section 10','source_ids':['S53a']},
 {'statute':'1 Anne c26','legislature':'Parliament of England','enacted_year':1702,'target':'purchased Irish forfeited estates','section':'10','legal_effect':'cottage/cabin under 30 shillings yearly value exception for day labourers','caveat':'further limited by section 21 (2 acres max)','source_ids':['S53a']},
 {'statute':'1 Anne c26','legislature':'Parliament of England','enacted_year':1702,'target':'purchased Irish forfeited estates','section':'21','legal_effect':'day-labourer exception constrained to two acres and a single cottage','caveat':'documentary legal limit not a cadastral claim or counted expropriations','source_ids':['S53a']},
 {'statute':'2 Anne c6','legislature':'Parliament of Ireland','enacted_year':'1703/1704 session; assented 1704','target':'Catholic education, inheritance, office, voting and pilgrimage','section':'2','legal_effect':'suspected foreign schooling, requiring parents produce child','caveat':'do not infer any actual deportations from text alone','source_ids':['S53a','C4-IRL-PENAL-1704']},
 {'statute':'2 Anne c6','legislature':'Parliament of Ireland','enacted_year':'1703/1704 session; assented 1704','target':'religious inheritance','section':'3','legal_effect':'Protestant child could challenge Catholic parent estate through Chancery','caveat':'individual suit/transfer requires case evidence','source_ids':['S53a']},
 {'statute':'2 Anne c6','legislature':'Parliament of Ireland','enacted_year':'1703/1704 session; assented 1704','target':'Catholic parliamentary vote','section':'24','legal_effect':'religious oaths and abjuration conditions on voting','caveat':'1728 Act separate later comprehensive exclusion; do not mark 1704 as identical to 1728','source_ids':['S53a']},
 {'statute':'Acts of Union','legislature':'separate Scottish and English Parliaments','enacted_year':1707,'target':'state constitutional order','section':'4','legal_effect':'trade access to empire for Scottish and English subjects','caveat':'commercial access not military occupation, individual voyages unverified','source_ids':['C2-UNION-ART','C6-UK-COMMONS-UNION2026']},
 {'statute':'Acts of Union','legislature':'separate Scottish and English Parliaments','enacted_year':1707,'target':'Scotland legal/judicial system','section':'18–19','legal_effect':'separate Scottish laws and courts persist','caveat':'not merged legal jurisdictions despite shared Westminster Parliament','source_ids':['C2-UNION-ART','C6-UK-COMMONS-UNION2026']},
 {'statute':'Acts of Union','legislature':'separate Scottish and English Parliaments','enacted_year':1707,'target':'Equivalent fiscal transfer','section':'15','legal_effect':'statutory equivalent of £398,085 10s with multiple purposes','caveat':'no individual Darien payout, not all available money for Darien investors','source_ids':['C2-UNION-ART']}]})
# Baseline year-by-year decisions for 1699–1710 with more exact site identity in a new file; do not overwrite prior scheme
site_decisions=[]
for y in range(1699,1711):
 site_decisions += [
 {'site':'York Factory I / Fort Bourbon','year':y,'state':'French fort occupation per 1697–1713 institutional history interval','basis':'period source not separate yearly muster','source_ids':['C5-HBC-PARKS-YORK','C6-CAN-PARKS-YORK2007'],'historical_boundary_verified':False,'coordinates':None},
 {'site':'Churchill River first 1689 HBC post','year':y,'state':'no continuing first HBC fort following 1689 destruction, no 1717 renewed post yet','basis':'period source, does not prove absence of all transient European presence','source_ids':['C5-HBC-PARKS-CHURCHILL','C6-CAN-PARKS-PRINCE2024'],'historical_boundary_verified':False,'coordinates':None}
 ]
wr('ROUND6_1699_1710_SITE_IDENTITY_GRID.json',{'schema':'assistant-C-site-identity-year-end-v1','status':'research_only','decision_count':len(site_decisions),'year_end_site_checks':site_decisions,'disclaimer':'These are annotated period interpretations, not each-year primary garrison muster. Coordinates null, historical polygons forbidden.'})
# Update comments, counts, write after all additions
sj['source_count']=len(sj['sources']);ej['event_count']=len(ej['events']);cj['evidence_count']=len(cj['claims'])
wr('SOURCE_REGISTRY.json',sj);wr('EVENT_CANDIDATES.json',ej);wr('MAP_CANDIDATES.geojson',gj);wr('CLAIM_EVIDENCE_MATRIX.json',cj)
# CSVs regenerated consistent with source JSON field normalizations
for name,items in [('EVENT_CANDIDATES.csv',ej['events']),('CLAIM_EVIDENCE_MATRIX.csv',cj['claims'])]:
 keys=[]
 for row in items:
  for k in row:
   if k not in keys:keys.append(k)
 with (P/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=keys);w.writeheader()
  for d in items:w.writerow({k:json.dumps(v,ensure_ascii=False) if isinstance(v,(list,dict)) else v for k,v in d.items()})
print('sources',len(sj['sources']),'events',len(ej['events']),'places',len(gj['features']),'claims',len(cj['claims']),'conflicts',len(conf['conflicts']))
