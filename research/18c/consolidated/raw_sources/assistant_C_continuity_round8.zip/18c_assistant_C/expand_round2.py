"""Append second batch of research evidence. Research only; no GitHub write."""
from pathlib import Path
import json,csv
P=Path('/mnt/data/18c_assistant_C')
def load(n):return json.loads((P/n).read_text(encoding='utf-8'))
def save(n,obj):(P/n).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
S=load('SOURCE_REGISTRY.json');E=load('EVENT_CANDIDATES.json');C=load('CONTROL_TRANSITIONS_1699_1709.json');G=load('MAP_CANDIDATES.geojson');A=load('CROSS_CENTURY_AUDIT.json')
new_sources=[
 ('C2-DAR-2025','Revista de Indias / CSIC','Channing Eberhard & Pajuelo Moreno, La fallida colonia escocesa en el Darién (1698-1700): una historia entrelazada','https://revistadeindias.revistas.csic.es/index.php/revistadeindias/article/view/1835','peer_reviewed_open_article_search_index_extract_not_pdf_facsimile','1700年2月13日、3月15日、3月28日、4月12日、4月13日分阶段；需与Borland 1715日历历法核对'),
 ('C2-DAR-CHRONO','National Museums Scotland','The Darien Scheme: Second expedition','https://www.nms.ac.uk/discover-catalogue/the-darien-scheme','national_museum_article','第二远征1699-11-30抵达，1700-01攻打Toubacanti，后围攻投降撤离'),
 ('C2-UNION-ART','Scottish Archives for Schools / National Records of Scotland','Articles of Union 1707, Article 15','https://www.scottisharchivesforschools.org/union1707/chapter3-3.asp','national_archives_educational_article_text','£398,085 10s为Equivalent总额，多用途；不能等同达连全额赔偿'),
 ('C2-UNION-PAY','Scottish Archives for Schools / National Records of Scotland','Union 1707: Equivalent first instalment August 1707','https://www.scottisharchivesforschools.org/union1707/chapter8.asp','national_archives_educational_primary_records_index','1707-08首批Equivalent资金到达及支付记录E111'),
 ('C2-IRL-1702','University of Minnesota Law Library','Irish penal laws, Anne reign: English Act 1 Anne c26 (1702)','https://librarycollections.law.umn.edu/archive/irishlaws/chron-anne.html','archived_statutory_extracts','1702英格兰法令针对爱尔兰已没收庄园的天主教继承/租赁限制；不同1704爱尔兰法'),
 ('C2-IRL-1778','Church History / Cambridge University Press','Robert E Burns: The Catholic Relief Act in Ireland 1778','https://www.cambridge.org/core/journals/church-history/article/abs/catholic-relief-act-in-ireland-1778/00046185A6727830F62990B4BB170D6E','peer_reviewed_abstract','1778爱尔兰议会松动天主教土地获得与遗嘱处置限制，不能说1704法制到1798年保持不变'),
 ('C2-IRL-1782','UK Parliament','Meeting Ireland\'s Terms','https://www.parliament.uk/about/living-heritage/evolutionofparliament/legislativescrutiny/parliamentandireland/overview/meeting-irelands-terms/','parliamentary_history','1779-80贸易限制松动、1782年撤1720法、修改Poynings法律、爱尔兰议会获得立法权限'),
 ('C2-IRL-1783','Oireachtas / Irish Parliament','Irish statute law revision memorandum on the Declaratory Act and 1783 Renunciation','https://data.oireachtas.ie/ie/oireachtas/bill/1981/27/eng/memo/bills1983b-02.pdf','official_parliament_pdf_search_excerpt_not_facsimile_read','1782撤6 Geo I c5; 1783进一步承认爱尔兰立法与终审权限，需原法复核'),
 ('C2-IRL-1494','UK Parliament','Poynings\' Law institutional chronology','https://www.parliament.uk/about/living-heritage/evolutionofparliament/legislativescrutiny/parliamentandireland/overview/poynings-law/','parliamentary_history','16C起立法控制延续至1782，三世纪政治连续性重要来源'),
 ('C2-IRL-1798-ARCH','National Archives of Ireland','The Rebellion of 1798: 17 facsimile documents and contextual commentary','https://www.nationalarchives.ie/PDF/1798.pdf','government_archive_pdf_text_read_web_screenshot_unavailable','存档文献索引清楚记录1798-05-23/24、06-21、08-23等；未逐件核完整原始手稿影像'),
 ('C2-IRL-UNION','UK Parliament','Parliamentary Union, 1799 defeat, 1800 Act, 1801 commencement','https://www.parliament.uk/about/living-heritage/evolutionofparliament/legislativescrutiny/parliamentandireland/overview/parliamentary-union/','parliamentary_history','1799-01-24议会反对，1800-03-28通过文本，1801-01-01实际统一'),
 ('C2-IRL-1798-MUS','National Army Museum','Irish Rebellion 1798 overview','https://www.nam.ac.uk/explore/irish-rebellion-1798','national_museum_historical_analysis','Oulart、Vinegar Hill、Scullabogue各地冲突及责任有区别'),
 ('C2-SCO-SHEEP','Studies in Scottish Literature / University of South Carolina','Alexander Dick (2020), Bliadhna nan Caorach, Year of the Sheep','https://scholarcommons.sc.edu/ssl/vol46/iss1/6/','peer_reviewed_article_abstract','1792 Ross-shire Strathrusdale反牧羊土地抗议；约200参与驱赶约1万头为学术综述估计非逐人档册'),
 ('C2-SCO-CLEAR','Scottish History Society','Highland Clearances first wave and limitations','https://scottishhistorysociety.com/the-highland-clearances/','historical_society_educational_research','18C初期清场，1809–21 Sutherland典型但世纪不同'),
 ('C2-SCO-DRESS','National Records of Scotland','Tartan: the fabric of a nation; 1747 Act, 1782 repeal','https://www.nrscotland.gov.uk/learning-and-events/all-features-and-articles/tartan-the-fabric-of-a-nation/','national_archive_article','1747服饰法部分平民男性，1782撤销，不等于禁止盖尔语'),
 ('C2-SCO-PROTEST','Rural History / Cambridge University Press','Genealogies of protest in the Scottish Highlands after 1750','https://www.cambridge.org/core/journals/rural-history/article/genealogies-of-protest-and-resistance-in-the-scottish-highlands-and-islands-after-1750/8DEA32A2DC7044117CFC84CACF594BA9','peer_reviewed_article_page','1792抗争与其他18C反抗、19C Sellar事件分开'),
 ('C2-AU-COOKJ','National Museum of Australia / National Library of Australia','Cook journal full August 1770 transcription','https://www.nma.gov.au/exhibitions/endeavour-voyage/cooks-journal/august-1770','historic_journal_transcription','1770-08-22 Cook声索是其日记记载，未构成已占有东岸政治版图'),
 ('C2-AU-COOK-CONTEST','Australian Museum / Kaurareg Traditional Owners','Contested Possession: alternate Indigenous account of Tuined','https://australian.museum/learn/first-nations/unsettled/recognising-invasions/contested-possession/','museum_first_nations_oral_historical_account','传统所有者对Cook实际上岸/升旗叙事提出异议，不擅自断定岛上实际仪式'),
 ('C2-AU-FIRSTFLEET','State Library of NSW','First Fleet original journal material and 1787-88 voyage','https://www2.sl.nsw.gov.au/archive/discover_collections/history_nation/terra_australis/firstfleet.html','state_library_educational_primary_catalogue','11船从英国至Botany Bay及Sydney Cove的海上锚点；航路不可用直线GPS假装'),
 ('C2-AU-NSW-FLEET','Museums of History NSW','First Fleet passenger transportees figures','https://mhnsw.au/stories/general/first-fleet/','official_state_museum_analysis','759 transportees + 13 children reported;与SLNSW 750-780口径不同'),
 ('C2-AU-PARRA','City of Parramatta','Parramatta timeline 1788 to present','https://historyandheritage.cityofparramatta.nsw.gov.au/blog/2015/05/26/parramatta-timeline-1788-present','municipal_local_history','1788-11-02 Rose Hill建站、1789私人农场、1791授地、1791-06-04改名'),
 ('C2-AU-PARRA-IND','City of Parramatta','Rosehill brief history: Burramattagal Darug Country','https://historyandheritage.cityofparramatta.nsw.gov.au/research-topics/suburbs/rosehill-brief-history','municipal_first_nations_local_history','Burramattagal长期土地使用及殖民时期土地清除对资源影响'),
 ('C2-AU-NORFOLK','Australian Government DCCEEW','Kingston and Arthurs Vale Historic Area','https://www.dcceew.gov.au/parks-heritage/heritage/places/national/kavha','australian_government_heritage_history','1788-03-06 Kingston首次欧洲殖民小站及早期耕作，不把整岛所有权划为已测界'),
 ('C2-AU-PKJ','State Library of NSW','Philip Gidley King journal and 6 March 1788 Norfolk Island','https://www2.sl.nsw.gov.au/archive/discover_collections/history_nation/terra_australis/journals/gidley_king/index.html','original_manuscript_catalogue_with_summary','King在1788-03-06宣布占领Norfolk Island，馆方有原日志目录'),
 ('C2-AU-HAWKES','Towards Truth / Jumbunna Institute','Hawkesbury River 1795-1800 archival-document-linked research','https://www.towardstruth.org.au/themes/country/dispossession/120-frontier-wars/sub0533-hawkesbury-river','indigenous_rights_document_linked_historical_analysis','1794农地授权、1795年5月军队出击；7/8死与5俘是当局报告口径，不当最终精确死亡总数'),
 ('C2-AU-HAWKES-COUNCIL','Hawkesbury City Council','Hawkesbury local strategic plan historic timeline','https://www.hawkesbury.nsw.gov.au/__data/assets/pdf_file/0005/178349/LSPS-February-2021.pdf','government_pdf_search_index_timeline_not_full_pdf_read','1789河流探索、1794官方分授118名定居者（需土地名册再复核）'),
 ('C2-AU-PEMULWUY','Australian Dictionary of Biography / ANU','J. L. Kohen, Pemulwuy historical biography','https://adbonline.anu.edu.au/biography/pemulwuy-13147','academic_biographical_entry','1797-03军方追击伤害、医院拘押及同年4月前逃脱，1801/1802下一世纪'),
 ('C2-AU-PARRA-RES','City of Parramatta','Aboriginal Resistance Leader – Pemulwuy','https://historyandheritage.cityofparramatta.nsw.gov.au/research-topics/aboriginal/aboriginal-resistance-leader-pemulwuy','municipal_historical_article','1797-03先在Toongabbie袭击官田后到Parramatta外围冲突，勿合并1794'),
 ('C2-US-NJ','New Jersey government','A Short History of New Jersey: 1702 administrative handover','https://www.nj.gov/nj/about/history/short_history.shtml','state_government_history','1702领主交行政权但产权/土著主权独立'),
 ('C2-US-NJ-PRIMARY','Yale Avalon / Rutgers law','1702 East and West New Jersey surrender and 1702 commission','https://avalon.law.yale.edu/18th_century/nj13.asp','historical_legal_transcription','1702-04-15及04-17法律节点需区分土地契约'),
 ('C2-US-NJ-LAW','Rutgers Law','Leaming and Spicer primary compilation original instruments 1702','https://njlaw.rutgers.edu/statutes/LS.php','historical_printed_legislation_index','原1758印本目录明示1702-04-15交政和04-17接受'),
 ('C2-US-DE','Delaware Public Archives','Lower Three Counties separate assembly 1704, Penn governor retained','https://archives.delaware.gov/delaware-agency-histories/colonialprestatehood-records/','state_archives_government_history','1704新议会不等于独立州或划出欧洲新殖民领土'),
 ('C2-US-MA','Massachusetts Secretary of Commonwealth Archives','Province of Massachusetts Bay governorship 1692–1774','https://www.sec.state.ma.us/divisions/archives/collections/mass-archives-collection.htm','state_archive_official_governor_list','1700–02过渡管理及1702后Joseph Dudley任总督，与旧1692特许主权声索区分'),
 ('C2-US-DELNPS','US National Park Service','Delaware 12 Mile Arc and separate assembly 1704','https://www.nps.gov/articles/000/delaware-s-12-mile-arc.htm','national_park_history','下三郡1704独立议会，Penn行政仍保持'),
]
by_id={s['id'] for s in S['sources']}
for sid,org,title,url,depth,notes in new_sources:
 if sid not in by_id:S['sources'].append({'id':sid,'institution':org,'title':title,'url':url,'access_level':depth,'original_manuscript_personally_inspected':False,'reviewed_online_on':'2026-11-08','specific_use_and_limits':notes})
S['source_count']=len(S['sources']);save('SOURCE_REGISTRY.json',S)
# append record factory; new records include calendar and conflict markers when appropriate
new_events=[]
def ev(id,topic,date,precision,title,actor,action,place,refs,geometry=None,notes='',**kw):
 e={'id':id,'topic_id':topic,'date':date,'date_precision':precision,'title':title,'actor':actor,'action':action,'historical_place':place,'source_ids':refs,'research_state':'research_only','cartographic_status':'source_supported_event; mapping_review_required','geometry_ref':geometry,'historical_control_polygon_approved':False,'evidence_notes':notes}
 e.update(kw);new_events.append(e)
ev('C2-F09-001','E18-F09','1700-02-13','day_reported_calendar_unconfirmed','苏格兰达连堡击退西方袭击（史学记日）','苏格兰公司驻军；西班牙军队','据2025/26学术论文据Borland历史文本，苏军抵御一轮西班牙攻击','Fort St Andrew, Darien',['C2-DAR-2025'],geometry='PLACE-DARIEN',notes='二手史学引用的2月13日；西班牙/苏格兰的旧式新式日历未核；需原Borland 1715页60')
ev('C2-F09-002','E18-F09','1700-03-15','day_reported_calendar_unconfirmed','西班牙Pimienta发出撤离最后通牒','西班牙军官Pimienta；苏格兰公司殖民当局','提出协商撤离条件，苏格兰据点拒绝','Darien, Caret Bay / Fort St Andrew',['C2-DAR-2025'],geometry='PLACE-DARIEN',notes='二手来源日期；地点为区域，且日历来源待核')
ev('C2-F09-003','E18-F09','1700-03-28','day_reported_calendar_unconfirmed','苏格兰驻军提出议和条件','苏格兰公司驻军指挥者；西班牙Pimienta','苏方在被围后致信寻求投降/撤离条件','Fort St Andrew, Darien',['C2-DAR-2025'],geometry='PLACE-DARIEN',notes='源引Borland 1715 p153，未翻原卷；日历待核')
ev('C2-F09-004','E18-F09','1700-04-12','day_reported_calendar_unconfirmed','达连第二远征签订降约','苏格兰公司驻军；西班牙Pimienta军队','史学研究报告1700-04-12正式议定投降','Fort St Andrew, Darien',['C2-DAR-2025','C2-DAR-CHRONO'],geometry='PLACE-DARIEN',notes='研究引用Borland 1715；公历/旧历日期仍需辨析。不能把日历本体精确核准')
ev('C2-F09-005','E18-F09','1700-04-13','day_reported_calendar_unconfirmed','达连第二远征开始撤离','苏格兰公司殖民者','据研究投降次日开始离开堡垒；年末已无苏格兰殖民驻军','Fort St Andrew, Darien',['C2-DAR-2025'],geometry='PLACE-DARIEN',notes='开始撤离≠所有船最终离港日；需要原始航海日记')
ev('C2-F09-006','E18-F09','1707-08','month','1707年Equivalent补偿资金首批抵达苏格兰','大不列颠王国财政当局；苏格兰公司投资人与其他收款人','《联合条款》第15条下财税抵偿方案首期抵达，包含达连投资者补偿、官员欠薪等','Edinburgh, Kingdom of Great Britain',['C2-UNION-ART','C2-UNION-PAY'],geometry='PLACE-EDINBURGH',notes='Equivalent £398,085 10s是总法定资金，不能把全部误称达连投资人的净收益')
ev('C2-F01-001','E18-F01','1702','year','英格兰议会约束爱尔兰没收庄园天主教继承及租赁','英格兰王国议会与王室','1 Anne c26约束针对没收庄园的天主教继承、受让和租赁；给殖民产权制度增加1702节点','Kingdom of Ireland land-title cases; English Parliament',['C2-IRL-1702'],geometry='PLACE-DUBLIN',notes='英格兰法令影响爱尔兰地产，但不是1704爱尔兰议会2 Anne c6；不能绘为新增实控土地')
ev('C2-F01-002','E18-F01','1778','year','爱尔兰天主教土地限制首次重大松动','爱尔兰王国议会','通过首个重要Catholic Relief Act，松动土地获得和遗嘱处置方面的主要限制','Dublin, Kingdom of Ireland',['C2-IRL-1778'],geometry='PLACE-DUBLIN',notes='依据同行评审摘要，具体每section需原法对照')
ev('C2-F02-001','E18-F02','1779-1780','multi_year_legislative_reforms','英国松动爱尔兰对外贸易限制','大不列颠王国议会；爱尔兰商人及政治运动','分项取消若干贸易限制，爱尔兰仍受东印度公司垄断约束','Westminster and Dublin',['C2-IRL-1782'],geometry=None,notes='贸易松绑是多个法案，不能聚合为单日占地')
ev('C2-F02-002','E18-F02','1782','year','大不列颠撤销1720爱尔兰依附宣示法','大不列颠议会；爱尔兰王国议会','撤销6 George I c5并修改Poynings Law，使爱尔兰议会立法与上诉权限改变','Westminster / Dublin',['C2-IRL-1782','C2-IRL-1494'],geometry='PLACE-DUBLIN',notes='这是此前F02 1719/1720法律限制的反向节点，英国行政任命权仍继续')
ev('C2-F02-003','E18-F02','1783','year','大不列颠进一步承认爱尔兰立法司法权限','大不列颠议会；爱尔兰王国议会','通过Renunciation Act，进一步确定仅爱尔兰议会法律约束其事务','Westminster / Dublin',['C2-IRL-1783'],geometry='PLACE-DUBLIN',notes='Oireachtas官方说明不是原法全文；需复核23 Geo III c28原文')
ev('C2-F05-001','E18-F05','1792','year','高地Year of the Sheep牧羊驱赶抗议','Ross-shire的Strathrusdale及邻近高地居民','为抗议大地主向高地引入牧羊场，约两百人参与将羊群向Inverness驱赶','Strathrusdale / Ross-shire',['C2-SCO-SHEEP','C2-SCO-PROTEST'],geometry=None,notes='研究摘要提最多约10,000只羊的说法，属于估计，不是核定被驱逐家庭/羊数；不生成路径线',reported_participants_approx=200,reported_sheep_estimate_upper=10000)
ev('C2-D01-001','E18-D01','1770-08-22','day','库克记载的占有仪式受到Kaurareg传统所有者质疑','James Cook；Kaurareg传统所有者','航海日志称在Tuined升旗宣示东岸；Kaurareg守护者的口述历史质疑Cook曾登岛/升旗','Tuined / Possession Island',['C2-AU-COOKJ','C2-AU-COOK-CONTEST'],geometry=None,notes='这是史料冲突标记，不是第二次征服事件；航海日志声称与当地族群历史证言并列',evidence_conflict='Cook journal versus Kaurareg custodians; do not resolve unilaterally')
ev('C2-D03-001','E18-D03','1788-03-06','day','殖民队伍在诺福克岛建立Kingston据点','Philip Gidley King；英国殖民海军；囚犯','在Norfolk Island Kingston登陆并形成小型殖民据点，以囚犯劳动开垦','Kingston / Arthurs Vale, Norfolk Island',['C2-AU-NORFOLK','C2-AU-PKJ'],geometry=None,notes='本地设站点不能等同整岛殖民实控边界；早期波利尼西亚住民考古另查')
ev('C2-D03-002','E18-D03','1788-11-02','day','Rose Hill建立内陆殖民农耕据点','Arthur Phillip总督及新南威尔士殖民人员','在Burramattagal/Darug Country确立玫瑰山内陆定居与农耕工作站','Rose Hill (now Parramatta)',['C2-AU-PARRA','C2-AU-PARRA-IND'],geometry=None,notes='有据地点但无1788历史围界及当日土地清册；不可用现代Parramatta城区划成英国占领面积')
ev('C2-D10-001','E18-D10','1789-11-01','day','James Ruse在Rose Hill开始早期私人耕作','获流放的James Ruse；殖民土地当局','Rose Hill已形成个人耕作试验并改变Burramattagal传统资源利用','Rose Hill / Parramatta',['C2-AU-PARRA'],geometry=None,notes='市档年表，勿把耕作扩大为整块现代Parramatta行政区域')
ev('C2-D10-002','E18-D10','1791-03-30','day','Rose Hill的Experiment Farm授地','Arthur Phillip殖民政府；James Ruse','市政年表记No.1 grant 1791-03-30，授予早期流放者农业用地','Rose Hill / Parramatta',['C2-AU-PARRA'],geometry=None,notes='行政授地事实可核，历史地籍轮廓未经复核；市政年表同时称30英亩，未取得原契据')
ev('C2-D10-003','E18-D10','1791-06-04','day','Rose Hill定居点改名Parramatta','新南威尔士殖民政府','英方将已建定居点以源于原住民地名的Parramatta命名','Parramatta',['C2-AU-PARRA','C2-AU-PARRA-IND'],geometry=None,notes='原住民地名连续但英方改名不是新征服')
ev('C2-D10-004','E18-D10','1793','year','第一批内陆殖民道路连接悉尼与Parramatta','新南威尔士殖民政府和劳动者','市档记首条Sydney–Parramatta道路兴建，路位与施工区需地籍校正','Sydney–Parramatta corridor',['C2-AU-PARRA'],geometry=None,notes='不画假设直线公路；历史路线需原规划图')
ev('C2-D10-005','E18-D10','1793-1794','year_range','Hawkesbury河沿岸开始殖民农业定居及授地','新南威尔士殖民官署与定居者','1793末至1794殖民者进入河岸地并有1794追认赠地，影响Darug/Darkinjung地区','Hawkesbury River riverbanks',['C2-AU-HAWKES'],geometry=None,notes='地点仅为河岸区域，逐块契据与实际占地需要查；不画整个河流两岸殖民实控面')
ev('C2-D10-006','E18-D10','1794','year','Hawkesbury Green Hills/Mulgrave Place设早期农业聚居','新南威尔士殖民当局；流放服刑结束者','拓展至Hawkesbury河Green Hills附近，部分分授地块形成实际耕作据点','Green Hills / Mulgrave Place (later Windsor)',['C2-AU-HAWKES','C2-AU-HAWKES-COUNCIL'],geometry=None,notes='据地方政府及历史原文摘要，授地面积、地块尚不可合成现代市界')
ev('C2-D10-007','E18-D10','1799','year','Hawkesbury定居人口报告进入千人规模','殖民人口记录；Hawkesbury河沿岸定居点','Towards Truth来源引人口史档称1799年末定居人口1008，为官方/历史记录口径','Hawkesbury river settlements',['C2-AU-HAWKES'],geometry=None,notes='1,008为该来源报告的人口，不是受害者数或实际控制面积；人口研究独立存栏',reported_settler_population=1008)
ev('C2-D06-001','E18-D06','1795-05','month','Hawkesbury军队奉令惩罚原住民并实施致命镇压','代理总督William Paterson；殖民士兵；当地原住民','殖民官署派62名士兵驱逐Darug等社群，殖民官员事后报告七八名原住民被杀及5人俘获','Hawkesbury River, NSW',['C2-AU-HAWKES'],geometry=None,notes='军方报告的7/8死和5俘属官员自述，不能扩展为全区独立核实伤亡/伪造精确遇害点',reported_soldiers=62,reported_killed_range=[7,8],reported_captives=5,reported_number_status='colonial_official_report_not_independently_approved')
ev('C2-D06-002','E18-D06','1796-02','month','Hunter针对Hawkesbury冲突下令殖民者协同出击又限制随意杀害','总督John Hunter；Hawkesbury河定居者','令殖民定居者在可能发生大型袭扰时互相协作，同时禁止无故射杀原住民','Hawkesbury River, NSW',['C2-AU-HAWKES'],geometry=None,notes='殖民政府命令文字≠其在地方实际贯彻或本地治权已覆盖沿岸')
ev('C2-D09-001','E18-D09','1797-03','month','Pemulwuy先袭Toongabbie官田，后在Parramatta外围受伤','Pemulwuy和Bidjigal抵抗群体；殖民定居者/士兵','两场连锁行动地理不同，应分别验证袭击与追击位置','Toongabbie -> outskirts of Parramatta',['C2-AU-PEMULWUY','C2-AU-PARRA-RES'],geometry=None,notes='此为地理纠错候审，不画无GPS的追击线路；后者伤后囚院并逃走')
ev('C2-F06-001','E18-F06','1798-05-23/24','night_range','爱尔兰起义在Kildare、Meath与Dublin一带爆发','United Irishmen起义者；王室军队与地方治安力量','据爱尔兰国家档案馆，5月23—24日晚三郡主要行动先于Wexford起义','Dublin / Kildare / Meath',['C2-IRL-1798-ARCH'],geometry=None,notes='不同地区行动不表示所有城镇同晚完成政治易手')
ev('C2-F06-002','E18-F06','1798-08-23','day','法军增援在Killala Bay登陆','法国远征队；联合爱尔兰人；当地支持者','国家档案馆记录1798-08-23 Killala Bay登陆及随后Mayo等地区反抗','Killala Bay, County Mayo',['C2-IRL-1798-ARCH'],geometry=None,notes='更精确登陆日更新现有C-F06-005的仅月份精度；不是独立的第二次登陆')
ev('C2-F06-003','E18-F06','1798-05-27','day','Oulart政府军战败信件由Wexford副市长呈报','Ebenezer Jacob, Deputy Mayor；王室军队；Wexford起义者','国家档案馆第8号影印目录包括当日Oulart败报，可交叉核实既有战事记录','Oulart Hill / Wexford',['C2-IRL-1798-ARCH','C2-IRL-1798-MUS'],geometry=None,notes='此为史料关联记录，不算一场新战争；原文胜负评价需逐封审读')
ev('C2-F06-004','E18-F06','1798-06-06','day','Wexford起义联军发布军队命令','Wexford United Army领导者','国家档案馆facsimile 10登记起义军当日命令，帮助确认其内部军事组织','Wexford (exact drafting site unknown)',['C2-IRL-1798-ARCH'],geometry=None,notes='国家档案馆影印文件目录确认日期，具体发布地点与内容细节须原件核验')
ev('C2-F06-005','E18-F06','1798-09-25','day','Killala收复后的军情书信','Joshua Kemmis；爱尔兰王室军事当局','爱尔兰国家档案馆载9月25日Ballina来信，描述政府军取得Killala的行动','Ballina / Killala, County Mayo',['C2-IRL-1798-ARCH'],geometry=None,notes='这是来信日期，不能直接当城镇被攻克确切当日')
ev('C2-C22-001','E18-C22','1702','year','新泽西从领主行政权转由英格兰王室','East and West Jersey proprietors；Queen Anne','1702-04-15签交政文书、04-17王室受理，形成统一王室殖民政府；土地所有权未一并转让','East and West Jersey provincial administration',['C2-US-NJ','C2-US-NJ-LAW','C2-US-NJ-PRIMARY'],geometry=None,notes='本事件与北美助手领域重叠，仅记录控制制度断点，不开展新泽西后续大规模调查')
ev('C2-C22-002','E18-C22','1704','year','Delaware下三郡建立单独议会但仍在Penn总督之下','Lower Three Counties representatives；William Penn','New Castle、Kent、Sussex辖区获得单独议会，未独立国家或退出Penn统治','New Castle (Three Lower Counties)',['C2-US-DE','C2-US-DELNPS'],geometry=None,notes='跨世纪行政断点候审；本事件属于助手1研究领域，仅提供协作锚点')
existing={x['id'] for x in E['events']}
for x in new_events:
 if x['id'] not in existing:E['events'].append(x)
E['event_count']=len(E['events']);save('EVENT_CANDIDATES.json',E)
# add new feature placeholders with explicit null geometry and supplied name, never fabricate coordinates
existing_feats={x['id'] for x in G['features']}
places=[('PLACE-NORFOLK-KINGSTON','Kingston/Arthurs Vale Norfolk Island',['C2-AU-NORFOLK','C2-AU-PKJ']),('PLACE-PARRAMATTA','Rose Hill / Parramatta',['C2-AU-PARRA','C2-AU-PARRA-IND']),('PLACE-HAWKESBURY','Hawkesbury River Green Hills / Mulgrave Place',['C2-AU-HAWKES']),('PLACE-STRATHRUSDALE','Strathrusdale, Ross-shire',['C2-SCO-SHEEP']),('PLACE-TUINED','Tuined / Possession Island',['C2-AU-COOK-CONTEST']),('PLACE-OULART','Oulart Hill, County Wexford',['C2-IRL-1798-ARCH']),('PLACE-KILLALA','Killala Bay, County Mayo',['C2-IRL-1798-ARCH']),('PLACE-NEWCASTLE-DE','New Castle lower three counties separate assembly',['C2-US-DE'])]
for pid,name,sids in places:
 if pid not in existing_feats:
  G['features'].append({'type':'Feature','id':pid,'geometry':None,'properties':{'name':name,'source_ids':sids,'linked_event_ids':[x['id'] for x in E['events'] if name.lower().split('/')[0] in x['historical_place'].lower()],'coordinate_method':'no_coordinate_supplied; named_historical_locality','coordinate_status':'unlocated_pending_independent_reference','geo_precision':'historic_name_locality_only_not_site_geometry','historical_boundary_confirmed':False,'territorial_claim':False,'fill_authorized':False,'area_sqkm':None,'exclude_from_area_aggregation':True,'publication_status':'research_only','map_inclusion':'review_name_only'}})
save('MAP_CANDIDATES.geojson',G)
# enrich previously known specific events without changing their original IDs or claims
for e in E['events']:
 if e['id']=='C-D01-001':e['evidence_conflict']={'source_ids':['C2-AU-COOKJ','C2-AU-COOK-CONTEST'],'summary':'Journal date and claim exist; Kaurareg custodians dispute island landing and flag ceremony. Not de facto east-coast control.'}
 if e['id']=='C-F09-003':e['subevents_new_source_review']=['C2-F09-001','C2-F09-002','C2-F09-003','C2-F09-004','C2-F09-005'];e['precision_refinement_not_overwritten']=True
 if e['id']=='C-D09-001':e['map_note_update']='1797 Toongabbie farm raid, subsequent Parramatta outskirts confrontation; 1794 Toongabbie is a separate conflict.'
 if e['id']=='C-F06-005':e['date_refinement_source']='C2-F06-002'
save('EVENT_CANDIDATES.json',E)
# Annual control updates: only administrative state, never inferred polygons
for q in C['candidates']:
 sid=q['stable_id']
 for r in q['year_end_reviews']:
  y=r['year']
  if sid=='C-TRANS-MASSACHUSETTS':
   r['year_end_evidence_state']='province_royal_governance_attested_boundary_unverified';r['source_ids']=sorted(set(r['source_ids']+['C2-US-MA']))
   r['documented_royal_office']=('Earl of Bellomont until death 1700; Stoughton acting later in 1700' if y==1700 else 'William Stoughton acting; Council after his 1701 death' if y==1701 else 'Council then Joseph Dudley in 1702' if y==1702 else 'Joseph Dudley, royal governor (office list 1702–1715)')
   r['note']='Massachusetts Archives lists actual provincial governors for this year; no surveyed border or Indigenous cession established by list.'
  elif sid=='C-TRANS-DELAWARE':
   if y<=1703:r['year_end_evidence_state']='lower_counties_shared_pennsylvania_assembly_governance_attested';r['note']='Delaware Public Archives states Lower Counties shared Pennsylvania assembly until 1704; actual county boundaries and Indigenous rights not implied.'
   else:r['year_end_evidence_state']='separate_lower_counties_assembly_same_penn_governor_documented';r['note']='1704 Lower Counties separate Assembly; remained directly under Penn-appointed Pennsylvania Governor and proprietor/royal authority.'
   r['source_ids']=sorted(set(r['source_ids']+['C2-US-DE','C2-US-DELNPS']))
  elif sid=='C-TRANS-NEWJERSEY' and y>=1702:
   r['year_end_evidence_state']='royal_administration_from_1702_land_property_rights_not_transferred'
   r['legal_change_anchor']='1702-04-15 proprietor surrender signed; 1702-04-17 Queen acceptance per legal compilation'
   r['source_ids']=sorted(set(r['source_ids']+['C2-US-NJ','C2-US-NJ-LAW']))
   r['note']='Crown takes civil governance of East/West Jersey, not proprietors land property, not Native polity sovereignty. Existing charter reference area unverified.'
  elif sid=='C-TRANS-DARIEN' and y==1700:
   r['source_ids']=sorted(set(r['source_ids']+['C2-DAR-2025','C2-DAR-CHRONO']))
   r['reported_capitulation_date']='1700-04-12 as reported in Revista de Indias academic article (calendar unresolved)'
   r['reported_evacuation_start']='1700-04-13 as reported (not final ship departure)'
   r['note']='Scots garrison besieged and capitulated in 1700. By year end no Scots occupation of fort. Exact historical calendar and final sailing date need Borland/Spanish archival verification.'
  elif sid=='C-TRANS-IRELAND' and y==1702:
   r['source_ids']=sorted(set(r['source_ids']+['C2-IRL-1702']))
   r['statute_land_rights_note']='English statute 1 Anne c26 affected forfeited Irish estates; does not represent an Irish kingdom-wide newly occupied land polygon.'
  elif sid=='C-TRANS-IRELAND' and y==1704:
   r['source_ids']=sorted(set(r['source_ids']+['C2-IRL-1702']))
   r['statute_land_rights_note']='1704 Irish 2 Anne c6 extends religious disability system, distinct from previous 1702 English law.'
  elif sid=='C-TRANS-NEWFOUNDLAND' and y==1700:
   r['year_end_evidence_state']='1699_fishery_statute_operative_1700_no_whole_island_actual_control_proof'
   r['note']='Some articles of the 1699 fishery act in force 1700-03-25; neither fishing ordinance nor colonial charter is a whole-island garrison or Beothuk land transfer.'
C['investigation_round2']={'date':'2026-11-08','method':'institutional archival/list/legal checkpoints; unchanged 27 seed diagram boundaries not approved','new_controls_with_positive_office_evidence':['C-TRANS-MASSACHUSETTS','C-TRANS-DELAWARE','C-TRANS-NEWJERSEY'],'additional_dates':['1700-04-12 scholarly Darien capitulation (unresolved calendar)','1702-04-15/17 NJ surrender/acceptance','1704 Delaware independent assembly','1702 English Irish estate statute','1704 Irish penal law','1707 Scotland/England union'], 'no_true_control_polygons':True}
save('CONTROL_TRANSITIONS_1699_1709.json',C)
# Additional audit corrections: early ending of Old charter episode != end of proprietary private ownership
for row in A['entries']:
 if row['previous_story_id']=='E6-T04-DARIEN':
  row['new_1700_end_evidence']='1700 capitulation per scholarly article reported Apr 12; first evacuations Apr 13; historic calendar not resolved'
  row['new_source_ids']=sorted(set(row.get('new_source_ids',[])+['C2-DAR-2025','C2-DAR-CHRONO']))
 if row['previous_story_id']=='E6-T03-LAND-1642-1698':
  row['new_legislative_breaks']=[1702,1704,1778,1782,1783]
  row['new_source_ids']=sorted(set(row.get('new_source_ids',[])+['C2-IRL-1702','C2-IRL-1778','C2-IRL-1782']))
 if row['previous_story_id']=='E6-T09-CAR':
  row['new_audit_warning']='New Jersey 1702/Delaware 1704 distinct colonial governance; this parent Carolina topic is not their precursor.'
save('CROSS_CENTURY_AUDIT.json',A)
# derive CSV dynamically; standard columns original plus extra event fields as JSON strings
with (P/'EVENT_CANDIDATES.csv').open('w',encoding='utf-8-sig',newline='') as f:
 keys=['id','topic_id','date','date_precision','title','actor','action','historical_place','source_ids','research_state','cartographic_status','geometry_ref','historical_control_polygon_approved','evidence_notes']
 writer=csv.DictWriter(f,fieldnames=keys);writer.writeheader()
 for e in E['events']:
  writer.writerow({k:(';'.join(e[k]) if k=='source_ids' else str(e[k]) if e.get(k) is not None else '') for k in keys})
print('saved',E['event_count'],'events',S['source_count'],'sources',len(G['features']),'named localities')
