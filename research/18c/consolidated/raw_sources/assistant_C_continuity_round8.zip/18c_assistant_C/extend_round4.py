"""Assistant C round 4. Append-only historical research, independent sourced corrections. GitHub untouched."""
from pathlib import Path
from datetime import date
import json,csv
p=Path('/mnt/data/18c_assistant_C')

def read(n):return json.loads((p/n).read_text(encoding='utf-8'))
def write(n,o): (p/n).write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def append(n,s):
 with (p/n).open('a',encoding='utf-8') as f:f.write('\n'+s.rstrip()+'\n')

sr=read('SOURCE_REGISTRY.json'); ev=read('EVENT_CANDIDATES.json');cl=read('CLAIM_EVIDENCE_MATRIX.json');gc=read('MAP_CANDIDATES.geojson');cf=read('ROUND3_EVIDENCE_CONFLICTS.json');sc=read('SITE_SPECIFIC_CONTROL_1697_1715.json');ct=read('CONTROL_TRANSITIONS_1699_1709.json');aud=read('CROSS_CENTURY_AUDIT.json')
# Each added URL points to inspected source. Duplicate pre-existing source URLs deliberately reuse source ID.
url_to_id={x['url']:x['id'] for x in sr['sources']}
new_sources=[
('C4-IRL-ANNE-STAT','University of Minnesota Law Library (archived historical law transcription)','Irish Penal Law: statutes under Queen Anne, sectioned transcriptions of 1702 English and 1703/04 Irish acts','https://librarycollections.law.umn.edu/archive/irishlaws/chron-anne.html','historical_legal_text_transcription; original vellum folio not viewed'),
('C4-IRL-ASSENT-1704','Yale MacMillan Center, historical text','1824 Historical Account of Irish Catholic Penal Laws: 4 March 1704 royal assent','https://macmillan.yale.edu/glc/history-penal-laws-against-irish-catholics','historical_secondary_text_digitization'),
('C4-IRL-BURNS','Cambridge University Press','Robert E Burns, Catholic Relief Act 1778 interpretation','https://www.cambridge.org/core/journals/church-history/article/abs/catholic-relief-act-in-ireland-1778/00046185A6727830F62990B4BB170D6E','peer_reviewed_abstract_not_full_article'),
('C4-SCO-NRS-ESTATE','National Records of Scotland','E738 Forfeited Estates 1745: particular estate series Arnprior, 1747 Vesting, 1752 annexing','https://catalogue.nrscotland.gov.uk/nrsonlinecatalogue/details.aspx?reference=E738','official_archive_catalogue_description_not_original_deeds'),
('C4-SCO-NRS-GUIDE','National Records of Scotland','Exchequer records: E600-687, E701-788 forfeit estates papers 1716–1824','https://www.nrscotland.gov.uk/learning-and-events/research-guides/exchequer-records/','official_archive_guide'),
('C4-SCO-NLS-JAC','National Library of Scotland','Jacobites timeline: 1747 Vesting Act, confiscations','https://www.nls.uk/collections/stories/scottish-history/jacobites-timeline/','national_library_chronology'),
('C4-SCO-TNA-JAC','The National Archives (UK)','1715 and 1745 Jacobite risings official archive series guide','https://www.nationalarchives.gov.uk/help-with-your-research/research-guides/jacobite-risings-1715-and-1745/','official_archive_guide'),
('C4-SCO-DISARM','NCBI Bookshelf, academic history chapter','Contextualising the punishment of death: 1716 and 1725 Scottish disarming acts, 1746 repression','https://www.ncbi.nlm.nih.gov/books/NBK481739/','academic_book_chapter_public_fulltext'),
('C4-SCO-CLEARWAVE','Scottish History Society at University of Glasgow','1780–1825 first Highland clearances and Sutherland chronology','https://www.scottishhistorysociety.org/departments/scottishhistorysociety/learningresources/thehighlandclearances/briefaccountofevents/1780-1825thefirstwaveofclearancesandsutherland/index.html','historical_society_educational_research'),
('C4-AU-ANMM-WATER','Australian National Maritime Museum','Contested waterways: Aboriginal canoe raids, 1788 canoe appropriation, Balloderry 1791 and Hawkesbury 1795–97','https://www.sea.museum/en/first-nations/contested-waterways','national_museum_historical_essay_with_period_accounts'),
('C4-AU-ANU-BENN','Australian National University Press','Keith Vincent Smith, Bennelong among his people, Aboriginal History 33','https://press-files.anu.edu.au/downloads/press/p74631/html/ch01.html?page=4&referer=','academic_journal_open_fulltext_with_primary_period_citations'),
('C4-AU-ANU-PEM','Australian Dictionary of Biography (ANU)','Pemulwuy biography with March 1797 shooting and hospital escape','https://adbonline.anu.edu.au/biography/pemulwuy-13147','academic_biographical_research'),
('C4-AU-RYDE-BENN','City of Ryde (NSW)','Bennelong and Colebee Manly Cove 25 Nov 1789 abduction','https://www.ryde.nsw.gov.au/Finding-Bennelong/Abduction?lang_update=639273559362686604','local_government_historical_analysis'),
('C4-AU-RYDE-PEM','City of Ryde (NSW)','Pemulwuy March 1797 fighting and wounded/captured escape','https://www.ryde.nsw.gov.au/Finding-Bennelong/Glossary/Pemulwuy','local_government_historical_analysis'),
('C4-AU-NMA-PEM','National Museum of Australia','Pemulwuy primary-dispatch history; dates and command chronology','https://www.nma.gov.au/defining-moments/resources/pemulwuy','national_museum_primary_dispatch_quoted'),
('C4-CAN-PARKS-FORTWILL','Parks Canada','Fort William national designation approved plaque: 1705 resisted, 1709 captured destroyed','https://www.pc.gc.ca/apps/dfhd/page_nhs_eng.aspx?id=240','federal_heritage_designation; internal 1708/1709 inscription inconsistency recorded'),
('C4-CAN-PARKS-PLACENTIA','Parks Canada','Placentia/Plaisance French colony capital from 1662 until Treaty of Utrecht in 1713','https://www.pc.gc.ca/apps/dfhd/page_nhs_eng.aspx?id=10390','federal_heritage_designation'),
('C4-CAN-NEWF-STJOHNS','Memorial University Newfoundland and Labrador Heritage','St Johns 1500-1815 Fort William battles and fortification chronology','https://www.heritage.nf.ca/articles/society/st-johns-1815.php','university_regional_history'),
('C4-CAN-GOV-FORTS1926','Natural Resources Canada archival hosting, 1926 government printed list','Forts and Trading Posts in Labrador Peninsula: Albany 1696 recapture/1709 assault','https://geochem.nrcan.gc.ca/ftp/data/publications/pub_10480/labrador_forts_and_trading_posts.pdf','historical_government_compilation_not_original_hbc_journal; cover screenshot reviewed'),
('C4-CAN-DCB-BEALE','Dictionary of Canadian Biography, scholarly institutional project','Anthony Beale and Albany Fort 1700–1714 government vs real site','https://www.biographi.ca/en/bio/633?revision_id=6422','biographical_scholarship_search_excerpt_site_rate_limited'),
('C4-CAN-DCB-KNIGHT','Dictionary of Canadian Biography','James Knight Albany Fort English until 1713, York Fort French after 1697','https://www.biographi.ca/en/bio/knight_james_2E.html?revision_id=25239','biographical_scholarship'),
('C4-CAN-MHS-YORK1714','Manitoba Historical Society','York Fort 1714–1716 documented reoccupation and French memoir context','https://mhs.mb.ca/docs/transactions/3/yorkdemography.shtml','regional_historical_society_article'),
('C4-IRE-NAI-1798','National Archives of Ireland','1798 rebellion facsimiles introduction and document list (govt and rebel documents)','https://www.nationalarchives.ie/PDF/1798.pdf','archival_educational_document_list_extracted_text; PDF screenshot unavailable; no claim of image inspection'),
('C4-IRE-NAM-1798','National Army Museum','Irish Rebellion 1798, dates Oulart, Arklow, Vinegar Hill','https://www.nam.ac.uk/explore/irish-rebellion-1798','national_army_museum_historical_analysis'),
('C4-CAN-PARKS-YORK','Parks Canada','York Factory history 1697 French reoccupation to 1713 treaty','https://parks.canada.ca/lhn-nhs/mb/yorkfactory/culture/histoire-history','federal_historic_site_research'),
('C4-IRE-UW-SMITH','Australian National University Press','Bennelong among his people, Arabanoo grabbed 30 December 1788','https://press-files.anu.edu.au/downloads/press/p74631/html/ch01.html?page=4&referer=','peer_reviewed_aboriginal_history_research'),
]
new_ids=[]
for sid,inst,title,url,depth in new_sources:
 if url in url_to_id:
  new_ids.append((sid,url_to_id[url]));continue
 if sid in {x['id'] for x in sr['sources']}:raise RuntimeError('Duplicate '+sid)
 sr['sources'].append({'id':sid,'institution':inst,'title':title,'url':url,'access_level':depth,'original_manuscript_personally_inspected':False,'reviewed_online_on':'2026-11-08','source_handling':'Official archive description ≠ original folio; scholarship and historical transcription marked by access_level.'})
 url_to_id[url]=sid;new_ids.append((sid,sid))
sidmap={a:b for a,b in new_ids}
def S(sid):return sidmap.get(sid,sid)
sr['source_count']=len(sr['sources'])

# All dates qualified by precision. Avoid duplicating old topic entries; 16C/17C IDs retained.
new_events=[
('C4-C26-001','E18-C26','1705','year','法军破坏圣约翰斯定居点、威廉堡抵御攻击','法属普莱桑斯出发的军队','进攻英方圣约翰斯，虽毁坏定居地，但未攻占Fort William','St. John’s / Fort William',['C4-CAN-PARKS-FORTWILL','C4-CAN-NEWF-STJOHNS'],None,'城镇与堡垒必须分开标；不能按“1705法军夺堡”制图'),
('C4-C26-002','E18-C26','1709','year','法军攻占并拆毁圣约翰斯威廉堡','法国Saint-Ovide指挥的袭击队','攻占并破坏Fort William防御设施；旧式1708/09记年与后代碑铭存在差异','Fort William, St. John’s',['C4-CAN-PARKS-FORTWILL','C4-CAN-NEWF-STJOHNS'],None,'1709年末应标堡垒不再作为原英军有驻守堡；不等于法军当年末在那里持续驻军'),
('C4-C26-003','E18-C26','1713','year','法国将普莱桑斯要塞与殖民据点让予大不列颠','法国王室／大不列颠王室','依据乌得勒支条约将Plaisance殖民据点移交英国方面','Plaisance / Placentia',['C4-CAN-PARKS-PLACENTIA'],None,'条约年和各堡实际移交日尚需单证；不可据此宣称当年全岛各原住民族政权被征服'),
('C4-C27-001','E18-C27','1705','year','Anthony Beale获任奥尔巴尼堡管理职务','哈德孙湾公司','委任Beale管理Albany相关事务，文书权限包含更广流域但实际管理限于詹姆斯湾据点','Albany Fort, James Bay',['C4-CAN-DCB-BEALE'],None,'职位领地范围为纸面法权，不是大片实控疆域'),
('C4-C27-002','E18-C27','1709','year','法军攻打奥尔巴尼堡未能得手','来自法属加拿大的法军','对Fort Albany发动进攻但守军击退','Fort Albany, James Bay',['C4-CAN-GOV-FORTS1926'],None,'1926年政府编纂源于历史文件目录；具体进攻月份、双方人数未核'),
('C4-C27-003','E18-C27','1714','year','哈德孙湾公司在乌得勒支条约后重新驻守约克堡','哈德孙湾公司英国人员','有1714年起约克堡现场英方日记及重新管理记录','York Fort / Fort Bourbon, Hayes River',['C4-CAN-MHS-YORK1714','C4-CAN-PARKS-YORK'],None,'1713和约不等同1713当日英国实体进驻；实际移交详细日子待原日记'),
('C4-F01-001','E18-F01','1704-03-04','day','爱尔兰惩罚法限制天主教土地取得及31年租约','爱尔兰议会（王后恩准）','2 Anne c.6第6节限制购地及租约，部分转让追溯以1703年3月24日为参照日期','Kingdom of Ireland (legislative seat Dublin)',['C4-IRL-ANNE-STAT','C4-IRL-ASSENT-1704'],'PLACE-DUBLIN','1703既是议会会期标号也是条文追溯截点，1704年3月4日为王室批准；法律不是1703年占领地块'),
('C4-F01-002','E18-F01','1704-03-04','day','爱尔兰惩罚法奖励宗教改宗并限制天主教监护权','爱尔兰议会','第3、4节规定改宗子女继承及天主教监护权限制的法定机制','Kingdom of Ireland (statutory national scope)',['C4-IRL-ANNE-STAT','C4-IRL-ASSENT-1704'],'PLACE-DUBLIN','只能标法律文本与机制；不得推造每个爱尔兰郡发生了多少宗地权变更'),
('C4-F01-003','E18-F01','1705-03-24','day','戈尔韦、利默里克城内天主教住民担保期限','爱尔兰议会与城市当局','2 Anne c.6第23及28节规定部分天主教住民需在限日前提供担保，否则按条款迁出；法定职业/房价例外另记','Galway and Limerick (two separate named cities)',['C4-IRL-ANNE-STAT'],None,'这是法定条件截止日期；尚无证据说明两城1705年实际迁出人数，绝不绘制“全体被驱逐”事件'),
('C4-F01-004','E18-F01','1704-03-04','day','爱尔兰法律将Donegal宗教朝圣集会定为违法','爱尔兰议会','2 Anne c.6第26–27节将部分宗教朝圣集会、圣物标识作为政府镇压对象','St Patrick’s Purgatory, County Donegal',['C4-IRL-ANNE-STAT'],'PLACE-DONEGAL-PURGATORY','法条具名宗教地与地理已知；实际逮捕和刑罚案例待核；参考点geometry=null'),
('C4-F04-001','E18-F04','1716','year','英国在1715詹姆斯党起义后通过苏格兰缴械法','大不列颠议会','以限制高地武器为手段压制潜在再次起义','Scottish Highlands (law applies in designated areas)',['C4-SCO-DISARM'],None,'法律适用区域与执行程度待查，不能用高地现代整体边界作实控面'),
('C4-F04-002','E18-F04','1725','year','政府再次制定苏格兰缴械措施','大不列颠议会','通过后续缴械法并以军队设施和道路推进治安军事网络','Scottish Highlands',['C4-SCO-DISARM'],None,'1725法律与1746法律独立事件；道路长度不可视为占领面积'),
('C4-F04-003','E18-F04','1747-06-17','day','大不列颠议会授权查封并管理部分詹姆斯党庄园','大不列颠议会、苏格兰财政法院','20 Geo II c.41 Vesting Act获王室批准，允许询问庄园产权并征收租金','Scotland; identified estate collections E738',['C4-SCO-NRS-ESTATE','C4-SCO-NLS-JAC'],None,'53处经查勘庄园并非53处都实际充公；NRS说明12处司法裁判未没收'),
('C4-F04-004','E18-F04','1752-03','month','Annexing Act规定部分战后没收庄园归王室长期管理','大不列颠议会','25 Geo II c.41授权部分没收庄园转王室长期行政、收益指定用途','Scottish Highlands and adjoining estate land',['C4-SCO-NRS-ESTATE'],None,'仅经查证具名遗产地契能落绘；不能将法案受理全部区域填作新的征服'),
('C4-F04-005','E18-F04','1752-12','month','苏格兰部分没收庄园纳入王室财产管理','英国王室财政机构、Commissioners for Annexed Estates','从1752年12月起实施Annexing Act下的庄园收益与公共改造管理','Selected named annexed estates in Highlands and nearby areas',['C4-SCO-NRS-ESTATE','C4-SCO-NRS-GUIDE'],None,'NRS表述13处实际特殊处理、原14处中Keppoch被认定不应没收；不可用14作为实际没收庄园数'),
('C4-D11-001','E18-D11-PROPOSED','1788-05','month','悉尼殖民方扣留原住民独木舟后发生致命冲突','原住民战士／英国流放殖民者','殖民方调查将William Okey与Samuel Davis之死与先前强留当地独木舟关联','Sydney Cove region (exact encounter unknown)',['C4-AU-ANMM-WATER'],None,'殖民军法官David Collins的因果判断，具体现场与执行者身份未核'),
('C4-D11-002','E18-D11-PROPOSED','1790','year','Bennelong参与原住民水上夺回捕鱼资源行动','Bennelong及原住民族群、英国捕鱼者','由独木舟接近殖民捕鱼艇并要求交出渔获','Sydney Harbour waterways',['C4-AU-ANMM-WATER'],None,'行动只知道1790后期，船上冲突具体坐标与确切日未知'),
('C4-D11-003','E18-D11-PROPOSED','1791-06','month','殖民地囚犯毁坏Balloderry独木舟','英国流放犯','毁坏Balloderry在Sydney岸边暂放的nawi，殖民法院随后对当事人处以鞭刑','Sydney Harbour area',['C4-AU-ANMM-WATER'],None,'Balloderry个人行动而非整片海岸归属；时间源为1791年6月'),
('C4-D11-004','E18-D11-PROPOSED','1791','year','Balloderry针对独木舟被毁以长矛实施报复','Balloderry及同行者','在毁舟及殖民方处罚后，殖民记录报告一名流放者被矛刺伤','Sydney Harbour vicinity',['C4-AU-ANMM-WATER'],None,'与毁舟的间隔“数周”，暂不编精确年月和战斗GPS'),
('C4-D11-005','E18-D11-PROPOSED','1795','year','原住民沿Hawkesbury河袭击殖民运载船','当地Darug/Darkinjung社区人士（具体群组待核）','在Hawkesbury河沿岸武装反抗殖民者通航与侵占农地','Hawkesbury River (specific reach not established)',['C4-AU-ANMM-WATER'],'PLACE-HAWKESBURY','馆方确认“1795年末”事件；原住民个体身份未知，不能以现代河道当一次船只确切航线'),
('C4-D11-006','E18-D11-PROPOSED','1797','year','下Hawkesbury原住民登上殖民运输船取粮','当地原住民水上战士','乘独木舟接近运粮船，殖民记述其中一起冲突造成船员死亡且玉米被取走','Lower Hawkesbury, Broken Bay area',['C4-AU-ANMM-WATER'],None,'殖民叙述，具体日期/船名及船员人数待核；不归咎于Pemulwuy本人'),
('C4-D11-007','E18-D11-PROPOSED','1797','year','下Hawkesbury另一场船上武装冲突与杀伤','当地原住民水上战士、殖民船员','另一艘殖民船发生争夺武器的冲突，殖民者对原住民造成致命伤害','Lower Hawkesbury, Broken Bay area',['C4-AU-ANMM-WATER'],None,'同年第二起独立船上冲突；原叙事只见Collins殖民方报告，死者人数未审'),
('C4-D11-008','E18-D11-PROPOSED','1797','year','殖民总督下令军队护航Hawkesbury与Sydney船只','新南威尔士总督John Hunter及驻军','派驻军人随船保护Green Hills至Sydney之间运输','Hawkesbury River / Sydney maritime connection',['C4-AU-ANMM-WATER'],None,'仅两端及通航关系有源，航迹/河段未逐段追证，不绘GIS线'),
('C4-F06-001','E18-F06','1798-05-26','day','韦克斯福德郡Boulavogue反政府起事','当地反政府居民及John Murphy等','与殖民政府骑兵发生最初战斗，政府档案汇编记起事从本日开始','Boulavogue parish, County Wexford',['C4-IRE-NAI-1798'],None,'NAI facsimile 8说明；汇编属档案馆编辑解说，不是逐页原件影像审读'),
('C4-F06-002','E18-F06','1798-05-28','day','起义军攻取Enniscorthy镇','韦克斯福德起义队伍','政府档案馆编写说明起义者进入Enniscorthy','Enniscorthy town, County Wexford',['C4-IRE-NAI-1798'],None,'城镇临时占领可研究城市核心，周边行政边界及确切撤守时间未核'),
('C4-F06-003','E18-F06','1798-05-30','day','政府驻军撤离Wexford城镇','爱尔兰王国政府驻军、起义军','政府守军撤离城镇，起义军随后占领','Wexford town, County Wexford',['C4-IRE-NAI-1798'],None,'档案馆叙述“two days later”，按28日+2日记录；精确当日需查守军日记，不绘全郡夺权面'),
('C4-F06-004','E18-F06','1798-06-13','day','Ballynahinch政府军击败Down郡反抗队伍','政府驻军与County Down联合爱尔兰人','政府档案馆收录6月13日来自贝尔法斯特的击败反抗者通报','Ballynahinch, County Down',['C4-IRE-NAI-1798'],None,'通报日期为13日，战斗实际日通常为13日；应核原通报及其他军令记录'),
]
existing_ids={e['id'] for e in ev['events']}
for eid,topic,dt,prec,title,actor,action,loc,ss,gref,note in new_events:
 if eid in existing_ids:continue
 ev['events'].append({'id':eid,'topic_id':topic,'date':dt,'date_precision':prec,'title':title,'actor':actor,'action':action,'historical_place':loc,'source_ids':[S(x) for x in ss], 'research_state':'research_only','cartographic_status':'source_attested_candidate_no_approved_map; source_precision_preserved','geometry_ref':gref,'historical_control_polygon_approved':False,'evidence_notes':note,'evidence_phase':'round4_new_source_review','reader_impact':'No unverified fill or navigable route'})
ev['event_count']=len(ev['events'])
# Existing Arabanoo capture day: 30 Dec (ANU) vs 31 Dec (TowardsTruth): resolve only month, retain both claims.
for x in ev['events']:
 if x['id']=='C-D04-001':
  x.update(date='1788-12',date_precision='month_day_conflicted_30_vs_31',historical_day_candidates=['1788-12-30','1788-12-31'],evidence_notes='ANU Keith Vincent Smith says 30 December; Towards Truth 31 December. Not settled by one precise day. Original annual event remains Dec 1788.')
  x['source_ids']=list(dict.fromkeys(x['source_ids']+[S('C4-AU-ANU-BENN')]))
 if x['id']=='C-D04-002':
  x['evidence_notes']=((x.get('evidence_notes') or '')+'；学术资料有April 1789与18 May 1789差异；18 May来源为Steele/Dawes时间表，继续追核原始医疗日记').strip('；')
 if x['id'] in ['C-D09-001','C2-D09-001']:
  x['evidence_notes']=((x.get('evidence_notes') or '')+'；ANU ADB载1797年3月遭枪击后被送医院，后从医院脱逃，切勿写作当场逃脱').strip('；')
  x['source_ids']=list(dict.fromkeys(x['source_ids']+[S('C4-AU-ANU-PEM')]))

conf_extra=[
 {'id':'C4-ARABANOO-DEC1788','prior_row':'C-D04-001','claim':'Arabanoo具体抓捕日','positions':[{'source_ids':[S('C4-AU-ANU-BENN')],'date':'1788-12-30','type':'academic_article_period_research'},{'source_ids':['S21'],'date':'1788-12-31','type':'TowardsTruth_website_period_record_index'}],'resolution':'登记1788-12；具体日保留30/31冲突；不可擅自选择日','map_effect':'one location, December 1788, no day-specific release'},
 {'id':'C4-ARABANOO-DEATH1789','prior_row':'C-D04-002','claim':'Arabanoo被拘后死于天花月份','positions':[{'source_ids':[S('C4-AU-ANU-BENN')],'date':'1789-05 (month)','type':'academic_article_summary'},{'source_ids':['C3-AU-DAWES-STEETE'] if any(s['id']=='C3-AU-DAWES-STEETE' for s in sr['sources']) else [S('C4-AU-ANU-BENN')],'date':'1789-05-18','type':'Dawes_notebook_chronology_as_quoted_in_prior_round'},{'source_ids':['S22'],'date':'1789-04 or 1789-05 uncertain','type':'epidemic_context_not_exact_death_source'}],'resolution':'以前18 May已有具体转录依据，但有April/May二手矛盾，保留待原始入葬/医疗簿；地理不变','map_effect':'no spurious extra death'},
 {'id':'C4-FORTWILLIAM-1708-09','prior_row':'C4-C26-002','claim':'St Johns Fort William captured 1708 or 1709','positions':[{'source_ids':[S('C4-CAN-PARKS-FORTWILL')],'date':'1708','type':'historical_older_plaque_text'},{'source_ids':[S('C4-CAN-PARKS-FORTWILL')],'date':'1709','type':'approved_federal_plaque_inscription'},{'source_ids':[S('C4-CAN-NEWF-STJOHNS')],'date':'1708 winter 1708/09','type':'regional_history_siege_interval'}],'resolution':'17/18c England Julian Old Style year before 25 March plus 1708/1709 raid sequence possible; use 1709 as approved inscription year, not claim exact 1708-12-31 physical status','map_effect':'hold Fort William on 1708-12-31 as status needing exact capture day confirmation; by 1709-12-31 original fort destroyed'},
 {'id':'C4-YORK-1713-14','prior_row':'C4-C27-003','claim':'York Fort treaty jurisdiction (1713) vs company staff physical return (1714)','positions':[{'source_ids':[S('C4-CAN-PARKS-YORK')],'date':'1713','type':'official_site_treaty_end_of_French_control'},{'source_ids':[S('C4-CAN-MHS-YORK1714')],'date':'1714','type':'post_reoccupation_staff_journals_and_secondary_history'}],'resolution':'separate treaty-year legal change from provable first staff journal, exact handover date undecided','map_effect':'1713 site not blindly replaced with firm HBC army polygon, 1714 named post source supported'},
 {'id':'C4-SCO-ANNEX13-14','prior_row':'C4-F04-005','claim':'13 vs 14 Crown-annexed Jacobite estate numbers','positions':[{'source_ids':[S('C4-SCO-NRS-ESTATE')],'date':'1752','type':'official_NRS_catalogue_13_real_and_fourteenth_Keppoch_not_forfeited'},{'source_ids':[S('C4-SCO-NRS-GUIDE')],'date':'1752','type':'archive_guide_no_detailed_13_14_disambiguation'}],'resolution':'13 historically annexed per one NRS description; a list initially called 14 includes Keppoch not truly forfeited. Need named parcel ledgers rather than an abstract giant estate polygon.','map_effect':'no 14-estate automatic territorial fill'},
]
cf['conflicts'].extend(c for c in conf_extra if c['id'] not in {x['id'] for x in cf['conflicts']})

# Site-actual-control corpus. Explicit evidence of site not a river basin, port district or colony boundary.
def site(years,code,name,actor,rel,notes,sources,statusfn):
 return {'id':code,'name':name,'historic_site_distinction':notes,'control_relation':rel,'actor_in_1700_1709':actor,'indigenous_dimension':'Named trading/military sites do not transfer territorial sovereignty over Indigenous peoples or communities.','last_known_recapture_year':None,'treaty_change_year':1713 if code=='C4-SITE-PLACENTIA-FR' else None,'actual_physical_handover_exact_date':None,'source_ids':[S(x) for x in sources],'geographic_point':None,'historical_control_polygon_confirmed':False,'fill_authorized':False,'records':[{'year':yr,'physical_site_control':statusfn(yr)[0],'year_end_evidence_state':statusfn(yr)[1],'verified_historical_polygon':False,'source_ids':[S(x) for x in sources]} for yr in years]}
new_sites=[
 site(range(1700,1710),'C4-SITE-ALBANY-HBC-1696-1710','Fort Albany / Chechewan, James Bay','English HBC personnel at fort','Actual HBC fort and local trade (not all Rupert Land)','HBC recaptured 1696; 1709 French raid failed. Annual continuity from academic biography and historic government compilation, not a muster for each year.', ['C4-CAN-DCB-BEALE','C4-CAN-GOV-FORTS1926','C4-CAN-DCB-KNIGHT'],lambda yr:('HBC physical fort occupancy supported by institutional histories 1696–1714; 1709 attacked but not taken','site_period_supported_not_yearly_personnel_ledger') ),
 site(range(1700,1710),'C4-SITE-FORTWILLIAM-STJOHNS-1697-1709','Fort William, St John’s Newfoundland','English garrison until French assault destroying fort in 1709','Site-specific English fort, not the entirety of Newfoundland','Original Fort William reconstructed 1697; 1705 resisted; 1709 destroyed. Separate French town damage 1705 from the fort status.', ['C4-CAN-PARKS-FORTWILL','C4-CAN-NEWF-STJOHNS'],lambda yr:('Fort destroyed after French attack, 1709 year-end; not proven occupied by resident French garrison','destroyed_by_year_end_institutionally_supported') if yr==1709 else ('Fort William existing English fort, 1705 siege repelled' if yr==1705 else 'Fort William English military installation in recorded 1697–1709 interval','institutional_interval_existence_not_annual_personnel_roster') ),
 site(range(1700,1710),'C4-SITE-PLACENTIA-FR','Plaisance / Placentia fortified French fishing colony Newfoundland','French Crown civil-military fishing settlement','French colony capital and local forts, not full Newfoundland sovereignty','Parks Canada identifies fortified French colonial capital from 1662 to cession at Utrecht 1713; specific forts and garrison yearly strength unreviewed.', ['C4-CAN-PARKS-PLACENTIA'],lambda yr:('French military/fishing colony at Placentia','institutional_interval_supported_not_every_year_garrison_roster')),
]
siteids={x['id'] for x in sc['sites']}
sc['sites'].extend(x for x in new_sites if x['id'] not in siteids)
sc.setdefault('round4_research',{})
sc['round4_research'].update({'method':'A garrison, trading post, colonial settlement or destroyed fort is a point/site political relation; no land area or unproven sovereignty polygon.','confidence':'Source-attested site historical interval; no claim of every year muster sheet','new_site_count':len(new_sites),'potential_fort_william_calendar_conflict':'old plaque 1708 / approved 1709; year 1708 exact year end not independently solved','sources_reviewed':'Parks Canada, Canadian biography, 1926 govt compilation, university heritage'})
for rec in sc['sites']:
 if rec['id'].startswith('C4-') and rec['id'].endswith('-1709'):
  pass
# Update Newfoundland 27 seed with actual DISTINCT named site cross-links; 1699 abstract remains a paper layer.
for x in ct['candidates']:
 if x['stable_id']=='C-TRANS-NEWFOUNDLAND':
  x['round4_named_site_counterexamples']=['C4-SITE-FORTWILLIAM-STJOHNS-1697-1709','C4-SITE-PLACENTIA-FR']
  x['round4_reading']='English St Johns fort 1700–08 (1705 survived); French Plaisance simultaneously 1700–09; Fort William destroyed 1709. Two sites, no entire-island occupation.'
  for z in x['year_end_reviews']:
   z['additional_site_source_ids']=[S('C4-CAN-PARKS-FORTWILL'),S('C4-CAN-PARKS-PLACENTIA')]
   z['site_specific_control_registry']='SITE_SPECIFIC_CONTROL_1697_1715.json'
 if x['stable_id']=='C-TRANS-RUPERT-PAPER':
  x['round4_named_site_counterexamples']=['C-SITE-YORKFACTORY-FR-1697-1713','C4-SITE-ALBANY-HBC-1696-1710']
  x['round4_reading']='French Fort Bourbon and English HBC Fort Albany both simultaneous 1700–09; entire Rupert Land charter alone cannot yield a singular color.'
ct['investigation_round4']={'date':'2026-11-08','site_relation_anchors':['Fort Albany 1696–1709 HBC','Fort Bourbon 1697–1713 French','Fort William 1697–1708 English, destroyed 1709','Placentia 1662–1713 French'],'change_warning':'St Johns winter 1708/09 date and 1709 year end distinguished; 1713 legal Utrecht change and 1714 documented York HBC reoccupation separate.','no_polygon':True,'indigenous_political_rights_not_extinguished':True}

# Legal section-level time ledger prevents author from treating all law provisions as one uniform effect-year.
laws={'schema':'assistant-C-round4-law-section-timings-v1','editorial_state':'research_only','rules':['Section text from a historically archived transcription is not an inspection of parchment original.', 'Regnal year 2 Anne c.6 (1703) differs from assent 4 March 1704.', 'Site-specific statutory bond does not establish actual displacement counts or real property boundaries.','English 1702 law applies to forfeited estates; Irish penal statute 1704 a separate legislature.'],'statutory_clauses':[
 {'id':'C4-IRL-1702-ENGLAND-FORFEIT','act':'English Statute 1 Anne c26','statute_label_year':1702,'royal_assent_confirmed':None,'section':'7–10,15','effective_date_claim':None,'effect':'Restricts inherited, held and newly leased Irish forfeited estates for Catholics subject to exact statutory exceptions','source_ids':[S('C4-IRL-ANNE-STAT')],'applies_to':'Specified forfeited estates, not all Irish land','mapping':'no land parcel geoms'},
 {'id':'C4-IRL-1704-S6','act':'Irish Statute 2 Anne c6','statute_label_year':1703,'assent_day':'1704-03-04','section':'6','historical_reference_date':'1703-03-24','effect':'Catholics disabled from land purchase and most new leases; permitted leases <=31 years meeting strict rent tests; certain acquisitions after 24 March 1703 declared void','source_ids':[S('C4-IRL-ANNE-STAT'),S('C4-IRL-ASSENT-1704')],'mapping':'statutory applicability only; 1703 reference date not a royal conquest event'},
 {'id':'C4-IRL-1704-S3-4','act':'Irish Statute 2 Anne c6','statute_label_year':1703,'assent_day':'1704-03-04','section':'3–4','effect':'Reward to heirs changing religious adherence and restrictions on Catholic guardians','source_ids':[S('C4-IRL-ANNE-STAT')],'mapping':'individual land transaction not documented'},
 {'id':'C4-IRL-1704-S10','act':'Irish Statute 2 Anne c6','statute_label_year':1703,'assent_day':'1704-03-04','section':'10','effect':'Gavelkind equal division of Catholic estate among sons where relevant; Protestant-inheritance exception requires tracing','source_ids':[S('C4-IRL-ANNE-STAT')],'mapping':'no inferred cadastral subdivision'},
 {'id':'C4-IRL-1704-S16-18','act':'Irish Statute 2 Anne c6','statute_label_year':1703,'assent_day':'1704-03-04','section':'16–18','effect':'Certain public officials must take prescribed oaths and conform to established Eucharist practice; noncompliance penalties','source_ids':[S('C4-IRL-ANNE-STAT')],'mapping':'office eligibility only, not land'},
 {'id':'C4-IRL-1705-S23-28','act':'Irish Statute 2 Anne c6','statute_label_year':1703,'assent_day':'1704-03-04','section':'23,28','effective_date_claim':'1705-03-24','effect':'Specified Limerick and Galway Catholic inhabitants must provide security by date or depart, with express exemptions for seamen, fishers and specified poorer labourers','source_ids':[S('C4-IRL-ANNE-STAT')],'mapping':'two city references only, no measured property or expulsions count'},
 {'id':'C4-IRL-1704-S24','act':'Irish Statute 2 Anne c6','statute_label_year':1703,'assent_day':'1704-03-04','section':'24','effect':'Voting requires allegiance and abjuration oath certification; do not confuse with separate explicit 1728 disenfranchisement','source_ids':[S('C4-IRL-ANNE-STAT')],'mapping':'political rights history; not territorial'},
 {'id':'C4-IRL-1704-S26-27','act':'Irish Statute 2 Anne c6','statute_label_year':1703,'assent_day':'1704-03-04','section':'26–27','effect':'Suppression and penalisation of Catholic pilgrimage to named Donegal site and wells','source_ids':[S('C4-IRL-ANNE-STAT')],'mapping':'named place only, no evidence of enforcement site or area'}
 ]}
write('LEGAL_CLAUSE_TIMELINE_1702_1709.json',laws)

# Specific disputed/verified claims and their cartographic gating.
new_claims=[
 ('C4-YORK-ALBANY-COEXIST-1709','1700–1709','Fort Bourbon is French while Albany Fort is English HBC: trading company paper region is not one political color',['C4-CAN-PARKS-YORK','C4-CAN-DCB-BEALE','C4-CAN-GOV-FORTS1926'],'company_fort_history_academic_biography_government_1926','Albany French attack 1709 repelled; annual garrison rosters lacking','two named core sites as distinct points; no Rupert Land polygon'),
 ('C4-NEWF-FR-ENG-1700S','1700–1709','French Plaisance and English St Johns military core coexist on Newfoundland',['C4-CAN-PARKS-PLACENTIA','C4-CAN-PARKS-FORTWILL'],'official_federal_heritage_designation','Different fort garrisons and indigenous land rights; site only','two named places distinct actors; historic polygon null'),
 ('C4-FORTWILLIAM-1705-09','1705 / 1709','1705 Fort William survived attack; 1709 fort captured and destroyed',['C4-CAN-PARKS-FORTWILL','C4-CAN-NEWF-STJOHNS'],'official_federal_inscription_and_university_history','official heritage page preserves conflicting 1708 previous text / 1709 approved text; exact Old Style day unverified','1709 year-end destroyed physical fort, not French settled colony'),
 ('C4-ANNE-LIMERICK-GALWAY','1705-03-24','2 Anne c6 §§23,28 conditional city bonds/relocation, explicit labourer exceptions',['C4-IRL-ANNE-STAT'],'historical_law_excerpt_transcription','actual individual expulsions, households, judicial enforcement untraced','legal-site references only, neither forced area nor verified headcounts'),
 ('C4-ANNE-LAND-1703-1704','1703-03-24 / 1704-03-04','2 Anne c6 §6 has retrospective land cutoff 1703, royal assent 1704',['C4-IRL-ANNE-STAT','C4-IRL-ASSENT-1704'],'legal_transcription_and_historical_text','exact difference statute year/session, Gregorian/Julian applicability, exemptions; no cadastral outcomes','two dates in one legal episode not separate conquest'),
 ('C4-SCOT-FORFEIT-1747-1752','1747-06-17 / 1752-12','Vesting Act empowered property inquiry, later thirteen estates actually annexed to Crown; 14th Keppoch excluded after review',['C4-SCO-NRS-ESTATE','C4-SCO-NLS-JAC'],'official_scottish_archives_catalogue','53 surveyed vs 12 exempt vs 13 final annexed are DIFFERENT denominators','no polygon; identify estate titles and rentals individually'),
 ('C4-AU-BOAT-1791','1791-06','Balloderry canoe destruction, later spearing, colonial flogging occur as connected but separate actions',['C4-AU-ANMM-WATER'],'Australian_national_maritime_museum_historical_essay','colonial report of motive, not exact shore GPS or native casualty count','one regional research marker null, not harbour route'),
 ('C4-AU-HAWKESBURY-1797','late 1797','Two watercraft attacks are separate on lower Hawkesbury; one with stolen maize and dead crew, another colonial gunfight and Indigenous deaths',['C4-AU-ANMM-WATER'],'Australian_national_maritime_museum_historical_essay','uncertain boat/individual identifiers and deaths count, period source Collins','two research events, no GPS river path or false count'),
 ('C4-WEXFORD-LOCAL-1798','1798-05-26 to 1798-05-30','Boulavogue outbreak, Enniscorthy and Wexford taken in separate phases',['C4-IRE-NAI-1798'],'Irish_national_archives_educational_facsimile_descriptions','PDF screenshot unavailable: text extraction and descriptive headings only, actual folios not viewed','temporary named towns may be prospective control core; no County Wexford blanket occupation')]
for id0,dr,summary,ss,atype,limit,geo in new_claims:
 if any(q['id']==id0 for q in cl['claims']):continue
 cl['claims'].append({'id':id0,'date_or_range':dr,'claim_summary':summary,'source_ids':[S(x) for x in ss],'access_type':atype,'audit_limit':limit,'map_eligibility':geo,'original_folio_personally_inspected':False})
cl['evidence_count']=len(cl['claims'])

# GeoJSON new evidence-backed named historical localities, left unlocated until independent coordinate publication.
new_geo=[
('PLACE-FORTWILLIAM-STJOHNS','Fort William, St John’s Newfoundland',['C4-CAN-PARKS-FORTWILL'],['C4-C26-001','C4-C26-002']),
('PLACE-PLACENTIA','Plaisance / Placentia French Newfoundland',['C4-CAN-PARKS-PLACENTIA'],['C4-C26-003']),
('PLACE-ALBANY-FORT','Fort Albany / Chechewan, James Bay',['C4-CAN-GOV-FORTS1926','C4-CAN-DCB-BEALE'],['C4-C27-001','C4-C27-002']),
('PLACE-GALWAY','Galway (1705 Penal Law statutory city)',['C4-IRL-ANNE-STAT'],['C4-F01-003']),
('PLACE-LIMERICK','Limerick (1705 Penal Law statutory city)',['C4-IRL-ANNE-STAT'],['C4-F01-003']),
('PLACE-DONEGAL-PURGATORY','St Patrick’s Purgatory, County Donegal',['C4-IRL-ANNE-STAT'],['C4-F01-004']),
('PLACE-ENNISCORTHY','Enniscorthy town, County Wexford',['C4-IRE-NAI-1798'],['C4-F06-002']),
('PLACE-WEXFORD-TOWN','Wexford town, County Wexford',['C4-IRE-NAI-1798'],['C4-F06-003']),
('PLACE-BOULAVOGUE','Boulavogue parish, County Wexford',['C4-IRE-NAI-1798'],['C4-F06-001']),
('PLACE-BALLYNAHINCH','Ballynahinch, County Down',['C4-IRE-NAI-1798'],['C4-F06-004']),
('PLACE-BROKENBAY','Broken Bay / lower Hawkesbury',['C4-AU-ANMM-WATER'],['C4-D11-006','C4-D11-007']),
]
geo_ids={x['id'] for x in gc['features']}
for gid,name,ss,refs in new_geo:
 if gid in geo_ids:continue
 gc['features'].append({'type':'Feature','id':gid,'geometry':None,'properties':{'name':name,'source_ids':[S(x) for x in ss],'linked_event_ids':refs,'coordinate_method':'not_geocoded_independently','coordinate_status':'named_attested_location_coordinate_pending','geo_precision':'reference_locality_not_historical_combat_site','historical_boundary_confirmed':False,'territorial_claim':False,'fill_authorized':False,'area_sqkm':None,'exclude_from_area_aggregation':True,'publication_status':'research_only','map_inclusion':'research_not_published'}})

# Cross-century old story audit field remains 36 entries, with explicit updated anchors.
audit_add={
'E6-T10-HBC':'1700-09年分堡：约克堡法国/奥尔巴尼堡英HBC。1713《乌得勒支条约》与1714英国重驻时间区分。',
'E6-T10-NEWFOUNDLAND':'1700-09年圣约翰斯英方威廉堡与法属普莱桑斯并行；1705袭镇未夺堡、1709攻陷摧毁堡垒。',
'E6-T10':'阿卡迪亚、纽芬兰、哈德孙湾不得因为同一17C母题而用统一政治色。',
'E6-T03-LAND-1642-1698':'1704惩罚法第6节1703-03-24法定追溯截点；1705-03-24戈尔韦/利默里克有条件担保期限。',
'E6-T03':'1702英格兰没收庄园特定法与1704爱尔兰惩罚法属不同立法主体。',
'E6-T04':'1716和1725缴械法规以及1747 Vesting、1752 Annexing政策均为各自立法/地产处理事件，不能当作17C征服战役延续。',
'E6-T04-CONQUEST':'1652结束的军事占领不能被1747/1752新的财产管理制度重新贴为1652—1752不间断军事战事。',
'E6-T04-GLENCOE':'1692杀戮是已结束行动，1716/1725/1746军政法独立机制，1747–52战后庄园没收另立。',
}
for x in aud['entries']:
 if x['previous_story_id'] in audit_add:
  notes=x.setdefault('round4_findings',[])
  if audit_add[x['previous_story_id']] not in notes:notes.append(audit_add[x['previous_story_id']])
  for i in ({'E6-T10-HBC':['C4-CAN-PARKS-YORK','C4-CAN-DCB-BEALE'],'E6-T10-NEWFOUNDLAND':['C4-CAN-PARKS-FORTWILL','C4-CAN-PARKS-PLACENTIA'],'E6-T03-LAND-1642-1698':['C4-IRL-ANNE-STAT'],'E6-T04':['C4-SCO-NRS-ESTATE']}.get(x['previous_story_id'],[])):
   v=S(i)
   if v not in x['source_ids']:x['source_ids'].append(v)

# Write batches now, before longform prose and QA, to preserve on interrupt.
for n,obj in [('SOURCE_REGISTRY.json',sr),('EVENT_CANDIDATES.json',ev),('ROUND3_EVIDENCE_CONFLICTS.json',cf),('SITE_SPECIFIC_CONTROL_1697_1715.json',sc),('CONTROL_TRANSITIONS_1699_1709.json',ct),('CLAIM_EVIDENCE_MATRIX.json',cl),('MAP_CANDIDATES.geojson',gc),('CROSS_CENTURY_AUDIT.json',aud)]: write(n,obj)

# Update CSV mirrors automatically, without relying on prior rigid columns.
with (p/'EVENT_CANDIDATES.csv').open('r',encoding='utf-8-sig',newline='') as f: fields=csv.DictReader(f).fieldnames
with (p/'EVENT_CANDIDATES.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader()
 for x in ev['events']:w.writerow({k:(';'.join(str(i) for i in x[k]) if isinstance(x.get(k),list) else json.dumps(x[k],ensure_ascii=False) if isinstance(x.get(k),dict) else x.get(k,'')) for k in fields})
with (p/'CLAIM_EVIDENCE_MATRIX.csv').open('r',encoding='utf-8-sig',newline='') as f: cfields=csv.DictReader(f).fieldnames
with (p/'CLAIM_EVIDENCE_MATRIX.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=cfields,extrasaction='ignore');w.writeheader()
 for x in cl['claims']:w.writerow({k:(';'.join(str(i) for i in x[k]) if isinstance(x.get(k),list) else x.get(k,'')) for k in cfields})

memo='''# 第四轮专项深度核查｜地权法条、实际堡垒、原住民水路抵抗

日期：2026-11-08｜状态：**research_only**｜GitHub：**未修改**。

## 1. 1700—1709年哈德孙湾一片地区同时出现两种不同实际驻点

Parks Canada（C4-CAN-PARKS-YORK）指出，约克堡1697年被法国夺回，改称Fort Bourbon，至少在1713年条约前为法方堡垒。Dictionary of Canadian Biography（C4-CAN-DCB-BEALE；C4-CAN-DCB-KNIGHT）记奥尔巴尼堡依然是英格兰哈德孙湾公司在James Bay的实际据点，1696英方重得；1705年任命Anthony Beale的委任文书权限广，但当时实际权力远小于这份文书。1926年加拿大政府刊物（C4-CAN-GOV-FORTS1926）记录1709法军袭Albany被击退。由于法方占York、英方据Albany在1699与1700—1709具有并列现实，Ruperts Land 1670王室纸面特许不能画成统一英国实控面。两个历史地点都保持geometry:null，避免以今York Factory III点位冒充当年York Fort I。

1709并非约克堡改为英国驻军年份。1713年条约法理转变与1714年公司人员重驻及第一批日记并存，需要查询原HBC档案HBCA B.239/a/1；`C4-YORK-1713-14`保存时间差异。

## 2. 纽芬兰1705和1709年是真实据点断点

加拿大公园局已批准的Fort William碑文（C4-CAN-PARKS-FORTWILL）区分：1705年法军进攻，英方城堡未被夺；1709年城堡陷落及遭摧毁。该遗址网页旧碑铭又称1708年，现代批准碑铭改为1709。两条记年可能涉及1708—1709冬季与英国旧历年界差异，暂记录冲突，不强行确定某一日期。1709年末物理上的原堡已被毁；不得据攻陷反向推断法国士兵在1709年12月31日仍驻守同一堡。

同一时期Plaisance/Placentia是法国王室从1662年起的殖民军事与渔业据点，到1713年才在乌得勒支条约下转予英国（C4-CAN-PARKS-PLACENTIA）。**全岛统一色块错误**：圣约翰斯城镇、威廉堡与普莱桑斯需分地、分年份、分政权；Beothuk等原住民族政治另列。

## 3. 爱尔兰惩罚法逐条时间分层

明尼苏达大学法学图书馆公开的旧法**转录**（C4-IRL-ANNE-STAT）显示：1702英格兰议会`1 Anne c.26`主要涉及没收庄园的特定权利；爱尔兰议会`2 Anne c.6`虽然史料有“1703”法条年度标签，历史法律叙述记**1704-03-04**批准。第6节对土地租约及购地限制引用**1703-03-24**作为判定某类交易的历史法定参照日；这个法内追溯日期不是1703年另一次实际抄没地块。第3–4节规定某些改宗继承与监护限制；第10节对特定遗产强制平分；第16–18节涉及特定公职的宗教与宣誓资格。

尤其要将第23及28节单列：法规定**Galway与Limerick两座城市**的某些天主教居民应在1705-03-24以前提供合法担保，否则须迁出；又为部分海员、渔民和特定低房价日工明确设置例外。文本只证明政治歧视性限制和期限，未证明具体执行人数、迁出街区或任何宗教人口分布Polygon。第26–27节则明确点名Donegal朝圣地点——这些属具名法定打压对象，具体执法仍待司法原卷。

详见`LEGAL_CLAUSE_TIMELINE_1702_1709.json`。今后逐条重核史料时要区分**法案署年、王室批准、条款适用起点、法院执行、地产实际转手**五种不同年份。

## 4. 苏格兰1747—1752没收庄园的现实分母

NRS苏格兰国家档案馆`E738`目录（C4-SCO-NRS-ESTATE）明确：1747年6月17日Vesting Act允许苏格兰财政法院查勘没收地产、租金与债权；其后有**53处庄园经查勘、其中12处经法院支持所有权抗辩而认定不被没收**。1752年3月通过Annexing Act，在1752年12月开始特别归入王室财务管理的被没收庄园，目录指出**13处真正符合，原列第14处Keppoch后来不符合没收条件**。这三组数是不同法务节点和样本，不能混为国家直接取得54块土地。

逐宗具体边线需读NRS的E600–687 / E701–788财产、租金、地籍图及具体个案（C4-SCO-NRS-GUIDE）。即使可以识别庄园，王室税地管理与新建军事据点也不是同一种颜色、同一种控制类型。1716和1725年缴械法按独立年代节点登记，不并入1746年战役或某一18世纪“持续战争”。

## 5. 澳大利亚原住民族水路抵抗：补齐1770/1788后被忽略的资源主权

Australian National Maritime Museum（C4-AU-ANMM-WATER）举1788年殖民者扣押原住民独木舟、William Okey与Samuel Davis在5月被杀的案例，法官Collins与总督Phillip将事件联系到被抢独木舟；来源属于殖民方事后归因。1791年6月流放犯破坏Balloderry的`nawi`，虽殖民政府对毁舟者施刑，Balloderry之后仍以长矛袭击殖民者。1790年Bennelong也被记载率独木舟对英国捕鱼艇施压，要求交出捕鱼资源。这些都是殖民占水域、渔获与传统财产权的具名对抗，不能只在地图上写“原住民无故攻击”。

博物馆还区分1795年末Hawkesbury攻击通航者与1797年末下Hawkesbury（Broken Bay附近）**两次独立登船袭击**，后者之一导致殖民船员死亡和玉米被取走，另一次发生夺枪交战，殖民方承认部分原住民死亡。Hunter后派军队护航Green Hills到Sydney的河运。原文对实际遇害人数、航线位置并未提供可恢复的精确坐标，不得画推测袭击GPS或Hawkesbury整河统治线。参见新增事件`C4-D11-001`至`C4-D11-008`。

## 6. 1798爱尔兰的实际阶段性控制

爱尔兰国家档案馆1798传真文献包的解说与文件目录（C4-IRE-NAI-1798；*本轮网页可读文本，PDF截图无法打开，未阅逐页原始传真*）指明：Wexford当地起事于5月26日下午Boulavogue一带，5月28日抵抗者夺Enniscorthy，其后政府驻军离开Wexford镇。仅此信息可以考虑具名城镇**临时控制核心候审**，仍需逐日开闭及军事驻点证据；不能据“1798 Wexford rebellion”就把现代郡县边界全涂成起义控制面，也不能把殖民民兵/王室正规军的暴力与起义者针对平民行为混为一个责任主体。

国家档案馆的5月27日Oulart副市长呈报、6月13日Ballynahinch军情、6月6日Wexford起义军命令已经列于以前账本；新增分地节点避免将这些不同城市塞进一处Vinegar Hill圆点。

## 7. 第四轮明确冲突清单

- 1788年Arabanoo抓捕日：ANU研究记12月30日，Towards Truth记12月31日，回退到`1788-12`月精度；官方/学术来源差异独立保留，原论文/日记仍待校。
- Fort William 1708/1709：老碑文与新批准碑文同一机构不同，1709年末城堡毁坏较有把握，1710新堡状态待查。
- York Fort 1713/1714：条约法权与英方重新派驻人员不能合为同一天。
- 苏格兰1752庄园数：最初14处计划与最终13处实际王室特别管理不应混淆。
- 1797年Pemulwuy中弹被带回医院后脱逃，不能说当场脱逃（C4-AU-ANU-PEM）。

**历史几何：本轮新增具名地点全部geometry:null，零幅新的真实控制疆域面。**
'''
(p/'ROUND4_DEEP_RESEARCH.md').write_text(memo,encoding='utf-8')

md_add={
'E18-D04.md':'''### 第四轮证据冲突：Arabanoo精确日期
ANU Keith Vincent Smith《Bennelong among his people》（C4-AU-ANU-BENN）记Arabanoo在1788年12月30日被抓，但Towards Truth（S21）记31日。本轮将`C-D04-001`改为1788-12月精度，冲突见`ROUND3_EVIDENCE_CONFLICTS.json`新增项。1789年Bennelong、Colebee抓捕、离监路线和各自Wangal/Gadigal归属见C4-AU-RYDE-BENN及C4-AU-ANU-BENN。早期殖民官员强制抓人并不能被写成双方自愿翻译雇用。''',
'E18-D07.md':'''### 第四轮：水域、独木舟与粮食抢夺
C4-AU-ANMM-WATER来源建立1788年独木舟被强留后杀戮、1790年Bennelong捕鱼船交涉、1791 Balloderry毁舟与报复、1795/1797 Hawkesbury舟战和随后殖民护航。逐独立行为建`C4-D11-001…008`，只显示可核的现代区域名，不推断船迹、原住民作战控制海域。''',
'E18-D09.md':'''### 第四轮：1797被俘与医院脱逃的顺序
ANU ADB《Pemulwuy》（C4-AU-ANU-PEM）明确1797年3月对Toongabbie官田袭击后，遭追击至Parramatta边缘中弹、被带去医院，后来才从医院脱身。不要在同一战斗现场画成直接逃跑成功；时间线事件卡保留两个行动。''',
'E18-F01.md':'''### 第四轮：1704第6/10/23/28节与1705执行节点
按大学法图书馆历史法条转录C4-IRL-ANNE-STAT，第6节涉及1703-03-24参照日、31年租约及租金限制；第3–4节宗教改宗继承、监护，第10节财产继承平分，第23、28节Galway、Limerick有条件担保及1705-03-24期限，第26–27节Donegal朝圣活动镇压。由1704-03-04王室批准，部分法条署名“1703”。正文必须保留程序条件与豁免，不得将法律范围着色为天主教全部财产实占变更。详LEGAL_CLAUSE_TIMELINE_1702_1709.json。''',
'E18-F04.md':'''### 第四轮：缴械法及财产没收另立阶段
1716、1725分次Disarming Acts（C4-SCO-DISARM）；1747年6月17日Vesting Act（20 Geo II c.41）授权庄园税务查勘；1752年3月Annexing Act通过、12月特别王室管理。NRS E738写53处查勘、12处有权属抗辩而不没收，原14处拟特别处理包括1处Keppoch后来未被没收，实际13处。必须逐宗查档 E600–687/E701–788；法律政治影响与地籍范围无可证Polygon。''',
'E18-F05.md':'''### 第四轮：清场与1747–52国有庄园税务区别
1752王室王室特别管理没收庄园是不同于1780s以后地主清场的政策，不能把前者的13个地产变成18世纪13处均已驱逐居民。1780–1825“第一波”确证但具体驱逐庄园时点需逐宗租约。National Records Scotland遗产 E738与苏格兰历史学会研究 C4-SCO-CLEARWAVE 联读。''',
'E18-F06.md':'''### 第四轮：Wexford临时城镇占领需分点
国家档案馆C4-IRE-NAI-1798的解说材料把Boulavogue起事放1798-05-26、Enniscorthy进入放5月28、Wexford镇守军随后撤离，属于3个连续但地理不同事件。Ballynahinch 6月13政府军胜利与Wexford战区也不能混放。未在原始6月城镇驻军原册和各方口述交叉核前，只在候审点层表示，县界不涂。''',
'1700_NEWFOUNDLAND_LAW.md':'''### 第四轮：1700–09同岛英法据点反差
1700–09法军驻Plaisance；St John’s的Fort William由英方重建，1705法军袭镇未取堡，1709攻克摧毁。Parks Canada旧碑铭1708与已批准碑文1709有异；地图年末只敢认定1709原堡被毁，不能推算永久法军占领圣约翰斯。资料见C4-CAN-PARKS-FORTWILL及C4-CAN-PARKS-PLACENTIA。''',
'HBC_1699_1713.md':'''### 第四轮：Albany与York分堡并存证据
York/Fort Bourbon法国据点1697–1713（有1714公司日记）；Albany英国HBC在1696夺回，1705委任Anthony Beale管理James Bay，据1926政府汇编1709法军进攻被击退。公司指挥官声索整个Hudson Bay不是实际逐堡驻军。新增SITE_SPECIFIC_CONTROL_1697_1715.json 3站，并附逐年事证等级。''',
'SCOTLAND_1700_1746_1780.md':'''### 第四轮：1747/1752没收庄园并非一处大面积战争前线
NRS E738庄园管理目录明确区分查勘53、受法院保护12、特殊王室管理13（原14计划中Keppoch被排除）；分1747 Vesting授权、1752 Annexing立法、1752-12具体纳入。必须逐件财产与租金核可，避免将此当1745詹姆斯党叛乱在1752年仍进行。''',
}
for fn,extra in md_add.items():append('TOPIC_DOSSIERS/'+fn,extra)

append('MISSING_TOPICS.md','''## 第四轮新增待核项目（2026-11-08）

1. **HBC分堡控制（交助手1）**：已找到York/Fort Bourbon法国占据、Albany英国HBC驻守的同期反例；请取HBCA B.3/a（Albany逐年日记）、B.239/a/1（1714 York重驻）及1709法军袭Albany的双方日记。两座Fort和Rupert's Land不可使用同种英国色；法国驻堡亦不自动确证全流域土地占领。
2. **1708/1709圣约翰斯双年记载（交助手1）**：Parks Canada同一遗址网页旧碑铭1708与正式批准铭文1709不一致。需原1708-12～1709-01 Saint-Ovide通讯、Julian/Gregorian日期转写、英方撤军/法方滞留期限；Plaisance则可作为1700s法国实际堡垒地点。
3. **爱尔兰1704/1705法律逐条执行（本助手）**：2 Anne c6的土地继承、宗教监护和Galway/Limerick担保必须寻找实际法院判决和居民名册。不能从文本直接绘制“1705驱逐天主教人口”范围；历史转录还需旧版法案校勘。
4. **高地国有庄园（本助手）**：E738等官方档案已给出查勘53、判定排除12、王室特别管理13，逐地产需取初始判决、租册、实际改良/清场/偿付。1752王室庄园产权与18世纪人口强制迁移不能合并。
5. **原住民水路抵抗（本助手）**：ANMM 1790–97资料显示Balloderry和Hawkesbury多次舟战，姓名、伤亡和攻击船地理未独立交叉校验。需逐个查Collins 1798版、Tench手稿、船名及原住民族家族历史；禁止画船行GPS路线。
6. **Arabanoo日精度（本助手）**：1788-12-30 ANU与12-31 TowardsTruth差异暂存`ROUND3_EVIDENCE_CONFLICTS.json`，原事件降至月精度。1789年死亡日期也有April/May的史料摘要差异，应取医生White与殖民秘书日记校正。
7. **1798镇区占领（本助手）**：Wexford、Enniscorthy、Boulavogue、Ballynahinch各有独立史料点；按每个城镇的入驻、守军退出、反攻分别重建，不可用现代县境无依据地填色。国家档案PDF文字提取可用但截图服务失败，原传真仍需直接读档。
''')

prog='''## 第四轮保存与交接｜2026-11-08

- 保留第三版全部资料，本轮增录有逐条来源的HBC/纽芬兰军事站点断点、爱尔兰具体法条、苏格兰庄园没收分母、澳大利亚河道抵抗和1798爱尔兰具名镇区行动。
- `SITE_SPECIFIC_CONTROL_1697_1715.json`：在York之外新增Albany Fort (HBC)、St John’s Fort William (English 1705守住、1709摧毁) 与法属Plaisance等3个同期据点，每处1700–1709十个年末**来源支持的时期判断**。源文年代段支持仍不等于逐年士兵名册。
- `LEGAL_CLAUSE_TIMELINE_1702_1709.json`：8组具名法条，分署年/批准/追溯/条件截止/执行，地理区仅名城，不制造真实案件与地籍数据。
- `ROUND4_DEEP_RESEARCH.md`：本轮深入研究、实际控制对照、原始史料线索和日历冲突细节。
- `EVENT_CANDIDATES.json/.csv`、`CLAIM_EVIDENCE_MATRIX.json/.csv`、`SOURCE_REGISTRY.json`、`ROUND3_EVIDENCE_CONFLICTS.json`、`MAP_CANDIDATES.geojson`及各相应专题均同步更新。
- 特别纠错：Arabanoo抓捕日由1788-12-31改为1788-12月精度，留30/31日期争议；1797 Pemulwuy中弹后进医院再逃脱；1708/09 Fort William和1713/14 York法律与现场分开。
- 地图仍为全部`research_only`，无经证史料历史土地Polygon；新增地点不自动赋坐标。
- 本轮QA在`ROUND4_QA_REPORT.json`，之前校验脚本复核条数门槛相应更新；非原卷逐叶的来源访问深度保留。
'''
append('PROGRESS.md',prog)
append('README.md',f'''## 第四轮增补（2026-11-08）

- 累计**{len(ev['events'])}**件候审记录、**{len(sr['sources'])}**条来源，**{len(cl['claims'])}**组声明证据检查、**{len(gc['features'])}**处命名地理候选；有效具独立现代参考坐标仍仅3处。
- 3座新具名堡垒/驻点各增加1700–09年末核对数据，与York共计{len(sc['sites'])}个据点（不是“4块国土”）。
- 额外8组爱尔兰法条执行时间`LEGAL_CLAUSE_TIMELINE_1702_1709.json`、跨部门对照`ROUND4_DEEP_RESEARCH.md`及增补冲突`ROUND3_EVIDENCE_CONFLICTS.json`。
- 依旧不发布、不合并、不推断历史边线；GitHub未更改。
''')
print('Round4 saved',{'events':len(ev['events']),'sources':len(sr['sources']),'claims':len(cl['claims']),'sites':len(sc['sites']),'geo':len(gc['features']),'conflicts':len(cf['conflicts'])})
