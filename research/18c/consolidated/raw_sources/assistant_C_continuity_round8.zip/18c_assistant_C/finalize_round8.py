#!/usr/bin/env python3
"""Round 8: dedup new event nodes; proof matrix, dossiers, QA, and immutable archive."""
import csv,datetime,hashlib,json,re,collections,pathlib,os,zipfile,shutil
R=pathlib.Path('/mnt/data/18c_assistant_C');O=R/'ROUND8_SYSTEMIC_IMPACT'
def get(p):return json.loads(p.read_text())
def write(p, obj):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def cwrite(p,arr):
 if not arr:return
 cols=list(dict.fromkeys(k for row in arr for k in row));
 with p.open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=cols);w.writeheader();
  for row in arr:w.writerow({k:(json.dumps(v,ensure_ascii=False) if isinstance(v,(list,dict)) else v) for k,v in row.items()})
SRC=R/'SOURCE_REGISTRY.json';EV=R/'EVENT_CANDIDATES.json';src=get(SRC);ev=get(EV);pol=get(O/'POLICY_MECHANISM_MATRIX.json');quant=get(O/'QUANTIFIED_IMPACTS.json');lm=get(O/'ROUND8_SOURCE_REGISTRY.json')['lookup_slug_to_source_id']
assert len(src['sources'])>=229 and len(ev['events'])==216
# Secondary numerical estimates from publicly indexed academic PDF were only retrieved as search text, not inspected page by page.
url='https://research.tees.ac.uk/files/6460589/560928.pdf'
sl=next((x['id'] for x in src['sources'] if x['url']==url),None)
if sl is None:
 sl='C8-S18';assert sl not in {x['id'] for x in src['sources']}
 src['sources'].append({'id':sl,'institution':'Teesside University repository (Ultán Gillen)','title':'Ascendancy Ireland 1660–1800 research essay, land ownership estimates','url':url,'access_level':'academic_author_manuscript_search_snippet_pdf_pages_not_screenshot_verified','original_manuscript_personally_inspected':False,'reviewed_online_on':'2026-11-08','research_note':'14% in 1704 and 5% by 1776; explains legal circumvention and lease interests; these are secondary historiographic estimates, with historical denominator and varying landholding types.'})
for v in quant['records']:
 if v['id'] in ('C8-Q03','C8-Q04'):
  v['source_ids']=[sl]
  v['non_additivity_or_limitation']+='; searchable research text, not underlying original land survey or validated PDF page'
write(O/'QUANTIFIED_IMPACTS.json',quant);cwrite(O/'QUANTIFIED_IMPACTS.csv',quant['records'])
src['source_count']=len(src['sources']);write(SRC,src)
# Old event fixes, corrections documented and never erase source of previous assertion.
corrections=[]
for e in ev['events']:
 if e['id']=='C7-SCT-1746-PROSC':
  before=e['title']; e['title']='《禁止法》开始在苏格兰高地实行加强缴械措施；服饰禁令留待1747'
  e['action']='1746年8月开始对列举地区的高地人实施新缴械规定；服饰禁令条款实际于1747年8月生效'
  e['evidence_notes']=(e.get('evidence_notes','')+' | Round8: Historic statute separates Aug 1746 disarm from Aug 1747 dress ban.').strip(' |')
  e['source_ids']=list(dict.fromkeys(e.get('source_ids',[])+[lm['SCT-PROSC']]))
  corrections.append({'event_id':e['id'],'previous_title':before,'corrected_title':e['title'],'source_ids':[lm['SCT-PROSC']]})
 if e['id']=='C-F04-004':
  e['date']='1747-08-01';e['date_precision']='day';e['title']='苏格兰高地男童与男子服饰禁令正式生效（部分例外）'
  e['action']='第二次定罪可被强制运往海外殖民地7年；实际执行例数需查法院档案'
  e['source_ids']=list(dict.fromkeys(e.get('source_ids',[])+[lm['SCT-PROSC']]))
  corrections.append({'event_id':e['id'],'event_date_updated_to':'1747-08-01','source_ids':[lm['SCT-PROSC']]})
new=[]
def event(i,topic,date,title,actor,action,place,slugs,notes,context_id=None,prec='year',etype='policy_mechanism',maptype='named_region_no_polygon'):
 assert i not in {x['id'] for x in ev['events']}
 new.append({'id':i,'topic_id':topic,'date':date,'date_precision':prec,'title':title,'actor':actor,'action':action,'historical_place':place,'source_ids':list(dict.fromkeys(lm[k] for k in slugs)),'research_state':'research_only','cartographic_status':maptype,'geometry_ref':None,'historical_control_polygon_approved':False,'event_continues_1699_story_id':context_id,'evidence_notes':notes,'round_added':8,'statistical_area_sqkm':None,'event_type':etype,'original_folio_personally_inspected':False})
event('C8-F01-1727-VOTE','E18-F01','1727','爱尔兰郡县议会选举权明确排除天主教徒','爱尔兰王国议会','郡县天主教徒被剥夺议会选举权，直到1793年改革','爱尔兰王国（多个郡县）',['IRL-VOTE'],'该记录为1727年法令年代节点，具体生效月日原法待核，不能使用2026成年男性人数作为历史投票总数','E6-T03',etype='electoral_statute')
event('C8-F03-1725-TAX','E18-F03','1725-06','苏格兰麦芽税抗议引起Shawfield事件并被军队镇压','大不列颠税务和驻军、地方抗议者','因麦芽税引发格拉斯哥骚乱，学者记录军人导致8名平民死亡','Glasgow',['SCT-PAY-HIST'],'8为同行评议文献二手引用，精确日与姓名需市政案卷复核；不得把整座格拉斯哥涂为被占地','E6-T04',prec='month',etype='economic_policy_unrest')
event('C8-F04-1746-ENFORCE','E18-F04','1746-08-01','高地缴械制度列明罚款、监禁和海外军队服役机制','大不列颠议会、地方官员','被认定持有武器可罚£15，欠缴者可在符合条件时送美洲服役或拘押','Scottish Highlands, specified counties',['SCT-PROSC'],'条文规定处罚选项不等于实际遣送名单，不扩大至苏格兰所有居民','E6-T04',prec='day',etype='coercive_law_detail')
event('C8-F08-1721-ADMIRALTY','E18-F08','1721','苏格兰海事法院记录出现与奴役贸易船东有关的商事纠纷','苏格兰海事法院、商人','国家档案目录登记Daniel v Graham案卷AC9/718','Scotland (specific judicial seat unverified)',['SCT-SLAVE-ARCH'],'仅档案索引确定涉奴役贸易商事诉讼，不知道原案判决或金额；不当作奴役交易位置',None,etype='archive_file_exists')
event('C8-F08-1727-ADMIRALTY','E18-F08','1727','苏格兰海事法院两份奴役船务商事案卷可供进一步核查','苏格兰海事法院、私商','Clark v Inglis及Horseburgh v Bogle案卷涉及奴隶船金融贸易','Scotland (specific judicial seat unverified)',['SCT-SLAVE-ARCH'],'NRS AC9/1022 AC9/1042仅档案可用等级，当前无原庭审定论',None,etype='archive_file_exists')
event('C8-F08-1731-SLAVE-LETTER','E18-F08','1731-05','格拉斯哥商号收到巴巴多斯有关运奴船的具年信件','William Gordon & Co、寄信者Bleney Harper','NRS馆藏CS228/A/3/19记录1731年5月商业信件','Barbados/Glasgow',['SCT-SLAVE-ARCH'],'仅登记信件和两端城市，不制造航海路线或确切涉案被奴役人数',None,prec='month',etype='archival_economic_network')
event('C8-D10-1797-FIRE-ORDER','E18-D10','1797-11','Hunter总督授权对特定条件下原住民开枪','Governor John Hunter','殖民秩序令允许在原住民群体中发现特定逃亡欧洲人时开枪','Hawkesbury River district',['AU-HAWK'],'条款需保留触发条件；不能写成总督批准无差别射杀',None,prec='month',etype='conditional_governor_order')
event('C8-D10-1799-MURDER-TRIAL','E18-D10','1799','Hawkesbury两名原住民男孩遭杀害，定罪后被告未实际执行刑罚','殖民法院、涉案定居者','据原史档衍生资料定罪者获释待王室定夺，1802另获赦','Hawkesbury River district',['AU-HAWK'],'定罪/获释具体日不详；1802获赦另存后世纪交接，不当成1799全部事件',None,etype='individual_judicial_impunity')
event('C8-F06-1798-FREEQUARTER','E18-F06','1798-05-16','爱尔兰Kildare解除武装伴随自由驻扎与强制军费供给','爱尔兰驻军、都柏林城堡行政机关','政府部队强制居住和征发住户补给以获取武器及惩罚疑似同情者','County Kildare',['IRL-1798'],'档案馆1798介绍引5月16日邓达斯信；完整驻军命令与例数待原卷逐页阅读','E6-T03-WILLIAMITE-WAR',prec='day',etype='military_requisition')
event('C8-D02-1790-MEDICAL','E18-D02','1790-06','第二舰队抵达后约200名重病犯人立即安排营地与医治','英国殖民地医疗人员/被强制运输罪犯','殖民官David Collins报告运输者遭坏血病、痢疾和发热，医疗营地紧急扩建','Sydney Cove',['AU-CONVICT'],'约200指当时Collins所述登岸重病者，非该运输总死亡数；已登记第二舰队总事件保持不重复',None,prec='month',etype='forced_transport_health_consequence')
# Existing events kept instead of creating a duplicate e.g. 1707 Union, 1787 instructions, 1791 Queen, 1795 soldiers and 1798 June Lake orders.
ev['events'].extend(new);ev['event_count']=len(ev['events']);write(EV,ev)
cwrite(R/'EVENT_CANDIDATES.csv',ev['events']);
write(O/'ROUND8_EVENT_DEDUP_AND_CORRECTIONS.json',{'schema':'c8-event-dedup-v1','old_event_count':216,'added_ids':[x['id'] for x in new],'already_covered_no_duplicate':['C6-F03-003','C2-F09-006','C7-D01-1787-INSTR','C7-D02-1790-SECOND','C7-D02-1791-IRISH','C7-IRL-1786-TRAN','C7-IRL-1790-TRAN','C5-F06-003','C2-D06-001','C-F02-002','C4-F04-003','C7-SCT-1769-TOBACCO','C7-IRL-1740-FAMINE'],'corrected_existing_events':corrections,'not_included_as_18th_century_events':['1699 Wool Act effective 1699-06-24 only as historical predecessor','1802 pardons only in 1799-1800 handoff'],'new_event_count':len(new)})
# Append evidence claims for old/new cases, with real sources
matrix=R/'CLAIM_EVIDENCE_MATRIX.json';claims=get(matrix);crm=[]
for p in pol['rows']:
 q={'id':'C8-CLAIM-'+p['id'].split('C8-P')[-1],'date_or_range':p['date_or_span'],'claim_summary':p['title']+'：'+p['mechanism'],'source_ids':p['source_ids'],'access_type':p['state_involvement_class'],'audit_limit':p['evidence_limit'],'map_eligibility':p['map_representation'],'original_folio_personally_inspected':False,'round_added':8,'policy_id':p['id']}
 claims['claims'].append(q);crm.append(q)
claims['evidence_count']=len(claims['claims']);write(matrix,claims);cwrite(R/'CLAIM_EVIDENCE_MATRIX.csv',claims['claims'])
# State involvement vs private action 16 cases and explicit counterexamples.
decisions=[]
def case(i,policy,typ,judgement,allowed,limits):
 p=next(x for x in pol['rows'] if x['id']==policy)
 decisions.append({'id':i,'policy_id':policy,'research_question':p['title'],'evidence_class':typ,'working_conclusion':judgement,'what_can_be_claimed':allowed,'what_cannot_be_claimed':limits,'source_ids':p['source_ids'],'evidence_depth':p['state_involvement_class'],'status':'research_only'})
case('C8-E01','C8-P01','direct_statute','国家竞争保护政策','英格兰议会在禁令原文明确以英格兰毛纺织业利益为目的限制爱尔兰对外出口','不能单由禁令推导利润或死亡数据')
case('C8-E02','C8-P02','direct_statute','法律性宗教—财产排除','爱尔兰议会对天主教继承、教育与权利施行体系化约束','不能把所有后续私有地产丧失归因于同一条')
case('C8-E03','C8-P03','direct_treaty','制度性给予殖民网络准入','1707第4条以法律为苏格兰臣民开放英国海外殖民地贸易资格','不能指称苏格兰所有商人都参加奴役贸易')
case('C8-E04','C8-P04','state_finance','公共补偿与殖民投资亏损关联','联合法案有国库向失利达连股份及其他财务需求提供Equivalent','不能全额算奴隶贸易利润或秘密买票')
case('C8-E05','C8-P07','military_repression','税务政策与武装镇压衔接','麦芽税激发1725城市抗议，论文报告士兵打死8人','原士兵名单/现场点未复核')
case('C8-E06','C8-P10','direct_statute','文化限制并附劳役刑罚','1747服饰禁令具海外流放法定后果','没有实际法院名单前不能把惩罚上限当实际发送人数')
case('C8-E07','C8-P11','estate_confiscation','查封、征租与管理法有明确权限','国库和财政法院对没产庄园具名处分、征租','不能画成全部高地已成为英国殖民地')
case('C8-E08','C8-P19','governor_order_killings','殖民土地保护和政府军杀戮相关','Paterson令62名士兵驱逐原住民并报告7/8人死亡','个别受害者名单及战场精度未核')
case('C8-E09','C8-P20','counterevidence_restraint','殖民政府同时有保护命令','1796 Hunter明令不得随意杀害原住民，可作为反证','不能据此断言执法确实全面有效')
case('C8-E10','C8-P21','conditional_force_authorisation','含条件使用致命武力','1797令对部分与被逃亡者共同行动的原住民可开枪','不能扩大为原住民普遍射杀许可')
case('C8-E11','C8-P24','after_the_fact_impunity','判罪后未处罚与1802赦免','特定杀害原住民儿童案定罪人获释、后获王室赦免','不能以此证明所有司法机关从未惩罚杀人者')
case('C8-E12','C8-P17','order_not_executed','严厉杀人命令与实际结果分开','Phillip原本下令抓12/杀10，后改为抓/杀6','该次远征未杀到目标，不得捏造死者')
case('C8-E13','C8-P23','counterevidence_disciplined_order','1798军队有明确限制越权毁产命令','军令承认严惩叛乱但不准士兵未授权焚屋','不能以行政禁令推论没有发生未经授权破坏')
case('C8-E14','C8-P27','environmental_shock_not_proven_intent','饥荒首先由严寒歉收导致','1740—41气候与经济脆弱性叠加人口损失巨大','无直接资料支持英国政府蓄意投毒或策划当次饥荒')
case('C8-E15','C8-P26','judicial_institution_private_finance','国家法院与奴役交易合同并存','苏格兰法院存有海事船东商事案卷','仅案卷目录不能证明陪审法院判决或交易金额')
case('C8-E16','C8-P25','state_transport_not_automatically_oversight_fault','流放制度与运输高死亡率同在','1790运输是官方刑罚链，严重疾病及死亡有报告','承包合同、检验/疏失责任须原卷，不能无条件直接定政府故意使囚犯死亡')
write(O/'STATE_RESPONSIBILITY_ADJUDICATION.json',{'schema':'c8-involvement-verdict-v1','method':'Use direct laws/orders, formal funding, delegated authority, institution records, court outcomes and countervailing restraints separately; do not predetermine all cases as permitted.','cases':decisions})
cwrite(O/'STATE_RESPONSIBILITY_ADJUDICATION.csv',decisions)
# Save 17C research boundary legal activation separately
write(O/'BOUNDARY_1698_1700_POLICY.json',{'stable_story_id':'E6-T14-NAV','law':'Wool Act 1698 (10 Will.III c16)','act_year':1698,'commencement_date':'1699-06-24','evidence_source_id':lm['LEG-WOOL'],'1700_status':'statute_attested_but_enforcement_geographies_and_specific_shipments_not_proven','continuity_class':'institutional_law_continuation','new_1700_event_created':False,'territorial_change':False,'research_only':True})
# Distinct root atlas controls and identities unaffected
write(O/'MAP_POLICY_LIMITS.json',{'geometry_added':0,'reason':'Legislative texts and demographic results are not spatial boundaries; no new coordinates sourced to event-site accuracy.','forbidden':['whole Ireland religion percent polygons','whole New South Wales British occupation from 1787 instructions','whole Scottish Highlands conflated with direct royal estate ownership','route lines and ship GPS from offender transport aggregate','1699 trade law as 1700 land capture','1795 Hawkesbury reference river as exact killing coordinates'],'allowed_after_review':['state policy icon at documented parliament/administrative site','historical town point after georeference with qualification','scoped approximate dotted area if independently sourced per place','documented fort/estate legal status per year with independently checked historical boundaries'],'research_state':'research_only'})
# Narrative dossiers with source refs and explicit claims. Material formatted for editorial use.
chapters=[
('IRELAND_LAND_LAW_ECONOMY', '爱尔兰：地权、宗教及贸易限制如何相互强化', '''1699年毛纺织品对外出口禁令清楚表明英国议会以保护英格兰毛纺织业为由，限制爱尔兰王国的合法出口市场。此法律名为Wool Act 1698，禁令日期从1699年6月24日起算。英国议会官方说明同时指出其即时经济效应不宜被无限夸大。本次将其视为明确的经济保护主义政策，而不是虚构的全国制造业失业总数。\n\n1703—1704年的爱尔兰王国议会刑法体系把天主教地产取得、继承、教育、监护与公职权利连接起来。1727年进一步明确剥夺县郡天主教选举权，直到1793年才逐步恢复。这里的立法主体首先是爱尔兰王国的议会，英王及英国政府影响另设字段；不要倒装为当时已存在联合王国内的现代北爱行政区。\n\n经济和政权效应必须区分：法定排斥存在，但旧地主拥有的土地比例变化还受到先前战乱没产、继承法、宗教改宗、家族信托、租赁规避及市场交易影响。文献流行的1704约14%和1776约5%是学术估算，不是本轮GIS测量。1778年法案大幅缓和地权限制，1782年又有宗教教育放宽，不能把限制延长到1800而没有变化。''',['LEG-WOOL','PARL-IRL','PENAL','IRL-VOTE','IRL-1778','IRL-1774']),
('IRELAND_FAMINE_TITHE_RURAL', '爱尔兰：1740—1741饥荒、税赋与农村反抗', '''1740—1741年爱尔兰出现大规模饥荒，由极端寒冬、农业减产、粮价与社会脆弱性共同造成。学术评论援引的310000—480000人死亡是估算值；人口资料不足使误差很大，应与1845—1852年大饥荒严格分开。不能把严寒当作英国施行的特定蓄意政策。研究重点是土地权不平等、佃户资源和救灾应对怎样增加脆弱性，而这些因果环节尚需财政赈济原账核实。\n\n1761年末Whiteboys在Knockmealdown山麓出现，对公地圈占、地租和什一税承包人的收费举动反抗。主体是当地农民结社、地主、宗教什一税承包人和政府；运动并非单场英国王室军战役，也不能不审地方身份就把全部反抗解释为单一民族起义。''',['IRL-FAMINE','IRL-FAMINE-DEM','IRL-WHITE']),
('IRELAND_STATE_REPRESSION_TRANSPORT', '爱尔兰：1798国家镇压、军事强取与海外流放', '''英国国家陆军博物馆记录1798年国家反叛乱力量采用大规模抓捕、鞭打、焚屋和军事占据。爱尔兰国家档案馆1798年5月16日军事书信的说明载有「free quarters」强制住宿及征用供给等集体惩罚方式。国家陆军博物馆又馆藏1798年6月2日Lake将军命令：维持严厉军事惩罚的同时限制士兵未经军官许可焚毁财产、擅自入屋。必须把「有据的官方军事策略」与「命令明令禁止的越权暴行」分别记账。\n\n爱尔兰王国1786海外流放法、1790修订、1791首船Queen自Cork启航，在制度上把爱尔兰的司法刑罚连接到澳大利亚殖民劳动力需求。1798年起义后至少300人获得海外运输判决的国家博物馆数据属于跨年司法结果，不能当成1798年立刻抵澳人数。1804年的澳大利亚Castle Hill起义是19世纪后续专题，不得塞回1799地图。''',['IRL-1798','IRL-ORDERS','AU-IRISH-TRANS','AU-IRISH-SHIP','AU-1798-TRANS']),
('SCOTLAND_UNION_TAX_FINANCE', '苏格兰：1707财政联合、殖民市场准入与1725抗税镇压', '''1707年联合条约Article 4直接将英格兰海外殖民地贸易向新大不列颠的苏格兰臣民开放，是制度性经济收益的明确法律基础。Article 15的£398085 10s Equivalent同时解决英格兰国债义务、旧政府薪资及达连投资人损失，不能全算赔偿达连的纯殖民利润。苏格兰国家记录保存1707年首笔到账与工资支付账目。\n\n1725年苏格兰麦芽税引发城镇示威和酿酒商停工，格拉斯哥Shawfield事件中学术研究称士兵杀死八位平民。须继续收集士兵开枪的具体日、命令和受害者名单。该案证明财政法令存在可记录的社会冲突，但不能因此把苏格兰整国史写成「同一种殖民地被征服」。''',['SCT-UNION','SCT-PAY','SCT-PAY-HIST','SCT-TRADE-NRS']),
('SCOTLAND_HIGHLANDS_PROPERTY', '苏格兰高地：治安立法、财产没收与农业资本化', '''1746年禁止法规定高地部分郡县居民缴械：可以罚款、监禁；法定某些欠缴罚金、适于服役者可被转送美洲军事服务。服饰禁令虽属1746年法案第17条，但到1747年8月1日才开始；二次定罪有海外强制流放七年的法定选项。需要对应法院案卷才能判断实际裁定数量。\n\n1747没产调查及1752附属庄园管理使政府依法征租并安排收入，档案记载53处曾被调查，其中12处判为非没产，最后只有部分指定庄园可作王室治理收入范围。史学研究将1780年代起的高地清场与收益率更高的牧羊、农田重组相联系；地主、经纪人与中央政府不同项目的行为不应被混写成一条遍及全高地的英国官方「清场令」。1809—1821年Sutherland大清场属于19世纪。''',['SCT-PROSC','SCT-ESTATE','SCT-HIGHLAND']),
('SCOTLAND_SLAVERY_CREDIT', '苏格兰奴役经济：港口、信用、商人及司法档案', '''1707年后殖民市场准入与苏格兰商贸机构的扩张构成历史结构性联系。1769年克莱德河三港占当年英国烟草进口52%，与美国切萨皮克由被奴役者劳动生产的烟草具有经济关系；这里不能把52%错算奴隶航次、全部收益或强迫人口。牛津学术论文给出该贸易份额和信贷机制。格拉斯哥大学证明苏格兰商人、医生、种植园所有人和出口制造商都参与经济网络，不只是本地出港奴隶船。\n\n苏格兰国家档案馆提供1721/1727年海事法院与运奴船东之间的诉讼案卷号，及1731年格拉斯哥商号往来信件，证明这类活动通过私商合同、司法债权网络形成常规商业业务。仅凭有官司不能推断法院判决支持哪一方或政府参与单次捕奴；这些案卷下一步应查原手稿。苏格兰参与东印度公司的人才网络也是海外经济扩张，但地区主责由助手2进行。''',['SCT-TOBACCO','SCT-SLAVE','SCT-SLAVE-ARCH','SCT-EIC']),
('AUSTRALIA_TERRITORIAL_LAW', '澳大利亚：王室授地授权与原住民土地未获承认', '''1768年Cook的航海指令提及经当地原住民同意占取合适地点的条件，1787年Phillip的总督指示保护原住民生命并期望友好相处，却没有把他们的土地权作为英方殖民产权的有效基线。英国法律和殖民勘测直接赋予总督土地特许权，给获释罪犯、军人和自由移民。授权虽可称制度性土地掠夺通道，实际地籍与已定居范围必须另证。\n\nRuse农场尤其能够展示法律对象差异：历史占用始于1789，获得土地记录在1791前后，1792-02-22进入正式登记；旧契据上的1790年文字被有馆藏记录的学者质疑。不得将单份地契当作已经同意的Burramattagal地权让渡，更不可将NSW王室书面权力全涂成实占面。''',['AU-1768','AU-1787','AU-GRANTS','AU-GRANT-DETAIL']),
('AUSTRALIA_LABOUR_MORTALITY', '澳大利亚：强迫运输、劳役体系与人口健康后果', '''1787—88第一舰队及随后1790第二舰队的运输是英国国家设立的流放劳动力机制。新南威尔士州立图书馆指出，第二舰队约1250名男性囚犯中超过四分之一死于旅途中，Neptune、Scarborough和Surprize三艘的航行死亡率另记26%。这些是不同分母/时间窗的资料，不能加到一起。登陆后大量生病人员接受紧急救治；后续死亡的统计起算必须确立存活分母。\n\n人口运输与土地配给共同扩张，1791年爱尔兰囚犯Queen抵港，为爱尔兰司法体系向新南威尔士转移人口开端。统计必须保留罪犯船旗、性别、刑期以及实际抵港人数，禁止把1853年底累计被运输人数全部算进18世纪。''',['AU-CONVICT','AU-CONVICT-2','AU-IRISH-TRANS','AU-IRISH-SHIP']),
('AUSTRALIA_ORDERS_IMPUNITY', '澳大利亚：1790—1799官方报复、军事护地与定罪后赦免', '''1790年Phillip因McIntyre遭刺伤向军队下令抓12杀10并取首级；军官Tench促成修订抓6或杀6。两次出击最终未抓到或杀死原住民——「官方命令」强证，「按命令执行了六名死者」为错误。1795年Paterson正式派出62士兵前往Hawkesbury确保殖民农田所有，官方报告致死7–8人、俘5人。政府直接命令和报告的衔接比单纯私人冲突更能判断国家参与。\n\n1796年Hunter禁止定居者随意杀害原住民，又在1797特定条件下允许开枪；政府命令在不同年份和条件下存在矛盾。1799年两名原住民男孩被定居者杀害，法院判罪但先放人，1802年获王室赦免。这是可追溯的特定处罚落空样本，比笼统「英国全体默许所有屠杀」更能精确表达制度和执行问题。''',['AU-INDIG','AU-HAWK']),
('HUMAN_DEMOGRAPHICS_AND_LIMITS', '人口变动的可证与不可证：爱尔兰饥荒、悉尼天花和Hawkesbury拓殖', '''1795年Hawkesbury至少约500名殖民定居者，1799年末报告1008名，证明欧洲移居者数量增长。但同期原住民人口计数与土地精确范围未能核实，不应从1008反推原住民死亡/被驱人数。\n\n1789年悉尼附近原住民群体经历小痘疫情；国家博物馆将部分受影响社群死亡上限称为70%，不是整座澳洲全部原住民70%。2026年新的流行病统计模型支持东南澳来源假说，模拟某些条件下损失220000人，但此数是模型结果而非1789年户口或具名死亡登记。两组数不能合并。爱尔兰1740—41年310000—480000死亡也是学者估算，和澳洲小痘完全不同分母。''',['AU-HAWK','AU-POP','AU-POP-MODEL','IRL-FAMINE','IRL-FAMINE-DEM']),
]
for filename,title,body,slugs in chapters:
 sid=[lm[x] for x in slugs]
 foot='\n'.join(f'- `{i}` — {next(x["title"] for x in src["sources"] if x["id"]==i)}; {next(x["url"] for x in src["sources"] if x["id"]==i)}' for i in sid)
 (O/(filename+'.md')).write_text('# '+title+'\n\n**阶段：research_only，供史学和制图审核。**\n\n'+body+'\n\n## 对应材料\n\n'+foot+'\n\n**制图规则：** 没有古代地籍/军事实控边界时只记事件或具核地点；财税份额、人口比率、王室特许均不得转换成历史实控Polygon。\n',encoding='utf-8')
# proposal nodes: no automatic publication and distinguish economic/policy framing
proposals=[
('E18-F16-PROPOSED','Ireland 1699–1782 trade and franchise legislation','E18-F01','E18-F02'),
('E18-F17-PROPOSED','Scottish post-Union fiscal riots 1725, tax and coercion','E18-F03','E18-F04'),
('E18-F18-PROPOSED','Scotland legal/court financial infrastructure supporting Atlantic enslavement','E18-F08',None),
('E18-D13-PROPOSED','Australia early penal transportation supply chain & mortality 1787–1795','E18-D02','E18-D10'),
('E18-D14-PROPOSED','NSW Crown land grants / indigenous uncompensated land loss 1787–1799','E18-D01','E18-D10'),
('E18-D15-PROPOSED','NSW official force vs punishment failure 1790–1802','E18-D06','E18-D10')]
write(O/'PROPOSED_ECONOMIC_POLICY_TOPICS.json',{'status':'research_only','items':[{'id':x,'title':title,'existing_nearby_parent_ids':[i for i in (a,b) if i],'why_proposed':'Only if editor finds a distinct editorial question; default to existing topic and avoid parallel master narratives','no_approved_polygon':True}for x,title,a,b in proposals]})
# Link events and policy to old events to avoid duplicate counts
write(O/'ROUND8_TOPIC_LINKAGE.json',{'source_story_registry':'CROSS_CENTURY_AUDIT.json','links':[
 {'arc':'Ireland economic law','source_17c':['E6-T03-LAND-1642-1698','E6-T14-NAV'],'new_18c':['E18-F01','E18-F02'],'mechanisms':['C8-P01','C8-P02','C8-P06','C8-P08','C8-P13']},
 {'arc':'Highland state intervention','source_17c':['E6-T04','E6-T04-CONQUEST','E6-T04-GLENCOE'],'new_18c':['E18-F03','E18-F04','E18-F05','E18-F09'],'mechanisms':['C8-P03','C8-P04','C8-P05','C8-P07','C8-P09','C8-P10','C8-P11','C8-P12']},
 {'arc':'Scottish slavery and EIC networks','source_17c':['E6-T11-VOYAGES','E6-T13','E6-T12'],'new_18c':['E18-F08','E18-A01','E18-B01'],'mechanisms':['C8-P26']},
 {'arc':'Irish and British convicts Australia','source_17c':['E6-T03','E6-T09'],'new_18c':['E18-D02','E18-D03','E18-F06'],'mechanisms':['C8-P14','C8-P18','C8-P25']},
 {'arc':'Aboriginal land and British colony state','source_17c':[],'new_18c':['E18-D01','E18-D03','E18-D06','E18-D10'],'mechanisms':['C8-P15','C8-P16','C8-P17','C8-P19','C8-P20','C8-P21','C8-P24']}
],'other_investigators':{'assistant1':'Clyde tobacco source/quantity bridge to Chesapeake enslaved labour and transport, no duplicate Atlantic investigation','assistant2':'Scottish East India Company patronage and Indian revenue, not duplicate Indian regional map'},'gis_polygons_approved':0})
# Update docs
progress=R/'PROGRESS.md';progress.write_text(progress.read_text(encoding='utf-8')+'\n\n## Round 8 (2026-11-08): 经济、人口与政策机制\n- 新增 `ROUND8_SYSTEMIC_IMPACT/`：27条政策机制、22项人口/经济口径、16例国家参与/限制反证、研究系列专题档案、交接与数据审核。\n- Source Registry由212条扩大至'+str(len(src['sources']))+'条；Event candidates由216条扩大至'+str(len(ev['events']))+'条，新事件仅'+str(len(new))+'条，其余在旧ID补证。\n- 行为类型明示：法令授权、行政命令、制度性经济收益、私人行动、司法结果与地方禁令；未证政府授意的私人违法行为不强行认定「国家命令」。\n- 1699毛纺出口法只算17世纪法令后续制度、1799杀害儿童案例1802后续王室赦免单列19世纪，不跨期篡改日期。\n- 无新的历史实控Polygon和虚构GPS。全部成果本地保存，未修改GitHub。\n',encoding='utf-8')
miss=R/'MISSING_TOPICS.md';miss.write_text(miss.read_text(encoding='utf-8')+'\n\n## Round 8仍未完成的原始文书/统计缺口\n- 爱尔兰县郡1727投票禁令的原始法号、施行日期、1793恢复范围与实际个体选民名单；土地14%→5%原始统计、宗教和租地绕行情况。\n- 爱尔兰1740—1741本地济贫财政、粮食进出口、地租与赈济账册，避免把严寒导致的饥荒错误标为政府蓄意杀害。\n- 苏格兰1746服饰禁令实际二次定罪和运输人数、1725税务抗议8名死者及士兵开枪命令、附属地产准确地籍及历年净租金。\n- 苏格兰NRS AC9/718、AC9/1022、AC9/1042、CS228/A/3/19民商案卷原始庭审结论；伦敦王室财政/苏格兰商人贸易账必须由助手1/2协同调查。\n- NSW第二舰队私人承包及疾病死亡分母、1790 Phillip报复命令两版和两次远征最终结果、1795 Paterson报表原卷、1799杀害两名男孩司法案与1802赦免王室原件。\n- 1787 Phillip地权/财产权宣示与原住民书面同意不存在的证据需要原土地测量范围；不能从早期殖民授地推算NSW全境被占面积。\n- 2026年新小痘统计模拟需通读模型方法、检验区域人口与病例记载；模型损失不归入真实伤亡总数。\n',encoding='utf-8')
read=R/'README.md';read.write_text(read.read_text(encoding='utf-8')+'\n\n### Round 8 经济、人口、政策体系审查\n查看 `ROUND8_SYSTEMIC_IMPACT/`，首读 `ROUND8_INDEX.json` → `POLICY_MECHANISM_MATRIX.json` → `STATE_RESPONSIBILITY_ADJUDICATION.json` → `QUANTIFIED_IMPACTS.json` → 分篇MD。该轮不创造新历史边界，未查原件均保留阅读等级。\n',encoding='utf-8')
