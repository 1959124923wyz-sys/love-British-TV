"""Reproducible local structural QA. No GitHub writes or external network requests."""
from pathlib import Path
from collections import Counter
import json,csv,zipfile,hashlib
p=Path('/mnt/data/18c_assistant_C')
def read(f):return json.loads((p/f).read_text(encoding='utf-8'))
a=read('CROSS_CENTURY_AUDIT.json')
c=read('CONTROL_TRANSITIONS_1699_1709.json')
e=read('EVENT_CANDIDATES.json')
s=read('SOURCE_REGISTRY.json')
g=read('MAP_CANDIDATES.geojson')
checks=[]
def check(label,cond,details=''):
 checks.append({'test':label,'passed':bool(cond),'details':str(details)[:1500]})
 if not cond:print('FAIL',label,details)
aids=[x['previous_story_id'] for x in a['entries']];check('17C 36 exact unique identifiers',len(aids)==36 and len(set(aids))==36)
check('17C five continuation classes',Counter(x['continuation_kind'] for x in a['entries'])=={'institutional_continuation':18,'consequences_only':7,'parent_program':7,'direct_cross_boundary_episode':2,'closed_earlier_no_same_event':2})
check('Old research window separate from historical end',all('previous_research_end_year' in x and 'historical_endpoint_year' in x and 'historical_endpoint_status' in x for x in a['entries']))
check('Old metadata unconfirmed territory never carried',all(x['geometry_auto_carry_allowed'] is False for x in a['entries']))
check('27 geographic seed layers',len(c['candidates'])==27)
check('27 unique stable labels',len({x['stable_id'] for x in c['candidates']})==27)
check('27 x 10 distinct annual slots',all([x['year'] for x in q['year_end_reviews']]==list(range(1700,1710)) for q in c['candidates']))
check('No mapped colonial polygon authorized',all(q['historical_boundary_confirmed'] is False and all(z['verified_historical_polygon'] is False for z in q['year_end_reviews']) for q in c['candidates']))
check('Darien ends by end-1700',next(q for q in c['candidates'] if q['stable_id']=='C-TRANS-DARIEN')['year_end_reviews'][0]['year_end_evidence_state']=='abandoned_by_year_end_source_attested')
check('All original 17C reference layers retain invalid polygon status',all(q['geography_type']=='reference_only_unverified_polygon' for q in c['candidates']))
check('Source IDs unique',len({x['id'] for x in s['sources']})==len(s['sources']))
source_ids={x['id'] for x in s['sources']}
for collection,items in [('17C audit',a['entries']),('annual years',[r for q in c['candidates'] for r in q['year_end_reviews']]),('additional political relation',c['additional_distinct_political_relations']),('events',e['events']),('geojson',[q['properties'] for q in g['features']])]:
 missing=sorted({sid for q in items for sid in q.get('source_ids',[]) if sid not in source_ids})
 check(collection+' sources all registered',not missing,missing)
check('No empty source URLs',all(x['url'].startswith('https://') for x in s['sources']))
ids=[x['id'] for x in e['events']];check('Event identifiers unique and >= 110',len(ids)==len(set(ids)) and len(ids)>=110)
with (p/'EVENT_CANDIDATES.csv').open(encoding='utf-8-sig',newline='') as f:cc=list(csv.DictReader(f))
check('CSV and JSON event IDs/topics aligned',len(cc)==len(ids) and {(x['id'],x['topic_id']) for x in cc}=={(x['id'],x['topic_id']) for x in e['events']})
check('126 source registrations minimum',len(source_ids)>=126)
bridges=read('TRIPLE_CENTURY_BRIDGES.json')
claims=read('CLAIM_EVIDENCE_MATRIX.json')
bridge_ids=[x['id'] for x in bridges['bridges']]
claim_ids=[x['id'] for x in claims['claims']]
check('Eight unique triple-century bridge comparisons',len(bridge_ids)==len(set(bridge_ids))==8)
check('37 source-linked claim evidence checks',len(claim_ids)==len(set(claim_ids))==claims['evidence_count']>=37)
check('Triple-century source references registered',not set(sid for x in bridges['bridges'] for sid in x['source_ids'])-source_ids)
check('Claim evidence source references registered',not set(sid for x in claims['claims'] for sid in x['source_ids'])-source_ids)
with (p/'CLAIM_EVIDENCE_MATRIX.csv').open(encoding='utf-8-sig',newline='') as f: claim_csv=list(csv.DictReader(f))
check('Claim evidence matrix CSV rows',len(claim_csv)==len(claim_ids))
check('All new source access types explicitly noted',all('access_level' in src and 'original_manuscript_personally_inspected' in src for src in s['sources']))
check('No cross-domain check mis-assigned to Virginia code E18-C22',all(x['topic_id']!='E18-C22' for x in e['events'] if x['id'] in ('C2-C22-001','C2-C22-002')))

check('No false Atlases publication labels',all(x['research_state']=='research_only' and x['historical_control_polygon_approved'] is False for x in e['events']))
check('Events have actor, action, place and accuracy',all(all(x.get(k) for k in ('date','actor','action','historical_place','date_precision','cartographic_status')) for x in e['events']))
check('E18 D01-D10 and F01-F09 all represented',all(any(x['topic_id']=='E18-'+s+'%02d'%n for x in e['events']) for s,k in [('D',10),('F',9)] for n in range(1,k+1)))
check('All D/F dossiers exist',all((p/'TOPIC_DOSSIERS'/('E18-'+s+'%02d.md'%n)).exists() for s,k in [('D',10),('F',9)] for n in range(1,k+1)))
check('Nine additional continuity dossiers exist',len(list((p/'TOPIC_DOSSIERS').glob('*.md')))==28)
refs={f['id'] for f in g['features']}
check('All linked event geo references exist',all(not x['geometry_ref'] or x['geometry_ref'] in refs for x in e['events']))
check('42+ named localities and only 3 sourced modern Point references',len(g['features'])>=42 and sum(bool(x['geometry']) for x in g['features'])==3)
check('GeoJSON no lines/polygons',all(x['geometry'] is None or x['geometry']['type']=='Point' for x in g['features']))
check('GeoJSON no boundary/area claims',all(x['properties'].get('historical_boundary_confirmed') is False and x['properties'].get('territorial_claim') is False and x['properties'].get('fill_authorized') is False and x['properties'].get('area_sqkm') is None and x['properties'].get('exclude_from_area_aggregation') is True for x in g['features']))
check('No invented numeric precision',all(x['geometry'] is None or len(x['geometry']['coordinates'])==2 for x in g['features']))
check('Narrative handoffs exist',all((p/q).exists() for q in ('MISSING_TOPICS.md','PROGRESS.md','README.md','CONTROL_RELATION_DECISION_GUIDE.md')))
# Dossier source references occasionally contain source ids not used on actual events; checked by collecting lines.

# Third-round added authoritative site control and boundary transition quality gates
sites=read('SITE_SPECIFIC_CONTROL_1697_1715.json')
check('Four distinct forts each with 1700-1709 slots',len(sites['sites'])>=4 and all(len(x['records'])==10 and [z['year'] for z in x['records']]==list(range(1700,1710)) for x in sites['sites']))
check('All France site control source IDs registered',not set(i for s0 in sites['sites'] for i in s0.get('source_ids',[]))-source_ids)
check('Old York Fort not mapped to modern York Factory III coordinate',all(s0['geographic_point'] is None and s0['historical_control_polygon_confirmed'] is False for s0 in sites['sites']))
rupert=next(q for q in c['candidates'] if q['stable_id']=='C-TRANS-RUPERT-PAPER')
check('Rupert charter separately references actual French York fort',rupert.get('site_specific_counterexample_1700_1709')=='C-SITE-YORKFACTORY-FR-1697-1713')
conflicts=read('ROUND3_EVIDENCE_CONFLICTS.json')
check('Nine or more dated source/identity conflicts tracked',len(conflicts['conflicts'])>=9)
check('Evidence conflict source IDs registered',not set(i for case in conflicts['conflicts'] for pos in case['positions'] for i in pos.get('source_ids',[]))-source_ids)
hand=read('BOUNDARY_1799_1800_HANDOFF.json')
check('5 explicit 1799-1800 stable future arcs',len(hand['entries'])==5)
check('Future arc source IDs registered',not set(i for row in hand['entries'] for i in row['source_ids'])-source_ids)
check('No 1800 future arc mistakenly published',hand['is_1800s_production_atlas'] is False and all(row['geometry_supported'] is False for row in hand['entries']))
check('Ruse date contradiction still visible',any(x['id']=='C2-D10-002' and x['date_precision']=='reported_day_conflicted' for x in e['events']))
check('Ruse archival registration independently recorded',any(x['id']=='C3-D10-002' and x['date']=='1792-02-22' for x in e['events']))
check('Arabanoo and Bennelong precision updated',all(any(x['id']==key and x['date']==date for x in e['events']) for key,date in [('C-D04-001','1788-12'),('C-D04-002','1789-05-18'),('C-D04-003','1789-11-25')]))
check('Scottish 1746 act is not effective 1746 map status',any(x['id']=='C3-F04-001' and x['date']=='1748-03-25' for x in e['events']))
check('Round3 longform plus separate QA support files exist',all((p/q).exists() for q in ['ROUND3_DEEP_RESEARCH.md','ROUND3_EVIDENCE_CONFLICTS.json','SITE_SPECIFIC_CONTROL_1697_1715.json','BOUNDARY_1799_1800_HANDOFF.json']))

check('Source count manifest matches',s['source_count']==len(s['sources']))
check('Event count manifest matches',e['event_count']==len(e['events']))
report={'schema':'assistant-C-local-qa-v1','date':'2026-11-08','overall_pass':all(q['passed'] for q in checks),'checked_objects':{'old_story_ids':len(aids),'annual_control_records':sum(len(x['year_end_reviews']) for x in c['candidates']),'topic_dossiers':len(list((p/'TOPIC_DOSSIERS').glob('*.md'))),'event_rows':len(ids),'source_registry':len(source_ids),'geojson_place_candidates':len(g['features']),'located_modern_points':sum(bool(x['geometry']) for x in g['features'])},'checks':checks,'limitations':['Automated QA checks self-consistency only, not independent facsimile verification','Most 1700-1709 annual actual administrative and garrison status remains unproved','All georeferenced points are modern reference points, not precise historic event coordinates','No production 18C Atlas, no browser acceptance testing, no true historical boundary validation']}
(p/'QA_REPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('LOCAL QA:',len(checks),'checks,',sum(q['passed'] for q in checks),'PASS, overall',report['overall_pass'])
if not report['overall_pass']:raise SystemExit('Local QA failed, no release')
zip_path=Path('/mnt/data/18c_assistant_C_continuity_australia.zip')
with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for f in sorted(p.rglob('*')):
  if f.is_file() and '_inputs' not in f.parts: z.write(f,arcname='18c_assistant_C/'+str(f.relative_to(p)))
with zipfile.ZipFile(zip_path) as z:
 bad=z.testzip();files=z.namelist()
 assert bad is None
 assert '18c_assistant_C/PROGRESS.md' in files
 assert '18c_assistant_C/MISSING_TOPICS.md' in files
print('ZIP VERIFIED:',zip_path,'files',len(files),'bytes',zip_path.stat().st_size,'SHA256',hashlib.sha256(zip_path.read_bytes()).hexdigest())
