#!/usr/bin/env python3
import json,csv,pathlib,collections,re,hashlib,zipfile
P=pathlib.Path(__file__).resolve().parent
j=lambda n:json.loads((P/n).read_text(encoding='utf8'))
checks=[];exceptions=[]
def test(name,fn):
 try:
  r=fn();checks.append({'name':name,'ok':True,'detail':r})
 except Exception as e:checks.append({'name':name,'ok':False,'detail':str(e)});exceptions.append(name)
S=j('SOURCE_REGISTRY.json');E=j('EVENT_CANDIDATES.json');G=j('MAP_CANDIDATES.geojson');C=j('CLAIM_EVIDENCE_MATRIX.json');T=j('CONTROL_TRANSITIONS_1699_1709.json');A=j('CROSS_CENTURY_AUDIT.json');Q=j('ROUND5_SITE_YEAR_DECISION_MATRIX_1699_1710.json');D=j('ROUND3_EVIDENCE_CONFLICTS.json');site=j('SITE_SPECIFIC_CONTROL_1697_1715.json');idx=j('ROUND5_INDEX.json')
sids={r['id'] for r in S['sources']};eids={r['id'] for r in E['events']}
test('36 complete 17c stable story IDs', lambda:(len(A['entries'])==36 and len({r['previous_story_id'] for r in A['entries']})==36) or (_ for _ in ()).throw(ValueError('not 36 unique')))
test('17c continuity classifications sum 36',lambda:(sum(A['counts_by_kind'].values())==36) or (_ for _ in ()).throw(ValueError('wrong classifications')))
test('27 distinct 1699 reference candidates',lambda:(len(T['candidates'])==27 and len({r['stable_id'] for r in T['candidates']})==27) or (_ for _ in ()).throw(ValueError('missing reference layers')))
test('270 1700..1709 legacy research years',lambda: all(len(x['year_end_reviews'])==10 and [y['year'] for y in x['year_end_reviews']]==list(range(1700,1710)) for x in T['candidates']) or (_ for _ in ()).throw(ValueError('annual slots not 10')))
test('8 additional 1699..1710 site/polity relations',lambda:(len(Q['relations'])==8 and all([y['year'] for y in r['annual_1699_1710']]==list(range(1699,1711)) for r in Q['relations'])) or (_ for _ in ()).throw(ValueError('incorrect 12-year histories')))
test('source register count and unique IDs',lambda:(len(S['sources'])==S['source_count']==len(sids)) or (_ for _ in ()).throw(ValueError('source count/duplicates')))
test('event count/unique IDs',lambda:(len(E['events'])==E['event_count']==len(eids)) or (_ for _ in ()).throw(ValueError('event count/duplicates')))
test('evidence claims count',lambda:(len(C['claims'])==C['evidence_count']) or (_ for _ in ()).throw(ValueError('claim count')))
test('conflict IDs unique',lambda:(len({r['id'] for r in D['conflicts']})==len(D['conflicts'])) or (_ for _ in ()).throw(ValueError('duplicate conflicts')))
def walk_sources(obj,path='root'):
 if isinstance(obj,dict):
  for k,v in obj.items():
   if k=='source_ids' and isinstance(v,list):
    bad=[x for x in v if x not in sids]
    if bad:raise ValueError(path+' missing '+str(bad))
   elif k=='source_ids' and isinstance(v,str):
    if v not in sids:raise ValueError(path+' missing '+v)
   else:walk_sources(v,path+'/'+k)
 elif isinstance(obj,list):
  for i,x in enumerate(obj):walk_sources(x,path+f'/{i}')
for n in ['EVENT_CANDIDATES.json','CLAIM_EVIDENCE_MATRIX.json','MAP_CANDIDATES.geojson','ROUND3_EVIDENCE_CONFLICTS.json','HISTORICAL_MAP_SOURCE_CATALOG.json','SITE_SPECIFIC_CONTROL_1697_1715.json','ROUND5_SITE_YEAR_DECISION_MATRIX_1699_1710.json','ROUND5_PRE_POST_18C_ANCHORS.json','CROSS_CENTURY_AUDIT.json','CONTROL_TRANSITIONS_1699_1709.json']:
 test('all source IDs valid: '+n,lambda n=n:walk_sources(j(n)))
def geom_validate():
 assert G['type']=='FeatureCollection'
 for f in G['features']:
  geom=f['geometry']
  assert geom is None or geom['type']=='Point',f['id']
  pr=f['properties'];assert pr.get('fill_authorized') is False,f['id'];assert pr.get('historical_boundary_confirmed') is False,f['id'];assert pr.get('area_sqkm') is None,f['id']
  for ref in pr.get('linked_event_ids',[]): assert ref in eids,(f['id'],ref)
 return 'only sourced points, all nonpolygon, no unverified event refs'
test('all 46 geographic candidates are points/null with valid links',geom_validate)
test('geo source count and 3 points',lambda:(len(G['features'])>=46 and sum(bool(x['geometry']) for x in G['features'])==3) or (_ for _ in ()).throw(ValueError('unexpected geo')))
def event_semantics():
 wrong=[]
 for r in E['events']:
  d=r['date'];precision=r['date_precision']
  if not re.fullmatch(r'\d{4}(-\d{2}){0,2}',d):wrong.append((r['id'],d))
  if not ((1699<=int(d[:4])<=1799) or (r.get('is_prior_century_continuity_anchor') is True and int(d[:4])<1700)):wrong.append((r['id'],'outside 1699-1799 without preceding-continuity-anchor tag'))
  if r.get('historical_control_polygon_approved') is not False:wrong.append((r['id'],'polygon approval'))
  if not r.get('source_ids'):wrong.append((r['id'],'no sources'))
 if wrong:raise ValueError(str(wrong[:15]))
 return 'dates normalized, 1697 and 1699 predecessor context explicitly tagged or retained, no unauthorized polygon'
test('events chronological review',event_semantics)
def csv_equal():
 with (P/'EVENT_CANDIDATES.csv').open(encoding='utf-8-sig',newline='') as f:
  rows=list(csv.DictReader(f))
 assert len(rows)==len(E['events'])
 for row,e in zip(rows,E['events']):
  assert row['id']==e['id'] and row['date']==e['date'] and row['source_ids']==';'.join(e['source_ids'])
 return 'CSV matches JSON exact IDs/dates/source IDs'
test('csv-json event equivalence',csv_equal)
def crew():
 a=j('ROUND5_PRE_POST_18C_ANCHORS.json');b=j('ROUND5_EVENT_DEDUP_REVIEW.json')
 assert len(a['anchors'])==3 and all(x['id'] not in eids for x in a['anchors'])
 assert len(b['merged_redundant_events'])==6 and all(x['discard_redundant_candidate'] not in eids and x['retained_id'] in eids for x in b['merged_redundant_events'])
 return 'all 9 records preserved by merge/archive not forgotten'
test('event record deduplication/audit anchors',crew)
test('D-series dossiers 10 files',lambda:all((P/'TOPIC_DOSSIERS'/f'E18-D{i:02d}.md').exists() for i in range(1,11)) or (_ for _ in ()).throw(ValueError('D missing')))
test('F-series dossiers 9 files',lambda:all((P/'TOPIC_DOSSIERS'/f'E18-F{i:02d}.md').exists() for i in range(1,10)) or (_ for _ in ()).throw(ValueError('F missing')))
test('all D/F dossiers preserve 5th round research',lambda:(sum('第五轮' in x.read_text() for x in (P/'TOPIC_DOSSIERS').glob('E18-[DF]*.md'))>=15) or (_ for _ in ()).throw(ValueError('dossier append missing')))
test('new 1708 O.S. / 1709 N.S. date resolution',lambda:(next(x for x in E['events'] if x['id']=='C4-C26-002')['date']=='1709-01-01') or (_ for _ in ()).throw(ValueError('calendar unresolved')))
test('year 1798 Killala unresolved day preserved',lambda:(next(x for x in E['events'] if x['id']=='C2-F06-002')['date']=='1798-08') or (_ for _ in ()).throw(ValueError('unwarranted day')))
test('Scotland precise parliament dates',lambda:(next(x for x in E['events'] if x['id']=='C-F03-001')['date']=='1707-01-16' and next(x for x in E['events'] if x['id']=='C-F03-002')['date']=='1707-03-06') or (_ for _ in ()).throw(ValueError('Scotland exact dates')))
test('round 5 archived counts preserved as lower-bound baseline',lambda:(idx['ending_counts']['events']<=len(E['events']) and idx['ending_counts']['sources']<=len(S['sources']) and idx['ending_counts']['places']<=len(G['features'])) or (_ for _ in ()).throw(ValueError('index stale')))
report={'schema':'assistant-C-round5-static-quality-audit-v1','state':'research_only_not_publication','date':'2026-11-08','checks':checks,'pass':sum(c['ok'] for c in checks),'fail':len(exceptions),'fails':exceptions,'quantitative_summary':{'17c_stories':len(A['entries']),'1699_reference_layers':len(T['candidates']),'1700_1709_reference_reviews':sum(len(r['year_end_reviews']) for r in T['candidates']),'site_regimes_1699_1710':len(Q['relations']),'site_regime_year_decisions':sum(len(r['annual_1699_1710']) for r in Q['relations']),'event_candidate_rows':len(E['events']),'sources':len(S['sources']),'claim_evidence':len(C['claims']),'date_source_conflicts':len(D['conflicts']),'named_geolocations':len(G['features']),'points_with_coordinates':sum(bool(x['geometry']) for x in G['features']),'actual_colonial_polygons':0},'limitations':['No original manuscripts personally examined unless explicitly noted otherwise','Period-supported annual facts are not individual end-of-year garrison archives','No original 1798 campaign maps georeferenced','No GitHub writes','No published atlas map or browser integration']}
(P/'ROUND5_QA_REPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print('PASS',report['pass'],'FAIL',report['fail']);print(json.dumps(report['quantitative_summary'],ensure_ascii=False))
if exceptions:
 for x in checks:
  if not x['ok']:print('FAIL',x['name'],x['detail'])
 raise SystemExit(1)
