# 跨世纪专题调查：JAMAICA_MAROONS

原17世纪稳定ID：`E6-T08`。对应18世纪研究专题：`E18-A05 E18-A11 E18-A12`。


## 已核时间链

Maroons autonomous across 1700; First Maroon War 1728–39, treaties 1739, Second 1795, transport 1796


## 地图实控、政权与边界风险

Do not automatically count autonomous Maroon mountains as direct plantation rule.


## 研究任务

将原17世纪文章末尾准确的研究截止和真实战事结束分别录入。校对相邻年份发生的法律效力、实地驻军及地方原住民/自治政体，建立多主体年末状态。已有旧文章不需要为延长年份而改写已发生的战争。


## 来源

- `SRC17` GitHub project PR #289 https://github.com/1959124923wyz-sys/love-British-TV/blob/492a153aa181517edea47877e6b7c83951412e43/research/18c/CROSS_CENTURY_STORY_CONTINUITY.json


状态：研究级交接，地图历史范围未获测绘核准。

## 第三轮专题复查

**跨到1800而非1799结束**：Parks Canada新斯科舍马龙国家历史事件资料C3-CAN-MAROON-PLAQ记：1796年4月Trelawny Town社区遭放逐，7月到Nova Scotia，持续请愿后于1800迁居Sierra Leone，9月30日HMS Asia于Freetown下锚，船上分妇女177、男子151、儿童222。另有少数Maroon留在新斯科舍，不可将1796强制迁移画成每名成员都于1800离开。人数为不同统计日期和分母，切勿重复累计。该事实属于与助手1的协作锚点。
