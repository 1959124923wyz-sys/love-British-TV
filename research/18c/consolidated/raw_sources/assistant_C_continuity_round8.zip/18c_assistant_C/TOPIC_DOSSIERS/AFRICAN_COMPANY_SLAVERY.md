# 跨世纪专题调查：AFRICAN_COMPANY_SLAVERY

原17世纪稳定ID：`E6-T11;E6-T13;E6-T17-AFRICAN-FORTS`。对应18世纪研究专题：`E18-A01 E18-A03 E18-E10`。


## 已核时间链

1698 RAC monopoly altered but African trafficking/Atlantic trade persisted; 18C source denominator must be new


## 地图实控、政权与边界风险

Fort trading license is not inland political sovereignty; never reuse 1601–1700 voyage totals.


## 研究任务

将原17世纪文章末尾准确的研究截止和真实战事结束分别录入。校对相邻年份发生的法律效力、实地驻军及地方原住民/自治政体，建立多主体年末状态。已有旧文章不需要为延长年份而改写已发生的战争。


## 来源

- `S82` UK Parliament https://www.parliament.uk/about/living-heritage/transformingsociety/tradeindustry/slavetrade/overview/parliament-regulates-the-africa-trade/

- `S38` Historic England https://historicengland.org.uk/research/results/reports/8203/TheTransatlanticSlaveEconomyandEnglandsBuiltEnvironmentAResearchAudit


状态：研究级交接，地图历史范围未获测绘核准。

## 第三轮专题复查

**1796→1800马龙迁徙跨世纪链接**：加拿大公园局国家历史事件公告（C3-CAN-MAROON-PLAQ）证明1796年Trelawny Maroons遭从牙买加放逐并在7月抵新斯科舍，1800-09-30 HMS Asia到达Freetown时载177名妇女、151名男子、222名儿童。三数字合550，代表**这艘船具体到达口径**，不可倒填为1796当初全岛放逐总人数；1800跨入19世纪，不能用1799事件提前显示。此内容交助手1；负责跨世纪断点，不重复其牙买加主线。
