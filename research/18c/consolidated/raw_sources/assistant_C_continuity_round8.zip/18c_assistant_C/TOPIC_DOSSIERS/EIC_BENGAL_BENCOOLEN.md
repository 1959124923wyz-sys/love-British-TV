# 跨世纪专题调查：EIC_BENGAL_BENCOOLEN

原17世纪稳定ID：`E6-T12`。对应18世纪研究专题：`E18-B01 E18-E15`。


## 已核时间链

EIC company 1698 Mughal Bengal three village rights; 1719 Bencoolen revolt and withdrawal; 1723 recapture


## 地图实控、政权与边界风险

Zamindari not sovereign Bengal; annual fort occupancy needs real registers.


## 研究任务

将原17世纪文章末尾准确的研究截止和真实战事结束分别录入。校对相邻年份发生的法律效力、实地驻军及地方原住民/自治政体，建立多主体年末状态。已有旧文章不需要为延长年份而改写已发生的战争。


## 来源

- `S78` Journal of British Studies / Cambridge https://www.cambridge.org/core/journals/journal-of-british-studies/article/making-and-unmaking-of-a-presidency-envisioning-empire-in-british-bencoolen-16851825/4C0CA8C6BF1E88181DA0CEACBC33C47A


状态：研究级交接，地图历史范围未获测绘核准。
