# 跨世纪专题调查：1700_NEWFOUNDLAND_LAW

原17世纪稳定ID：`E6-T10-NEWFOUNDLAND`。对应18世纪研究专题：`E18-C26`。


## 已核时间链

1699 fishery statute clauses begun 1700-03-25; existing seasonal fishing and French Plaisance distinct


## 地图实控、政权与边界风险

Law effect is not 1700 capture of island nor loss of Beothuk sovereignty.


## 研究任务

将原17世纪文章末尾准确的研究截止和真实战事结束分别录入。校对相邻年份发生的法律效力、实地驻军及地方原住民/自治政体，建立多主体年末状态。已有旧文章不需要为延长年份而改写已发生的战争。


## 来源

- `S79` Memorial University Newfoundland https://www.heritage.nl.ca/lawfoundation/articles/doc2_1699william.html

- `S80` Newfoundland Provincial Court https://www.court.nl.ca/provincial/about/court-profile/historical-overview/


状态：研究级交接，地图历史范围未获测绘核准。

### 第四轮：1700–09同岛英法据点反差
1700–09法军驻Plaisance；St John’s的Fort William由英方重建，1705法军袭镇未取堡，1709攻克摧毁。Parks Canada旧碑铭1708与已批准碑文1709有异；地图年末只敢认定1709原堡被毁，不能推算永久法军占领圣约翰斯。资料见C4-CAN-PARKS-FORTWILL及C4-CAN-PARKS-PLACENTIA。

## 第五轮｜1708旧历／1709新历圣约翰斯堡垒易手

Fort William于1708-12-21旧历即1709-01-01新历被Saint-Ovide军攻下，DCB C5-CAN-DCB-LLOYD提供两日期对应；1709年末英方持久驻军未证，法国当年末驻军亦需另核。1729司法机构新阶段必须与1699法案1700条款生效分开。
