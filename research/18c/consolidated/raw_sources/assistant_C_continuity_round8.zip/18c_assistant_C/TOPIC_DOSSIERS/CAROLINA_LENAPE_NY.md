# 跨世纪专题调查：CAROLINA_LENAPE_NY

原17世纪稳定ID：`E6-T09-CAR;E6-T09-PENNSYLVANIA;E6-T09-NY`。对应18世纪研究专题：`E18-C21 E18-C23 E18-C24 E18-C25`。


## 已核时间链

1715 Yamasee, 1737 Walking Purchase, 1712 NY resistance, 1741 NY alleged conspiracy trials


## 地图实控、政权与边界风险

Distinct Indigenous sovereignty, coerced land deeds, criminal allegation evidence, charters not occupancy.


## 研究任务

将原17世纪文章末尾准确的研究截止和真实战事结束分别录入。校对相邻年份发生的法律效力、实地驻军及地方原住民/自治政体，建立多主体年末状态。已有旧文章不需要为延长年份而改写已发生的战争。


## 来源

- `S73` South Carolina Encyclopedia https://www.scencyclopedia.org/sce/entries/yamassee-war/

- `S75` Historical Society of New York Courts https://history.nycourts.gov/case/slave-conspiracy-trials/

- `S76` Haverford College https://findingaids.library.upenn.edu/records/HAVERFORD_HC.MC.950.175

- `S83` NYC Commission on Human Rights https://home4.nyc.gov/assets/cchr/downloads/pdf/publications/AntiBlackRacism_Report.pdf


状态：研究级交接，地图历史范围未获测绘核准。


## 2026-11-08第二轮补核

额外跨世纪对照：New Jersey 1702-04-15/17领主交政权但产权不转；Delaware Lower Three Counties 1704独立议会但仍由Penn governor管理；上述只是新政治关系断点，进一步调查交助手1。
