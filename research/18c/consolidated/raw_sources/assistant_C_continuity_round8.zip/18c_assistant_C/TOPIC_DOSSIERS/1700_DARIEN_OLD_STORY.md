# 跨世纪专题调查：1700_DARIEN_OLD_STORY

原17世纪稳定ID：`E6-T04-DARIEN`。对应18世纪研究专题：`E18-F09`。


## 已核时间链

1699 second landing, 1700 Toubacanti attack, 1700 Spanish siege and Scottish surrender; exact day pending


## 地图实控、政权与边界风险

No Scottish garrison as of 1700-12-31; Guna not ceded; do not paint Panama as Scots/British.


## 研究任务

将原17世纪文章末尾准确的研究截止和真实战事结束分别录入。校对相邻年份发生的法律效力、实地驻军及地方原住民/自治政体，建立多主体年末状态。已有旧文章不需要为延长年份而改写已发生的战争。


## 来源

- `S72` National Museums Scotland https://www.nms.ac.uk/discover-catalogue/the-darien-scheme

- `S88` National Museums Scotland https://www.nms.ac.uk/discover-catalogue/scotland-and-the-transatlantic-slave-system


状态：研究级交接，地图历史范围未获测绘核准。


## 2026-11-08第二轮补核

C2-DAR-2025补出1700年2、3、4月候审时间链，儒略/公历尚不裁定；1707 Equivalent法定金额独立案，不延长1700据点。

## 第五轮｜达连文书史料层级与三月—四月分界

C5-SCOT-NLS-DARIENPAPERS收录1700年3月18日达连议事、21日委任书；此为后世印刷的同期文书选录，不是已逐页审阅17世纪亲笔原档。投降日期另据C2-DAR-2025，应保留不同来源，1707不再作为殖民据点控制持续状态。
