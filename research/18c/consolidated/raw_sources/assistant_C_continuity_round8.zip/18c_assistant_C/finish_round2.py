from pathlib import Path
import json,csv
P=Path('/mnt/data/18c_assistant_C')
def read(n):return json.loads((P/n).read_text(encoding='utf-8'))
def dump(n,data):(P/n).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
bridges=[
 ('T3C-IRISH-CONSTITUTION',['tudor-wales-ireland-legal-restructuring-1536-1542'],['E6-T01','E6-T02','E6-T03-LAND-1642-1698'],['E18-F01','E18-F02','E18-F06','E18-F07'],'1536-1542, 1600s plantation/confiscation, 1702/1704 religious land acts, 1778 relief, 1782-1783 legislative reversal, 1798 uprising, 1800/1801 union','在16世纪由英王对爱尔兰政治与宗教制度重组后，17世纪殖民计划、没产法律与威廉派战争逐步形成新的地权关系，18世纪惩罚法不应被静态延续到1782后。','new_discrete_statutes_and_conflicts_not_a_single_three_century_war',['C2-IRL-1494','C2-IRL-1702','C2-IRL-1778','C2-IRL-1782','C2-IRL-1798-ARCH']),
 ('T3C-IRISH-MUNSTER',['munster-gilbert-first-desmond-rebellion-1569','munster-desmond-1579-1586','munster-plantation-land-grants-and-aftermath-1584-1589'],['E6-T01','E6-T02','E6-T03-LAND-1642-1698'],['E18-F01','E18-F06'],'1569 war, 1579-1583 war, 1584-89 grants; 1600s other land seizures; 1702/04 legal disabilities; 1798 uprisings','16世纪芒斯特具体庄园地块不是18世纪已证现存同一土地所有权；要求逐产权转让链。','different_violence_vs_land_title_vs_law_no_geometry_carry',['C2-IRL-1702','C2-IRL-1798-ARCH']),
 ('T3C-ATLANTIC-ENSLAVEMENT',['english-guinea-trade-enslaved-africans-1553-1557','hawkins-lovell-atlantic-enslavement-1562-1569'],['E6-T11','E6-T11-VOYAGES','E6-T13','E6-T07-BARBADOS'],['E18-A01','E18-A02','E18-A03','E18-A09'],'1550s independent English voyages -> later 17C RAC/ship commerce -> 1698 monopoly changes -> 18C ship registries/trades','不同年段分母、插补、船旗、俘虏人数和抵岸/登船口径互不合并；贸易法权不等于西非陆地主权。','voyage_network_continuity_not_same_organization_or_voyage',['S82','SRC17']),
 ('T3C-PIRACY-CAPTURE',['drake-panama-mule-train-raid-1572-1573','drake-circumnavigation-privateering-resistance-1577-1580','drake-great-west-indian-raid-1585-1586'],['E6-T14','E6-T14-NAV'],['E18-A02','E18-C15'],'16C海盗/王室私掠 -> 17C航海法、英荷战争 -> 18C海上税法和战时截船','历史航行线未核GPS与实际海军占领海域严禁混同；对各年份授权和船主另核。','trade_legal_network_without_maritime_sov_polygon',['SRC17']),
 ('T3C-NEWFOUNDLAND',['cabot-bristol-atlantic-voyages-1496-1498'],['E6-T10','E6-T10-NEWFOUNDLAND'],['E18-C26'],'1497 voyage and competing landfall hypotheses; 1610 onward intermittent settlements; 1699 fishery act, 1700 partial operation, 1729 courts','16世纪航海探索声索不应当成17—18世纪贝奥图克祖地的实际征服，1610特许又与1700法令不是一个事件。','royal_legal_claim_vs_indigenous_authority_vs_admin_site',['S79','S80']),
 ('T3C-ENGLAND-SCOTLAND',['tudor-wales-ireland-legal-restructuring-1536-1542'],['E6-T04','E6-T04-CONQUEST','E6-T04-GLENCOE','E6-T04-DARIEN'],['E18-F03','E18-F04','E18-F05','E18-F09'],'1603 crowns sharing (not parliaments); 1650s conquest and Restoration; 1698-1700 Darien; 1707 union; 1745-47 repression; 1792 sheep protests','不应以1650年代英军占苏格兰的短期政治体推导1700王室直接统治；Darien直到1700仍属独立王国公司企图。','different_sovereigns_by_year; no colonial_polygon_of_scotland_from_1652',['C2-DAR-2025','C2-UNION-ART','C2-SCO-SHEEP']),
 ('T3C-INDIGENOUS-POLITIES',['cabot-bristol-atlantic-voyages-1496-1498'],['E6-T05','E6-T06','E6-T09-CAR','E6-T10-ACADIA','E6-T10-HBC'],['E18-C01','E18-C17','E18-C21','E18-C25','E18-C27'],'15-16C European travel documents -> 17C charter enclaves -> 18C treaty/war/land deals','英王远距王室特许、地方港口与原住民共同使用空间三种对象不可互相覆盖；族群权力独立审史。','no_automatic_colonial_polygon_from_charter',['C2-US-NJ','C2-US-MA']),
 ('T3C-CARTOGRAPHY-UNCERTAINTY',['drake-panama-mule-train-raid-1572-1573','munster-plantation-land-grants-and-aftermath-1584-1589'],['E6-T04-DARIEN','E6-T12','E6-T09-PENNSYLVANIA'],['E18-F09','E18-B01','E18-C25'],'same programme visual convention 16C->17C->18C with stable old story IDs and case-specific event dates','16C GIS虚线军事活动参考包络不因17C海上或18C法律新事件自动变成历史实控边界；任何现代图示多边形不算历史地籍。','source-grounded_points_and_uncertainty_polylines_only',['SRC17'])
]
obj={'schema':'16c-17c-18c-bridges-assistant-C-v1','status':'research_only','input':'16C_stories_cartography_interaction_reference.zip / data/stories/index.json contains 39 published 16C stories; second-century data/stories/serial/index.json 36 stories','notes':['Only IDs actually found in original 16C reference ZIP used; some links are thematic antecedents, not causally proven identity.','No old event considered to continue after its historic battle, short occupation or passage ends.','18C successor IDs are from PR #289 research topics and remain unpublished.'], 'bridges':[]}
for id,ids16,ids17,ids18,years,continuity,rule,sources in bridges:
 obj['bridges'].append({'id':id,'story_ids_16c':ids16,'story_ids_17c':ids17,'topics_18c':ids18,'chronological_anchors':years,'continuity_hypothesis':continuity,'cartographic_rule':rule,'source_ids':sources,'audit_level':'topic_level_crosswalk_not_folio_verified'})
dump('TRIPLE_CENTURY_BRIDGES.json',obj)
# targeted evidence matrix, with each evidence link and exact claim limit
matrix=[
 ('DARIEN-EXIT-1700','1700-04-12','降约日期在2025/26学术研究中记为4月12日','C2-DAR-2025','peer_reviewed_text_search_excerpt','日历与Borland原卷待核','stop Scottish occupation by 1700 year-end; no Guna sovereignty claim'),
 ('DARIEN-1707-EQUIV','1707','£398085 10s是Union Equivalent法定总额','C2-UNION-ART','national_archives_teaching_art15','不得当全额达连净损失或净赔付','non_geographic_financial_event'),
 ('IRL-LAND-1702','1702','英格兰1 Anne c26管理爱尔兰已没收庄园产权','C2-IRL-1702','statute_extract','分条与地区产权待核','no_new_territory'),
 ('IRL-LAND-1704','1704','爱尔兰2 Anne c6另有购地、继承、监护限制','S53a','statute_transcription','法令批准日另核','non_spatial_legal_effect'),
 ('IRL-LAND-1778','1778','爱尔兰议会重要土地宗教限制松动','C2-IRL-1778','peer_reviewed_abstract','逐条原法待核','non_spatial_statutory_change'),
 ('IRL-LEGIS-1782','1782','英国撤1720法并修改Poynings','C2-IRL-1782','parliament_historical_guide','行政任命仍英方主导','constitutional_relation_change'),
 ('IRL-LEGIS-1783','1783','Renunciation Act确立爱尔兰内部立法权','C2-IRL-1783','official_memorandum_pdf_search_excerpt','原法未独立阅','constitutional_relation_change'),
 ('IRL-UNION-1801','1801-01-01','英爱合并1801才生效','C2-IRL-UNION','parliament_historical_guide','1800表决及法案与1801生效区分','no_1799_union'),
 ('SCO-CLEAR-1792','1792','Strathrusdale约200农人驱赶至多约10000羊','C2-SCO-SHEEP','scholarly_abstract','数值是文献估计非人口被驱逐总数','do_not_plot_fictitious_sheep_route'),
 ('AUS-1770-POSSESSION','1770-08-22','Cook日志记对东岸声索','C2-AU-COOKJ','transcribed_ship_journal','Kaurareg守护者对仪式实地发生有异议','claim_not_control_polygon'),
 ('AUS-1770-KAURAREG','1770-08-22','Kaurareg口述异议是对Cook版本的直接反证','C2-AU-COOK-CONTEST','first_nations_museum_interviews','不得凭一方单方描述伪造英国仪式现场','present_both_historical_accounts'),
 ('AUS-NORFOLK-1788','1788-03-06','King在Norfolk Island建立Kingston殖民站','C2-AU-NORFOLK','heritage_official_history','仅具名站点，地籍边线待核','site_point_only'),
 ('AUS-ROSEHILL-1788','1788-11-02','Rose Hill殖民内陆农业站建立','C2-AU-PARRA','municipal_historical_timeline','现代Parramatta城区≠1788实控面积','no_polygon'),
 ('AUS-ROSEHILL-IND','1788','该地是Burramattagal/Darug长期Country','C2-AU-PARRA-IND','local_government_first_nations_history','不将王室土地赠与当原住民让与','indigenous_territory_separately_recorded'),
 ('AUS-HAWKES-1795','1795-05','Paterson派兵62人，官方记7/8人死及5人俘','C2-AU-HAWKES','primary_letters_linked_by_indigenous_archive','殖民报告数无独立验尸/屠杀现场GPS','reported_casualty_sample_only'),
 ('AUS-HAWKES-1796','1796-02','Hunter令民兵互助但禁止随意杀害原住民','C2-AU-HAWKES','archival_document_linked','法令存在不表示贯彻','law_vs_real_violence'),
 ('AUS-PEMULWUY-1797','1797-03','Toongabbie官田袭击后Parramatta外围追击','C2-AU-PEMULWUY','university_biography','1794 Toongabbie不同战斗','two_distinct_places_no_unverified_line'),
 ('CONTROL-NJ-1702','1702-04-15/17','新泽西领主交政权与王室接受','C2-US-NJ-LAW','print_primary_sources_index','未交私人土地所有权，更未涉及Lenape主权','political_governance_not_land_polygon'),
 ('CONTROL-DE-1704','1704','下三郡独立议会，仍由Pennsylvania总督管理','C2-US-DE','state_archives_history','未因此变成独立殖民国家','same_crown_proprietor_distinct_assembly'),
 ('CONTROL-MA-1700-1709','1700-1709','马萨诸塞省总督与执行机构名单有年度记录','C2-US-MA','official_archives_governor_list','特许内新斯科舍等声索不随之成为实占','admin_center_attested_not_polygon'),
]
m={'schema':'assistant-C-claim-evidence-spatial-limit-v1','editorial_state':'research_only','evidence_count':len(matrix),'claims':[{'id':id,'date_or_range':dt,'claim_summary':claim,'source_ids':[sid],'access_type':depth,'audit_limit':limit,'map_eligibility':geom,'original_folio_personally_inspected':False} for id,dt,claim,sid,depth,limit,geom in matrix]}
dump('CLAIM_EVIDENCE_MATRIX.json',m)
# append dossier notes and source references per topic
notes={
'E18-F09.md':('达连1700年降约日与1707 Equivalent区分','新增参考：C2-DAR-2025（据Borland 1715引文的同评审研究），C2-DAR-CHRONO，C2-UNION-ART，C2-UNION-PAY。1700-02-13、03-15、03-28、04-12、04-13为学术论文所载日期；由于历史新旧历转换及原档原版未核，保留`day_reported_calendar_unconfirmed`；1700年末临时据点已撤离。1707年£398,085 10s为Equivalent总法定数额，包含公司投资者退偿及多项其他用途；1707年8月首笔款抵达。'),
'E18-F01.md':('1702前驱法令与1778产权限制逆转','C2-IRL-1702记录英格兰议会1 Anne c.26针对爱尔兰没收庄园受让、继承和租赁，先于1703/04爱尔兰2 Anne c.6。C2-IRL-1778（Cambridge同行评审摘要）支持1778爱尔兰王国议会土地限制首次重大松动。不得把1704全部禁制延续至1799不发生变化。'),
'E18-F02.md':('1720法律制度不是1800年不变','C2-IRL-1494说明Poynings法始于1494、持续并修改至1782。C2-IRL-1782核1779/80逐项贸易限制解除及1782英国撤1720法、爱尔兰议会立法/终审权变化；C2-IRL-1783为Oireachtas官方法律备忘录，1783再作确认。Ireland 1782后仍由英方委任Lord Lieutenant和Chief Secretary。'),
'E18-F03.md':('1707立法支付而非达连仍占领','C2-UNION-ART给第15条£398,085 10s的多重财政用途；C2-UNION-PAY见1707-08首笔Equivalent资金到达爱丁堡。1707一体化是大不列颠王国（不含爱尔兰议会合并）。'),
'E18-F05.md':('1792年可以落年但不可画虚构清场边界','C2-SCO-SHEEP与C2-SCO-PROTEST记录Strathrusdale/Ross-shire反牧羊地权抗争，约200农人，最多约10,000羊为摘要所载估计；并非被驱逐人数。历史学会认定早期清场始于1780年代，Sutherland 1809—21是19世纪另段。'),
'E18-F06.md':('1798国家档案馆17件原始文书目录','C2-IRL-1798-ARCH：5月23/24日Kildare/Meath/Dublin，5月27日Oulart当地报告，6月6日Wexford起义军命令，6月21日Vinegar Hill，8月23日Killala登陆，9月25日Ballina关于Killala军情信。注意书信写作日与被描述军事行动日不同；未读取每份纸质原件全部影像。'),
'E18-F07.md':('1799提案失败至1801正式合并分界','C2-IRL-UNION英国议会叙述：1799-01-24议会反对、1800-03-28爱尔兰两院接受条款、1800-08-01王室批准、1801-01-01生效。禁止在1799图层上写已并入UK。'),
'E18-D01.md':('Cook日记与Kaurareg First Nations反证并置','C2-AU-COOKJ是National Museum Australia历史航海日记逐日转录；C2-AU-COOK-CONTEST澳大利亚博物馆中Kaurareg传统守护者质疑Cook真的登上Tuined升旗。英王宣示有日记文字证据，但对本岛具体仪式史实出现冲突。不存在由此得到东海岸真实实控Polygon的根据。'),
'E18-D02.md':('第一舰队数量口径与航路审查','C2-AU-FIRSTFLEET为State Library NSW收藏的原始日志索引和航次；C2-AU-NSW-FLEET报759人受遣送、13名儿童，而州图书馆另说750—780犯人；两个统计不能相加，亦不能把起点与悉尼湾直线当实际GPS航路。'),
'E18-D03.md':('Norfolk Island与Rose Hill分站建置','C2-AU-NORFOLK/C2-AU-PKJ：1788-03-06 King率队在Norfolk Island Kingston/Arthurs Vale建殖民据点。C2-AU-PARRA：1788-11-02 Rose Hill建内陆耕作站；C2-AU-PARRA-IND：Burramattagal/Darug Country前殖民自主与资源权。二地均未取得1788实测管理边界，坐标暂为null。'),
'E18-D06.md':('1795年Hawkesbury军队镇压原档线索','C2-AU-HAWKES：1795-05当局派62人、官员报告七或八名原住民被杀及五名俘获；1796-02 Hunter下令自卫同时禁止随意杀害。军方报告的7/8死是官员自述而非独立伤亡普查，DOC5887、DOC5882、DOC2907需翻原档。'),
'E18-D07.md':('地方社群多样性','C2-AU-PEMULWUY/ C2-AU-PARRA-RES：Pemulwuy领导Bidjigal抗拒农耕扩张，1697〔更正：1797〕在Toongabbie袭击官田后于Parramatta外围被追击受伤；跨到1801通缉、1802被杀是19世纪确切续篇。'),
'E18-D09.md':('1797 Toongabbie与Parramatta连续行动','C2-AU-PEMULWUY澳洲大学传记记录1797年3月Toongabbie农田袭击及后续Parramatta外围追杀、治疗后逃脱；与1794 Toongabbie战斗不可并为同一场，也不能为两点编造战斗轨迹。'),
'E18-D10.md':('1788—99逐步建站、授地、开垦与暴力','City of Parramatta档案C2-AU-PARRA：1789-11-01 James Ruse、1791-03-30 Experiment Farm土地授予、1791-06-04改名；C2-AU-HAWKES：1793/94 Hawkesbury农业占地、1794追认地契、1799居民记录1,008。所有具体农庄面积与边界必须另查历史契据。'),
}
# fix calendar typo programmatically
notes['E18-D07.md']=(notes['E18-D07.md'][0],notes['E18-D07.md'][1].replace('1697〔更正：1797〕','1797'))
for file,(title,body) in notes.items():
 p=P/'TOPIC_DOSSIERS'/file
 with p.open('a',encoding='utf-8') as f:f.write('\n\n## 第二轮追加｜'+title+'\n\n'+body+'\n\n更多逐项论点、来源精度和地图禁忌见`../ROUND2_RESEARCH_NOTES.md`、`../CLAIM_EVIDENCE_MATRIX.json`。\n')
# special continuity handoff append
continuity={'1700_DARIEN_OLD_STORY.md':'C2-DAR-2025补出1700年2、3、4月候审时间链，儒略/公历尚不裁定；1707 Equivalent法定金额独立案，不延长1700据点。','IRELAND_LAND_1691_1704_1798.md':'1702英格兰针对Irish forfeited estates的1 Anne c26与1704爱尔兰2 Anne c6必须分开；1778地权部分放开、1782/83法权改变、1798起义及1801正式联合各自新节点。','SCOTLAND_1700_1746_1780.md':'1700达连军事退出；1707政治联合；1792 Year of the Sheep地方抗议是具年事件，1809–21 Sutherland属19C。','CAROLINA_LENAPE_NY.md':'额外跨世纪对照：New Jersey 1702-04-15/17领主交政权但产权不转；Delaware Lower Three Counties 1704独立议会但仍由Penn governor管理；上述只是新政治关系断点，进一步调查交助手1。'}
for file,body in continuity.items():
 with (P/'TOPIC_DOSSIERS'/file).open('a',encoding='utf-8') as f:f.write('\n\n## 2026-11-08第二轮补核\n\n'+body+'\n')
# manual csv to allow project integration into dossiers source citations
with (P/'CLAIM_EVIDENCE_MATRIX.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=['id','date_or_range','claim_summary','source_ids','access_type','audit_limit','map_eligibility']);w.writeheader()
 for q in m['claims']:w.writerow({k: (';'.join(q[k]) if k=='source_ids' else q[k]) for k in w.fieldnames})
print('round2 dossier updates',len(notes)+len(continuity),'bridges',len(obj['bridges']),'claims',len(matrix))
