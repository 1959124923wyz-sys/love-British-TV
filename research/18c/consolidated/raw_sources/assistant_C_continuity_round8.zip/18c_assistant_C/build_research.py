import json,csv,re,os,zipfile,hashlib,datetime
from pathlib import Path
root=Path('/mnt/data/18c_assistant_C');(root/'TOPIC_DOSSIERS').mkdir(exist_ok=True);(root/'_inputs').mkdir(exist_ok=True)
def out(name,obj):
 p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');return p
def md(name,body):
 p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(body,encoding='utf-8');return p
# Research provenance: original 17c manifest and PR #289 handoff inspected through the connected GitHub reader 2026-11-08.
pr='https://github.com/1959124923wyz-sys/love-British-TV/blob/492a153aa181517edea47877e6b7c83951412e43/'
main='https://github.com/1959124923wyz-sys/love-British-TV/blob/main/'
urls={
'S01':('UK Parliament','Acts of Union 1707 overview','https://www.parliament.uk/about/living-heritage/evolutionofparliament/legislativescrutiny/act-of-union-1707/'),
'S01a':('UK Parliament','1707 exact dates','https://www.parliament.uk/about/living-heritage/evolutionofparliament/legislativescrutiny/act-of-union-1707/key-dates/'),
'S19':('National Museum of Australia','Cook claiming east coast 1770','https://www.nma.gov.au/defining-moments/resources/cook-claims-australia'),
'S19a':('National Museum of Australia','Possession Island First Nations context','https://www.nma.gov.au/exhibitions/endeavour-voyage/bedanug-thunadha-bedhan-lag-tuidin-possession-island'),
'S20':('National Museum of Australia','Pemulwuy 1790–1802','https://www.nma.gov.au/defining-moments/resources/pemulwuy'),
'S20a':('City of Ryde','Pemulwuy 1797 Toongabbie to Parramatta','https://www.ryde.nsw.gov.au/Finding-Bennelong/Glossary/Pemulwuy'),
'S21':('Towards Truth','Initial confrontation; Arabanoo, Colbee, Bennelong','https://towardstruth.org.au/themes/country/dispossession/120-frontier-wars/sub0194-initial-confrontation-and-resistance'),
'S22':('National Museum of Australia','Smallpox epidemic of April 1789; origin contested','https://www.nma.gov.au/defining-moments/resources/smallpox-epidemic'),
'S22a':('National Museum of Australia','Smallpox classroom source and provenance dispute','https://digital-classroom.nma.gov.au/defining-moments/smallpox-epidemic-0'),
'S23':('National Army Museum','Irish Rebellion of 1798','https://www.nam.ac.uk/explore/irish-rebellion-1798'),
'S37':('National Museum of Australia','Convict transportation peaks; First Fleet 751 estimate','https://www.nma.gov.au/defining-moments/resources/convict-transportation-peaks'),
'S37a':('State Library NSW','First Fleet dates and convict count range','https://guides.sl.nsw.gov.au/convicts-bound-for-australia/first_fleet'),
'S37b':('National Museum of Australia','First Fleet 26 Jan 1788 settlement','https://www.nma.gov.au/defining-moments/resources/convict-cargo'),
'S37c':('National Museum of Australia','Sydney Cove first settlement and rights context','https://digital-classroom.nma.gov.au/defining-moments/first-fleet-arrives-sydney-cove'),
'S38':('Historic England','Slave economy research audit','https://historicengland.org.uk/research/results/reports/8203/TheTransatlanticSlaveEconomyandEnglandsBuiltEnvironmentAResearchAudit'),
'S40':('Scottish History Society','Highland Clearances c1750–1900, wave 1780–1825','https://scottishhistorysociety.com/the-highland-clearances/'),
'S40a':('Historic Environment Scotland','First wave and tenants','https://blog.historicenvironment.scot/2025/04/the-highland-clearances/'),
'S53':('Irish Historical Studies / Cambridge','Making of penal law 2 Anne c6, 1703–4','https://www.cambridge.org/core/journals/irish-historical-studies/article/abs/making-of-a-penal-law-2-anne-c6-17034/BFF887B070C7357A2D7A26C2AA2E9E45'),
'S53a':('University of Minnesota Law Library','Transcription Penal Law 2 Anne c6 sections','https://librarycollections.law.umn.edu/archive/irishlaws/chron-anne.html'),
'S53b':('Irish Historical Studies / Cambridge','Catholic inheritance: interpretation of 2 Anne c6','https://www.cambridge.org/core/journals/irish-historical-studies/article/abs/catholic-inheritance-under-the-penal-laws-in-ireland/592D53B4F4EB902DE81AC4A37ECC1EDC'),
'S61':('UK Parliament','1799 Union motion failed; 1800 passed; 1801 effected','https://www.parliament.uk/about/living-heritage/evolutionofparliament/legislativescrutiny/parliamentandireland/overview/parliamentary-union/'),
'S61a':('UK Parliament','Irish sovereignty, 1720 Declaratory Act','https://www.parliament.uk/about/living-heritage/evolutionofparliament/legislativescrutiny/parliamentandireland/overview/constitutional-differences/'),
'S61b':('UK Parliamentary Archives','1800 Union Act archival catalogue','https://archives.parliament.uk/collections/getrecord/GB61_HL_PO_PU_1_1800_39and40G3n241'),
'S72':('National Museums Scotland','Darien, 1698–1700; January assault, surrender, equivalent','https://www.nms.ac.uk/discover-catalogue/the-darien-scheme'),
'S73':('South Carolina Encyclopedia','Yamasee War 1715','https://www.scencyclopedia.org/sce/entries/yamassee-war/'),
'S74':('Virginia Center for Digital History','Virginia 1705 laws','https://www2.vcdh.virginia.edu/gos/laws1700-1750.html'),
'S75':('Historical Society of New York Courts','1741 alleged slave conspiracy trials','https://history.nycourts.gov/case/slave-conspiracy-trials/'),
'S76':('Haverford College','Walking Purchase archival ledger','https://findingaids.library.upenn.edu/records/HAVERFORD_HC.MC.950.175'),
'S77':('Bucks County','1737 Walking Purchase local history','https://www.buckscounty.gov/1567/Walking-Purchase'),
'S78':('Journal of British Studies / Cambridge','Bencoolen colonial presidency 1685–1825','https://www.cambridge.org/core/journals/journal-of-british-studies/article/making-and-unmaking-of-a-presidency-envisioning-empire-in-british-bencoolen-16851825/4C0CA8C6BF1E88181DA0CEACBC33C47A'),
'S79':('Memorial University Newfoundland','1699 Newfoundland Fishery Act transcription','https://www.heritage.nl.ca/lawfoundation/articles/doc2_1699william.html'),
'S80':('Newfoundland Provincial Court','1729 Courts chronology','https://www.court.nl.ca/provincial/about/court-profile/historical-overview/'),
'S81':('Manitoba Historical Society','HBC 1713,1715,1774 timeline','https://www.mhs.mb.ca/docs/features/timeline.shtml'),
'S82':('UK Parliament','Royal African Company monopoly altered in 1698','https://www.parliament.uk/about/living-heritage/transformingsociety/tradeindustry/slavetrade/overview/parliament-regulates-the-africa-trade/'),
'S83':('NYC Commission on Human Rights','1712 NYC enslaved population and revolt','https://home4.nyc.gov/assets/cchr/downloads/pdf/publications/AntiBlackRacism_Report.pdf'),
'S84':('Smithsonian Magazine','1736 Antigua case contested','https://www.smithsonianmag.com/history/antiguas-disputed-slave-conspiracy-of-1736-117569/'),
'S85':('Manitoba Historical Society','Hudson Bay posts and 1713 restitution','https://www.mhs.mb.ca/docs/transactions/3/princeofwalesfort.shtml'),
'S86':('University of Pennsylvania','Lenape land background','https://dia.upenn.edu/en/content/LeechM001/'),
'S88':('National Museums Scotland','Scotland and transatlantic slave system','https://www.nms.ac.uk/discover-catalogue/scotland-and-the-transatlantic-slave-system'),
'NMS-TARTAN':('National Museums Scotland','1747 civilian male clothing restriction, repeal 1782','https://www.nms.ac.uk/discover-catalogue/jacobites-and-tartan-symbolism-and-style'),
'NJ-1702':('New Jersey government','East West Jersey civil authority surrendered 1702','https://www.nj.gov/nj/about/history/short_history.shtml'),
'NSW-1794':('National Museum of Australia','Chronology of Hawkesbury 1794','https://www.nma.gov.au/defining-moments/defining-moments-timeline'),
'SRC17':('GitHub project PR #289','36 old-stories continuity registry',pr+'research/18c/CROSS_CENTURY_STORY_CONTINUITY.json'),
'SRC17INDEX':('GitHub project main','17th century story manifest',main+'data/stories/serial/index.json'),
'SRCSEED':('GitHub project PR #289','27 1699 schematic footprint candidates',pr+'research/18c/TRANSITION_1699_1700_RESEARCH_SEED.json'),
'SRCTOPICS':('GitHub project PR #289','18th century 105-topic master register',pr+'research/18c/MAJOR_TOPICS.json'),
'SRCSTD':('GitHub project main','Map first cartography standard',main+'docs/MAP_FIRST_CARTOGRAPHY_STANDARD.md'),
'SRCCONTROL':('GitHub project main','Territory continuity playbook',main+'docs/RESEARCH_TERRITORY_CONTINUITY_PLAYBOOK.md'),
}
sources=[{'id':k,'institution':v[0],'title':v[1],'url':v[2],'access_level':('repository_file_read' if k.startswith('SRC') else 'first_party_online_transcription_or_primary_quote' if k in ['S19','S53a','S79','S21'] else 'peer_reviewed_academic_page' if k in ['S53','S53b','S78'] else 'institutional_summary_or_guide'),'original_manuscript_personally_inspected':False,'reviewed_online_on':'2026-11-08','note':'Original manuscript / archival folios not inspected; webpage is the evidence tier for assertions.'} for k,v in urls.items()]
out('SOURCE_REGISTRY.json',{'schema':'assistant-C-research-sources-v1','research_only':True,'primary_registry':pr+'research/18c/SOURCE_REGISTRY.json','source_count':len(sources),'sources':sources})
# Full stable identifiers preserved; publication-window end is NEVER presumed to be actual historical endpoint.
old=[
('E6-T01','Ulster plantation 1603–1641','institutional_continuation',1641,None,'F01 F06','SRC17 S53','王室殖民授地历史阶段止于1641研究窗；1703/04新罚法及1798革命不同事件'),
('E6-T02','Ireland conquest and land debt 1641–1670','consequences_only',1670,1658,'F01 F06','SRC17 S53','1641-58战事结束；产权债权与宗教法及1798起义另述'),
('E6-T03','Ireland land / Williamite parent','parent_program',1699,None,'F01 F06','SRC17 S53','尚研究母题；不能转已发表'),
('E6-T03-LAND-1642-1698','Ireland land dispossession 1642–1698','institutional_continuation',1698,None,'F01 F06','SRC17 S53 S53a','产权结果及1704法制继续；1698仅旧文章终点'),
('E6-T03-WILLIAMITE-WAR','Williamite War 1689–91','consequences_only',1691,1691,'F01 F06','SRC17 S53','1691军事结束，战后压制有新法律年'),
('E6-T04','Scotland independent polity parent','parent_program',1699,None,'F09 F03 F04','SRC17 S72 S01','苏格兰独立到1707-05-01；达连同时含1699-1700战斗'),
('E6-T04-CONQUEST','Cromwellian Scotland conquest 1650–52','consequences_only',1652,1660,'F04','SRC17 S01','1650–52征服战争与1652–60共和驻治；1700不是继续占领'),
('E6-T04-GLENCOE','Glencoe 1692 and enquiry 1695','consequences_only',1695,1695,'F04','SRC17','1692屠杀已结束，1695问责另事；1745/46是新阶段'),
('E6-T04-DARIEN','Darien 1695–99 old article','direct_cross_boundary_episode',1699,1700,'F09 F03','S72 S88 SRC17','1699-11-30第二批抵达；1700-01进攻Toubacanti；1700年投降撤离；1707仅金融政治余波'),
('E6-T05','Virginia Powhatan wars and hereditary slavery','institutional_continuation',1677,None,'C22 C17','SRC17 S74','1600年代战争结束，1705奴役法律是新事件；不得延长战争'),
('E6-T06','New England Pequot & Metacom wars','consequences_only',1679,1679,'C12 C17','SRC17','战争已结束，18C新战争与法律分列'),
('E6-T07','Barbados/E Caribbean parent','parent_program',1699,None,'A06 A14 A15 A21','SRC17 S84','17C法规母题research_only'),
('E6-T07-BARBADOS','Barbados 1625–92 slavery laws','institutional_continuation',1692,None,'A06 A07','SRC17','奴役法及种植园在1692后继续，不能复制每年事件'),
('E6-T07-LEEWARD','Leewards 1623–99','institutional_continuation',1699,None,'A21 A14 A15','SRC17 S84','殖民点延续；1736安提瓜案为独立嫌疑而非自动既定起义'),
('E6-T08','Jamaica Maroon & slavery 1654–99','institutional_continuation',1699,None,'A05 A11 A12','SRC17','英国沿岸行政与山区马龙自治并存；1739/1795/1796独立节点'),
('E6-T09','NY Carolina parent','parent_program',1699,None,'C21 C23 C24 C25','SRC17','领主制、地权和反抗研究母题未完成'),
('E6-T09-NE-DOMINION','Dominion of New England 1686–92','consequences_only',1692,1692,'C13 C17','SRC17','1689崩解，1692继任体制；不能在1700继续该自治领'),
('E6-T09-PENNSYLVANIA','Pennsylvania deeds 1681–96','institutional_continuation',1696,None,'C25 C14','SRC17 S76 S77','领主殖民继续，1737步行购买新欺诈性交易；有原住民主权'),
('E6-T09-CAR','Carolina proprietary slavery 1661–99','institutional_continuation',1699,None,'C21 C14','SRC17 S73','1715亚马西新战争，不可自动当领主全境实控'),
('E6-T09-NY','New Netherland/NY 1609–91','institutional_continuation',1691,None,'C23 C24','SRC17 S83 S75','1674英荷换旗已经发生，1712/1741属新奴役体制事件'),
('E6-T10','Hudson Bay Acadia Newfoundland parent','parent_program',1699,None,'C01 C02 C26 C27','SRC17 S79 S81','三海区拆成逐堡逐点政治核查'),
('E6-T10-QUEBEC-KIRKE','Quebec Kirke occupation 1629–32','consequences_only',1632,1632,'C11','SRC17','1632归法国，1700绝对不可继续英国占领'),
('E6-T10-ACADIA','Acadia Mi’kmaq and imperial rivalry','institutional_continuation',1699,None,'C01 C02 C03 C07 C08 C09 C10','SRC17','1690英袭无持续驻军，1710 Port Royal新占领、1713条约另述'),
('E6-T10-HBC','Hudson’s Bay Company 1668–99','institutional_continuation',1699,None,'C27','S81 S85 SRC17','公司特许继续但堡垒1690年代多次易手、1713部分返还；鲁珀特地不是实控'),
('E6-T10-NEWFOUNDLAND','Newfoundland Beothuk and fishery 1600–99','direct_cross_boundary_episode',1699,None,'C26 C20','S79 S80 SRC17','1699法律部分款1700-03-25生效，同一法令行动；不推断整岛实际治理'),
('E6-T11','Atlantic enslavement parent','parent_program',1699,None,'A01 A02 A09','SRC17','跨洋制度与人口权利问题母题'),
('E6-T11-VOYAGES','Atlantic enslaved voyages 1600–99','institutional_continuation',1699,None,'A01 A02 A09','SRC17','不跨世纪复制17C人数统计分母'),
('E6-T12','East India Company 1600–1699','institutional_continuation',1699,1874,'E15 B01 B03 B06 B07 B10','SRC17 S78','旧世纪文章截止1699，贸易公司跨后世；母公司长期存续≠每地堡垒永久实控'),
('E6-T13','Royal African Company 1618–1698','institutional_continuation',1699,None,'A03 A01 E10','S82 SRC17','1698贸易垄断改变，奴役活动没有在1698结束'),
('E6-T14','Navigation acts war parent','parent_program',1699,None,'A02 C15 C17','SRC17','三次英荷战争已结束，法令制度持续另核'),
('E6-T14-NAV','Navigation acts and Anglo-Dutch wars','institutional_continuation',1699,None,'A02 C15 C17','SRC17','1651/1660等制度与17C战争分别描述'),
('E6-T15','Fiscal-state trade war finances','institutional_continuation',1699,None,'A02 A04 B08','SRC17','1694银行债权、18C国家战争财政仍需单独证据'),
('E6-T16-SURINAME','English Suriname 1650–1668','closed_earlier_no_same_event',1668,1668,'','SRC17','1668后非英属殖民据点，不能继续画英国实控'),
('E6-T16-PROVIDENCE','Providence Island 1630–1641','closed_earlier_no_same_event',1641,1641,'','SRC17','1641西班牙占领，1700不是英国殖民岛'),
('E6-T16-ATLANTIC-ISLANDS','Bermuda and Bahamas 1609–95','institutional_continuation',1695,None,'A22','SRC17','百慕大据点与巴哈马部分岛屿需逐岛核，不把特许当控制'),
('E6-T17-AFRICAN-FORTS','African forts Cape Coast Tangier 1653–84','institutional_continuation',1684,None,'E10 A01','SRC17 S82','丹吉尔1684英方撤出；海岸角城堡与RAC贸易据点另行续核'),
]
audit=[]
for id,title,kind,win,hend,nxt,ss,note in old:
 audit.append({'previous_story_id':id,'previous_title_short':title,'previous_research_end_year':win,'historical_endpoint_year':hend,'historical_endpoint_status':'source_attested_or_registered' if hend is not None else 'not_proven_single_end_year','continuation_kind':kind,'findings':note,'new_18c_topic_ids':['E18-'+x for x in nxt.split()] if nxt else [],'source_ids':ss.split(),'year_1700_territorial_control_verified':False,'geometry_auto_carry_allowed':False,'research_state':'screened_with_topic_level_sources; site-by-site primary audit still required','archive_reference':pr+'research/18c/CROSS_CENTURY_STORY_CONTINUITY.json'})
out('CROSS_CENTURY_AUDIT.json',{'schema':'17c-18c-continuity-audit-assistant-C-v1','date':'2026-11-08','expected_count':36,'observed_count':len(audit),'counts_by_kind':{k:sum(a['continuation_kind']==k for a in audit) for k in sorted(set(a['continuation_kind'] for a in audit))},'note':'Research window end is separate from historical endpoint. Null is deliberately unproved, not continuous to 1799. Only direct_cross_boundary_episode includes Darien military action and 1699 Newfoundland Act partial commencement. No archived polygon auto-carried.','entries':audit})
print('SAVED stage 1 sources',len(sources),'audit',len(audit),flush=True)
# 1699 references: these labels are schematic old-layer SEEDS, not 27 verified jurisdictions.
seed=[
('CAROLINA-PAPER','1665年卡罗来纳扩展特许：29—36.5度向太平洋','charter_claim','English Carolina proprietors','C21','Crown charter far exceeds settlements and Indigenous sovereignty'),
('RUPERT-PAPER','1670年哈德孙湾公司鲁珀特地：浩大流域纸面声索','company_charter_claim','Hudson’s Bay Company','C27','Watershed charter != direct control; inspect named actual bay forts and French garrisons'),
('PENN-PAPER','1681年宾夕法尼亚领主特许：远超早期费城聚落','charter_claim','Penn proprietary province','C25','Lenape rights persist; parcel deeds separately'),
('ULSTER','1609年阿尔斯特六郡王室殖民授地计划','settlement_land_legal_regime','Kingdom of Ireland; Protestant landowners','F01','Original grants & possession vary by estate; no six-county fill'),
('IRELAND','1652—1699年英格兰征服后爱尔兰王国政权的大范围控制','dependent_kingdom_crown_government','Kingdom of Ireland under same monarch as England','F01','Dublin-centered English interest and distinct Irish parliament; not modern UK'),
('JAMAICA','1655年后英格兰占领牙买加：全岛殖民声索与马龙抵抗','colonial_administration_and_autonomous_maroon','English colony and Maroon communities','A05','Government sites known; Maroon autonomy and indigenous communities not erased'),
('BARBADOS','1627年后巴巴多斯殖民地：全岛经营与糖园奴役','colonial_administration','English Barbados colony','A06','Settled colony ≠ every plot surveyed'),
('BERMUDA','1612年后百慕大：英格兰公司与王室海岛殖民','colonial_administration','English Bermuda polity','A22','Check documented islands and garrisons'),
('BAHAMAS','1670年巴哈马领主特许：群岛广泛声索而非实际逐岛占领','charter_claim','Carolina proprietors; Bahamas settlements','A22','Piracy/disrupted settlements and unreached islands; no archipelago fill'),
('VIRGINIA','1625年后王室弗吉尼亚殖民地：切萨皮克及内陆宽幅参考','colonial_administration_with_indigenous_autonomy','English Virginia government','C22','Royal administration at towns; Powhatan/other nations hold territories'),
('MARYLAND','1632年马里兰领主特许：切萨皮克湾与波托马克河间领地','charter_claim_and_settlement','Maryland proprietary/crown','C17','1691 royal government stage to check; Indigenous land rights persist'),
('CONNECTICUT','1662年康涅狄格王室特许：东岸至南海（太平洋）纸面声索','charter_claim','Connecticut colony','C17','Pacific-reaching claim not actual English possession'),
('NEWYORK','1674年后恢复的英属纽约：区别1673—1674荷兰收复期','colonial_administration','English New York government','C23','Town/control confirmed earlier; Iroquois/Haudenosaunee and Lenape autonomous'),
('NEWFOUNDLAND','1610年后英格兰纽芬兰殖民特许：整岛声索与英法争夺','mixed_seasonal_fishery_and_settlement','English fishery communities and French Plaisance','C26','Coastal fishing settlements, France & Beothuk rights distinct'),
('LEEWARD','1632年后背风群岛英格兰殖民据点：圣基茨、尼维斯、安提瓜、蒙特塞拉特','multiple_discrete_island_colonies','English island colonists, French interests, Kalinago','A21','Islands differ; do not conflate with St Vincent control'),
('STHELENA','1659年后东印度公司圣赫勒拿岛：南大西洋补给殖民地','company_governed_island_site','English East India Company','B01','Trading company administration of island, historical coast reference not boundary'),
('MASSACHUSETTS','1692年后马萨诸塞湾省：新特许下的普利茅斯、缅因及部分阿卡迪亚声索','charter_claim_and_admin_core','Massachusetts province','C17','Acadia claims exceed Port Royal control; Indigenous sovereignties'),
('RHODEISLAND','1663年罗得岛与普罗维登斯殖民地特许：纳拉甘西特湾','colonial_administration','Rhode Island colonial government','C17','Coastal English towns not entire Native interior'),
('CAPECOAST','1665年后英方海岸角城堡：加纳黄金海岸奴隶贸易据点','fort_trade_post','Royal African Company at Cape Coast Castle','A03','Castle and adjacent foothold not Gold Coast entire region'),
('BOMBAY','1668年后东印度公司孟买岛：王室授予的港口司法和军事管辖','company_admin_core','East India Company at Bombay','B01','Harbour fort island rights not neighbouring polities'),
('FORTSTGEORGE','1640年后东印度公司圣乔治堡：马德拉斯沿海商馆与城镇','fort_trade_post','East India Company at Fort St George','B01','Coromandel rulers political authority continues beyond site'),
('NEWJERSEY','1674—1699年英属新泽西领主殖民省：东、西泽西授地与政治分治','proprietary_administration','East and West Jersey proprietors','C17','1702 formally surrender governance; 1699 parcels uncertain'),
('DELAWARE','1682—1699年佩恩的特拉华下三郡：与宾夕法尼亚并行的殖民领主辖区','proprietary_administration','Lower Counties on Delaware','C17','Separate institutions and Indigenous title, county parcel lines unverified'),
('NEWHAMPSHIRE','1692—1699年复设新罕布什尔王室殖民省：西部界线不明','colonial_administration','Royal Province of New Hampshire','C17','Crown title vs New England local land governance'),
('DARIEN','1698—1699年苏格兰达连殖民计划：巴拿马加勒比海岸与新爱丁堡','short_lived_scottish_fort','Company of Scotland, independent Kingdom of Scotland','F09','Second expedition 1699-11-30, surrendered and exited 1700; Guna sovereignty remains'),
('CALCUTTA','1690—1699年东印度公司苏塔纳蒂—加尔各答三村商馆与1698扎明达里','company_land_revenue_rights','English East India Company within Mughal Bengal','B01','Zamindari revenue management 3 named villages not sovereign Bengal'),
('BENCOOLEN','1685—1699年英东印度公司本古伦商站与约克堡：苏门答腊西岸','company_fort_trade_post','English East India Company & local Sumatran polities','E15','1719 attack abandonment and 1723 return future transition'),
]
trans=[]
for key,label,kind,actor,topic,caveat in seed:
 annual=[]
 for y in range(1700,1710):
  baseline='not_independently_verified_for_year_end'
  detail='No year-specific garrison, tax administration or boundary research establishes this 1699 schematic footprint as controlled land in this particular year.'
  ss=['SRCSEED']
  if key=='DARIEN':
   baseline='abandoned_by_year_end_source_attested' if y>=1700 else baseline
   detail='1700 second Scottish expedition surrendered to Spanish force and departed. No Scottish fort at the 1700 year-end; Guna land rights retained.'
   ss=['S72','S88']
  elif key=='NEWJERSEY' and y>=1702:
   baseline='royal_governance_change_documented_at_province_level_not_boundary' 
   detail='In 1702 East and West Jersey proprietors ceded governmental authority to Crown; title/private interests and Lenape rights require separate inquiry.'
   ss=['NJ-1702']
  elif key=='IRELAND':
   baseline='constitutional_relation_documented_not_territorial_geometry' if y>=1707 else 'pre_1707_distinct_kingdom_government_context'
   detail='Ireland remains a separately constituted kingdom with Dublin parliament; from 1707 Crown shared with Great Britain; no 1801 UK status in 1700–09.'
   ss=['S01','S61a']
  elif key=='CALCUTTA':
   baseline='inherited_pre_1700_revenue_rights_unchecked_annual_implementation'
   detail='1698 three-village zamindari in Mughal Bengal; annual local tax exercise, military perimeter and legal jurisdiction separately unverified.'
   ss=['SRC17']
  elif key in ('BOMBAY','FORTSTGEORGE','CAPECOAST','STHELENA'):
   baseline='site_documented_pre_1700_but_annual_garrison_unsupported'
   detail='17c specific fort/island administrative site; 1700–09 annual tenure and changes require original company correspondence/fort register.'
   ss=['SRC17']
  annual.append({'year':y,'year_end_evidence_state':baseline,'note':detail,'source_ids':ss,'verified_historical_polygon':False,'known_end_year':1700 if key=='DARIEN' else None,'last_attested_year':1700 if key=='DARIEN' else (1702 if key=='NEWJERSEY' and y>=1702 else None)})
 trans.append({'stable_id':'C-TRANS-'+key,'prior_1699_reference_label':label,'reference_class':kind,'actor_at_1699':actor,'associated_topic_id':'E18-'+topic,'caution':caveat,'geography_type':'reference_only_unverified_polygon','historical_boundary_confirmed':False,'prior_layer_is_proof_of_control':False,'year_end_reviews':annual,'research_depth':'preliminary categorical screening; explicit unknown where no dated control evidence'})
# separately warranted relationships excluded from old 27 diagram: true historical actors vs abstract footprint
extra=[
 {'id':'C-POL-ENGLAND-SCOTLAND','entity':'Kingdom of Scotland','year_start':1700,'year_end':1706,'class':'independent_kingdom_shared_monarch','then':'Kingdom of Great Britain','change_year':1707,'source_ids':['S01','S01a'],'geom':'not supplied'},
 {'id':'C-POL-GREATBRITAIN','entity':'Kingdom of Great Britain','year_start':1707,'year_end':1709,'class':'united_kingdom_after_acts_of_union','then':None,'change_year':1707,'source_ids':['S01','S01a'],'geom':'not supplied'},
 {'id':'C-POL-GUNA','entity':'Guna polities around Darien','year_start':1699,'year_end':1700,'class':'indigenous_autonomy_and_diplomacy','then':'requires localized sources after Scottish withdrawal','change_year':1700,'source_ids':['S72','SRC17'],'geom':'not supplied'},
 {'id':'C-POL-IRELAND','entity':'Kingdom of Ireland','year_start':1700,'year_end':1709,'class':'separate_dependent_kingdom_with_its_own_parliament','then':'1801 later political union NOT active','change_year':None,'source_ids':['S61a'],'geom':'not supplied'},
 {'id':'C-POL-ACADIA','entity':'French Port Royal and Mi’kmaq territories','year_start':1700,'year_end':1709,'class':'French_military_site_vs_Mikmaq_autonomous_lands','then':'1710 Port Royal capture /1713 treaty outside current 1700–09 window','change_year':1710,'source_ids':['SRC17'],'geom':'not supplied'},
 {'id':'C-POL-NEWFOUNDLAND','entity':'French Plaisance, English fisheries and Beothuk country','year_start':1700,'year_end':1709,'class':'competing_footholds_seasonal_economy_indigenous_sovereignty','then':'1713 territorial treaty after current window','change_year':1713,'source_ids':['S79','SRC17'],'geom':'not supplied'},
 {'id':'C-POL-HBC','entity':'HBC trading posts and French fort competition','year_start':1700,'year_end':1709,'class':'site_specific_company_presence_requires_fort_by_fort_check','then':'1713 fortress handover after 1709; not all watershed sovereignty','change_year':1713,'source_ids':['S81','S85'],'geom':'not supplied'}]
out('CONTROL_TRANSITIONS_1699_1709.json',{'schema':'1699-1709-annual-continuity-screen-v1','editorial_state':'research_only','reference_seed_count':27,'all_candidates_years':list(range(1700,1710)),'comparison_warning':'No 1699 diagram is assumed to be verified historical territory. Repeated unknown in years means verification outstanding, not proven control or proven absence. Clear 1700 end at Darien and 1702 New Jersey constitutional change are specific evidence exceptions. 1707 parliamentary union is constitutional transition; it does not create extra overseas polygons.','previous_source':pr+'research/18c/TRANSITION_1699_1700_RESEARCH_SEED.json','candidates':trans,'additional_distinct_political_relations':extra,'qa_open_issues':['Annual garrison registers/administrative minutes needed at Cape Coast, Bombay, Madras, HBC bay forts, Bencoolen','1699 footprints should be mapped by stable site IDs not old illustrative polygon IDs','No 1707 pre-existing Scotland British territorial color before 1 May','1699/1700 Newfoundland statute effective date not proof of Beothuk territory control','1699 New Jersey proprietary power changes in 1702; do not reuse same political subcategory']})
print('SAVED stage 2 annual control candidates',len(trans),'annual checks',len(trans)*10,flush=True)
# Granular event candidates. The event ID is new local RESEARCH id, never an Atlas production ID.
events=[]
def ev(topic,date,precision,title,actor,action,place,source_ids,geo=None,status='source_supported_event; mapping_review_required',notes='',related=None):
 n=sum(z['topic_id']==topic for z in events)+1
 events.append({'id':'C-'+topic.replace('E18-','')+'-'+str(n).zfill(3),'topic_id':topic,'date':date,'date_precision':precision,'title':title,'actor':actor,'action':action,'historical_place':place,'source_ids':source_ids.split(),'research_state':'research_only','cartographic_status':status,'geometry_ref':geo,'historical_control_polygon_approved':False,'event_continues_1699_story_id':related,'evidence_notes':notes})
# 17C direct continuation (first priority)
ev('E18-F09','1699-11-30','day','达连第二批苏格兰移民抵达','苏格兰公司第二远征队','抵达此前已废弃的New Edinburgh并重新建立暂时据点','达连New Edinburgh／Fort St Andrew','S72',None,related='E6-T04-DARIEN')
ev('E18-F09','1700-01','month','苏格兰殖民者攻打西班牙堡垒','苏格兰达连殖民者','攻打Toubacanti西班牙要塞，引发军事反击','Toubacanti（实际堡址待测）','S72',None,related='E6-T04-DARIEN')
ev('E18-F09','1700','year','达连第二远征遭西班牙围攻后投降离开','西班牙军队；苏格兰公司远征队','西军围攻Fort St Andrew；苏格兰殖民方最终投降撤离，短暂占据结束','Darien Fort St Andrew／New Edinburgh','S72 S88',None,notes='Exact surrender day NOT established by NMS page; historical end 1700, not 1707.',related='E6-T04-DARIEN')
ev('E18-F09','1707','year','联盟财政等价款安排关联达连亏损','英苏联合法案谈判代表','就财政等价款398,085英镑10先令安排，部分涉及达连投资者及债务','爱丁堡与威斯敏斯特（立法档案点）','S72 S01',None,notes='£398,085 10s is the Equivalent package, NOT all Darien direct damages compensation.',related='E6-T04-DARIEN')
ev('E18-C26','1700-03-25','day','纽芬兰1699渔法部分条款开始实施','英格兰议会既有1699法','部分法令款项按1699文本规定日期生效','纽芬兰英方渔业港口，精确作用范围未核','S79',None,related='E6-T10-NEWFOUNDLAND')
# Australia D01-D10
ev('E18-D01','1770-08-22','day','库克以英王名义声称占有澳洲东岸','James Cook；英王George III','在Possession Island进行旗帜仪式及文字宣示，声称New South Wales东岸','Possession Island／Bedanug','S19 S19a',None,notes='Claim, NOT conquest/settlement, Indigenous rights continue.')
ev('E18-D02','1787-05-13','day','第一舰队从英格兰启航','英国政府；Arthur Phillip与第一舰队','11艘船启航，将囚犯强制流放至太平洋殖民地','Portsmouth 英国','S37 S37a',None,notes='Ship count 11; total convicts estimates range 750–780 in NSW State Library; NMA 751 arrival.')
ev('E18-D02','1788-01-18','day','第一舰队抵达Botany Bay','Arthur Phillip与第一舰队','舰队开始抵达Botany Bay，随后改选Port Jackson','Botany Bay，Kamay','S37a S37',None)
ev('E18-D03','1788-01-26','day','英国在悉尼湾建立第一流放定居点','Arthur Phillip；海军陆战队；被流放囚犯','选定Sydney Cove，建立常设英国殖民核心','Sydney Cove (Warrane), Port Jackson','S37b S37c','PLACE-SYDNEY',notes='Site core, no NSW-wide British possession polygon. Traditional Eora land.')
ev('E18-D03','1788','year','Eora传统土地遭殖民占建和资源挤压','英国殖民行政；Eora各地方社群','定居设施、粮食及外来动物与当地法权及土地利用方式发生冲突','Warrane和悉尼港周边','S37c S19a','PLACE-SYDNEY',status='narrative_review; no imaginary aggregate Indigenous territory polygon')
ev('E18-D04','1788-12-31','day','Phillip下令拘捕原住民并掳走Arabanoo','新南威尔士总督Arthur Phillip所遣人员','强制抓捕Arabanoo并拘禁，企图建立殖民翻译及接触渠道','悉尼港及政府驻地，具体抓捕位置待核','S21',None,notes='Victim Arabanoo named; not volunteer diplomat.')
ev('E18-D04','1789-05','month','被羁押的Arabanoo因天花死亡','Arabanoo；新南威尔士殖民总督府','Arabanoo在照顾患者过程中患天花去世','悉尼殖民据点','S21',None,notes='Do not assume original captivity exact room geolocation.')
ev('E18-D04','1789-12','month','Colbee与Bennelong被殖民方抓捕','Arthur Phillip所遣殖民人员；Colbee；Bennelong','强制带走两名原住民男子，成为殖民官方语言与接触策略一部分','Sydney Harbour（具体抓捕地点需源复核）','S21',None,notes='Separate from December 1788 Arabanoo seizure.')
ev('E18-D05','1789-04','month','悉尼当地原住民遭遇严重天花疫情','当地原住民族社群；病原传播路径未定','疫情造成重大死亡，殖民记述留下目击记录','悉尼港与附近社区','S22 S22a','PLACE-SYDNEY',notes='Exact origin contested; do NOT assert deliberate infection, or assign unverified deaths to one agent.')
ev('E18-D06','1790-12-10','day','John McIntyre被Pemulwuy等人袭击负伤','Pemulwuy；John McIntyre','殖民总督的狩猎人被刺伤；可能涉及其侵害原住民社会','Botany Bay附近（具体位置待核）','S20',None,notes='Motivation historian inference, not first-hand certainty.')
ev('E18-D06','1790-12','month','Phillip下令武装惩罚性远征','Governor Arthur Phillip；约50名军人及随队医务人员','下令搜捕/惩罚地方原住民；首次行动未获预期结果再派遣','Botany Bay／附近林地，行军路线未知','S20',None,notes='No invented marching GPS, actual capture/kill counts not inferred from orders.')
ev('E18-D07','1792-05','month','Pemulwuy在Prospect开展抵抗行动','Pemulwuy及其Bidjigal同伴','袭击逐步进入原住民领地的农庄、阻碍殖民开垦','Prospect地区，现代地名参考','S20','PLACE-PROSPECT',notes='NMA chronologically first raiding action May 1792.')
ev('E18-D07','1792-1799','multi_year_research_scope','抵抗行动持续并与多个地点殖民占地冲突','Pemulwuy与不同原住民族抵抗者','系列袭击及地方土地防卫，具体行动须单独按年找原记述','悉尼西部、Parramatta与Georges River','S20',None,status='arc_only_no_yearly_point_until_individual_actions_verified',notes='This is arc-level context NOT a manufactured annual event at each year.')
ev('E18-D08','1794-04','month','Toongabbie冲突中殖民人员斩首死者','殖民报复队伍；当地抵抗者','冲突中殖民队伍斩首遇害原住民战士并带回悉尼作为证明','Toongabbie地区','S20','PLACE-TOONGABBIE',notes='Do not conflate with 1797 Parramatta battle or claim head was Pemulwuy.')
ev('E18-D09','1797-03','month','Toongabbie至Parramatta交战Pemulwuy中弹后脱逃','Pemulwuy约100名抵抗者；定居者与英军','殖民队伍追击并在Parramatta开火，至少五名抵抗者被杀，Pemulwuy负伤、被捕后逃出','Parramatta地区（非精确战场）','S20 S20a','PLACE-PARRAMATTA',notes='March supported City of Ryde; NMA article confirms year, >=5 victims. Site reference only.')
ev('E18-D10','1791','year','第三舰队继续将囚犯输送至殖民地','英国政府；私人承包商；Third Fleet','增派被流放者，扩充新南威尔士定居殖民劳力','悉尼港','S37 S37c',None,notes='No reliable point for all 11 ship disembarkations, no total mortality invented.')
ev('E18-D10','1793','year','第一批自由殖民移民抵达','英方移民与殖民政府','英国殖民当局扩大定居人口来源，殖民农地及劳役体系发展','新南威尔士殖民核心附近','S37',None,notes='NMA says first free settlers arrived 1793, individual grants need archive verification.')
# F01-F09
ev('E18-F01','1703-1704','legislative_session','爱尔兰限制天主教产权及监护的法案经议会辩论','爱尔兰议会及英王政治机构','2 Anne c.6法案经过1703/04立法审议，控制地产继承、教育和监护等','都柏林议会（城市参考）','S53 S53a',None,notes='Legislative session not entire 1703 calendar implementation.')
ev('E18-F01','1704-03-04','day','2 Anne c.6爱尔兰宗教惩罚法获得王室批准','爱尔兰王国立法机构与君主','进一步限制天主教徒购地、遗产继承、子女监护与部分公职权利','Dublin，Kingdom of Ireland','S53 S53a',None,notes='Dated royal assent cited Yale older historical printing; Cambridge legal study verifies 1703/04. Only original act source tier in secondary transcription.')
ev('E18-F01','1704','year','天主教土地继承与改宗激励制度','爱尔兰王国议会','法条将宗教身份关联地权，特殊例外及继承法律条款逐项核原文','爱尔兰王国法律效力范围，不是新领土征服','S53a S53b',None,notes='Do not collapse section 7 Protestant estate provision into complete ban of all inheritance.')
ev('E18-F02','1719','year','Sherlock v Annesley导致两院上诉权限争端','爱尔兰与英国两院；诉讼当事人','争夺爱尔兰终审司法权限','Dublin／Westminster','S61a',None)
ev('E18-F02','1720-03','month','英国议会通过爱尔兰依附性宣示法','英国大不列颠议会','Declaratory Act宣示伦敦可制定约束爱尔兰的法律并审理终审上诉','Westminster; Kingdom of Ireland impacted','S61a',None,notes='Distinct Kingdom of Ireland and Parliament remained until 1800/1801.')
ev('E18-F03','1707-01','month','苏格兰议会批准联合条款','独立苏格兰王国议会','经议会批准与英格兰合并政治条款','Edinburgh','S01a',None,notes='Prior to May 1 the Scottish polity remains separate.')
ev('E18-F03','1707-03','month','英格兰议会批准联合条款','英格兰议会','批准建立统一大不列颠王国的条款','Westminster','S01a',None)
ev('E18-F03','1707-05-01','day','大不列颠王国正式成立','英格兰王国与苏格兰王国','两国议会合并；此后同一大不列颠王国政治主体','London / Edinburgh','S01 S01a',None,notes='Ireland a distinct kingdom until 1801.')
ev('E18-F04','1715','year','第一次詹姆斯党大起义','詹姆斯党人与汉诺威王朝政府','企图恢复斯图亚特王朝，战争结局不等同后来的1745起义','Scotland（多站点待核）','S01a',None,status='event_only_site_pending_source',notes='British Parliament timeline supports 1715, exact battle list not yet researched.')
ev('E18-F04','1745-08-19','day','Charles Edward Stuart在Glenfinnan举旗','詹姆斯党起义军','举旗发动1745年战役','Glenfinnan，苏格兰','S01a',None,notes='Historic Environment Scotland battle overview supports precise date; source enhancement pending.')
ev('E18-F04','1746-04-16','day','Culloden政府军击败詹姆斯党军','政府军和Charles Edward Stuart所部','Drummossie Moor会战导致詹姆斯党军事失败','Culloden战场','S01a',None,notes='Specific battlefield survey exists from Historic Environment Scotland; geometry not downloaded here.')
ev('E18-F04','1747','year','禁止部分苏格兰平民男性穿高地服饰制度生效','大不列颠议会/政府','在1746战后颁布的服饰禁令，于1747对符合规定的男性平民施行','Scotland 高地制度范围','NMS-TARTAN',None,notes='Exceptions for women and army, not a blanket all-tartan-all-people ban; repealed in 1782.')
ev('E18-F04','1782','year','1747高地服饰禁令废止','大不列颠议会','废除对部分高地服饰的禁令','Scotland','NMS-TARTAN',None)
ev('E18-F05','1750-1780','period_not_specific_event','高地商业农业改造及政府没收庄园改革背景','苏格兰地主、管理人、战后没收庄园管理机构','牧场扩大、租金与土地结构调整；多处农民受影响','Highlands (broad; no polygon)','S40',None,status='context_only_no_point_no_polygon',notes='Long trend not necessarily documented every annual eviction.')
ev('E18-F05','1780-1799','period_not_specific_event','高地早期清场第一波','高地庄园地主、管理人及遭驱逐的佃户','部分庄园迁移佃户、改造牧场及沿海安置；具体地块年份仍待逐庄园档案','Scottish Highlands various estates','S40 S40a',None,status='context_only_no_point_no_polygon',notes='Sutherland 1809–21 mass clearances must not be moved into 18c.')
ev('E18-F06','1798-05-27','day','Oulart战斗起义军击败North Cork Militia','爱尔兰起义军；北科克民兵','起义军获胜并扩大战局','Oulart，County Wexford','S23',None)
ev('E18-F06','1798-05','month','联合爱尔兰人发动反抗王室统治的起义','Society of United Irishmen及盟友；爱尔兰政府军','多郡起义遭到军事镇压，在Wexford等地方出现反复','Ireland（多个地方需分点）','S23',None,status='multi-site_no_fake_centroid',notes='May 1798 rising, independent participants and civilian violence need attribution.')
ev('E18-F06','1798-06-21','day','Vinegar Hill会战政府军轰击并击溃起义军','英国军队及爱尔兰王室政府军；反抗者','政府军炮轰与攻占营地，多个幸存者撤离','Vinegar Hill，Enniscorthy附近','S23',None)
ev('E18-F06','1798-06','month','起义中双方针对非战斗人员的暴力','忠诚派军队、起义军的不同单位','Scullabogue起义者焚杀多名忠诚派被囚人员；政府及忠诚派军队发生报复杀戮','County Wexford多个局部地点','S23',None,status='separate_incidents_need_primary_casualty_audit',notes='Attribute each action and avoid group moral simplification; no combined single death total.')
ev('E18-F06','1798-08','month','法国远征队于Killala登陆支援起义','Jean Humbert法军及爱尔兰地方支持者','小规模法军在Mayo登陆并试图支持起义','Killala Bay, County Mayo','S23',None)
ev('E18-F06','1798-08-27','day','Castlebar法军及支持者取得战斗胜利','Humbert法军与当地盟友','击败王室政府力量','Castlebar, County Mayo','S23',None)
ev('E18-F06','1798-09-08','day','Ballinamuck政府军使法国远征军投降','英国军队；Humbert法军','围困并迫使远征军投降，西部起义阶段被镇压','Ballinamuck, County Longford','S23',None)
ev('E18-F07','1799-01-22','day','爱尔兰下院提出考虑与大不列颠联合','爱尔兰议会与英国政府','爱尔兰下院初步考虑两院联合方案','Dublin','S61',None)
ev('E18-F07','1799-01-24','day','爱尔兰下院否决联合动议','爱尔兰下议院','反对首次将议会联合推进；未在1799年达成议会联合','Dublin','S61',None,notes='1800 statute and 1801 effective date are outside the 18c proposed event period.')
ev('E18-F08','1700-1799','period_not_specific_event','奴役经济资金联系的英国庄园与港口待核母题','英国私人商人、银行、庄园及船主','历史研究关联存在，但逐笔资金和人物关系仍待账册验证','British ports and estates; no single place','S38',None,status='research_topic_not_event_no_map',notes='Do not claim any precise ROI, cash flow, enslaver holdings or source of 1694 Bank subscriptions without individual documents.')
# cross-region handoff, not duplicated regional large investigations
for t,date,precision,title,actor,action,place,src,related in [
('E18-C27','1713','year','HBC部分海湾堡垒依和约返还','法英政府与HBC','战争后海湾堡垒移交安排，逐堡驻守待详核','Hudson Bay shores','S81 S85','E6-T10-HBC'),
('E18-C21','1715-04-15','day','亚马西战争爆发','Yamasee等原住民群体与Carolina殖民政府','对殖民贸易债务、掳奴贸易及侵地展开战争','Carolina / Yamasee region','S73','E6-T09-CAR'),
('E18-C22','1705','year','弗吉尼亚奴役法律编订','Virginia colonial assembly','修改并编订强制奴役与刑事法规','Williamsburg（殖民地议会参考）','S74','E6-T05'),
('E18-C23','1712','year','纽约被奴役者武装反抗及镇压','被奴役纽约人；纽约殖民政权','反抗与后续逮捕、处决或惩罚','New York','S83','E6-T09-NY'),
('E18-C24','1741','year','纽约殖民司法阴谋案审判','纽约殖民当局和被控被奴役／自由居民','大规模指控、审判及处决；所谓阴谋真伪有争议','New York','S75','E6-T09-NY'),
('E18-C25','1737','year','步行购买欺诈争议','Penn家族及Lenape','殖民土地声索及争议性测量剥夺原住民地权','Pennsylvania','S76 S77 S86','E6-T09-PENNSYLVANIA'),
('E18-E15','1719','year','本古伦当地起义与英方撤退','Sumatran local polities与EIC人员','地方冲突迫使公司人员离开贸易据点','Bencoolen','S78','E6-T12'),
('E18-E15','1723','year','本古伦公司据点重建','东印度公司','公司重返并重新设防，前1719-22不能简单延续驻守','Bencoolen','S78','E6-T12'),
('E18-A05','1739','year','牙买加马龙条约','英国殖民当局与Maroon领导团体','达成自治及其他约束条约，需区分各马龙群体','Jamaican Maroon towns','SRC17','E6-T08'),
('E18-A12','1796','year','牙买加部分马龙人遭驱逐至Nova Scotia','牙买加殖民当局与遭驱逐马龙人','1795战争后进行跨大西洋驱逐','Jamaica to Nova Scotia endpoints only','SRC17','E6-T08'),
]:ev(t,date,precision,title,actor,action,place,src,None,status='handoff_not_full_region_research; point_requires_review',related=related)
out('EVENT_CANDIDATES.json',{'schema':'18c-assistant-C-event-candidates-v1','editorial_state':'research_only','notes':['Candidate IDs are new local research IDs, not production Atlas IDs.','Date precision is explicit; period/context rows are not individual annual actions.','None of these creates a British historical territorial polygon.','Overseas handoff events are minimal continuity pointers, other assistant owns detailed cases.'],'event_count':len(events),'events':events})
fields=['id','topic_id','date','date_precision','title','actor','action','historical_place','source_ids','research_state','cartographic_status','geometry_ref','historical_control_polygon_approved','event_continues_1699_story_id','evidence_notes']
with (root/'EVENT_CANDIDATES.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=fields);w.writeheader();
 for e in events:w.writerow({**e,'source_ids':';'.join(e['source_ids'])})
print('SAVED stage 3 event candidates',len(events),flush=True)
# Three explicitly sourced modern georeferences + provenance-only named sites (null geometries)
urls.update({
'GEO-SYD':('Dictionary of Sydney (archived)','Sydney Cove / Warrane feature location','https://dictionaryofsydney.org/natural_feature/sydney_cove'),
'GEO-CULLODEN':('Gazetteer of British Place Names','Culloden Battlefield modern representative location','https://gazetteer.org.uk/place/Culloden_Battlefield%2C_Inverness-shire_301227'),
'GEO-VINEGAR':('Excavations.ie / Irish archaeology record','Vinegar Hill 2022 monitored site coordinate','https://excavations.ie/report/2022/Wexford/0031602/'),
'HES-CULLODEN':('Historic Environment Scotland','Battle of Culloden historical site record and 16 April 1746','https://portal.historicenvironment.scot/apex/f?p=1505%3A300%3A%3A%3A%3A%3AVIEWTYPE%2CVIEWREF%3Adesignation%2CBTL6'),
'S53c':('Yale MacMillan Center online historical tract','19th-century commentary on 1704-03-04 Irish royal assent','https://macmillan.yale.edu/glc/history-penal-laws-against-irish-catholics'),
})
all_geo={
'PLACE-SYDNEY':(['GEO-SYD','S37c'],[151.2117281,-33.8580126],'Sydney Cove / Warrane','cove_feature_representative_not_original_1788_tent_or_occupation_extent'),
'PLACE-CULLODEN':(['GEO-CULLODEN','HES-CULLODEN'],[-4.100492,57.478367],'Culloden battlefield modern representative','modern_battlefield_reference_not_exact_1746_army_line'),
'PLACE-VINEGAR':(['GEO-VINEGAR','S23'],[-6.552728,52.502764],'Vinegar Hill monitored modern location','specific_2022_excavation_point_near_historical_battlefield_not_entire_engagement'),
'PLACE-PROSPECT':(['S20'],None,'Prospect district','documented_name_but_modern_reference_coordinates_not_yet_verified'),
'PLACE-TOONGABBIE':(['S20'],None,'Toongabbie locality','documented_1794_location_but_exact_battle_site_unknown'),
'PLACE-PARRAMATTA':(['S20','S20a'],None,'Parramatta district','documented_locality_but_exact_1797_battlefield_not_verified'),
'PLACE-BOTANY':(['S37a'],None,'Botany Bay / Kamay','large_estuary_not_single_precise_1788_landing_point'),
'PLACE-POSSESSION':(['S19','S19a'],None,'Bedanug / Possession Island','Cook_landed_at_named_island_but_ceremony_spot_not_verified'),
'PLACE-DARIEN':(['S72'],None,'Darien Fort St Andrew / New Edinburgh','fort_exact_location_not_verified'),
'PLACE-EDINBURGH':(['S01'],None,'Edinburgh Parliament','parliament_building_geocode_not_separately_verified'),
'PLACE-DUBLIN':(['S61','S53'],None,'Dublin Parliament / Ireland','date_documented_not_exact_chamber_coordinate'),
'PLACE-CAPECOAST':(['SRC17'],None,'Cape Coast Castle','prior_story_fort_named_annual_control_unverified'),
'PLACE-GUNA':(['S72','SRC17'],None,'Guna communities Darien coast','native_territory_no_source_based_boundary'),
'PLACE-MADRAS':(['SRC17'],None,'Fort St George','company_site_annual_changes_unverified'),
'PLACE-BOMBAY':(['SRC17'],None,'Bombay / Mumbai fort','company_site_annual_changes_unverified'),
'PLACE-CALCUTTA':(['SRC17'],None,'Sutanuti / Dihi Kalikata / Gobindapur','three_village_income_rights_not_sovereignty'),
'PLACE-BENCOOLEN':(['S78'],None,'Bencoolen','17c_company_trade_site_1719_discontinuity'),
'PLACE-NEWJERSEY':(['NJ-1702'],None,'East and West Jersey','political_change_not_actual_parcel_boundary'),
'PLACE-HUDSON':(['S81','S85'],None,'Hudson Bay trading fort nodes','need_fort_by_fort_coordinates')
}
features=[]
for key,(refs,coord,label,method) in all_geo.items():
 related=[e['id'] for e in events if e.get('geometry_ref')==key]
 if key=='PLACE-CULLODEN':related.extend([e['id'] for e in events if e['date']=='1746-04-16'])
 if key=='PLACE-VINEGAR':related.extend([e['id'] for e in events if e['date']=='1798-06-21'])
 if key=='PLACE-POSSESSION':related.extend([e['id'] for e in events if e['date']=='1770-08-22'])
 if key=='PLACE-DARIEN':related.extend([e['id'] for e in events if e['topic_id']=='E18-F09' and e['date'] in ['1699-11-30','1700-01','1700']])
 if key=='PLACE-DUBLIN':related.extend([e['id'] for e in events if e['topic_id'] in ['E18-F01','E18-F07']])
 f={'type':'Feature','id':key,'geometry':{'type':'Point','coordinates':coord} if coord else None,'properties':{'name':label,'source_ids':refs,'linked_event_ids':sorted(set(related)),'coordinate_method':method,'coordinate_status':'modern_georeference_online_sourced' if coord else 'no_numeric_coordinate_verified','geo_precision':'modern_place_reference_not_historical_event_site','historical_boundary_confirmed':False,'territorial_claim':False,'fill_authorized':False,'area_sqkm':None,'exclude_from_area_aggregation':True,'publication_status':'research_only','map_inclusion':'review_point' if coord else 'unresolved_place_catalogue_only'}}
 features.append(f)
out('MAP_CANDIDATES.geojson',{'type':'FeatureCollection','name':'18c_assistant_C_evidence_only_georeferences','source_description':'Only three externally sourced modern place-reference coordinates; other well-evidenced named places deliberately have geometry null. No measured historical territorial polygon.','features':features})
# Adjust events to map sourced sites where possible and to mark original coverage layers only research
for e in events:
 if e['date']=='1770-08-22': e['geometry_ref']='PLACE-POSSESSION'
 elif e['date']=='1746-04-16': e['geometry_ref']='PLACE-CULLODEN'
 elif e['date']=='1798-06-21': e['geometry_ref']='PLACE-VINEGAR'
 elif e['topic_id']=='E18-F09' and e['date'] in ['1699-11-30','1700-01','1700']:e['geometry_ref']='PLACE-DARIEN'
 elif e['topic_id']=='E18-F07':e['geometry_ref']='PLACE-DUBLIN'
 elif e['topic_id']=='E18-F01':e['geometry_ref']='PLACE-DUBLIN'
# The collection's links are generated after adjustment
for f in features:
 f['properties']['linked_event_ids']=sorted(set(e['id'] for e in events if e['geometry_ref']==f['id']))
out('MAP_CANDIDATES.geojson',{'type':'FeatureCollection','name':'18c_assistant_C_evidence_only_georeferences','coordinate_order':'[longitude, latitude]','source_description':'Only three externally sourced modern reference coordinates; 16 further attested named localities have geometry:null pending independent geocoding. No historical territorial polygon.','features':features})
out('EVENT_CANDIDATES.json',{'schema':'18c-assistant-C-event-candidates-v1','editorial_state':'research_only','notes':['Research IDs only, not production Atlas IDs; year range context rows are NOT individual annual events','Only three modern coordinates sourced separately, other georefs unresolved, no invented routes','No events authorize actual historical control polygons.'],'event_count':len(events),'events':events})
with (root/'EVENT_CANDIDATES.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
 for e in events:w.writerow({**e,'source_ids':';'.join(e['source_ids'])})
sources=[{'id':k,'institution':v[0],'title':v[1],'url':v[2],'access_level':('repository_file_read' if k.startswith('SRC') else 'academic_history_or_archaeological_reference' if k in ['GEO-CULLODEN','GEO-VINEGAR','GEO-SYD','HES-CULLODEN'] else 'peer_reviewed_abstract_or_published_analytical_page' if k in ['S53','S53b','S78'] else 'public_digital_transcription_or_institutional_history'),'original_manuscript_personally_inspected':False,'reviewed_online_on':'2026-11-08'} for k,v in urls.items()]
out('SOURCE_REGISTRY.json',{'schema':'assistant-C-research-sources-v1','editorial_status':'research_only','primary_registry':pr+'research/18c/SOURCE_REGISTRY.json','source_count':len(sources),'sources':sources,'interpretation_notice':'Journal abstract != full paper review; archival citation != original folio read. Dossiers identify source-grade differences.'})
print('SAVED stage 4 geo references',len(features),'with real sourced WGS84 points',sum(x['geometry'] is not None for x in features),flush=True)
# Detailed dossiers: independent interpretive synthesis with source-level qualifications, follow-up archive tasks.
D={
'D01':('库克1770年声索与原住民主权','1770-08-22',
'''库克1768—1771航行中的1770年8月22日行使的是英国军官对东海岸的**声索仪式**。澳大利亚国家博物馆刊录库克当日日志，记载升旗并以乔治三世名义宣示整条东岸、海湾及岛屿。库克此前接触多个原住民族社群，也并未建立持续驻军或内陆征税机构。该声索与当地土地使用、法权和主权诉求互相冲突。国家博物馆的Possession Island专文同时呈现当地先民自身的生活网络。原史事应放在当时可据证的岛屿地点，而非把库克宣称的“整个东岸”填为已占领英国领土。''',
'''优先锁定库克日志22 August原始版本、Possession Island各语族地理、1770英国命令及后世如何使用“terra nullius”概念的法律史。现有材料足以设主权声索事件，不足以制作1770“英国占领澳洲东半岛”实心疆域。''','S19 S19a'),
'D02':('第一舰队与流放犯运输','1787–1788',
'''11艘第一舰队船于1787年5月13日离开英格兰，1788年1月18日开始抵达Botany Bay，1月26日建立Sydney Cove定居点。运输是国家组织的刑罚强制流放，同时与对Gadigal等原住民族领地的实际侵犯结合。数量需保留两种来源口径：新南威尔士州图书馆说运输囚犯约750—780人，澳大利亚国家博物馆记载到达后登陆人数751人；后者不宜冒称整个远征期间所有船上登船总数。航行各港口停靠、死亡分母、家属/海军陆战队各类人数分开统计。''',
'''必须从State Library NSW First Fleet文献指南、各船名单/日记查港口启离日期、每船登船/抵岸/死亡；只有经源证实的港口间关系才画非GPS虚线。单个具名被流放者和船只未来可另建索引。''','S37 S37a S37b S37c'),
'D03':('1788年悉尼湾殖民政权建立','1788',
'''1月26日Phillip在Sydney Cove建立实际营地与行政—军事实体。澳大利亚国家图书馆保存囚犯Francis Fowkes于1788年4月绘制的初期营地草图（1789刊行），有建筑、帐篷、田地等清楚地标；但州图书馆提醒该图非准确测绘图。这是“点/有限营地核心”最强的相对空间证据之一，**仍无法推出新南威尔士当时广大纸面行政范围被实地占领**。Gadigal、Cammeraygal、Wangal与其他Eora当地社区没有因英方宣示或营地建立而全部被消除。''',
'''下阶段应从NLA原地图高清、测绘大地控制点和早期行政/粮田土地分配记录重建具有误差范围的**1788营地参考区**；至有可复核地理校正和法律语义前不输出实控Polygon。图形优先考虑现代湾区参考点及原图影像出处。''','S37b S37c GEO-SYD'),
'D04':('殖民者抓捕Arabanoo、Colbee与Bennelong','1788–1789',
'''Towards Truth平台收录并索引殖民文书：1788年12月31日Phillip遣人强行抓捕Arabanoo，把他置于殖民总督监视及拘禁下，称为学习语言、促进交往；Arabanoo帮助护理天花患者，1789年5月死亡。1789年12月殖民者又抓捕Colbee与Bennelong。这不是基于平等自愿的外交会面。应把各次抓捕及死亡拆成独立事件，避免把所有三名受害者的时间一律写为1788。''',
'''继续查Towards Truth所链殖民原文件DOC2103、DOC1608及Tench、Collins相关原文，定位确切抓捕湾滩并区分被抓人身拘束、获释和后续外交；当前无抓捕GPS，地点暂不插点。''','S21'),
'D05':('1789年天花流行及传入途径争论','1789',
'''悉尼港原住民社区于1789年4月发生严重天花流行，大量死亡。NMA文章引用David Collins及Newton Fowell当代见闻，为疫情发生提供扎实证据。疫情的**初始传入链未确证**；澳洲国家博物馆教育资源倾向认为第一舰队医者携带的接种材料是可能路径，但仍未证明具体暴露方式；机构另篇文章明确记载几种流行假说和其争议。不得给殖民者构造无档案证明的“蓄意散播”年份地点，也不能把机构局部人口损失估计转为悉尼全部原住民族的确定死者人数。''',
'''进一步求证DNA研究、环境与流行病史、当代港湾逐地点人口叙述和NMA两篇不同的解释；人命数字保留来源/地点/分母。地图只对确证的1789疫区具名地点标注，疫情扩散边界尚无史料测量。''','S22 S22a'),
'D06':('1790年McIntyre事件及惩罚远征','1790',
'''NMA记载McIntyre于1790年12月10日遭Pemulwuy等人攻击负重伤。国家博物馆援引史学研究指出McIntyre被当地社区恐惧与厌恶，报复动机是**合理史学推测**。Phillip随后派出约50名军人及医务人员、带有装尸体袋的惩罚远征队，首次未获预期战果又派出第二次。必须把总督军事命令与实际杀害、俘虏人数分开；地图无史料支持不得画两支军队“精确路线”或杀戮范围。''',
'''查Phillip军事命令文本及Watkin Tench《A Complete Account》当代观察，确认兵数、具体区域、两次远征各自出发/返回日期、实际后果；省略未实证的伤亡累计。''','S20'),
'D07':('Pemulwuy与Bidjigal反殖民抵抗','1792–1799',
'''Pemulwuy所属Bidjigal抵抗者的已证早期行动包括1792年5月Prospect一带袭击，随后多处农庄和交通路段冲突扩大。抵抗者的社会组织及土地权利不能写成“英国治下叛乱臣民”的简单叙事。该长系列持续到1802年Pemulwuy去世，**1799是本轮研究视窗**，不是历史结束；后续1801年官方shoot-on-sight命令及1802斩首必须交给19世纪团队接续。''',
'''查询1792–1802原殖民公报、Phillip/King信函、早期西悉尼农地档案、地方原住民历史口述。时间精度为月的行动可落区域名称，不能把Prospect/Parramatta/Georges River连成持续军事占据区域。''','S20 S20a'),
'D08':('1794年Toongabbie报复斩首','1794-04',
'''NMA对于1794年4月前后殖民者—原住民族间频繁冲突有明确叙述，其所谓“Battle of Toongabbie”中殖民方报复队伍将一位遇害原住民战士斩首并带回悉尼作为证据。该战斗发生在**1794年，不是1797年Parramatta会战**。姓名、确切人数与冲突所在农场均须继续翻原始记录。斩首地点与后来的收藏地点必须分别审核。''',
'''下一步核对NMA脚注的Tench/Collins资料及地方考古，从逐日叙事确认月份和地点；Toongabbie现代镇中心不能直接当斩首发生的精准经纬度。''','S20'),
'D09':('1797年Parramatta冲突与Pemulwuy逃脱','1797-03',
'''NMA确定1797年Pemulwuy领约100名战士推进Parramatta，当局士兵开火致**至少5名原住民战士死亡**，Pemulwuy中霰弹负伤，后成功逃离；City of Ryde对该战斗与追击线路记录为1797年3月、从Toongabbie朝Parramatta附近推进，并提到他被俘后逃脱。资料对某些行动细节及地理位置保有来源等级差异，不能把“至少5人”扩大为所有参与者死伤。''',
'''查1797具体日期与政府农场地籍、谁开枪、伤亡和Pemulwuy被拘地，之后才考虑两端事件点和示意行动关系；禁止以近代Parramatta市界作为英国夺占土地面积。''','S20 S20a'),
'D10':('1790年代农庄扩张、刑罚劳动与土地分配','1790–1799',
'''英国当局利用被流放囚犯技能安排道路、建筑和农庄劳力，同时以囚犯土地配给、后来的自由移民定居持续扩张新南威尔士城镇核心。国家博物馆明确记1793年首批自由殖民移民抵达，以及1791年第三舰队进一步输送囚犯。强制劳动、法律身份与原住民土地被占的机制须按各处营地、农庄和实际授地年月具体整理，不能凭1770纸面声索绘制1790年整个大陆殖民面。''',
'''优先详查Parramatta/Rose Hill、Toongabbie、Hawkesbury、Norfolk Island各自粮田创建、授地文书、冲突年份及实际驻军；这些新增地点需要单独记录旧地权和原住民族政治主体。''','S37 S37c S20'),
'F01':('爱尔兰天主教土地和教育限制：1703–1704','1703–1704',
'''17世纪阿尔斯特移民殖民、克伦威尔没产及1691年威廉派战争的**制度结果**进入1703–04爱尔兰议会的宗教惩罚法律体系。J. G. Simms的Irish Historical Studies论文专论2 Anne c.6在1703–04形成的复杂政治过程；明尼苏达大学法学院保存逐条史法英译/转录，具体涉及购地权、继承、子女监护与宗教教育。土地部分法条需区别“限制从新取得产权”“不得继承新教徒产业”“天主教徒死后分割旧有土地”以及例外机制；绝非“1704没收全爱尔兰天主教徒全部土地”的单一地理事件。''',
'''按2 Anne c6每个section建立立法正文逐条表，考证1704批准日、后续修法/豁免、地籍实际交易。每一法律冲击地点最好与实际产权诉讼记录相关联；全岛法的效力边界与每块土地真实转让严格分开。''','S53 S53a S53b S53c'),
'F02':('1720年英国对爱尔兰立法和终审权宣示','1719–1720',
'''1699年Woollen Act和1707联合之后，爱尔兰仍保有独立议会；Sherlock v Annesley在1719年引发爱尔兰与英国两院谁有终审司法权的冲突。英国议会1720年3月通过Declaratory Act，明定Westminster能够立对爱尔兰有约束力之法，英国上议院可作为终审法院。作为爱尔兰王国政治依附关系加深的明确时点，地图上应是**政治法权状态变化**，而非新一圈被征服的都柏林战场。''',
'''优先查原法全文6 Geo. I c.5及1720起讼文件与具体英爱两院程序，分别建立17C已有爱尔兰行政控制、1720英国议会对爱尔兰法权扩大。''','S61a'),
'F03':('1707年独立英苏王国议会联合','1707',
'''1707年以前，英格兰和苏格兰具有共同君主，但仍是两个王国、两个议会。英国议会的历史公报把苏格兰批准置于1707年1月、英格兰批准置于3月，真正建立Kingdom of Great Britain的生效日是**1707年5月1日**。爱尔兰此时是另一个有自身议会的王国，不能将苏格兰、爱尔兰、英属海外省全部按现代统一UK法制追溯标色。达连失败是英国与苏格兰联盟谈判的经济背景，但1700军事退出与1707合并不能当同一军事事件。''',
'''核实联合法案Articles of Union 1695–1707原文、英苏议会分别投票、£398085 10s Equivalent的不同补偿对象及公司清算实际流水；1707对旧公司对外贸易权利的法律更换需要逐公司核。''','S01 S01a S72'),
'F04':('詹姆斯党战争结局与1746–1747高地打击','1715;1745–1747',
'''1715起义与1745起义是两次不同军事政治过程。1745年8月19日Glenfinnan举旗，1746年4月16日Culloden会战政府军战胜詹姆斯党军。胜利后政府通过解除武装及限制高地文化服饰的法规；国家博物馆确认1747年施行的禁令只针对部分民间男子服装，女性和正规军服饰不受相同限制，1782年撤销。不能泛称“所有苏格兰人所有格子呢从1746到1815被禁”，也不能把高地政府军镇压等同一切苏格兰人均被殖民征服。''',
'''进一步核证1746解除武装法及《Heritable Jurisdictions》法条是否于1747施行、没收庄园11处档案、逃亡者追捕和战后具体村落搜缴/焚毁；Culloden遗址地图已可查询HES，但战后军政辖域仍不得按整个高地铺色。''','S01a NMS-TARTAN HES-CULLODEN S40'),
'F05':('高地清场早期阶段：1750–1799','c.1750–1799',
'''苏格兰历史学会将1750–1780概括为庄园经济“改良”与重整阶段，并把**1780–1825**作为第一波清场：租金、圈地、羊牧扩张与部分佃户向海岸迁移，决策主体具体是庄园地主、经管人和法律制度，其强制与经济动因因庄园而异。Sutherland 1809–1821的著名大规模清场发生在**19世纪**，不应塞进1780/1790年代地图。该题与1746詹姆斯党镇压存在制度/政治链条，但17世纪格伦科屠杀不应被错误延长为整个清场运动。''',
'''优先找1780/1790年代有确切日期的庄园租约解约、迁居命令、佃农证词、旧统计账户1791–99逐郡文章；逐地辨别主动迁移、驱逐、圈地、补偿及后续饥荒，谨防把各县抽象“高地清场边界”当一张确定行政地图。''','S40 S40a'),
'F06':('1798年爱尔兰起义与镇压、法军来援','1798',
'''1798年联合爱尔兰人主导反对殖民依附的起义，在Wexford、Ulster及其他多郡出现不同局势。国家陆军博物馆记载5月27日Oulart起义者击败North Cork Militia，随后占据Enniscorthy与Wexford，6月21日Gerard Lake的政府军炮轰Vinegar Hill并攻占；法国Humbert部8月登陆Killala，8月27日赢Castlebar，但9月8日在Ballinamuck投降。证据同样包括起义者对Scullabogue被囚者纵火与政府、忠诚派军队的报复屠杀；应对每种行为分别标明责任，不能制造单方独占全部暴力的假历史。''',
'''进一步核对每地档案/法庭/军事报表、死亡人口统计之分母、各派军队独立指挥链以及平民伤亡。当代爱尔兰“王国”与英方驻军是两个政治层级，1798战事不能当1801已经生效的联合王国镇压。''','S23'),
'F07':('1799联合提案失败与1800–1801后续门禁','1799',
'''英国议会历史网站给出非常明确的断点：1799年1月22日爱尔兰下院被要求考虑议会联合，1月24日该动议**失败**；政府随后以封爵、养老金与政治游说继续推动。1800年3月28日爱尔兰两院最终通过相关条款，1800年8月1日取得王室批准，1801年1月1日联合王国正式成立。这三个阶段严禁并到1799年；英国财政的土地利益集团游说应核具名交易，而非机械地给所有议员标记金钱贿赂。''',
'''主编18世纪最后一页只保留1799提议及遭拒；1800立法与1801生效属于下一世纪初的**直接承接**，应在未来19C研究任务中建立正式节点。''','S61 S61b'),
'F08':('英伦港口、奴役经济与私人政治资本','1700–1799',
'''该母题是**长期经济网络研究**，并非1700年发生的单一战争或财产转让。Historic England有跨大西洋奴役经济与英格兰建筑环境的研究审计，支持从港口、庄园、保险、银行、投资人网络追溯获利联系。但每项资金路径必须以同年、同主体、账簿或法案形成证据；不得把1694年英格兰银行120万英镑政府贷款全部声称来自奴役贸易利润，也不得虚构18世纪所有英国庄园均由奴役劳动资助。''',
'''优先索取奴隶赔偿委员会19世纪档案反查18世纪家族持有但不能时间逆投，追查港口船东与税账、个人遗嘱、保险货单；具体事实与A系列调查员对接，避免双重计算同一公司利润。''','S38'),
'F09':('达连第二远征及1707年联盟财政余波','1699–1707',
'''17世纪旧专题E6-T04-DARIEN在1699年11月30日第二远征船队抵达以后**不能结束整条事件故事**。苏格兰国家博物馆确认1700年1月苏方为防西班牙进军先袭Toubacanti，西班牙武力随后围Fort St Andrew，苏方最终投降并获准离开。1700年末不再有苏格兰公司在此堡垒持续占据；Guna社区政治自主与西班牙地方力量另作地图对象。苏格兰国家博物馆还记英苏联合中的Equivalent款为£398,085 10s，涉及国家债务分担和部分达连投资损失安排，不能全部归类作达连赔偿。''',
'''这是唯一应直接续接原1699年苏格兰殖民行动的F系列案件。还须读《The Darien Papers》各页、1699/1700西班牙围城报告、投降准确日期、Guna首领与双方协定；旧堡计划图只能作为有史料来源的地理研究影像，不能直接当实测政治边界。''','S72 S88 S01'),
}
for code,(title,window,analysis,gaps,refs) in D.items():
 topic='E18-'+code
 evs=[e for e in events if e['topic_id']==topic]
 org=['## 档案摘要',f'**原始研究ID：** `{topic}`   **时段：** {window}   **状态：** `research_only`\n','## 经核查的历史过程',analysis,'\n## 本地候审事件（不得视为已刊发）']
 for e in evs:
  org.append(f"- `{e['id']}` · **{e['date']}**（{e['date_precision']}）：{e['title']}；主体：{e['actor']}；行为：{e['action']}；地点：{e['historical_place']}。来源：{', '.join(e['source_ids'])}。")
 org+=['\n## 地图制作决策','**仅研究候审。** 清楚区别政治声索、实际行政据点、土地私有/没产制度、独立原住民族社群、战场与实际占领。只允许有出处的现代参考位置作为点；尚无核准历史边界，不发布实控多边形、不计算面积；无法定位者保持 geometry:null。独立苏格兰/爱尔兰政治主体按真实当年命名。','\n## 仍需翻阅的原档和下一轮调查',gaps,'\n## 本轮已读/核对来源（完整链接）']
 for r in refs.split():
  if r in urls:org.append(f'- `{r}` {urls[r][0]}：{urls[r][1]}。{urls[r][2]}')
 org+=['\n## 可交付程度','目前为逐事件年份和政治语义的研究级资料，原始档案页、精细空间标定以及地图浏览器交互未作正式出版复核。']
 md('TOPIC_DOSSIERS/'+topic+'.md','\n\n'.join(org)+'\n')
# Additional cross-century dossiers with actionable editor handoff rather than duplicate regional research.
CONT={
'1700_DARIEN_OLD_STORY.md':('E6-T04-DARIEN','1699 second landing, 1700 Toubacanti attack, 1700 Spanish siege and Scottish surrender; exact day pending','S72 S88','E18-F09','No Scottish garrison as of 1700-12-31; Guna not ceded; do not paint Panama as Scots/British.'),
'1700_NEWFOUNDLAND_LAW.md':('E6-T10-NEWFOUNDLAND','1699 fishery statute clauses begun 1700-03-25; existing seasonal fishing and French Plaisance distinct','S79 S80','E18-C26','Law effect is not 1700 capture of island nor loss of Beothuk sovereignty.'),
'HBC_1699_1713.md':('E6-T10-HBC','HBC 1670 charter, late 1690s French/English fort exchanges, 1713 change, Cree/Dene diplomacy 1715','S81 S85','E18-C27','Fort-by-fort, year-by-year; patent watershed not effective military realm.'),
'EIC_BENGAL_BENCOOLEN.md':('E6-T12','EIC company 1698 Mughal Bengal three village rights; 1719 Bencoolen revolt and withdrawal; 1723 recapture','S78','E18-B01 E18-E15','Zamindari not sovereign Bengal; annual fort occupancy needs real registers.'),
'JAMAICA_MAROONS.md':('E6-T08','Maroons autonomous across 1700; First Maroon War 1728–39, treaties 1739, Second 1795, transport 1796','SRC17','E18-A05 E18-A11 E18-A12','Do not automatically count autonomous Maroon mountains as direct plantation rule.'),
'CAROLINA_LENAPE_NY.md':('E6-T09-CAR;E6-T09-PENNSYLVANIA;E6-T09-NY','1715 Yamasee, 1737 Walking Purchase, 1712 NY resistance, 1741 NY alleged conspiracy trials','S73 S75 S76 S83','E18-C21 E18-C23 E18-C24 E18-C25','Distinct Indigenous sovereignty, coerced land deeds, criminal allegation evidence, charters not occupancy.'),
'AFRICAN_COMPANY_SLAVERY.md':('E6-T11;E6-T13;E6-T17-AFRICAN-FORTS','1698 RAC monopoly altered but African trafficking/Atlantic trade persisted; 18C source denominator must be new','S82 S38','E18-A01 E18-A03 E18-E10','Fort trading license is not inland political sovereignty; never reuse 1601–1700 voyage totals.'),
'IRELAND_LAND_1691_1704_1798.md':('E6-T01;E6-T02;E6-T03-LAND-1642-1698;E6-T03-WILLIAMITE-WAR','1691 Williamite military end; 1704 Catholic exclusion laws; 1798 independent uprising; 1801 later union','S53 S53b S23','E18-F01 E18-F06','Do not extend 1691 battles into 1700; estate rights vs legal disabilities distinct.'),
'SCOTLAND_1700_1746_1780.md':('E6-T04;E6-T04-CONQUEST;E6-T04-GLENCOE','1700 separate Scotland, 1707 Union, 1745 uprising, 1746 defeat, 1747 garment restriction, first Highland clearances 1780s','S01 NMS-TARTAN S40','E18-F03 E18-F04 E18-F05','1650–52 Cromwellian conquest ended, 1692 Glencoe massacre not a centuries-long battle.'),
}
for fname,(ids,flow,ss,nxt,spatial) in CONT.items():
 lines=[f'# 跨世纪专题调查：{fname.replace(".md","")}',f'原17世纪稳定ID：`{ids}`。对应18世纪研究专题：`{nxt}`。','\n## 已核时间链',flow,'\n## 地图实控、政权与边界风险',spatial,'\n## 研究任务','将原17世纪文章末尾准确的研究截止和真实战事结束分别录入。校对相邻年份发生的法律效力、实地驻军及地方原住民/自治政体，建立多主体年末状态。已有旧文章不需要为延长年份而改写已发生的战争。','\n## 来源']
 for r in ss.split():
  if r in urls:lines.append(f'- `{r}` {urls[r][0]} {urls[r][2]}')
 lines.append('\n状态：研究级交接，地图历史范围未获测绘核准。')
 md('TOPIC_DOSSIERS/'+fname,'\n\n'.join(lines)+'\n')
print('SAVED stage 5 topic dossiers',len(D),'cross-century',len(CONT),flush=True)
# Stage 6: Explicit handoffs, missing topics, year-end decision interpretation and honest QA status.
missing='''# 爱英TV：第三调查员跨世纪遗漏与协作清单

**日期：** 2026-11-08  · **性质：** 18世纪历史研究候审（未发表）  · **GitHub：** 仅阅读，未修改仓库。

## 最优先纠错：跨年不等于持续占领

1. **达连殖民（E6-T04-DARIEN → E18-F09）**：1699年11月第二远征接入1700年1月Toubacanti进攻、其后西班牙围城、苏格兰殖民者投降与撤离。1700年12月31日苏格兰该据点不再存续。未读到有权威精确投降日的原档；不可把苏方全部已消失据点绘成1707年英国新占地。古纳政治社群另建关系。来源：S72、S88。
2. **纽芬兰（E6-T10-NEWFOUNDLAND → E18-C26）**：1699年贸易与渔业法律部分条文1700年3月25日起生效，属于旧法分期生效，非新征服。岛上英方季节性渔场、法方普莱桑斯据点、贝奥图克人自治须分别绘制。1713和约及1729司法机构变化请助手1继续（S79、S80）。
3. **哈德孙湾公司（E6-T10-HBC → E18-C27）**：1713条约与逐堡易手，1715 Thanadelthur参与的跨族群外交，1774 Cumberland House首个内陆贸易站，各自建事件和实际地点。1670年特许的整个Rupert's Land流域不是实控地；助手1逐个堡址核驻军及法方控制断点（S81、S85）。
4. **马德拉斯/孟买/孟加拉/本古伦（E6-T12）**：EIC 1698苏塔努蒂三村的zamindari收益与权责不等于孟加拉主权；1719本古伦地方反抗使公司撤离，1723重建。助手2请逐年复核1668–1709据点、1719–23控制中断及地方主权（S78）。
5. **牙买加马龙（E6-T08 → E18-A05/A11/A12）**：维持马龙社区政治自主，1739条约、1795战争、1796强制流放分开标注，不能以英国统治示意区覆盖整个山区。助手1负责战争、人数、地理（原17C基线SRC17）。
6. **卡罗来纳、纽约、宾夕法尼亚（E6-T09各子篇）**：1715亚马西战争根源与原住民族政治，1712纽约奴役者反抗，1737 Penn家族“Walking Purchase”夺地欺诈，1741纽约被指控阴谋司法案件须以当事人及档案分别审核；不能把指控认定为已证实密谋。助手1补充逐案地契和事件规模（S73、S75、S76、S83）。
7. **非洲贸易公司及运奴船（E6-T11, E6-T13, E6-T17）**：1698皇家非洲公司垄断安排变化不等于奴隶贸易结束。助手1负责船次新世纪分母及马龙，助手2负责西非实控据点；避免把港口交易站当整条海岸内陆治权（S82）。
8. **已确定结束的旧战争**：魁北克英方1629–1632短占、英格兰1650–52征服苏格兰、1691爱尔兰威廉派战争、1692格伦科杀戮、1650–1668英属苏里南、1630–1641普罗维登斯岛。不能用“长期后果存在”生成跨1700仍在进行的旧战役。

## 第三调查员自有研究未解决问题

- **爱尔兰产权**：1703/1704 `2 Anne c.6` 需要逐section审原法全文、真实土地所有权交易与例外；1720 Declaratory Act英方对爱尔兰立法和上诉管辖变化应加入独立政治法权层，不能在版图上画新地块（S53、S53a、S61a）。
- **爱尔兰1798**：Oulart、Enniscorthy、Wexford、Vinegar Hill、Killala、Castlebar、Ballinamuck各有不同军队、受难群体和日期。需核战事报告、各地伤亡及名册；1799立法动议失败，1800通过、1801生效留给下世纪直接续篇（S23、S61）。
- **苏格兰清场**：1780年代第一波高地清场要找有日期可定位的庄园原租约、改良清册及驱逐记录。1809–1821 Sutherland大规模清场属19世纪，不可塞进18世纪（S40）。1746 Culloden、1747服饰限制、1782撤销要拆节点；禁令不能泛化到妇女和军人（NMS-TARTAN）。
- **澳洲1770/1788**：1770库克海岸声索是符号与法律宣称，1788悉尼湾定居只是局部事实。需取得Francis Fowkes早期营地历史图像与足够校正依据，才能尝试1788局部有边界图层。原住民族具体Country名称与地方议会/领袖多方考证（S19、S37c）。
- **澳洲1790–1799**：Arabanoo在1788被拘、1789死；Colbee/Bennelong于1789被抓，需要原档逐案核抓捕地点。1789天花传播源高度争议，不能断言蓄意投毒。1794 Toongabbie战斗与1797 Parramatta战斗不得合并。1794 Hawkesbury定居推进、Norfolk Island、Toongabbie授地、Parramatta、Prospect应建“据点逐年”台账。1797后Pemulwuy抵抗延续1802，1801通缉射杀命令应下世纪接续（S20、S21、S22）。
- **跨三个世纪：16C前史 → 17C → 18C**：1625巴巴多斯及1630s奴役法律与17C糖园扩张、18C压榨相承；1570s私人海盗/公司航线不应被转成17/18C主权海域。16C爱尔兰殖民法律、土地臣属、16C英西海战声索和17C Plantation/强迫劳动应以清晰的“制度持续、战争另立、地籍更迭”三种关系审计。16C未调查或有争议的行政疆界仍为虚线，不能借18C参考层倒灌。跨17C多阶段母项目全部沿原稳定ID链接。

## 1700–1709制图证据缺口（不是27处已核实领土）

- PR #289的27张参考示意图全部已逐年登记，共270条独立年末审核槽位；其中绝大多数停在`not_independently_verified_for_year_end`。这是**待证**，并非控制已消失或已证明持续。
- 逐地点需要找当年驻军名单、行政区官署、判例、各公司获准贸易与实际占领证据；尤其York Factory、Cape Coast、Bombay、Fort St George、Bencoolen、苏塔努蒂与苏格兰Darien，严格区分英国/英格兰/苏格兰、公司、地方政体。
- 对1699年英王特许、1665卡罗来纳向太平洋声索、1670 Rupert's Land流域声索，不能生成任何未经历史地籍证实的实心殖民Polygon。新泽西1702王室接管政治行政是已知性质变化，不是一夜获得现代州境界。

## 给其他助手的明确分流

- **助手1（A/C）**：1710皇家港易手、1713《乌得勒支条约》后阿卡迪亚与Mi'kmaq政权，纽芬兰、HBC、牙买加马龙、Yamasee、Lenape，跨大西洋奴役航次数；请回传旧稳定ID、事件年精度、史料、可测据点与不能涂色的区域。
- **助手2（B/E）**：EIC在孟买/马德拉斯/孟加拉1698三村与1700—1757改权的精确性质，1719本古伦中断与1723再进入；RAC/Cape Coast和其他非洲商站的实地驻军与地方政权；请区分特许、征税、军事管辖及地方主权。
- **主编**：把1700、1702、1707、1710、1713、1719、1723、1799/1801作为年末对照优先锚点；地点旧stable_id必须能逐项追踪，且只有经证的城市核心或真实地籍区才可转正式控制层。本站18C Atlas与浏览器点击/双击/返回的出版测试尚未进行。

**总规则：** 精确位置未知就使用`geometry:null`，历史界线不明只允许明确标注的虚线研究区，**不制造虚假控制面或历史面积**。
'''
md('MISSING_TOPICS.md',missing)
md('CONTROL_RELATION_DECISION_GUIDE.md','''# 1699 → 1709 年末关系判定指南

源档：`CONTROL_TRANSITIONS_1699_1709.json`。27个ID**仅代表旧示意层**, 不是27个历史疆土已核实控制体。每个ID有1700至1709年10条审核，核实层级是“地点/法院/堡垒/军营/税政/文书/原住民族政治主权”，而非旧示意地块。

| 类型 | 1700年核查内容 | 可见的变动或不变 | 地图语义 |
|---|---|---|---|
| 苏格兰达连 | 1699第二远征仍在；1700战败撤出 | 1700年底**苏方临时据点已终结** | 不出现1700年底苏格兰/英国该堡面；当地Guna及西班牙角色区分 |
| 英苏本土 | 两个王国、两个议会直到1707 | 1707-05-01成立大不列颠王国 | 1707年生效以前历史国名区别；不会凭联合新生海外面积 |
| 爱尔兰王国 | 属王冠联系但仍有独立议会的政治体 | 1703/4新立惩罚法、1720议会终审法权转移；1801才联合 | 国名、财政立法和地方土地实际统治三个不同数据层 |
| 新泽西 | 东西两侧领主省治权 | 1702向王室交出省总督治权 | 记录改变的是治理安排；没有历史边界就不画现代NJ填色 |
| 纽芬兰 | 英属季节渔场、法驻军、Beothuk政治及1699法规 | 1700-03-25若干法规条款生效 | 只作法律节点，不是整岛新军事占领 |
| 海岸角、EIC各堡、哈德孙湾 | 特许、商站和堡垒各有差异 | 每个年末驻军/行政登记仍需进一步找原件 | 先研究当地堡垒点或实体；贸易权不等于沿海/流域主权 |
| 卡罗来纳与宾州、弗吉尼亚等 | 王室或领主特许覆盖原住民土地 | 需核具名城镇和地权逐年变动 | 帝国声索虚线与具证实际行政核心相互分层 |

### 史料证据场景

1. 如明确有官员和军队在**某一年末**驻守一个城堡，可核准该城堡**核心点/屏幕面积符号**，仍不自动核准城墙实测Polygon。
2. 如果一项1699史事在1700法律生效，无新的占领史实，应记新法律效力和旧权源关系，不绘新的征服面。
3. 如某一年末仅有旧专题研究截止`1699`和旧图层图块，年末设`null`+`needs_year_specific_sources`，不是`false / destroyed`。
4. 合并政治身份、军事占据、公司特许、地产份额、原住民国家的记录，必须多主体独立字段，禁止“属于英国”一栏吞并。

参考来源：`S72`, `S01`, `S01a`, `S53`, `S61a`, `S79`, `NJ-1702`, `SRCSEED`, `SRC17`，详细链接在来源注册表。

本地CSV/JSON均为`research_only`，不将任何研究层投放到正式主站。
''')
# Provenance level, coverage and packaging notes.
counts={'old_topics':len(old),'annual_candidate_layers':len(trans),'annual_slots':sum(len(c['year_end_reviews']) for c in trans),'dossiers_d':10,'dossiers_f':9,'dossiers_cross_century':len(CONT),'candidate_events':len(events),'place_records':len(features),'modern_georeference_points':sum(bool(f['geometry']) for f in features),'source_records':len(sources)}
progress=f'''# 爱英TV｜第三调查员交接进度（2026-11-08）

## 阶段性成果

- 核对GitHub `AGENTS.md`、两个政治/空间连续性规范、16世纪参考ZIP、PR #289主研究清单、17世纪36个专题列表及研究交接。当前PR #289 HEAD：`492a153aa181517edea47877e6b7c83951412e43`（草稿研究PR，不作为已出版18C Atlas）。
- `CROSS_CENTURY_AUDIT.json`：**{counts['old_topics']}条17C原故事稳定ID**逐一核，7项后果、18项制度连续、7项研究母项目、2项真正跨世纪行为、2项已结束旧殖民活动；旧文章研究截止与真实历史终止分别记录，缺证的真实终止年为`null`。
- `CONTROL_TRANSITIONS_1699_1709.json`：旧参考层**{counts['annual_candidate_layers']}个候选×10年={counts['annual_slots']}个年末审核槽位**。已有的部分特殊断点是1700达连撤离与1702新泽西行政权调整、1707英苏政治联合；绝大多数逐年实际驻军、财税治理和界线仍**待核**。这不是270条确认持续占领记录。
- `TOPIC_DOSSIERS/`：D01–D10十篇、F01–F09九篇，以及跨世纪连续性专题九篇，**共{19+counts['dossiers_cross_century']}篇研究档案**；按来源、已核事实、时间和下一步原档任务分类。
- `EVENT_CANDIDATES.json`/`.csv`：**{counts['candidate_events']}条候审事件或明确标作`multi_year_research_scope`的时段条目**；具体主体、日期精度、地点、来源、政治行为、地图候审状态分列；非正式18C Atlas IDs。
- `MAP_CANDIDATES.geojson`：**{counts['place_records']}处历史地理参考/具名地点，其中仅{counts['modern_georeference_points']}处经过独立外部来源核对的现代参考Point**（Sydney Cove、Culloden、Vinegar Hill），其余`geometry:null`等待地理考证。零条虚构海上航迹，零个实控Polygon。
- `SOURCE_REGISTRY.json`：**{counts['source_records']}条直接用过的馆藏、国家博物馆、学术资料、网站及本项目GitHub来源记录**，源URL与查阅级别各自保存；PR #289原88源研究目录作为独立源库关联，不将网页说明伪装成档案逐页原卷。
- `MISSING_TOPICS.md`：三世纪承接缺口、需要助手1/2回报的疑点及跨阶段地理风险清单。
- `CONTROL_RELATION_DECISION_GUIDE.md`：政治主体、贸易特许、法律、驻军和原住民自主不同图层的年末处理方法。
- `build_research.py`：本次本地可复查数据构建脚本，在资料包内保留；未连接/修改GitHub写入端。

## 证据成熟度

**已核/可作为候审事件：** 1700达连撤离、1707政治合并、1770库克声索、1788悉尼定居、1788/89强制抓捕、1790McIntyre与惩罚命令、1794 Toongabbie、1797 Parramatta、1798爱尔兰起义及战场年序、1799联合提案遭否决等有机构公开资料支持的分段事实。

**继续研究、不得以精准事实生产地图：** 1700达连投降具体日、1788营地地籍、1789天花病原传播链、1788至1799逐田产地权变动、爱尔兰宗教法律逐条财产实际执行、清场具体庄园剥夺人数、部分1800年前公司堡垒逐年驻军。地图地理Point**仅是现代位置参考**而非事发处GPS。

## 任务余项

1. 研究主编批注：不要用研究数据直接生成正式`data/atlas-1700-1709.json`，更不能以旧27图形充历史占领范围。
2. 对27项参考图层逐处取得1700–1709官署/驻军/地权史料，按史料核实有效年份后给出增、减、换手或待核状态。
3. 澳洲需核最初殖民营地、1794 Hawkesbury、1801和1802 Pemulwuy后续；爱尔兰需研1704原法与1798具体平民命册，苏格兰需研1700西班牙及Guna原档、1780s清场庄园原账。
4. 与其他两位调查员合并源链但避免重复计算：A/C北美加勒比从助手1输入，B/E亚洲非洲从助手2输入。完整18C Atlas、桌面地图事件交互、严格GeoJSON空间审核尚待主编执行。

## 保存与交付

- 当前本地研究目录：`/mnt/data/18c_assistant_C/`。
- 最终归档：`/mnt/data/18c_assistant_C_continuity_australia.zip`。
- **GitHub 无新增分支、提交、Issue或PR，本助手全程只读。**
- 全部成果标记 `research_only`，不存在任何正式出版宣告。
'''
md('PROGRESS.md',progress)
md('README.md','''# 18世纪第三调查员研究数据包

**研究范围：** 17C→18C连续性与1699–1709年末政治控制审核、澳洲D01–D10、爱尔兰苏格兰F01–F09。

本文件夹是研究候审成果，不是生产站点的地图数据库。请先读`PROGRESS.md`和`MISSING_TOPICS.md`，再读机器数据与`TOPIC_DOSSIERS/`。所有事件使用第三调查员研究ID (`C-DXX-...`/`C-FXX-...`)，不得与未来主编正式Atlas事件ID混淆。

## 文件

- `CROSS_CENTURY_AUDIT.json` — 36项旧专题（历史结束与旧研究截止分开）
- `CONTROL_TRANSITIONS_1699_1709.json` — 27幅候审参考图形 × 10年逐年缺口与已证变更
- `TOPIC_DOSSIERS/` — 19篇全部D/F专题分析 + 9篇跨世纪专项
- `EVENT_CANDIDATES.json`, `.csv` — 事件/阶段研究账本（明确年份精度）
- `SOURCE_REGISTRY.json` — 来源与原卷访问级别、链接，接上游PR #289的88条清单
- `MAP_CANDIDATES.geojson` — 地理候审位置：3个具现代参考坐标点，其余`null`；无历史边界Polygon
- `CONTROL_RELATION_DECISION_GUIDE.md` — 制图和证据规则
- `MISSING_TOPICS.md` — 重大漏项与其他两位调查员协作任务
- `PROGRESS.md` — 本轮成果、证据等级、未解决问题
- `QA_REPORT.json` — 本地结构完整性检查
- `build_research.py` — 本地生成源代码，可重跑生成文件；非GitHub操作脚本

## 重要区分

17世纪研究窗停在1699年不表示历史制度截止1699；1700达连军事实控终结与1707两王国联合分成不同事件。1707年前苏格兰仍是独立王国，爱尔兰直到1801年才正式合并；1770东海岸声索绝非英国当时已实际控制澳洲大陆。

GIS只记录史事具名地理、现代来源可追的点，不使用现代州、郡、流域或大陆轮廓冒充历史殖民实控范围。正式主站上的点击/双击和返回尚未做18C版本浏览器验证。
''')
print('SAVED stage 6 progress and missing topics; metrics',counts,flush=True)
