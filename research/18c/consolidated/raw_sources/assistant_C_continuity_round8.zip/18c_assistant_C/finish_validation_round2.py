"""Final append-only QA preparation, without overwriting historical evidence."""
from pathlib import Path
import json,csv
p=Path('/mnt/data/18c_assistant_C')
e=json.loads((p/'EVENT_CANDIDATES.json').read_text(encoding='utf-8'))
keys=['id','topic_id','date','date_precision','title','actor','action','historical_place','source_ids','research_state','cartographic_status','geometry_ref','historical_control_polygon_approved','evidence_notes']
with (p/'EVENT_CANDIDATES.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=keys); w.writeheader()
 for x in e['events']:
  w.writerow({k:(';'.join(x[k]) if k=='source_ids' else str(x[k]) if x.get(k) is not None else '') for k in keys})
script=p/'validate_local.py'
s=script.read_text(encoding='utf-8')
s=s.replace("check('Event 57 unique IDs',len(ids)==len(set(ids))==57)","check('Event identifiers unique and >= 89',len(ids)==len(set(ids)) and len(ids)>=89)")
s=s.replace("check('CSV and JSON event IDs aligned',len(cc)==57 and {x['id'] for x in cc}==set(ids))","check('CSV and JSON event IDs/topics aligned',len(cc)==len(ids) and {(x['id'],x['topic_id']) for x in cc}=={(x['id'],x['topic_id']) for x in e['events']})")
s=s.replace("check('19 geographical entries, only 3 points',len(g['features'])==19 and sum(bool(x['geometry']) for x in g['features'])==3)","check('26 named localities and only 3 sourced modern Point references',len(g['features'])==26 and sum(bool(x['geometry']) for x in g['features'])==3)")
needle="check('No false Atlases publication labels',all(x['research_state']=='research_only' and x['historical_control_polygon_approved'] is False for x in e['events']))"
extra="""check('87 source registrations minimum',len(source_ids)>=87)
bridges=read('TRIPLE_CENTURY_BRIDGES.json')
claims=read('CLAIM_EVIDENCE_MATRIX.json')
bridge_ids=[x['id'] for x in bridges['bridges']]
claim_ids=[x['id'] for x in claims['claims']]
check('Eight unique triple-century bridge comparisons',len(bridge_ids)==len(set(bridge_ids))==8)
check('20 source-linked claim evidence checks',len(claim_ids)==len(set(claim_ids))==claims['evidence_count']==20)
check('Triple-century source references registered',not set(sid for x in bridges['bridges'] for sid in x['source_ids'])-source_ids)
check('Claim evidence source references registered',not set(sid for x in claims['claims'] for sid in x['source_ids'])-source_ids)
with (p/'CLAIM_EVIDENCE_MATRIX.csv').open(encoding='utf-8-sig',newline='') as f: claim_csv=list(csv.DictReader(f))
check('Claim evidence matrix CSV rows',len(claim_csv)==20)
check('All new source access types explicitly noted',all('access_level' in src and 'original_manuscript_personally_inspected' in src for src in s['sources']))
check('No cross-domain check mis-assigned to Virginia code E18-C22',all(x['topic_id']!='E18-C22' for x in e['events'] if x['id'] in ('C2-C22-001','C2-C22-002')))
"""
s=s.replace(needle,extra+'\n'+needle)
s=s.replace("check('No empty source URLs',all(x['url'].startswith('https://') for x in s['sources']))", "check('No empty source URLs',all(x['url'].startswith('https://') for x in s['sources']))")
s=s.replace("check('No invented numeric precision',all(x['geometry'] is None or len(x['geometry']['coordinates'])==2 for x in g['features']))", "check('No invented numeric precision',all(x['geometry'] is None or len(x['geometry']['coordinates'])==2 for x in g['features']))")
s=s.replace("'checked_objects':{'old_story_ids':len(aids)","'checked_objects':{'old_story_ids':len(aids)")
script.write_text(s,encoding='utf-8')
print('Prepared dynamic event CSV and enhanced validation')
