# 候审补题 E18-D11-PROPOSED｜悉尼湾与Hawkesbury原住民水路反抗（1788—1799）

**这不是PR #289已存在的正式D11；只是助手3提出的候审缺口，等待主编决定是否新增。**

原E18-D07专题锁定Pemulwuy / Bidjigal从1792年的抵抗。1788年独木舟被抢、1791年Balloderry的反抗、1795—1797 Hawkesbury水上袭击都**没有可靠证据证明全部由Pemulwuy领导**。因此将8件本轮候审记录独立为C4-D11-001…008，避免虚构共同指挥。

主要机构证据：Australian National Maritime Museum [Contested Waterways](https://www.sea.museum/en/first-nations/contested-waterways)（SOURCE_REGISTRY ID C4-AU-ANMM-WATER）。

行动分三段：1788殖民流放者强留nawi与Okey/Davis死亡争议；1790年Bennelong与渔获/船只紧张关系、1791年Balloderry毁舟后报复；1795、1797年Darug与Darkinjung Country水域的船艇冲突及殖民军护航。

待核：各个群体自称与具体Country；Collins/Tench原日记各页；具体舟船数及人命；是否属于同一族群连续军事组织；所有精确海河路线的历史证据。地图最多使用具名地理参考点或null，不画河面控制Polygon。

## 第六轮海事博物馆专题补证
澳大利亚国家海事博物馆以White、Collins、Tench等同时代记录，分别指出1788年5月扣舟争端、8月山羊争端、9月Dawes Point舟上群体与殖民羊群、1789年夺舟后舵手遇袭、1790年12月原住民乘舟规避惩罚队、1791年英国船武装通行及港口排斥、1795与1797年Hawkesbury河运船被袭。上述是不同年份具名行动；1788年Bloody Point位置是博物馆从Bradley的当时海图提出的历史解释，不能升格成古代战斗坐标。

勿从殖民记载推定全部遭袭人数或伤亡，也勿将原住民水上抵抗简单归入Pemulwuy一人。数据：`C6-D11-001`—`004`及旧`C4-D11-*`，来源 `C4-AU-ANMM-WATER`。
