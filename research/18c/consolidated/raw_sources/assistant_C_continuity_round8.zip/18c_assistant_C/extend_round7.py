#!/usr/bin/env python3
"""Round 7: additional major-impact history, original corpus retained; research only."""
from pathlib import Path
import json,csv,hashlib,zipfile,collections,datetime,os
ROOT=Path('/mnt/data/18c_assistant_C')
TODAY='2026-11-08'
def read(n):return json.loads((ROOT/n).read_text(encoding='utf-8'))
def dump(n,obj): (ROOT/n).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
sources=read('SOURCE_REGISTRY.json'); events=read('EVENT_CANDIDATES.json'); places=read('MAP_CANDIDATES.geojson'); claims=read('CLAIM_EVIDENCE_MATRIX.json')
new_sources=[
 ('C7-S01','New South Wales State Library','Second Fleet convict deaths, 1790','https://guides.sl.nsw.gov.au/convicts-bound-for-australia/second_fleet','institutional_research_guide'),
 ('C7-S02','National Museum of Australia','Convict transportation from America to Australia, 1717–1788','https://www.nma.gov.au/defining-moments/resources/convict-transportation-peaks','museum_historical_research'),
 ('C7-S03','National Archives of Ireland','Transportation of Irish convicts 1791–1853 research guide','https://nationalarchives.ie/wp-content/uploads/2025/01/Ireland_Australia_transportation.pdf','archival_research_guide_pdf_extract_only'),
 ('C7-S04','National Museum of Australia','Castle Hill rebellion and 1798 Irish exiles','https://www.nma.gov.au/defining-moments/resources/castle-hill-rebellion','museum_historical_analysis'),
 ('C7-S05','NSW Migration Heritage Centre','1787 instructions and purported NSW colony legal bounds','https://www.migrationheritage.nsw.gov.au/exhibition/objectsthroughtime/draughtinstructions/index.html','primary_source_contextual_institutional_explanation'),
 ('C7-S06','Parramatta City Council','Burramattagal dispossession and Rosehill chronology','https://historyandheritage.cityofparramatta.nsw.gov.au/research-topics/events/parramattas-foundation-story','local_government_historical_explanation'),
 ('C7-S07','Parramatta City Council','Old Government Farm, Toongabbie, April 1791','https://historyandheritage.cityofparramatta.nsw.gov.au/blog/2015/06/05/oaks-reserve-old-toongabbie','local_government_site_history'),
 ('C7-S08','Parramatta City Council','Rosehill Macarthur grant 1793 and traditional owners','https://historyandheritage.cityofparramatta.nsw.gov.au/research-topics/suburbs/rosehill-brief-history','local_government_site_history'),
 ('C7-S09','National Museum of Australia','1797 merino sheep introduction','https://www.nma.gov.au/defining-moments/defining-moments-timeline','museum_chronology'),
 ('C7-S10','Irish Historical Studies / Cambridge University Press','Whiteboy movement, 1761–65','https://www.cambridge.org/core/journals/irish-historical-studies/article/abs/whiteboy-movement-17615/51FA8CC01E50A1784078B5A38581D400','peer_reviewed_abstract_and_extract'),
 ('C7-S11','Environment & Society Portal / Climate of the Past','Ireland 1740–1741 famine climate and vulnerability','https://www.environmentandsociety.org/mml/irish-famine-1740-1741-famine-vulnerability-and-climate-migration','peer_reviewed_article_abstract'),
 ('C7-S12','Cambridge University Press / International Review of Social History','Review of Famine in European History, Irish 1740–41 mortality estimates','https://www.cambridge.org/core/journals/international-review-of-social-history/article/famine-in-european-history-ed-by-guido-alfani-grada-corman-o-cambridge-university-press-cambridge-etc-2017-xi-325-pp-maps-6999-paper-2399/102EC302166801BD24D6AB0650EDF798','peer_reviewed_book_review'),
 ('C7-S13','UK Parliament','Irish constitutional conflicts, 1699 wool 1720 dependency Wood coinage','https://www.parliament.uk/about/living-heritage/evolutionofparliament/legislativescrutiny/parliamentandireland/overview/constitutional-differences/','parliamentary_history'),
 ('C7-S14','Ulster University CAIN','1795 Diamond battle and 1797 martial law','https://cain.ulster.ac.uk/othelem/chron/ch1169-1799.htm','university_historical_chronology'),
 ('C7-S15','History Ireland','1798 Ulster battle campaign and short-lived Ballymena administration','https://historyireland.com/1798-in-the-north/','expert_history_article'),
 ('C7-S16','Discover Ulster-Scots','Presbyterians and 1798 revolt','https://discoverulsterscots.com/history-culture/story-presbyterians-ulster','institutional_community_history'),
 ('C7-S17','Heritage Ireland / OPW','Dwyer McAllister 15 February 1799 Wicklow continued resistance','https://heritageireland.ie/educational-downloads/dwyer-mcallister-cottage/','government_heritage_site'),
 ('C7-S18','National Army Museum','1798 military counterinsurgency and atrocities','https://www.nam.ac.uk/explore/irish-rebellion-1798','military_museum_history'),
 ('C7-S19','National Army Museum','1715 and 1719 Jacobite risings and government military roads','https://www.nam.ac.uk/explore/jacobites','military_museum_history'),
 ('C7-S20','Historic Environment Scotland','Glenshiel historic battlefield listing, NGR NH 996 137','https://portal.historicenvironment.scot/apex/f?p=1505%3A300%3A%3A%3A%3A%3AVIEWTYPE%2CVIEWREF%3Adesignation%2CBTL10','designated_historical_battlefield_record'),
 ('C7-S21','National Trust for Scotland','Culloden Learning Resource p13 prisoners and Proscription','https://ntswebstorage01.blob.core.windows.net/nts-web-assets-production/downloads/Culloden_Learning_Resource.pdf','museum_educational_pdf_extract_not_original_archival'),
 ('C7-S22','National Records of Scotland','Knight v Wedderburn 1774–1778 primary court document overview','https://www.nrscotland.gov.uk/learning-and-events/slavery-and-scotland/the-joseph-knight-case/','archival_summary_and_partial_transcript'),
 ('C7-S23','Judiciary of Scotland','Knight v Wedderburn decision 15 January 1778 and court tally','https://www.judiciary.scot/home/media-information/media-hub-news/2022/12/06/plaque-marks-historic-slavery-case-at-court-of-session','judicial_institutional_history'),
 ('C7-S24','National Museums Scotland','Scottish links to enslavement, Dundas 1792, 1793 Leith Bank','https://www.nms.ac.uk/discover-catalogue/scotland-and-the-transatlantic-slave-system','national_museum_object_research'),
 ('C7-S25','National Museums Scotland','1769 domestic slave sale ad, Scottish Caribbean plantations','https://www.nms.ac.uk/discover-catalogue/the-experiences-of-enslaved-people','national_museum_object_research'),
 ('C7-S26','Oxford University Press / American Journal of Legal History','Glasgow tobacco trade and enslavement, import 1769 52%','https://academic.oup.com/ajlh/article/63/2/150/7231728','peer_reviewed_academic_study'),
 ('C7-S27','Scottish History Society','Highland Clearances c1750–20th-century chronology and source limitations','https://scottishhistorysociety.com/the-highland-clearances/','scholarly_society_analysis'),
 ('C7-S28','National Museums Scotland','Darien failure and Union Equivalent £398085 10s','https://www.nms.ac.uk/discover-catalogue/the-darien-scheme','national_museum_history'),
 ('C7-S29','The National Archives (UK)','Criminal transportation guide, 1776–1788 disruption and new Australian destination','https://www.nationalarchives.gov.uk/help-with-your-research/research-guides/criminal-transportation/','archive_guide'),
 ('C7-S30','National Archives of Ireland','Rebellion Papers CSO/REB/620 and state papers 1790–1808','https://nationalarchives.ie/help-with-research/research-guides/the-rebellion-papers/','official_archive_finding_aid'),
 ('C7-S31','National Museum of Australia','Aboriginal resistance Pemulwuy through 1802','https://www.nma.gov.au/defining-moments/resources/pemulwuy','national_museum_historical_explanation'),
 ('C7-S32','National Trust for Scotland','National Culloden source early state suppression overview','https://www.nts.org.uk/visit/places/culloden','heritage_site_overview'),
]
url_to_id={s.get('url'):s['id'] for s in sources['sources']}
for sid,inst,title,url,access in new_sources:
 if url in url_to_id: continue
 sources['sources'].append({'id':sid,'institution':inst,'title':title,'url':url,'access_level':access,'original_manuscript_personally_inspected':False,'reviewed_online_on':TODAY,'research_note':'Referenced online research-level institutional or peer reviewed text; no claim of reading inaccessible full archival originals.'})
 url_to_id[url]=sid
sources['source_count']=len(sources['sources'])
# Alias not yet originally in registry allowed only if entry appended above
source_alias={sid:url_to_id[url] for sid,_,_,url,_ in new_sources}
# Each new candidate contains a specific historical action; exact dates only where source supports.
E=[
# political and transportation chain
('C7-TRANS-1717','E18-D02','1717','year','英国建立规范化罪犯海外流放法制','大不列颠议会','1717运输法明确7年与14年刑期；美洲殖民地成为主要目的地','伦敦／英格兰议会','C7-S02;C7-S29','political_legal_context','PLACE-WESTMINSTER','英属美洲流放先于1788澳洲；不可绘作1717澳大利亚殖民。'),
('C7-TRANS-1785','E18-D02','1785','year','英国枢密院筹建新南威尔士罪犯殖民地','英王枢密院／英方行政机关','发布筹建流放殖民地的Orders in Council（馆方编年）','伦敦／新南威尔士纸面拟议地','C7-S02','legal_claim_only','PLACE-WESTMINSTER','决定殖民地点不能证明1785年已在澳洲驻军。'),
('C7-TRANS-1786','E18-D02','1786-10-12','day','Arthur Phillip获任新南威尔士总督','英王与皇家海军','任命殖民总督并开始组织第一舰队','伦敦／英格兰','C7-S02','legal_administrative_not_land_control','PLACE-WESTMINSTER','任命当日未有澳洲实际驻点。'),
('C7-D01-1787-INSTR','E18-D01','1787-04-25','day','Phillip治理指示给新南威尔士宽泛法定经度声索','英王政府及殖民行政官','草拟殖民辖域至东经135度，要求管理流放犯及对原住民维持友好','伦敦；新南威尔士图上声索','C7-S05','paper_claim_only','PLACE-WESTMINSTER','135度只是拟议文书声索经线，不生成控制Polygon。'),
('C7-D02-1790-SECOND','E18-D02','1790','year','第二舰队极端苛刻运输导致大量囚犯途中死亡','运输合约承包者与英方流放体系','第二舰队男性流放者约1250，逾四分之一在航途中死亡；抵岸幸存者大批住院','英格兰港口—悉尼湾','C7-S01','no_route_geometry','PLACE-SYDNEY','约1250和逾25%来自州立图书馆综述；不编造分船人数和死者精确定位。'),
('C7-D10-1791-FARM','E18-D10','1791-04','month','政府在Toongabbie建立较大农业劳役农场','新南威尔士殖民总督与流放犯劳役体系','设立政府农场、清地开垦并依靠流放犯劳动','Toongabbie，Dharug传统土地','C7-S07;C7-S06','local_settlement_not_area_polygon','PLACE-TOONGABBIE','建立农场说明局地定居活动；无原始地块图不可画圈作耕地面积。'),
('C7-D10-1793-MAC','E18-D10','1793','year','John Macarthur取得Rosehill地区授地并建立Elizabeth Farm','新南威尔士殖民行政当局及John Macarthur','授出约100英亩并在当年营建农舍，建立私人殖民地产','Rosehill／Parramatta，Dharug土地','C7-S08','individual_grant_without_survey_polygon','PLACE-PARRAMATTA','100英亩来自市政史，不自动扩成Hawkesbury/整州领土。'),
('C7-D10-1797-MERINO','E18-D10','1797-07-01','day','美利奴羊引进奠定澳洲殖民羊毛经济后续扩张基础','殖民牧畜者','引进美利奴羊种并逐步改良，后世牧羊开拓加剧土地压力','新南威尔士（具体初次引进点需核）','C7-S09','regional_reference_only','', '年度事实可核但不得用后世牧场覆盖1797年；具体传播地点与头数待核。'),
('C7-D10-1788-DISPOS','E18-D10','1788','year','Rose Hill殖民扩张破坏Burramattagal食物与地权','殖民总督、驻兵及被强制派工者','清林、铲除山药、开垦，挤占Dharug的狩猎采集和生活地点','Rose Hill／Parramatta','C7-S06;C7-S08','contextual_local_dispossession','PLACE-PARRAMATTA','行动为逐期过程，非单一精确日或可测占地多边形。'),
('C7-D02-1791-IRISH','E18-D02','1791-04','month','首批从爱尔兰直接出航的新南威尔士流放船启航','爱尔兰王国政府与英方帝国流放网络','爱尔兰议会1786/1790年流放制度调整之后，第一船约1791年4月启航','爱尔兰港口→新南威尔士','C7-S03','origin_destination_no_ship_route','', '档案指南支持月份，具体船名和启航港应核原船册。'),
('C7-IRL-1786-TRAN','E18-F06','1786','year','爱尔兰议会通过自身的海外流放法律','爱尔兰王国议会','26 Geo III c24允许将囚犯流放欧洲之外，尚不能直接套用英格兰1784法律','都柏林','C7-S03','institutional_legal','PLACE-DUBLIN','区别两个王国各自立法。'),
('C7-IRL-1790-TRAN','E18-F06','1790','year','爱尔兰议会修订囚犯海外流放执行程序','爱尔兰王国议会','30 Geo III c32便利流放执行，为1791年从爱尔兰启航铺路','都柏林','C7-S03','institutional_legal','PLACE-DUBLIN','法律阶段不同于1791年实际首航。'),
# Ireland land, economy, resistance
('C7-IRL-1722-WOOD','E18-F02','1722','year','英国政府授予William Wood向爱尔兰铸铜币特许','英王政府与商人William Wood','批出向爱尔兰供应铜币的特许，引发当地宪制和货币争议','爱尔兰王国与英格兰','C7-S13','legal_claim_not_new_occupation','PLACE-DUBLIN','不能直接叫作已经证实大规模牟利金额；来源为议会历史。'),
('C7-IRL-1723-DRAPIER','E18-F02','1723','year','爱尔兰出现反对William Wood铜币的抗议','爱尔兰城镇反对者与作家Jonathan Swift','组织公共反对并出版相关宣传作品（1723起的运动）','都柏林／爱尔兰','C7-S13','political_protest','PLACE-DUBLIN','抗议运动非军事占领，Swift具体小册子年份勿全套记1723。'),
('C7-IRL-1740-FAMINE','E18-F01','1740','year','1740—1741年严寒歉收触发爱尔兰大饥荒','气候冲击与爱尔兰既有经济社会结构','1740严寒、粮价上涨，延续1741饥荒和移民','爱尔兰王国（多个地方）','C7-S11;C7-S12','multi_region_context_no_polygon','', '1740—1741跨年过程；死亡数为史家估计，不能说英国政府蓄意制造。'),
('C7-IRL-1761-WHITE','E18-F01','1761-10','month','Whiteboys在蒂珀雷里边缘反抗围占公地与什一税','爱尔兰Whiteboys农民结社、地产地主与什一税承包人','夜间集会拆毁围栏、反对公地圈占与新增征收','Knockmealdown／Clogheen—Ballyporeen周边','C7-S10','regional_agrarian_protest','', '学术研究确认1761年末初起，地理多镇不能编造成单个斗争精确点。'),
('C7-IRL-1762-WHITE','E18-F01','1762','year','Whiteboys土地与税赋抗争扩展到蒙斯特多个聚落','Whiteboys农民网络与爱尔兰地主体系','围栏拆除、集会与抵抗向Kilmallock、Bruff等地扩展','蒙斯特多地','C7-S10','multi_site_not_polygon','', '不可描绘为同一连续军事战线或统一组织控制区。'),
('C7-IRL-1795-DIAMOND','E18-F06','1795-09-21','day','Armagh宗派团体在Battle of the Diamond冲突','Defenders与Peep o’ Day Boys等团体','在Loughgall附近发生战斗，之后Orange Order成立','Loughgall／The Diamond，Armagh','C7-S14','sectarian_conflict_not_crown_battle','', '责任多主体，不能将所有宗派冲突归于正规英军命令。'),
('C7-IRL-1797-MARTIAL','E18-F06','1797','year','爱尔兰政府在1798起义前扩大军事戒严与解除武装','爱尔兰政府、英军、民兵、Yeomanry','在爱尔兰多地实施戒严、搜捕、军事反叛乱与酷刑','爱尔兰王国（各郡）','C7-S14;C7-S18','institutional_repression_no_region_polygon','', '需逐郡查军方命令与强制行动，不把全岛画成战时占领变动。'),
('C7-IRL-1798-ANTRIM','E18-F06','1798-06-07','day','Antrim起义军短暂攻入城镇后遭政府军反击','Henry Joy McCracken麾下联合爱尔兰人及王室军队','起义军对Antrim发动进攻并短暂在镇内交战，政府增援部队收复','Antrim town，Ulster','C7-S15;C7-S16','contested_short_episode_no_polygon','', '短时易手/部分街区不能据此绘制全郡起义军稳定地块。'),
('C7-IRL-1798-BALLYMENA','E18-F06','1798-06-07','day','起义军占据Ballymena并短时组建治理委员会','当地联合爱尔兰人','约三天占据城镇并组织临时政治委员会，之后接受当局赦免条件','Ballymena，Antrim郡','C7-S15','short_local_regime_core_review','', '约三日为史学叙述，不精造结束日；需原始驻军记录。'),
('C7-IRL-1798-SAINTFIELD','E18-F06','1798-06-09','day','Saintfield起义军伏击迫使政府军撤退','County Down联合爱尔兰人和政府York Fencibles','伏击殖民政府军队，后续起义军集结Ballynahinch','Saintfield，Down郡','C7-S15','battle_not_sustained_territory','', '单次战斗胜利不等于后续政治统治。'),
('C7-IRL-1798-MCCRACKEN','E18-F06','1798-07-17','day','Antrim起义领袖Henry Joy McCracken被处决','爱尔兰王室军事司法系统','俘获McCracken后经审讯在贝尔法斯特绞刑','Belfast','C7-S15;C7-S16','execution_reference','', '用正式城市地点参考，具体刑场位置需进一步核原始档。'),
('C7-IRL-1799-DWYER','E18-F06','1799-02-15','day','Michael Dwyer在Wicklow山区逃脱政府军搜捕','起义余部Michael Dwyer、Sam McAllister与政府军','McAllister牺牲掩护Dwyer逃出，当地游击抵抗持续到19世纪初','Dwyer McAllister Cottage，Wicklow山区','C7-S17','historic_site_reference','', '1798起义实际行动并未全部在1798年12月停止，另存1800—1803续篇。'),
# Scottish military / dislocation
('C7-SCT-1715-SHER','E18-F04','1715-11-13','day','Sheriffmuir发生詹姆斯党与政府军大会战','詹姆斯党Mar军与阿盖尔公爵政府军','两军会战并于其后分别退兵；1715起义延续至1716初','Sheriffmuir，Perthshire','C7-S19','battle_needs_local_map_review','', '国家陆军博物馆用词有胜负简化，需Historic Environment Scotland地图独立审查。'),
('C7-SCT-1719-EILEAN','E18-F04','1719-05','month','英方海军攻击并毁坏Eilean Donan城堡据点','英王海军与詹姆斯党／西班牙支持者','海军炮击和摧毁詹姆斯党军事指挥据点','Eilean Donan，Loch Duich','C7-S19;C7-S20','named_castle_battle_reference','', '1719战事而非1745詹姆斯党持续同一战役。'),
('C7-SCT-1719-GLEN','E18-F04','1719-06-10','day','Glenshiel战役结束1719詹姆斯党起义','英国政府军与詹姆斯党、少量西班牙军','政府军击败山谷防线，其后西班牙分队投降','Glenshiel，Highlands','C7-S20;C7-S19','official_battlefield_reference_only','PLACE-GLENSHIEL','现代战场清单边界是考古景观，不是1719英国主权地籍；可参考HES NGR中心点。'),
('C7-SCT-1746-PROSC','E18-F04','1746-08-01','day','《禁止法》对高地实施武器及服饰限制','英国议会／高地驻军','在1716缴械制度基础上强制限制武器携带并规定惩罚','苏格兰高地','C7-S21','statute_social_control_no_polygon','', '准确条款不同处罚各异；穿着限制与此前研究记1747执行要区分。'),
('C7-SCT-1746-DEPORT','E18-F04','1746','year','卡洛登战后詹姆斯党嫌疑人被监禁并强制运往海外','英国政府军及军事司法当局','逮捕数千人，部分被处决，936名幸存者被流放以供契约劳役（信托馆方口径）','苏格兰、英格兰监狱、海外流放目的地','C7-S21','multi_site_transport_not_route','', '936源为信托资源整理数字，不得称同一艘船的流放人数或与死亡数相加。'),
('C7-SCT-1769-AD','E18-F08','1769-01-20','day','爱丁堡报纸刊载转让被奴役黑人少年的广告','苏格兰个人奴役持有人、报纸广告商','公开登载把一名年幼黑人家仆当作可处分财产的广告','爱丁堡','C7-S25','material_culture_evidence','', '广告反映欲处分行为，不默认交易成交或该少年的后续命运。'),
('C7-SCT-1774-KNIGHT','E18-F08','1774-05-20','day','Joseph Knight在Perth获得反对永久奴役的重要有利裁决','Joseph Knight及Perth郡法院','地方法院反对殖民地奴役权在苏格兰执行，Wedderburn提起上诉','Perth，Scotland','C7-S22','court_event_core_point_reference','', '诉讼延续到1778；日期对应Perth郡法庭摘录。'),
('C7-SCT-1778-KNIGHT','E18-F08','1778-01-15','day','苏格兰最高民事法院确认Joseph Knight摆脱永久强制劳役','苏格兰Court of Session与Joseph Knight','确认牙买加种植园主对Knight主张的永久劳役和强制送离苏格兰权利不可执行','爱丁堡，苏格兰最高民事法院','C7-S22;C7-S23','court_event_core_point_reference','', 'NRS写8比4，司法机构写10比4，应保留冲突，不以票数判断判决的有无。'),
('C7-SCT-1769-TOBACCO','E18-F08','1769','year','克莱德河三大港口承担英国烟草进口的约52%','格拉斯哥商人与被奴役劳动支持的切萨皮克贸易网络','Glasgow、Greenock、Port Glasgow合计英国当年烟草进口约52%','格拉斯哥与克莱德河港口','C7-S26','statistical_flow_not_territory','', '52%为英国烟草进口份额，不是英国奴隶贸易航次占比、非法制实控面积。'),
('C7-SCT-1792-DUNDAS','E18-F08','1792','year','Henry Dundas促使立即废除贩奴贸易提案改为渐进方案','英国政府内阁成员Henry Dundas与英国议会','推动对废奴贸易提案加入渐进条款；改变当时议会方案的立法进程','伦敦议会；苏格兰政治网络','C7-S24','political_legislative_action','PLACE-WESTMINSTER','NMS对动机/后果提供分析，正式文本及议会表决需进一步逐页复核。'),
('C7-SCT-1793-LEITHBANK','E18-F08','1793','year','Leith Banking Company由有殖民商人背景的合伙人创立','Leith银行合伙人、部分殖民商人','18名合伙人建立银行，体现苏格兰金融与殖民贸易的关系','Leith，Edinburgh','C7-S24','commercial_institution_not_slave_ownership','', '不能把18名合伙人全认定奴隶主；逐人股权与贷款档案待核。'),
('C7-SCT-1794-MITCHELL','E18-F08','1794','year','牙买加种植园主向Doune教区教堂捐赠圣餐杯','William Mitchell及Kilmadock教会','在苏格兰当地捐赠器物，反映海外种植园财产与本土社会联系','Doune／Kilmadock，苏格兰','C7-S24','evidenced_object_provenance','', '物证可核，杯子本身不等于已审核种植园利润净额。'),
('C7-SCT-1796-CARIB','E18-F08','1796','year','Henry Dundas担任殖民战争大臣时英军干涉加勒比殖民秩序','英国战争与殖民部、英国远征军','推进牙买加等西印度群岛军政行动并干预海地摆脱奴役过程','伦敦／加勒比（多地）','C7-S24','cross_region_handoff_only','', '具体海地、圣文森特、牙买加军次交助手1；不能在苏格兰地图画跨洋军事控制。'),
]
existing_ids={e['id'] for e in events['events']}
new_ledger=[]
for eid,tid,date,prec,title,actor,action,place,sids,mapstatus,geom,note in E:
 if eid in existing_ids:continue
 refs=[source_alias[s] for s in sids.split(';')]
 row={'id':eid,'topic_id':tid,'date':date,'date_precision':prec,'title':title,'actor':actor,'action':action,'historical_place':place,'source_ids':refs,'research_state':'research_only','cartographic_status':mapstatus,'geometry_ref':geom or None,'historical_control_polygon_approved':False,'event_continues_1699_story_id':None,'evidence_notes':note,'round_added':7,'map_note_update':'No control polygon; local politics, territorial authority and reference site geometry reviewed independently.','evidence_phase':'round7_research_review','original_folio_personally_inspected':False}
 if eid=='C7-IRL-1740-FAMINE':row.update({'start_date':'1740','end_date':'1741','year_span_not_an_episode':'Famine originated in severe climate, shaped by structural vulnerability; no fabricated dated massacre or area'})
 if eid=='C7-SCT-1746-DEPORT':row.update({'start_date':'1746','end_date':'1747','reported_deportees':936,'number_type':'survivors_deported_for_indentured_service_museum_summary'})
 if eid=='C7-D02-1790-SECOND':row.update({'reported_male_transportees_approx':1250,'reported_male_voyage_mortality':'over_25_percent','number_type':'institutional_aggregate_approximation_not_ship_by_ship'})
 events['events'].append(row);new_ledger.append(row);existing_ids.add(eid)
events['event_count']=len(events['events'])
# claims specifically handle source contradictory lines / cartographic constraints
new_claims=[
('R7-SECOND-FLEET-1790','1790','Second Fleet 1250 approximate male convicts >25% died in transit.','C7-S01','The 2.8% First Fleet comparison belongs to different fleet and sex/transport denominator','Cannot map individual deaths at Sydney arrival point.'),
('R7-IRISH-TRANSPORT-1791','1786/1790/1791','Irish legal acts (1786,1790) preceded first Irish shipload 1791-04.','C7-S03','One PDF archival guide; exact ship, port and manifest must be checked','Transport corridor only as endpoints if separately evidenced; no plotted route.'),
('R7-CLIMATE-1740','1740–1741','Famine triggered by European exceptional winter; social vulnerability exacerbated outcomes.','C7-S11;C7-S12','15–20% estimates are debated and do not identify casualties of intentional UK policy','No invented famine footprint or capitalised tally as colonial killings.'),
('R7-WHITEBOYS-1761','1761–1765','Whiteboys mobilised in response to enclosure and tithe demands near Clogheen–Ballyporeen.','C7-S10','Source scholarly excerpt only; not a single coordinated countrywide army','Use named region review layer only if verified, not control polygon.'),
('R7-BALLYMENA-1798','1798-06','Ballymena was held about three days by United Irishmen; Antrim had briefer fighting.','C7-S15','Three days reported, start/end hour uncertain','Town core short episode; no whole county authority claimed.'),
('R7-BALLYNAHINCH-DATE','1798-06-11/13','Existing C4-F06-004 uses 13 June; Ulster-Scots 11 June and History Ireland 12-13 June.','C7-S15;C7-S16','Distinct references may date mobilization, battle or final action; original dispatch needed','Retain chronology conflict; avoid a sole certain date for whole event.'),
('R7-DWYER-1799','1799-02-15','Michael Dwyer escaped after 1798 uprising; Wicklow resistance continued afterwards.','C7-S17','HES-site style local heritage narrative, finer chronology must be checked','Keep 1799 episodic anchor and 1800–1803 boundary follow-up.'),
('R7-GLENSHIEL-1719','1719-06-10','HES battlefield inventory confirms 1719 battle and original NGR NH996137.','C7-S20','NGR is battlefield-reference centre not a measured 1719 fort line','Only represent modern centroid point; inventory landscape polygon not sovereignty.'),
('R7-CULLODEN-936','1746–1747','National Trust for Scotland guide reports 936 transported for indentured service, 120 executed.','C7-S21','Institutional aggregate; archival prisoner and destination lists must be separately checked','Do not add counts as all people killed, or draw transports as forced paths.'),
('R7-1746-ACT-DATE','1746/1747','NTS reports Proscription effective 1746-08-01, old corpus clothes restrictions effective 1747.','C7-S21','Different statute sections and enforcement days; obtain parliamentary enrolled text','No blanket identical effective date across distinct prohibitions.'),
('R7-KNIGHT-1778','1778-01-15','Scotland court recognized Joseph Knight freedom and invalidity of colonial slavery claim.','C7-S22;C7-S23','National Records of Scotland 8–4; Judiciary of Scotland 10–4; conflicting court vote counts','No vote tally in Atlas until court roll/proceedings audited.'),
('R7-TOTAL-GLASGOW-1769','1769','52% of British tobacco import came through Glasgow/Greenock/Port Glasgow in 1769.','C7-S26','Metric: tobacco imports, not profit, slaves, exports or land area','Record as trade-port network, not slavery ship routes or colonial territories.'),
('R7-DUNDAS-1792','1792','Museum states Henry Dundas proposed gradual instead of immediate slave-trade abolition.','C7-S24','Original bill version, parliamentary division and motives need direct review','Political legislative action; no implied military footprint in Scotland.'),
('R7-LEITH-1793','1793','Leith Banking Company had 18 partners many colonial merchants, museum explanation.','C7-S24','Cannot assume all partners owned enslaved persons or loans tied to human collateral','Named institution point only; financial chain requires signed records.'),
('R7-SCOT-NO-COLONY','1707–1799','Scots both subject to Hanoverian state policies and invested in colonial enslavement through British Empire.','C7-S24;C7-S26','Do not collapse Highland tenant displacement and Scottish plantation ownership into an undifferentiated actor','Political subjects, regions and perpetrators separate.'),
('R7-FIRST-GRANT-1791','1789–1792','Parramatta sources disagree on exact James Ruse grant formal dates; arrival at farm and deed registration distinct.','C7-S06;C7-S08','Existing C2/C3 source conflict log remains authoritative','Do not update 1789 work start into exact 1789 deed transfer.'),
('R7-INDIGENOUS-SETTLEMENT','1788–1793','Parramatta City Council documents Dharug land and yam grounds removed by cultivation.','C7-S06;C7-S08','Dates for individual fields and precolonial sites uncertain','Do not infer 1788 English control over entire Dharug territory.'),
('R7-KNIGHT-CONTINUITY','1769–1778','Domestic sales/adverts and 1778 Scotland court judgment coexist with Scottish overseas slave economies.','C7-S22;C7-S25','Do not claim 1778 abolished Caribbean plantation slavery','18th century policy/legal layers should remain separate.'),
]
claim_ids={c['id'] for c in claims['claims']}
for ci,date,summary,src,audit,map_ in new_claims:
 if ci in claim_ids: continue
 claims['claims'].append({'id':ci,'date_or_range':date,'claim_summary':summary,'source_ids':[source_alias[s] for s in src.split(';')],'access_type':'institutional_scholarship_research_reading','audit_limit':audit,'map_eligibility':map_,'original_folio_personally_inspected':False,'round_added':7})
claims['evidence_count']=len(claims['claims'])
# Add a genuine historic-environment-verified location reference point only when geographic coordinates traceable.
place_index={f['id'] for f in places['features']}
local_places=[
('PLACE-GLENSHIEL','Glenshiel battlefield',[-3.663478661250737,57.20303942244357],'HES official NGR NH 996 137 OSGB36 to WGS84 via pyproj EPSG27700→4326, representative inventory centre', ['C7-S20']),
('PLACE-TOONGABBIE','Old Toongabbie Government Farm',None,'historic named locality documented in Parramatta council history, no surveyed 1791 farm centroid',['C7-S07']),
('PLACE-BALLYMENA','Ballymena 1798 town',None,'historic town per expert historian; modern referent to locate separately',['C7-S15']),
('PLACE-ANTRIM-1798','Antrim 1798 town',None,'historic town per 1798 campaign expert historian; exact insurgent held blocks unknown',['C7-S15']),
('PLACE-SAINTFIELD','Saintfield battlefield/settlement',None,'1798 June 9 encounter; battle point unverified',['C7-S15']),
('PLACE-KNOCKMEALDOWN','Clogheen–Ballyporeen Whiteboys initial district',None,'multi-site starting area, not centroid or accurate historical boundary',['C7-S10']),
('PLACE-DWYER-COTTAGE','Dwyer McAllister Cottage',None,'official protected heritage site, coordinates not captured',['C7-S17']),
('PLACE-EDINBURGH','Edinburgh courts and finance',None,'historic named city; Court of Session seat not yet georeferenced',['C7-S23']),
('PLACE-PERTH-SCOT','Perth sheriff court',None,'historic city; courtroom GPS not verified',['C7-S22']),
('PLACE-LEITH','Leith banking establishment',None,'modern historic town; original 1793 bank building coordinates not verified',['C7-S24']),
('PLACE-DOUNE','Doune/Kilmadock parish',None,'1994 museum record of 1794 donation; historical church location unverified',['C7-S24']),
('PLACE-GLASGOW','Glasgow tobacco trade port',None,'historical commercial town; no colonial boundary or exact 1769 port GIS yet',['C7-S26']),
('PLACE-GREENOCK','Greenock tobacco trade port',None,'historical port; no 1769 wharf GPS',['C7-S26']),
('PLACE-PORTGLASGOW','Port Glasgow tobacco trade port',None,'historical port; no 1769 wharf GPS',['C7-S26']),
('PLACE-DUBLIN','Dublin, Ireland',None,'historical administration and activism; no legal control polygon from named city',['C7-S13']),
('PLACE-WESTMINSTER','Westminster, London',None,'site for institutional decisions, not affected land polygon',['C7-S13']),
('PLACE-BELFAST','Belfast, 1798',None,'historical city; specific execution site not independently georeferenced',['C7-S15']),
]
for id_,name,coords,method,sids in local_places:
 if id_ in place_index: continue
 props={'name':name,'source_ids':[source_alias[s] for s in sids],'linked_event_ids':[e['id'] for e in new_ledger if e.get('geometry_ref')==id_],
        'coordinate_method':method,'coordinate_status':'institutional_grid_reference_converted' if coords else 'unlocated_research_only',
        'geo_precision':'modern_historic_site_inventory_center_not_exact_1719_firing_line' if coords else 'no_georeference',
        'historical_boundary_confirmed':False,'territorial_claim':False,'fill_authorized':False,'area_sqkm':None,'exclude_from_area_aggregation':True,'publication_status':'research_only',
        'map_inclusion':'review_point' if coords else 'needs_original_cartography'}
 places['features'].append({'type':'Feature','id':id_,'geometry':{'type':'Point','coordinates':coords} if coords else None,'properties':props});place_index.add(id_)
# Update existing feature links to newly added events, avoid modifying original coordinates
for f in places['features']:
 for e in new_ledger:
  if e.get('geometry_ref')==f['id']:
   p=f['properties'];p.setdefault('linked_event_ids',[])
   if e['id'] not in p['linked_event_ids']:p['linked_event_ids'].append(e['id'])
# Write core files first -- avoid loss due to validation errors
for n,o in [('SOURCE_REGISTRY.json',sources),('EVENT_CANDIDATES.json',events),('MAP_CANDIDATES.geojson',places),('CLAIM_EVIDENCE_MATRIX.json',claims)]:dump(n,o)
for n,rows,keys in [
 ('EVENT_CANDIDATES.csv',events['events'],None),('CLAIM_EVIDENCE_MATRIX.csv',claims['claims'],None)]:
 old_header=[]
 with (ROOT/n).open('r',encoding='utf-8-sig',newline='') as ff:old_header=next(csv.reader(ff))
 fields=old_header+[k for row in rows for k in row if k not in old_header and not (old_header.append(k))]
 # previous comprehension appends to old_header; recalc stable
 fields=list(dict.fromkeys(fields))
 with (ROOT/n).open('w',encoding='utf-8-sig',newline='') as ff:
  writer=csv.DictWriter(ff,fieldnames=fields,extrasaction='ignore');writer.writeheader()
  for row in rows:
   r={k:(json.dumps(v,ensure_ascii=False) if isinstance(v,(list,dict)) else v) for k,v in row.items()}
   writer.writerow(r)
# Detailed emerging topic ledger, separate draft not part of editor #289
proposals=[
 ('E18-F10-PROPOSED','1761—1765 Ireland Whiteboys: enclosing commonage, tithe collection and rural collective resistance',['C7-IRL-1761-WHITE','C7-IRL-1762-WHITE']),
 ('E18-F11-PROPOSED','1740—1741 Irish Great Frost famine: mortality, migration, institutional vulnerability without single-agent blame',['C7-IRL-1740-FAMINE']),
 ('E18-F12-PROPOSED','1746 Jacobite prisoner incarceration/deportation, Highland proscription, Eilean Donan/Glenshiel 1719',['C7-SCT-1746-PROSC','C7-SCT-1746-DEPORT','C7-SCT-1719-GLEN']),
 ('E18-F13-PROPOSED','Scottish enslavers and enslaved peoples in Scotland: 1769 sale advertisements and 1778 Knight litigation',['C7-SCT-1769-AD','C7-SCT-1774-KNIGHT','C7-SCT-1778-KNIGHT']),
 ('E18-F14-PROPOSED','Scotland tobacco/finance and slavery-linked plantations, 1769–1796',['C7-SCT-1769-TOBACCO','C7-SCT-1792-DUNDAS','C7-SCT-1793-LEITHBANK','C7-SCT-1794-MITCHELL','C7-SCT-1796-CARIB']),
 ('E18-D12-PROPOSED','Second Fleet 1790 mortality and coerced convict labor supply after the First Fleet',['C7-D02-1790-SECOND']),
 ('E18-D13-PROPOSED','Ireland-to-Australia convict transportation chain, 1786–1804',['C7-IRL-1786-TRAN','C7-IRL-1790-TRAN','C7-D02-1791-IRISH']),
 ('E18-D14-PROPOSED','Rosehill/Toongabbie local Darug dispossession and agricultural expansion 1788–1799',['C7-D10-1788-DISPOS','C7-D10-1791-FARM','C7-D10-1793-MAC']),
 ('E18-F15-PROPOSED','Irish 1798 revolt Ulster local-control mini-episodes Antrim, Ballymena, Saintfield',['C7-IRL-1798-ANTRIM','C7-IRL-1798-BALLYMENA','C7-IRL-1798-SAINTFIELD']),
]
dump('ROUND7_PROPOSED_MAJOR_TOPICS.json',{'schema':'18c-C-round7-proposals','status':'research_only_not_added_to_PR289','not_duplicates_of_existing_topics':False,
 'policy':'Candidate subtopics to support or split original E18 F/D stories; chief editor approves IDs',
 'proposals':[{'id':id_,'title':title,'candidate_event_ids':ids,'publication_state':'research_only','historical_control_polygon_approved':False} for id_,title,ids in proposals]})
# Short, reviewable stage-specific control status independent of legacy 1700-09 file
control=[
 {'site':'Antrim town','time':'1798-06-07','observed_action':'United Irishmen attacked and entered town; crown columns recovered control in same battle','year_end_1798':'crown_governance','evidence_ids':[source_alias['C7-S15']],'map_type':'short-lived contested town action, not rebel whole-county area','uncertainty':'exact blocks/hours not established'},
 {'site':'Ballymena town','time':'1798-06-07 to approximately 1798-06-09','observed_action':'insurgents held town and formed Committee of Public Safety, accepted amnesty after news from Antrim','year_end_1798':'crown_governance','evidence_ids':[source_alias['C7-S15']],'map_type':'temporary rebel town core; exact dates pending','uncertainty':'approx three days, no surveyed bounds'},
 {'site':'Saintfield battlefield','time':'1798-06-09','observed_action':'government column ambushed and retreated','year_end_1798':'crown_governance','evidence_ids':[source_alias['C7-S15']],'map_type':'battle event, no standing 1798 rebel city jurisdiction implied','uncertainty':'force footprint unknown'},
 {'site':'Glenshiel battlefield','time':'1719-06-10','observed_action':'government field victory over Jacobite-Spanish position','year_end_1719':'Kingdom of Great Britain Scotland, pre-existing governmental jurisdiction','evidence_ids':[source_alias['C7-S20']],'map_type':'battlefield point not ownership change','uncertainty':'HES landscape inventory not dynastic state frontier'},
 {'site':'Toongabbie farm','time':'1791-04','observed_action':'small government convict agricultural site established on Darug land','year_end_1791':'local British colonial settlement and farm, Darug sovereignty/political continuity separately attested','evidence_ids':[source_alias['C7-S07']],'map_type':'named farm site only; no precise cadastral polygon','uncertainty':'first 1791 farm footprint not digitised'},
 {'site':'Rose Hill/Parramatta','time':'1788-11 onward','observed_action':'British convict agricultural settlement established, land clearing dispossessed Burramattagal and Dharug residents','year_end_1788':'local British outpost core, Darug country beyond remains not adjudicated','evidence_ids':[source_alias['C7-S06']],'map_type':'settlement core / land-dispossession event point','uncertainty':'individual early grants not validated geometric parcel boundaries'},
]
dump('ROUND7_LOCAL_CONTROL_EPISODES.json',{'schema':'18c-C-research-only-site-control','time_period':'1719,1788–1799','episodes':control,'rule':'No implied continuum of governmental control from a one-day rebellion or a paper concession.'})
# Conflicts log
conflicts=[
 {'id':'R7-VOTE-1778','issue':'Court of Session Joseph Knight vote reported differently','a':'National Records of Scotland says eight-to-four','b':'Judiciary of Scotland says ten-to-four','source_ids':[source_alias['C7-S22'],source_alias['C7-S23']],'resolution':'Decision date and result confirmed; suppress exact vote until full judicial minutes audited'},
 {'id':'R7-BALLYNAHINCH-DATE','issue':'June 1798 Ballynahinch battle day differs by phases','a':'History Ireland describes preliminary engagement June12 and battle following day','b':'Discover Ulster Scots dates a rebel defeat June11; prior event candidate June13','source_ids':[source_alias['C7-S15'],source_alias['C7-S16']],'resolution':'Keep multi-day phase and mark June12–13 needs primary dispatch checking'},
 {'id':'R7-SCOTS-CLOTHES','issue':'1746 Act of Proscription came into force vs 1747 clothing restriction','a':'NTS says Act came into force 1746-08-01','b':'Earlier corpus marks Highland dress restrictions as effective 1747','source_ids':[source_alias['C7-S21']],'resolution':'Retain different section-effective dates; inspect enrolled statute before correction'},
 {'id':'R7-FAMINE-MORTALITY','issue':'1740–41 310k–480k or 15–20% historic estimates lack census precision','a':'Cambridge review recounts guessed 15–20% mortality','b':'Climate of the Past abstract confirms severe climate, vulnerability without mortality precision','source_ids':[source_alias['C7-S11'],source_alias['C7-S12']],'resolution':'Omit fixed precise death toll from event text, preserve estimates only in historiography note'},
 {'id':'R7-CULLODEN-COUNTS','issue':'Culloden captured/deported executed counts depend on custody and survival denominator','a':'NTS about 3,500 arrested, 936 deported, 120 executed; deaths in captivity unnumbered','b':'original prisoner rolls not examined','source_ids':[source_alias['C7-S21']],'resolution':'Store figure as NTS compiled report, never claim 936 British enslaved captive death total'},
]
dump('ROUND7_EVIDENCE_CONFLICTS.json',{'schema':'18c-C-round7-critical-conflicts','open_count':len(conflicts),'conflicts':conflicts})
# New research documents
N=len(new_ledger)
md=f'''# 爱英TV 助手3｜第七轮重大影响事件扩展调查（研究候审）

**日期：{TODAY}；范围：1700—1799年爱尔兰、苏格兰、澳大利亚及明确的帝国连接点。**

本轮新增 **{N}** 条具有来源的事件/阶段候审记录、{len(new_sources)}条机构/学术来源登记请求（若原库已有相同网址则复用）、{len(new_claims)}条证据审查、{len(local_places)}处具名地点候审。所有“英国”政治称谓按1707前后分开，18世纪澳大利亚纸面声索与实际殖民点分开，不建立任何领土Polygon。

## 1 重要补漏：爱尔兰

### 1740—1741大饥荒不是单一战役
剑桥学术评论综述显示严寒及粮食短缺引发规模巨大的饥荒，研究对死亡人数估计有巨大不确定性。2013年气候史研究阐述了歉收、高粮价和社会脆弱性。**受害者及结构性弱势应呈现，但不能将整个饥荒武断写成伦敦单独策划的杀戮行动。**（C7-S11、C7-S12）

### 1761—1765 Whiteboys土地与税费抗争
学术论文将其起点放在1761年蒂珀雷里西南边缘，乡村结社反对公地围占、什一税额外征收及地产权力。按Clogheen/Ballyporeen、Kilmallock等具名地逐步补证；**这不是一个统一疆域的长期军政国家**。（C7-S10）

### 1795—1799地方内战与镇压
1795 Armagh的宗派冲突、1797军事戒严与反叛乱镇压、1798年Antrim、Ballymena和Saintfield的短期地方战争及1799年Wicklow山区的持续游击必须拆开。Antrim镇不曾作为起义军全年控制区，Ballymena有约三天临时管理，Saintfield仅战斗胜利。政府军对嫌疑人的酷刑、处决与焚屋见国家陆军博物馆；起义军杀害被囚保王派的旧有独立记录继续保留，避免混淆责任。（C7-S14–S18）

### 爱尔兰囚犯抵达澳大利亚的制度线路
英国1730年代至1775北美流放、1784英国流放法、爱尔兰1786/1790分别立法和1791首艘由爱尔兰出航的新南威尔士囚船是**多阶段不同法律机构**。1798起义后的政治囚犯被流放及1804澳洲Castle Hill起义另作为后世纪桥接；不要把1804事件塞进1799。（C7-S02、S03、S04、S29）

## 2 重要补漏：苏格兰

### 1719詹姆斯党与1715、1745分开
政府军1719年5月炮毁Eilean Donan、6月10日Glenshiel战役击败詹姆斯党与西班牙分队，HES保存一份真实历史战场专用清单和原始档目录。该地理清单边界不是英国对苏格兰获得新主权的边界。Glenshiel新增**唯一有政府历史网格参考的研究Point**。（C7-S19、S20）

### 1746败后羁押、流放、剥夺法权
NTS教育资源估计，数千人被捕，其中936名幸存者被海外流放从事契约劳役、120人被处决。分母为战后涉案人员，不是死于Culloden战场数字；没有逐人囚船清单不绘制海上GPS路线。1746年8月1日《禁止法》与不同服饰条款生效日期保留独立审查。（C7-S21）

### 奴隶制与苏格兰司法的矛盾
1769爱丁堡报纸将一名未成年黑人家仆作为可处分财产刊登广告；1774 Joseph Knight在Perth申诉获得有利判决，1778-01-15苏格兰Court of Session确定牙买加奴役主张无法在当地强制执行。**苏格兰法院推翻个案的永久奴役主张，并没有改变苏格兰商人在加勒比的种植园经营。** 此案两家苏格兰官方机构对表决数字各记8–4和10–4，判决结果清楚，票数暂不进入正文。（C7-S22、S23、S25）

### 苏格兰从海外奴役体系受益的可审链条
牛津大学学术论文记述1769年Glasgow、Greenock、Port Glasgow三港口合计占英国烟草进口约52%。NMS的1793 Leith Banking Company、1794 Doune捐赠物、1792 Henry Dundas改渐进废奴修正案及1796加勒比军事行动，提供了具年、具名公司/政治人物/物件的研究链。**不能据贸易参与者全部推为拥有奴隶、所有港口商品都是奴隶船运输，或捏造具体净利润。**（C7-S24–S26）

## 3 重要补漏：澳大利亚

### 罪犯流放既是帝国政策也是强制劳动供给
1717法律规范流放，1776后北美输送中断，1785内阁筹设新目的地、1786总督任命、1787指示信提出远超实际驻点的法理范围。第二舰队1790年的极高死亡率（男性囚犯约1250，超过四分之一死于途中）应从第一舰队专题独立出来。其死亡不是1788年悉尼湾战斗死亡人数。（C7-S01、S02、S05、S29）

### Burramattagal/Dharug土地被开垦与1788—1799年农业殖民
Rose Hill、Toongabbie自1788、1791年起的土地清理、农场劳役及私人授地，造成原住民山药、林木、狩猎采集地受破坏，市政历史材料直接描述。John Macarthur1793年获得约100英亩授地，属于单人产权阶段；土地授予及1750后牧业发展不代表整块澳大利亚大陆已被英国实控。（C7-S06–S09）

### 真正跨世纪的后果
1797美利奴羊引种是后续草场扩张的长期前史；1801 Pemulwuy被殖民当局悬赏追缉及1802遇害、1804澳大利亚爱尔兰囚犯起义不能因地图研究窗口1699/1799就提前结束，但必须分在下一世纪独立事件。（C7-S04、S09、S31）

## 4 研究所用史料等级与地图门禁

- **历史行动层**：独立事件有年份、行动者和来源；少数只有年度或月份的记录不得编造精确日。
- **原住民土地层**：殖民清林/授地是局部行动；Darug、Burramattagal等政治土地关系单独表达，不把1787声索经线当实控疆界。
- **地图几何层**：本轮仅把HES实地战场 NGR NH996137 转换WGS84为现代参考Point；该点不是战斗准确位置、地籍界或国家实占面。
- **来源层**：官方纪念、国家博物馆、国家档案馆研究指南和同行评审摘要都有来源等级；未读原手稿不标记“已阅原件”。
- **对外协作**：苏格兰商人与奴役种植园涉及助手1加勒比经济史；1717—1775流放美洲涉及助手1北美；1796海地远征与加勒比战争具体受害者、行军地图由对应调查员逐例调查，助手3仅提供桥接。

## 5 研究局限与下一步

- 苏格兰Knight判决投票分歧需原法庭原件；NTS战俘936数字需逐档列名前不能计作已核名单。
- 1798 Ballynahinch 11/12/13日不同文献的战斗阶段尚有分歧。
- 1740–41饥荒缺符合一致分母的精确伤亡统计；应展示灾难和社会结构，不设计英国杀戮面积。
- Toongabbie、Rose Hill早期实际农田边界、逐户Darug土地关系仍需政府历史地籍和第一民族证据核验。

**本轮成果为研究候审，GitHub无写入、正式地图未发布。**
'''
(ROOT/'ROUND7_MAJOR_IMPACT_RESEARCH.md').write_text(md,encoding='utf-8')
# major episodes narrative dossier files split for editor reuse
dossier_dir=ROOT/'ROUND7_MAJOR_IMPACT_DOSSIERS';dossier_dir.mkdir(exist_ok=True)
sections={
 'F_IRISH_LAND_FAMINE_AGRARIAN.md':('爱尔兰1740—1797饥荒、Whiteboys、宗教土地税费制度',["C7-IRL-1740-FAMINE","C7-IRL-1761-WHITE","C7-IRL-1762-WHITE","C7-IRL-1722-WOOD","C7-IRL-1723-DRAPIER"]),
 'F_IRISH_1798_LOCAL_CONTROLS.md':('爱尔兰1798—1799短期城镇实控与多方镇压',["C7-IRL-1795-DIAMOND","C7-IRL-1797-MARTIAL","C7-IRL-1798-ANTRIM","C7-IRL-1798-BALLYMENA","C7-IRL-1798-SAINTFIELD","C7-IRL-1798-MCCRACKEN","C7-IRL-1799-DWYER"]),
 'F_SCOT_JACOBITE_TRANSPORT.md':('苏格兰1715、1719、1746分期战争与战败强制流放',["C7-SCT-1715-SHER","C7-SCT-1719-EILEAN","C7-SCT-1719-GLEN","C7-SCT-1746-PROSC","C7-SCT-1746-DEPORT"]),
 'F_SCOT_SLAVERY_MONEY_LAW.md':('苏格兰海外奴役经济、国内司法和政治制度',["C7-SCT-1769-AD","C7-SCT-1774-KNIGHT","C7-SCT-1778-KNIGHT","C7-SCT-1769-TOBACCO","C7-SCT-1792-DUNDAS","C7-SCT-1793-LEITHBANK","C7-SCT-1794-MITCHELL","C7-SCT-1796-CARIB"]),
 'D_SECOND_FLEET_TRANSPORT.md':('1717—1791流放体系、美洲中断与第二舰队',["C7-TRANS-1717","C7-TRANS-1785","C7-TRANS-1786","C7-D01-1787-INSTR","C7-D02-1790-SECOND","C7-D02-1791-IRISH","C7-IRL-1786-TRAN","C7-IRL-1790-TRAN"]),
 'D_DHARUG_FARM_LAND.md':('新南威尔士1788—1799定居农业和Burramattagal土地侵入',["C7-D10-1788-DISPOS","C7-D10-1791-FARM","C7-D10-1793-MAC","C7-D10-1797-MERINO"]),
}
for fn,(title,ids) in sections.items():
 lines=[f'# {title}','', '**状态：research_only，非正式地图文章。**','', '本档案是主编阅研索引；所有行动者、地理、来源和历史边界均以EVENT_CANDIDATES和SOURCE_REGISTRY为准。','']
 for i,eid in enumerate(ids,1):
  e=next(e for e in events['events'] if e['id']==eid)
  links=[next((s['url'] for s in sources['sources'] if s['id']==sid),'') for sid in e['source_ids']]
  lines += [f'## {i}. {e["date"]}｜{e["title"]}','',f'**主体：** {e["actor"]}。**行为：** {e["action"]}。',f'**地点：** {e["historical_place"]}。**地图状态：** `{e["cartographic_status"]}`。',f'**史料限制：** {e["evidence_notes"]}','','**来源：** '+', '.join(f'[{sid}]({u})' for sid,u in zip(e['source_ids'],links)),'']
 lines+=['## 主编验收门禁','', '- 每个历史行为须有独立年份；年份范围不能在前端显示为每年发生同一战斗。','- 不是实控地籍Polygon。地点为历史地名参考或现代遗址参考，不能被当作实际战争范围。','- 源文档链接存在不代表馆藏未公开原手稿已经逐叶审查。','- 与旧库事件合并时保留稳定研究ID和史料冲突台账。','']
 (dossier_dir/fn).write_text('\n'.join(lines),encoding='utf-8')
# Draft coordination note
(ROOT/'ROUND7_COOPERATION_AND_19C_BOUNDARY.md').write_text('''# 助手3第七轮｜跨团队及19世纪交接\n\n- 助手1：1769格拉斯哥烟草贸易52%英国烟草进口，**不是奴役人口运输比例**；向北美殖民地流放罪犯1717–1775超五万人；1796 Dundas涉加勒比军事行动逐战研究；苏格兰Dundas对贩奴贸易废除进程修订案。请用本包C7-S02、S24、S26开独立核源。\n- 助手2：暂没有大规模东印度重查；如分析苏格兰公司和EIC的联盟商业进入权，务必先区分1707 Article 4纸面制度与各个商馆真实控制。\n- 主编：新 proposed D12/D13/D14、F10/F11/F12/F13/F14/F15 是补漏候审母题，不应该未经批准加入已正式MAJOR_TOPICS；可作为既有D02/D10/F01/F04/F06/F08子篇。\n- 边界1799→1800：1798爱尔兰囚徒在新南威尔士延续政治抵抗，1804 Castle Hill起义是独立19世纪节点；1801/1802 Pemulwuy是独立19世纪节点；高地清场最常引用的Sutherland 1809–1821是19世纪，不可落在1799。\n- 殖民地法律主体：爱尔兰1786及1790流放法是18世纪爱尔兰王国议会立法，英国1784流放法是另一条法系；1707前苏格兰不是统一王国。\n- 1798起义在Wexford/Antrim/Ballymena/Saintfield/Wicklow的短暂事件不得绘制全岛叛军控制；独立具名短时状态账见ROUND7_LOCAL_CONTROL_EPISODES.json。\n''',encoding='utf-8')
# PROGRESS separate Round7 update to avoid replacing prior full handoff
with (ROOT/'PROGRESS.md').open('a',encoding='utf-8') as f:
 f.write(f'\n## 第七轮扩展重大影响事件（{TODAY}）\n\n- 新候审事件 {N} 条；来源累计 {len(sources["sources"])} 条；地点累计 {len(places["features"])} 处；证据累计 {len(claims["claims"])} 条。\n- 新增6份重大影响专题档案、9条待审子专题母题、1798地方控制记录、史料冲突。\n- 新增Glenshiel官方HES National Grid Reference现代中心点；仍零个真实控制面。\n- 未修改GitHub；全部候审。\n')
with (ROOT/'MISSING_TOPICS.md').open('a',encoding='utf-8') as f:
 f.write('''\n## 第七轮新增历史缺口（全面排查重要性）\n\n- 1746后936名被流放詹姆斯党囚徒的逐人姓名、刑期、港口、种植园主与死亡；NTS数字目前只是机构总览。\n- 1798 Antrim、Ballymena起义军短期控制的确切小时、城镇街区，1799 Wicklow游击残余活动；需要爱尔兰国家档案馆REB逐卷。\n- 1740–41大饥荒教区和县级死亡/粮价/土地结构；不得编造饥荒屠杀Polygon。\n- Knight v Wedderburn原判法院表决8:4/10:4不同机构冲突；需要苏格兰NRS CS235/K/2/2与判决册。\n- 1769苏格兰烟草进口52%港口份额并非殖民利润；须靠逐商人账簿建立利润、贷款、人口奴役责任链。\n- 1790第二舰队分船被流放者人数/途中死者与幸存入院人数；整队二次整理不可拆为单船GPS海面事件。\n- 爱尔兰1786及1790流放法，1791首船具体船名、从何港口出航与何时抵岸，仍待1787—1791原始登记。\n- Toongabbie 1791农业用地与Burramattagal祖居地关系、地契原地籍图需现代原住民族机构参与核验。\n- HES Glenshiel清单战场景观有据，但不能作为1719王室取得主权边界或原始军阵精确线。\n''')
print('round7 written',{'new_events':N,'events':len(events['events']),'sources':len(sources['sources']),'places':len(places['features']),'claims':len(claims['claims'])})
