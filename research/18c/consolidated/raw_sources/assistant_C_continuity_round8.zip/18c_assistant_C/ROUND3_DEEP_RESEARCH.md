# 第三轮深入调查｜现场实控、法律生效与原始档案矛盾

**研究状态：research_only；时间：2026-11-08；GitHub只读。**

## 一、1700—1709年约克堡新发现：法方Fort Bourbon，不是英方驻军

加拿大Parks Canada的York Factory国家历史遗址年表明确记录：1697年法军重新夺占原York Fort并重命名Fort Bourbon，法方占据直至1713年乌得勒支和约；商业公司声索和堡垒实控完全不同。其管理规划另识别York Factory I（1684—1715）、II（1715—1788）和III（1788—1957），今天遗址地理点一般是III，并非1699时期军事堡址。1700—1709年英方控制图层若将York Fort标作英国实际驻军，必须更正为法方堡垒独立标记（当前源只到具名地点；精确原址仍待历史堡址坐标核验）。

本地`SITE_SPECIFIC_CONTROL_1697_1715.json`保存10年逐年“官方遗址历史区间证实”的法方控制状态：不是十份独立驻防名册；1999参考虚线大Rupert流域仍不具实控证明。其他海湾堡垒Albany、Moose、Rupert、Severn、Churchill待逐堡审查，绝不因约克堡归法国而整个流域涂法国。来源C3-HBC-PARKS-YORK、C3-HBC-PARKS-PLAN。

## 二、1788殖民行为由法理宣示拆成至少四个独立时点

- 1788-01-26：Sydney Cove/Warrane实际立营。
- **1788-02-07**：Royal Commission及殖民法院执法文书公示。State Library NSW的David Collins专题、悉尼大学公开逐日引录的1788日记及NSW总督办公室官方讲话均支持当日，不能合并入1月26日。文书提及广大的纸面管理声索范围，实际据点另核。
- **1788-03-06**：Norfolk Island Kingston殖民副站，由澳大利亚政府遗产机关DCCEEW精确确认。
- 1788-04-24今Parramatta地择址，11-02 Rose Hill农耕据点建立；和Burramattagal/Darug土地关系另列。

由此建立`royal_claim`、`institutional_proclamation`、`physical_settlement`、`Indigenous_political_land`四种独立字段。只画文书地点与已证聚落点，绝不把135°E等委任书坐标生成为英国实际占领面。

## 三、三位被抓走的原住民：重新核日并记录能动性

州立图书馆和City of Ryde：Arabanoo于1788-12-31在Manly Cove遭强制抓捕，1789-05-18因天花去世；Bennelong与Colebee于**1789-11-25**同地遭殖民人员抓捕，William Bradley原始写生提供独立视觉证据。Bennelong于1790-05逃脱；1790-09-07 Willemering以矛刺伤Phillip，是否报复仪式属解释层；1790-10-08 Bennelong与双方重开自主交往。不得将这些史实压成“1789俘虏—1799被殖民者同化”的单线故事。C3-AU-RYDE-ARAB / BEN / SETTLE，C3-AU-SLNSW-ABDUCT。

## 四、殖民土地账簿难题：1791/1792同时保留

James Ruse早于1789-11就在Rose Hill耕种，Parramatta当地年表称1791-03-30“首次授地”，ANU传记称1791-04；但NSW官方State Archives以`NRS 898 [9/2731 p.2]`为据称首项授地登记于**1792-02-22**，州立图书馆收藏的SAFE/DLMSF37原手写契据日期写成1790而编目为`[1792]`、也承认是否抄写错误有争议。

本轮没选一个取代其他：C2-D10-002改为“1791地方报道、日期冲突、待审”，另立C3-D10-002记1792年档案登记；1789耕作单列。1792-02-22另有州图书馆Schaffer140英亩和Varndell30英亩原契据目录。面积为契据载明数字，不代表已知地籍GIS Polygon。1791-07-18 Prospect Hill殖民农户安置已从Heritage NSW找到具体开端，另独立地名候审点。

## 五、爱尔兰不应按1704全年禁令描述1798

PRONI官方选举资料显示1727–1793只有符合40先令freehold要求的新教徒有选举权，**1793起符合要求的天主教徒恢复投票权**，但无普选、议员任职权等推断。Ulster Historical Foundation逐项列1772年61年农业改良租约、1778年999年租约及地产限制宽免、1782进一步土地与教学变化、1792专业限制松动；英国议会官方资料印证1720→1782立法权转折及1753财政治理变化。必须分大不列颠1778宗教宽免和爱尔兰议会1778法案，不得混年份、混政体。

## 六、苏格兰1748转折由原始法案直接证实

英国官方立法数据库列`20 Geo II c43`，其第1条规定世袭司法权于**1748-03-25**消失（保留部分男爵收租等例外），而不是1746立法标题年份。Historic Environment Scotland新Fort George Ardersier官方记录证实1748-06-11开工、1769完成、1750年代起已有军人使用。三个不同时间口径不能涂成一个英军1769年才全面占有高地的地图。原国家史册详细存于C3-SCO-LEG-1746、C3-SCO-NRS-COURTS、C3-SCO-HES-GEORGE。

## 七、1799→1800跨世纪不断线

- 1799爱尔兰下院拒联合，1800接受并通过，**1801-01-01**《联合法》生效。不得把1798起义地图预先标为现代英国行政区（C3-IRL-UKPARL-UNION）。
- 1792—1799 Pemulwuy抵抗系列于1801-05-01出现殖民政府射杀令，1801-11悬赏令，1802-06-02或此前被杀并斩首，杀人者尚有争论。1797被击中不是结束（C3-AU-NMA-PEMULWUY-1802）。
- 1796牙买加Trelawny Town Maroons被放逐至新斯科舍；**1800-09-30**加拿大国家公园局记HMS Asia到Freetown时船上177名妇女、151名男子、222名儿童——这是1800船上口径，不能挪作1796流放全员口径；有人留在新斯科舍（C3-CAN-MAROON-PLAQ）。只作助手1接棒锚点。

## 证据等级与地图限制

截至本轮：原卷多数为官方档案目录/原文网页转录，未亲自翻阅全部纸本；Parks Canada区间控制具有可靠官方史迹陈述，但并非逐年10份驻军登记；部分1700达连精确降约日历和1791土地文书仍待原卷交叉查验。新增地点均`geometry:null`，旧3个现代参考点未改变。完整证据清单详`ROUND3_EVIDENCE_CONFLICTS.json`、`SITE_SPECIFIC_CONTROL_1697_1715.json`、`CLAIM_EVIDENCE_MATRIX.json/.csv`。
