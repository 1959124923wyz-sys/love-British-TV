from pathlib import Path
import json,csv
P=Path('/mnt/data/18c_assistant_C')
def rd(n):return json.loads((P/n).read_text(encoding='utf8'))
def wr(n,obj):(P/n).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
s=rd('SOURCE_REGISTRY.json');e=rd('EVENT_CANDIDATES.json');c=rd('ROUND3_EVIDENCE_CONFLICTS.json');g=rd('MAP_CANDIDATES.geojson');a=rd('CLAIM_EVIDENCE_MATRIX.json')
sby={x['id']:x for x in s['sources']};eb={x['id']:x for x in e['events']};gb={x['id']:x for x in g['features']}
def S(id,title,url,inst):
 if id not in sby:
  x={'id':id,'institution':inst,'title':title,'url':url,'access_level':'regional_local_heritage_chronology_not_original_court_martial','original_manuscript_personally_inspected':False,'reviewed_online_on':'2026-11-08','evidence_scope':'Date, local actors and geographic disambiguation: 1798 County Wicklow','source_handling':'Local scholarly chronology is not a scanned original court, register or exact GIS polygon'}
  s['sources'].append(x);sby[id]=x
S('C6-WICKLOW-LOCAL-CHRON','Chronology of Important Events during 1798 Rebellion in County Wicklow','https://heritage.wicklowheritage.org/topics/1798_in_county_wicklow/chronology_of_the_important_events_during_the_1798_rebellion_in_county_wicklow','County Wicklow Heritage / historian Joan Kavanagh')
S('C6-WATERFORD-REGIONAL-MUSEUM','1798 Rebellion and Waterford, local museum chronology','https://www.waterfordmuseum.ie/1798-rebellion-and-waterford/3/','Waterford County Museum')
# Conflict of published local chronology re Carnew 7 vs June 30
x=eb['C6-F06-004'];x.update(date='1798-06',date_precision='month',title='Carnew附近起义活动及7日/30日记载差异',action='一篇史学文章记7日Carnew方向有战术成功，但Wicklow地方史注明6月30日对Carnew守军进攻失败；须分辨两次行动和地点',source_ids=['C6-IRL-HISTIRELAND-WEXFORD','C6-WICKLOW-LOCAL-CHRON'],cartographic_status='hold_for_local_occupation_date_conflict',geometry_ref=None,evidence_notes='不可把1798-06-07直接作为Carnew被起义军占领的已证实事件；待当日原档/旧地图分辨Carnew镇与附近战术行动。')
# Bridge Wexford date: reputable summaries differ, do not overstate 21 June as signed unique day.
x=eb['C6-F06-005'];x.update(date='1798-06',date_precision='month_with_candidate_days',title='1798年6月Wexford桥梁处杀害被拘押保王派',source_ids=['C6-IRL-NAM-1798','C6-WATERFORD-REGIONAL-MUSEUM'],evidence_notes='官方国家陆军博物馆把约70名被囚保王派遇害放在Vinegar Hill失利叙事旁，但没有逐日证明；其他地方记20 June。20/21日待原始文件裁决。人数在不同来源间差别较大，不能合并。',candidate_dates=['1798-06-20','1798-06-21'])
# no guessed Wexford town event location for diffuse reprisals
x=eb['C6-F06-006'];x['geometry_ref']=None;x['cartographic_status']='multiple_sites_unknown_no_event_marker_without_local_proof'
# Do not import Hudson fort source into unrelated NSW agriculture D10 dossier
p=P/'TOPIC_DOSSIERS'/'E18-D10.md';t=p.read_text(encoding='utf8');t=t.replace('来源：C6-CAN-PARKS-YORK2007。状态：`research_only`，原卷与历史地籍未完全校准。','来源：C3-AU-MHNSW-RUSE、C3-AU-CITYPARRA-TIMELINE。状态：`research_only`，殖民授地契据原卷与历史地籍尚未完全校准。');p.write_text(t,encoding='utf8')
# Right-size mistaken conflict ID
for x in c['conflicts']:
 if x['id']=='C6-IRL-1802-REBEL-BILLET':x['id']='C6-IRL-1798-MILITIA-BILLET'
if not any(x['id']=='C6-CARNEW-JUNE-CONFLICT' for x in c['conflicts']):c['conflicts'].append({'id':'C6-CARNEW-JUNE-CONFLICT','claim':'1798 Carnew town: 7 June tactical success vs 30 June failed assault on same garrison','positions':[{'source_ids':['C6-IRL-HISTIRELAND-WEXFORD'],'date':'1798-06-07','finding':'general narrative mentions 7 June offensive success at Carnew; ambiguous whether town occupied'}, {'source_ids':['C6-WICKLOW-LOCAL-CHRON'],'date':'1798-06-30','finding':'Ballyellis ambush near Carnew followed by failed Carnew garrison assault'}],'resolution':'Do not display 7 June occupation. Candidate 7 June downgraded month and no georeference; 30 June dated garrison defensive episode separately. Primary manuscript and old military map needed.','never_merge_as_one_conquest':True})
if not any(x['id']=='C6-WEXFORD-BRIDGE-DAY-CONFLICT' for x in c['conflicts']):c['conflicts'].append({'id':'C6-WEXFORD-BRIDGE-DAY-CONFLICT','claim':'1798 Wexford Bridge killings exact day and count uncertain','positions':[{'source_ids':['C6-IRL-NAM-1798'],'date':'June 1798, position in narrative following 21 June','finding':'reports approx 70 prisoners, no day-stamped original article reproduced'}, {'source_ids':['C6-WATERFORD-REGIONAL-MUSEUM'],'date':'1798-06 undated','finding':'regional overview places bridge killings near final campaign stages, count varies'}],'resolution':'Date field only 1798-06, retain candidates 20/21 in evidence notes; no point for precise bridge massacre until original chronology validated.','never_merge_as_one_conquest':True})
# Add high-confidence new records from local heritage, NAI facsimile and NAM
def add(id,date,title,actor,action,historical_place,sids,geom,notes):
 if id in eb:return
 x={'id':id,'topic_id':'E18-F06','date':date,'date_precision':'day','title':title,'actor':actor,'action':action,'historical_place':historical_place,'source_ids':sids,'research_state':'research_only','cartographic_status':'source_attested_named_place_review_no_historic_polygon','geometry_ref':geom,'historical_control_polygon_approved':False,'evidence_notes':notes,'round':'sixth_evidence_conflict_remediation'}
 e['events'].append(x);eb[id]=x
 if geom in gb: gb[geom]['properties'].setdefault('linked_event_ids',[]).append(id)
def point(id,name,sources):
 if id in gb:return
 x={'type':'Feature','id':id,'geometry':None,'properties':{'name':name,'source_ids':sources,'linked_event_ids':[],'coordinate_method':'no_coordinates','coordinate_status':'historically_attested_place_not_located_to_ancient_site','geo_precision':'modern local name only; actual 1798 incident coordinates unverified','historical_boundary_confirmed':False,'territorial_claim':False,'fill_authorized':False,'area_sqkm':None,'exclude_from_area_aggregation':True,'publication_status':'research_only','map_inclusion':'research_not_published'}}
 g['features'].append(x);gb[id]=x
point('PLACE-DUNLAVIN','Dunlavin, County Wicklow',['C6-WICKLOW-LOCAL-CHRON'])
point('PLACE-CARNEW-BALLALLEY','Carnew Ball Alley, County Wicklow',['C6-WICKLOW-LOCAL-CHRON'])
point('PLACE-BALLYELLIS','Ballyellis near Carnew, County Wicklow',['C6-WICKLOW-LOCAL-CHRON'])
add('C6-F06-009','1798-06-05','Scullabogue被拘押保王派多人遭杀害','部分Wexford起义军看守；保王派被拘押者','根据Rebellion Papers Frazer Mss 1/30与历史研究，围绕New Ross战役消息被拘押者遭杀害、部分被锁在谷仓焚死','Scullabogue near New Ross',['C5-IRL-NAI-1798','C6-IRL-NAM-1798'],'PLACE-SCULLABOGUE','国家档案馆提示当时幸存者记载部分细节可能不准确；至少上百人的机构总结不能作为完整名册或精确总数')
add('C6-F06-010','1798-05-24','Dunlavin约43名被拘押者遭亲政府武装处决','当地亲王室武装，精确单位待核','Wicklow地方史记43名被拘押者被射杀或绞刑，反映在公开起义前夕的镇压','Dunlavin, County Wicklow',['C6-WICKLOW-LOCAL-CHRON'],'PLACE-DUNLAVIN','43为区域地方史记载；逐名档案和部队军籍待核，地图位置仅为城镇名')
add('C6-F06-011','1798-06-01','Carnew Ball Alley反政府疑犯集体遭枪杀','亲王室地方镇压部队，所属军政单位需核','Wicklow地方历史年表记超过40名联合爱尔兰人被射杀','Carnew Ball Alley',['C6-WICKLOW-LOCAL-CHRON'],'PLACE-CARNEW-BALLALLEY','人数为地方史概数，不合并全国死亡估计；原始死者名单未核对')
add('C6-F06-012','1798-06-30','Ballyellis起义军伏击并试攻Carnew但未占领守军据点','Wicklow起义军；Ancient Britons与Fifth Dragoons','近Carnew的Ballyellis发生伏击，但随后进攻Carnew驻军失败','Ballyellis and Carnew, County Wicklow',['C6-WICKLOW-LOCAL-CHRON'],'PLACE-BALLYELLIS','明确定义伏击军事行动和未能攻取Carnew的区别，禁止在6月30日给Carnew绘起义军实控填充')
# eliminate obsolete links referencing conflicting site on older row
for fid in ('PLACE-CARNEW','PLACE-WEXFORD-TOWN'):
 if fid in gb:
  ids=gb[fid]['properties']['linked_event_ids'];
  if fid=='PLACE-CARNEW':ids[:]=[i for i in ids if i!='C6-F06-004']
  if fid=='PLACE-WEXFORD-TOWN':ids[:]=[i for i in ids if i!='C6-F06-006']
# report corrections and explicit unresolved items
p=P/'ROUND6_DEEP_RESEARCH.md';p.write_text(p.read_text(encoding='utf8')+'\n## 第六轮交叉反证后的事件修订\n\n- Carnew 6月7日“被攻占”不能确立：History Ireland的战术概述与Wicklow地方年表6月30日未攻下城镇的记录需要按各次战斗区分，旧`C6-F06-004`降级为6月待核节点，不再有合法场景地理点；另立6月30日Ballyellis伏击/失败攻城。\n- Wexford桥梁遇害具体是6月20日或21日存在二手史学分歧，先降为月份；数字70/100左右为不同来源口径，来源ID与疑点单列。\n- Scullabogue 6月5日起义军看守实施的杀害，与英军对起义者的报复须独立主体、地点、日期；不得为叙事偏好遗漏任何一侧。\n- 新增5月24日Dunlavin与6月1日Carnew Ball Alley镇压事件，地方史有据，但单位、名录、建筑GPS仍待审核。\n',encoding='utf8')
# update cross-agent notes
p=P/'MISSING_TOPICS.md';p.write_text(p.read_text(encoding='utf8')+'\n## 第六轮新增须深查的矛盾与原件\n\n- York Factory I/II遗址被侵蚀，切勿把York Factory III现代坐标放在1700 Fort Bourbon；需加拿大公园局旧堡考古断面与HBC柜台地图。\n- 1798-06-07 Carnew是否曾由起义军控制存在资料冲突；先核当代日记、军需册、地方军事地图，6月30日攻城失败不能被忽略。\n- 1798 Wexford Bridge杀害被拘押者的准确日20/21日存在冲突；按官方军报和证词裁定，暂只显示月份。\n- 1788 Bradley航海图Bloody Point是否能关联William Okey/Samuel Davis死亡仍属历史地名解释，古代GPS未知。\n',encoding='utf8')
wr('ROUND3_EVIDENCE_CONFLICTS.json',c);wr('SOURCE_REGISTRY.json',s);wr('EVENT_CANDIDATES.json',e);wr('MAP_CANDIDATES.geojson',g)
# Preserve existing source ID semicolon CSV contract
for name,items in [('EVENT_CANDIDATES.csv',e['events']),('CLAIM_EVIDENCE_MATRIX.csv',a['claims'])]:
 keys=list(dict.fromkeys(k for row in items for k in row))
 with (P/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=keys);w.writeheader()
  for row in items:w.writerow({k:';'.join(map(str,v)) if isinstance(v,list) and k=='source_ids' else json.dumps(v,ensure_ascii=False) if isinstance(v,(list,dict)) else v for k,v in row.items()})
s['source_count']=len(s['sources']);e['event_count']=len(e['events']);wr('SOURCE_REGISTRY.json',s);wr('EVENT_CANDIDATES.json',e)
print('sources',len(s['sources']),'events',len(e['events']),'places',len(g['features']),'conflicts',len(c['conflicts']))
