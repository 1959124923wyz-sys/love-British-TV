# 第二轮证据攻坚：1700年断点、1770—1799澳洲殖民地扩展、爱尔兰与苏格兰

日期：2026-11-08 · `research_only` · 从原研究包继续，不修改GitHub

本轮为已有57条事件追加32条候审记录；重在“历史上发生了什么及何时发生”，不以数量作为真实性证明。新来源编号 `C2-*`，均见完整SOURCE_REGISTRY；网页说明、论文摘要、法条节选与原档逐页影像分层。校验脚本与ZIP保留原始文件和新增资料。

## I. 1699—1700达连：年末撤离证据升级

- **1699-11-30** 国家博物馆S72证实第二次远征抵达此前已废弃的New Edinburgh，与1698初次驻地及1699-07第一远征撤离分开。
- **1700-01** 殖民方主动攻击西班牙Toubacanti，是苏格兰公司军事行为而非英国军队；与后续围攻Fort St Andrew分成不同事件。
- **1700-02-13 / 03-15 / 03-28 / 04-12 / 04-13**：2025卷/2026出版显示的西班牙语同行评审论文 Channing Eberhard与Pajuelo Moreno 引用Borland (1715)等材料，分别提到据点击退进攻、Pimienta最后通牒、苏军致函议和、**4月12日正式签降约、13日开始撤离**。因原始1715史书/西班牙原件及儒略历/公历尚未并列复核，事件ID标记`day_reported_calendar_unconfirmed`。网页论文主页：https://revistadeindias.revistas.csic.es/index.php/revistadeindias/article/view/1835 ；已索引PDF：https://revistadeindias.revistas.csic.es/index.php/revistadeindias/article/download/1835/2246?inline=1 （全文扫描工具读取超时，绝不写“独立读过原卷”）。
- **1700-12-31**：达连苏格兰第二殖民据点已经退出，可作为政治状态的“该据点不继续占据”的强结论，但无据将其涂为西班牙对全部Guna Yala土地的新实控多边形。
- **1707** 《联合条款》第15条的`Equivalent`法定总额£398,085 10s，具有抵销英债/税负、达连投资者退偿、欠薪、经济建设等多重法定/政策用途。第一批付款1707年8月到达。它不是当年达连取得的经济收益、也不能声称£398,085 10s全额已转给达连投资者。档案链接：https://www.scottisharchivesforschools.org/union1707/chapter3-3.asp 和 https://www.scottisharchivesforschools.org/union1707/chapter8.asp 。

## II. 爱尔兰：区分1702、1704、1778、1782、1783、1798、1799—1801

| 年份 | 政治/法制动作 | 判断与地图含义 | 来源 |
|---|---|---|---|
| 1702 | **英格兰**议会1 Anne c.26约束爱尔兰没收地产的租赁及天主教继承 | 与爱尔兰议会1704法令非同一法律；地产权利不等于领土实控改变 | C2-IRL-1702 |
| 1703—1704 | 爱尔兰议会2 Anne c.6 对宗教与购地继承施加系统限制 | 以法令地点Dublin作行政参考，不把全部被限制土地画成新英军占领 | S53, S53a |
| 1778 | 爱尔兰王国议会Catholic Relief Act 放松主要土地取得和遗嘱处分限制 | 旧法制的明确逆向节点；需逐条原法审查例外 | C2-IRL-1778 |
| 1779—1780 | 英国议会逐项松动爱尔兰商业限制，EIC垄断仍存在 | 贸易准入制度变化，不做政治疆域涂色 | C2-IRL-1782 |
| 1782 | 英国撤销1720 Declaratory Act、Poynings法被实质修改，爱尔兰议会内部事务立法获得更广权限 | 爱尔兰国别仍与大不列颠分开，且大不列颠仍任命行政长官 | C2-IRL-1782, C2-IRL-1494 |
| 1783 | 英国进一步确认爱尔兰法定立法与终审权限（Renunciation） | 不要把1720—1800全部套同一“英国议会完全有权直接立法”的静态语句 | C2-IRL-1783 |
| 1798 | 起义者5月23—24日首先在Kildare、Meath、Dublin行动；Wexford当地随后爆发 | 不把所有城市“1798全年起义军/英军”涂成同一权力区 | C2-IRL-1798-ARCH |
| 1798-06-21 | Vinegar Hill起义军营地遭攻克 | 战事各地逐场评定；不能理解为国家控制当日一次切换 | C2-IRL-1798-ARCH |
| 1798-08-23 | 法国远征队抵达Killala Bay | 法方单次登陆，不可推成整个Mayo为法国长时辖区 | C2-IRL-1798-ARCH |
| 1799-01-24 | 爱尔兰下院拒绝联合提案 | 1799不是英爱已经合并 | C2-IRL-UNION |
| 1800-08-01 / 1801-01-01 | 联合法批准后于1801年元旦生效 | **下个世纪真实法定政治断点**，1800年案卷不倒填1799或1707 | C2-IRL-UNION |

爱尔兰国家档案馆的1798史料包共有17件史料影印目录：1798-05-27 Oulart败报、1798-06-06 Wexford军队命令、1798-09-25 Killala军情信、1799-07-16军法庭等。**写信之日≠信中所叙军事行动之日。**该PDF可以检索文字，但本轮网页截图功能返回404，故访问深度仅标记“政府PDF文本+索引”，未标记完整影像核对。来源：https://www.nationalarchives.ie/PDF/1798.pdf 。

## III. 苏格兰：1792年高地抗议可具年，不把19世纪Sutherland塞入18世纪

- 苏格兰历史学会将*first wave*概括为1780年代开始，持续至19世纪初。缺少某庄园逐块地籍和租户账本时，只是一个历史过程，不是可按十年涂色的行政封锁圈。
- **1792 Ross-shire/Strathrusdale “Year of the Sheep”**：Alexander Dick发表于*Studies in Scottish Literature*第46卷(2020)的同行评审论文摘要记约200名高地农民参加驱赶牧羊活动，估计最多1万只羊。此为**抗议牧场扩张**，人数为研究摘要估计，不是“1792被驱逐1万人”。来源：https://scholarcommons.sc.edu/ssl/vol46/iss1/6/ 。
- 法律层次：1747 Act of Proscription限制**男性平民**的特定高地服饰，妇女与军人另有例外；1782年禁令撤销。禁止盖尔语、所有格子呢、所有高地居民或以1809—1821大规模清场方式描述1792，均不符合来源。来源：https://www.nrscotland.gov.uk/learning-and-events/all-features-and-articles/tartan-the-fabric-of-a-nation/ 。

## IV. 澳大利亚：1770原住民族争议、1788后多地建站、1795原住民土地冲突

- **1770-08-22 Tuined/Possession Island**：Cook日志明确记录宣称东岸属于英王。澳大利亚博物馆访问Kaurareg传统土地守护者记录指出，其族群**质疑**Cook曾上岛举行升旗仪式。应展示两种证言，保留1770的“声索”层，不画整个澳大利亚实际已驻军面积。https://www.nma.gov.au/exhibitions/endeavour-voyage/cooks-journal/august-1770 与 https://australian.museum/learn/first-nations/unsettled/recognising-invasions/contested-possession/ 。
- **1788-03-06** Norfolk Island的Kingston/Arthurs Vale：Philip Gidley King率早期小队建立殖民站；这是Sydney Cove之后第二处可具名实际建站地点，不能因为分配整岛而宣称已有真实界线。国家遗产局：https://www.dcceew.gov.au/parks-heritage/heritage/places/national/kavha 。
- **1788-11-02** Rose Hill（今Parramatta）：在Burramattagal/Darug Country建立殖民农田据点，1789 James Ruse农作、1791-03-30实验农场地权、1791-06-04改名。地点历史由Parramatta市政府档案支持；传统土地政治与殖民地开垦必须双层表示。https://historyandheritage.cityofparramatta.nsw.gov.au/blog/2015/05/26/parramatta-timeline-1788-present 。
- **1793/94** Hawkesbury河沿岸第一批农业土地“追认授予”成为新实地扩展点；但跨河的Darug、Darkinjung政治不能用殖民文书取代。
- **1795年5月** Acting Governor Paterson部署62名军人到Hawkesbury河沿，欲驱离当地原住民族，殖民方**报告**射杀7—8人及拘押5人（损失口径仅为殖民官员报告）。Towards Truth已将不同殖民信件、军令索引为DOC5887等，下一轮须查每个DOC原信。不能把击毙地点GPS定位为“河中心”，也不能把官方报告等同所有实际伤亡。https://www.towardstruth.org.au/themes/country/dispossession/120-frontier-wars/sub0533-hawkesbury-river 。
- **1796年2月** Hunter发出河岸定居者防务与不得随意射杀原住民的并列命令，表明前一年的军事行动不可自动绘成永久驻军占领全部河道。
- **1797年3月** Pemulwuy先攻Toongabbie的政府农场，再在Parramatta外围遭殖民人武装追击受伤；与1794 Toongabbie斩首事件应分开。ANU澳洲传记：https://adbonline.anu.edu.au/biography/pemulwuy-13147 。

### 数据中的数值不得互换

- Museums of History NSW报第一舰队759名受遣送者，13名同行儿童；State Library NSW另一介绍谨慎标750—780囚犯区间。数字口径不同，未复核逐人旅客名单前，不把两者相加或称全程航次死亡率。
- 1707 £398,085 10s是财政Equivalent总额，不是达连殖民净损失或运奴利润。
- 1792至多约10,000羊只与抗议者约200人是不同统计分母。
- 1795 7—8人死亡/5被俘是殖民政府自报，且只是一次行动的记述，不是该地区死伤总计。
- 1799 1,008 Hawkesbury定居人口是某地某年人口口径，与被夺地土著人数无关。

### 空间数据门禁

所有新增8处`MAP_CANDIDATES.geojson`候审地点目前`geometry:null`。已有3个参考坐标点保持不动、原始GIS数据不修改为“精确历史位置”。一旦要为Parramatta、Norfolk Island、Tuined等地绘制代表点，须找到可复核的现代官方坐标，并标为`modern_reference_point`；领土多边形全部待核。
