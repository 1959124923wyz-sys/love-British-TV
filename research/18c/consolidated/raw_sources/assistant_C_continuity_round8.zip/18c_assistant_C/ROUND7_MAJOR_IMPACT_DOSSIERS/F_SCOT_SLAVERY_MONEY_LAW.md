# 苏格兰海外奴役经济、国内司法和政治制度

**状态：research_only，非正式地图文章。**

本档案是主编阅研索引；所有行动者、地理、来源和历史边界均以EVENT_CANDIDATES和SOURCE_REGISTRY为准。

## 1. 1769-01-20｜爱丁堡报纸刊载转让被奴役黑人少年的广告

**主体：** 苏格兰个人奴役持有人、报纸广告商。**行为：** 公开登载把一名年幼黑人家仆当作可处分财产的广告。
**地点：** 爱丁堡。**地图状态：** `material_culture_evidence`。
**史料限制：** 广告反映欲处分行为，不默认交易成交或该少年的后续命运。

**来源：** [C7-S25](https://www.nms.ac.uk/discover-catalogue/the-experiences-of-enslaved-people)

## 2. 1774-05-20｜Joseph Knight在Perth获得反对永久奴役的重要有利裁决

**主体：** Joseph Knight及Perth郡法院。**行为：** 地方法院反对殖民地奴役权在苏格兰执行，Wedderburn提起上诉。
**地点：** Perth，Scotland。**地图状态：** `court_event_core_point_reference`。
**史料限制：** 诉讼延续到1778；日期对应Perth郡法庭摘录。

**来源：** [C7-S22](https://www.nrscotland.gov.uk/learning-and-events/slavery-and-scotland/the-joseph-knight-case/)

## 3. 1778-01-15｜苏格兰最高民事法院确认Joseph Knight摆脱永久强制劳役

**主体：** 苏格兰Court of Session与Joseph Knight。**行为：** 确认牙买加种植园主对Knight主张的永久劳役和强制送离苏格兰权利不可执行。
**地点：** 爱丁堡，苏格兰最高民事法院。**地图状态：** `court_event_core_point_reference`。
**史料限制：** NRS写8比4，司法机构写10比4，应保留冲突，不以票数判断判决的有无。

**来源：** [C7-S22](https://www.nrscotland.gov.uk/learning-and-events/slavery-and-scotland/the-joseph-knight-case/), [C7-S23](https://www.judiciary.scot/home/media-information/media-hub-news/2022/12/06/plaque-marks-historic-slavery-case-at-court-of-session)

## 4. 1769｜克莱德河三大港口承担英国烟草进口的约52%

**主体：** 格拉斯哥商人与被奴役劳动支持的切萨皮克贸易网络。**行为：** Glasgow、Greenock、Port Glasgow合计英国当年烟草进口约52%。
**地点：** 格拉斯哥与克莱德河港口。**地图状态：** `statistical_flow_not_territory`。
**史料限制：** 52%为英国烟草进口份额，不是英国奴隶贸易航次占比、非法制实控面积。

**来源：** [C7-S26](https://academic.oup.com/ajlh/article/63/2/150/7231728)

## 5. 1792｜Henry Dundas促使立即废除贩奴贸易提案改为渐进方案

**主体：** 英国政府内阁成员Henry Dundas与英国议会。**行为：** 推动对废奴贸易提案加入渐进条款；改变当时议会方案的立法进程。
**地点：** 伦敦议会；苏格兰政治网络。**地图状态：** `political_legislative_action`。
**史料限制：** NMS对动机/后果提供分析，正式文本及议会表决需进一步逐页复核。

**来源：** [S88](https://www.nms.ac.uk/discover-catalogue/scotland-and-the-transatlantic-slave-system)

## 6. 1793｜Leith Banking Company由有殖民商人背景的合伙人创立

**主体：** Leith银行合伙人、部分殖民商人。**行为：** 18名合伙人建立银行，体现苏格兰金融与殖民贸易的关系。
**地点：** Leith，Edinburgh。**地图状态：** `commercial_institution_not_slave_ownership`。
**史料限制：** 不能把18名合伙人全认定奴隶主；逐人股权与贷款档案待核。

**来源：** [S88](https://www.nms.ac.uk/discover-catalogue/scotland-and-the-transatlantic-slave-system)

## 7. 1794｜牙买加种植园主向Doune教区教堂捐赠圣餐杯

**主体：** William Mitchell及Kilmadock教会。**行为：** 在苏格兰当地捐赠器物，反映海外种植园财产与本土社会联系。
**地点：** Doune／Kilmadock，苏格兰。**地图状态：** `evidenced_object_provenance`。
**史料限制：** 物证可核，杯子本身不等于已审核种植园利润净额。

**来源：** [S88](https://www.nms.ac.uk/discover-catalogue/scotland-and-the-transatlantic-slave-system)

## 8. 1796｜Henry Dundas担任殖民战争大臣时英军干涉加勒比殖民秩序

**主体：** 英国战争与殖民部、英国远征军。**行为：** 推进牙买加等西印度群岛军政行动并干预海地摆脱奴役过程。
**地点：** 伦敦／加勒比（多地）。**地图状态：** `cross_region_handoff_only`。
**史料限制：** 具体海地、圣文森特、牙买加军次交助手1；不能在苏格兰地图画跨洋军事控制。

**来源：** [S88](https://www.nms.ac.uk/discover-catalogue/scotland-and-the-transatlantic-slave-system)

## 主编验收门禁

- 每个历史行为须有独立年份；年份范围不能在前端显示为每年发生同一战斗。
- 不是实控地籍Polygon。地点为历史地名参考或现代遗址参考，不能被当作实际战争范围。
- 源文档链接存在不代表馆藏未公开原手稿已经逐叶审查。
- 与旧库事件合并时保留稳定研究ID和史料冲突台账。
