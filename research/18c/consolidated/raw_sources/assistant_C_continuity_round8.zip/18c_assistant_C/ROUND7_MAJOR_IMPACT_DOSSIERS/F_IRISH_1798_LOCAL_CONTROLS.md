# 爱尔兰1798—1799短期城镇实控与多方镇压

**状态：research_only，非正式地图文章。**

本档案是主编阅研索引；所有行动者、地理、来源和历史边界均以EVENT_CANDIDATES和SOURCE_REGISTRY为准。

## 1. 1795-09-21｜Armagh宗派团体在Battle of the Diamond冲突

**主体：** Defenders与Peep o’ Day Boys等团体。**行为：** 在Loughgall附近发生战斗，之后Orange Order成立。
**地点：** Loughgall／The Diamond，Armagh。**地图状态：** `sectarian_conflict_not_crown_battle`。
**史料限制：** 责任多主体，不能将所有宗派冲突归于正规英军命令。

**来源：** [C7-S14](https://cain.ulster.ac.uk/othelem/chron/ch1169-1799.htm)

## 2. 1797｜爱尔兰政府在1798起义前扩大军事戒严与解除武装

**主体：** 爱尔兰政府、英军、民兵、Yeomanry。**行为：** 在爱尔兰多地实施戒严、搜捕、军事反叛乱与酷刑。
**地点：** 爱尔兰王国（各郡）。**地图状态：** `institutional_repression_no_region_polygon`。
**史料限制：** 需逐郡查军方命令与强制行动，不把全岛画成战时占领变动。

**来源：** [C7-S14](https://cain.ulster.ac.uk/othelem/chron/ch1169-1799.htm), [C6-IRL-NAM-1798](https://www.nam.ac.uk/explore/irish-rebellion-1798)

## 3. 1798-06-07｜Antrim起义军短暂攻入城镇后遭政府军反击

**主体：** Henry Joy McCracken麾下联合爱尔兰人及王室军队。**行为：** 起义军对Antrim发动进攻并短暂在镇内交战，政府增援部队收复。
**地点：** Antrim town，Ulster。**地图状态：** `contested_short_episode_no_polygon`。
**史料限制：** 短时易手/部分街区不能据此绘制全郡起义军稳定地块。

**来源：** [C7-S15](https://historyireland.com/1798-in-the-north/), [C7-S16](https://discoverulsterscots.com/history-culture/story-presbyterians-ulster)

## 4. 1798-06-07｜起义军占据Ballymena并短时组建治理委员会

**主体：** 当地联合爱尔兰人。**行为：** 约三天占据城镇并组织临时政治委员会，之后接受当局赦免条件。
**地点：** Ballymena，Antrim郡。**地图状态：** `short_local_regime_core_review`。
**史料限制：** 约三日为史学叙述，不精造结束日；需原始驻军记录。

**来源：** [C7-S15](https://historyireland.com/1798-in-the-north/)

## 5. 1798-06-09｜Saintfield起义军伏击迫使政府军撤退

**主体：** County Down联合爱尔兰人和政府York Fencibles。**行为：** 伏击殖民政府军队，后续起义军集结Ballynahinch。
**地点：** Saintfield，Down郡。**地图状态：** `battle_not_sustained_territory`。
**史料限制：** 单次战斗胜利不等于后续政治统治。

**来源：** [C7-S15](https://historyireland.com/1798-in-the-north/)

## 6. 1798-07-17｜Antrim起义领袖Henry Joy McCracken被处决

**主体：** 爱尔兰王室军事司法系统。**行为：** 俘获McCracken后经审讯在贝尔法斯特绞刑。
**地点：** Belfast。**地图状态：** `execution_reference`。
**史料限制：** 用正式城市地点参考，具体刑场位置需进一步核原始档。

**来源：** [C7-S15](https://historyireland.com/1798-in-the-north/), [C7-S16](https://discoverulsterscots.com/history-culture/story-presbyterians-ulster)

## 7. 1799-02-15｜Michael Dwyer在Wicklow山区逃脱政府军搜捕

**主体：** 起义余部Michael Dwyer、Sam McAllister与政府军。**行为：** McAllister牺牲掩护Dwyer逃出，当地游击抵抗持续到19世纪初。
**地点：** Dwyer McAllister Cottage，Wicklow山区。**地图状态：** `historic_site_reference`。
**史料限制：** 1798起义实际行动并未全部在1798年12月停止，另存1800—1803续篇。

**来源：** [C7-S17](https://heritageireland.ie/educational-downloads/dwyer-mcallister-cottage/)

## 主编验收门禁

- 每个历史行为须有独立年份；年份范围不能在前端显示为每年发生同一战斗。
- 不是实控地籍Polygon。地点为历史地名参考或现代遗址参考，不能被当作实际战争范围。
- 源文档链接存在不代表馆藏未公开原手稿已经逐叶审查。
- 与旧库事件合并时保留稳定研究ID和史料冲突台账。
