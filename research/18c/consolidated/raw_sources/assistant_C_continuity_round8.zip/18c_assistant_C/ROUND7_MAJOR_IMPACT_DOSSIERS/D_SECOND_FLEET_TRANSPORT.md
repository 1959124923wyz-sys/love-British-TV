# 1717—1791流放体系、美洲中断与第二舰队

**状态：research_only，非正式地图文章。**

本档案是主编阅研索引；所有行动者、地理、来源和历史边界均以EVENT_CANDIDATES和SOURCE_REGISTRY为准。

## 1. 1717｜英国建立规范化罪犯海外流放法制

**主体：** 大不列颠议会。**行为：** 1717运输法明确7年与14年刑期；美洲殖民地成为主要目的地。
**地点：** 伦敦／英格兰议会。**地图状态：** `political_legal_context`。
**史料限制：** 英属美洲流放先于1788澳洲；不可绘作1717澳大利亚殖民。

**来源：** [S37](https://www.nma.gov.au/defining-moments/resources/convict-transportation-peaks), [C7-S29](https://www.nationalarchives.gov.uk/help-with-your-research/research-guides/criminal-transportation/)

## 2. 1785｜英国枢密院筹建新南威尔士罪犯殖民地

**主体：** 英王枢密院／英方行政机关。**行为：** 发布筹建流放殖民地的Orders in Council（馆方编年）。
**地点：** 伦敦／新南威尔士纸面拟议地。**地图状态：** `legal_claim_only`。
**史料限制：** 决定殖民地点不能证明1785年已在澳洲驻军。

**来源：** [S37](https://www.nma.gov.au/defining-moments/resources/convict-transportation-peaks)

## 3. 1786-10-12｜Arthur Phillip获任新南威尔士总督

**主体：** 英王与皇家海军。**行为：** 任命殖民总督并开始组织第一舰队。
**地点：** 伦敦／英格兰。**地图状态：** `legal_administrative_not_land_control`。
**史料限制：** 任命当日未有澳洲实际驻点。

**来源：** [S37](https://www.nma.gov.au/defining-moments/resources/convict-transportation-peaks)

## 4. 1787-04-25｜Phillip治理指示给新南威尔士宽泛法定经度声索

**主体：** 英王政府及殖民行政官。**行为：** 草拟殖民辖域至东经135度，要求管理流放犯及对原住民维持友好。
**地点：** 伦敦；新南威尔士图上声索。**地图状态：** `paper_claim_only`。
**史料限制：** 135度只是拟议文书声索经线，不生成控制Polygon。

**来源：** [C7-S05](https://www.migrationheritage.nsw.gov.au/exhibition/objectsthroughtime/draughtinstructions/index.html)

## 5. 1790｜第二舰队极端苛刻运输导致大量囚犯途中死亡

**主体：** 运输合约承包者与英方流放体系。**行为：** 第二舰队男性流放者约1250，逾四分之一在航途中死亡；抵岸幸存者大批住院。
**地点：** 英格兰港口—悉尼湾。**地图状态：** `no_route_geometry`。
**史料限制：** 约1250和逾25%来自州立图书馆综述；不编造分船人数和死者精确定位。

**来源：** [C7-S01](https://guides.sl.nsw.gov.au/convicts-bound-for-australia/second_fleet)

## 6. 1791-04｜首批从爱尔兰直接出航的新南威尔士流放船启航

**主体：** 爱尔兰王国政府与英方帝国流放网络。**行为：** 爱尔兰议会1786/1790年流放制度调整之后，第一船约1791年4月启航。
**地点：** 爱尔兰港口→新南威尔士。**地图状态：** `origin_destination_no_ship_route`。
**史料限制：** 档案指南支持月份，具体船名和启航港应核原船册。

**来源：** [C7-S03](https://nationalarchives.ie/wp-content/uploads/2025/01/Ireland_Australia_transportation.pdf)

## 7. 1786｜爱尔兰议会通过自身的海外流放法律

**主体：** 爱尔兰王国议会。**行为：** 26 Geo III c24允许将囚犯流放欧洲之外，尚不能直接套用英格兰1784法律。
**地点：** 都柏林。**地图状态：** `institutional_legal`。
**史料限制：** 区别两个王国各自立法。

**来源：** [C7-S03](https://nationalarchives.ie/wp-content/uploads/2025/01/Ireland_Australia_transportation.pdf)

## 8. 1790｜爱尔兰议会修订囚犯海外流放执行程序

**主体：** 爱尔兰王国议会。**行为：** 30 Geo III c32便利流放执行，为1791年从爱尔兰启航铺路。
**地点：** 都柏林。**地图状态：** `institutional_legal`。
**史料限制：** 法律阶段不同于1791年实际首航。

**来源：** [C7-S03](https://nationalarchives.ie/wp-content/uploads/2025/01/Ireland_Australia_transportation.pdf)

## 主编验收门禁

- 每个历史行为须有独立年份；年份范围不能在前端显示为每年发生同一战斗。
- 不是实控地籍Polygon。地点为历史地名参考或现代遗址参考，不能被当作实际战争范围。
- 源文档链接存在不代表馆藏未公开原手稿已经逐叶审查。
- 与旧库事件合并时保留稳定研究ID和史料冲突台账。
