# 新南威尔士1788—1799定居农业和Burramattagal土地侵入

**状态：research_only，非正式地图文章。**

本档案是主编阅研索引；所有行动者、地理、来源和历史边界均以EVENT_CANDIDATES和SOURCE_REGISTRY为准。

## 1. 1788｜Rose Hill殖民扩张破坏Burramattagal食物与地权

**主体：** 殖民总督、驻兵及被强制派工者。**行为：** 清林、铲除山药、开垦，挤占Dharug的狩猎采集和生活地点。
**地点：** Rose Hill／Parramatta。**地图状态：** `contextual_local_dispossession`。
**史料限制：** 行动为逐期过程，非单一精确日或可测占地多边形。

**来源：** [C3-AU-CITYPARRA-FOUND](https://historyandheritage.cityofparramatta.nsw.gov.au/research-topics/events/parramattas-foundation-story), [C2-AU-PARRA-IND](https://historyandheritage.cityofparramatta.nsw.gov.au/research-topics/suburbs/rosehill-brief-history)

## 2. 1791-04｜政府在Toongabbie建立较大农业劳役农场

**主体：** 新南威尔士殖民总督与流放犯劳役体系。**行为：** 设立政府农场、清地开垦并依靠流放犯劳动。
**地点：** Toongabbie，Dharug传统土地。**地图状态：** `local_settlement_not_area_polygon`。
**史料限制：** 建立农场说明局地定居活动；无原始地块图不可画圈作耕地面积。

**来源：** [C7-S07](https://historyandheritage.cityofparramatta.nsw.gov.au/blog/2015/06/05/oaks-reserve-old-toongabbie), [C3-AU-CITYPARRA-FOUND](https://historyandheritage.cityofparramatta.nsw.gov.au/research-topics/events/parramattas-foundation-story)

## 3. 1793｜John Macarthur取得Rosehill地区授地并建立Elizabeth Farm

**主体：** 新南威尔士殖民行政当局及John Macarthur。**行为：** 授出约100英亩并在当年营建农舍，建立私人殖民地产。
**地点：** Rosehill／Parramatta，Dharug土地。**地图状态：** `individual_grant_without_survey_polygon`。
**史料限制：** 100英亩来自市政史，不自动扩成Hawkesbury/整州领土。

**来源：** [C2-AU-PARRA-IND](https://historyandheritage.cityofparramatta.nsw.gov.au/research-topics/suburbs/rosehill-brief-history)

## 4. 1797-07-01｜美利奴羊引进奠定澳洲殖民羊毛经济后续扩张基础

**主体：** 殖民牧畜者。**行为：** 引进美利奴羊种并逐步改良，后世牧羊开拓加剧土地压力。
**地点：** 新南威尔士（具体初次引进点需核）。**地图状态：** `regional_reference_only`。
**史料限制：** 年度事实可核但不得用后世牧场覆盖1797年；具体传播地点与头数待核。

**来源：** [NSW-1794](https://www.nma.gov.au/defining-moments/defining-moments-timeline)

## 主编验收门禁

- 每个历史行为须有独立年份；年份范围不能在前端显示为每年发生同一战斗。
- 不是实控地籍Polygon。地点为历史地名参考或现代遗址参考，不能被当作实际战争范围。
- 源文档链接存在不代表馆藏未公开原手稿已经逐叶审查。
- 与旧库事件合并时保留稳定研究ID和史料冲突台账。
