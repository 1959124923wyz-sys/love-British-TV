# 苏格兰1715、1719、1746分期战争与战败强制流放

**状态：research_only，非正式地图文章。**

本档案是主编阅研索引；所有行动者、地理、来源和历史边界均以EVENT_CANDIDATES和SOURCE_REGISTRY为准。

## 1. 1715-11-13｜Sheriffmuir发生詹姆斯党与政府军大会战

**主体：** 詹姆斯党Mar军与阿盖尔公爵政府军。**行为：** 两军会战并于其后分别退兵；1715起义延续至1716初。
**地点：** Sheriffmuir，Perthshire。**地图状态：** `battle_needs_local_map_review`。
**史料限制：** 国家陆军博物馆用词有胜负简化，需Historic Environment Scotland地图独立审查。

**来源：** [C7-S19](https://www.nam.ac.uk/explore/jacobites)

## 2. 1719-05｜英方海军攻击并毁坏Eilean Donan城堡据点

**主体：** 英王海军与詹姆斯党／西班牙支持者。**行为：** 海军炮击和摧毁詹姆斯党军事指挥据点。
**地点：** Eilean Donan，Loch Duich。**地图状态：** `named_castle_battle_reference`。
**史料限制：** 1719战事而非1745詹姆斯党持续同一战役。

**来源：** [C7-S19](https://www.nam.ac.uk/explore/jacobites), [C7-S20](https://portal.historicenvironment.scot/apex/f?p=1505%3A300%3A%3A%3A%3A%3AVIEWTYPE%2CVIEWREF%3Adesignation%2CBTL10)

## 3. 1719-06-10｜Glenshiel战役结束1719詹姆斯党起义

**主体：** 英国政府军与詹姆斯党、少量西班牙军。**行为：** 政府军击败山谷防线，其后西班牙分队投降。
**地点：** Glenshiel，Highlands。**地图状态：** `official_battlefield_reference_only`。
**史料限制：** 现代战场清单边界是考古景观，不是1719英国主权地籍；可参考HES NGR中心点。

**来源：** [C7-S20](https://portal.historicenvironment.scot/apex/f?p=1505%3A300%3A%3A%3A%3A%3AVIEWTYPE%2CVIEWREF%3Adesignation%2CBTL10), [C7-S19](https://www.nam.ac.uk/explore/jacobites)

## 4. 1746-08-01｜《禁止法》对高地实施武器及服饰限制

**主体：** 英国议会／高地驻军。**行为：** 在1716缴械制度基础上强制限制武器携带并规定惩罚。
**地点：** 苏格兰高地。**地图状态：** `statute_social_control_no_polygon`。
**史料限制：** 准确条款不同处罚各异；穿着限制与此前研究记1747执行要区分。

**来源：** [C7-S21](https://ntswebstorage01.blob.core.windows.net/nts-web-assets-production/downloads/Culloden_Learning_Resource.pdf)

## 5. 1746｜卡洛登战后詹姆斯党嫌疑人被监禁并强制运往海外

**主体：** 英国政府军及军事司法当局。**行为：** 逮捕数千人，部分被处决，936名幸存者被流放以供契约劳役（信托馆方口径）。
**地点：** 苏格兰、英格兰监狱、海外流放目的地。**地图状态：** `multi_site_transport_not_route`。
**史料限制：** 936源为信托资源整理数字，不得称同一艘船的流放人数或与死亡数相加。

**来源：** [C7-S21](https://ntswebstorage01.blob.core.windows.net/nts-web-assets-production/downloads/Culloden_Learning_Resource.pdf)

## 主编验收门禁

- 每个历史行为须有独立年份；年份范围不能在前端显示为每年发生同一战斗。
- 不是实控地籍Polygon。地点为历史地名参考或现代遗址参考，不能被当作实际战争范围。
- 源文档链接存在不代表馆藏未公开原手稿已经逐叶审查。
- 与旧库事件合并时保留稳定研究ID和史料冲突台账。
