# 爱尔兰1740—1797饥荒、Whiteboys、宗教土地税费制度

**状态：research_only，非正式地图文章。**

本档案是主编阅研索引；所有行动者、地理、来源和历史边界均以EVENT_CANDIDATES和SOURCE_REGISTRY为准。

## 1. 1740｜1740—1741年严寒歉收触发爱尔兰大饥荒

**主体：** 气候冲击与爱尔兰既有经济社会结构。**行为：** 1740严寒、粮价上涨，延续1741饥荒和移民。
**地点：** 爱尔兰王国（多个地方）。**地图状态：** `multi_region_context_no_polygon`。
**史料限制：** 1740—1741跨年过程；死亡数为史家估计，不能说英国政府蓄意制造。

**来源：** [C7-S11](https://www.environmentandsociety.org/mml/irish-famine-1740-1741-famine-vulnerability-and-climate-migration), [C7-S12](https://www.cambridge.org/core/journals/international-review-of-social-history/article/famine-in-european-history-ed-by-guido-alfani-grada-corman-o-cambridge-university-press-cambridge-etc-2017-xi-325-pp-maps-6999-paper-2399/102EC302166801BD24D6AB0650EDF798)

## 2. 1761-10｜Whiteboys在蒂珀雷里边缘反抗围占公地与什一税

**主体：** 爱尔兰Whiteboys农民结社、地产地主与什一税承包人。**行为：** 夜间集会拆毁围栏、反对公地圈占与新增征收。
**地点：** Knockmealdown／Clogheen—Ballyporeen周边。**地图状态：** `regional_agrarian_protest`。
**史料限制：** 学术研究确认1761年末初起，地理多镇不能编造成单个斗争精确点。

**来源：** [C7-S10](https://www.cambridge.org/core/journals/irish-historical-studies/article/abs/whiteboy-movement-17615/51FA8CC01E50A1784078B5A38581D400)

## 3. 1762｜Whiteboys土地与税赋抗争扩展到蒙斯特多个聚落

**主体：** Whiteboys农民网络与爱尔兰地主体系。**行为：** 围栏拆除、集会与抵抗向Kilmallock、Bruff等地扩展。
**地点：** 蒙斯特多地。**地图状态：** `multi_site_not_polygon`。
**史料限制：** 不可描绘为同一连续军事战线或统一组织控制区。

**来源：** [C7-S10](https://www.cambridge.org/core/journals/irish-historical-studies/article/abs/whiteboy-movement-17615/51FA8CC01E50A1784078B5A38581D400)

## 4. 1722｜英国政府授予William Wood向爱尔兰铸铜币特许

**主体：** 英王政府与商人William Wood。**行为：** 批出向爱尔兰供应铜币的特许，引发当地宪制和货币争议。
**地点：** 爱尔兰王国与英格兰。**地图状态：** `legal_claim_not_new_occupation`。
**史料限制：** 不能直接叫作已经证实大规模牟利金额；来源为议会历史。

**来源：** [C5-UK-PARL-IRISH-1720](https://www.parliament.uk/about/living-heritage/evolutionofparliament/legislativescrutiny/parliamentandireland/overview/constitutional-differences/)

## 5. 1723｜爱尔兰出现反对William Wood铜币的抗议

**主体：** 爱尔兰城镇反对者与作家Jonathan Swift。**行为：** 组织公共反对并出版相关宣传作品（1723起的运动）。
**地点：** 都柏林／爱尔兰。**地图状态：** `political_protest`。
**史料限制：** 抗议运动非军事占领，Swift具体小册子年份勿全套记1723。

**来源：** [C5-UK-PARL-IRISH-1720](https://www.parliament.uk/about/living-heritage/evolutionofparliament/legislativescrutiny/parliamentandireland/overview/constitutional-differences/)

## 主编验收门禁

- 每个历史行为须有独立年份；年份范围不能在前端显示为每年发生同一战斗。
- 不是实控地籍Polygon。地点为历史地名参考或现代遗址参考，不能被当作实际战争范围。
- 源文档链接存在不代表馆藏未公开原手稿已经逐叶审查。
- 与旧库事件合并时保留稳定研究ID和史料冲突台账。
