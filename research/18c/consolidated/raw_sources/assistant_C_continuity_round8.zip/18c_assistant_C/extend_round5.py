#!/usr/bin/env python3
"""Round 5: add source-based findings to the existing assistant C research pack.
Preserve all original IDs and never infer possession polygons from charters.
"""
import json,csv,os, pathlib,zipfile,hashlib,collections,datetime
P=pathlib.Path(__file__).resolve().parent
TODAY='2026-11-08'
def load(n):return json.loads((P/n).read_text(encoding='utf-8'))
def save(n,x):(P/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

S=load('SOURCE_REGISTRY.json'); E=load('EVENT_CANDIDATES.json'); G=load('MAP_CANDIDATES.geojson'); C=load('CLAIM_EVIDENCE_MATRIX.json'); D=load('ROUND3_EVIDENCE_CONFLICTS.json'); SITE=load('SITE_SPECIFIC_CONTROL_1697_1715.json'); T=load('CONTROL_TRANSITIONS_1699_1709.json')
old_s=len(S['sources']);old_e=len(E['events']);old_g=len(G['features']);old_c=len(C['claims']);old_d=len(D['conflicts'])
ss={s['id'] for s in S['sources']}; ee={e['id'] for e in E['events']};gg={g['id'] for g in G['features']};cc={c['id'] for c in C['claims']}; dd={d['id'] for d in D['conflicts']}

def src(i,ins,title,url,level,scope):
 if i in ss: return
 S['sources'].append({'id':i,'institution':ins,'title':title,'url':url,'access_level':level,'original_manuscript_personally_inspected':False,'reviewed_online_on':TODAY,'evidence_scope':scope,'source_handling':'Published facsimile/official interpretation/archival description is not proof of personal inspection of original manuscript or surveyed historical boundaries.'})
 ss.add(i)

def ev(i,topic,date,title,actor,action,place,sources,precision='day',geom=None,note='',grade='source_supported_map_review'):
 if i in ee:return
 assert all(s in ss for s in sources),(i,sources,ss)
 E['events'].append({'id':i,'topic_id':topic,'date':date,'date_precision':precision,'title':title,'actor':actor,'action':action,'historical_place':place,'source_ids':sources,'research_state':'research_only','cartographic_status':grade,'geometry_ref':geom,'historical_control_polygon_approved':False,'evidence_notes':note,'round':'fifth_source_research','source_date_calendar':'as_displayed_in_source_unless_noted'})
 ee.add(i)

def claim(i,when,statement,sources,method,limit,eligibility):
 if i in cc:return
 assert all(s in ss for s in sources),(i,sources)
 C['claims'].append({'id':i,'date_or_range':when,'claim_summary':statement,'source_ids':sources,'access_type':method,'audit_limit':limit,'map_eligibility':eligibility,'original_folio_personally_inspected':False})
 cc.add(i)

def conflict(i,old_row,claim_,positions,resolution):
 if i in dd:return
 D['conflicts'].append({'id':i,'prior_row':old_row,'claim':claim_,'positions':positions,'resolution':resolution,'never_merge_as_one_conquest':True,'round':'fifth_source_research'})
 dd.add(i)

def geo(i,name,srcs,links,precision='named_historical_locality_no_event_site_coordinate'):
 if i in gg:return
 G['features'].append({'type':'Feature','id':i,'geometry':None,'properties':{'name':name,'source_ids':srcs,'linked_event_ids':links,'coordinate_method':'not_geocoded_independently','coordinate_status':'attested_name_georeference_pending','geo_precision':precision,'historical_boundary_confirmed':False,'territorial_claim':False,'fill_authorized':False,'area_sqkm':None,'exclude_from_area_aggregation':True,'publication_status':'research_only','map_inclusion':'research_not_published'}})
 gg.add(i)

# SOURCE REGISTER — primary transcripts, institutional histories, historical maps and date-conflict crosschecks.
src('C5-HBC-PARKS-CHURCHILL','Parks Canada','History of Prince of Wales Fort: original 1689 post burnt, permanent return 1717','https://www.parks.canada.ca/lhn-nhs/mb/prince/culture/decouvrir-discover1','national_heritage_site_history','Churchill 1689 fire, 1717 reconstruction; Cree/Dene trading networks distinct from post control')
src('C5-HBC-PARKS-CAPEMERRY','Parks Canada','History of Cape Merry and James Knight 1717 re-establishment','https://parks.canada.ca/lhn-nhs/mb/prince/culture/decouvrir-discover2','national_heritage_site_history','John Abraham 1686; 1689 HBC post built and burned; 1717 renewed HBC construction')
src('C5-HBC-PARKS-YORK','Parks Canada','Human history: York Fort French from 1697 through 1713; Fort Bourbon','https://parks.canada.ca/lhn-nhs/mb/yorkfactory/culture/histoire-history','national_heritage_site_history','Site-specific possession; old Hayes River site not modern later York factory')
src('C5-CAN-DCB-LLOYD','Dictionary of Canadian Biography, University of Toronto / Université Laval','Thomas Lloyd: 21 Dec 1708 (O.S.) / 1 Jan 1709 (N.S.) St Johns capture','https://www.biographi.ca/en/bio/lloyd_thomas_2E.html','peer_reviewed_biographical_history','Exact double calendar, siege, captives and destruction; no historic fort Polygon')
src('C5-NFL-HERITAGE-WAR','Memorial University of Newfoundland / Newfoundland and Labrador Heritage','Anglo-French Conflict, 1690–1713','https://www.heritage.nf.ca/articles/exploration/wartime.php','academic_public_history','1705 unsuccessful capture of forts, 1708 blockade of Plaisance, 1709 French St Johns raid, 1713 transfer')
src('C5-NFL-PARKS-FORTWILLIAM','Parks Canada Historic Sites and Monuments Board','Fort William historical designation','https://www.pc.gc.ca/apps/dfhd/page_nhs_eng.aspx?id=240','heritage_designation_notice_internal_anachronism','1705 repulsed, Jan1709 captured; post-1709 garrison absence; text wrongly compresses British at Placentia to pre1713')
src('C5-SCOT-NLS-DARIENPAPERS','National Library of Scotland digitisation; John Hill Burton edition (1849)','The Darien Papers (1849 printed selection of 1695–1700 originals)','https://deriv.nls.uk/dcn23/7878/78785290.23.pdf','digitised_1849_primary_document_edition_NOT_original_manuscript','Volume contents: 18 March council minute, 21 March commission and Veitch instructions; third expedition observed Spanish flag; no modern accurate survey')
src('C5-SCOT-HES-DARIEN2026','Historic Environment Scotland','Caledonian Catastrophe: Scotland and the Darien Scheme','https://blog.historicenvironment.scot/2026/11/caledonian-catastrophe-scotland-and-the-darien-scheme/','heritage_agency_historical_analysis','Second Darien departure in April 1700; approx victims estimates not independently verified population census')
src('C5-UK-PARL-UNION-RATIFY','UK Parliament','Ratification of Articles of Union: Scottish vote 16 January 1707, 110 vs 67','https://www.parliament.uk/about/living-heritage/evolutionofparliament/legislativescrutiny/act-of-union-1707/overview/ratification-october-1706---march-1707/','legislative_institution_history','Separate Scotland sovereign legislative ratification, prior to 1 May change')
src('C5-UK-PARL-UNION-HOUSE','UK Parliament / House of Lords','Privileges Second Report: separate Scotland assent 16 Jan, England assent 6 Mar 1707','https://publications.parliament.uk/pa/ld199899/ldselect/ldprivi/108i/10806.htm','official_parliamentary_constitutional_report','Separate Acts and assent; legal entity Great Britain begins 1 May 1707')
src('C5-UK-PARL-1707-OVERVIEW','UK Parliament','1707 union key dates / 1705 Aliens Act','https://www.parliament.uk/about/living-heritage/evolutionofparliament/legislativescrutiny/act-of-union-1707/key-dates/','legislative_institution_history','1705 Aliens Act trade pressure; July 1706 Articles; 1707 union')
src('C5-UK-LEGIS-TENURES','legislation.gov.uk / UK National Archives','Tenures Abolition Act 1746 c50 full statutory transcription','https://www.legislation.gov.uk/apgb/Geo2/20/50/data.xht?view=snippet&wrap=true','published_statutory_text','Wardholding and feudal duties conversion from 25 March 1748; distinguish 1746 statute year from 1748 effective')
src('C5-UK-PARL-IRISH-1782','UK Parliament','Meeting Ireland’s terms: 1720 Declaratory Act repeal and Poynings Law relaxation in 1782','https://www.parliament.uk/about/living-heritage/evolutionofparliament/legislativescrutiny/parliamentandireland/overview/meeting-irelands-terms/','legislative_institution_history','Legislative independence 1782 limited by executive still appointed from Britain; not full decolonisation')
src('C5-UK-PARL-IRISH-1720','UK Parliament','Constitutional differences: March 1720 Declaratory Act','https://www.parliament.uk/about/living-heritage/evolutionofparliament/legislativescrutiny/parliamentandireland/overview/constitutional-differences/','legislative_institution_history','Sherlock v Annesley 1719, 1720 supremacy legislation, 1782 reversal')
src('C5-UK-PARL-IRISH-1799','UK Parliament','Parliamentary union: 22/24 January 1799 debate and 1800/1801 stages','https://www.parliament.uk/about/living-heritage/evolutionofparliament/legislativescrutiny/parliamentandireland/overview/parliamentary-union/','legislative_institution_history','1799 initial proposal defeated, 28 March 1800 Irish acceptance, 1 Jan 1801 union effective')
src('C5-AU-NLA-COOK','National Library of Australia','James Cook Endeavour Journal transcription 22 August 1770','https://www.library.gov.au/learn/digital-classroom/indigenous-responses-cook-and-his-voyage/james-cooks-endeavour-journal','first_person_historical_journal_transcription_institutional','22 Aug claimed possession; text may not record unanimous consent; no measured sovereign boundary')
src('C5-AU-NMA-COOK-AUG','National Museum of Australia (with National Library Australia transcript)','August 1770 Cook diary public transcript','https://www.nma.gov.au/exhibitions/endeavour-voyage/cooks-journal/august-1770','institutionally_hosted_primary_diary_transcription','Cook dated declaration 22 August; general coastline claim vs actual temporary landing')
src('C5-AU-NMA-TIMELINE-ERR','National Museum of Australia','Forster background timeline (apparent 13 September 1770 error)','https://www.nma.gov.au/explore/features/cook_forster/background/timeline','institutional_timeline_internal_date_discrepancy','Lists 13 September for claim while Cook 22 August diary; record disagreement, prefer journal date')
src('C5-AU-MUSEUM-CONTEST','Australian Museum, Unsettled exhibition First Nations curators','Contested Possession; Kaurareg responses and evidence question','https://australian.museum/learn/first-nations/unsettled/recognising-invasions/contested-possession/','museum_first_nations_oral_history_curatorial_analysis','Ceremony narrative contested; Cook diary versus Banks accounts; Kaurareg autonomy')
src('C5-AU-NMA-KAURAREG','National Museum of Australia with Kaurareg elders','Bedanug/Tuidin Possession Island and Kaurareg leaders','https://www.nma.gov.au/exhibitions/endeavour-voyage/bedanug-thunadha-bedhan-lag-tuidin-possession-island','museum_indigenous_oral_history_and_diaries','Indigenous witnesses political organization; no British land survey or Kaurareg consent record')
src('C5-AU-SLNSW-FIRSTFLEET','State Library of New South Wales','First Fleet convicts: 11 ships, dates, convicts estimated range','https://guides.sl.nsw.gov.au/convicts-bound-for-australia/first_fleet','state_library_reference_guide','13 May 1787 departure, 18 Jan 1788 Botany Bay, 26 Jan Sydney Cove; transported 750–780 estimated; keep uncertainty')
src('C5-AU-SLNSW-FIRSTFARMS','State Library of New South Wales','First farms Rose Hill government farm and James Ruse','https://www2.sl.nsw.gov.au/archive/discover_collections/history_nation/agriculture/life/farms/index.html','state_library_historical_exhibition','1789 Ruse wheat harvest; >200 acres cultivation government farm end 1791; not historical surveyed parcel polygon')
src('C5-AU-SLNSW-BRADLEY','State Library of New South Wales','Bennelong and Phillip: Bradley drawing 25 November 1789','https://www.sl.nsw.gov.au/stories/bennelong-and-phillip','state_library_collection_history','Bradley historical depiction of Colebee and Bennelong capture, date 25 November 1789')
src('C5-AU-HAWKESBURY-COUNCIL','Hawkesbury City Council; GML Heritage report (2021)','Hawkesbury LGA Aboriginal Cultural Heritage Study; Aboriginal consultation','https://www.hawkesbury.nsw.gov.au/__data/assets/pdf_file/0020/214328/AT-1-Hawkesbury-Aboriginal-Cultural-Heritage-Study.pdf','municipal_commissioned_historical_study_with_community_review','1794–95 land dispossession and violence; contemporary source quotation, evidence uncertainty; government region modern not historic battle perimeter')
src('C5-AU-NSW-PARLIAMENT-SUBMIT','NSW Parliament public submission, author Barry Corr','Submission on frontier Hawkesbury 1795 troops and casualties','https://files.parliament.nsw.gov.au/fileapi/ParlFiles/GetArtifact/0251%20Mr%20Barry%20Corr.pdf?serverRelativeUrl=%2Flcdocs%2Fsubmissions%2F59745%2F0251+Mr+Barry+Corr.pdf','external_research_submission_NOT_official_findings','Claims of troop party ~60, captives and killings; requires Collins diary exact page before authoritative statistics')
src('C5-IRL-NAI-1798','National Archives of Ireland','The Rebellion of 1798: 17 facsimile documents and explanatory notes','https://www.nationalarchives.ie/PDF/1798.pdf','national_archives_educational_facsimile_pack_not_original_folio','23–24 May uprising, Wexford revolt/temporary territory until 21 June, 23 August Killala; soldier letter claims must be attributed')
src('C5-IRL-NAM-1798','National Army Museum','Irish Rebellion of 1798: chronology, violence and participants','https://www.nam.ac.uk/explore/irish-rebellion-1798','army_museum_historical_analysis','Outbreak May 23, Oulart, Arklow, 21 June Vinegar Hill, 27 Aug Castlebar, 8 Sept Ballinamuck; rebels and loyalists violence')
src('C5-IRL-NAM-ORDERS','National Army Museum accession NAM.1985-12-15-8','General orders 29 May 1798–26 May 1801; order 2 June','https://collection.nam.ac.uk/detail.php?acc=1985-12-15-8&pos=10078&q=page%3D507%26resultsDisplay%3Dgrid%26searchType%3Dsimple%26simpleText%3D%26themeID%3D&total=28182','historical_manuscript_catalogue_and_quoted_order_not_complete_folio','2 June order insists soldiers must not burn/destroy without officer order; contemporaneous measures against insurgents')
src('C5-IRL-NAM-BLOMELEY','National Army Museum accession NAM.1987-10-7-1','Corporal Blomeley letter dated 2 July 1798','https://collection.nam.ac.uk/detail.php?acc=1987-10-7-1','historical_letter_catalogue_with_quote','Describes 5 June New Ross battle from hostile army viewpoint; not neutral casualty source')
src('C5-IRL-NAM-FOULKES','National Army Museum accession NAM.1971-02-33-471-1','Engraving Battle of Wexford / Foulkesmills 20 June 1798','https://collection.nam.ac.uk/detail.php?acc=1971-02-33-471-1','museum_object_catalogue_with_scholarly_description','20 June Moore defeats Father Roche at Foulkesmills; 21 June Wexford recapture')
src('C5-IRL-NLI-TAYLOR-MAP','National Library of Ireland MS L 368','A map of Enniscorthy and Vinegar Hill by Alexander Taylor [1798?]','https://catalogue.nli.ie/Record/vtls000640125/StaffViewMARC','archival_cartographic_catalogue_original_map_not_digitally_analyzed','40 perches per inch; routes and Lake attack point; military author perspective; no digitised geo alignment read')
src('C5-IRL-NLI-HARDY-MAP','National Library of Ireland MS L 391','Plan and perspective Vinegar Hill battle by J Hardy [1798]','https://catalogue.nli.ie/Record/vtls000737440','archival_cartographic_catalogue_original_map_not_digitally_analyzed','Battlefield deployments, numbered legend; should georeference after visual original and distortion assessment')
src('C5-IRL-NLI-LAKELETTER','National Library of Ireland','21 June 1798 official Lake dispatch re Vinegar Hill','https://catalogue.nli.ie/Record/vtls000208721/StaffViewMARC','original_imprint_catalogue_only','Official narrative with possible military bias; 21 June dated report')
src('C5-IRL-NAM-KILLALA','National Army Museum','Irish Rebellion 1798: Ballinamuck 8 Sep 1798 and Killala western stage','https://www.nam.ac.uk/explore/irish-rebellion-1798','military_museum_history','Landing date differs NAI 23 Aug vs Irish military study 22 Aug; retain day conflict')
src('C5-IRL-IRISH-MIL-HUMBERT','Military Heritage of Ireland, historical research paper','French landings at Kilcummin 22 Aug 1798','https://www.militaryheritage.ie/wp-content/uploads/2018/11/Gunner-Magee-Defender-of-Arty-Corps-Values.pdf','military_heritage_study_not_original_diary','Says 22 Aug for French landing vs NAI 23 Aug; retain contested until primary ship logs')

# NEW distinct event occurrences / documented archival records. No duplication of existing battle events.
ev('C5-F09-001','E18-F09','1700-03-18','达连殖民委员会召开议降相关会议','苏格兰公司达连殖民地议事委员会','召开有关向西班牙军议降的会议，留存会议纪要','Fort St Andrew／New Edinburgh Darien',['C5-SCOT-NLS-DARIENPAPERS'],'day','PLACE-DARIEN','1849年所刊原文档选辑目录载3月18日会议；勿写成实际投降日')
ev('C5-F09-002','E18-F09','1700-03-21','苏格兰殖民委员会给Veitch船长发出指令','苏格兰公司殖民委员会','向Veitch船长出具办理投降相关事务的委任与指示','Darien Fort St Andrew',['C5-SCOT-NLS-DARIENPAPERS'],'day','PLACE-DARIEN','所刊原文档选辑目录明确日期；内容详页待复核')
ev('C5-F09-003','E18-F09','1700-spring','达连后续苏格兰救援船发现西班牙军旗','苏格兰公司第三次／后续航运人员','后到船只发现Fort Caledonia升起西班牙旗，证实据点丧失','Darien New Edinburgh',['C5-SCOT-NLS-DARIENPAPERS'],'season','PLACE-DARIEN','出版文献序言回顾；精确抵达日未从船舶日志确定')
ev('C5-F03-001','E18-F03','1705','英格兰通过Aliens Act施压苏格兰','英格兰王国议会','以限制苏格兰贸易等措施推动联合谈判','英格兰和苏格兰贸易口岸，不能绘制虚构海关边界',['C5-UK-PARL-1707-OVERVIEW'],'year',None,'立法压力，不是英军征服苏格兰')
ev('C5-F03-002','E18-F03','1707-01-16','苏格兰议会正式批准英苏联合条款','苏格兰议会','以110票比67票批准联合法案及条款','爱丁堡，苏格兰议会',['C5-UK-PARL-UNION-RATIFY','C5-UK-PARL-UNION-HOUSE'],'day','PLACE-EDINBURGH','议会本身至5月1日尚为苏格兰王国议会')
ev('C5-F03-003','E18-F03','1707-03-06','英格兰议会批准联合条款并获得御准','英格兰议会及安妮女王','通过独立的英格兰联合法','伦敦威斯敏斯特',['C5-UK-PARL-UNION-HOUSE'],'day',None,'不是苏格兰法案的同一次表决')
ev('C5-F03-004','E18-F03','1707-10','大不列颠议会首次召开','大不列颠议会','由两个旧王国议会改组后的新议会开始开会','威斯敏斯特',['C5-UK-PARL-1707-OVERVIEW'],'month',None,'5月1日联合法已生效，10月是首次开会，不是生效')
ev('C5-F04-001','E18-F04','1748-03-25','苏格兰wardholding封建土地保有制转换条款生效','大不列颠议会1746年相关土地改革法','废止苏格兰wardholding并将相关土地义务依法转换','苏格兰土地法体系，无法逐地块定位',['C5-UK-LEGIS-TENURES'],'day',None,'与世袭司法权改革同日生效但法案及法律对象不同')
ev('C5-C27-001','E18-C27','1689','丘吉尔河口早期哈德孙湾公司商站当年焚毁','哈德孙湾公司驻站人员','短命木制商站建成即因火灾毁坏；其后1717年才有长期重建','Churchill River上游早期驻点',['C5-HBC-PARKS-CHURCHILL','C5-HBC-PARKS-CAPEMERRY'],'year','PLACE-CHURCHILL-RIVER','17C前史，1700s不能渲染为仍有驻军的英方堡垒')
ev('C5-C27-002','E18-C27','1717','哈德孙湾公司在丘吉尔河重建较稳定商站','哈德孙湾公司James Knight','在1689年烧毁的旧址设立新商站，后为Prince of Wales Fort前身','Churchill River near Cape Merry',['C5-HBC-PARKS-CHURCHILL','C5-HBC-PARKS-CAPEMERRY'],'year','PLACE-CHURCHILL-RIVER','1717时间点，而非1700年英方现存驻点')
ev('C5-F02-001','E18-F02','1720-03','大不列颠议会通过爱尔兰依附地位宣示法','大不列颠议会','宣示其为爱尔兰制定有约束力法律及最终上诉审判的权力','伦敦、都柏林政治制度',['C5-UK-PARL-IRISH-1720'],'month','PLACE-DUBLIN','制度层，不是英国新占领一块土地')
ev('C5-F02-002','E18-F02','1782','英国议会废除1720年依附地位宣示法','大不列颠议会及爱尔兰议会','撤销1720年限制并实质调整Poynings Law，爱尔兰议会取得排他立法权','伦敦、都柏林政治制度',['C5-UK-PARL-IRISH-1782'],'year','PLACE-DUBLIN','行政仍由大不列颠政府任命的总督／秘书掌握，不等于爱尔兰完全独立主权')
ev('C5-F06-001','E18-F06','1796-12','法国支持的入侵爱尔兰行动因冬季风暴失败','法国远征舰队与联合爱尔兰人关联成员','拟登陆支援起义，但航海风暴导致撤回法国','爱尔兰西南外海',['C5-IRL-NAM-1798'],'month',None,'失败的远征，不画侵入陆地主权或确定船舶GPS航迹')
ev('C5-F06-002','E18-F06','1798-05-18','联合爱尔兰人领导人Edward Fitzgerald遭抓捕时受致命伤','王室安全人员与Lord Edward Fitzgerald','Fitzgerald拒捕过程中受伤，后来死亡，打击起义组织','都柏林',['C5-IRL-NAM-1798'],'day','PLACE-DUBLIN','将个体事件与5月23日全面起义区分')
ev('C5-F06-003','E18-F06','1798-06-02','英军总参谋命令限制部队未经许可焚烧房屋','爱尔兰驻军副将George Hewitt所记录军令／Gerard Lake指挥体系','要求军队未经军官命令不许焚毁房屋及财产，表明反叛乱军事行动中存在焚毁风险','爱尔兰政府军命令体系（未指定唯一地名）',['C5-IRL-NAM-ORDERS'],'day',None,'来自馆藏军令目录及选引，不能当作命令全部得到遵行')
ev('C5-F06-004','E18-F06','1798-06-05','政府军抵御联合爱尔兰人在New Ross的攻击','联合爱尔兰人起义队伍、英国与爱尔兰政府驻军','起义者攻击New Ross遭到军队抵抗，成为韦克斯福德扩张失败的一环','New Ross, County Wexford',['C5-IRL-NAM-BLOMELEY','C5-IRL-NAM-1798'],'day','PLACE-NEWROSS','历史士兵书信对起义者带强烈敌意，不能以之单独估算伤亡')
ev('C5-F06-005','E18-F06','1798-06-09','Arklow政府驻军击退起义军','联合爱尔兰人起义队伍、英国与爱尔兰政府驻军','起义军向韦克斯福德外扩大失败','Arklow, County Wicklow',['C5-IRL-NAM-1798'],'day','PLACE-ARKLOW','胜负已证，城区精确战线和范围未证')
ev('C5-F06-006','E18-F06','1798-06-20','Foulkesmills英国政府军击败约翰·罗奇神父队伍','政府军John Moore及起义者Father Roche率军','政府军击退企图防御韦克斯福德外围的起义队伍','Foulkesmills, County Wexford',['C5-IRL-NAM-FOULKES'],'day','PLACE-FOULKESMILLS','士兵数字是博物馆对当时战斗的近似归述，避免固定为准确兵员总数')
ev('C5-F06-007','E18-F06','1798-06-21','Vinegar Hill战役的政府军作战报告当天发出','Gerard Lake、爱尔兰都柏林城堡政务机关','官方发布叙述政府军击败起义军的通讯','Enniscorthy and Vinegar Hill',['C5-IRL-NLI-LAKELETTER'],'day','PLACE-VINEGAR','1798文献原版编目可查；为政府军视角，伤亡和起义动机须多源交叉核对')
ev('C5-F06-008','E18-F06','1798-09','英国政府军在Ballinamuck后攻入Killala镇','爱尔兰王室/政府军与地方起义军','法军主要部队投降后地方反抗据点继续抵抗，9月再被政府军夺回','Killala, County Mayo',['C5-IRL-NAI-1798'],'month','PLACE-KILLALA','国档文书显示Ballinamuck后镇压未完全结束；不可将9月8日设整个岛屿战争结束日')
ev('C5-F07-001','E18-F07','1800-03-28','爱尔兰两院同意与大不列颠议会联合条款','爱尔兰议会上下两院','两院同意联合法条款','都柏林议会',['C5-UK-PARL-IRISH-1799'],'day','PLACE-DUBLIN','19世纪承接事项，必须留在1800阶段，不作为1799年已联合法')
ev('C5-F07-002','E18-F07','1801-01-01','大不列颠与爱尔兰议会联合正式生效','大不列颠及爱尔兰政治机构','创建联合王国议会政治秩序','伦敦与都柏林',['C5-UK-PARL-IRISH-1799'],'day','PLACE-DUBLIN','1801年事项仅用于下一世纪交接，绝不放入1799地图年末')
ev('C5-D01-001','E18-D01','1770-08-22','库克航海日志记载的宣示与Kaurareg土地政治解释发生分歧','James Cook、Kaurareg原住民族传统所有者','英国航海日志记载声索整段东岸，而Kaurareg口述与其他船员记录对仪式真实性提出质疑','Bedanug/Tuidin（Possession Island）',['C5-AU-NLA-COOK','C5-AU-MUSEUM-CONTEST','C5-AU-NMA-KAURAREG'],'day','PLACE-POSSESSION','同一天对事件解释并存；保留两方证词，绝不绘制整个东海岸英国实控面','conflicting_historical_testimony')
ev('C5-D02-001','E18-D02','1788-01-26','第一舰队转移到悉尼湾建立殖民驻点','英格兰殖民总督Arthur Phillip及第一舰队','军人、被流放犯与官员由Botany Bay转入Port Jackson Sydney Cove','Warrane / Sydney Cove',['C5-AU-SLNSW-FIRSTFLEET'],'day','PLACE-SYDNEY','11艘船及被流放犯750–780为估计口径；登陆不是全新南威尔士实控')
ev('C5-D10-001','E18-D10','1789','James Ruse在Rose Hill有早期小麦收成','流放者James Ruse、殖民总督及殖民配给体系','前流放者用殖民分派地开展耕作，1789年收成可保存下一年种子','Rose Hill / Parramatta',['C5-AU-SLNSW-FIRSTFARMS'],'year','PLACE-PARRAMATTA','不应以1789年耕作证明1791/92土地授予文件具体签发日期')
ev('C5-D10-002','E18-D10','1791-12','Rose Hill殖民政府农场已有超过200英亩在耕','新南威尔士殖民政府和被强制劳动者','至1791年末政府农场报告超过200英亩耕作，代表局部耕作改变','Rose Hill / Parramatta',['C5-AU-SLNSW-FIRSTFARMS'],'month','PLACE-PARRAMATTA','英亩只是来源报告的耕地面积，不是准确历史耕地边界；不要绘制Polygon')
ev('C5-D10-003','E18-D10','1795-01','Hawkesbury殖民当局派兵镇压原住民抵抗','Acting Governor William Paterson、殖民驻军、Darug与邻近原住民族群','受地方冲突刺激，Paterson下令军队前往Hawkesbury，对原住民采取致命暴力','Hawkesbury River / Dyarubbin',['C5-AU-HAWKESBURY-COUNCIL'],'month','PLACE-HAWKESBURY','地方遗产研究引当时David Collins记录；行动人数、遭害者身份及精确地点需对照Collins原件')

# NEW CLAIM-LEVEL AUDIT & SOURCE CONTRADICTIONS
claim('C5-1708-1709-OLDSTYLE','1708-12-21 O.S. / 1709-01-01 N.S.','Saint-Ovide夺取圣约翰斯威廉堡，旧历1708年12月21日即新历1709年1月1日',['C5-CAN-DCB-LLOYD','C5-NFL-HERITAGE-WAR'],'scholarly_biographical_date_crosswalk','需要记录所用历法；切片按规范统一现代公历1709年，不可将其画为两次不同战斗','1708年末英方驻军；1709年末Fort William不应显示连续英国驻军；仍需追查1709 rebuilt未驻军细节')
claim('C5-CHURCHILL-GAP','1689-1716','1689 HBC丘吉尔商站焚毁，1717才重建较稳定驻点',['C5-HBC-PARKS-CHURCHILL','C5-HBC-PARKS-CAPEMERRY'],'Parks_Canada_site_history','对1689毁坏至1717复建中间年份未查私人短期抵达，不可夸张成绝对没有任何英商活动','1700—1709不许有持续HBC驻防/实控核心标记')
claim('C5-COOK-DATE-CONFLICT','1770-08-22 vs timeline 1770-09-13','库克本人日志22日明确宣示；NMA某一般时间表误列13 September',['C5-AU-NLA-COOK','C5-AU-NMA-TIMELINE-ERR'],'direct_journal_transcript_and_institutional_timeline','源内不一致尚未得官方更正，不能据推测给出另一次宣示','以22 August为候审原事件发生日，来源冲突公开保留')
claim('C5-COOK-KAURAREG-CONTEST','1770','英国占有仪式的物理发生及原住民同意均受澳大利亚博物馆与Kaurareg历史陈述质疑',['C5-AU-MUSEUM-CONTEST','C5-AU-NMA-KAURAREG','C5-AU-NLA-COOK'],'First_Nations_curatorial_oral_history_plus_diary','避免将记录争议简单定性一方捏造；目前未逐页核船上其他日志','地图上显示英国主张文书与Kaurareg的独立地方政治，拒绝整片英国实控地理填充')
claim('C5-IRL-FRONT-SPLIT-1798','1798-05-23..1798-09','1798起义发生在多地不同阶段，Wexford部分地区到6月21日前曾有起义军治理／军事实际控制，Mayo在9月仍在反抗',['C5-IRL-NAI-1798','C5-IRL-NAM-1798'],'national_archives_facsimile_explanation_and_museum','各地精确边界和有效控制年末需原军事巡行/地方记录复核','按事件局部点及时间段处理，不把整个爱尔兰重新涂成反叛/英国统一控制色')
claim('C5-IRL-VINEGAR-1798-MAPS','1798-06-21','NLI馆藏MS L368/MS L391现存战时军事地形图，包含行军路线、战斗部署及地名',['C5-IRL-NLI-TAYLOR-MAP','C5-IRL-NLI-HARDY-MAP'],'archival_map_catalogue_not_actual_cartographic_rectification','尚未查看地图高分辨率原图和辨识旧地图比例、旋转、扭曲；需按版权规则使用','可用于进一步生成审查级虚线战场影响区，当前零实控Polygon且路线不得擅自描边')
claim('C5-IRL-1707-1720-1782','1707/1720/1782','苏格兰1707入大不列颠，爱尔兰王国仍为独立议会；1720英国对其司法立法权限制，1782部分解除',['C5-UK-PARL-UNION-HOUSE','C5-UK-PARL-IRISH-1720','C5-UK-PARL-IRISH-1782'],'official_legislative_institutional_history','爱尔兰独立立法权与英方任命行政权并存，不以二元主权分类替代','仅政治制度字段分段，不因1707或1782直接重画已核行政辖界')
claim('C5-NSW-COERCION-1795','1794-1795','Hawkesbury 1794–95定居扩张、原住民生计压力、殖民军暴力与报复循环分别发生',['C5-AU-HAWKESBURY-COUNCIL'],'2021_local_heritage_study_indigenous_consultation','引述英国殖民记录的伤亡数应逐条标为报告而非独立统计；无可复核死者/驻军GPS','Hawkesbury区域仅具名地理参考，武装冲突点位不应由现代LGA边界推出')
claim('C5-SCOT-1748-TWO-ACTS','1746 Acts effective 1748-03-25','Tenures Abolition Act与Heritable Jurisdictions Scotland Act为两个法制对象，均含1748-03-25起效','C5-UK-LEGIS-TENURES'.split() if False else ['C5-UK-LEGIS-TENURES','C3-SCO-LEG-1746'], 'official_statute_text_and_existing_round3_source', '来源主体为两部原法，地权制度变革不能凭此画地产没收实际边界','1748年3月25日在行政叙事中要区别司法和土地保有制改革')

conflict('C5-FORTWILLIAM-CALENDAR','C4-C26-002','1708或1709圣约翰斯威廉堡失守的相互矛盾年份',[{'source_ids':['C5-CAN-DCB-LLOYD'],'date':'1708-12-21 old style = 1709-01-01 new style','type':'explicit_dual_calendar_date'},{'source_ids':['C5-NFL-PARKS-FORTWILLIAM','C5-NFL-HERITAGE-WAR'],'date':'January 1709','type':'modern_style'},{'source_ids':['C5-NFL-HERITAGE-WAR'],'date':'1708 naval blockade','type':'separate_event_must_not_confuse'}],'保持一场战斗，公历1 Jan 1709；保留旧历日期字段；1708海上封锁是独立行为')
conflict('C5-FORTWILLIAM-PLACENTIA-TEXT','C4-C26-003','Parks Canada某句称1709至1743英国纽芬兰唯一驻军在Placentia，但1713年前Placentia为法国据点',[{'source_ids':['C5-NFL-PARKS-FORTWILLIAM'],'date':'1709-1743','type':'museum_sentence_overbroad'},{'source_ids':['C5-NFL-HERITAGE-WAR'],'date':'1713','type':'confirmed_transfer_to_British'}],'官方站点该句显然把1713后背景泛化；1709—1712 Placentia不得判英国驻防；1709圣约翰斯英国堡垒短期修复亦非回归驻军')
conflict('C5-COOK-SEPTEMBER-1770','C-D01-001','1770年库克宣示在国家博物馆不同网页中写22 Aug和13 Sep',[{'source_ids':['C5-AU-NLA-COOK','C5-AU-NMA-COOK-AUG'],'date':'1770-08-22','type':'contemporary_journal_date'},{'source_ids':['C5-AU-NMA-TIMELINE-ERR'],'date':'1770-09-13','type':'museum_compact_timeline_conflict'}],'优先采航海日志的22 Aug，另将9/13标为未解决错误而非第二次宣示')
conflict('C5-KAURAREG-POSSESSION-ACCOUNT','C2-D01-001','库克22 Aug声索所叙述的仪式是否如公开传统形象发生',[{'source_ids':['C5-AU-NLA-COOK'],'date':'1770-08-22','type':'Cook_own_diary_announcement'},{'source_ids':['C5-AU-MUSEUM-CONTEST','C5-AU-NMA-KAURAREG'],'date':'1770 First Nations testimony and other ship diaries','type':'curated_counter_evidence'}],'将殖民声称作为可确证文本事件，而将仪式物理细节列入争议；任何英国实际占领面积恒为null')
conflict('C5-KILLALA-AUGUST-1798','C2-F06-002','1798年法军Humbert登陆Killala具体是8月22日还是23日',[{'source_ids':['C5-IRL-NAI-1798'],'date':'1798-08-23','type':'national_archives_historical_explainer'},{'source_ids':['C5-IRL-IRISH-MIL-HUMBERT'],'date':'1798-08-22','type':'military_historical_study'}],'事件年份月份已明确，严格不擅定日；高分辨率原航海日志或陆上军报复核后再做日级地图')
conflict('C5-DARIEN-DOCS-VERSUS-CAPITULATION','C2-F09-004','达连投降前18/21 March议会文书与4月12日投降不可混为同一日期',[{'source_ids':['C5-SCOT-NLS-DARIENPAPERS'],'date':'1700-03-18/21','type':'printed_original_council_documents'},{'source_ids':['C2-DAR-2025'],'date':'1700-04-12','type':'peer_reviewed_history_claim'}],'分别记录谈判会议/委任/实际降约；不会由18 March反推据点当天即被西班牙控制')

# Add map research placeholders without fabricated coordinates
geo('PLACE-CHURCHILL-RIVER','Churchill River initial HBC 1689/1717 post sites',['C5-HBC-PARKS-CHURCHILL'],['C5-C27-001','C5-C27-002'],'separate_1689_and_1717_wooden_sites_not_modern_stone_fort')
geo('PLACE-NEWROSS','New Ross, County Wexford, Ireland',['C5-IRL-NAM-BLOMELEY'],['C5-F06-004'])
geo('PLACE-ARKLOW','Arklow, County Wicklow, Ireland',['C5-IRL-NAM-1798'],['C5-F06-005'])
geo('PLACE-FOULKESMILLS','Foulkesmills, County Wexford, Ireland',['C5-IRL-NAM-FOULKES'],['C5-F06-006'])

# Historic primary maps are source holdings, not coordinates or re-use of copyrighted image itself.
save('HISTORICAL_MAP_SOURCE_CATALOG.json',{'schema':'assistant-C-historical-map-evidence-catalogue-v1','editorial_state':'research_only','items':[
 {'id':'C5-IRL-VINEGAR-TAYLOR-1798','source_ids':['C5-IRL-NLI-TAYLOR-MAP'],'holding':'National Library of Ireland, MS L 368','date_on_item':'[1798?]','geographic_scope':'Enniscorthy and Vinegar Hill','published_cartographic_material':'printed hand-coloured one map 37 x 29 cm, scale 40 perches to inch','attested_information':'Government/rebel approaches, Lake attack point','map_reuse_license':'NLI reproduction rights owned by NLI; link to catalog only','geometry':'none','primary_map_imaging_and_georectification_required':True,'historical_claims':'partisan military cartography; not neutral exact political sovereignty perimeter'},
 {'id':'C5-IRL-VINEGAR-HARDY-1798','source_ids':['C5-IRL-NLI-HARDY-MAP'],'holding':'National Library of Ireland, MS L 391','date_on_item':'[1798]','geographic_scope':'Vinegar Hill, County Wexford','published_cartographic_material':'hand-coloured plan and perspective after J Hardy, with numbered index','attested_information':'Government/rebel positions 21 June','map_reuse_license':'NLI catalogue, must obtain reuse rights before display','geometry':'none','primary_map_imaging_and_georectification_required':True,'historical_claims':'battle-specific troop disposition, not county-wide sovereignty'},
 {'id':'C5-SCOT-DARIEN-1849-PLAN','source_ids':['C5-SCOT-NLS-DARIENPAPERS'],'holding':'National Library of Scotland digitised 1849 Darien Papers frontispiece plan','date_on_item':'published 1849, historical object claimed late 1690s','geographic_scope':'Golden Island / Fort St Andrew regional harbour','published_cartographic_material':'plan in printed archive collection','attested_information':'Fort and harbour relative positions; no reliable historical geospatial reference yet','map_reuse_license':'Check NLS image-specific rights','geometry':'none','primary_map_imaging_and_georectification_required':True,'historical_claims':'guide named localities, never draw exact colonial polygon from printed page alone'}]})

# Add one strongly sourced separate site control: 1689 Churchill burned, 1717 repopulated.
siteid='C5-SITE-CHURCHILL-1689-1717'
if not any(s['id']==siteid for s in SITE['sites']):
 SITE['sites'].append({'id':siteid,'name':'Churchill River / early HBC wooden post (not 1731 Prince of Wales stone fort)','control_relation':'HBC 1689 wooden post burned that year; no attested continuously occupied permanent company fort until 1717','source_ids':['C5-HBC-PARKS-CHURCHILL','C5-HBC-PARKS-CAPEMERRY'],'map_conflict':'Do not carry 1689 commercial presence as 1700 British fort control; First Nations sovereignty remains distinct','historical_control_polygon_confirmed':False,'fill_authorized':False,'geographic_point':None,'records':[{'year':y,'physical_site_control':'1689 old post burned; no verified permanent HBC fort occupancy by 1700–1709','evidence_state':'official_heritage_site_history_interval_1689_destroyed_to_1717_rebuild','HBC_licensed_claim_does_not_establish_fort':True,'indigenous_political_autonomy_preserved':True,'source_ids':['C5-HBC-PARKS-CHURCHILL'],'historical_polygon_verified':False} for y in range(1700,1710)],'later_reestablishment_year':1717,'last_documented_post_year_before_gap':1689})

# Broader multi-site decisions, focused on point garrisons vs paper charters, not fake historic borders
regimes=[
 ('YORK-FORT','Fort Bourbon / old York Fort on Hayes River','French post; HBC paper claim persists','French','C5-HBC-PARKS-YORK',1697,1713,'HBC site physical occupation, not watershed sovereignty'),
 ('FORT-ALBANY','Fort Albany / Chechewan on James Bay','English HBC foothold; 1709 French attack repulsed','English HBC','C4-CAN-DCB-KNIGHT',1696,None,'Specific fortified core, not James Bay basin'),
 ('ST-JOHNS-FORT-WILLIAM','Fort William, St John’s','English fort/garrison 1700-1708; French assault and destruction on 1 Jan 1709 (N.S.)','English until 1708, breached 1709','C5-CAN-DCB-LLOYD',1697,1709,'1709 rebuilding of structure must not be painted as re-garrisoning'),
 ('PLAISANCE','Plaisance / Placentia Newfoundland','French administrative and military settlement throughout 1700-1709','French','C5-NFL-HERITAGE-WAR',1697,1713,'British only after 1713 treaty+handover, not 1709'),
 ('CHURCHILL-RIVER','Churchill River original wooden post','1689 destroyed and rebuilt 1717, not extant occupied HBC fort 1700-1709','not_verified_HBC_permanent_post','C5-HBC-PARKS-CHURCHILL',1689,1717,'Absence of fort != lack of Indigenous settlement, seasonal trade, travel'),
 ('DARIEN','Scottish New Edinburgh / Fort St Andrew in Guna territory','1699 reoccupation ends with 1700 surrender/withdrawal','Scottish company until early 1700 departure','C5-SCOT-HES-DARIEN2026',1699,1700,'Scottish not British, after surrender no Scottish occupation; Guna sovereignty independent'),
 ('NEWJERSEY','East/West Jersey political province','1702 proprietary governing rights were transferred to royal government, deeds and indigenous lands separate','English royal colony governance by 1702','C2-NJ-1702',1702,None,'No claim that all charter outline land fully settled'),
 ('DELAWARE-THREE-COUNTIES','Delaware lower three counties','1704 separate representative assembly under shared governor of Pennsylvania','proprietary governance with separate assembly','C2-DE-1704',1704,None,'Do not classify as independent country or automatic British border expansion')
]
annual=[]
for key,name,summary,actor,ref,started,finished,notes in regimes:
 years=[]
 for y in range(1699,1711):
  if key=='YORK-FORT': value='French garrison at Fort Bourbon (interval)' if y<=1709 else 'French post pending 1713'
  elif key=='FORT-ALBANY': value='English HBC fort, continuous interpretation from 1696 recovery + 1709 defence' if y<=1709 else 'continued pending annual journal'
  elif key=='ST-JOHNS-FORT-WILLIAM':value='English fort; no evidence of French occupation at year-end' if y<=1708 else 'fort captured Jan 1709; rebuilt later without restored garrison (year-end)' 
  elif key=='PLAISANCE':value='French fortified settlement (continues until 1713)'
  elif key=='CHURCHILL-RIVER':value='No continuously occupied HBC fort evidenced; 1689 wooden post burnt, 1717 rebuilding'
  elif key=='DARIEN':value='Scottish company seasonal colony at year-end 1699 only' if y==1699 else 'Scottish colony ended and withdrew during 1700' if y>=1700 else 'unverified'
  elif key=='NEWJERSEY':value='proprietary political governments' if y<=1701 else 'royal provincial government (actual town core boundaries not researched)'
  elif key=='DELAWARE-THREE-COUNTIES':value='lower counties sharing assembly with Pennsylvania before 1704' if y<=1703 else 'distinct lower counties assembly but still shared proprietary/governor ties'
  years.append({'year':y,'year_end_site_or_institution_status':value,'evidence_level':'supported_period_by_institutional_history_not_independent_each_year_archival_folio','historic_boundary_verified':False,'source_ids':[ref]})
 annual.append({'id':'C5-REGIME-'+key,'site_or_relation':name,'actor_summary':actor,'temporal_summary':summary,'last_key_reference':ref,'start_signal_year':started,'next_change_year':finished,'annual_1699_1710':years,'critical_spatial_note':notes})
save('ROUND5_SITE_YEAR_DECISION_MATRIX_1699_1710.json',{'schema':'assistant-C-round5-site-year-1699-1710-v1','editorial_state':'research_only','year_scope':[1699,1710],'purpose':'Decision-support for site/political institution annual inheritance. Heritage historical intervals are NOT twelve independent annual garrison roll proofs.','relations':annual,'count':len(annual),'requirement':'No direct conversion to historical colonial_polygons; local verified core references may be drawn after editor approval.'})

# enrich parent annual review with a round5 note but do not promote tentative 27 shapes
T['investigation_round5']={'date':TODAY,'new_site_matrix':'ROUND5_SITE_YEAR_DECISION_MATRIX_1699_1710.json','distinct_sites_and_political_institutions':len(annual),'decision':'All twenty-seven prior schematic territorial footprints remain non-publishable; site-level institutional records supersede paper charter for selected years.','key_fixes':['Fort William 21 Dec 1708 OS = 1 Jan 1709 NS','Churchill 1689 burned, re-established 1717','Darien Scottish withdrawal April 1700','Plaisance French garrison until treaty 1713','New Jersey 1702 institutional government shift, not territorial conquest']}

# put source-registry updates in one initial durable disk checkpoint
S['source_count']=len(S['sources']);E['event_count']=len(E['events']);C['evidence_count']=len(C['claims'])
for n,obj in [('SOURCE_REGISTRY.json',S),('EVENT_CANDIDATES.json',E),('CLAIM_EVIDENCE_MATRIX.json',C),('ROUND3_EVIDENCE_CONFLICTS.json',D),('MAP_CANDIDATES.geojson',G),('SITE_SPECIFIC_CONTROL_1697_1715.json',SITE),('CONTROL_TRANSITIONS_1699_1709.json',T)]:save(n,obj)
# standard CSV of original types
with (P/'EVENT_CANDIDATES.csv').open('w',newline='',encoding='utf-8-sig') as f:
 fields=['id','topic_id','date','date_precision','title','actor','action','historical_place','source_ids','research_state','cartographic_status','geometry_ref','historical_control_polygon_approved','evidence_notes'];w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader()
 for e in E['events']:
  o={k:e.get(k) for k in fields};o['source_ids']=';'.join(e.get('source_ids',[]));w.writerow(o)
with (P/'CLAIM_EVIDENCE_MATRIX.csv').open('w',newline='',encoding='utf-8-sig') as f:
 fields=['id','date_or_range','claim_summary','source_ids','access_type','audit_limit','map_eligibility','original_folio_personally_inspected'];w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader()
 for c in C['claims']:
  o={k:c.get(k) for k in fields};o['source_ids']=';'.join(c.get('source_ids',[]));w.writerow(o)

# Structured cross-century collaboration tasks: no duplicated NA/India/Africa regional research
handoffs=[
 {'recipient':'助手1','topic':'E18-A05/A11/A12','issue':'马龙自治及1796后Nova Scotia、1800 Sierra Leone后续阶段，不将村寨全区涂英国统治','specific_test':'1739条约后的逐共同体政治关系、1795-1796流放具体起止；到达人数不同事件不同分母'},
 {'recipient':'助手1','topic':'E18-C26','issue':'1708-12-21 OS=1709-01-01 NS St Johns英法攻守、1713 Placentia转移','specific_test':'17C母篇接18C独立事件，1705胜守1709失堡，Site-year非整个纽芬兰面积'},
 {'recipient':'助手1','topic':'E18-C27','issue':'York Bourbon French 1697-1713、Albany English HBC、Churchill early 1689 burnt/1717 rebuild','specific_test':'在城堡地点做差异而非整个Rupert land填充；1709 Albany守住，不能画成法军占地'},
 {'recipient':'助手2','topic':'E18-E15','issue':'1719 Bencoolen撤离1723再建，地权与商贸、驻防分离','specific_test':'需带时间与具名地点说明中断；1700—1718不能用公司特许覆盖整个苏门答腊'},
 {'recipient':'助手2','topic':'E18-Bxx','issue':'EIC在孟买、马德拉斯与孟加拉村三种法权类型相异','specific_test':'1698 zamindari不等于宗主权，1719当地抗争与1757/1765分阶段'},
 {'recipient':'主编','topic':'E18-D01','issue':'Cook journal 22 August vs NMA简略时间表13 September；登陆仪式亦有Kaurareg挑战','specific_test':'具体发表日期22 August，右侧标注争议；绝不整个东岸英属Polygon'},
 {'recipient':'主编','topic':'E18-F06','issue':'National Library Ireland MS L368 /391 1798 military plans, historical georectification','specific_test':'确认底图地图绘画和版权许可；路线仅有证据时为虚线军队行动，不能创建县界英国占领面'},
 {'recipient':'主编','topic':'E18-F03/F07','issue':'1707英苏分国至5/1；1799爱尔兰联合动议失败、1800成功与1801生效','specific_test':'政治主体状态逐期正确，1800/01事件不冒充1799制度已完成'}]
save('ROUND5_HANDOFF_OTHER_ASSISTANTS.json',{'schema':'assistant-C-round5-coordination-v1','review_status':'research_only','tasks':handoffs})

# Summary checkpoint so work survives unexpected runtime interruption
round_summary={'start_counts':{'sources':old_s,'events':old_e,'places':old_g,'claim_rows':old_c,'date_conflicts':old_d},'ending_counts':{'sources':len(S['sources']),'events':len(E['events']),'places':len(G['features']),'claim_rows':len(C['claims']),'date_conflicts':len(D['conflicts'])},'new_events':[x['id'] for x in E['events'] if x['id'].startswith('C5-')],'new_sources':[x['id'] for x in S['sources'] if x['id'].startswith('C5-')],'new_geographies':[x['id'] for x in G['features'] if x['id'] in ['PLACE-CHURCHILL-RIVER','PLACE-NEWROSS','PLACE-ARKLOW','PLACE-FOULKESMILLS']]}
save('ROUND5_INDEX.json',round_summary)
print(json.dumps(round_summary['ending_counts'],ensure_ascii=False))
