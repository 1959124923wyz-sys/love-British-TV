from pathlib import Path
import json
from pyproj import Transformer
p=Path('/mnt/data/18c_assistant_C')
def load(f):return json.loads((p/f).read_text('utf8'))
def out(f,j):(p/f).write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n','utf8')
s=load('SOURCE_REGISTRY.json')
for x in s['sources']:
 if x['id']=='C7-S20':
  x['title']='Official live BTL10 designation: Glenshiel NG 99566 13704, easting 199566 northing 813704'
  x['research_note']='Live HES HTML designation has authoritative easting/northing. Older PDF printed NH 996 137 is a likely grid-letter typo; separate conflict logged.'
if not any(x['id']=='C7-S33' for x in s['sources']):
 s['sources'].append({'id':'C7-S33','institution':'Historic Environment Scotland','title':'Legacy Glenshiel battlefield inventory PDF with NH 996 137 typo','url':'https://portal.historicenvironment.scot/document/600000877','access_level':'historical_government_pdf_metadata_conflicts_with_live_designation','original_manuscript_personally_inspected':False,'reviewed_online_on':'2026-11-08','research_note':'Legacy PDF cites NH 996 137, but map eastings 196000–202000 and live BTL10 easting 199566 prove the correct square NG. Historical grid used only for review.'})
s['source_count']=len(s['sources']);out('SOURCE_REGISTRY.json',s)
G=load('MAP_CANDIDATES.geojson')
for f in G['features']:
 if f['id']=='PLACE-GLENSHIEL':
  lon,lat=Transformer.from_crs(27700,4326,always_xy=True).transform(199566,813704)
  f['geometry']['coordinates']=[round(lon,9),round(lat,9)]
  f['properties']['coordinate_method']='HES BTL10 live designation easting=199566 northing=813704 NGR=NG 99566 13704; EPSG27700 converted WGS84 with pyproj. Legacy HES PDF NH 996 137 is inconsistent; see conflict C7-GRID-NH-NG.'
  f['properties']['coordinate_status']='modern_government_battlefield_inventory_representative_point_not_historic_battle_line'
  f['properties']['source_ids']=['C7-S20','C7-S33']
  print('Correct Glenshiel point',f['geometry']['coordinates'])
out('MAP_CANDIDATES.geojson',G)
cl=load('CLAIM_EVIDENCE_MATRIX.json')
for x in cl['claims']:
 if x['id']=='R7-GLENSHIEL-1719':
  x['claim_summary']='Official HES BTL10 live inventory gives NG 99566 13704 / easting199566 northing813704; older PDF NH996137 is conflicting typo.'
  x['audit_limit']='Live designation supersedes legacy PDF; reference centroid is not the historic armies positions; no redistribution of PDF OS map image.'
  x['source_ids']=['C7-S20','C7-S33']
out('CLAIM_EVIDENCE_MATRIX.json',cl)
c=load('ROUND7_EVIDENCE_CONFLICTS.json');c['conflicts'].append({'id':'C7-GRID-NH-NG','issue':'Official HES sources conflict over Glenshiel grid-square letter','a':'2015 legacy PDF says NH 996 137, 100 km east of historical valley','b':'Live HES BTL10 says NG 99566 13704, easting199566 northing813704','source_ids':['C7-S20','C7-S33'],'resolution':'Use live numeric EN 199566,813704, stored converted lon/lat; never map legacy NH location; official battlefield area remains non-sovereignty historical landscape.'});c['open_count']=len(c['conflicts']);out('ROUND7_EVIDENCE_CONFLICTS.json',c)
for fp in ['ROUND7_MAJOR_IMPACT_RESEARCH.md','ROUND7_MAJOR_IMPACT_DOSSIERS/F_SCOT_JACOBITE_TRANSPORT.md','PROGRESS.md']:
 t=(p/fp).read_text('utf8').replace('NGR NH996137','NGR NG99566 13704').replace('NGR NH 996 137','NGR NG 99566 13704')
 (p/fp).write_text(t,'utf8')
with (p/'ROUND7_MAJOR_IMPACT_RESEARCH.md').open('a',encoding='utf8') as f:
 f.write('\n### 关键GIS来源纠错（同日）\n\nHES旧版PDF误印`NH 996 137`，其现行BTL10网页给出`NG 99566 13704`、E=199566 N=813704。**经坐标转换得到[lon=-5.316893383, lat=57.170256090]**。地图Point已按现行数值修订，旧坐标严禁使用。源C7-S20/C7-S33，冲突账本C7-GRID-NH-NG。\n')
