import json,csv,pathlib,datetime
P=pathlib.Path('/mnt/data/18c_assistant_C'); R=P/'ROUND8_SYSTEMIC_IMPACT'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def save(p,j):p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
cl=read(P/'CLAIM_EVIDENCE_MATRIX.json')['claims']
columns=[]
for r in cl:
 for k in r:
  if k not in columns: columns.append(k)
with (P/'CLAIM_EVIDENCE_MATRIX.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=columns);w.writeheader()
 for r in cl:w.writerow({k:json.dumps(v,ensure_ascii=False) if isinstance(v,(list,dict)) else v for k,v in r.items()})
(R/'SCOTLAND_ABOLITION_JUDICIARY_INSTITUTIONAL_CONTRAST.md').write_text('''# 1792年议会渐进废奴与1778年Knight判决：正反证据

## 1792年动议：知情后的议会选择
Henry Dundas推动将即刻终止跨大西洋贩奴贸易的动议改为渐进终止。英国下院1792年4月形成渐进议决，但此议决未成为禁止奴隶贸易法，英国到1807年才立法。这证明议会在公开审议下，仍使殖民贩奴贸易合法延续；至于个别议员是否直接从个人贿赂获利，需要独立财务证据。C8-S19、C8-S20（后者为1806年对1792年的追述）。

## 1778年法院：具证反例
1778年1月15日苏格兰Court of Session判决John Wedderburn不能依据牙买加奴役法让Joseph Knight在苏格兰永久服务或违愿带离。苏格兰本土的司法约束与海外殖民奴役制度必须分开。NRS原档馆藏CS235/K/2/2；苏格兰两个官方机构有关投票票数分别写8比4与10比4，故研究正式稿不采用未核的票数。C8-S21、C8-S22。

**空间**：议会和法院是当时有证据的机构，但此法权范围不是历史实控测绘Polygon，研究级仅作政策记录，不计算面积。
''',encoding='utf-8')
(R/'CLAIMS_OF_SYSTEMICITY.md').write_text('''# 国家授权、制度化收益与默许：证据判定框架（Round 8）

## 结论及适用范围
研究涵盖18世纪爱尔兰王国（不是1801后联合王国的行政区）、1707年前苏格兰王国及其后大不列颠、1788年以后的新南威尔士殖民地。几个案例有法律、财政、军令、议会决议或司法裁判可直接证明**体系性**；另一些只能证明个别行为、地方当局监管失败或私有资本参与，证据等级严格区分。

### 一级：法律明文授权/议会清楚选择
- 1698年英格兰议会制定爱尔兰毛纺出口限制，1699年6月开始执行，保护英格兰业者市场；商业损失幅度仍待账目。`C8-P01`。
- 1703—04年爱尔兰议会宗教地产限制：继承、购地、学校和其他权益各按原条款逐项确认；1720年英国议会宣称针对爱尔兰立法审查权。`C8-P02`、相关F01/F02。
- 1707年英苏联合第4条为苏格兰居民开放殖民市场，第15条安排名义财政补偿含达连投资者；这是一套法律化帝国经济准入与赔偿机制，不能推断所有苏格兰人都支持海外奴役。`C8-P03/P04`。
- 1792年英国下院选择渐进废止跨大西洋贩奴贸易的议决，却没有形成停止贸易的立法；1806年下院有明确追述，1810年之后不得误投到1790年代。`C8-P28`。

### 二级：行政明令或按制度实施的暴力
- 1795年Hawkesbury殖民总督署派兵62人保护新农场，并有原住民被杀和被捕的官方报告；居民自行扩张与政府派兵合力改变土地使用和当地安全，限于当地地点。`C8-P19`。
- 爱尔兰1798年驻军、搜捕和处决必须按具体军令与地方事件区分；可见政府命令限制无授权烧屋，故不能把所有破坏均说成英军奉令。`C8-P22/P23`。
- 1746—1747年苏格兰高地缴械、服饰限制分生效日；1747—1752年没收地产/国库管理须按实际处置及有权司法单位审核。`C8-P07/P08` 等。

### 三级：有据知情/监管失败或不处罚（不是无限概括）
- 1799年Hawkesbury两名原住民男孩被杀，涉案殖民者经法院认定有罪后释放、后获赦：追究中断是可证司法结局，不能由此倒推事先官员下令杀害。后续1802赦免是19世纪节点。`C8-P24`。
- 尽管1796年殖民总督令禁止随意杀害原住民，1797年亦有武力指示，因此必须同时记录保护宣示、例外条件、事实执行、实际处罚。`C8-P20/P21`。

### 四级：私人经营与制度基础设施
- 格拉斯哥和格里诺克烟草商、苏格兰商人及法律争议与被奴役劳动有关，需依次证实合伙、具体船次、奴役劳动产出与最终收益，不能用1769年进口份额套算利润或死亡。`C8-P26`。
- 1778年Knight案确认苏格兰法庭可以限制奴役者的人身控制，是法律体系内部的重要反证。`C8-P29`。

### 未经证实而不主张
- 1740—1741年爱尔兰饥荒源于气候危机与社会脆弱性，尚无证据可把死亡直接称作英国有计划制造。人口死亡估算需区分分母、地区与推算模型。
- 1789年悉尼天花流行的引入路径及是否人为传播仍有争议；不能声称总督有蓄意毒害命令。
- 1770年库克宣示不能作为英方已实际占领澳大利亚东岸内陆的证据。

**来源与索引**：`POLICY_MECHANISM_MATRIX.json`（29项）、`STATE_RESPONSIBILITY_ADJUDICATION.json`（18项）、`QUANTIFIED_IMPACTS.json`（22项）、`SOURCE_REGISTRY.json`；事件日期和原地图候选另有独立记录。全部`research_only`。
''',encoding='utf-8')
(R/'ROUND8_INDEX.json').write_text(json.dumps({'schema':'love-british-tv-assistant-c-round8-index-v1','status':'research_only','topic':'1700–1799 Ireland Scotland Australia systemic economic demographic policy evidence','read_order':['ROUND8_SYSTEMIC_IMPACT/CLAIMS_OF_SYSTEMICITY.md','ROUND8_SYSTEMIC_IMPACT/POLICY_MECHANISM_MATRIX.json','ROUND8_SYSTEMIC_IMPACT/STATE_RESPONSIBILITY_ADJUDICATION.json','ROUND8_SYSTEMIC_IMPACT/QUANTIFIED_IMPACTS.json','ROUND8_SYSTEMIC_IMPACT/SCOTLAND_ABOLITION_JUDICIARY_INSTITUTIONAL_CONTRAST.md','SOURCE_REGISTRY.json','EVENT_CANDIDATES.json','CROSS_CENTURY_AUDIT.json','CONTROL_TRANSITIONS_1699_1709.json','ROUND8_QA_REPORT.json'],'geospatial_notice':'no new boundary polygons or invented areas','note':'review and verify original folios and local land surveys before formal map production'},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
P.joinpath('README.md').open('a',encoding='utf-8').write('\n### Round 8 制度化政策—人口—经济影响研究（补完）\n- `ROUND8_SYSTEMIC_IMPACT/ROUND8_INDEX.json` 为总入口；包含29项政策机制、22项有口径的经济人口数值、18项国家责任归属裁定与11篇专题补证，新增1778 Knight司法反例、1792渐进废奴议会选择。\n- 文字要区分立法授权、行政执行、司法不追究、私人暴力、法律限制和仍存争议的因果；所有资料`research_only`。\n')
P.joinpath('PROGRESS.md').open('a',encoding='utf-8').write('\n- Round 8补证：1792渐进废奴议决（议会知情并延缓禁止）与1778 Knight判决（苏格兰本土司法限制奴役者），数值不伪造，结果为29项政策、18项归责、114条证据与234来源；10新增事件，226累计，暂未新增经核实控制面。\n')
print('round8 documentation complete')
