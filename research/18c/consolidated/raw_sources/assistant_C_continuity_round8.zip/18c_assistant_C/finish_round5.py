#!/usr/bin/env python3
"""Round five editorial cleanup; outputs and QA report, never writes GitHub."""
import json,csv,pathlib,collections,re,hashlib,zipfile,datetime
P=pathlib.Path(__file__).resolve().parent
J=lambda p:json.loads((P/p).read_text(encoding='utf-8'))
def W(p,d):(P/p).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
E=J('EVENT_CANDIDATES.json');S=J('SOURCE_REGISTRY.json');A=J('CROSS_CENTURY_AUDIT.json');mat=J('ROUND5_SITE_YEAR_DECISION_MATRIX_1699_1710.json');idx=J('ROUND5_INDEX.json')
byid={e['id']:e for e in E['events']}
sourceset={s['id'] for s in S['sources']}
rows=[('C5-F02-001','C-F02-002','1720 Irish Declaratory Act same act'),('C5-F02-002','C2-F02-002','1782 repeal'),('C5-D01-001','C2-D01-001','Cook date / Kaurareg witness; not another possession'),('C5-D02-001','C-D03-001','Sydney Cove 26 Jan 1788; two thematic labels for one event'),('C5-F03-002','C-F03-001','Scottish ratification 16 Jan 1707'),('C5-F03-003','C-F03-002','English act assent 6 Mar 1707')]
reconciled=[]
for new,old,why in rows:
 assert new in byid and old in byid,(new,old)
 x,y=byid[new],byid[old]
 y['source_ids']=list(dict.fromkeys(y.get('source_ids',[])+x['source_ids']))
 y['evidence_notes']=(y.get('evidence_notes','')+' | round5: '+x.get('evidence_notes','')).strip(' |')
 if new=='C5-F03-002':y.update(date='1707-01-16',date_precision='day'); y['actor']='苏格兰王国议会'; y['action']='以110票赞成、67票反对批准联合法条款（议会仍属独立苏格兰）'
 if new=='C5-F03-003':y.update(date='1707-03-06',date_precision='day')
 if new=='C5-D01-001':y['source_conflict_review']='C5-COOK-SEPTEMBER-1770 / C5-KAURAREG-POSSESSION-ACCOUNT'
 reconciled.append({'discard_redundant_candidate':new,'retained_id':old,'cause':why,'merged_sources':x['source_ids']})
# transfer historical predecessor/successor anchors to research-only separate file
anchors=[byid[i] for i in ('C5-C27-001','C5-F07-001','C5-F07-002')]
W('ROUND5_PRE_POST_18C_ANCHORS.json',{'schema':'assistant-C-excluded-from-eighteenth-century-candidate-events','editorial_state':'research_only','why':'The history matters but date is outside 1700–1799 map-period; cross-century handoff only','anchors':anchors})
exclude={x for x,_,_ in rows}|{a['id'] for a in anchors}
E['events']=[x for x in E['events'] if x['id'] not in exclude];E['event_count']=len(E['events'])
eid={x['id']:x for x in E['events']}
assert len(eid)==len(E['events'])
# clean special calendar research precision
if 'C5-F09-003' in eid:
 r=eid['C5-F09-003'];r['date']='1700';r['date_precision']='year';r['evidence_notes']+=' | 1700年春，确切日/月未核；season in evidence_notes only.'
r=eid['C4-C26-002'];r['date']='1709-01-01';r['date_precision']='day';r['date_old_style']='1708-12-21';r['source_ids']=list(dict.fromkeys(r['source_ids']+['C5-CAN-DCB-LLOYD','C5-NFL-HERITAGE-WAR']));r['evidence_notes']+=' | 1708-12-21 O.S. = 1709-01-01 Gregorian; one capture event, NOT two.'
r=eid['C2-F06-002'];r['date']='1798-08';r['date_precision']='month';r['day_disagreement_review']=['1798-08-22','1798-08-23'];r['source_ids']=list(dict.fromkeys(r['source_ids']+['C5-IRL-NAI-1798','C5-IRL-IRISH-MIL-HUMBERT']));r['evidence_notes']+=' | Day conflict between NAI explainer and military-history source; reduced to month.'
# latest cross-century developments appended, retain existing stable ID counts
for row in A['entries']:
 if row['previous_story_id']=='E6-T10-HBC':
  row['round5_new_breakpoints']=[{'site':'Churchill River trading post','year':1689,'event':'built/burnt same year; reconstructed 1717','sources':['C5-HBC-PARKS-CHURCHILL']},{'site':'York Fort / Fort Bourbon','year':1697,'event':'French occupation into 1713','sources':['C5-HBC-PARKS-YORK']}]
 elif row['previous_story_id']=='E6-T04-DARIEN':
  row['round5_new_breakpoints']=[{'year':1700,'event':'documented 18/21 March council records versus April capitulation; distinct actions','sources':['C5-SCOT-NLS-DARIENPAPERS','C2-DAR-2025']}]
 elif row['previous_story_id']=='E6-T10-NEWFOUNDLAND':
  row['round5_new_breakpoints']=[{'year':1709,'event':'Fort William captured 1708-12-21 O.S. / 1709-01-01 new style','sources':['C5-CAN-DCB-LLOYD']}]
for rel in mat['relations']:
 for annual in rel['annual_1699_1710']:
  annual['source_ids']=['C2-US-NJ' if s=='C2-NJ-1702' else 'C2-US-DE' if s=='C2-DE-1704' else s for s in annual['source_ids']]
# inspect all source references, no bogus placeholders
unresolved=[(r['id'],y['year'],s) for r in mat['relations'] for y in r['annual_1699_1710'] for s in y['source_ids'] if s not in sourceset]
assert not unresolved,unresolved
# revise GeoJSON cross-links removed duplicate rows; all source links retained in predecessor events
G=J('MAP_CANDIDATES.geojson')
mapreplace={n:o for n,o,_ in rows}
for feature in G['features']:
 prop=feature.get('properties',{});prop['linked_event_ids']=list(dict.fromkeys(mapreplace.get(id,id) for id in prop.get('linked_event_ids',[])))
# GeoJSON may reference older story IDs or other events; need not lose named point metadata
W('MAP_CANDIDATES.geojson',G)
W('ROUND5_EVENT_DEDUP_REVIEW.json',{'schema':'round5-event-id-stability-decision','editorial_state':'research_only','merged_redundant_events':reconciled,'moved_to_non_18c_handoff':[x['id'] for x in anchors],'calendar_normalizations':[{'event_id':'C4-C26-002','calendar_date':'1709-01-01','old_style_date':'1708-12-21'},{'event_id':'C2-F06-002','date':'1798-08','alternative_days':['1798-08-22','1798-08-23']}],'note':'Do not silently assign new IDs to old published events; these are local candidate IDs only.'})
idx['ending_counts']['events']=len(E['events']);idx['new_events']=[i for i in idx['new_events'] if i not in exclude];idx['deduplication']={'merges':len(rows),'chronologically_outside_18c_moved_to_handoff':len(anchors),'original_after_initial_5th_survey':164,'remaining_candidates':len(E['events'])}
W('ROUND5_INDEX.json',idx)
W('EVENT_CANDIDATES.json',E);W('CROSS_CENTURY_AUDIT.json',A);W('ROUND5_SITE_YEAR_DECISION_MATRIX_1699_1710.json',mat)
# CSV export follows JSON canon after reconciliation
with (P/'EVENT_CANDIDATES.csv').open('w',encoding='utf-8-sig',newline='') as f:
 keys=['id','topic_id','date','date_precision','title','actor','action','historical_place','source_ids','geometry_ref','cartographic_status','evidence_notes','historical_control_polygon_approved'];wr=csv.DictWriter(f,fieldnames=keys,extrasaction='ignore');wr.writeheader()
 for r in E['events']:
  c={k:r.get(k) for k in keys};c['source_ids']=';'.join(c.get('source_ids') or []);wr.writerow(c)
# append dossier facts with source-level actual arguments
section={
'E18-D01':('1770年现场文书与仪式争议','C5-AU-NLA-COOK保存8月22日库克当日航海记述；C5-AU-NMA-TIMELINE-ERR另写9月13日，应列为未解释时间线冲突，而不是新的一次宣示。C5-AU-MUSEUM-CONTEST与C5-AU-NMA-KAURAREG记录Kaurareg对是否上岛升旗的不同证言。地图可标“英方声索宣示文书”，不作东岸英国实际占领面。'),
'E18-D02':('1787—1788运输与登陆节点','C5-AU-SLNSW-FIRSTFLEET：11艘船作为第一舰队；运输的罪犯人数须注明统计口径和不同来源估计范围。1788-01-18 Botany Bay抵达与1788-01-26 Sydney Cove定居分开；C-D03-001为保留的悉尼核心事件ID。'),
'E18-D03':('悉尼湾定居权与土地自治','C5-AU-SLNSW-FIRSTFLEET证明英方在Warrane/Sydney Cove建设临时海军陆战及流放犯定居据点；城市点可作现代参考定位，但不能扩张为1788年整个NSW东西界的实际英军治理。'),
'E18-D04':('抓捕证词继续交叉比对','C5-AU-SLNSW-BRADLEY的航海日记及原始绘图叙述可作为Bennelong等原住民强制抓捕的独立同期视角；仍须核独立日历、新旧地名和幸存证词，避免将跨文化关系统归自愿外交。'),
'E18-D07':('地方武装抵抗独立于英国殖民主权','C5-AU-HAWKESBURY-COUNCIL研究记录Dyarubbin/Hawkesbury原住民族社区因殖民耕地侵入组织水路及岸上抵抗；不能自动将河上所有袭击归于Pemulwuy。'),
'E18-D08':('1794军事事件地域核验','1794年Toongabbie伤亡、斩首的记载需回到个别军官日志；C5-AU-HAWKESBURY-COUNCIL记录的1795年惩罚军事行动是不同年份、不同地方事件，必须另立节点。'),
'E18-D09':('Parramatta与Hawkesbury不可合并','1797年Parramatta地区武装抵抗按本地社区及具体行动记载，和1795年Hawkesbury、1794年Toongabbie各是独立阶段；不由任何一个战斗推导殖民统治Polygon。'),
'E18-D10':('Rose Hill农场与生计土地变迁','据C5-AU-SLNSW-FIRSTFARMS，James Ruse较早在Rose Hill耕作，到1791年末政府农场报告200多英亩已开垦。该英亩数为耕种量估计，不是已测绘的可入库Polygon；1791/92首份地契的日期仍存在档案分歧。C5-AU-HAWKESBURY-COUNCIL记录1795年殖民军对Hawkesbury原住民的惩罚行动，必须与定居扩张同时显示。'),
'E18-F01':('1704法律与后期缓和时间层','宗教—继承—租约限制必须分条审计；18世纪后期1778等分阶段缓和不可倒推1704年同一权利。1720议会权归属与1782立法限制修订属于F02，非F01新土地征服。'),
'E18-F02':('1720法律与1782撤销的区分','C5-UK-PARL-IRISH-1720核1720年3月英国议会申明对爱尔兰立法与终审上诉权；C5-UK-PARL-IRISH-1782核1782年废除与Poynings Law调整。爱尔兰议会本身仍存，其行政官仍受英方影响，不应写为“1782爱尔兰成为完全独立国家”。'),
'E18-F03':('英苏两份立法的具体日期','C5-UK-PARL-UNION-RATIFY：苏格兰议会1707年1月16日以110比67通过；C5-UK-PARL-UNION-HOUSE：英格兰联合法获得御准1707年3月6日；1707年5月1日才是统一王国成立。旧候审ID C-F03-001/C-F03-002已更新成日级；未另起重复事件。'),
'E18-F04':('1746法案与1748真实生效','C5-UK-LEGIS-TENURES的Tenures Abolition Act与既有C3-SCO-LEG-1746的Heritable Jurisdictions Act属不同法律措施，虽均在1748年3月25日有重要生效条款。高地监控、氏族土地转变和没收实际登记必须分别复核。'),
'E18-F06':('1798年战事与原战场地图核验','C5-IRL-NAI-1798、C5-IRL-NAM-1798和C5-IRL-NAM-FOULKES可辨认5月起义、6月5日New Ross、6月9日Arklow、6月20日Foulkesmills、6月21日Vinegar Hill及9月Killala仍在反抗的不同战时阶段。C5-IRL-NLI-TAYLOR-MAP、C5-IRL-NLI-HARDY-MAP编目记两幅同期作战图，但没有高分辨率原画校正坐标，暂时不画精确战线。法军Humbert在Killala登陆具体8月22/23日资料分歧，目前退为8月记录。'),
'E18-F07':('1799否决与1800／1801的严格断点','C5-UK-PARL-IRISH-1799证实1799年爱尔兰议会初提合并被挡下；1800年法案通过和1801年1月1日生效属19世纪交接，保存ROUND5_PRE_POST_18C_ANCHORS.json，不计入1799年度活动或英国政治版图。'),
'E18-F09':('1700年达连原始打印文书线索','C5-SCOT-NLS-DARIENPAPERS是1849年印行的《达连文书》选录，见1700年3月18日会议记录、3月21日委任文书；与C2-DAR-2025所记1700年4月投降为不同阶段。仍属苏格兰公司在古纳土地附近的殖民行动；1700年底该苏格兰据点已结束，1707只是公司资本政治余波。')
}
for topic,(heading,paragraph) in section.items():
 p=P/'TOPIC_DOSSIERS'/f'{topic}.md';assert p.exists(),p
 old=p.read_text(encoding='utf8');marker=f'## 第五轮核实｜{heading}'
 if marker not in old:p.write_text(old.rstrip()+f'\n\n{marker}\n\n{paragraph}\n',encoding='utf8')
# HBC, Newfoundland, Darien long series extras
for dossier,head,body in [
('HBC_1699_1713.md','丘吉尔1699→1700错误驻军识别','加拿大公园局C5-HBC-PARKS-CHURCHILL/C5-HBC-PARKS-CAPEMERRY明确1689商站建成即焚毁，1717才开始新址重建。York Fort则1697—1713由法国驻点，参照C5-HBC-PARKS-YORK。不能将两处同时画成英方军事驻军，更不能将Rupert Land全部填充英国实控色。'),
('1700_NEWFOUNDLAND_LAW.md','1708旧历／1709新历圣约翰斯堡垒易手','Fort William于1708-12-21旧历即1709-01-01新历被Saint-Ovide军攻下，DCB C5-CAN-DCB-LLOYD提供两日期对应；1709年末英方持久驻军未证，法国当年末驻军亦需另核。1729司法机构新阶段必须与1699法案1700条款生效分开。'),
('1700_DARIEN_OLD_STORY.md','达连文书史料层级与三月—四月分界','C5-SCOT-NLS-DARIENPAPERS收录1700年3月18日达连议事、21日委任书；此为后世印刷的同期文书选录，不是已逐页审阅17世纪亲笔原档。投降日期另据C2-DAR-2025，应保留不同来源，1707不再作为殖民据点控制持续状态。')]:
 p=P/'TOPIC_DOSSIERS'/dossier;txt=p.read_text(encoding='utf8');mark=f'## 第五轮｜{head}'
 if mark not in txt:p.write_text(txt.rstrip()+f'\n\n{mark}\n\n{body}\n',encoding='utf8')
# comprehensive investigation report and 16-18 continuity production handoff
report='''# 第五轮深入调查｜三世纪历史连续性、澳大利亚、爱尔兰、苏格兰\n\n研究状态：`research_only`；2026-11-08；GitHub只读；原始档案馆目录与经过编辑的影印并不等同已翻检原件。\n\n## 一、1699/1700关键控制位点\n\n| 位点 | 1699—1709可靠阶段判断 | 禁止自动延续/问题 | 主要来源 |\n|---|---|---|---|\n| York Fort / Fort Bourbon (Hayes River) | 法方1697夺取，直至1713年和约变化 | HBC 1670特许不等于此堡持续英国驻军，旧址与现代York Factory III区别 | C5-HBC-PARKS-YORK, C3-HBC-PARKS-YORK |\n| Churchill River | 1689短命HBC商站起火消失，1717才较稳定重建 | 1700—1709不能自行推定英方现役驻守 | C5-HBC-PARKS-CHURCHILL, C5-HBC-PARKS-CAPEMERRY |\n| Albany Fort | 英商站仍存，1709曾受法方袭击 | 仅堡核心点；非哈德孙湾流域实占 | 见四轮SITE_SPECIFIC_CONTROL_1697_1715.json |\n| Newfoundland St John’s Fort William | 1705年法方攻击未夺，1708旧历/1709新历攻陷并毁坏 | 一次攻陷、双历日期；1709年末复驻军必须另外证明 | C5-CAN-DCB-LLOYD, C5-NFL-HERITAGE-WAR |\n| French Plaisance/Placentia | 1713年转移前为法方据点 | 官方资料一句概述有时间压缩，不能在1713前判英国实控 | C5-NFL-HERITAGE-WAR |\n| New Edinburgh, Darien | 1699第二批抵达、1700投降结束 | 苏格兰公司；古纳自主，17C旧文章截止1699并非真实结尾 | C5-SCOT-NLS-DARIENPAPERS, C2-DAR-2025 |\n\nYEAR-END的逐年格子仅把已证历史区间应用于各年；绝不是每一年有独立点验驻军的原档。见ROUND5_SITE_YEAR_DECISION_MATRIX_1699_1710.json。\n\n## 二、苏格兰Darien与1707年联盟\n\n1849年印行的Darien Papers选录提及1700-03-18/21议事与委任，后续投降4月阶段独立。1707-01-16苏格兰议会以110票对67票批准条款；1707-03-06英格兰立法获御准；1707-05-01大不列颠王国成立。期间爱尔兰保留自己的王国议会。以合同、贸易与债权追述达连经济后果，不画作1700后当地苏格兰实控面积。来源 C5-UK-PARL-UNION-RATIFY, C5-UK-PARL-UNION-HOUSE, C5-SCOT-NLS-DARIENPAPERS。\n\n## 三、1770—1799澳大利亚当地政治与殖民扩张\n\n1770-08-22 库克航海日志宣示有直接文字源；NMA某时间线写1770-09-13，标注为冲突源；澳大利亚博物馆与Kaurareg传统土地持有人对实际登岛升旗有所异议。1770年东岸不得涂英国实际占领。1788-01-18 Botany Bay到达与1788-01-26在Warrane/Sydney Cove设站分开。1789 Rose Hill小麦耕作、1791年末政府农场>200英亩仅能证明局部农耕，不能由英亩绘制地契Polygon。1794/1795 Hawkesbury殖民侵入与本地反抗、惩罚行动按各地方角色呈现，不将所有河流反抗归于Pemulwuy。原住民政治主体与殖民机构在同年并存。来源 C5-AU-NLA-COOK, C5-AU-MUSEUM-CONTEST, C5-AU-SLNSW-FIRSTFLEET, C5-AU-SLNSW-FIRSTFARMS, C5-AU-HAWKESBURY-COUNCIL。\n\n## 四、爱尔兰1720—1801法律与军事断点\n\n1720年3月 Declaratory Act 强化伦敦议会对爱尔兰立法和上诉权；1782年英国废除限制并改造Poynings Law制度，爱尔兰议会仍与英国任命行政机构并存。1798年军事行动要区分都柏林组织遭拘捕、Wexford New Ross、Arklow、Foulkesmills、Vinegar Hill、法军Killala登陆与9月残余抵抗。国家档案馆1798史料配套及NLI两幅当时战场图均建立目录；地图尚未取得可校正的原图像素和元数据，不画精确军阵。Killala登陆日有22/23日冲突，事件日期退为月份。1799英爱联合提案初遭否决；1800通过、1801生效属于19C，不提前投射。来源 C5-UK-PARL-IRISH-1720, C5-UK-PARL-IRISH-1782, C5-IRL-NAI-1798, C5-IRL-NLI-TAYLOR-MAP, C5-IRL-NLI-HARDY-MAP, C5-UK-PARL-IRISH-1799。\n\n## 五、苏格兰1746法制与1748起效\n\n1746年Tenures Abolition与Heritable Jurisdictions两法不能因为有共同的1748-03-25重要生效日而合并一个法令。氏族辖区的实际军事镇压、没收各处产业和后续高地牧场资本主义经营，须分别按庄园核对。不将19世纪Sutherland大清场投射1790年代。来源 C5-UK-LEGIS-TENURES, C3-SCO-LEG-1746。\n\n## 六、仍阻碍实控Polygon发布的档案问题\n\n1. 1699各堡点位/年末驻军的原始名册与换旗真实日期；Parks Canada公布的是区间历史，不是每年逐堡兵员原卷。\n2. 达连 Fort St Andrew 本体、西班牙围城及Guna主权区域没有可核准1720以前历史界线。\n3. 1798 NLI L368/L391军事地图尚未根据原图实测控制点做空间配准；历史图可研究不等于现代精准战线。\n4. Parramatta/Hawkesbury小田地、征用地契和古纳/Gadigal/Darug实际领地界线未独立核证。\n5. 岛屿、海湾、航线和18世纪英方省级特许研究几何保持研究层，不能计殖民实际土地面积。\n\n伴随审计：ROUND5_EVENT_DEDUP_REVIEW.json、ROUND5_PRE_POST_18C_ANCHORS.json、ROUND3_EVIDENCE_CONFLICTS.json、HISTORICAL_MAP_SOURCE_CATALOG.json。\n'''
(P/'ROUND5_DEEP_RESEARCH.md').write_text(report,encoding='utf8')
with (P/'ROUND5_THREE_CENTURIES_CONTINUITY_GAPS.md').open('w',encoding='utf8') as f:f.write('''# 16—18世纪常漏承接议题（第五轮）\n\n- 16世纪爱尔兰都柏林Pale／英格兰王权核心与17世纪阿尔斯特殖民、克伦威尔土地没收及18世纪1704宗教惩罚法：每段历史控制与土地所有权关系不同，不能将17世纪战争扩展到整个18世纪。\n- 16世纪跨洋王室航海声索→17世纪公司贸易特许／港口驻军→18世纪1770航海声索与1788定居：三种不同主权概念，原住民自治应有独立政治层。\n- 17世纪E6-T04-DARIEN从1698首航、1699第二批抵达到1700年投降与撤退，后1707年金钱债权后果；后世纪不再有苏格兰殖民驻点。\n- HBC公司1670特许→1697约克堡法国易手，1689丘吉尔短期商站焚毁→1713约克堡返还，1717丘吉尔重建；同一个公司每处驻点实际控制断点不同。\n- 1699纽芬兰法案1700部分生效与1705 Fort William守城、1708 O.S./1709 N.S.失守不能混为同一条持续殖民发展线。\n- 英苏1707年联合与爱尔兰1720/1782立法权变化、1798起义、1800批准和1801正式合并：国名与法律主体在不同年份逐一调整。\n- 1770 Kaurareg/库克声索→1788 Gadigal居住地殖民建站→1795 Dyarubbin/Hawkesbury地方冲突→1801/1802 Pemulwuy抵抗：不同族群，不能笼统写成同一条英属新南威尔士统治Polygon。\n- 1795/1796牙买加马龙战争与1796放逐新斯科舍后，1800抵塞拉利昂；跨19世纪船上人口与放逐总数分母不同，不加入1799年度。\n''')
for fname,para in [('MISSING_TOPICS.md','第五轮待核：Fort William新旧历与1709持久驻军；Churchill 1689-1717空窗的短期商贸；Fort Bourbon和Albany逐年原始驻军；1798年NLI L368/L391原地图版权、扫描和配准；Kaurareg 1770仪式争议；Killala 1798年8月22/23日；Darien 1700年3月、4月文书；爱尔兰各地产和原住民族分界。参见 ROUND5_DEEP_RESEARCH.md、ROUND5_HANDOFF_OTHER_ASSISTANTS.json。'),('PROGRESS.md','第五轮新增：35条独立来源、9条证据论点、6条日期/叙述冲突、96条分关系逐年区间判断、3份爱尔兰1798原图/目录记录、跨世纪历史断点。原始事件164条经6组去重并移出3条1689/1800/1801承接记录后剩155条（含既有17C起始前史事件）；所有临时删除的研究内容已合并旧ID或保存在ROUND5_PRE_POST_18C_ANCHORS.json。未作任何Github写操作。'),('README.md','第五轮资料入口：ROUND5_DEEP_RESEARCH.md（主题证据与制图禁忌）、ROUND5_EVENT_DEDUP_REVIEW.json（稳定ID去重）、ROUND5_SITE_YEAR_DECISION_MATRIX_1699_1710.json（非独立年度驻军报告）、ROUND5_PRE_POST_18C_ANCHORS.json（跨18C界限前后事件）、HISTORICAL_MAP_SOURCE_CATALOG.json（原始战场图馆藏目录）、ROUND5_THREE_CENTURIES_CONTINUITY_GAPS.md（16—18C断点）。')]:
 p=P/fname;txt=p.read_text(encoding='utf8');head='## 第五轮新增｜历史精准断点和后续任务';
 if head not in txt:p.write_text(txt.rstrip()+f'\n\n{head}\n\n{para}\n',encoding='utf8')
print('post-edited sources, events, topics, places',len(S['sources']),len(E['events']),len(section),len(G['features']))
