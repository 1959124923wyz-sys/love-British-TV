from pathlib import Path
import json,csv,hashlib,zipfile,collections,re,datetime
P=Path('/mnt/data/18c_assistant_C');Z=Path('/mnt/data/18c_assistant_C_continuity_australia.zip')
load=lambda n:json.loads((P/n).read_text('utf-8'))
src=load('SOURCE_REGISTRY.json');ev=load('EVENT_CANDIDATES.json');geo=load('MAP_CANDIDATES.geojson');claim=load('CLAIM_EVIDENCE_MATRIX.json');cont=load('CROSS_CENTURY_AUDIT.json');ann=load('CONTROL_TRANSITIONS_1699_1709.json')
checks=[]
def check(name,val,detail=None):checks.append({'check':name,'pass':bool(val),'detail':detail})
source_ids=[s['id'] for s in src['sources']]; event_ids=[e['id'] for e in ev['events']]; point_ids=[f['id'] for f in geo['features']]; claim_ids=[c['id'] for c in claim['claims']]
check('source_count_matches',len(src['sources'])==src['source_count'],src['source_count']);check('event_count_matches',len(ev['events'])==ev['event_count'],ev['event_count']);check('claim_count_matches',len(claim['claims'])==claim['evidence_count'],claim['evidence_count']);check('unique_source_ids',len(source_ids)==len(set(source_ids)));check('unique_event_ids',len(event_ids)==len(set(event_ids)));check('unique_place_ids',len(point_ids)==len(set(point_ids)));check('unique_claim_ids',len(claim_ids)==len(set(claim_ids)))
for e in ev['events']:
 if e.get('id','').startswith('C7-'):
  check('R7 source-link '+e['id'],set(e['source_ids']).issubset(source_ids));check('R7 anti-polygon '+e['id'],e.get('historical_control_polygon_approved') is False);check('R7 event-has-place-and-actor '+e['id'],bool(e.get('actor') and e.get('action') and e.get('historical_place')))
  if e.get('geometry_ref'):check('R7 mapped-ref '+e['id'],e['geometry_ref'] in point_ids,e['geometry_ref'])
for c in claim['claims']:
 if c.get('id','').startswith('R7-'):
  check('R7 claim-links '+c['id'],set(c['source_ids']).issubset(source_ids))
for f in geo['features']:
 check('geography no polygon '+f['id'], f.get('geometry') is None or f['geometry']['type']=='Point')
 if f.get('geometry') and f['geometry']['type']=='Point':
  lon,lat=f['geometry']['coordinates'];check('geo WGS84 '+f['id'],-180<=lon<=180 and -90<=lat<=90)
 check('geo no area '+f['id'],f['properties'].get('area_sqkm') is None and f['properties'].get('fill_authorized') is False)
 if f['id']=='PLACE-GLENSHIEL':
  lon,lat=f['geometry']['coordinates'];check('Glenshiel correct NG grid',-5.4<lon<-5.2 and 57.1<lat<57.3,{'lon':lon,'lat':lat,'not_NH_grid':True})
with (P/'EVENT_CANDIDATES.csv').open('r',encoding='utf-8-sig',newline='') as fp:erows=list(csv.DictReader(fp))
with (P/'CLAIM_EVIDENCE_MATRIX.csv').open('r',encoding='utf-8-sig',newline='') as fp:crows=list(csv.DictReader(fp))
check('events CSV JSON row parity',len(erows)==len(event_ids));check('claims CSV JSON row parity',len(crows)==len(claim_ids));check('events CSV IDs parity',set(r['id'] for r in erows)==set(event_ids));check('claims CSV IDs parity',set(r['id'] for r in crows)==set(claim_ids));check('R7 event count',sum(e['id'].startswith('C7-') for e in ev['events'])==37)
check('R7 proposals 9 rows',len(load('ROUND7_PROPOSED_MAJOR_TOPICS.json')['proposals'])==9)
check('R7 dossier files six',len(list((P/'ROUND7_MAJOR_IMPACT_DOSSIERS').glob('*.md')))==6)
check('R7 conflicts tracked six',load('ROUND7_EVIDENCE_CONFLICTS.json')['open_count']==6)
check('no original historical claim polygon in corpus',not any(f.get('geometry',{} ) and f.get('geometry',{}).get('type') in ('Polygon','MultiPolygon') for f in geo['features']))
for i in [p['candidate_event_ids'] for p in load('ROUND7_PROPOSED_MAJOR_TOPICS.json')['proposals']]:check('R7 proposed events resolve',set(i).issubset(event_ids))
# preserve 36 and 270 legacy checks by understanding schema
check('36-story continuity preserved',len(cont.get('entries',[]))==36,str(cont.keys()))
check('270 seed annual checks preserved', len(ann['candidates'])==27 and all(len(c.get('year_end_reviews',[]))==10 for c in ann['candidates']))
# Cohort consistency; source aliases in legacy manually resolved as in earlier rounds (test only new)
check('last source map all refs',all(set(f['properties'].get('source_ids',[])).issubset(source_ids) for f in geo['features'] if f['id']=='PLACE-GLENSHIEL'))
qa={'schema':'round7-major-impact-audit','date':'2026-11-08','status':'research_only','events':len(event_ids),'new_round7_events':37,'sources':len(source_ids),'places':len(point_ids),'claims':len(claim_ids),'check_count':len(checks),'checks_passed':sum(x['pass'] for x in checks),'checks_failed':sum(not x['pass'] for x in checks),'failed_checks':[x for x in checks if not x['pass']],'checks':checks,'publication_approved':False,'git_modified':False,'historical_actual_control_polygons':0}
(P/'ROUND7_QA_REPORT.json').write_text(json.dumps(qa,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
if qa['checks_failed']:print('FAIL',qa['failed_checks']);raise SystemExit(1)
summary={
 'schema':'18c-assistant-C-round7-major-impact-deliverable-index','editorial_state':'research_only','date':'2026-11-08',
 'source_round6':'ROUND6_INDEX.json','preserve_previous_rounds':True,'github_modified':False,
 'summary':{'all_events':len(event_ids),'added_round7_events':37,'all_source_entries':len(source_ids),'all_place_entries':len(point_ids),'all_evidence_claims':len(claim_ids),'new_major_impact_dossiers':6,'new_major_topic_proposals':9,'review_points_total':sum(bool(f['geometry']) for f in geo['features']),'geographic_polygons':0},
 'key_gains':['1790 Second Fleet severe mortality','1746 post-Culloden deportation','Ireland 1740-1741 famine and 1761 Whiteboys agrarian grievances','1798 Antrim/Ballymena/Saintfield short-held controls','1778 Joseph Knight Court of Session emancipation ruling and judicial tally conflict','Scottish slavery-linked Glasgow tobacco and Dundas 1792 abolition amendment','Irish 1786/1790 conviction acts and 1791 first Irish convict ship','1719 Glenshiel original battle grid corrected to NG from official live HES register'],
 'read_order':['ROUND7_MAJOR_IMPACT_RESEARCH.md','ROUND7_MAJOR_IMPACT_DOSSIERS/','ROUND7_EVIDENCE_CONFLICTS.json','ROUND7_LOCAL_CONTROL_EPISODES.json','ROUND7_PROPOSED_MAJOR_TOPICS.json','ROUND7_COOPERATION_AND_19C_BOUNDARY.md','EVENT_CANDIDATES.json','SOURCE_REGISTRY.json','MAP_CANDIDATES.geojson','ROUND7_QA_REPORT.json'],
 'historical_boundary_notice':'No real control territory polygons added; modern battlefield inventory center is not real 1719 army line.',
 'manual_user_actions':[]}
(P/'ROUND7_INDEX.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
with (P/'README.md').open('a',encoding='utf8') as f:
 f.write('\n## 第七轮增量（2026-11-08）\n\n新增多地区重大影响研究：见 `ROUND7_INDEX.json`、`ROUND7_MAJOR_IMPACT_RESEARCH.md`和`ROUND7_MAJOR_IMPACT_DOSSIERS/`。本次将旧有179条候审事件扩充至216条，全部研究候审，无历史控制Polygon。新增HES Glenshiel仅为现行政府网格转换的现代战场参考点，已纠正旧PDF网格拼写差错。原所有文件完整保留，GitHub未修改。\n')
# remove stale manifest; generate new listing checksums incl new current report, exclude itself
archived=[q for q in P.rglob('*') if q.is_file() and '__pycache__' not in q.parts and q.name!='ARCHIVE_MANIFEST.json']
manifest={'schema':'18c-assistant-C-integrity-sha256-v7','date':'2026-11-08','zip_filename':Z.name,'source_root':str(P),'file_count_excluding_manifest':len(archived),'files':[]}
for path in sorted(archived):
 b=path.read_bytes();manifest['files'].append({'path':str(path.relative_to(P)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
(P/'ARCHIVE_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
files=sorted(q for q in P.rglob('*') if q.is_file() and '__pycache__' not in q.parts)
with zipfile.ZipFile(Z,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
 for path in files: archive.write(path,arcname=str(Path('18c_assistant_C')/path.relative_to(P)))
with zipfile.ZipFile(Z) as archive:
 bad=archive.testzip();names=archive.namelist(); assert bad is None;assert len(names)==len(files)
 for rel in manifest['files']:
  actual=archive.read('18c_assistant_C/'+rel['path']); assert hashlib.sha256(actual).hexdigest()==rel['sha256'], rel['path']
print(json.dumps({'archive':str(Z),'zip_bytes':Z.stat().st_size,'file_count':len(files),'qa_checks':qa['check_count'],'qa_passed':qa['checks_passed'],'events':len(ev['events']),'sources':len(src['sources']),'places':len(geo['features']),'claims':len(claim['claims']),'hashes_passed':len(manifest['files'])},ensure_ascii=False))
