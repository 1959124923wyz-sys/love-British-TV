# 18世纪第三调查员研究数据包

**研究范围：** 17C→18C连续性与1699–1709年末政治控制审核、澳洲D01–D10、爱尔兰苏格兰F01–F09。

本文件夹是研究候审成果，不是生产站点的地图数据库。请先读`PROGRESS.md`和`MISSING_TOPICS.md`，再读机器数据与`TOPIC_DOSSIERS/`。所有事件使用第三调查员研究ID (`C-DXX-...`/`C-FXX-...`)，不得与未来主编正式Atlas事件ID混淆。

## 文件

- `CROSS_CENTURY_AUDIT.json` — 36项旧专题（历史结束与旧研究截止分开）
- `CONTROL_TRANSITIONS_1699_1709.json` — 27幅候审参考图形 × 10年逐年缺口与已证变更
- `TOPIC_DOSSIERS/` — 19篇全部D/F专题分析 + 9篇跨世纪专项
- `EVENT_CANDIDATES.json`, `.csv` — 事件/阶段研究账本（明确年份精度）
- `SOURCE_REGISTRY.json` — 来源与原卷访问级别、链接，接上游PR #289的88条清单
- `MAP_CANDIDATES.geojson` — 地理候审位置：3个具现代参考坐标点，其余`null`；无历史边界Polygon
- `CONTROL_RELATION_DECISION_GUIDE.md` — 制图和证据规则
- `MISSING_TOPICS.md` — 重大漏项与其他两位调查员协作任务
- `PROGRESS.md` — 本轮成果、证据等级、未解决问题
- `QA_REPORT.json` — 本地结构完整性检查
- `build_research.py` — 本地生成源代码，可重跑生成文件；非GitHub操作脚本

## 重要区分

17世纪研究窗停在1699年不表示历史制度截止1699；1700达连军事实控终结与1707两王国联合分成不同事件。1707年前苏格兰仍是独立王国，爱尔兰直到1801年才正式合并；1770东海岸声索绝非英国当时已实际控制澳洲大陆。

GIS只记录史事具名地理、现代来源可追的点，不使用现代州、郡、流域或大陆轮廓冒充历史殖民实控范围。正式主站上的点击/双击和返回尚未做18C版本浏览器验证。

## 第二轮增量（2026-11-08）

- `ROUND2_RESEARCH_NOTES.md`：新增来源交叉核对的历史断点、数值分母及与地图有关的结论。
- `TRIPLE_CENTURY_BRIDGES.json`：16世纪参考ZIP里存在的已发表稳定故事ID与17世纪36项登记、18世纪母题的8条研究连续性链。
- `CLAIM_EVIDENCE_MATRIX.json/.csv`：20条关键论点—直接来源—原件查阅层级—绘图许可的机器化矩阵。
- `expand_round2.py`与`finish_round2.py`：第二轮增量源与专题文件修改程序。**不应在最终资料上重新运行原`build_research.py`（会覆盖更新）**；重新搭建时先运行原脚本、再运行增量脚本、最后运行QA。
- 原始`validate_local.py`已调整为基于实际条目计数校验，可验证完整包，归档后另校对ZIP CRC和SHA256。

本轮新的Source ID以`C2-`开头，原`SOURCE_REGISTRY.json`的53个ID仍然保留；所有来源均标记相应访问层级，尤其学术论文搜索索引的摘录不宣称为亲阅1715原档。新增地点几何全部为空，现有现代参考Point数仍为3。

## 第三轮专题复查

### 第三轮（2026-11-08）

- 新增逐堡独立研究`SITE_SPECIFIC_CONTROL_1697_1715.json`：加拿大公园局证实York Fort(1697–1713)法方Fort Bourbon，原27块参考层的Rupert虚线**不能转为英国实控**；1700–1709十年有法方局点存在的机构史料区间、无逐年驻军名册/真实古堡GPS。
- 事件累计**110**（原89，新增21，另修订4个旧事件的日期与来源）；来源总计**126**（原87），地理参考地点共31（Point仍仅3，其余null）。`CLAIM_EVIDENCE_MATRIX`共37条。旧36专题、27×10=270条年份审核槽位均保留。
- NSW州档/州立图书馆揭露Ruse农田使用、1791地方授地叙述与1792-02-22正式记录的冲突；`ROUND3_EVIDENCE_CONFLICTS.json`已明确解决框架。Arabanoo 1788-12-31、1789-05-18，Bennelong/Colebee 1789-11-25经来源交叉核日。
- 爱尔兰1793有限天主教选民资格恢复、苏格兰世袭司法权1748-03-25生效、1748–1769Fort George逐步驻军建设均新增具年候审节点与19篇D/F专题升级。
- `BOUNDARY_1799_1800_HANDOFF.json`防止把Pemulwuy 1802被杀、英国爱尔兰1801合并、马龙1800西非迁徙提前至1799。所有仍仅`research_only`；本地未修改GitHub。

## 第四轮增补（2026-11-08）

- 累计**137**件候审记录、**142**条来源，**46**组声明证据检查、**42**处命名地理候选；有效具独立现代参考坐标仍仅3处。
- 3座新具名堡垒/驻点各增加1700–09年末核对数据，与York共计4个据点（不是“4块国土”）。
- 额外8组爱尔兰法条执行时间`LEGAL_CLAUSE_TIMELINE_1702_1709.json`、跨部门对照`ROUND4_DEEP_RESEARCH.md`及增补冲突`ROUND3_EVIDENCE_CONFLICTS.json`。
- 依旧不发布、不合并、不推断历史边线；GitHub未更改。

## 第五轮新增｜历史精准断点和后续任务

第五轮资料入口：ROUND5_DEEP_RESEARCH.md（主题证据与制图禁忌）、ROUND5_EVENT_DEDUP_REVIEW.json（稳定ID去重）、ROUND5_SITE_YEAR_DECISION_MATRIX_1699_1710.json（非独立年度驻军报告）、ROUND5_PRE_POST_18C_ANCHORS.json（跨18C界限前后事件）、HISTORICAL_MAP_SOURCE_CATALOG.json（原始战场图馆藏目录）、ROUND5_THREE_CENTURIES_CONTINUITY_GAPS.md（16—18C断点）。

## 第六轮最终补充（2026-11-08）

**最新权威入口：** `ROUND6_HANDOFF.md`、`ROUND6_INDEX.json`、`ROUND6_QA_REPORT.json`。后续计数请以第六轮机器索引为准，历史轮次的数字均是当时快照。新增约克工厂I/II/III及丘吉尔河旧新据点身份审核、1798年韦克斯福德镇级控制候审、1702/1704爱尔兰法条分署、1794年Hawkesbury定居者杀戮的跨来源冲突核对。全文件研究候审，GitHub不修改。

## 第七轮增量（2026-11-08）

新增多地区重大影响研究：见 `ROUND7_INDEX.json`、`ROUND7_MAJOR_IMPACT_RESEARCH.md`和`ROUND7_MAJOR_IMPACT_DOSSIERS/`。本次将旧有179条候审事件扩充至216条，全部研究候审，无历史控制Polygon。新增HES Glenshiel仅为现行政府网格转换的现代战场参考点，已纠正旧PDF网格拼写差错。原所有文件完整保留，GitHub未修改。


### Round 8 经济、人口、政策体系审查
查看 `ROUND8_SYSTEMIC_IMPACT/`，首读 `ROUND8_INDEX.json` → `POLICY_MECHANISM_MATRIX.json` → `STATE_RESPONSIBILITY_ADJUDICATION.json` → `QUANTIFIED_IMPACTS.json` → 分篇MD。该轮不创造新历史边界，未查原件均保留阅读等级。

### Round 8 制度化政策—人口—经济影响研究（补完）
- `ROUND8_SYSTEMIC_IMPACT/ROUND8_INDEX.json` 为总入口；包含29项政策机制、22项有口径的经济人口数值、18项国家责任归属裁定与11篇专题补证，新增1778 Knight司法反例、1792渐进废奴议会选择。
- 文字要区分立法授权、行政执行、司法不追究、私人暴力、法律限制和仍存争议的因果；所有资料`research_only`。
