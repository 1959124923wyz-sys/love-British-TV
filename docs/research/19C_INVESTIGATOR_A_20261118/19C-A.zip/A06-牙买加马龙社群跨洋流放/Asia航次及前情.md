# 马龙转运与前情

原居 Trelawny Town → 1796 押赴 Halifax → Preston 定居；部分人转 Boydville。1800 年转运港口为 Halifax、Freetown 外海，中途停靠未取得。  
Preston 目录安置数543；后出地方史列8月551人离港；Parks Canada 以9月30日船上分组计抵锚550。启航日精确到月，停锚精确到日。交 C07 核登陆文书、首次安置和当地治理。见 A06-S01 至 S05。
