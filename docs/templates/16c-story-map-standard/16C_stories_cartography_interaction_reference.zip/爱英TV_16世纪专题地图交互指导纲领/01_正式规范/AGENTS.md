# 爱英TV｜GitHub / AI 调查员接手入口

**2026-11-22正式进展：** 19世纪R1的T37已正式发表（#507）；**T46澳大利亚边疆五章**已按#509（37/37 Actions）与#510（35/35 Actions）正式发布，Pages #44985306164的构建和部署均成功。T46单专题25节75段、39年表链接、17 GIS图元，历史未核地籍与死亡点保留待核。R2 T05 Morant Bay已正式发表：[制作#512](https://github.com/1959124923wyz-sys/love-British-TV/pull/512)47/47、[出版#513](https://github.com/1959124923wyz-sys/love-British-TV/pull/513)46/46、[Pages #44992361081](https://github.com/1959124923wyz-sys/love-British-TV/actions/runs/44992361081) build/deploy双成功，18节54段23个历史事件6个GIS图元。继续原卷GIS待核，下一T14，详[R2 T05长期待办](research/19c/consolidated/T05_NEXT_ACTIONS.md)，T15/T26旧编审预览不会自动批准。



## 19世纪任务统一入口（2026-11-21，PR #463 已合并 main）

**跨对话总任务板：[Issue #499](https://github.com/1959124923wyz-sys/love-British-TV/issues/499)。** 所有后继任务可以从此进入，状态以CSV和已合并PR为准。

**以后任何新的主编／调查员／GIS智能体收到“继续十九世纪”“制作19世纪专题”“画十九世纪历史区域”等指令，第一步必须阅读 [19世纪接力总入口](research/19c/consolidated/START_HERE.md) 与 [总编—GIS交接](docs/research/19C_EDITORIAL_GIS_HANDOFF.md)，然后读取 [59专题工作板](research/19c/consolidated/TOPIC_WORKBOARD.csv)、[150章节工作板](research/19c/consolidated/CHAPTER_WORKBOARD.csv) 和 [研究进度](research/19c/consolidated/PROGRESS.md)。**

PR #463 的研究卷已正式归档：**59专题、150章、1,980条研究年表、1,520条史料索引、1,317条GIS线索、353条待核问题**；其中27专题为首批，32专题为后续。**这些数字只属于研究，不是已经发表的文章、实测疆界或新增正式事件。** 研究原案号、事件号、引用键不可丢失。后续任何新对话以 GitHub 的工作板和最新 `main` 数据为准，不必要求用户重复上传ZIP或自行操作代码。

正式站已经有1800—1899年的历史年表及 `data/nineteenth-century-*.geojson`；必须先与现有史实和地理去重，再按16世纪长篇模板、历史地图标准和公开文案禁令分批提交独立PR。只要证据足够，优先画有出处的真实地理区域；有据而边界不明的用虚线，禁止捏造土地、面积、死亡人数和原件内容。跨1800年和每个新十年要追踪控制关系的持续、转移、收缩、结束。每个PR更新上述两张工作板和进度，并通过严格GIS、桌面浏览器与Pages核验；没有发布核验就保持待审状态。



## 最高优先级：读者界面永久禁用制图／编审免责声明（2026-11-12，用户明确要求）

**这是所有后续主编、调查员、GIS制图人员、前端维护者、AI助手必须遵守的发布红线。发现类似问题时，先修复公共展示入口，再制作新图。**

- **用户能看到的任何地方一律禁止**：“虚线为概略历史地理参考，边界未经历史地图实测配准”“区域海河贸易通道，非英国河两岸主权”“殖民省行政外缘不等于持续驻军”“重叠的示意区块不能累加面积”等同类话术。包括地图悬浮卡、SVG/CSS提示、右侧区域与事件详情、专题文章、章节介绍、图例、年份状态、搜索结果、按钮标题、`title`／`aria-label` 等。
- **宽标准判断**：只要句子的主要用途是解释地图画法、像素／矩形／虚线／边界配准／地理代理坐标／面积不能计算／控制权不能凭颜色推定／编辑审核状态，就属于读者禁用文案。**不要换一种措辞重新塞回来**，也不要为了凑字数添加“仅供参考”“不代表真实主权”等提示。
- 对外只写**历史事实本身**：年份、地点、具体行动、组织者与受影响者、当地抵抗、可核结果，以及可靠史料链接。合法主权、政治主体及真实历史争议仍属于应写史实，不能被误删。所有不确定地图边界继续以**虚线**表达，图层类别和几何来源继续区分。
- **原始数据严禁批量删除**：`source_urls`、`geo_precision`、`geolocation_limit_zh`、`historical_boundary_confirmed`、`area_sqkm`、`note`、原始史学争议和史料证据照旧保存。**只在展示层过滤**，使用 `window.AtlasReaderCopy.clean()/label()`；新增展示组件须接入 `js/atlas-public-ui-guard.js` 的公共DOM最终保护。
- **每个后续PR必跑**：`node scripts/test_atlas_47_public_copy_guard.js` 、`node scripts/lint_atlas_47_frontend_copy.js`、`python3 scripts/browser_atlas_47_public_copy_guard.py` 和 `python3 scripts/browser_atlas_47_all_years.py`（逐年检查1497—1799年）（需Chrome/Selenium与本地服务）。CI工作流 `.github/workflows/atlas-47-public-copy-policy.yml` 自动执行；用真实Chrome测试跨16／17／18世纪、重叠区块与文章显示。出现读者可见的类似文本，PR不能验收。
- 详细规则、示例、排查清单及新同事操作流程：[读者界面文案永久约束](docs/READER_PUBLIC_COPY_POLICY.md)。历史来源与地图不确定性说明可留在研究档案，不可在读者页面以“学术备注”呈现。


## 地图密度与可点击性：第52批独立评估规则（暂为Draft，正式合并后生效）

**减少可见标记不等于删去历史事件。** 低缩放时所有有据、具坐标且处于当前历史窗口的事件都必须进入可点击聚合，聚合成员数须与原记录数量逐项一致；无法定位的事件照常留在左侧年表。大聚合用右侧完整列表，不自动在鼠标经过时弹出一整片图标。区域虚线仅通过可逆透明度减弱视觉拥挤，不关闭SVG的点击命中。独立事件标记优先于背景区域选择器，重叠区域必须列出全部对应史料。

实现、缩放分级、原始数据保护和Chrome验证详见 [地图密度与选择规则](docs/ATLAS_MAP_DENSITY_SELECTION_RULES.md)。本规则在 Draft PR #349 验收且正式合并前仅供审查，不能据此绕过现有质量门槛。

本仓库用于逐年、逐十年绘制英格兰、苏格兰及1707年之后英国相关的殖民统治、经济网络、军事行动、抵抗与独立。**所有调查智能体、编辑与主编，开展新历史时期前应先阅读以下规范。**

## 2026-11-10以后：历史选题重点与专题阅读器（用户正式要求）

**优先研究英国殖民者实施的、能够由权威史料支撑的烧杀掳掠和殖民剥夺。** 具体优先级：攻城和屠杀、劫掠民居及宗教机构、焚烧村庄和粮食、强迫迁徙或流放、奴役及人口贩运、征地没收、勒索赎金和战争赔款、强制征税、殖民军镇压当地抵抗。完整专题要说明谁组织实施、在哪个年份和地点、谁受到伤害、当事人如何反抗、掠获财产何去何从。纯英法竞争及外交制度背景只有在解释上述事实时才占据较大篇幅。

后续涉及英军或殖民军警的专题，优先追查执行部队或机构、命令链、可核证的受害者证词、毁损财物和追责经过。有资料时沿资源的产地、征用或采购、转运、目的地和受益者核查，分别登记实物数量、货值、公司利润与政府财政收入。

**不得为了突出暴行而捏造暴行、伤亡数、受害证言、英国获得的净利润或古代疆界。** 被要求的赔款、被开出的汇票、实际付到的款项、军官战利品与民众私人损失分开记录。英军占领一座外国殖民城市，不等于控制整个殖民地；当地原住民与西班牙/法国原统治者亦保留不同主体身份。

**全部长篇阅读页面一律取消浮动目录**：用户明确要求移除“章节目录／第X/Y节·已读Z%／回到开头”动态浮条及重复折叠阅读目录；保留章节标题、可靠来源、正文与地图事件互动，以及返回原事件。GitHub PR #300 已按此规范完成主分支的移除，未来专题不得再添加相同控件。只维护桌面网站。

## 16世纪成熟范例：所有后续重大专题必须模仿（2026-10-21生效）

**正式制作模板：** [16世纪专题写法、影响区画法、正文互动、地图镜头及出版审查纲领](docs/templates/16c-story-map-standard/README.md)，配套 [完整原始范例 ZIP](docs/templates/16c-story-map-standard/16C_stories_cartography_interaction_reference.zip) 及 [2026-10-22 接手核查与操作记录](docs/templates/16c-story-map-standard/HANDOFF_20261022.md)。所有历史调查员、地图制作者、主编及后来接手的智能体必须先对照包内**已上线16世纪故事、九年战争影响区、交互源代码及测试**，再制作任何新重大专题。

强制底线：**正文必须使用已核史实事件的 `[[ID|自然语言]]` 超链接**，单击能切到相应年份并移动地图、双击能进事件档案和返回；**军事/殖民影响区只有有据具名局部区域才允许虚线淡色示意**，无经核历史边界不能宣称实控Polygon或计算面积。所有新时期先查政治控制和跨年代延续，不能用商馆许可替代主权。GitHub按研究、文章、GIS、浏览器QA分批保存；全部通过后合并并核验Pages部署。

## 维护接手提醒（2026-10-18）

正式出版范围、章号与数据量应以当下的 `data/chapters.json`、各章 Atlas 及 `data/stories/index.json` 为准，不能以旧 `PROJECT_STATUS.md` 段落、尚未合并的研究 PR 或旧章号推断当前状态。截至2026-10-24，16世纪专题及地图已正式发布；1600—1699系列专题已在 `data/stories/serial/index.json` 中标记十六篇 `published`（爱尔兰土地、格伦科、达连苏格兰海外殖民与古纳外交、跨大西洋奴役航次人数估算及反抗、巴巴多斯、东印度公司、皇家非洲公司、新英格兰原住民战争与战俘奴役、弗吉尼亚波瓦坦战争与世袭奴役、牙买加征服与马龙抵抗和奴役法律、新尼德兰—纽约英荷政权更替与原住民土地权利、卡罗来纳领主殖民、原住民土地与奴役贸易、哈德孙湾公司与原住民毛皮网络及英法堡垒争夺、阿卡迪亚米克马克政治地理与皇家港英苏法驻点争夺、纽芬兰贝奥图克人海岸及英法渔业战争），其余仍有 `research_only` 候审母题。新英格兰专题的史料、地图标识、浏览器验收和研究缺口见 [E6-T06交接](docs/research/EDITOR7_E6_T06_NEW_ENGLAND_INDIGENOUS_WARS_20261023.md)。弗吉尼亚专题的1646/1677两份条约全文、奴役法律、地图规范与交接见 [E6-T05交接](docs/research/EDITOR7_E6_T05_VIRGINIA_POWHATAN_WARS_20261023.md)。牙买加专题的1658 Rio Nuevo战争、1661—1699奴役法律原文及山区马龙自主与18世纪年代禁忌见 [E6-T08交接](docs/research/EDITOR7_E6_T08_JAMAICA_MAROON_20261023.md)。纽约子篇E6-T09-NY 1664—1674英荷实控转换、1643荷兰对蒙西人的袭击、1670莱纳佩土地契据与非洲裔自由诉愿见 [主编9纽约专题交接](docs/research/EDITOR9_E6_T09_NY_NEW_NETHERLAND_20261024.md)。卡罗来纳子篇E6-T09-CAR 1663/1665领主声索、1669未全面实施宪制、1675/1676 Kussoe契据、1670/1680两处查尔斯敦城址、Westo俘虏贸易、1690遭否决和1696新奴役法规见 [主编9卡罗来纳专题交接](docs/research/EDITOR9_E6_T09_CAROLINA_20261024.md)。E6-T09母题仍research_only，不能因纽约及卡罗来纳两个子篇发表便视为该母题所有相关区域已充分研究。哈德孙湾公司子篇E6-T10-HBC 1668—1699特许与真实河口据点区别、原住民商业自主权、1686法国三堡攻取、1694—1697约克堡多次换旗，见 [主编9哈德孙湾公司专题交接](docs/research/EDITOR9_E6_T10_HBC_20261024.md)。阿卡迪亚子篇E6-T10-ACADIA涵盖1605第一处皇家港Habitation（与1629苏格兰Charles Fort/Fort Anne不同）、1654至1670英方驻点占领、1690 Phips夺堡掠夺而无永久驻军、1696博巴桑袭击和Mi’kmaq防卫外交、1697和约，见 [主编9阿卡迪亚专题交接](docs/research/EDITOR9_E6_T10_ACADIA_20261024.md)。E6-T10-NEWFOUNDLAND纽芬兰独立子篇已按17世纪范式记录贝奥图克人自主、1610丘比兹、1621费里兰、1662法国普莱桑斯和1696—1697战争及1699法规，参见 [主编10纽芬兰来源与地理交接](docs/research/EDITOR10_E6_T10_NEWFOUNDLAND_20261024.md)。**E6-T10总母题仍research_only**，三个独立子篇发表不等于整世纪海陆政治实控已经完成。17世纪专题发布不等于1600—1699全部年份的版图、事件和空间数据均已完成审核，必须分别核对数据与已批准的图层。

E6-T04-DARIEN苏格兰1695—1699达连殖民子篇已独立完成16章：苏格兰公司（非英格兰公司）认股与1698远征、古纳领袖1699年2月24日协议、西班牙殖民回应、1699年7月第一次撤离与11月第二批到达；不能把1698/1699短时据点外推为整座巴拿马或古纳土地实控。来源、初步坐标和1700年战斗排除规则见 [主编10达连史料交接](docs/research/EDITOR10_E6_T04_DARIEN_GUNA_20261025.md)。E6-T04母题（其他苏格兰海外/自治历史）仍research_only。

E6-T11-VOYAGES跨大西洋奴役人数／航次专题：18章与四个25年期英船旗 **估计被迫登船人数**（1601—1700合计428262人，含1700年，不等于1600—1699精确人数）；1680—1692年RAC子样本279个有据航次、84498登船与65157抵岸的差额，不可与史密森尼1673—1688年9万—10万估计相加或外推全世纪。另有1668逃亡、1675被处决、1688扣船、1694 Hannibal逾三百人死亡和1698 Bristol Beginning具年地图事件。严格不捏造单船起义年份、年度总人数、海上GPS或奴役控制地理Polygon，见 [E6-T11定量史料交接](docs/research/EDITOR12_E6_T11_ATLANTIC_SLAVERY_QUANT_20261025.md) 和 [结构化统计](data/research/e6-t11-transatlantic-slavery-1601-1700-estimates.json)；大母题个船档案审查仍research_only。

E6-T14-NAV航海法与英荷战争子篇，单列1651/1660/1663法令、1654/1667/1674和约、1666四日海战、1667荷兰梅德韦袭击、1672索尔湾/1673特塞尔及1695法条至1698适用日期，见 [主编11航海法与英荷战争交接](docs/research/EDITOR11_E6_T14_NAVIGATION_ANGLODUTCH_20261025.md)；E6-T14母题与各私掠船个案仍research_only，海面及舰队航迹不得转成历史主权面。

研究分支与 `main` 的同一年代文件可能已大幅分化。**只按事件 ID、来源和几何变化择优移植，不得用旧研究包完整替换新版章节，亦不得批量合并或关闭旧 PR。** 所有 GIS 与版图变更必须通过严格空间审核（`python3 scripts/audit_spatial_semantics.py --strict`），`ERROR` 阻止合并/发布，`REVIEW` 记录为待调查，不应通过删去真实疑点来追求零警告。具体清理优先级与核实数据见 [2026-10-18维护交接](docs/MAINTENANCE_TRIAGE_20261018.md)。

## 第一优先级：地图疆域与时间连续性

**十八世纪补绘的批次顺序与验收记录**见[十八世纪制图路线图](docs/research/18C_CARTOGRAPHY_ROADMAP.md)。

**每十年不得重置控制区；每次切片必须从上期最后一年继承控制关系，再根据史料逐项确认持续、扩张、收缩、转移、结束或未核实。** 没有新的文献不等于控制消失；上一期还有标记不等于当期已证实真实边界。任何变化都应有日期、地域、主体和来源。地图绘画优先于新增事件数量。

**详尽、可执行的调查工作纲领：** [docs/RESEARCH_TERRITORY_CONTINUITY_PLAYBOOK.md](docs/RESEARCH_TERRITORY_CONTINUITY_PLAYBOOK.md)

**历史地理绘画规范：** [docs/MAP_FIRST_CARTOGRAPHY_STANDARD.md](docs/MAP_FIRST_CARTOGRAPHY_STANDARD.md)

**点—线—区、军事影响区与具名地落图强制规范（2026-10-15）：** [docs/HISTORICAL_SPATIAL_NARRATIVE_STANDARD.md](docs/HISTORICAL_SPATIAL_NARRATIVE_STANDARD.md) · [逐项审查清单](docs/HISTORICAL_SPATIAL_REVIEW_CHECKLIST.md)。史料已确认的历史地名可落现代参考城市坐标，不能因缺16世纪城墙GPS长期留空；有据顺序才画线，区域行动证据才画淡色虚线影响区，均不当实测领土。**本仓库后续所有调查与制图PR必须遵照执行。**

**跨十年控制关系的底层规则：** [docs/TERRITORY_CONTINUITY_RULE.md](docs/TERRITORY_CONTINUITY_RULE.md)

**已批准的网站交互规则：** [docs/APPROVED_MAP_INTERACTION_STANDARD.md](docs/APPROVED_MAP_INTERACTION_STANDARD.md)

## 开工前执行

1. 先读取上一期地图 JSON、控制图层、虚线参考层、研究控制数据和上一期`PROGRESS.md`，不要仅凭当前章节事件决定领土。
2. 读取 [research/continuity/README.md](research/continuity/README.md) 与最近期末的控制区状态，列出前期每一处 `stable_id`。
3. 复制 [过渡模板](research/continuity/templates/DECADE_TRANSITION_TEMPLATE.json)，建立本次十年的控制去向记录；同时附带主编需要的 [交接模板](research/continuity/templates/EDITOR_HANDOFF_TEMPLATE.md)。
4. 调查并绘制可靠范围。真正历史控制区域才允许经过批准的实心面；城堡/城市屏幕圆形不代表古代面积；历史疆界不确定一律虚线。苏格兰1707年前是独立政体，不可误归英属殖民区。
5. 以精确日期判断年末状态、保留原始证据。**证据最后记载年份与历史控制结束年份必须分开。**
6. 提交独立Git分支，分批保存资料并记录SHA；运行核查脚本后创建草稿PR交主编。**不要擅自覆盖 `main`；不要把未部署的内容声称已上线。**

## 永久禁止

- 因十年跨越导致原控制区无端消失，或因单次战斗凭空扩大整块殖民版图。
- 将现代行政边界、示意凸包、法令地点折线或屏幕符号直接当古代实测辖区，或从中计算历史殖民面积。
- 把新的地图地名标签误记为实际“新征服”，把本地自治/独立政体统一改成英王直接殖民。
- 捏造来源、数字、战争疆界、撤军日期、海上航迹或殖民收益；删除无法证明的疑点而不记录。
- 只提交大量事件、不提交前后年代政治与空间变化说明。

## 已研究的连续性基线

- [1497—1529年33份年末状态及地理差异](research/continuity/CONTROL_TIMELINE_1497_1529.json)
- [1529→1530年待调查承接清单](research/continuity/TRANSITION_1529_1530_RESEARCH_SEED.json)
- [主编集成交接](research/continuity/EDITOR_HANDOFF_1497_1529.md)

这些文件是带来源与审核等级的**历史研究基线**，而非证明所有边界均精准。用户确认的“十年不重置、关注真实疆域变化”的规则适用于往后所有研究年代；规范与连续研究基线已通过主编无冲突整理（PR #15）进入 `main`；第四章候审事件与未经核准的历史疆界仍处于审核阶段，不能作为正式地图事实直接发布。

如遇既有指令冲突：**史料真实性和疆域类型区分优先；已批准的地图交互由主编负责保持；未确认的数据交由下一调查员继续核查。**


## R2 · 19世纪T14当前接力（2026-11-22）

新制作任务 **T14信德、旁遮普、阿瓦德征服与掠夺**：[专题工作清单](research/19c/consolidated/T14_NEXT_ACTIONS.md)；[29节长篇](data/stories/serial/e19-t14-sindh-punjab-awadh-conquest-expropriation-1842-1859.json)；[51已有事件的去重台账](data/research/19c-t14-existing-event-crosswalk.json)；[严格史料和历史GIS审计](docs/research/19C_T14_CONQUEST_PLUNDER_SOURCE_GIS_AUDIT.md)。只复用现有51旧事件ID、增3地名参考点，1855年阿瓦德旧边界明确虚线，不得编造战时死亡或财产金额。制作PR #515已49/49全站CI和Chrome通过并合并；母专题已转published/approved，正在独立出版PR审核与Pages部署。T05已正式`published/approved`并完结。
