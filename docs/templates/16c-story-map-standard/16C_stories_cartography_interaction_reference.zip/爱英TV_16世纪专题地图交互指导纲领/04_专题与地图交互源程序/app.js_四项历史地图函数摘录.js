function renderNineYearsWarImpact(){
 groups.nineYearsWar.clearLayers();
 if(!nineYearsWarImpact||year<1594||year>1599||
    !$('toggleTerritorialFootprints').checked||!$('toggleControlAreas').checked)return;
 const available=nineYearsWarImpact.features.filter(f=>{
  const p=f.properties||{};
  return p.map_layer==='territory'&&p.historical_boundary_confirmed===false&&
   p.fill_authorized===false&&p.territorial_claim===false&&p.area_sqkm===null&&
   year>=p.start_year&&year<=p.end_year;
 });
 for(const f of available){
  const p=f.properties,stage=p.year_stages?.find(q=>year>=q.start_year&&year<=q.end_year);
  const current=stage?{...f,properties:{...p,name:stage.title,
   summary_zh:stage.summary_zh,source_ids:stage.source_ids,
   related_event_ids:stage.related_event_ids,
   start_year:stage.start_year,
   end_year:stage.start_year===stage.end_year?null:stage.end_year}}:f;
  const isRoute=f.geometry.type==='LineString',isResistance=p.zone_type==='gaelic_resistance_plantation_collapse_schematic',
   isBattle=p.zone_type==='gaelic_resistance_to_crown_campaign_schematic';
  const style=isRoute?
   {color:'#e4a86a',weight:3.1,opacity:.94,dashArray:'10 7',
    lineJoin:'round',className:'atlas-essex-1599-schematic'}:
   {color:isResistance?'#66bc9e':isBattle?'#68b5bb':'#79aaa9',
    weight:2.2,opacity:.9,dashArray:'8 6',
    fill:true,fillColor:isResistance?'#3d9275':'#4e8f9f',
    fillOpacity:.12,className:'atlas-nine-years-war-study'};
  const pane=isRoute?'warReachPane':'invasionImpactPane';
  const renderer=isRoute?warReachRenderer:invasionImpactRenderer;
  L.geoJSON(current,{pane,renderer,interactive:true,bubblingMouseEvents:false,
   style:()=>style,
   onEachFeature:(_feature,layer)=>{
    layer.bindTooltip('<strong>'+escapeHTML(current.properties.name)+'</strong><div class="atlas-hover-summary">'+
     escapeHTML(p.label_type||'战争研究区')+' · 查看史料</div>',
     {sticky:true,direction:'auto',pane:'eventTooltipPane',className:'atlas-hover'});
    layer.on('click',e=>{
     if(e.originalEvent)L.DomEvent.stopPropagation(e.originalEvent);
     openTerritoryDossier(current,'nine-years-war');
    });
   }
  }).addTo(groups.nineYearsWar);
 }
}


function renderEarlyRegionalImpactAreas(){
 groups.earlyRegionalImpact.clearLayers();
 if(!earlyRegionalAreas||!$('toggleTerritorialFootprints').checked||!$('toggleControlAreas').checked)return;
 for(const feature of activeRegionalFeatures()){
  const p=feature.properties||{};
  if(p.historical_boundary_confirmed!==false||
     p.fill_authorized!==false||p.territorial_claim!==false||p.area_sqkm!==null)continue;
  const ochre=p.color_role==='plantation_ochre',violet=p.color_role==='occupation_violet',blue=p.color_role==='restoration_blue';
  const color=ochre?'#c49c58':violet?'#9475bc':blue?'#77b3ca':'#c56873',ring=feature.geometry.coordinates[0];
  const style={color,weight:2.5,opacity:.95,dashArray:ochre?'7 6':'8 6',fill:true,fillColor:color,
   fillOpacity:ochre?.11:.14,className:'atlas-early-regional-impact'};
  const open=e=>{if(e?.originalEvent)L.DomEvent.stopPropagation(e.originalEvent);openTerritoryDossier(feature,regionalFeatureKind(p));};
  const tooltip='<strong>'+escapeHTML(p.name)+'</strong><div class="atlas-hover-summary">地区历史 · 点击查看事件</div>';
  if(map.getZoom()<5){
   const center=ring.slice(0,-1).reduce((xy,[lon,lat],_,arr)=>[xy[0]+lat/arr.length,xy[1]+lon/arr.length],[0,0]);
   L.circleMarker(center,{renderer:invasionImpactRenderer,pane:'invasionImpactPane',radius:26,
    ...style,fillOpacity:.10,className:'atlas-early-regional-impact atlas-schematic-screen-cue',
    bubblingMouseEvents:false}).bindTooltip(tooltip,{sticky:true,direction:'auto',pane:'eventTooltipPane',className:'atlas-hover'})
    .on('click',open).addTo(groups.earlyRegionalImpact);
  }else{
   L.geoJSON(feature,{renderer:invasionImpactRenderer,pane:'invasionImpactPane',interactive:true,
    bubblingMouseEvents:false,style:()=>style,
    onEachFeature:(_f,layer)=>layer.bindTooltip(tooltip,
      {sticky:true,direction:'auto',pane:'eventTooltipPane',className:'atlas-hover'}).on('click',open)})
    .addTo(groups.earlyRegionalImpact);
  }
 }
}


function renderControlAreas(){
 groups.controlAreas.clearLayers();
 if(!frenchCityAreas||!$('toggleControlAreas').checked)return;
 for(const f of frenchCityAreas.features||[]){
  const p=f.properties||{};
  // Every selected year represents its year-end political snapshot.
  // An approximate district polygon must never hide a documented urban control core.
  if(year<(p.start_year||1497)||year>(p.observed_through_year||1519))continue;
  const coords=f.geometry?.coordinates;
  if(f.geometry?.type!=='Point'||!coords||coords.length!==2)continue;
  const center=[coords[1],coords[0]],zoom=map.getZoom();
  const isTournai=String(f.id).includes('tournai');
  const controller=controllerAtYear(p,year);
  const palette=controller?historicControllerPalette[controller.controller_group]:null;
  const mainColor=palette?.cityFill||(isTournai?'#c5a0f1':'#9867dd');
  const glowColor=palette?.cityHalo||(isTournai?'#e0bfff':'#a57de3');
  // City control is a sourced position, not a circular polygon of measured territory.
  const radius=Math.max(5.2,Math.min(8,5.6+Math.max(0,zoom-5)*.6));
  const core=L.circleMarker(center,{pane:'controlAreaPane',radius,
   color:glowColor,weight:2,opacity:1,fill:true,fillColor:mainColor,fillOpacity:.85,
   bubblingMouseEvents:false})
   .bindTooltip('<strong>'+escapeHTML(controller?p.draw_label+' · '+controller.controller_zh+'治理':p.name)+'</strong><div class="atlas-hover-summary">'+escapeHTML(historicAreaDescription(p,year))+'</div>',
    {sticky:true,direction:'auto',pane:'eventTooltipPane',className:'atlas-hover',offset:[12,0]})
   .on('click',()=>{
    const record=findPlaceAcrossChapters(p.source_place_id);
    // Source places may retain their Tudor-era text; show selected-year government.
    if(controller)openTerritoryDossier(f,'historic');
    else if(record)openDossier(record,'place');else openTerritoryDossier(f,'historic');
   }).addTo(groups.controlAreas);
  // Low-key geo-label shows which urban area changes, with no blocking background.
  if(zoom>=6){
   const label=L.divIcon({className:'',html:'<span class="control-area-label">'+escapeHTML(p.draw_label)+'</span>',
    iconSize:[60,17],iconAnchor:[30,-radius-4]});
   L.marker(center,{icon:label,interactive:false,pane:'controlAreaPane',zIndexOffset:0})
    .addTo(groups.controlAreas);
  }
 }
}


function focusEventFromSidebar(item){
 const options=arguments[1]||{};
 if(!item)return;
 if(!options.keepDossier)openDossier(item,'event');
 focusRequestToken++;
 focusedEventId=null;
 if(!canLocateEvent(item,year)){
  const note=!occurredByYear(item,year)?'请先将时间轴移至事件发生年份。':'此事件位置尚未核实，无法地图定位。';
  if(!options.keepDossier)$('dossierBody').insertAdjacentHTML('beforeend','<p class="atlas-location-note">'+escapeHTML(note)+'</p>');
  renderPoints();
  return;
 }
 stopPlay();
 focusedEventId=item.id;
 if(options.revealMap&&isCompactMap()){
  workspace.classList.add('dossier-collapsed','sidebar-collapsed');
  syncMobileEventsButton();syncPanels();
 }
 const token=focusRequestToken,position=[item.lat,item.lng];
 setTimeout(()=>{
  if(token!==focusRequestToken||focusedEventId!==item.id||!canLocateEvent(item,year))return;
  // Wait for dossier layout and then pan; never call flyTo, setZoom or change year.
  map.invalidateSize({pan:false});
  map.stop();
  map.once('moveend',()=>{
   if(token===focusRequestToken&&focusedEventId===item.id)renderPoints();
  });
  map.panTo(position,{animate:true,duration:0.9,easeLinearity:0.22});
  // Preserve smooth motion; if a remote jump is interrupted by layout/tile races,
  // settle on the requested historical event without changing zoom or the selected year.
  setTimeout(()=>{
   if(token!==focusRequestToken||focusedEventId!==item.id||!canLocateEvent(item,year))return;
   if(Math.abs(map.getCenter().lat-position[0])>0.35||Math.abs(map.getCenter().lng-position[1])>0.35){
    map.panTo(position,{animate:false});renderPoints();
   }
  },1600);
  renderPoints();
 },300);
}
